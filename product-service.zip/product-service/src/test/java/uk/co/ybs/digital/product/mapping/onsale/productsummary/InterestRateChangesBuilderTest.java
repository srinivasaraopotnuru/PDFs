package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.text.ParseException;
import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.InterestRateChanges;

public class InterestRateChangesBuilderTest {

  private InterestRateChangesBuilder testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new InterestRateChangesBuilder();
  }

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  public void testMapsSuccessfullyForFixedProduct() throws ParseException {
    final WebSiteProduct webSiteProduct =
        TestHelper.buildFullWebsiteProductFixedISA(
            "No", "Fixed Rate Cash ISA until 30 September 2022", "", "Fixed Rate ISA", "Yes");

    final Content item1 =
        Content.builder().format(FormatType.TEXT.getFormat()).text("<bold>No<bold>").build();
    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("The interest rate is fixed until 30 September 2022.")
            .build();

    final InterestRateChanges expected =
        InterestRateChanges.builder()
            .section(buildSection("2", true, true))
            .title("Can Yorkshire Building Society change the interest rate?")
            .content(Arrays.asList(item1, item2))
            .build();

    final InterestRateChanges result = testSubject.map(webSiteProduct);
    assertThat(result, is(expected));
  }

  @Test
  public void testMapsSuccessfullyForVariableProduct() throws ParseException {
    final WebSiteProduct webSiteProduct =
        TestHelper.buildFullWebsiteProductVariableISA(
            "Yes",
            "",
            "",
            "Internet Saver ISA Plus",
            "Internet Saver ISA Plus Issue 8",
            "Yes",
            "",
            "",
            "Yes",
            "",
            "Yes",
            "Yes",
            0,
            "Yes",
            "");

    final Content item1 =
        Content.builder().format(FormatType.TEXT.getFormat()).text("<bold>Yes<bold>").build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "We can make changes to the interest rate on this account for particular reasons. <link>General Terms and Conditions<link> 7 and 8 set out those reasons. Term 11 tells you how we will notify you of the changes.")
            .link("https://www.ybs.co.uk/productdata/YBM0617_Inline_General_TandCs.pdf")
            .build();

    final InterestRateChanges expected =
        InterestRateChanges.builder()
            .section(buildSection("2", true, true))
            .title("Can Yorkshire Building Society change the interest rate?")
            .content(Arrays.asList(item1, item2))
            .build();

    final InterestRateChanges result = testSubject.map(webSiteProduct);
    assertThat(expected, is(result));
  }
}
