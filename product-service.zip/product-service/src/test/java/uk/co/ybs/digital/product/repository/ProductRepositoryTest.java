package uk.co.ybs.digital.product.repository;

import static com.spotify.hamcrest.optional.OptionalMatchers.optionalWithValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.test.context.ActiveProfiles;
import uk.co.ybs.digital.product.config.ProductServiceConfig;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.InterestTier;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductRule;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;

@DataJpaTest
@ActiveProfiles({"test", "text-logging"})
@Import({ProductServiceConfig.class, ProductRepositoryTest.TestClockConfig.class})
class ProductRepositoryTest {

  private static final ZoneId ZONE_ID = ZoneId.of("Europe/London");
  private static final Instant NOW_INSTANT = Instant.parse("2020-04-23T13:56:15Z");
  private static final LocalDateTime NOW = LocalDateTime.ofInstant(NOW_INSTANT, ZONE_ID);
  private static final String FOO_PRODUCT_IDENTIFIER = "foo";
  private static final String BAR_PRODUCT_IDENTIFIER = "bar";
  private static final String BAZ_PRODUCT_IDENTIFIER = "baz";
  private static final String ISA_PRODUCT_TYPE = "ISA";
  private static final String CHAR_VALUE_Y = "Y";
  private static final String CHAR_VALUE_N = "N";
  private static final String PRODUCT_TYPE_CODE = "PRDTYP";
  private static final String WEB_RETENTION_CODE = "WEBRET";
  private static final String STOP_REC_CODE = "STPREC";
  private static final String BOND_PRODUCT_TYPE = "BOND";

  @Autowired private ProductRepository productRepository;

  @Autowired private Clock clock;

  @Autowired private TestEntityManager testEntityManager;

  private Product productWithSmartTieredTrue;
  private Product productWithSmartTieredFalse;
  private Product productWithSmartTieredNull;

  @BeforeEach
  void beforeEach() {
    productWithSmartTieredTrue =
        testEntityManager.persist(buildProduct(1L, FOO_PRODUCT_IDENTIFIER, true));
    productWithSmartTieredFalse =
        testEntityManager.persist(buildProduct(2L, BAR_PRODUCT_IDENTIFIER, false));
    productWithSmartTieredNull =
        testEntityManager.persist(buildProduct(3L, BAZ_PRODUCT_IDENTIFIER, null));
    persist();

    productWithSmartTieredNull.setSmartTiered(false);
    // need to override this to false after saving to db for assertions since smart tier field is
    // mapped to false if null in table
  }

  @Test
  void findByIdShouldReturnProduct() {
    final Optional<Product> found = productRepository.findById(1L);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(productWithSmartTieredTrue));
    assertThat(found.get(), samePropertyValuesAs(productWithSmartTieredTrue));
  }

  @Test
  void findByProductIdentifierShouldReturnProductAndInterestTiers() {
    final InterestTier tier1a =
        buildInterestTier(
            1L,
            productWithSmartTieredTrue,
            new BigDecimal("1.23"),
            new BigDecimal("4.56"),
            NOW,
            null,
            new BigDecimal("1.00"));
    final InterestTier tier1b =
        buildInterestTier(
            2L,
            productWithSmartTieredTrue,
            new BigDecimal("2.23"),
            new BigDecimal("5.56"),
            NOW,
            null,
            new BigDecimal("2.00"));
    final InterestTier tier2a =
        buildInterestTier(
            3L,
            productWithSmartTieredFalse,
            new BigDecimal("3.23"),
            new BigDecimal("6.56"),
            NOW,
            null,
            new BigDecimal("3.00"));
    persist(tier1a, tier1b, tier2a);

    assertThat(
        productRepository.findByProductIdentifier(FOO_PRODUCT_IDENTIFIER, NOW),
        optionalWithValue(
            samePropertyValuesAs(
                productWithSmartTieredTrue
                    .toBuilder()
                    .interestTier(tier1a)
                    .interestTier(tier1b)
                    .build())));
    assertThat(
        productRepository.findByProductIdentifier(BAR_PRODUCT_IDENTIFIER, NOW),
        optionalWithValue(
            samePropertyValuesAs(
                productWithSmartTieredFalse.toBuilder().interestTier(tier2a).build())));
  }

  @Test
  void findByProductIdentifierShouldReturnProductWhenNoInterestTiersExist() {
    assertThat(
        productRepository.findByProductIdentifier(FOO_PRODUCT_IDENTIFIER, NOW),
        optionalWithValue(samePropertyValuesAs(productWithSmartTieredTrue)));
  }

  @Test
  void findByProductIdentifierShouldReturnEmptyOptionalWhenProductDoesNotExist() {
    assertThat(productRepository.findByProductIdentifier("unknown", NOW), is(Optional.empty()));
  }

  @ParameterizedTest
  @CsvSource({"1,true", "2,false"})
  void findByProductIdentifierShouldFilterInterestTiersByProduct(
      final Long productSysid, final boolean expectFind) {
    findByProductIdentifierShouldFilterInterestTiers(productSysid, NOW, null, expectFind);
  }

  @ParameterizedTest
  @CsvSource({"-100,true", "-2,true", "-1,true", "0,true", "1,false", "2,false", "100,false"})
  void findByProductIdentifierShouldFilterInterestTiersByStartDate(
      final Long startDateAdjustmentSeconds, final boolean expectFind) {
    findByProductIdentifierShouldFilterInterestTiers(
        1L, NOW.plusSeconds(startDateAdjustmentSeconds), null, expectFind);
  }

  @ParameterizedTest
  @CsvSource(
      value = {
        "-100,false",
        "-2,false",
        "-1,false",
        "0,false",
        "1,true",
        "2,true",
        "100,true",
        "null,true"
      },
      nullValues = "null")
  void findByProductIdentifierShouldFilterInterestTiersByStartEndDate(
      final Long endDateAdjustmentSeconds, final boolean expectFind) {
    final LocalDateTime endDate =
        endDateAdjustmentSeconds == null ? null : NOW.plusSeconds(endDateAdjustmentSeconds);
    findByProductIdentifierShouldFilterInterestTiers(1L, NOW, endDate, expectFind);
  }

  private void findByProductIdentifierShouldFilterInterestTiers(
      final Long productSysid,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final boolean expectFind) {
    final Product product = testEntityManager.find(Product.class, productSysid);
    final InterestTier tier =
        buildInterestTier(
            1L,
            product,
            new BigDecimal("1.23"),
            new BigDecimal("4.56"),
            startDate,
            endDate,
            new BigDecimal("1.00"));
    persist(tier);

    final Product expected =
        expectFind
            ? productWithSmartTieredTrue.toBuilder().interestTier(tier).build()
            : productWithSmartTieredTrue;

    assertThat(
        productRepository.findByProductIdentifier(FOO_PRODUCT_IDENTIFIER, NOW),
        optionalWithValue(samePropertyValuesAs(expected)));
  }

  @Test
  void findAllByProductSearchCriteriaShouldFindAllProductsWhenNoCriteriaSpecified() {
    final Page<Product> multipleProductsInOnePageSearchResult =
        productRepository.findAll(
            ProductSearchCriteria.builder().build(), PageRequest.of(0, 10, Direction.ASC, "sysid"));
    assertThat(multipleProductsInOnePageSearchResult.getNumber(), is(0));
    assertThat(multipleProductsInOnePageSearchResult.getSize(), is(10));
    assertThat(multipleProductsInOnePageSearchResult.getTotalPages(), is(1));
    assertThat(multipleProductsInOnePageSearchResult.getTotalElements(), is(3L));
    assertThat(
        multipleProductsInOnePageSearchResult.getContent(),
        contains(
            samePropertyValuesAs(productWithSmartTieredTrue),
            samePropertyValuesAs(productWithSmartTieredFalse),
            samePropertyValuesAs(productWithSmartTieredNull)));
  }

  @Test
  void findAllByProductSearchCriteriaShouldFindProductsWithMatchingProductIdentifier() {
    final Page<Product> multipleProductsInOnePageSearchResult =
        productRepository.findAll(
            ProductSearchCriteria.builder()
                .productIdentifiers(
                    new HashSet<>(Arrays.asList(BAZ_PRODUCT_IDENTIFIER, BAR_PRODUCT_IDENTIFIER)))
                .build(),
            PageRequest.of(0, 10, Direction.ASC, "sysid"));
    assertThat(multipleProductsInOnePageSearchResult.getNumber(), is(0));
    assertThat(multipleProductsInOnePageSearchResult.getSize(), is(10));
    assertThat(multipleProductsInOnePageSearchResult.getTotalPages(), is(1));
    assertThat(multipleProductsInOnePageSearchResult.getTotalElements(), is(2L));
    assertThat(
        multipleProductsInOnePageSearchResult.getContent(),
        contains(
            samePropertyValuesAs(productWithSmartTieredFalse),
            samePropertyValuesAs(productWithSmartTieredNull)));
  }

  @Test
  void findAllByProductSearchCriteriaShouldFindPageOfProductsWithMatchingProductIdentifier() {
    final Page<Product> multipleProductsInOnePageSearchResult =
        productRepository.findAll(
            ProductSearchCriteria.builder()
                .productIdentifiers(
                    new HashSet<>(Arrays.asList(BAZ_PRODUCT_IDENTIFIER, FOO_PRODUCT_IDENTIFIER)))
                .build(),
            PageRequest.of(1, 1, Direction.ASC, "sysid"));
    assertThat(multipleProductsInOnePageSearchResult.getNumber(), is(1));
    assertThat(multipleProductsInOnePageSearchResult.getSize(), is(1));
    assertThat(multipleProductsInOnePageSearchResult.getTotalPages(), is(2));
    assertThat(multipleProductsInOnePageSearchResult.getTotalElements(), is(2L));
    assertThat(
        multipleProductsInOnePageSearchResult.getContent(),
        contains(samePropertyValuesAs(productWithSmartTieredNull)));
  }

  @Test
  void findReinvestableProductsShouldReturnProducts() {
    final Product product = productRepository.findById(1L).orElse(Product.builder().build());
    persistProductRuleAndAvailableProductRule(product, PRODUCT_TYPE_CODE, ISA_PRODUCT_TYPE);
    persistProductRuleAndAvailableProductRule(product, WEB_RETENTION_CODE, CHAR_VALUE_Y);
    persistProductRuleAndAvailableProductRule(product, STOP_REC_CODE, CHAR_VALUE_N);

    final List<Product> reinvestableProducts =
        productRepository.findReinvestableProducts(ISA_PRODUCT_TYPE, NOW);

    final List<Product> expectedProducts = Collections.singletonList(product);

    assertThat(reinvestableProducts, is(expectedProducts));
  }

  @Test
  void findReinvestableProductsShouldReturnMultipleProducts() {
    final Product product1 = productRepository.findById(1L).orElse(Product.builder().build());
    persistProductRuleAndAvailableProductRule(product1, PRODUCT_TYPE_CODE, BOND_PRODUCT_TYPE);
    persistProductRuleAndAvailableProductRule(product1, WEB_RETENTION_CODE, CHAR_VALUE_Y);
    persistProductRuleAndAvailableProductRule(product1, STOP_REC_CODE, CHAR_VALUE_N);

    final Product product2 = productRepository.findById(2L).orElse(Product.builder().build());
    persistProductRuleOnly(product2, PRODUCT_TYPE_CODE, BOND_PRODUCT_TYPE);
    persistProductRuleOnly(product2, WEB_RETENTION_CODE, CHAR_VALUE_Y);
    persistProductRuleOnly(product2, STOP_REC_CODE, CHAR_VALUE_N);

    final List<Product> reinvestableProducts =
        productRepository.findReinvestableProducts(BOND_PRODUCT_TYPE, NOW);

    final List<Product> expectedProducts = Arrays.asList(product1, product2);

    assertThat(reinvestableProducts, is(expectedProducts));
  }

  @ParameterizedTest
  @MethodSource("invalidProductRules")
  void findReinvestableProductsShouldNotReturnProductsWithInvalidRules(
      final List<String> productRuleCodes,
      final List<String> productRuleValues,
      final String productSearchType) {
    final Product product = productRepository.findById(1L).orElse(Product.builder().build());

    persistProvidedProductRules(product, productRuleCodes, productRuleValues);

    final List<Product> reinvestableProducts =
        productRepository.findReinvestableProducts(productSearchType, NOW);

    assertThat(reinvestableProducts, is(Collections.emptyList()));
  }

  static Stream<Arguments> invalidProductRules() {
    return Stream.of(
        // WEBRET = N
        Arguments.of(
            Arrays.asList(PRODUCT_TYPE_CODE, WEB_RETENTION_CODE),
            Arrays.asList(ISA_PRODUCT_TYPE, CHAR_VALUE_N),
            ISA_PRODUCT_TYPE),
        Arguments.of(
            Arrays.asList(PRODUCT_TYPE_CODE, WEB_RETENTION_CODE, STOP_REC_CODE),
            Arrays.asList(ISA_PRODUCT_TYPE, CHAR_VALUE_N, CHAR_VALUE_N),
            ISA_PRODUCT_TYPE),
        // STPREC = Y
        Arguments.of(
            Arrays.asList(PRODUCT_TYPE_CODE, WEB_RETENTION_CODE, STOP_REC_CODE),
            Arrays.asList(ISA_PRODUCT_TYPE, CHAR_VALUE_Y, CHAR_VALUE_Y),
            ISA_PRODUCT_TYPE),
        // Product type different from searched product type
        Arguments.of(
            Arrays.asList(PRODUCT_TYPE_CODE, WEB_RETENTION_CODE, STOP_REC_CODE),
            Arrays.asList(BOND_PRODUCT_TYPE, CHAR_VALUE_Y, CHAR_VALUE_N),
            ISA_PRODUCT_TYPE),
        // WEBRET rule missing
        Arguments.of(
            Arrays.asList(PRODUCT_TYPE_CODE, STOP_REC_CODE),
            Arrays.asList(BOND_PRODUCT_TYPE, CHAR_VALUE_N),
            BOND_PRODUCT_TYPE),
        // PRDTYP rule missing
        Arguments.of(
            Arrays.asList(WEB_RETENTION_CODE, STOP_REC_CODE),
            Arrays.asList(CHAR_VALUE_Y, CHAR_VALUE_N),
            BOND_PRODUCT_TYPE));
  }

  private void persist(final Object... objects) {
    for (final Object object : objects) {
      testEntityManager.persist(object);
    }
    testEntityManager.flush();
    testEntityManager.clear();
  }

  private Product buildProduct(
      final Long sysId, final String productIdentifier, final Boolean smartTiered) {
    return Product.builder()
        .sysid(sysId)
        .productIdentifier(productIdentifier)
        .startDate(LocalDateTime.now(clock).withNano(0))
        .endedDate(LocalDateTime.now(clock).plusSeconds(1).withNano(0))
        .dateObsolete(LocalDateTime.now(clock).plusSeconds(3).withNano(0))
        .brandCode("YBS")
        .penaltyDays(30)
        .fatcaReportable("N")
        .cardAvailable("N")
        .divisorDays(366)
        .previousDivisorDays(366)
        .periodEndDate(LocalDateTime.now(clock).plusSeconds(4).withNano(0))
        .penaltyCode(2)
        .penaltyAmount(new BigDecimal("999999999.990"))
        .periodEndIndicator("P")
        .smartTiered(smartTiered)
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private InterestTier buildInterestTier(
      final Long sysid,
      final Product product,
      final BigDecimal rangeLow,
      final BigDecimal rangeHigh,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final BigDecimal interestRate) {
    return InterestTier.builder()
        .sysid(sysid)
        .product(product)
        .rangeLow(rangeLow)
        .rangeHigh(rangeHigh)
        .startDate(startDate)
        .endDate(endDate)
        .interestRate(interestRate)
        .build();
  }

  private void persistProductRuleAndAvailableProductRule(
      final Product product, final String availableProductRuleCode, final String charValue) {
    buildAndPersistProductRule(product, availableProductRuleCode, charValue, true);
  }

  private void persistProductRuleOnly(
      final Product product, final String availableProductRuleCode, final String charValue) {
    buildAndPersistProductRule(product, availableProductRuleCode, charValue, false);
  }

  private void buildAndPersistProductRule(
      final Product product,
      final String availableProductRuleCode,
      final String charValue,
      final boolean persistAvailableProductRule) {
    final AvailableProductRule availableProductRule =
        AvailableProductRule.builder()
            .valueType(AvailableProductRule.ValueType.CHAR)
            .code(availableProductRuleCode)
            .build();

    if (persistAvailableProductRule) {
      persist(availableProductRule);
    }

    final ProductRule productRule =
        ProductRule.builder()
            .id(
                ProductRule.ProductRuleId.builder()
                    .apruleCode(availableProductRule.getCode())
                    .sprdSysid(product.getSysid())
                    .startDate(NOW.plusMonths(1L))
                    .build())
            .product(product)
            .availableProductRule(availableProductRule)
            .charValue(charValue)
            .build();

    persist(productRule);
  }

  void persistProvidedProductRules(
      final Product product,
      final List<String> productRuleCodes,
      final List<String> productRuleValues) {
    IntStream.range(0, productRuleCodes.size())
        .forEach(
            i ->
                persistProductRuleAndAvailableProductRule(
                    product, productRuleCodes.get(i), productRuleValues.get(i)));
  }

  static class TestClockConfig {
    @Primary
    @Bean
    public Clock testClock() {
      return Clock.fixed(NOW_INSTANT, ZONE_ID);
    }
  }
}
