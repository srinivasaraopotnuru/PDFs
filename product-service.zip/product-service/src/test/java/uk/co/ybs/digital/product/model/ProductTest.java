package uk.co.ybs.digital.product.model;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class ProductTest {
  @CsvSource({
    "2019-11-04T12:00:00,2019-11-04T11:59:59,true",
    "2019-11-04T12:00:00,2019-11-04T12:00:00,true",
    "2019-11-04T12:00:00,2019-11-04T12:00:01,false",
    ",2019-11-04T12:00:01,true"
  })
  @ParameterizedTest
  void shouldBeActiveWhenCandidateNotAfterEndedDate(
      final LocalDateTime endedDate, final LocalDateTime candidate, final boolean isActive) {
    final Product product = Product.builder().endedDate(endedDate).build();

    assertThat(product.isActiveAt(candidate), is(isActive));
  }

  @CsvSource({
    "2019-11-04T12:00:00,2019-11-04T11:59:59,true",
    "2019-11-04T12:00:00,2019-11-04T12:00:00,true",
    "2019-11-04T12:00:00,2019-11-04T12:00:01,false",
    ",2019-11-04T12:00:01,true"
  })
  @ParameterizedTest
  void shouldBeActiveWhenCandidateNotAfterDateObsolete(
      final LocalDateTime dateObsolete, final LocalDateTime candidate, final boolean isActive) {
    final Product product = Product.builder().dateObsolete(dateObsolete).build();

    assertThat(product.isActiveAt(candidate), is(isActive));
  }

  @CsvSource({
    "2019-11-04T12:00:00, 2019-11-04T12:00:02,2019-11-04T12:00:01,true",
    "2019-11-04T12:00:00, 2019-11-04T12:00:02,2019-11-04T12:00:00,true",
    "2019-11-04T12:00:00, 2019-11-04T12:00:02,2019-11-04T12:00:03,false",
    "2019-11-04T12:00:00,,2019-11-04T12:00:00,true",
    "2019-11-04T12:00:00,,2019-11-04T11:59:59,false",
  })
  @ParameterizedTest
  void shouldBeOpenWhenCandidateBetweenStartAndEndDate(
      final LocalDateTime startDate,
      final LocalDateTime endedDate,
      final LocalDateTime candidate,
      final boolean isOpen) {
    final Product product = Product.builder().startDate(startDate).endedDate(endedDate).build();

    assertThat(product.isOpenAt(candidate), is(isOpen));
  }
}
