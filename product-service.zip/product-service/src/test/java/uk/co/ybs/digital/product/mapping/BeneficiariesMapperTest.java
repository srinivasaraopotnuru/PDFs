package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.TestDataFactory.longProductRule;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;

@ExtendWith(MockitoExtension.class)
class BeneficiariesMapperTest {
  private static final long MAX_EXTERNAL_BENEFICIARIES = 10L;
  private static final long MAX_INTERNAL_BENEFICIARIES = 20L;

  @InjectMocks private BeneficiariesMapper testSubject;

  @Test
  void shouldMapPrivateBeneficiaries() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                longProductRule(
                    AvailableProductRule.EXTERNAL_BENEFICIARIES, MAX_EXTERNAL_BENEFICIARIES),
                longProductRule(
                    AvailableProductRule.INTERNAL_BENEFICIARIES, MAX_INTERNAL_BENEFICIARIES))
            .build();

    final ProductDetailsResponsePrivate.Beneficiaries beneficiaries =
        testSubject.mapPrivate(activeProductRules);
    assertThat(
        beneficiaries,
        is(
            ProductDetailsResponsePrivate.Beneficiaries.builder()
                .external(MAX_EXTERNAL_BENEFICIARIES)
                .internal(MAX_INTERNAL_BENEFICIARIES)
                .build()));
  }
}
