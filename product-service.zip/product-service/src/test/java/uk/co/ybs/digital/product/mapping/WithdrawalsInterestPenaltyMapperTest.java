package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.math.BigDecimal;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.WithdrawalsPrivate.InterestPenalty;

class WithdrawalsInterestPenaltyMapperTest {

  private final WithdrawalsInterestPenaltyMapper testSubject =
      new WithdrawalsInterestPenaltyMapper();

  @Test
  void shouldMapWhenPenaltyDaysPositive() {
    final Integer code = 2;
    final Integer days = 30;
    final BigDecimal balanceUpperBound = new BigDecimal("999999999.99");

    final Product product =
        Product.builder()
            .penaltyCode(code)
            .penaltyDays(days)
            .penaltyAmount(balanceUpperBound)
            .build();

    assertThat(
        testSubject.map(product),
        is(
            Optional.of(
                InterestPenalty.builder()
                    .code(code)
                    .days(days)
                    .balanceUpperBound(balanceUpperBound)
                    .build())));
  }

  @ParameterizedTest
  @ValueSource(ints = {Integer.MIN_VALUE, -1, 0})
  void shouldMapWhenPenaltyDaysNotPositive(final int penaltyDays) {
    final Product product = Product.builder().penaltyDays(penaltyDays).build();

    assertThat(testSubject.map(product), is(Optional.empty()));
  }
}
