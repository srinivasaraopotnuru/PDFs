package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.util.Base64;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.exception.ProductIngestException;
import uk.co.ybs.digital.product.service.LiferayDocument;
import uk.co.ybs.digital.product.service.WebSiteProduct;

@ExtendWith(MockitoExtension.class)
class WebsiteProductMapperTest {

  private static final String YES = "Yes";

  private WebSiteProductMapper testSubject;

  private final ObjectMapper objectMapper = new ObjectMapper();

  @BeforeEach
  public void beforeEach() {
    testSubject = new WebSiteProductMapper(objectMapper);
  }

  @Test
  void shouldMap() {

    final String productListString = readClassPathResource("api/productInfo/ProductInfo.json");

    LiferayDocument liferayDocument =
        LiferayDocument.builder()
            .contentValue(new String(Base64.getEncoder().encode(productListString.getBytes())))
            .build();

    final List<WebSiteProduct> productList = testSubject.map(liferayDocument);

    assertThat(productList, contains(createWebProduct()));
  }

  @Test
  void mapShouldThrowProductIngestExceptionWhenNotJson() {

    LiferayDocument liferayDocument =
        LiferayDocument.builder()
            .contentValue(new String(Base64.getEncoder().encode("Yo!".getBytes())))
            .build();

    final ProductIngestException exception =
        Assertions.assertThrows(
            ProductIngestException.class, () -> testSubject.map(liferayDocument));

    assertThat(exception.getMessage(), is("Unable to deserialize product info"));
    assertThat(exception.getCause().getClass(), is(JsonParseException.class));
  }

  @Test
  void mapShouldThrowProductIngestExceptionWhenNotBase64Encoded() {

    LiferayDocument liferayDocument = LiferayDocument.builder().contentValue("X").build();

    final ProductIngestException exception =
        Assertions.assertThrows(
            ProductIngestException.class, () -> testSubject.map(liferayDocument));

    assertThat(exception.getMessage(), is("Unable to deserialize product info"));
    assertThat(exception.getCause().getClass(), is(IllegalArgumentException.class));
  }

  private WebSiteProduct createWebProduct() {
    return WebSiteProduct.builder()
        .brand("YBS")
        .accountNameFull("Six Access e-Saver Issue 4")
        .accountNameShort("Six Access e-Saver")
        .newProduct(YES)
        .productID("YB841278W")
        .productCode("YB841278W")
        .equivalentProduct("")
        .effectiveDate("18/11/2020")
        .endDate("")
        .maxBalance(500000)
        .minOpeningBalance(1)
        .interestType("Variable")
        .interestAnnually(YES)
        .interestMonthly("")
        .annualGrossT1("0.15")
        .annualAERT1("0.15")
        .minBalanceT1("1")
        .tieredProduct(YES)
        .annualGrossT2("0.25")
        .annualAERT2("0.25")
        .minBalanceT2("1000")
        .annualGrossT3("0.40")
        .annualAERT3("0.40")
        .minBalanceT3("10000")
        .annualGrossT4("0.45")
        .annualAERT4("0.45")
        .minBalanceT4("50000")
        .previousRate("")
        .effectiveDatePrevious("")
        .applyOnline(YES)
        .applyInBranch("")
        .applyInAgency("")
        .applyByPost("")
        .manageOnline(YES)
        .viewOnline(YES)
        .manageInBranch("")
        .manageByPost("")
        .manageInAgency("")
        .trusteeAccountsAccepted("")
        .maturesIntoProductName("")
        .accountSwitching(YES)
        .maxAccountHolders(2)
        .minAgeCustomer(16)
        .interestDateLong1("31 March")
        .interestDateLong2("")
        .interestDateLong3("")
        .exampleBalanceT1(BigDecimal.valueOf(500.75))
        .exampleTermT1(12)
        .exampleStartingAmountT1(500)
        .exampleBalanceT2(BigDecimal.valueOf(1002.5))
        .exampleTermT2(12)
        .exampleStartingAmountT2(1000)
        .exampleBalanceT3(BigDecimal.valueOf(10040.0))
        .exampleTermT3(12)
        .exampleStartingAmountT3(10000)
        .exampleBalanceT4(BigDecimal.valueOf(50225.0))
        .exampleTermT4(12)
        .exampleStartingAmountT4(50000)
        .taxFree("")
        .fixedTerm("")
        .easyAccess(YES)
        .bond("")
        .cashISA("")
        .flexibleISA("")
        .passbook("")
        .withdrawalsPermitted(YES)
        .withdrawalDays(6)
        .closurePermitted(YES)
        .cancellationPermitted("")
        .maturityProduct("")
        .maturityHoldingPage("")
        .popularity(1)
        .prodType("Limited Access")
        .build();
  }
}
