package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Projections;

public class ProjectionsBuilderTest {
  private ProjectionsBuilder testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new ProjectionsBuilder();
  }

  @MethodSource("dataSource")
  @ParameterizedTest
  public void testMapsSuccessfully(
      final WebSiteProduct webSiteProduct, final Projections expected) {
    final Projections result = testSubject.map(webSiteProduct);
    assertThat(result, is(expected));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> dataSource() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "",
                "",
                "",
                "Annual Access Saver",
                "Annual Access Saver",
                "",
                "",
                "",
                "",
                "Yes",
                "",
                "Yes",
                0,
                "Yes",
                ""),
            buildProjectionsForFixedTerm()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "",
                "",
                "",
                "Help to Buy: ISA",
                "Help to Buy: ISA",
                "",
                "",
                "",
                "",
                "No",
                "",
                "Yes",
                0,
                "Yes",
                ""),
            buildProjectionsForHelpToBuyIsa()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "",
                "",
                "",
                "Annual Access Saver",
                "Annual Access Saver",
                "",
                "",
                "",
                "",
                "No",
                "",
                "Yes",
                0,
                "Yes",
                ""),
            buildProjectionsForOther()));
  }

  private static Projections buildProjectionsForFixedTerm() {
    final List<Content> contentList = new ArrayList<>();

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("At the end of the fixed term, the balance would be £500.75.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "We have worked this out assuming a £500 deposit is made on account opening on the first day the product goes on sale, interest earned is added to the account and no further deposits or withdrawals are made throughout the fixed-term.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "This projection is provided for illustrative purposes only and does not take into account your individual circumstances.")
            .build();

    contentList.addAll(Arrays.asList(item1, item2, item3));
    return Projections.builder()
        .title(
            "What would be the estimated balance at the end of the fixed term based on a £1,000 deposit?")
        .section(buildSection("3", true, true))
        .content(contentList)
        .build();
  }

  private static Projections buildProjectionsForHelpToBuyIsa() {
    final List<Content> contentList = new ArrayList<>();

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "£500 as an initial deposit and £50 each subsequent month saved at tax-free p.a./AER would lead to a balance of £500.75 at the end of the first 12 months.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "This projection is provided for illustrative purposes only and does not take into account your individual circumstances")
            .build();

    contentList.addAll(Arrays.asList(item1, item2));
    return Projections.builder()
        .title("What would be the estimated balance after 12 months based on a range of deposits?")
        .section(buildSection("3", true, true))
        .content(contentList)
        .build();
  }

  private static Projections buildProjectionsForOther() {
    final List<Content> contentList = new ArrayList<>();

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("If you deposit £500, after 12 months your balance would be £500.75")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("If you deposit £1,000, after 12 months your balance would be £1,002.50")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("If you deposit £10,000, after 12 months your balance would be £10,035.00")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("If you deposit £50,000, after 12 months your balance would be £50,200.00")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("If you deposit £80,000, after 12 months your balance would be £81,000.00")
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "We have worked this out assuming a deposit is made on account opening, no further deposits or withdrawals are made throughout the 12 months, the interest earned is added to the account and no changes made to the current interest rate.")
            .build();

    final Content item7 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "This projection is provided for illustrative purposes only and does not take into account your individual circumstances.")
            .build();

    contentList.addAll(Arrays.asList(item1, item2, item3, item4, item5, item6, item7));
    return Projections.builder()
        .title("What would be the estimated balance after 12 months based on a range of deposits?")
        .section(buildSection("3", true, true))
        .content(contentList)
        .build();
  }
}
