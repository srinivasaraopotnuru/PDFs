package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Applications;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Balance;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Deposits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Isa;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Saver;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Withdrawals;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.Beneficiaries;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.InterestPrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.IsaPrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.WithdrawalsPrivate;

@ExtendWith(MockitoExtension.class)
class ProductDetailsResponseMapperTest {

  private static final String PRODUCT_TYPE = "PRDTYP";
  private static final String MAXIMUM_NUMBER_OF_ACCOUNTS = "MAXNPD";
  private static final String CUSTOMER_DESCRIPTION = "CUSDES";
  private static final String MAXIMUM_MONTHLY_PAYMENT = "MAXPAY";
  private static final LocalDateTime NOW = LocalDateTime.parse("2019-09-10T00:30:00.0");
  private static final int CURRENT_TESSA_YEAR = 22;
  private static final String KYC_COLLECTION = "KYCCOL";
  private static final String YBS_BRAND_CODE = "YBS";
  private static final String PRODUCT_ID = "product-id";
  private static final String MY_PRODUCT_TYPE = "my-product-type";
  private static final String MY_CUSTOMER_DESCRIPTION = "my-customer-description";

  private ProductDetailsResponseMapper testSubject;

  @Mock private WithdrawalsMapper withdrawalsMapper;
  @Mock private DepositsMapper depositsMapper;
  @Mock private BalanceMapper balanceMapper;
  @Mock private ApplicationsMapper applicationsMapper;
  @Mock private InterestMapper interestMapper;
  @Mock private IsaMapper isaMapper;
  @Mock private SaverMapper saverMapper;
  @Mock private BeneficiariesMapper beneficiariesMapper;

  @BeforeEach
  public void beforeEach() {
    testSubject =
        new ProductDetailsResponseMapper(
            withdrawalsMapper,
            depositsMapper,
            balanceMapper,
            applicationsMapper,
            interestMapper,
            isaMapper,
            saverMapper,
            beneficiariesMapper);
  }

  @Test
  void shouldMap() {
    final Product product =
        Product.builder()
            .brandCode(YBS_BRAND_CODE)
            .cardAvailable("Y")
            .productIdentifier(PRODUCT_ID)
            .smartTiered(true)
            .build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(PRODUCT_TYPE, MY_PRODUCT_TYPE),
            TestDataFactory.longProductRule(MAXIMUM_NUMBER_OF_ACCOUNTS, 2L),
            TestDataFactory.charProductRule(CUSTOMER_DESCRIPTION, MY_CUSTOMER_DESCRIPTION),
            TestDataFactory.moneyProductRule(MAXIMUM_MONTHLY_PAYMENT, BigDecimal.TEN),
            TestDataFactory.charProductRule(KYC_COLLECTION, "Y"));

    final Withdrawals mappedWithdrawals = Withdrawals.builder().permittedOverWeb(true).build();
    when(withdrawalsMapper.map(product, productRules, NOW)).thenReturn(mappedWithdrawals);
    final Deposits mappedDeposits = Deposits.builder().build();
    when(depositsMapper.map(product, productRules, NOW)).thenReturn(mappedDeposits);
    final Applications mappedApplications = Applications.builder().build();
    when(applicationsMapper.map(product, productRules, NOW)).thenReturn(mappedApplications);
    final Interest mappedInterest = Interest.builder().build();
    when(interestMapper.map(product, productRules)).thenReturn(mappedInterest);
    final Isa mappedIsa = Isa.builder().build();
    when(isaMapper.map(productRules)).thenReturn(mappedIsa);
    final Saver mappedSaver = Saver.builder().build();
    when(saverMapper.map(productRules)).thenReturn(mappedSaver);
    when(balanceMapper.map(productRules)).thenReturn(Optional.empty());

    assertThat(
        testSubject.map(product, productRules, NOW),
        is(
            ProductDetailsResponse.builder()
                .brandCode(YBS_BRAND_CODE)
                .cardAvailable(true)
                .productIdentifier(PRODUCT_ID)
                .isKycRequired(true)
                .customerDescription(MY_CUSTOMER_DESCRIPTION)
                .productType(MY_PRODUCT_TYPE)
                .smartTiered(true)
                .maximumNumberOfAccounts(2L)
                .deposits(mappedDeposits)
                .applications(mappedApplications)
                .interest(mappedInterest)
                .withdrawals(mappedWithdrawals)
                .isa(mappedIsa)
                .saver(mappedSaver)
                .build()));
  }

  @Test
  void shouldMapPrivate() {
    final Product product =
        Product.builder()
            .sysid(1L)
            .startDate(LocalDateTime.parse("2019-07-11T00:00:00"))
            .brandCode(YBS_BRAND_CODE)
            .cardAvailable("Y")
            .smartTiered(false)
            .productIdentifier(PRODUCT_ID)
            .build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(PRODUCT_TYPE, MY_PRODUCT_TYPE),
            TestDataFactory.longProductRule(MAXIMUM_NUMBER_OF_ACCOUNTS, 2L),
            TestDataFactory.charProductRule(CUSTOMER_DESCRIPTION, MY_CUSTOMER_DESCRIPTION),
            TestDataFactory.moneyProductRule(MAXIMUM_MONTHLY_PAYMENT, BigDecimal.TEN),
            TestDataFactory.charProductRule(KYC_COLLECTION, "Y"));

    final WithdrawalsPrivate mappedWithdrawals =
        WithdrawalsPrivate.builder()
            .permittedOverWeb(true)
            .permittedOverWebOnAccountClosure(true)
            .build();
    when(withdrawalsMapper.mapPrivate(product, productRules, NOW)).thenReturn(mappedWithdrawals);
    final Deposits mappedDeposits = Deposits.builder().build();
    when(depositsMapper.map(product, productRules, NOW)).thenReturn(mappedDeposits);
    final Applications mappedApplications = Applications.builder().build();
    when(applicationsMapper.map(product, productRules, NOW)).thenReturn(mappedApplications);
    final InterestPrivate mappedInterest = InterestPrivate.builder().build();
    when(interestMapper.mapPrivate(product, productRules)).thenReturn(mappedInterest);
    final IsaPrivate mappedIsaPrivate = IsaPrivate.builder().isaYear(CURRENT_TESSA_YEAR).build();
    when(isaMapper.mapPrivate(productRules, NOW)).thenReturn(mappedIsaPrivate);
    final Saver mappedSaverPrivate = Saver.builder().build();
    when(saverMapper.map(productRules)).thenReturn(mappedSaverPrivate);
    final Beneficiaries mappedBeneficiaries = Beneficiaries.builder().build();
    when(beneficiariesMapper.mapPrivate(productRules)).thenReturn(mappedBeneficiaries);
    when(balanceMapper.map(productRules)).thenReturn(Optional.empty());

    assertThat(
        testSubject.mapPrivate(product, productRules, NOW),
        is(
            ProductDetailsResponsePrivate.builder()
                .productSysId(1L)
                .startDate(LocalDateTime.parse("2019-07-11T00:00:00"))
                .brandCode(YBS_BRAND_CODE)
                .isKycRequired(true)
                .cardAvailable(true)
                .productIdentifier(PRODUCT_ID)
                .customerDescription(MY_CUSTOMER_DESCRIPTION)
                .productType(MY_PRODUCT_TYPE)
                .maximumNumberOfAccounts(2L)
                .deposits(mappedDeposits)
                .applications(mappedApplications)
                .interest(mappedInterest)
                .withdrawals(mappedWithdrawals)
                .isa(mappedIsaPrivate)
                .saver(mappedSaverPrivate)
                .beneficiaries(mappedBeneficiaries)
                .smartTiered(false)
                .build()));
  }

  @Test
  void shouldMapDepositsWhenPresent() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules = createActiveProductRules();
    final Withdrawals mappedWithdrawals = Withdrawals.builder().permittedOverWeb(true).build();

    when(withdrawalsMapper.map(product, productRules, NOW)).thenReturn(mappedWithdrawals);
    final Deposits mappedDeposits =
        Deposits.builder()
            .limits(
                Deposits.DepositLimits.builder()
                    .amount(PeriodLimits.<BigDecimal>builder().year(BigDecimal.TEN).build())
                    .build())
            .build();
    when(depositsMapper.map(product, productRules, NOW)).thenReturn(mappedDeposits);
    when(balanceMapper.map(productRules)).thenReturn(Optional.empty());

    final Applications mappedApplication = Applications.builder().build();
    when(applicationsMapper.map(product, productRules, NOW)).thenReturn(mappedApplication);

    assertThat(
        testSubject.map(product, productRules, NOW),
        is(
            ProductDetailsResponse.builder()
                .cardAvailable(false)
                .applications(mappedApplication)
                .withdrawals(mappedWithdrawals)
                .deposits(mappedDeposits)
                .build()));
  }

  @Test
  void shouldMapBalanceWhenPresent() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules = createActiveProductRules();
    final Withdrawals mappedWithdrawals = Withdrawals.builder().permittedOverWeb(true).build();
    when(withdrawalsMapper.map(product, productRules, NOW)).thenReturn(mappedWithdrawals);
    final Deposits mappedDeposits = Deposits.builder().build();
    when(depositsMapper.map(product, productRules, NOW)).thenReturn(mappedDeposits);
    final Balance mappedBalance = Balance.builder().min(BigDecimal.ONE).build();
    when(balanceMapper.map(productRules)).thenReturn(Optional.of(mappedBalance));

    final Applications mappedApplication = Applications.builder().build();

    when(applicationsMapper.map(product, productRules, NOW)).thenReturn(mappedApplication);

    assertThat(
        testSubject.map(product, productRules, NOW),
        is(
            ProductDetailsResponse.builder()
                .cardAvailable(false)
                .applications(mappedApplication)
                .withdrawals(mappedWithdrawals)
                .deposits(mappedDeposits)
                .balance(mappedBalance)
                .build()));
  }

  @Test
  void defaultsCardAvailableToFalse() {
    final Product product = Product.builder().build();
    final ActiveProductRules activeProductRules = createActiveProductRules();
    assertThat(testSubject.map(product, activeProductRules, NOW).isCardAvailable(), is(false));
  }
}
