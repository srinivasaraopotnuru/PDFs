package uk.co.ybs.digital.product.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.product.web.dto.reinvestment.ProductReinvestmentResponse;
import uk.co.ybs.digital.product.web.dto.reinvestment.ReinvestmentProduct;

@JsonTest
class ProductReinvestmentResponseResponseJsonTest {

  @Autowired private JacksonTester<ProductReinvestmentResponse> json;

  @Value("classpath:responses/ProductReinvestmentResponse.json")
  private Resource file;

  private ProductReinvestmentResponse response;

  @BeforeEach
  void beforeEach() {
    response =
        ProductReinvestmentResponse.builder()
            .reinvestmentProducts(
                Collections.singletonList(
                    ReinvestmentProduct.builder().productIdentifier("WXYZ4321").build()))
            .build();
  }

  @Test
  void testSerialize() throws Exception {
    assertThat(json.write(response)).isEqualToJson(file, JSONCompareMode.STRICT);
  }

  @Test
  void testDeserialize() throws Exception {
    assertThat(json.readObject(file)).isEqualTo(response);
  }
}
