package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;
import static uk.co.ybs.digital.product.utils.TestHelper.ALLOW_BANK_TRANSFER_DEPOSITS;
import static uk.co.ybs.digital.product.utils.TestHelper.ALLOW_BRANCH_TRANSFERS;
import static uk.co.ybs.digital.product.utils.TestHelper.ALLOW_DIRECT_DEBIT_DEPOSITS;
import static uk.co.ybs.digital.product.utils.TestHelper.ISA_FLEXIBLE;
import static uk.co.ybs.digital.product.utils.TestHelper.ISA_HELP_TO_BUY;
import static uk.co.ybs.digital.product.utils.TestHelper.PAYMENT_ACCOUNT;
import static uk.co.ybs.digital.product.utils.TestHelper.PRODUCT_TYPE;
import static uk.co.ybs.digital.product.utils.TestHelper.STOP_EXTERNAL_DEPOSITS;
import static uk.co.ybs.digital.product.utils.TestHelper.WEB_TRANSACTIONS;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Deposits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Deposits.DepositLimits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;

@ExtendWith(MockitoExtension.class)
class DepositsMapperTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2019-09-10T00:30:00.0");

  @InjectMocks private DepositsMapper testSubject;

  @Mock private DepositLimitsMapper limitsMapper;

  @Mock private PeriodLimitsChecker periodLimitsChecker;

  @Mock private DepositsByCardChecker depositsByCardChecker;

  @Test
  void shouldMapProductRules() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule("STPREC", "N"),
            TestDataFactory.charProductRule("TRNSFR", "Y"),
            TestDataFactory.charProductRule("BRTRAN", "Y"));
    final DepositLimits depositLimits =
        Deposits.DepositLimits.builder()
            .amount(
                ProductDetailsResponse.PeriodLimits.<BigDecimal>builder()
                    .taxYear(BigDecimal.TEN)
                    .build())
            .build();

    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.of(depositLimits));

    assertThat(
        testSubject.map(product, productRules, NOW),
        is(
            Deposits.builder()
                .permittedExternal(true)
                .permittedInternal(false)
                .permittedInBranch(true)
                .limits(depositLimits)
                .build()));
  }

  @ParameterizedTest(name = "{0} rule evaluates to {2}")
  @MethodSource("externalDepositRules")
  void
      externalDepositsPermittedWhenAllowBankTransfersRuleIsYesAndStopExternalDepositsRuleIsNoOrAbsent(
          final String description, final ActiveProductRules rules, final boolean expectedValue) {
    final Product product = activeProductBuilder().build();
    assertThat(testSubject.map(product, rules, NOW).isPermittedExternal(), is(expectedValue));
  }

  private static Stream<Arguments> externalDepositRules() {

    final ActiveProductRules externalDepositsStoppedNoAndBankTransferAllowedYes =
        createActiveProductRules(
            TestDataFactory.charProductRule(STOP_EXTERNAL_DEPOSITS, "N"),
            TestDataFactory.charProductRule(ALLOW_BANK_TRANSFER_DEPOSITS, "Y"));

    final ActiveProductRules externalDepositsStoppedNoAndBankTransferAllowedNo =
        createActiveProductRules(
            TestDataFactory.charProductRule(STOP_EXTERNAL_DEPOSITS, "N"),
            TestDataFactory.charProductRule(ALLOW_BANK_TRANSFER_DEPOSITS, "N"));

    final ActiveProductRules externalDepositsStoppedNoAndBankTransferAllowedNotPresent =
        createActiveProductRules(TestDataFactory.charProductRule(STOP_EXTERNAL_DEPOSITS, "N"));

    final ActiveProductRules externalDepositsStoppedYesAndBankTransferAllowedYes =
        createActiveProductRules(
            TestDataFactory.charProductRule(STOP_EXTERNAL_DEPOSITS, "Y"),
            TestDataFactory.charProductRule(ALLOW_BANK_TRANSFER_DEPOSITS, "Y"));

    final ActiveProductRules externalDepositsStoppedYesAndBankTransferAllowedNo =
        createActiveProductRules(
            TestDataFactory.charProductRule(STOP_EXTERNAL_DEPOSITS, "Y"),
            TestDataFactory.charProductRule(ALLOW_BANK_TRANSFER_DEPOSITS, "N"));

    final ActiveProductRules externalDepositsStoppedYesAndBankTransferAllowedNotPresent =
        createActiveProductRules(TestDataFactory.charProductRule(STOP_EXTERNAL_DEPOSITS, "Y"));

    final ActiveProductRules bankTransferAllowedYesAndExternalDepositsStoppedNotPresent =
        createActiveProductRules(
            TestDataFactory.charProductRule(ALLOW_BANK_TRANSFER_DEPOSITS, "Y"));

    final ActiveProductRules bankTransferAllowedNoAndExternalDepositsStoppedNotPresent =
        createActiveProductRules(
            TestDataFactory.charProductRule(ALLOW_BANK_TRANSFER_DEPOSITS, "N"));

    final ActiveProductRules emptyProductRules = createActiveProductRules();

    return Stream.of(
        Arguments.of(
            "external deposits not stopped and bank transfers allowed",
            externalDepositsStoppedNoAndBankTransferAllowedYes,
            true),
        Arguments.of(
            "external deposits not stopped and bank transfers not allowed",
            externalDepositsStoppedNoAndBankTransferAllowedNo,
            false),
        Arguments.of(
            "external deposits not stopped and bank transfers rule not present",
            externalDepositsStoppedNoAndBankTransferAllowedNotPresent,
            true),
        Arguments.of(
            "external deposits stopped and bank transfers allowed",
            externalDepositsStoppedYesAndBankTransferAllowedYes,
            false),
        Arguments.of(
            "external deposits stopped and bank transfers not allowed",
            externalDepositsStoppedYesAndBankTransferAllowedNo,
            false),
        Arguments.of(
            "external deposits stopped and bank transfers rule not present",
            externalDepositsStoppedYesAndBankTransferAllowedNotPresent,
            false),
        Arguments.of(
            "bank transfers allowed and external deposits stopped not present",
            bankTransferAllowedYesAndExternalDepositsStoppedNotPresent,
            true),
        Arguments.of(
            "bank transfers not allowed and external deposits stopped not present",
            bankTransferAllowedNoAndExternalDepositsStoppedNotPresent,
            false),
        Arguments.of(
            "bank transfers not present and external deposits stopped not present",
            emptyProductRules,
            true));
  }

  @ParameterizedTest
  @MethodSource("internalDepositsPermittedProductTypeRules")
  void internalDepositsPermittedForCorrectProductTypeAndWebTransactionsArePermitted(
      final ActiveProductRules productRules) {
    final Product product = activeProductBuilder().build();
    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.empty());
    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(true));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<ActiveProductRules> internalDepositsPermittedProductTypeRules() {
    return Stream.of(
        // Payment product
        internalDepositsProductRulesBuilder()
            .addRules(TestDataFactory.charProductRule(PAYMENT_ACCOUNT, "Y"))
            .build(),
        // Saver product
        internalDepositsProductRulesBuilder()
            .addRules(TestDataFactory.charProductRule(PRODUCT_TYPE, "SAVER"))
            .build(),
        // ISA product - Classic
        internalDepositsProductRulesBuilder()
            .addRules(TestDataFactory.charProductRule(PRODUCT_TYPE, "ISA"))
            .build(),
        // ISA product - Help to buy
        internalDepositsProductRulesBuilder()
            .addRules(
                TestDataFactory.charProductRule(PRODUCT_TYPE, "ISA"),
                TestDataFactory.charProductRule(ISA_HELP_TO_BUY, "Y"))
            .build(),
        // ISA product - Flexible
        internalDepositsProductRulesBuilder()
            .addRules(
                TestDataFactory.charProductRule(PRODUCT_TYPE, "ISA"),
                TestDataFactory.charProductRule(ISA_FLEXIBLE, "Y"))
            .build());
  }

  @ParameterizedTest
  @MethodSource("internalDepositsNotPermittedProductTypeRules")
  void internalDepositsNotPermittedForIncorrectProductTypeAndWebTransactionsArePermitted(
      final ActiveProductRules productRules) {
    final Product product = activeProductBuilder().build();
    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.empty());
    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(false));
  }

  private static Stream<ActiveProductRules> internalDepositsNotPermittedProductTypeRules() {
    return Stream.of(
        // No product type rules
        internalDepositsProductRulesBuilder().build(),
        // Invalid product type rule values
        internalDepositsProductRulesBuilder()
            .addRules(
                TestDataFactory.charProductRule(PAYMENT_ACCOUNT, "N"),
                TestDataFactory.charProductRule(PRODUCT_TYPE, "OTHER"))
            .build());
  }

  @Test
  void internalDepositsNotPermittedWhenAllowDepositsInternalIsFalse() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules productRules =
        validPaymentProductInternalDepositsProductRulesBuilder()
            .changeRule(ALLOW_BANK_TRANSFER_DEPOSITS, "N")
            .build();
    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.empty());
    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(false));
  }

  @Test
  void internalDepositsNotPermittedWhenAllowDepositsInternalDoesNotExist() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules productRules =
        validPaymentProductInternalDepositsProductRulesBuilder()
            .removeRules(ALLOW_BANK_TRANSFER_DEPOSITS)
            .build();
    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.empty());
    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(false));
  }

  @ParameterizedTest
  @MethodSource("productRulesAndExpectedSupportedPeriodLimits")
  void internalDepositsPermittedWhenLimitsAreSupported(
      final ActiveProductRules productRules,
      final SupportedPeriodLimits expectedSupportedPeriodLimits) {
    final Product product = activeProductBuilder().build();
    final DepositLimits depositLimits =
        DepositLimits.builder().amount(PeriodLimits.<BigDecimal>builder().build()).build();

    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.of(depositLimits));
    when(periodLimitsChecker.isSupported(
            same(depositLimits.getAmount()), eq(expectedSupportedPeriodLimits)))
        .thenReturn(true);

    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(true));
  }

  @ParameterizedTest
  @MethodSource("productRulesAndExpectedSupportedPeriodLimits")
  void internalDepositsNotPermittedWhenLimitsAreNotSupported(
      final ActiveProductRules productRules,
      final SupportedPeriodLimits expectedSupportedPeriodLimits) {
    final Product product = activeProductBuilder().build();
    final DepositLimits depositLimits = DepositLimits.builder().build();

    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.of(depositLimits));
    when(periodLimitsChecker.isSupported(
            same(depositLimits.getAmount()), eq(expectedSupportedPeriodLimits)))
        .thenReturn(false);

    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(false));
  }

  @ParameterizedTest(name = "{0} rule evaluates to {2}")
  @MethodSource("branchTransferDepositRules")
  void shouldMapBranchTransferProductRule(
      final String description, final ActiveProductRules rules, final boolean expectedValue) {
    final Product product = activeProductBuilder().build();
    assertThat(testSubject.map(product, rules, NOW).isPermittedInBranch(), is(expectedValue));
  }

  private static Stream<Arguments> branchTransferDepositRules() {
    final ActiveProductRules branchTransfersAllowedRule =
        createActiveProductRules(TestDataFactory.charProductRule(ALLOW_BRANCH_TRANSFERS, "Y"));

    final ActiveProductRules branchTransfersNotAllowedRule =
        createActiveProductRules(TestDataFactory.charProductRule(ALLOW_BRANCH_TRANSFERS, "N"));

    final ActiveProductRules branchTransfersRuleNotPresent = createActiveProductRules();
    return Stream.of(
        Arguments.of("bank transfers allowed by rule", branchTransfersAllowedRule, true),
        Arguments.of("bank transfers not allowed by rule", branchTransfersNotAllowedRule, false),
        Arguments.of("bank transfers rule empty", branchTransfersRuleNotPresent, true));
  }

  private static Stream<Arguments> productRulesAndExpectedSupportedPeriodLimits() {
    return Stream.of(
        Arguments.of(
            validPaymentProductInternalDepositsProductRules(),
            SupportedPeriodLimits.builder().month(true).taxYear(true).build()),
        Arguments.of(
            validPaymentProductInternalDepositsProductRulesBuilder()
                .addRules(TestDataFactory.charProductRule(PRODUCT_TYPE, "ISA"))
                .build(),
            SupportedPeriodLimits.builder().month(true).taxYear(true).build()),
        Arguments.of(
            validPaymentProductInternalDepositsProductRulesBuilder()
                .addRules(
                    TestDataFactory.charProductRule(PRODUCT_TYPE, "ISA"),
                    TestDataFactory.charProductRule(ISA_HELP_TO_BUY, "Y"))
                .build(),
            SupportedPeriodLimits.builder().firstMonth(true).month(true).taxYear(true).build()));
  }

  @Test
  void internalDepositsNotPermittedWhenTransactionsAreNotPermitted() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules productRules =
        validPaymentProductInternalDepositsProductRulesBuilder()
            .changeRule(WEB_TRANSACTIONS, "N")
            .build();
    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.empty());
    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(false));
  }

  @Test
  void internalDepositsNotPermittedWhenWebTransactionsRuleDoesNotExist() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules productRules =
        validPaymentProductInternalDepositsProductRulesBuilder()
            .removeRules(WEB_TRANSACTIONS)
            .build();
    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.empty());
    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(false));
  }

  @ParameterizedTest(name = "{0} should be {2}")
  @MethodSource("obsoleteAndEndedDates")
  void internalDepositsNotPermittedWhenProductIsObsoleteOrEnded(
      final String description,
      final Product product,
      final boolean expectedPermittedInternalValue) {
    final ActiveProductRules productRules = validPaymentProductInternalDepositsProductRules();
    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.empty());
    assertThat(
        testSubject.map(product, productRules, NOW).isPermittedInternal(),
        is(expectedPermittedInternalValue));
  }

  private static Stream<Arguments> obsoleteAndEndedDates() {
    final Product obsoleteYesterday = activeProductBuilder().dateObsolete(NOW.minusDays(1)).build();
    final Product endedYesterday = activeProductBuilder().endedDate(NOW.minusDays(1)).build();

    final Product obsoleteTomorrow = activeProductBuilder().dateObsolete(NOW.plusDays(1)).build();
    final Product endedTomorrow = activeProductBuilder().endedDate(NOW.plusDays(1)).build();

    final Product endedAndObsoleteNotSet = activeProductBuilder().build();

    return Stream.of(
        Arguments.of("obsoleteYesterday", obsoleteYesterday, false),
        Arguments.of("endedYesterday", endedYesterday, false),
        Arguments.of("obsoleteTomorrow", obsoleteTomorrow, true),
        Arguments.of("endedTomorrow", endedTomorrow, true),
        Arguments.of("endedAndObsoleteNotSet", endedAndObsoleteNotSet, true));
  }

  @Test
  void internalDepositsPermittedWhenDirectDebitAllowedWithoutLimits() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules productRules =
        validPaymentProductInternalDepositsProductRulesBuilder()
            .addRules(TestDataFactory.charProductRule(ALLOW_DIRECT_DEBIT_DEPOSITS, "Y"))
            .build();
    when(limitsMapper.map(productRules, NOW)).thenReturn(Optional.empty());
    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(true));
  }

  @Test
  void internalDepositsNotPermittedWhenDirectDebitAllowedWithLimits() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules productRules =
        validPaymentProductInternalDepositsProductRulesBuilder()
            .addRules(TestDataFactory.charProductRule(ALLOW_DIRECT_DEBIT_DEPOSITS, "Y"))
            .build();

    when(limitsMapper.map(productRules, NOW))
        .thenReturn(Optional.of(DepositLimits.builder().build()));
    when(periodLimitsChecker.isSupported(any(), any())).thenReturn(true);
    assertThat(testSubject.map(product, productRules, NOW).isPermittedInternal(), is(false));
  }

  @Test
  void permittedByCardShouldBeFalseWhenCardDepositsAreNotPermitted() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules productRules = createActiveProductRules();
    assertThat(testSubject.map(product, productRules, NOW).isPermittedByCard(), is(false));
  }

  @Test
  void permittedByCardShouldBeTrueWhenCardDepositsArePermitted() {
    final Product product = activeProductBuilder().build();
    final ActiveProductRules rules = createActiveProductRules();

    when(depositsByCardChecker.isSupported(rules)).thenReturn(true);

    assertThat(testSubject.map(product, rules, NOW).isPermittedByCard(), is(true));
  }

  private static TestDataFactory.ActiveProductRulesBuilder
      validPaymentProductInternalDepositsProductRulesBuilder() {
    return TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
        .rules(
            TestDataFactory.charProductRule(ALLOW_BANK_TRANSFER_DEPOSITS, "Y"),
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.charProductRule(PAYMENT_ACCOUNT, "Y"));
  }

  private static TestDataFactory.ActiveProductRulesBuilder internalDepositsProductRulesBuilder() {
    return TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
        .rules(
            TestDataFactory.charProductRule(ALLOW_BANK_TRANSFER_DEPOSITS, "Y"),
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"));
  }

  private static ActiveProductRules validPaymentProductInternalDepositsProductRules() {
    return validPaymentProductInternalDepositsProductRulesBuilder().build();
  }

  private static Product.ProductBuilder activeProductBuilder() {
    return Product.builder();
  }
}
