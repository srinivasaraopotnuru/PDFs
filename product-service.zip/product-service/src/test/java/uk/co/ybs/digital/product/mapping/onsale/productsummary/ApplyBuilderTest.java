package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Apply;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;

public class ApplyBuilderTest {

  private ApplyBuilder testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new ApplyBuilder();
  }

  @Test
  public void testMapsSuccessfully() {
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Complete our simple, straightforward application form")
            .build();

    final Content item2 =
        Content.builder().format(FormatType.BUTTON.getFormat()).text("Apply").build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "If you feel you need additional support before applying for this account, please call us")
            .build();

    final Content item4 =
        Content.builder().format(FormatType.TEXT.getFormat()).text("0345 1200 100").build();

    final Content item5 =
        Content.builder().format(FormatType.TEXT.getFormat()).text("9am - 5pm Mon-Fri").build();

    final Content item6 =
        Content.builder().format(FormatType.TEXT.getFormat()).text("9am - 1pm Sat").build();

    final Apply expected =
        Apply.builder()
            .section(buildSection("8", false, false))
            .title("Apply")
            .content(Arrays.asList(item1, item2, item3, item4, item5, item6))
            .build();

    final Apply result = testSubject.map();
    assertThat(result, is(expected));
  }
}
