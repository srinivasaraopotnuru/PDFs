package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ManageAccount;

public class ManageAccountBuilderTest {

  private ManageAccountBuilder testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new ManageAccountBuilder();
  }

  @MethodSource("dataSource")
  @ParameterizedTest
  public void testMapsSuccessfully(
      final WebSiteProduct webSiteProduct, final ManageAccount expected) {
    final ManageAccount result = testSubject.map(webSiteProduct);
    assertThat(result, is(expected));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> dataSource() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "Yes",
                "",
                "",
                "Help to Buy: ISA",
                "Help to Buy: ISA",
                "Yes",
                "Yes",
                "Yes",
                "Yes",
                "Yes",
                "Yes",
                "Yes",
                0,
                "Yes",
                ""),
            buildExpectedWhenTaxFreeHelpToBuyIsaAndCashIsaAndMaturityProductAndManageInBranchAndOnlineAndFixedTermAndAcountSwitching()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "No",
                "",
                "",
                "Limited Access Saver ISA",
                "Six Access Saver ISA Issue 3",
                "No",
                "No",
                "No",
                "Yes",
                "No",
                "No",
                "Yes",
                0,
                "Yes",
                ""),
            buildExpectedWhenNotTaxFreeAndLimitedAccessSaverIsaAndNotCashIsaAndNotMaturityProductAndManageOnlineAndNotFixedTermAndNoAccountSwitching()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "No",
                "",
                "",
                "Loyalty Six Access Saver ISA",
                "Six Access Saver ISA Issue 3",
                "Yes",
                "Yes",
                "Yes",
                "No",
                "No",
                "No",
                "Yes",
                0,
                "Yes",
                ""),
            buildExpectedWhenNotTaxFreeAndLoyaltySixAccessSaverIsaAndCashIsaAndMaturityProductAndNotFixedTermAndNoAccountSwitching()));
  }

  private static ManageAccount
      buildExpectedWhenTaxFreeHelpToBuyIsaAndCashIsaAndMaturityProductAndManageInBranchAndOnlineAndFixedTermAndAcountSwitching() {
    return ManageAccount.builder()
        .section(buildSection("4", true, true))
        .title("How do I open and manage my account?")
        .content(buildContent1())
        .build();
  }

  private static ManageAccount
      buildExpectedWhenNotTaxFreeAndLimitedAccessSaverIsaAndNotCashIsaAndNotMaturityProductAndManageOnlineAndNotFixedTermAndNoAccountSwitching() {
    return ManageAccount.builder()
        .section(buildSection("4", true, true))
        .title("How do I open and manage my account?")
        .content(buildContent2())
        .build();
  }

  private static ManageAccount
      buildExpectedWhenNotTaxFreeAndLoyaltySixAccessSaverIsaAndCashIsaAndMaturityProductAndNotFixedTermAndNoAccountSwitching() {
    return ManageAccount.builder()
        .section(buildSection("4", true, true))
        .title("How do I open and manage my account?")
        .content(buildContent3())
        .build();
  }

  private static List<Content> buildContent1() {
    final Content item0 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Eligibility").build();

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "You have to be at least 16 years old. You must be a UK resident for tax purposes, or be a qualifying Crown employee or married to, or in a civil partnership with a qualified Crown employee. The account can only be held in your name. You may only subscribe to one Cash ISA in a single tax year.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "To qualify for a Help to Buy: ISA you must be an “Eligible Customer” as defined in the Scheme Rules but in brief:")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.LIST.getFormat())
            .list(
                Arrays.asList(
                    "have a valid National Insurance number",
                    "be a first time buyer, and never owned a residential property anywhere in the world",
                    "For full details of the scheme rules please visit http://www.helptobuy.gov.uk/isa",
                    "Each Help to Buy: ISA account holder can only have one Help to Buy: ISA. If we identify that a second account is held with us this account will be closed and the latest issue Instant ISA will be opened with these funds on your behalf."))
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.HEADER.getFormat())
            .text("Account opening and management")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Accounts can be opened with a minimum of £1 by logging into your online account.")
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The account can be managed in branch, at an agency or by post. You can also <link>register<link> to manage your account online.")
            .link("https://www.ybs.co.uk/help/online/registration.html")
            .build();

    final Content item7 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("£1 is required to maintain the account after it has been opened")
            .build();

    final Content item8 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "There is no maximum balance for this account but the maximum amount eligible for a bonus is £300")
            .build();

    final Content item9 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "A maximum of £10 can be saved in each calendar month apart from the first calendar month of account opening when a further £9000 may be added.")
            .build();

    final Content item10 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "If more than the maximum monthly contribution of £10 is received the funds will be removed and we will return the overpayment by cheque.")
            .build();

    final Content item11 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The calendar month commences when the first deposit is received to the account and runs from the first to last day of each month. You do not need to save every month or save the same amount every month. If you set up a standing order to pay a monthly contribution, we recommend you set the date prior to the 24th each month to ensure that we receive the funds in time.")
            .build();

    final Content item12 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Deposits for the 2023/24 tax year’s unused ISA allowance, and internal transfers from other Yorkshire Building Society accounts, are permitted until the Fixed Rate Cash e-ISA is withdrawn from sale. ISA transfers in requests (either with us or from other providers) are permitted up to 12/12/2022. Please check with your existing ISA provider for any charges applicable on transfer. Any deposits received after these timescales will be returned to you.")
            .build();

    final Content item13 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Transfer charges may apply, please check with your existing provider. Do not transfer any ISA balance yourself otherwise you’ll lose your tax benefit.")
            .build();

    return Arrays.asList(
        item0, item1, item2, item3, item4, item5, item6, item7, item8, item9, item10, item11,
        item12, item13);
  }

  private static List<Content> buildContent2() {

    final Content item0 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Eligibility").build();

    final Content item1 =
        Content.builder()
            .format(FormatType.HEADER.getFormat())
            .text("Account opening and management")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "At maturity, the funds from your Loyalty Six Access Saver ISA will automatically be transferred into this Six Access Saver ISA Issue 3")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("The minimum balance is £1.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Accounts can be opened with a minimum of £1 online at ybs.co.uk.")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "You will be able to check your balance, interest rate, make and view transactions on your account online whenever you wish.")
            .build();

    return Arrays.asList(item0, item1, item2, item3, item4, item5);
  }

  private static List<Content> buildContent3() {

    final Content item0 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Eligibility").build();

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "You have to be at least 16 years old. You must be a UK resident for tax purposes, or be a qualifying Crown employee or married to, or in a civil partnership with a qualified Crown employee. The account can only be held in your name and you can only hold one account. You may only subscribe to one Cash ISA in a single tax year. If you are named on more than one Loyalty Six Access Saver ISA the most recent account opened will be transferred to the Six Access Saver ISA Issue 3.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "You must have had a continuous membership with Yorkshire Building Society starting on or before the 1st January 2020 with an open account (Savings or Mortgage) with Yorkshire Building Society or Chelsea Building Society or YBS SharePlans, as either Main Holder, Other Holder or Trustee to be eligible for the Loyalty Six Access Saver ISA account. Attorneys on an existing accounts will not be eligible.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.HEADER.getFormat())
            .text("Account opening and management")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "At maturity, the funds from your Loyalty Six Access Saver ISA will automatically be transferred into this Six Access Saver ISA Issue 3")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("The minimum balance is £1.")
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Accounts can be opened with a minimum of £1 by logging into your online account.")
            .build();

    final Content item7 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The account can be managed in branch, at an agency or by post. You can also view this account online.")
            .build();

    final Content item8 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The maximum balance is £20,000 for 2023/24 ISA allowance plus previous years’ ISA transfers. Please check with your existing provider if any charges are applicable on transfer.")
            .build();

    final Content item9 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Deposits for the current tax year’s ISA allowance can be made at any time. External transfers for any used ISA allowances, including both previous years’ and current years’ subscriptions are permitted.")
            .build();

    return Arrays.asList(item0, item1, item2, item3, item4, item5, item6, item7, item8, item9);
  }
}
