package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.AdditionalInformation;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;

public class AdditionalInformationBuilderTest {
  private AdditionalInformationBuilder testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new AdditionalInformationBuilder();
  }

  @MethodSource("dataSource")
  @ParameterizedTest
  public void testMapsSuccessfully(
      final WebSiteProduct webSiteProduct, final List<Content> expectedContentList) {
    final AdditionalInformation expected =
        AdditionalInformation.builder()
            .section(buildSection("6", true, true))
            .title("Additional information")
            .content(expectedContentList)
            .build();

    final AdditionalInformation result = testSubject.map(webSiteProduct);
    assertThat(result, is(expected));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> dataSource() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildFullWebsiteProductFixedISA(
                "No", "Fixed Rate Cash ISA until 30 September 2022", "", "Fixed Rate ISA", "Yes"),
            null),
        Arguments.of(
            TestHelper.buildFullWebsiteProductFixedISA(
                "Yes", "Help to Buy: ISA", "", "Fixed Rate ISA", "Yes"),
            buildHelpToBuyISAContent()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductFixedISA(
                "Yes", "Another ISA", "", "Fixed Rate ISA", "Yes"),
            buildAnotherISATypeWithoutApplyOnline()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductFixedISA(
                "Yes", "Another ISA", "Yes", "Fixed Rate ISA", "Yes"),
            buildAnotherISATypeWithApplyOnlineAndValidProductNameContent()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductFixedISA("Yes", "Another ISA", "Yes", "", "Yes"),
            buildAnotherISATypeWithApplyOnlineAndNoProductNameContent()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductFixedISA("Yes", "Another ISA", "Yes", null, "Yes"),
            buildAnotherISATypeWithApplyOnlineAndNoProductNameContent()));
  }

  private static List<Content> buildHelpToBuyISAContent() {
    final Content item1 =
        Content.builder()
            .format(FormatType.HEADER.getFormat())
            .text("Conditions for bonus payment")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("The bonus is paid by the scheme administrators, on behalf of HM Treasury.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "When you are ready to buy your new home you will need to close your Help to Buy: ISA rather than simply withdrawing the balance. Closing the account will generate a Closing Letter. This letter will contain all the information that your conveyancer or solicitor dealing with the purchase of your new home will need to claim the bonus on your behalf.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("You must operate your account within the scheme rules.")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("The property you are buying must:")
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.LIST.getFormat())
            .list(
                Arrays.asList(
                    "be in the UK and be a residential property",
                    "cost up to £250,000, or up to £450,000 if you are buying in London",
                    "not be a second home or a buy-to-let property",
                    "not be rented out after you buy it",
                    "you must claim your bonus within 12 months of closing your Help to Buy: ISA",
                    "be purchased with a mortgage. You can choose from a wide range of mortgages that are generally available in the market. If you choose to apply for a mortgage with us, holding a Yorkshire Building Society Help to Buy: ISA is not a guarantee that you will be approved for a mortgage with us."))
            .build();

    final Content item7 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The Help to Buy: ISA can be re-opened if a house purchase falls through and is evidenced within 12 months of the event occurring. Your conveyancer or solicitor will be able to provide a letter of re-instatement to undertake this.")
            .build();

    return Arrays.asList(item1, item2, item3, item4, item5, item6, item7);
  }

  private static List<Content> buildAnotherISATypeWithoutApplyOnline() {
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Interest earned from your ISA is tax-free and does not contribute to your Personal Savings Allowance.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "If you fail to invest in your Cash ISA in a single year, under HM Revenue and Customs rules you will be required to complete a declaration form before you can invest further.")
            .build();

    return Arrays.asList(item1, item2);
  }

  private static List<Content> buildAnotherISATypeWithApplyOnlineAndValidProductNameContent() {
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Interest earned from your ISA is tax-free and does not contribute to your Personal Savings Allowance.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "If you fail to invest in your Cash ISA in a single year, under HM Revenue and Customs rules you will be required to complete a declaration form before you can invest further.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "We will advise you of the forthcoming product maturity, and generally communicate with you via email. It is very important that you notify us if your email address changes.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "You can change your contact details (postal address, email and telephone) when you are logged in. To change your name you will need to write, enclosing proof of the change, to Savings Service, Yorkshire Building Society, Yorkshire House, Bradford, West Yorkshire, BD5 8LJ.")
            .build();

    return Arrays.asList(item1, item2, item3, item4);
  }

  private static List<Content> buildAnotherISATypeWithApplyOnlineAndNoProductNameContent() {
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Interest earned from your ISA is tax-free and does not contribute to your Personal Savings Allowance.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "If you fail to invest in your Cash ISA in a single year, under HM Revenue and Customs rules you will be required to complete a declaration form before you can invest further.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "We will generally communicate with you via email. It is very important that you notify us if your email address changes.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "You can change your contact details (postal address, email and telephone) when you are logged in. To change your name you will need to write, enclosing proof of the change, to Savings Service, Yorkshire Building Society, Yorkshire House, Bradford, West Yorkshire, BD5 8LJ.")
            .build();

    return Arrays.asList(item1, item2, item3, item4);
  }
}
