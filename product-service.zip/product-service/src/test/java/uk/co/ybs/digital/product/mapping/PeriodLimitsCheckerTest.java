package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase;

class PeriodLimitsCheckerTest {

  private final PeriodLimitsChecker testSubject = new PeriodLimitsChecker();

  @ParameterizedTest
  @MethodSource("getSupportedPeriodLimits")
  void allSupported(
      final ProductDetailsResponse.PeriodLimits<?> periodLimits,
      final SupportedPeriodLimits supportedPeriodLimits,
      final boolean expectedSupported) {
    final boolean supported = testSubject.isSupported(periodLimits, supportedPeriodLimits);
    assertThat(supported, is(expectedSupported));
  }

  private static Stream<Arguments> getSupportedPeriodLimits() {
    final ProductDetailsResponseBase.PeriodLimits<?> allPeriodLimits = buildAllPeriodLimits();
    final SupportedPeriodLimits allSupported = buildAllSupported();
    return Stream.of(
        /*
         * All period limits
         */
        Arguments.of(allPeriodLimits, allSupported, true),
        Arguments.of(allPeriodLimits, allSupported.toBuilder().firstMonth(false).build(), false),
        Arguments.of(allPeriodLimits, allSupported.toBuilder().month(false).build(), false),
        Arguments.of(allPeriodLimits, allSupported.toBuilder().year(false).build(), false),
        Arguments.of(
            allPeriodLimits, allSupported.toBuilder().anniversaryYear(false).build(), false),
        Arguments.of(allPeriodLimits, allSupported.toBuilder().taxYear(false).build(), false),
        Arguments.of(allPeriodLimits, allSupported.toBuilder().productTerm(false).build(), false),
        /*
         * No supported limits
         */
        Arguments.of(
            ProductDetailsResponseBase.PeriodLimits.builder().build(),
            SupportedPeriodLimits.builder().build(),
            true),
        Arguments.of(
            ProductDetailsResponseBase.PeriodLimits.builder().firstMonth(new Object()).build(),
            SupportedPeriodLimits.builder().build(),
            false),
        Arguments.of(
            ProductDetailsResponseBase.PeriodLimits.builder().month(new Object()).build(),
            SupportedPeriodLimits.builder().build(),
            false),
        Arguments.of(
            ProductDetailsResponseBase.PeriodLimits.builder().year(new Object()).build(),
            SupportedPeriodLimits.builder().build(),
            false),
        Arguments.of(
            ProductDetailsResponseBase.PeriodLimits.builder().anniversaryYear(new Object()).build(),
            SupportedPeriodLimits.builder().build(),
            false),
        Arguments.of(
            ProductDetailsResponseBase.PeriodLimits.builder().taxYear(new Object()).build(),
            SupportedPeriodLimits.builder().build(),
            false),
        Arguments.of(
            ProductDetailsResponseBase.PeriodLimits.builder().productTerm(new Object()).build(),
            SupportedPeriodLimits.builder().build(),
            false));
  }

  private static SupportedPeriodLimits buildAllSupported() {
    return SupportedPeriodLimits.builder()
        .firstMonth(true)
        .month(true)
        .year(true)
        .anniversaryYear(true)
        .taxYear(true)
        .productTerm(true)
        .build();
  }

  private static ProductDetailsResponseBase.PeriodLimits<?> buildAllPeriodLimits() {
    return ProductDetailsResponseBase.PeriodLimits.builder()
        .firstMonth(new Object())
        .month(new Object())
        .year(new Object())
        .anniversaryYear(new Object())
        .taxYear(new Object())
        .productTerm(new Object())
        .build();
  }
}
