package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.reinvestment.ProductReinvestmentResponse;
import uk.co.ybs.digital.product.web.dto.reinvestment.ReinvestmentProduct;

class ReinvestmentResponseMapperTest {
  private static final String PRODUCT_IDENTIFIER_1 = "ABCD1234";
  private static final String PRODUCT_IDENTIFIER_2 = "WXYZ4321";
  private static final String YBS_BRAND_CODE = "YBS";

  private ReinvestmentResponseMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new ReinvestmentResponseMapper();
  }

  @Test
  void mapShouldReturnReinvestmentResponseFromProductList() {
    final List<Product> eligibleProducts = buildEligibleProductList();

    final ProductReinvestmentResponse expected =
        ProductReinvestmentResponse.builder()
            .reinvestmentProducts(
                Stream.of(
                        ReinvestmentProduct.builder()
                            .productIdentifier(PRODUCT_IDENTIFIER_1)
                            .build(),
                        ReinvestmentProduct.builder()
                            .productIdentifier(PRODUCT_IDENTIFIER_2)
                            .build())
                    .collect(Collectors.toList()))
            .build();

    assertThat(testSubject.map(eligibleProducts), is(expected));
  }

  @Test
  void mapShouldReturnReinvestmentResponseWithEmptyReinvestmentProductListWithNoEligibleProducts() {
    final List<Product> eligibleProducts = Collections.emptyList();
    final ProductReinvestmentResponse expected =
        ProductReinvestmentResponse.builder().reinvestmentProducts(Collections.emptyList()).build();

    assertThat(testSubject.map(eligibleProducts), is(expected));
  }

  List<Product> buildEligibleProductList() {
    return Stream.of(
            Product.builder()
                .sysid(1L)
                .productIdentifier(PRODUCT_IDENTIFIER_1)
                .brandCode(YBS_BRAND_CODE)
                .startDate(LocalDateTime.parse("2022-10-05T01:00:00"))
                .smartTiered(false)
                .build(),
            Product.builder()
                .sysid(2L)
                .productIdentifier(PRODUCT_IDENTIFIER_2)
                .brandCode(YBS_BRAND_CODE)
                .startDate(LocalDateTime.parse("2022-01-01T04:00:00"))
                .smartTiered(false)
                .build())
        .collect(Collectors.toList());
  }
}
