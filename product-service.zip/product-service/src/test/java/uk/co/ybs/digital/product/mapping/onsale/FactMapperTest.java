package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.FormattedMoneySource;
import uk.co.ybs.digital.product.utils.NoValuesSource;
import uk.co.ybs.digital.product.web.dto.onsale.Fact;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;

@ExtendWith(MockitoExtension.class)
public class FactMapperTest {

  private static final String YES = "Yes";
  private static final String ANNUAL_INTEREST = "Annual interest";
  @InjectMocks private final FactMapper factMapper = new FactMapper();

  @Test
  void shouldDisplayDefaultFacts() throws ParseException {
    final WebSiteProduct webSiteProduct = validWebSiteProductBuilder().build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    assertThat(facts, is(buildDefaultFacts()));
  }

  @ParameterizedTest
  @NullSource
  @ValueSource(ints = {-1, 0})
  void shouldNotDisplaySaveFromWhenNoMinOpeningBalance(final Integer minOpeningBalance)
      throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().minOpeningBalance(minOpeningBalance).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    assertThat(facts, is(buildDefaultFacts()));
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldDisplaySaveFrom(final String cashIsa) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().minOpeningBalance(1).cashISA(cashIsa).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Save from £1").build(),
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @FormattedMoneySource
  void shouldDisplaySaveFromFactWithMoneyComma(
      final int openingBalance, final String formattedOpeningBalance) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().minOpeningBalance(openingBalance).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text(String.format("Save from £%s", formattedOpeningBalance)).build(),
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplaySaveFromInCashIsaFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().minOpeningBalance(1).cashISA(YES).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Save from £1 in this Cash ISA").build(),
            buildAnnualInterestFactCashISA(),
            buildWithdrawalsNotPermittedFact());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayAllFactsForFixedLoyaltyBond() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .interestAnnually(YES)
            .build()
            .toBuilder()
            .minOpeningBalance(1000)
            .accountNameShort("Loyalty Fixed Rate eBond (No Access) until 31/01/2024")
            .withdrawalsPermitted("No")
            .endDate("31/01/2024")
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Loyalty eligibility criteria applies").build(),
            Fact.builder().text("Save from £1,000").build(),
            buildInterestPaidOnFactForLoyaltyProduct(),
            buildWithdrawalsLoyaltyBond());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldNotDisplayTieredInterestFactWhenTieredProductPropertyIsFalse(
      final String tieredProduct) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().tieredProduct(tieredProduct).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    assertThat(facts, is(buildDefaultFacts()));
  }

  @ParameterizedTest
  @MethodSource("tieredInterestFactArguments")
  void shouldDisplayTieredInterestFactWhenMultipleTiers(
      final int numberOfTiers, final String expectedNumberWord, final WebSiteProduct webSiteProduct)
      throws ParseException {
    final List<InterestTier> interestTiers =
        IntStream.range(0, numberOfTiers)
            .mapToObj(
                i ->
                    InterestTier.builder()
                        .rate(i + "0.10")
                        .description("TierDescription")
                        .range("£1 - £999")
                        .build())
            .collect(Collectors.toList());

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Stream.of(
                numberOfTiers > 1
                    ? Fact.builder()
                        .text(
                            String.format(
                                "%s tiered interest rates - rate depends on account balance",
                                expectedNumberWord))
                        .build()
                    : null,
                buildAnnualInterestFact(),
                buildWithdrawalsNotPermittedFact())
            .filter(Objects::nonNull)
            .collect(Collectors.toList());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldSuppressTieredInterestFactWhenMultipleTiersWithSameRate() throws ParseException {
    final WebSiteProduct webSiteProduct = validWebSiteProductBuilder().tieredProduct(YES).build();

    final List<InterestTier> interestTiers =
        IntStream.range(0, 5)
            .mapToObj(
                i ->
                    InterestTier.builder()
                        .rate("2.25")
                        .description("TierDescription")
                        .range("£1 - £999")
                        .build())
            .collect(Collectors.toList());

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(buildAnnualInterestFact(), buildWithdrawalsNotPermittedFact());

    assertThat(facts, is(expected));
  }

  private static Stream<Arguments> tieredInterestFactArguments() {

    final WebSiteProduct tieredProduct = validWebSiteProductBuilder().tieredProduct(YES).build();
    final WebSiteProduct smartTieredProduct = validWebSiteProductBuilder().smartTiered(YES).build();

    final List<String> words =
        Arrays.asList(
            "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten");

    return IntStream.range(1, 11)
        .mapToObj(
            i ->
                Arrays.asList(
                    Arguments.of(i, words.get(i), tieredProduct),
                    Arguments.of(i, words.get(i), smartTieredProduct)))
        .flatMap(Collection::stream);
  }

  @Test
  void shouldDisplayMonthlyOrAnnualInterestFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().interestMonthly(YES).interestAnnually(YES).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder()
                .text("Monthly or annual interest - rate varies for monthly interest")
                .build(),
            Fact.builder().text("Online pays annual interest").build(),
            buildWithdrawalsNotPermittedFact());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayFactsForRainyDayAccount() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .interestMonthly("No")
            .interestAnnually(YES)
            .build()
            .toBuilder()
            .accountNameShort("Online Rainy Day Account")
            .withdrawalsPermitted(YES)
            .withdrawalDays(2)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Interest will be paid annually").build(),
            buildWithdrawalsRainyDay());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayFactsForLoyaltySixAccessSaverEIsaAccount() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .interestMonthly("No")
            .interestAnnually(YES)
            .build()
            .toBuilder()
            .accountNameShort("Loyalty Six Access Saver ISA")
            .withdrawalsPermitted(YES)
            .withdrawalDays(6)
            .minOpeningBalance(1)
            .tieredProduct(YES)
            .loyalty(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiersThree();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder()
                .text(
                    "Membership eligibility criteria applies for this 1 year Cash ISA and Save from £1")
                .build(),
            Fact.builder().text("Three tiered interest rates and interest paid annually").build(),
            Fact.builder()
                .text(
                    "Withdrawals on 6 days/year & closure at any time - Use the ISA transfer process to keep tax-free status")
                .build());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldDisplayMonthlyInterestFact(final String noValue) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().interestAnnually(noValue).interestMonthly(YES).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Monthly interest").build(), buildWithdrawalsNotPermittedFact());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldDisplayBiannualInterestFact(final String noValue) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .interestAnnually(noValue)
            .interestMonthly(noValue)
            .interestBiannually(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Biannual interest").build(), buildWithdrawalsNotPermittedFact());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldDisplayAnnualInterestFact(final String noValue) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .interestAnnually(noValue)
            .interestMonthly(noValue)
            .interestBiannually(noValue)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text(ANNUAL_INTEREST).build(), buildWithdrawalsNotPermittedFact());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @NoValuesSource
  void
      shouldNotDisplayAllowWithdrawalsPerYearWithMultipleDaysFactWhenWithdrawalsPermittedPropertyIsFalse(
          final String withdrawalsPermitted) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .withdrawalsPermitted(withdrawalsPermitted)
            .withdrawalDays(1)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    assertThat(facts, is(buildDefaultFacts()));
  }

  @ParameterizedTest
  @CsvSource({
    "1,one,day",
    "2,two,days",
    "3,three,days",
    "4,four,days",
    "5,five,days",
    "6,six,days",
    "7,seven,days",
    "8,eight,days",
    "9,nine,days",
    "10,ten,days"
  })
  void shouldDisplayAllowWithdrawalsPerYearWithMultipleDaysFact(
      final int days, final String dayWord, final String dayText) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().withdrawalsPermitted(YES).withdrawalDays(days).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            Fact.builder()
                .text(String.format("Allows withdrawals on %s %s per year", dayWord, dayText))
                .build());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @CsvSource({"Six Access e-Saver ISA,''", "'',Six Access e-Saver"})
  void shouldDisplayAllowWithdrawalsPerYearWithMultipleDaysWithClosureFact(
      final String accountNameFull, final String accountNameShort) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameFull(accountNameFull)
            .accountNameShort(accountNameShort)
            .withdrawalsPermitted(YES)
            .withdrawalDays(6)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            Fact.builder().text("Allows withdrawals on six days per year plus closure").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayMaturityProductOfferFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .withdrawalsPermitted(YES)
            .bond(YES)
            .maturityProductOffer(YES)
            .lossOfInterest(90)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            Fact.builder()
                .text(
                    "Withdrawals and closure are permitted during the term, subject to 90 days loss of interest on the amount withdrawn.")
                .build());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @ValueSource(ints = {30, 90})
  void shouldDisplayDaysNoticeFact(final int days) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort(String.format("%s Day Notice", days))
            .withdrawalsPermitted(YES)
            .bond(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            Fact.builder().text(String.format("Withdrawals Require %s Days Notice", days)).build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayLimitedAccessSaverFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Limited Access Saver")
            .withdrawalsPermitted(YES)
            .bond(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            Fact.builder()
                .text(
                    "Unlimited withdrawals on one day per account year based on the anniversary of the account opening date. The account can be closed at any time.")
                .build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayLimitedAccessSaverIsaFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Limited Access Saver ISA")
            .withdrawalsPermitted(YES)
            .bond(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            Fact.builder()
                .text(
                    "Unlimited withdrawals, on any one day per account year based on the anniversary of the account opening date, subject to daily withdrawal limits.")
                .build());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @NullSource
  @ValueSource(ints = {-1, 0})
  void shouldDisplayUnlimitedWithdrawalsFactForBonds(final Integer withdrawalDays)
      throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .withdrawalsPermitted(YES)
            .bond(YES)
            .withdrawalDays(withdrawalDays)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(), Fact.builder().text("Unlimited withdrawals").build());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @ValueSource(strings = {"Internet Saver Plus", "Internet Saver ISA Plus"})
  void shouldDisplayUnlimitedWithdrawalsFactForInternetSaver(final String accountNameShort)
      throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .withdrawalsPermitted(YES)
            .bond("No")
            .accountNameShort(accountNameShort)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(), Fact.builder().text("Unlimited withdrawals").build());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldNotDisplayClosurePermittedFactWhenNotTaxFree(final String taxFree)
      throws ParseException {
    shouldNotDisplayClosurePermittedFactWhenNotTaxFree(taxFree, YES, 60);
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldNotDisplayClosurePermittedFactWhenNotFixedTerm(final String fixedTerm)
      throws ParseException {
    shouldNotDisplayClosurePermittedFactWhenNotTaxFree(YES, fixedTerm, 60);
  }

  @Test
  void shouldNotDisplayClosurePermittedFactWhenNoLossOfInterest() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().taxFree(YES).fixedTerm(YES).lossOfInterest(null).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    assertThat(facts, is(buildDefaultAndIsaTransferFacts()));
  }

  private void shouldNotDisplayClosurePermittedFactWhenNotTaxFree(
      final String taxFree, final String fixedTerm, final Integer lossOfInterest)
      throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .taxFree(taxFree)
            .fixedTerm(fixedTerm)
            .lossOfInterest(lossOfInterest)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    assertThat(facts, is(buildDefaultFacts()));
  }

  @Test
  void shouldDisplayClosurePermittedFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().taxFree(YES).fixedTerm(YES).lossOfInterest(60).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact(),
            Fact.builder().text("Closure permitted with 60 days' loss of interest").build(),
            buildIsaTransferPermittedFact());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayIsaTransferFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().taxFree(YES).fixedTerm(YES).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact(),
            Fact.builder().text("You can transfer your ISA from another provider").build());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldNotDisplayNoYbsFundsAllowedInAndOneYearTermFactWhenNoYBSFundsInAllowedPropertyIsFalse(
      final String noYBSFundsInAllowed) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Annual Access Account")
            .noYBSFundsInAllowed(noYBSFundsInAllowed)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact(),
            Fact.builder().text("1 year term").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayNoYbsFundsAllowedInAnnualAccessAccountFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Annual Access Account")
            .noYBSFundsInAllowed(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact(),
            Fact.builder()
                .text(
                    "You can't move money from existing Yorkshire Building Society Group accounts to open or add to this product")
                .build(),
            Fact.builder().text("1 year term").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayNoYbsFundsAllowedInFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().noYBSFundsInAllowed(YES).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact(),
            Fact.builder()
                .text("You can't fund the account from an existing YBS Group account")
                .build());

    assertThat(facts, is(expected));
  }

  @ParameterizedTest
  @ValueSource(strings = {"Annual Access Account", "Annual Access Account ISA"})
  void shouldDisplayOneYearTermFact(final String accountNameShort) throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().accountNameShort(accountNameShort).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact(),
            Fact.builder().text("1 year term").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldNotDisplayOneDayAccountFactWhenMaxAgeCustomerPropertyIsNull() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().accountNameShort("One Day Account").build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    assertThat(facts, is(buildDefaultFacts()));
  }

  @Test
  void shouldDisplayOneDayAccountFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().accountNameShort("One Day Account").maxAgeCustomer(21).build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact(),
            Fact.builder().text("Available to account holders under 21 years old").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayFreedomAccountFact() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder().accountNameShort("Freedom Account").build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            buildWithdrawalsNotPermittedFact(),
            Fact.builder().text("Open to 12 to 20 year olds").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayMakeMeASaverFacts() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Make Me A Saver")
            .monthlyLimit(150)
            .endDate("31/01/2023")
            .withdrawalsPermitted(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            buildAnnualInterestFact(),
            Fact.builder()
                .text(
                    "Unlimited instant withdrawals, subject to daily withdrawal limits, without loss of interest, plus closure.")
                .build(),
            Fact.builder().text("Save up to £150 per month until 31 January 2023").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayFamilySaverFacts() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Family eSavings Account")
            .smartTiered(YES)
            .interestMonthly(YES)
            .maxAccountsPerPerson(1)
            .minOpeningBalance(1)
            .withdrawalsPermitted(YES)
            .withdrawalDays(3)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiersThree();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Save from £1 in this three year product").build(),
            Fact.builder()
                .text("3 tiered variable interest rate and interest paid monthly")
                .build(),
            Fact.builder().text("Three withdrawal days per year and closure permitted").build(),
            Fact.builder().text("One account per customer").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayLoyaltySixEAccessFacts() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Loyalty Six Access eSaver")
            .withdrawalsPermitted(YES)
            .withdrawalDays(6)
            .minOpeningBalance(1)
            .maxBalance(500000)
            .loyalty(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiersThree();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder()
                .text("Loyalty eligibility criteria applies & only one account per person")
                .build(),
            Fact.builder().text("Open from £1 and save up to £500,000 for a year").build(),
            Fact.builder().text(ANNUAL_INTEREST).build(),
            Fact.builder().text("Six withdrawal days per year, plus closure").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayRainyDayIssue2Facts() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Online Rainy Day Account")
            .withdrawalsPermitted(YES)
            .withdrawalDays(2)
            .minOpeningBalance(1)
            .maxBalance(2000000)
            .smartTiered(YES)
            .interestAnnually(YES)
            .maxAccountsPerPerson(1)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiersTwo();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Save from £1").build(),
            Fact.builder()
                .text("2 tiered variable interest rate and interest paid annually")
                .build(),
            Fact.builder().text("Two withdrawal days per year and closure permitted").build(),
            Fact.builder().text("One account per customer").build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayEnergySavingsAwarenessEBondFacts() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Energy Saving Awareness Fixed Rate eBond until 31/01/2024")
            .equivalentProduct("YB131653B")
            .minOpeningBalance(1000)
            .maxOpeningBalance(2000000)
            .maxBalance(2000000)
            .interestAnnually(YES)
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Open from £1,000 and save up to £2 million").build(),
            Fact.builder().text(ANNUAL_INTEREST).build(),
            Fact.builder().text("Withdrawals and closure not permitted").build(),
            Fact.builder()
                .text(
                    "Receive free independent information in partnership with the Energy Saving Trust")
                .build());

    assertThat(facts, is(expected));
  }

  @Test
  void shouldDisplayChristmasRegularSaver() throws ParseException {
    final WebSiteProduct webSiteProduct =
        validWebSiteProductBuilder()
            .accountNameShort("Christmas 2023 Regular e-Saver")
            .equivalentProduct("YB571652B")
            .monthlyLimit(300)
            .regularSaverTerm("1")
            .minOpeningBalance(1)
            .maxBalance(3000)
            .interestType("Variable")
            .interestAnnually(YES)
            .applyOnline(YES)
            .maxAccountHolders(1)
            .maxAccountsPerPerson(1)
            .minAgeCustomer(16)
            .regularSaver(YES)
            .withdrawalsPermitted(YES)
            .withdrawalDays(1)
            .closurePermitted(YES)
            .prodType("Instant Access")
            .endDate("31/10/2023")
            .build();

    final List<InterestTier> interestTiers = buildInterestTiers();

    final List<Fact> facts = factMapper.map(webSiteProduct, interestTiers);

    final List<Fact> expected =
        Arrays.asList(
            Fact.builder().text("Open with and save from £1 to £300 a month").build(),
            Fact.builder().text("Interest paid on maturity which is 31 October 2023").build(),
            Fact.builder()
                .text(
                    "Limited access with one withdrawal day for the term of this product, plus closure if required")
                .build(),
            Fact.builder().text("Only one account per customer").build());

    assertThat(facts, is(expected));
  }

  private static Fact buildAnnualInterestFact() {
    return Fact.builder().text(ANNUAL_INTEREST).build();
  }

  private static Fact buildInterestPaidOnFactForLoyaltyProduct() {
    return Fact.builder().text("Interest paid on 31 January 2024").build();
  }

  private static Fact buildWithdrawalsLoyaltyBond() {
    return Fact.builder().text("Withdrawals and closure not permitted").build();
  }

  private static Fact buildAnnualInterestFactCashISA() {
    return Fact.builder().text("Cash ISA pays Annual interest").build();
  }

  private static Fact buildWithdrawalsNotPermittedFact() {
    return Fact.builder().text("Withdrawals not permitted").build();
  }

  private static Fact buildWithdrawalsRainyDay() {
    return Fact.builder()
        .text(
            "Allows withdrawals on two days per year based on the anniversary of the account opening date, plus closure at any time if required")
        .build();
  }

  private static Fact buildIsaTransferPermittedFact() {
    return Fact.builder().text("You can transfer your ISA from another provider").build();
  }

  private static List<Fact> buildDefaultFacts() {
    return Arrays.asList(buildAnnualInterestFact(), buildWithdrawalsNotPermittedFact());
  }

  private static List<Fact> buildDefaultAndIsaTransferFacts() {
    return Arrays.asList(
        buildAnnualInterestFact(),
        buildWithdrawalsNotPermittedFact(),
        buildIsaTransferPermittedFact());
  }

  private static List<InterestTier> buildInterestTiers() {
    return Collections.singletonList(
        InterestTier.builder()
            .description("TierDescription")
            .rate("0.4")
            .range("£1 - £999")
            .build());
  }

  private static List<InterestTier> buildInterestTiersThree() {
    return Arrays.asList(
        InterestTier.builder()
            .description("Tax-free p.a./AER variable on balances of")
            .rate("1.00")
            .range("£1,000 - £24,999")
            .build(),
        InterestTier.builder()
            .description("Tax-free p.a./AER variable on balances of")
            .rate("1.05")
            .range("£25,000 - £49,999")
            .build(),
        InterestTier.builder()
            .description("Tax-free p.a./AER variable on balances of")
            .rate("1.15")
            .range("£50,000+")
            .build());
  }

  private static List<InterestTier> buildInterestTiersTwo() {
    return Arrays.asList(
        InterestTier.builder()
            .description("Gross p.a./AER Variable on balances up to")
            .rate("2.50")
            .range("£5,000.00")
            .build(),
        InterestTier.builder()
            .description("Gross p.a./AER Variable on balances over")
            .rate("2.00")
            .range("£5,000.01")
            .build());
  }

  private static WebSiteProduct.WebSiteProductBuilder validWebSiteProductBuilder() {
    return WebSiteProduct.builder().accountNameFull("").accountNameShort("");
  }
}
