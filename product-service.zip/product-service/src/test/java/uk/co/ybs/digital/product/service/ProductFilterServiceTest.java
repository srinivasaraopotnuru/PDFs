package uk.co.ybs.digital.product.service;

import static java.util.Collections.singletonList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.exception.ProductServiceException;
import uk.co.ybs.digital.product.web.dto.AvailableProductDetails;
import uk.co.ybs.digital.product.web.dto.CustomerAccountDetails;
import uk.co.ybs.digital.product.web.dto.onsale.Fact;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;
import uk.co.ybs.digital.product.web.dto.onsale.Warning;
import uk.co.ybs.digital.product.web.dto.onsale.WarningCode;

@ExtendWith(MockitoExtension.class)
class ProductFilterServiceTest {

  private static final String PRODUCT_ID_1 = "YB851266W";
  private static final String PRODUCT_ID_2 = "YBS113131";
  private static final String PRODUCT_ID_ANNUAL = "YB851266WA";

  private static final String PRODUCT_ID_MONTHLY = "YB851266WM";
  // private static final String PRODUCT_CODE = "Product_code";

  private static final ZoneId ZONE_ID = ZoneId.of("Europe/London");
  private static final Instant NOW_INSTANT = Instant.parse("2020-05-18T13:15:21Z");
  private static final LocalDateTime NOW = LocalDateTime.ofInstant(NOW_INSTANT, ZONE_ID);
  private static final String SIX_ACCESS_E_SAVER_ISA_ISSUE_3_PRODUCT_NAME =
      "Six Access e-Saver ISA Issue 3";
  private static final String DATE_OF_BIRTH = "2011-11-30";

  private static final UUID REQUEST_ID = UUID.fromString("564e6e5c-7fac-4c68-b721-4e466645c7e3");

  @InjectMocks private ProductFilterService productFilterService;

  @Mock private OnSaleProductService onSaleProductService;

  @Test
  void testInvalidDate() {

    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder().dateOfBirth("2011-40-30").countryCode("UK").build();
    final Exception ex =
        assertThrows(
            ProductServiceException.class,
            () -> productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID));
    assertThat(
        ex.getMessage(),
        is(
            "Text '2011-40-30' could not be parsed: Invalid value for MonthOfYear (valid values 1 - 12): 40"));
  }

  @Test
  void shouldGetEmptyAvailableProducts() {

    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder().dateOfBirth(DATE_OF_BIRTH).countryCode("UK").build();
    final List<ProductCategory> details =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);
    assertThat(details.isEmpty(), is(true));
  }

  @Test
  void shouldAvailableProducts() {

    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder().dateOfBirth(DATE_OF_BIRTH).countryCode("UK").build();
    final List<ProductCategory> productCategory =
        buildOnSaleProducts(
            buildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.MONTHLY, null));

    when(onSaleProductService.getProducts(REQUEST_ID)).thenReturn(productCategory);
    final List<ProductCategory> details =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);

    assertThat(details.isEmpty(), is(false));
    assertThat(details.size(), is(1));
    assertThat(details.get(0).getDescription(), is("Straightforward and flexible")); // NOPMD
    assertThat(details.get(0).getProducts().isEmpty(), is(false));
    assertThat(details.get(0).getProducts().size(), is(1));
    assertThat(details.get(0).getUnavailableProducts().isEmpty(), is(true));
  }

  @Test
  void shouldSuppliedAvailableProducts() {

    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder().dateOfBirth(DATE_OF_BIRTH).countryCode("UK").build();
    final List<ProductCategory> productCategory =
        buildOnSaleProducts(
            buildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.MONTHLY, null));

    when(onSaleProductService.getProducts(REQUEST_ID)).thenReturn(productCategory);
    final List<ProductCategory> details =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);
    assertThat(details.isEmpty(), is(false));
    assertThat(details.size(), is(1));
    assertThat(details.get(0).getDescription(), is("Straightforward and flexible"));
    assertThat(details.get(0).getProducts().isEmpty(), is(false));
    assertThat(details.get(0).getProducts().size(), is(1));
    assertThat(details.get(0).getUnavailableProducts().isEmpty(), is(true));
  }

  @Test
  void shouldFRAvailableProducts() {

    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder().dateOfBirth(DATE_OF_BIRTH).countryCode("FR").build();
    final List<ProductCategory> productCategory =
        buildOnSaleProducts(
            buildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.MONTHLY, null));

    when(onSaleProductService.getProducts(REQUEST_ID)).thenReturn(productCategory);
    final List<ProductCategory> details =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);

    assertThat(details.isEmpty(), is(false));
    assertThat(details.size(), is(1));
    assertThat(details.get(0).getDescription(), is("Straightforward and flexible"));
    assertThat(details.get(0).getProducts().size(), is(0));
    assertThat(details.get(0).getUnavailableProducts().size(), is(1));
  }

  @ParameterizedTest
  @MethodSource("filterByAge")
  void filterProductBasedOnAge(
      final int age, final Integer minAge, final Integer maxAge, final boolean exists) {

    final LocalDateTime dob;
    dob = NOW.minusYears(age);

    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder()
            .dateOfBirth(dob.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
            .countryCode("UK")
            .build();

    final List<ProductCategory> onSaleProducts = buildOnSaleProducts(minAge, maxAge);

    when(onSaleProductService.getProducts(REQUEST_ID)).thenReturn(onSaleProducts);

    final List<ProductCategory> result =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);
    final List<ProductCategory> expected =
        exists
            ? onSaleProducts
            : buildFilteredProducts(
                minAge,
                maxAge,
                Warning.builder()
                    .code(WarningCode.APPLICANT_AGE)
                    .message("Product age Constraints not met")
                    .build());
    assertThat(result, is(expected));
  }

  @SuppressWarnings("unused") // NOPMD
  private static Stream<Arguments> filterByAge() {
    return Stream.of(
        Arguments.of(16, null, null, true),
        Arguments.of(16, 16, null, true),
        Arguments.of(16, 16, 99, true),
        Arguments.of(99, 16, 99, true),
        Arguments.of(15, 16, null, false),
        Arguments.of(100, null, 99, false),
        Arguments.of(15, 16, 99, false),
        Arguments.of(100, 16, 99, false));
  }

  public static List<CustomerAccountDetails> getMockApplicationResponsePrivateEmpty() {
    return Collections.emptyList();
  }

  public static List<CustomerAccountDetails> buildMockApplicationResponsePrivate(
      final int applicants, final String productId) {
    final CustomerAccountDetails customerAccountDetails =
        CustomerAccountDetails.builder().count(applicants).productIdentifier(productId).build();

    return singletonList(customerAccountDetails);
  }

  private static List<CustomerAccountDetails> buildOwnedAccountMock(
      final int count, final String productId) {
    final CustomerAccountDetails customerAccountDetails =
        CustomerAccountDetails.builder().count(count).productIdentifier(productId).build();
    return singletonList(customerAccountDetails);
  }

  @SuppressWarnings("unused") // NOPMD
  private static Stream<Arguments> matchesMaxNumberOfAccounts() {
    return Stream.of(
        Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID_1,
                InterestFrequency.MONTHLY,
                null), // no owned accounts and applications in progress matching so no
            // unavailable products
            buildOwnedAccountMock(1, "222222"),
            getMockApplicationResponsePrivateEmpty(),
            buildProductListResponse(
                cBuildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.MONTHLY, null),
                eList())),
        Arguments.of(
            buildOnSaleProductMock(
                4,
                PRODUCT_ID_1,
                InterestFrequency.ANNUAL,
                null), // within max number of accounts so product still available
            buildOwnedAccountMock(1, PRODUCT_ID_ANNUAL),
            buildMockApplicationResponsePrivate(1, PRODUCT_ID_ANNUAL),
            buildProductListResponse(
                cBuildOnSaleProductMock(4, PRODUCT_ID_1, InterestFrequency.ANNUAL, null), eList())),
        Arguments.of(
            buildOnSaleProductMock(
                1, PRODUCT_ID_1, InterestFrequency.ANNUAL, null), // 1 owned account matching
            buildOwnedAccountMock(1, PRODUCT_ID_ANNUAL),
            getMockApplicationResponsePrivateEmpty(),
            buildProductListResponse(
                eList(),
                cBuildOnSaleProductMock(
                    1,
                    PRODUCT_ID_1,
                    InterestFrequency.ANNUAL,
                    wList(
                        WarningCode.MAX_NO_OF_ACCOUNTS,
                        "Exceeded maximum number of Accounts. 1 open accounts, 0 applications in progress")))),
        (Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID_1,
                InterestFrequency.ANNUAL,
                null), // 1 application in progress matching
            buildOwnedAccountMock(1, "YB111111"),
            buildMockApplicationResponsePrivate(1, PRODUCT_ID_ANNUAL),
            buildProductListResponse(
                eList(),
                cBuildOnSaleProductMock(
                    1,
                    PRODUCT_ID_1,
                    InterestFrequency.ANNUAL,
                    wList(
                        WarningCode.MAX_NO_OF_ACCOUNTS,
                        "Exceeded maximum number of Accounts. 0 open accounts, 1 applications in progress"))))),
        Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID_2,
                InterestFrequency.ANNUAL,
                null), // 1 application in progress matching
            buildOwnedAccountMock(1, "YB111111"),
            buildMockApplicationResponsePrivate(1, PRODUCT_ID_2),
            buildProductListResponse(
                eList(),
                cBuildOnSaleProductMock(
                    1,
                    PRODUCT_ID_2,
                    InterestFrequency.ANNUAL,
                    wList(
                        WarningCode.MAX_NO_OF_ACCOUNTS,
                        "Exceeded maximum number of Accounts. 0 open accounts, 1 applications in progress")))),
        (Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID_1,
                InterestFrequency.MONTHLY,
                null), // no filtering because application status is not submitted or id
            // checked
            buildOwnedAccountMock(1, "YB111111"),
            buildMockApplicationResponsePrivate(0, PRODUCT_ID_MONTHLY),
            buildProductListResponse(
                cBuildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.MONTHLY, null),
                eList()))),
        (Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID_1,
                InterestFrequency.ANNUAL,
                null), // 1 owned account and 1 application in progress matching
            buildOwnedAccountMock(1, PRODUCT_ID_ANNUAL),
            buildMockApplicationResponsePrivate(1, PRODUCT_ID_ANNUAL),
            buildProductListResponse(
                eList(),
                cBuildUnavailableProductWithWarning(
                    1,
                    PRODUCT_ID_1,
                    makeWarning(
                        WarningCode.MAX_NO_OF_ACCOUNTS,
                        "Exceeded maximum number of Accounts. 1 open accounts, 1 applications in progress"))))),
        Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID_2,
                InterestFrequency.ANNUAL,
                null), // test with 1 owned account matching and product ID not ending in W
            buildOwnedAccountMock(1, PRODUCT_ID_2),
            getMockApplicationResponsePrivateEmpty(),
            buildProductListResponse(
                eList(),
                cBuildOnSaleProductMock(
                    1,
                    PRODUCT_ID_2,
                    InterestFrequency.ANNUAL,
                    wList(
                        WarningCode.MAX_NO_OF_ACCOUNTS,
                        "Exceeded maximum number of Accounts. 1 open accounts, 0 applications in progress")))),
        Arguments.of(
            buildOnSaleProductMock(
                5, PRODUCT_ID_1, InterestFrequency.ANNUAL, null), // 5 owned account matching
            buildOwnedAccountMock(5, PRODUCT_ID_ANNUAL),
            getMockApplicationResponsePrivateEmpty(),
            buildProductListResponse(
                eList(), // available products
                cBuildOnSaleProductMock(
                    5,
                    PRODUCT_ID_1,
                    InterestFrequency.ANNUAL,
                    wList(
                        WarningCode.MAX_NO_OF_ACCOUNTS,
                        "Exceeded maximum number of Accounts. 5 open accounts, 0 applications in progress"))) // unavailable products
            ),
        Arguments.of(
            buildOnSaleProductMock(
                5, PRODUCT_ID_1, InterestFrequency.ANNUAL, null), // 5 owned account matching
            buildOwnedAccountMock(2, PRODUCT_ID_ANNUAL),
            getMockApplicationResponsePrivateEmpty(),
            buildProductListResponse(
                cBuildOnSaleProductMock(5, PRODUCT_ID_1, InterestFrequency.ANNUAL, null), eList())),
        Arguments.of(
            buildOnSaleProductMock(5, PRODUCT_ID_1, InterestFrequency.ANNUAL, null),
            null,
            null,
            buildProductListResponse(
                cBuildOnSaleProductMock(5, PRODUCT_ID_1, InterestFrequency.ANNUAL, null),
                eList())));
  }
  // try to reduce the size of the above declaration
  private static <T> List<T> cList(final T object) {
    return singletonList(object);
  }

  private static <T> List<T> eList() {
    return Collections.emptyList();
  }

  private static Warning makeWarning(final WarningCode code, final String message) {
    return Warning.builder().code(code).message(message).build();
  }

  private static List<Warning> wList(final WarningCode code, final String message) {
    return cList(makeWarning(code, message));
  }

  @ParameterizedTest
  @MethodSource("matchesMaxNumberOfAccounts")
  void filterProductShouldRemoveProductWherePartyExceedsMaximum(
      final Product onSaleProducts,
      final List<CustomerAccountDetails> accounts,
      final List<CustomerAccountDetails> applicationsInProgress,
      final List<ProductCategory> expectedResponse) {

    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder()
            .dateOfBirth(DATE_OF_BIRTH)
            .countryCode("UK")
            .accounts(accounts)
            .applicationsInProgress(applicationsInProgress)
            .build();

    when(onSaleProductService.getProducts(REQUEST_ID))
        .thenReturn(buildOnSaleProducts(onSaleProducts));

    final List<ProductCategory> result =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);

    assertThat(result, is(expectedResponse));
  }

  @Test
  void testDuffProductsName() {

    final Product onSaleProduct =
        buildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.ANNUAL, null);

    final List<CustomerAccountDetails> accounts = new ArrayList<>();

    final CustomerAccountDetails duffAccount =
        CustomerAccountDetails.builder().productIdentifier("").count(1).build();

    accounts.add(duffAccount);
    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder()
            .dateOfBirth("2011-11-01")
            .countryCode("UK")
            .accounts(accounts)
            .build();

    final List<ProductCategory> expectedResponse = new ArrayList<>();
    final Warning warnings =
        Warning.builder()
            .code(WarningCode.INVALID_PARMETERS)
            .message("Invalid data count or name count 1 name ")
            .build();
    final List<Warning> warningList = singletonList(warnings);
    final Product warningSaleProduct =
        buildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.ANNUAL, warningList);
    expectedResponse.add(buildOnSaleProductElements(null, warningSaleProduct));
    when(onSaleProductService.getProducts(REQUEST_ID))
        .thenReturn(buildOnSaleProducts(onSaleProduct));

    final List<ProductCategory> result =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);
    assertThat(result, is(expectedResponse));
  }

  @Test
  void testDuffCountProductsName() {
    final Product onSaleProduct =
        buildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.ANNUAL, null);

    final List<CustomerAccountDetails> accounts = new ArrayList<>();

    final CustomerAccountDetails duffAccount =
        CustomerAccountDetails.builder().productIdentifier(PRODUCT_ID_ANNUAL).count(-1).build();

    accounts.add(duffAccount);
    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder()
            .dateOfBirth("2011-11-01")
            .countryCode("UK")
            .accounts(accounts)
            .build();

    final List<ProductCategory> expectedResponse = new ArrayList<>();
    final Warning warnings =
        Warning.builder()
            .code(WarningCode.INVALID_PARMETERS)
            .message("Invalid data count or name count -1 name YB851266WA")
            .build();
    final List<Warning> warningList = singletonList(warnings);
    final Product warningSaleProduct =
        buildOnSaleProductMock(1, PRODUCT_ID_1, InterestFrequency.ANNUAL, warningList);
    expectedResponse.add(buildOnSaleProductElements(null, warningSaleProduct));
    when(onSaleProductService.getProducts(REQUEST_ID))
        .thenReturn(buildOnSaleProducts(onSaleProduct));

    final List<ProductCategory> result =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);
    assertThat(result, is(expectedResponse));
  }

  @Test
  void testNullMaxAccountsProductsName() {

    //  Test that null maximumNumberOfAccounts does not break anything
    final Product onSaleProduct =
        buildOnSaleProductMock(null, PRODUCT_ID_1, InterestFrequency.ANNUAL, null);

    final List<CustomerAccountDetails> accounts = new ArrayList<>();

    final CustomerAccountDetails duffAccount =
        CustomerAccountDetails.builder().productIdentifier(PRODUCT_ID_ANNUAL).count(1).build();

    accounts.add(duffAccount);
    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder()
            .dateOfBirth("2011-11-01")
            .countryCode("UK")
            .accounts(accounts)
            .build();

    final List<ProductCategory> expectedResponse = new ArrayList<>();

    expectedResponse.add(buildOnSaleProductElements(onSaleProduct, null));
    when(onSaleProductService.getProducts(REQUEST_ID))
        .thenReturn(buildOnSaleProducts(onSaleProduct));

    final List<ProductCategory> result =
        productFilterService.filterProducts(availableProductDetails, NOW, REQUEST_ID);
    assertThat(result, is(expectedResponse));
  }

  public static List<ProductCategory> buildFilteredProducts(
      final Integer minAge, final Integer maxAge, final Warning warning) {

    final Product easyISA =
        buildProductDto(
            SIX_ACCESS_E_SAVER_ISA_ISSUE_3_PRODUCT_NAME,
            PRODUCT_ID_1,
            PRODUCT_ID_1,
            minAge,
            maxAge,
            null,
            Collections.emptyList(),
            Collections.emptyList(),
            ProductType.ISA,
            InterestFrequency.ANNUAL,
            singletonList(warning));

    return singletonList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(
                "http://localhost:%d/easy-access/index.html?display=allWaysToApply", 8080),
            false,
            Collections.emptyList(),
            singletonList(easyISA)));
  }

  public static List<ProductCategory> buildProductListResponse(
      final List<Product> availableProducts, final List<Product> unavailableProducts) {
    return singletonList(
        ProductCategory.builder()
            .title("Easy Access")
            .subTitle("Manage your money with greater freedom.")
            .description("Straightforward and flexible")
            .offlineOnlyProductsAvailable(false)
            .url("test.com")
            .products(availableProducts)
            .unavailableProducts(unavailableProducts)
            .build());
  }

  public static List<Product> cBuildUnavailableProductWithWarning(
      final Integer maximumNumberOfAccounts, final String productId, final Warning warning) {
    return cList(buildUnavailableProductWithWarning(maximumNumberOfAccounts, productId, warning));
  }

  public static Product buildUnavailableProductWithWarning(
      final Integer maximumNumberOfAccounts, final String productId, final Warning warning) {
    return buildProductDto(
        SIX_ACCESS_E_SAVER_ISA_ISSUE_3_PRODUCT_NAME,
        productId,
        productId,
        null,
        null,
        maximumNumberOfAccounts,
        Collections.emptyList(),
        Collections.emptyList(),
        ProductType.ISA,
        InterestFrequency.ANNUAL,
        singletonList(warning));
  }

  public static List<Product> cBuildOnSaleProductMock(
      final Integer maximumNumberOfAccounts,
      final String productId,
      final InterestFrequency interestFrequency,
      final List<Warning> warnings) {

    return cList(
        buildOnSaleProductMock(maximumNumberOfAccounts, productId, interestFrequency, warnings));
  }

  public static Product buildOnSaleProductMock(
      final Integer maximumNumberOfAccounts,
      final String productId,
      final InterestFrequency interestFrequency,
      final List<Warning> warnings) {
    return buildProductDto(
        SIX_ACCESS_E_SAVER_ISA_ISSUE_3_PRODUCT_NAME,
        productId,
        productId,
        null,
        null,
        maximumNumberOfAccounts,
        Collections.emptyList(),
        Collections.emptyList(),
        ProductType.ISA,
        interestFrequency,
        warnings);
  }

  public static ProductCategory buildOnSaleProductElements(
      final Product product, final Product unavailableProduct) {

    return buildProductCategory(
        ProductCategoryTypeHelper.EASY_ACCESS,
        "test.com",
        false,
        product == null ? Collections.emptyList() : singletonList(product),
        unavailableProduct == null ? Collections.emptyList() : singletonList(unavailableProduct));
  }

  public static List<ProductCategory> buildOnSaleProducts(final Product product) {

    return singletonList(buildOnSaleProductElements(product, null));
  }

  public static List<ProductCategory> buildOnSaleProducts(
      final Integer minAge, final Integer maxAge) {

    final Product easyISA =
        buildProductDto(
            SIX_ACCESS_E_SAVER_ISA_ISSUE_3_PRODUCT_NAME,
            PRODUCT_ID_1,
            PRODUCT_ID_1,
            minAge,
            maxAge,
            null,
            Collections.emptyList(),
            Collections.emptyList(),
            ProductType.ISA,
            InterestFrequency.ANNUAL,
            null);

    return singletonList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(
                "http://localhost:%d/easy-access/index.html?display=allWaysToApply", 8080),
            false,
            singletonList(easyISA),
            Collections.emptyList()));
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private static Product buildProductDto(
      final String productName,
      final String productCode,
      final String productId,
      final Integer minimumAge,
      final Integer maximumAge,
      final Integer maximumNumberOfAccounts,
      final List<InterestTier> tiers,
      final List<String> facts,
      final ProductType productType,
      final InterestFrequency interestFrequency,
      final List<Warning> warnings) {
    return Product.builder()
        .name(productName)
        .productCode(productCode)
        .type(productType)
        .url(String.format("http://localhost:%d/product.html?id=%s", 8080, productId))
        .interestTiers(tiers)
        .facts(buildFacts(facts))
        .minimumAge(minimumAge)
        .maximumAge(maximumAge)
        .maximumNumberOfAccounts(maximumNumberOfAccounts)
        .interestFrequency(interestFrequency)
        .warnings(warnings)
        .loyalty(false)
        .build();
  }

  private static List<Fact> buildFacts(final List<String> facts) {
    return facts.stream()
        .map(fact -> Fact.builder().text(fact).build())
        .collect(Collectors.toList());
  }

  private static ProductCategory buildProductCategory(
      final ProductCategoryTypeHelper type,
      final String url,
      final boolean offlineAvailable,
      final List<Product> products,
      final List<Product> unavailableProducts) {
    return ProductCategory.builder()
        .title(type.getTitle())
        .subTitle(type.getSubTitle())
        .description(type.getDescription())
        .url(url)
        .offlineOnlyProductsAvailable(offlineAvailable)
        .products(products)
        .unavailableProducts(unavailableProducts)
        .build();
  }
}
