package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class InterestTierDescriptionMapperTest {

  private static final String FAMILY_SAVINGS_ACCOUNT_NAME_SHORT = "Family eSavings Account";
  private static final String ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT = "Online Rainy Day Account";
  private static final String ACCOUNT_SHORT_NAME = "accountShortName";
  private static final String FIXED_INTEREST_TYPE = "fixed";
  private static final String VARIABLE_INTEREST_TYPE = "variable";

  private final InterestTierDescriptionMapper testSubject = new InterestTierDescriptionMapper();

  @ParameterizedTest
  @MethodSource("mappingValues")
  @SuppressWarnings("PMD.ExcessiveParameterList")
  void shouldMap(
      final boolean taxFree,
      final String interestType,
      final boolean tiered,
      final boolean smartTiered,
      final String nextBalance,
      final String accountShortName,
      final int index,
      final boolean consolidatedTiers,
      final String expected) {
    final String description =
        testSubject.map(
            taxFree,
            interestType,
            tiered,
            smartTiered,
            nextBalance,
            accountShortName,
            index,
            consolidatedTiers);
    assertThat(description, is(expected));
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  private static Stream<Arguments> mappingValues() {
    return Stream.of(
        Arguments.of(
            true,
            FIXED_INTEREST_TYPE,
            true,
            false,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Tax-free p.a./AER fixed on balances of"),
        Arguments.of(
            false,
            VARIABLE_INTEREST_TYPE,
            false,
            false,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Gross p.a./AER variable"),
        Arguments.of(
            false,
            FIXED_INTEREST_TYPE,
            true,
            false,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Gross p.a./AER fixed on balances of"),
        Arguments.of(
            true,
            VARIABLE_INTEREST_TYPE,
            true,
            false,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Tax-free p.a./AER variable on balances of"),
        Arguments.of(
            true,
            FIXED_INTEREST_TYPE,
            false,
            false,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Tax-free p.a./AER fixed"),
        Arguments.of(
            true,
            FIXED_INTEREST_TYPE,
            false,
            true,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Tax-free p.a./AER fixed on balances of"),
        Arguments.of(
            false,
            VARIABLE_INTEREST_TYPE,
            false,
            false,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Gross p.a./AER variable"),
        Arguments.of(
            false,
            FIXED_INTEREST_TYPE,
            false,
            true,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Gross p.a./AER fixed on balances of"),
        Arguments.of(
            true,
            VARIABLE_INTEREST_TYPE,
            false,
            true,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Tax-free p.a./AER variable on balances of"),
        Arguments.of(
            true,
            FIXED_INTEREST_TYPE,
            false,
            false,
            null,
            ACCOUNT_SHORT_NAME,
            0,
            false,
            "Tax-free p.a./AER fixed"),
        Arguments.of(
            false,
            FIXED_INTEREST_TYPE,
            false,
            true,
            "100",
            FAMILY_SAVINGS_ACCOUNT_NAME_SHORT,
            0,
            false,
            "Gross p.a./AER fixed on balances up to"),
        Arguments.of(
            false,
            FIXED_INTEREST_TYPE,
            false,
            true,
            "200",
            FAMILY_SAVINGS_ACCOUNT_NAME_SHORT,
            1,
            false,
            "Gross p.a./AER fixed on balances of"),
        Arguments.of(
            false,
            FIXED_INTEREST_TYPE,
            false,
            true,
            null,
            FAMILY_SAVINGS_ACCOUNT_NAME_SHORT,
            3,
            false,
            "Gross p.a./AER fixed on balances over"),
        Arguments.of(
            false,
            FIXED_INTEREST_TYPE,
            false,
            true,
            "100",
            ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT,
            0,
            false,
            "Gross p.a./AER fixed on balances up to"),
        Arguments.of(
            false,
            FIXED_INTEREST_TYPE,
            false,
            true,
            null,
            ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT,
            1,
            false,
            "Gross p.a./AER fixed on balances over"),
        Arguments.of(
            false,
            VARIABLE_INTEREST_TYPE,
            true,
            false,
            "125",
            ACCOUNT_SHORT_NAME,
            1,
            true,
            "Gross p.a./AER variable across all tiers"),
        Arguments.of(
            true,
            FIXED_INTEREST_TYPE,
            true,
            true,
            "150",
            ACCOUNT_SHORT_NAME,
            1,
            true,
            "Tax-free p.a./AER fixed across all tiers"));
  }
}
