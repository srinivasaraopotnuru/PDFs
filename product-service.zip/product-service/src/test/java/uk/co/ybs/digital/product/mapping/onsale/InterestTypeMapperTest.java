package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.exception.ProductNotSupportedException;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;

public class InterestTypeMapperTest {

  private static final String YES = "Yes";
  private static final String NO = "No";

  private InterestFrequencyMapper testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new InterestFrequencyMapper();
  }

  @ParameterizedTest
  @MethodSource("productData")
  public void testMapsInterestFrequencySuccessfully(
      final WebSiteProduct webSiteProduct, final InterestFrequency expected) {
    final InterestFrequency result = testSubject.map(webSiteProduct);
    assertEquals(expected, result);
  }

  @Test
  public void testUnknownInterestFrequencyThrowsException() {

    final ProductNotSupportedException exception =
        assertThrows(
            ProductNotSupportedException.class,
            () -> testSubject.map(buildProduct(null, null, null)));

    assertThat(
        exception.getMessage(), is("Unable to decode interest frequency for product YB851266W"));
  }

  private static Stream<Arguments> productData() {
    return Stream.of(
        Arguments.of(buildProduct(YES, null, null), InterestFrequency.ANNUAL),
        Arguments.of(
            buildProduct(YES, StringUtils.EMPTY, StringUtils.EMPTY), InterestFrequency.ANNUAL),
        Arguments.of(buildProduct(YES, NO, NO), InterestFrequency.ANNUAL),
        Arguments.of(buildProduct(null, YES, null), InterestFrequency.MONTHLY),
        Arguments.of(
            buildProduct(StringUtils.EMPTY, YES, StringUtils.EMPTY), InterestFrequency.MONTHLY),
        Arguments.of(buildProduct(NO, YES, NO), InterestFrequency.MONTHLY),
        Arguments.of(buildProduct(null, null, YES), InterestFrequency.BIANNUAL),
        Arguments.of(
            buildProduct(StringUtils.EMPTY, StringUtils.EMPTY, YES), InterestFrequency.BIANNUAL),
        Arguments.of(buildProduct(NO, NO, YES), InterestFrequency.BIANNUAL));
  }

  private static WebSiteProduct buildProduct(
      final String annually, final String monthly, final String biAnnually) {
    return WebSiteProduct.builder()
        .accountNameFull("Six Access e-Saver ISA Issue 3")
        .productCode("YB851266W")
        .cashISA(YES)
        .flexibleISA(YES)
        .easyAccess(YES)
        .regularSaver(NO)
        .childrens(NO)
        .bond(NO)
        .minAgeCustomer(16)
        .maxAgeCustomer(99)
        .interestAnnually(annually)
        .interestMonthly(monthly)
        .interestBiannually(biAnnually)
        .maxAccountsPerPerson(1)
        .build();
  }
}
