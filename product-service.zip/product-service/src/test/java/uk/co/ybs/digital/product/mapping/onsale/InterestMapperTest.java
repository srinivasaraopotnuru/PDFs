package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;

@ExtendWith(MockitoExtension.class)
public class InterestMapperTest {

  private static final String DESCRIPTION = "description";
  private static final String T1_MIN_BAL = "1";
  private static final String T1_RATE = "0.6";
  private static final String RATE_TWO_PERCENT = "2.00%";
  private static final String RATE_THREE_PERCENT = "3.00%";
  private static final String T1_RATE_FULL = "0.60";
  private static final String ACCOUNT_SHORT_NAME = "accountShortName";
  private static final String FAMILY_SAVINGS_ACCOUNT_SHORT_NAME = "Family eSavings Account";

  private static final String T1_RANGE_NO_TIER = "£1+";
  private static final String FIXED_INTEREST_TYPE = "fixed";
  private static final String VARIABLE_INTEREST_TYPE = "variable";
  private static final String YES = "Yes";

  @Mock private InterestTierDescriptionMapper descriptionMapper;
  @Mock private InterestRangeMapper rangeMapper;

  @InjectMocks private InterestMapper testSubject;

  @Test
  @Ignore
  void shouldReturnEmptyListWhenNonAnnualInterest() {
    final WebSiteProduct webSiteProduct =
        buildWebSiteProduct(FIXED_INTEREST_TYPE).toBuilder().interestAnnually("").build();
    final List<InterestTier> interestTiers = testSubject.map(webSiteProduct);

    assertThat(interestTiers, is(Collections.emptyList()));
    verifyNoInteractions(descriptionMapper);
    verifyNoMoreInteractions(rangeMapper);
  }

  @Test
  void shouldReturnSingleInterestTierWhenNotATieredProduct() {
    final WebSiteProduct webSiteProduct =
        buildWebSiteProduct(VARIABLE_INTEREST_TYPE).toBuilder().tieredProduct("").build();

    when(descriptionMapper.map(
            true, VARIABLE_INTEREST_TYPE, false, false, null, ACCOUNT_SHORT_NAME, 0, false))
        .thenReturn(DESCRIPTION);

    when(rangeMapper.map(false, false, T1_MIN_BAL, null, ACCOUNT_SHORT_NAME, 0))
        .thenReturn(T1_RANGE_NO_TIER);

    final List<InterestTier> expected =
        Collections.singletonList(
            InterestTier.builder()
                .rate(T1_RATE_FULL + "%")
                .description(DESCRIPTION)
                .range(T1_RANGE_NO_TIER)
                .build());
    final List<InterestTier> interestTiers = testSubject.map(webSiteProduct);

    assertThat(interestTiers, is(expected));
    verifyNoMoreInteractions(descriptionMapper);
    verifyNoMoreInteractions(rangeMapper);
  }

  @Test
  void shouldReturnTiers() {
    final String t1Range = "£1 - £19";
    final String t2MinimumBalance = "20";
    final String t2Rate = "0.62";
    final String t2Range = "£20 - £29";
    final String t3MinimumBalance = "30";
    final String t3Rate = "0.64";
    final String t3Range = "£30 - £39";
    final String t4MinimumBalance = "40";
    final String t4Rate = "0.68";
    final String t4Range = "£40 - £49";
    final String t5MinimumBalance = "50";
    final String t5Rate = "0.71";
    final String t5Range = "£50-£99";
    final String t6MinimumBalance = "100";
    final String t6Rate = "0.77";
    final String t6Range = "£100-£199";
    final String t7MinimumBalance = "200";
    final String t7Rate = "0.79";
    final String t7Range = "£200-£299";
    final String t8MinimumBalance = "300";
    final String t8Rate = "0.83";
    final String t8Range = "£300-£399";
    final String t9MinimumBalance = "400";
    final String t9Rate = "0.89";
    final String t9Range = "£400-£500.49";
    final String t10MinimumBalance = "500.50";
    final String t10Rate = "0.99";
    final String t10Range = "£500+.50+";

    final WebSiteProduct webSiteProduct =
        buildWebSiteProduct(VARIABLE_INTEREST_TYPE)
            .toBuilder()
            .minBalanceT2(t2MinimumBalance)
            .annualGrossT2(t2Rate)
            .minBalanceT3(t3MinimumBalance)
            .annualGrossT3(t3Rate)
            .minBalanceT4(t4MinimumBalance)
            .annualGrossT4(t4Rate)
            .minBalanceT5(t5MinimumBalance)
            .annualGrossT5(t5Rate)
            .minBalanceT6(t6MinimumBalance)
            .annualGrossT6(t6Rate)
            .minBalanceT7(t7MinimumBalance)
            .annualGrossT7(t7Rate)
            .minBalanceT8(t8MinimumBalance)
            .annualGrossT8(t8Rate)
            .minBalanceT9(t9MinimumBalance)
            .annualGrossT9(t9Rate)
            .minBalanceT10(t10MinimumBalance)
            .annualGrossT10(t10Rate)
            .build();

    when(descriptionMapper.map(
            eq(true),
            eq(VARIABLE_INTEREST_TYPE),
            eq(true),
            eq(false),
            any(),
            eq(ACCOUNT_SHORT_NAME),
            anyInt(),
            eq(false)))
        .thenReturn(DESCRIPTION);

    when(rangeMapper.map(true, false, T1_MIN_BAL, t2MinimumBalance, ACCOUNT_SHORT_NAME, 0))
        .thenReturn(t1Range);
    when(rangeMapper.map(true, false, t2MinimumBalance, t3MinimumBalance, ACCOUNT_SHORT_NAME, 1))
        .thenReturn(t2Range);
    when(rangeMapper.map(true, false, t3MinimumBalance, t4MinimumBalance, ACCOUNT_SHORT_NAME, 2))
        .thenReturn(t3Range);
    when(rangeMapper.map(true, false, t4MinimumBalance, t5MinimumBalance, ACCOUNT_SHORT_NAME, 3))
        .thenReturn(t4Range);
    when(rangeMapper.map(true, false, t5MinimumBalance, t6MinimumBalance, ACCOUNT_SHORT_NAME, 4))
        .thenReturn(t5Range);
    when(rangeMapper.map(true, false, t6MinimumBalance, t7MinimumBalance, ACCOUNT_SHORT_NAME, 5))
        .thenReturn(t6Range);
    when(rangeMapper.map(true, false, t7MinimumBalance, t8MinimumBalance, ACCOUNT_SHORT_NAME, 6))
        .thenReturn(t7Range);
    when(rangeMapper.map(true, false, t8MinimumBalance, t9MinimumBalance, ACCOUNT_SHORT_NAME, 7))
        .thenReturn(t8Range);
    when(rangeMapper.map(true, false, t9MinimumBalance, t10MinimumBalance, ACCOUNT_SHORT_NAME, 8))
        .thenReturn(t9Range);
    when(rangeMapper.map(true, false, t10MinimumBalance, null, ACCOUNT_SHORT_NAME, 9))
        .thenReturn(t10Range);

    final List<InterestTier> expected =
        Arrays.asList(
            InterestTier.builder()
                .rate(T1_RATE_FULL + "%")
                .description(DESCRIPTION)
                .range(t1Range)
                .build(),
            InterestTier.builder()
                .rate(t2Rate + "%")
                .description(DESCRIPTION)
                .range(t2Range)
                .build(),
            InterestTier.builder()
                .rate(t3Rate + "%")
                .description(DESCRIPTION)
                .range(t3Range)
                .build(),
            InterestTier.builder()
                .rate(t4Rate + "%")
                .description(DESCRIPTION)
                .range(t4Range)
                .build(),
            InterestTier.builder()
                .rate(t5Rate + "%")
                .description(DESCRIPTION)
                .range(t5Range)
                .build(),
            InterestTier.builder()
                .rate(t6Rate + "%")
                .description(DESCRIPTION)
                .range(t6Range)
                .build(),
            InterestTier.builder()
                .rate(t7Rate + "%")
                .description(DESCRIPTION)
                .range(t7Range)
                .build(),
            InterestTier.builder()
                .rate(t8Rate + "%")
                .description(DESCRIPTION)
                .range(t8Range)
                .build(),
            InterestTier.builder()
                .rate(t9Rate + "%")
                .description(DESCRIPTION)
                .range(t9Range)
                .build(),
            InterestTier.builder()
                .rate(t10Rate + "%")
                .description(DESCRIPTION)
                .range(t10Range)
                .build());

    final List<InterestTier> interestTiers = testSubject.map(webSiteProduct);

    assertThat(interestTiers, is(expected));
  }

  @ParameterizedTest
  @ValueSource(strings = {FAMILY_SAVINGS_ACCOUNT_SHORT_NAME, ACCOUNT_SHORT_NAME})
  @SuppressWarnings("PMD.ExcessiveMethodLength")
  void shouldReturnTiersForSmartTieredProduct(final String accountShortName) {
    final String t1Range = "£1 - £19";
    final String t2MinimumBalance = "20";
    final String t2Rate = "0.62";
    final String t2Range = "£20 - £29";
    final String t3MinimumBalance = "30";
    final String t3Rate = "0.64";
    final String t3Range = "£30 - £39";
    final String t4MinimumBalance = "40";
    final String t4Rate = "0.68";
    final String t4Range = "£40 - £49";
    final String t5MinimumBalance = "50";
    final String t5Rate = "0.71";
    final String t5Range = "£50-£99";
    final String t6MinimumBalance = "100";
    final String t6Rate = "0.77";
    final String t6Range = "£100-£199";
    final String t7MinimumBalance = "200";
    final String t7Rate = "0.79";
    final String t7Range = "£200-£299";
    final String t8MinimumBalance = "300";
    final String t8Rate = "0.83";
    final String t8Range = "£300-£399";
    final String t9MinimumBalance = "400";
    final String t9Rate = "0.89";
    final String t9Range = "£400-£500.49";
    final String t10MinimumBalance = "500.50";
    final String t10Rate = "0.99";
    final String t10Range = "£500+.50+";

    final WebSiteProduct webSiteProduct;

    if (FAMILY_SAVINGS_ACCOUNT_SHORT_NAME.equals(accountShortName)) {
      webSiteProduct =
          buildWebSiteProductSmartTiered(VARIABLE_INTEREST_TYPE)
              .toBuilder()
              .accountNameShort(FAMILY_SAVINGS_ACCOUNT_SHORT_NAME)
              .interestMonthly(YES)
              .interestAnnually(null)
              .monthlyGrossT1(T1_RATE)
              .minBalanceT2(t2MinimumBalance)
              .monthlyGrossT2(t2Rate)
              .minBalanceT3(t3MinimumBalance)
              .monthlyGrossT3(t3Rate)
              .minBalanceT4(t4MinimumBalance)
              .monthlyGrossT4(t4Rate)
              .minBalanceT5(t5MinimumBalance)
              .monthlyGrossT5(t5Rate)
              .minBalanceT6(t6MinimumBalance)
              .monthlyGrossT6(t6Rate)
              .minBalanceT7(t7MinimumBalance)
              .monthlyGrossT7(t7Rate)
              .minBalanceT8(t8MinimumBalance)
              .monthlyGrossT8(t8Rate)
              .minBalanceT9(t9MinimumBalance)
              .monthlyGrossT9(t9Rate)
              .minBalanceT10(t10MinimumBalance)
              .monthlyGrossT10(t10Rate)
              .build();
    } else {
      webSiteProduct =
          buildWebSiteProductSmartTiered(VARIABLE_INTEREST_TYPE)
              .toBuilder()
              .annualGrossT1(T1_RATE)
              .minBalanceT2(t2MinimumBalance)
              .annualGrossT2(t2Rate)
              .minBalanceT3(t3MinimumBalance)
              .annualGrossT3(t3Rate)
              .minBalanceT4(t4MinimumBalance)
              .annualGrossT4(t4Rate)
              .minBalanceT5(t5MinimumBalance)
              .annualGrossT5(t5Rate)
              .minBalanceT6(t6MinimumBalance)
              .annualGrossT6(t6Rate)
              .minBalanceT7(t7MinimumBalance)
              .annualGrossT7(t7Rate)
              .minBalanceT8(t8MinimumBalance)
              .annualGrossT8(t8Rate)
              .minBalanceT9(t9MinimumBalance)
              .annualGrossT9(t9Rate)
              .minBalanceT10(t10MinimumBalance)
              .annualGrossT10(t10Rate)
              .build();
    }

    when(descriptionMapper.map(
            eq(true),
            eq(VARIABLE_INTEREST_TYPE),
            eq(false),
            eq(true),
            any(),
            eq(accountShortName),
            anyInt(),
            eq(false)))
        .thenReturn(DESCRIPTION);

    when(rangeMapper.map(false, true, T1_MIN_BAL, t2MinimumBalance, accountShortName, 0))
        .thenReturn(t1Range);
    when(rangeMapper.map(false, true, t2MinimumBalance, t3MinimumBalance, accountShortName, 1))
        .thenReturn(t2Range);
    when(rangeMapper.map(false, true, t3MinimumBalance, t4MinimumBalance, accountShortName, 2))
        .thenReturn(t3Range);
    when(rangeMapper.map(false, true, t4MinimumBalance, t5MinimumBalance, accountShortName, 3))
        .thenReturn(t4Range);
    when(rangeMapper.map(false, true, t5MinimumBalance, t6MinimumBalance, accountShortName, 4))
        .thenReturn(t5Range);
    when(rangeMapper.map(false, true, t6MinimumBalance, t7MinimumBalance, accountShortName, 5))
        .thenReturn(t6Range);
    when(rangeMapper.map(false, true, t7MinimumBalance, t8MinimumBalance, accountShortName, 6))
        .thenReturn(t7Range);
    when(rangeMapper.map(false, true, t8MinimumBalance, t9MinimumBalance, accountShortName, 7))
        .thenReturn(t8Range);
    when(rangeMapper.map(false, true, t9MinimumBalance, t10MinimumBalance, accountShortName, 8))
        .thenReturn(t9Range);
    when(rangeMapper.map(false, true, t10MinimumBalance, null, accountShortName, 9))
        .thenReturn(t10Range);

    final List<InterestTier> expected =
        Arrays.asList(
            InterestTier.builder()
                .rate(T1_RATE_FULL + "%")
                .description(DESCRIPTION)
                .range(t1Range)
                .build(),
            InterestTier.builder()
                .rate(t2Rate + "%")
                .description(DESCRIPTION)
                .range(t2Range)
                .build(),
            InterestTier.builder()
                .rate(t3Rate + "%")
                .description(DESCRIPTION)
                .range(t3Range)
                .build(),
            InterestTier.builder()
                .rate(t4Rate + "%")
                .description(DESCRIPTION)
                .range(t4Range)
                .build(),
            InterestTier.builder()
                .rate(t5Rate + "%")
                .description(DESCRIPTION)
                .range(t5Range)
                .build(),
            InterestTier.builder()
                .rate(t6Rate + "%")
                .description(DESCRIPTION)
                .range(t6Range)
                .build(),
            InterestTier.builder()
                .rate(t7Rate + "%")
                .description(DESCRIPTION)
                .range(t7Range)
                .build(),
            InterestTier.builder()
                .rate(t8Rate + "%")
                .description(DESCRIPTION)
                .range(t8Range)
                .build(),
            InterestTier.builder()
                .rate(t9Rate + "%")
                .description(DESCRIPTION)
                .range(t9Range)
                .build(),
            InterestTier.builder()
                .rate(t10Rate + "%")
                .description(DESCRIPTION)
                .range(t10Range)
                .build());

    final List<InterestTier> interestTiers = testSubject.map(webSiteProduct);

    assertThat(interestTiers, is(expected));
  }

  @ParameterizedTest
  @MethodSource("testConsolidationTiers")
  void shouldReturnSingleTierForConsolidatedTiers(
      final List<InterestTier> tiers,
      final List<InterestTier> expected,
      final boolean expectCallToDescriptionMapper) {

    final WebSiteProduct webSiteProduct =
        WebSiteProduct.builder()
            .accountNameFull("Test Account")
            .accountNameShort("Test Account")
            .taxFree("Yes")
            .interestType(VARIABLE_INTEREST_TYPE)
            .tieredProduct("Yes")
            .build();

    if (expectCallToDescriptionMapper) {
      when(descriptionMapper.map(
              eq(true),
              eq(VARIABLE_INTEREST_TYPE),
              eq(true),
              eq(false),
              eq(null),
              eq("Test Account"),
              eq(0),
              eq(true)))
          .thenReturn("zxc");
    }

    List<InterestTier> result = testSubject.consolidate(webSiteProduct, tiers);

    assertThat(result, is(expected));

    verifyNoMoreInteractions(descriptionMapper);
  }

  private static Stream<Arguments> testConsolidationTiers() {

    final List<InterestTier> tierThatWillBeConsolidated =
        Arrays.asList(
            InterestTier.builder()
                .rate(RATE_TWO_PERCENT)
                .description(DESCRIPTION)
                .range("£1.00 - £9,999.99")
                .build(),
            InterestTier.builder()
                .rate(RATE_TWO_PERCENT)
                .description(DESCRIPTION)
                .range("£10,000.00 - £49,999.99")
                .build(),
            InterestTier.builder()
                .rate(RATE_TWO_PERCENT)
                .description(DESCRIPTION)
                .range("£50,000.00+")
                .build());

    final List<InterestTier> singleTier =
        Arrays.asList(
            InterestTier.builder()
                .rate(RATE_TWO_PERCENT)
                .description(DESCRIPTION)
                .range("£1.00 - £9,999.99")
                .build());

    final List<InterestTier> multiRateTiers =
        Arrays.asList(
            InterestTier.builder()
                .rate(RATE_TWO_PERCENT)
                .description(DESCRIPTION)
                .range("£1.00 - £9,999.99")
                .build(),
            InterestTier.builder()
                .rate(RATE_THREE_PERCENT)
                .description(DESCRIPTION)
                .range("£10,000.00 - £49,999.99")
                .build(),
            InterestTier.builder()
                .rate(RATE_TWO_PERCENT)
                .description(DESCRIPTION)
                .range("£50,000.00+")
                .build());

    final List<InterestTier> consolidateTiers =
        Arrays.asList(
            InterestTier.builder().rate(RATE_TWO_PERCENT).description("zxc").range(null).build());

    return Stream.of(
        Arguments.of(tierThatWillBeConsolidated, consolidateTiers, true),
        Arguments.of(singleTier, singleTier, false),
        Arguments.of(multiRateTiers, multiRateTiers, false));
  }

  @Test
  void shouldReturnTiersWhenFewerTiersThanMaxAllowed() {
    final String t1Range = "£1 - £9";
    final String t2MinimumBalance = "10";
    final String t2Rate = "0.62";
    final String t2Range = "£10+";

    final WebSiteProduct webSiteProduct =
        buildWebSiteProduct(FIXED_INTEREST_TYPE)
            .toBuilder()
            .minBalanceT2(t2MinimumBalance)
            .annualGrossT2(t2Rate)
            .build();

    when(descriptionMapper.map(
            true, FIXED_INTEREST_TYPE, true, false, t2MinimumBalance, ACCOUNT_SHORT_NAME, 0, false))
        .thenReturn(DESCRIPTION);
    when(descriptionMapper.map(
            true, FIXED_INTEREST_TYPE, true, false, null, ACCOUNT_SHORT_NAME, 1, false))
        .thenReturn(DESCRIPTION);

    when(rangeMapper.map(true, false, T1_MIN_BAL, t2MinimumBalance, ACCOUNT_SHORT_NAME, 0))
        .thenReturn(t1Range);
    when(rangeMapper.map(true, false, t2MinimumBalance, null, ACCOUNT_SHORT_NAME, 1))
        .thenReturn(t2Range);

    final List<InterestTier> expected =
        Arrays.asList(
            InterestTier.builder()
                .rate(T1_RATE_FULL + "%")
                .description(DESCRIPTION)
                .range(t1Range)
                .build(),
            InterestTier.builder()
                .rate(t2Rate + "%")
                .description(DESCRIPTION)
                .range(t2Range)
                .build());
    final List<InterestTier> interestTiers = testSubject.map(webSiteProduct);

    assertThat(interestTiers, is(expected));
    verifyNoMoreInteractions(descriptionMapper);
  }

  private static WebSiteProduct buildWebSiteProduct(final String interestType) {
    return WebSiteProduct.builder()
        .accountNameShort(ACCOUNT_SHORT_NAME)
        .interestAnnually(YES)
        .minBalanceT1(T1_MIN_BAL)
        .annualGrossT1(T1_RATE)
        .taxFree(YES)
        .fixedTerm(YES)
        .interestType(interestType)
        .tieredProduct(YES)
        .build();
  }

  private static WebSiteProduct buildWebSiteProductSmartTiered(final String interestType) {
    return WebSiteProduct.builder()
        .accountNameShort(ACCOUNT_SHORT_NAME)
        .interestAnnually(YES)
        .minBalanceT1(T1_MIN_BAL)
        .taxFree(YES)
        .fixedTerm(YES)
        .interestType(interestType)
        .smartTiered(YES)
        .build();
  }
}
