package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.config.onsale.OnSaleProductProperties;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.NoValuesSource;
import uk.co.ybs.digital.product.web.dto.onsale.Fact;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;

@ExtendWith(MockitoExtension.class)
public class ProductMapperTest {

  private static final String BASE_URI = "http://test.com";
  private static final String FACT_TEXT = "Text is required for a fact";

  @Mock private InterestMapper interestMapper;
  @Mock private OnSaleProductProperties onSaleProductProperties;
  @Mock private FactMapper factMapper;
  @Mock private ProductFilter productFilter;
  @Mock private TypeMapper typeMapper;
  @Mock private InterestFrequencyMapper interestFrequencyMapper;

  @InjectMocks private ProductMapper testSubject;

  @Test
  void shouldNotMap() throws ParseException {
    final WebSiteProduct webSiteProduct = buildWebSiteProduct();

    when(productFilter.includeProduct(webSiteProduct)).thenReturn(false);

    final Optional<Product> actual = testSubject.map(webSiteProduct);

    assertThat(actual.isPresent(), is(false));

    verifyNoInteractions(interestMapper);
    verifyNoInteractions(interestFrequencyMapper);
    verifyNoInteractions(factMapper);
  }

  @ParameterizedTest
  @NoValuesSource
  void shouldMap(final String fixedTerm) throws ParseException {
    final WebSiteProduct webSiteProduct =
        buildWebSiteProduct().toBuilder().fixedTerm(fixedTerm).build();
    final List<InterestTier> interestTiers = buildInterestTiers();
    final Fact fact = Fact.builder().text(FACT_TEXT).build();

    when(productFilter.includeProduct(webSiteProduct)).thenReturn(true);

    when(interestMapper.map(webSiteProduct)).thenReturn(interestTiers);

    when(factMapper.map(webSiteProduct, interestTiers)).thenReturn(Collections.singletonList(fact));

    when(typeMapper.map(webSiteProduct)).thenReturn(ProductType.ISA);

    when(interestFrequencyMapper.map(webSiteProduct)).thenReturn(InterestFrequency.ANNUAL);

    when(onSaleProductProperties.getBaseUri()).thenReturn(BASE_URI);

    when(interestMapper.consolidate(webSiteProduct, interestTiers)).thenReturn(interestTiers);

    final Optional<Product> expected =
        Optional.of(
            buildProduct(
                interestTiers,
                webSiteProduct.getAccountNameFull(),
                webSiteProduct.getProductCode(),
                webSiteProduct.getProductCode(),
                webSiteProduct.getMinAgeCustomer(),
                webSiteProduct.getMaxAgeCustomer(),
                webSiteProduct.getMaxAccountsPerPerson(),
                Boolean.parseBoolean(webSiteProduct.getLoyalty()),
                InterestFrequency.ANNUAL,
                ProductType.ISA,
                Collections.singletonList(fact)));

    final Optional<Product> actual = testSubject.map(webSiteProduct);

    assertThat(actual.isPresent(), is(true));
    assertThat(expected, is(actual));
  }

  @Test
  void shouldMapFixedTerm() throws ParseException {
    final WebSiteProduct webSiteProduct =
        buildWebSiteProduct()
            .toBuilder()
            .accountNameShort("Six Access e-Saver")
            .fixedTerm("Yes")
            .build();
    final List<InterestTier> interestTiers = buildInterestTiers();
    final List<Fact> facts = Collections.singletonList(Fact.builder().text(FACT_TEXT).build());

    when(productFilter.includeProduct(webSiteProduct)).thenReturn(true);

    when(interestMapper.map(webSiteProduct)).thenReturn(interestTiers);

    when(factMapper.map(webSiteProduct, interestTiers)).thenReturn(facts);

    when(typeMapper.map(webSiteProduct)).thenReturn(ProductType.BOND);

    when(interestFrequencyMapper.map(webSiteProduct)).thenReturn(InterestFrequency.ANNUAL);

    when(onSaleProductProperties.getBaseUri()).thenReturn(BASE_URI);

    when(interestMapper.consolidate(webSiteProduct, interestTiers)).thenReturn(interestTiers);

    final Optional<Product> expected =
        Optional.of(
            buildProduct(
                interestTiers,
                webSiteProduct.getAccountNameShort(),
                webSiteProduct.getProductCode(),
                webSiteProduct.getProductCode(),
                webSiteProduct.getMinAgeCustomer(),
                webSiteProduct.getMaxAgeCustomer(),
                webSiteProduct.getMaxAccountsPerPerson(),
                Boolean.parseBoolean(webSiteProduct.getLoyalty()),
                InterestFrequency.ANNUAL,
                ProductType.BOND,
                facts));

    final Optional<Product> actual = testSubject.map(webSiteProduct);

    assertThat(actual.isPresent(), is(true));
    assertThat(expected, is(actual));
  }

  @Test
  void shouldMapProductNameFullEnergySavingAwareness() throws ParseException {
    final WebSiteProduct webSiteProduct =
        buildWebSiteProduct()
            .toBuilder()
            .accountNameShort("Energy Saving Awareness Fixed Rate eBond until 31/01/2024")
            .accountNameFull(
                "Energy Saving Awareness Fixed Rate eBond (No Access) until 31 January 2024")
            .build();
    final List<InterestTier> interestTiers = buildInterestTiers();
    final List<Fact> facts = Collections.singletonList(Fact.builder().text(FACT_TEXT).build());

    when(productFilter.includeProduct(webSiteProduct)).thenReturn(true);

    when(interestMapper.map(webSiteProduct)).thenReturn(interestTiers);

    when(factMapper.map(webSiteProduct, interestTiers)).thenReturn(facts);

    when(typeMapper.map(webSiteProduct)).thenReturn(ProductType.ISA);

    when(interestFrequencyMapper.map(webSiteProduct)).thenReturn(InterestFrequency.ANNUAL);

    when(onSaleProductProperties.getBaseUri()).thenReturn(BASE_URI);

    when(interestMapper.consolidate(webSiteProduct, interestTiers)).thenReturn(interestTiers);

    final Optional<Product> expected =
        Optional.of(
            buildProduct(
                interestTiers,
                webSiteProduct.getAccountNameFull(),
                webSiteProduct.getProductCode(),
                webSiteProduct.getProductCode(),
                webSiteProduct.getMinAgeCustomer(),
                webSiteProduct.getMaxAgeCustomer(),
                webSiteProduct.getMaxAccountsPerPerson(),
                Boolean.parseBoolean(webSiteProduct.getLoyalty()),
                InterestFrequency.ANNUAL,
                ProductType.ISA,
                facts));

    final Optional<Product> actual = testSubject.map(webSiteProduct);

    assertThat(actual.isPresent(), is(true));
    assertThat(expected, is(actual));
  }

  @ParameterizedTest
  @CsvSource({"YB851265A,YB851265", "YB851267M,YB851267", "YB851267Z,YB851267Z"})
  void shouldMapTruncatedProductIds(final String productId, final String expectedProductId)
      throws ParseException {
    final WebSiteProduct webSiteProduct =
        buildWebSiteProduct().toBuilder().productCode(productId).build();
    final List<InterestTier> interestTiers = buildInterestTiers();
    final List<Fact> facts = Collections.singletonList(Fact.builder().text(FACT_TEXT).build());

    when(productFilter.includeProduct(webSiteProduct)).thenReturn(true);

    when(interestMapper.map(webSiteProduct)).thenReturn(interestTiers);

    when(factMapper.map(webSiteProduct, interestTiers)).thenReturn(facts);

    when(typeMapper.map(webSiteProduct)).thenReturn(ProductType.CHILDRENS);

    when(interestFrequencyMapper.map(webSiteProduct)).thenReturn(InterestFrequency.ANNUAL);

    when(onSaleProductProperties.getBaseUri()).thenReturn(BASE_URI);

    when(interestMapper.consolidate(webSiteProduct, interestTiers)).thenReturn(interestTiers);

    final Optional<Product> expected =
        Optional.of(
            buildProduct(
                interestTiers,
                webSiteProduct.getAccountNameFull(),
                expectedProductId,
                webSiteProduct.getProductCode(),
                webSiteProduct.getMinAgeCustomer(),
                webSiteProduct.getMaxAgeCustomer(),
                webSiteProduct.getMaxAccountsPerPerson(),
                Boolean.parseBoolean(webSiteProduct.getLoyalty()),
                InterestFrequency.ANNUAL,
                ProductType.CHILDRENS,
                facts));

    final Optional<Product> actual = testSubject.map(webSiteProduct);

    assertThat(actual.isPresent(), is(true));
    assertThat(expected, is(actual));
  }

  private static WebSiteProduct buildWebSiteProduct() {
    return WebSiteProduct.builder()
        .accountNameFull("Six Access e-Saver ISA Issue 3")
        .productCode("YB851266W")
        .minAgeCustomer(16)
        .maxAgeCustomer(99)
        .maxAccountsPerPerson(1)
        .build();
  }

  private static List<InterestTier> buildInterestTiers() {
    return Collections.singletonList(
        InterestTier.builder().description("Description").rate("0.4").range("£1 - £999").build());
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private static Product buildProduct(
      final List<InterestTier> interestTiers,
      final String productName,
      final String productId,
      final String productCode,
      final Integer minimumAge,
      final Integer maximumAge,
      final Integer maximumNumberOfAccounts,
      final boolean loyalty,
      final InterestFrequency interestFrequency,
      final ProductType productType,
      final List<Fact> facts) {
    return Product.builder()
        .facts(facts)
        .interestTiers(interestTiers)
        .name(productName)
        .type(productType)
        .url(String.format("%s/product.html?id=%s", BASE_URI, productId))
        .productCode(productCode)
        .minimumAge(minimumAge)
        .maximumAge(maximumAge)
        .maximumNumberOfAccounts(maximumNumberOfAccounts)
        .loyalty(loyalty)
        .interestFrequency(interestFrequency)
        .build();
  }
}
