package uk.co.ybs.digital.product.mapping.onsale;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;

public class TypeMapperTest {

  private static final String YES = "Yes";
  private static final String NO = "No";
  private TypeMapper testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new TypeMapper();
  }

  @ParameterizedTest
  @MethodSource("productData")
  public void testMapsTypeSuccessfully(
      final WebSiteProduct webSiteProduct, final ProductType expected) {
    final ProductType result = testSubject.map(webSiteProduct);
    assertEquals(expected, result);
  }

  private static Stream<Arguments> productData() {
    return Stream.of(
        Arguments.of(buildWebSiteProductCashIsa(), ProductType.ISA),
        Arguments.of(buildWebSiteProductFlexibleIsa(), ProductType.ISA),
        Arguments.of(buildWebSiteProductEasyAccess(), ProductType.EASY_ACCESS),
        Arguments.of(buildWebSiteProductRegularSaver(), ProductType.SAVER),
        Arguments.of(buildWebSiteProductChildrens(), ProductType.CHILDRENS),
        Arguments.of(buildWebSiteProductBond(), ProductType.BOND),
        Arguments.of(buildWebSiteProductEasyAccessAndIsa(), ProductType.ISA),
        Arguments.of(buildWebSiteProductNoTypes(), ProductType.DEFERRED));
  }

  private static WebSiteProduct buildWebSiteProductCashIsa() {
    return buildProduct(YES, NO, NO, NO, NO, NO);
  }

  private static WebSiteProduct buildWebSiteProductFlexibleIsa() {
    return buildProduct(NO, YES, NO, NO, NO, NO);
  }

  private static WebSiteProduct buildWebSiteProductEasyAccess() {
    return buildProduct(NO, NO, YES, NO, NO, NO);
  }

  private static WebSiteProduct buildWebSiteProductRegularSaver() {
    return buildProduct(NO, NO, NO, YES, NO, NO);
  }

  private static WebSiteProduct buildWebSiteProductChildrens() {
    return buildProduct(NO, NO, NO, NO, YES, NO);
  }

  private static WebSiteProduct buildWebSiteProductBond() {
    return buildProduct(NO, NO, NO, NO, NO, YES);
  }

  private static WebSiteProduct buildWebSiteProductEasyAccessAndIsa() {
    return buildProduct(YES, YES, YES, NO, NO, NO);
  }

  private static WebSiteProduct buildWebSiteProductNoTypes() {
    return buildProduct(NO, NO, NO, NO, NO, NO);
  }

  private static WebSiteProduct buildProduct(
      final String cashIsa,
      final String flexibleIsa,
      final String easyAccess,
      final String regularSaver,
      final String childrens,
      final String bond) {
    return WebSiteProduct.builder()
        .accountNameFull("Six Access e-Saver ISA Issue 3")
        .productCode("YB851266W")
        .cashISA(cashIsa)
        .flexibleISA(flexibleIsa)
        .easyAccess(easyAccess)
        .regularSaver(regularSaver)
        .childrens(childrens)
        .bond(bond)
        .minAgeCustomer(16)
        .maxAgeCustomer(99)
        .maxAccountsPerPerson(1)
        .build();
  }
}
