package uk.co.ybs.digital.product.mapping;

import static com.spotify.hamcrest.optional.OptionalMatchers.emptyOptional;
import static com.spotify.hamcrest.optional.OptionalMatchers.optionalWithValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.ProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Withdrawals;

class WithdrawalLimitsMapperTest {
  private static final String MONTH_CODE = "NOWDLM";
  private static final String YEAR_CODE = "NOWDLC";
  private static final String ANNIVERSARY_YEAR_CODE = "ANNWDL";
  private static final String TAX_YEAR_CODE = "NOWDLI";
  private static final String PRODUCT_TERM_CODE = "NOWDLP";

  private WithdrawalLimitsMapper testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new WithdrawalLimitsMapper();
  }

  @Test
  void shouldMapToEmptyOptionalWhenProductRulesDoNotIncludeAnyWithdrawalLimitRules() {
    final ActiveProductRules productRules = createActiveProductRules();

    assertThat(testSubject.map(productRules), emptyOptional());
  }

  @Test
  void shouldMapWhenProductRulesContainsMonthLimit() {
    final ActiveProductRules productRules =
        createActiveProductRules(numberProductRule(MONTH_CODE, 1L));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(
            is(
                Withdrawals.WithdrawalLimits.builder()
                    .number(PeriodLimits.<Long>builder().month(1L).build())
                    .build())));
  }

  @Test
  void shouldMapWhenProductRulesContainsYearLimit() {
    final ActiveProductRules productRules =
        createActiveProductRules(numberProductRule(YEAR_CODE, 2L));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(
            is(
                Withdrawals.WithdrawalLimits.builder()
                    .number(PeriodLimits.<Long>builder().year(2L).build())
                    .build())));
  }

  @Test
  void shouldMapWhenProductRulesContainsAnniversaryYearLimit() {
    final ActiveProductRules productRules =
        createActiveProductRules(numberProductRule(ANNIVERSARY_YEAR_CODE, 3L));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(
            is(
                Withdrawals.WithdrawalLimits.builder()
                    .number(PeriodLimits.<Long>builder().anniversaryYear(3L).build())
                    .build())));
  }

  @Test
  void shouldMapWhenProductRulesContainsTaxYearLimit() {
    final ActiveProductRules productRules =
        createActiveProductRules(numberProductRule(TAX_YEAR_CODE, 4L));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(
            is(
                Withdrawals.WithdrawalLimits.builder()
                    .number(PeriodLimits.<Long>builder().taxYear(4L).build())
                    .build())));
  }

  @Test
  void shouldMapWhenProductRulesContainsProductTermLimit() {
    final ActiveProductRules productRules =
        createActiveProductRules(numberProductRule(PRODUCT_TERM_CODE, 5L));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(
            is(
                Withdrawals.WithdrawalLimits.builder()
                    .number(PeriodLimits.<Long>builder().productTerm(5L).build())
                    .build())));
  }

  @Test
  void shouldMapWhenProductRulesContainsMultipleLimit() {
    final ActiveProductRules productRules =
        createActiveProductRules(
            numberProductRule(MONTH_CODE, 1L),
            numberProductRule(YEAR_CODE, 2L),
            numberProductRule(ANNIVERSARY_YEAR_CODE, 3L),
            numberProductRule(TAX_YEAR_CODE, 4L),
            numberProductRule(PRODUCT_TERM_CODE, 5L));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(
            is(
                Withdrawals.WithdrawalLimits.builder()
                    .number(
                        PeriodLimits.<Long>builder()
                            .month(1L)
                            .year(2L)
                            .anniversaryYear(3L)
                            .taxYear(4L)
                            .productTerm(5L)
                            .build())
                    .build())));
  }

  private ProductRule numberProductRule(final String code, final Long value) {
    return ProductRule.builder()
        .availableProductRule(AvailableProductRule.builder().code(code).build())
        .numberValue(value)
        .build();
  }
}
