package uk.co.ybs.digital.product.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import uk.co.ybs.digital.product.exception.NoProductForIdentifierException;
import uk.co.ybs.digital.product.mapping.ProductDetailsResponseMapper;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.InterestTier;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductRule;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;
import uk.co.ybs.digital.product.repository.InterestTierRepository;
import uk.co.ybs.digital.product.repository.ProductRepository;
import uk.co.ybs.digital.product.repository.ProductRuleRepository;
import uk.co.ybs.digital.product.web.dto.AvailableProductDetails;
import uk.co.ybs.digital.product.web.dto.CustomerAccountDetails;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;

@ExtendWith(MockitoExtension.class)
class ProductDetailsServiceTest {

  private static final Long PRODUCT_SYSID_1 = 1L;
  private static final Long PRODUCT_SYSID_2 = 2L;

  private static final String PRODUCT_IDENTIFIER_1 = "foo";
  private static final String PRODUCT_IDENTIFIER_2 = "bar";

  private static final String PRODUCT_RULE_CODE = "code";

  private static final ZoneId ZONE_ID = ZoneId.of("Europe/London");
  private static final Instant NOW_INSTANT = Instant.parse("2020-05-18T13:15:21Z");
  private static final LocalDateTime NOW = LocalDateTime.ofInstant(NOW_INSTANT, ZONE_ID);

  private static final UUID REQUEST_ID = UUID.fromString("564e6e5c-7fac-4c68-b721-4e466645c7e3");

  private static final int CURRENT_TESSA_YEAR = 22;

  private static final List<String> PRODUCT_RULES =
      Stream.concat(
              AvailableProductRule.KNOWN_PRODUCT_RULES.stream(),
              Stream.of(AvailableProductRule.DEPOSIT_LIMIT_TAX_YEAR_PREFIX + CURRENT_TESSA_YEAR))
          .collect(Collectors.toList());

  private static final String SYSID_PROPERTY = "sysid";

  @Mock private ProductRepository productRepository;
  @Mock private InterestTierRepository interestTierRepository;
  @Mock private ProductRuleRepository productRuleRepository;
  @Mock private ProductDetailsResponseMapper productDetailsResponseMapper;
  @Mock private TessaYearCalculator tessaYearCalculator;

  @Mock private ProductFilterService productFilterService;

  private final Clock clock = Clock.fixed(NOW_INSTANT, ZONE_ID);

  private ProductDetailsService testSubject;

  @BeforeEach
  void setUp() {
    testSubject =
        new ProductDetailsService(
            clock,
            productRepository,
            interestTierRepository,
            productRuleRepository,
            productDetailsResponseMapper,
            tessaYearCalculator,
            productFilterService);
  }

  @Test
  void getProductDetailsForProductIdentifierShouldFindAndMapProduct() {
    final Product foundProduct = stubProduct();
    final ProductRule foundProductRule = stubProductRule(foundProduct);

    final ProductDetailsResponse mappedProductDetailsResponse =
        ProductDetailsResponse.builder().productIdentifier(PRODUCT_IDENTIFIER_1).build();
    when(productDetailsResponseMapper.map(
            foundProduct, new ActiveProductRules(Collections.singletonList(foundProductRule)), NOW))
        .thenReturn(mappedProductDetailsResponse);

    final ProductDetailsResponse response =
        testSubject.getProductDetailsForIdentifier(PRODUCT_IDENTIFIER_1);

    assertThat(response, is(mappedProductDetailsResponse));
    verifyNoInteractions(interestTierRepository);
  }

  @Test
  void getProductDetailsPrivateForProductIdentifierShouldFindAndMapProduct() {
    final Product foundProduct = stubProduct();
    final ProductRule foundProductRule = stubProductRule(foundProduct);

    final ProductDetailsResponsePrivate mappedProductDetailsResponse =
        ProductDetailsResponsePrivate.builder().productIdentifier(PRODUCT_IDENTIFIER_1).build();
    when(productDetailsResponseMapper.mapPrivate(
            foundProduct, new ActiveProductRules(Collections.singletonList(foundProductRule)), NOW))
        .thenReturn(mappedProductDetailsResponse);

    final ProductDetailsResponsePrivate response =
        testSubject.getProductDetailsPrivateForIdentifier(PRODUCT_IDENTIFIER_1);

    assertThat(response, is(mappedProductDetailsResponse));
    verifyNoInteractions(interestTierRepository);
  }

  @ParameterizedTest
  @MethodSource("serviceMethods")
  void
      getProductDetailsForProductIdentifierShouldThrowNoProductForIdentifierExceptionWhenProductNotFound(
          final Function<ProductDetailsService, Executable> serviceMethod) {
    when(productRepository.findByProductIdentifier(PRODUCT_IDENTIFIER_1, NOW))
        .thenReturn(Optional.empty());

    final NoProductForIdentifierException thrown =
        assertThrows(NoProductForIdentifierException.class, serviceMethod.apply(testSubject));

    assertThat(thrown.getMessage(), is("No product found for identifier: foo"));
    verifyNoInteractions(interestTierRepository);
    verifyNoInteractions(productRuleRepository);
  }

  private static Stream<Function<ProductDetailsService, Executable>> serviceMethods() {
    return Stream.of(
        service -> () -> service.getProductDetailsForIdentifier(PRODUCT_IDENTIFIER_1),
        service -> () -> service.getProductDetailsPrivateForIdentifier(PRODUCT_IDENTIFIER_1));
  }

  @Test
  void searchProductsShouldFindAndMapPageOfProducts() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1, PRODUCT_IDENTIFIER_2))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY);

    final Product foundProduct1 = product(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final Product foundProduct2 = product(PRODUCT_SYSID_2, PRODUCT_IDENTIFIER_2);
    final ImmutableList<Product> foundProducts = ImmutableList.of(foundProduct1, foundProduct2);
    when(productRepository.findAll(searchCriteria, pageable))
        .thenReturn(new PageImpl<>(foundProducts, pageable, 2));

    final InterestTier foundInterestTier1a =
        InterestTier.builder().sysid(1L).product(foundProduct1).build();
    final InterestTier foundInterestTier1b =
        InterestTier.builder().sysid(2L).product(foundProduct1).build();
    final InterestTier foundInterestTier2a =
        InterestTier.builder().sysid(3L).product(foundProduct2).build();

    when(interestTierRepository.findAllActive(Arrays.asList(PRODUCT_SYSID_1, PRODUCT_SYSID_2), NOW))
        .thenReturn(Arrays.asList(foundInterestTier1a, foundInterestTier1b, foundInterestTier2a));

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    final ProductRule product1Rule =
        productRule(foundProduct1, availableProductRule(PRODUCT_RULE_CODE));
    final ProductRule product2Rule =
        productRule(foundProduct2, availableProductRule(PRODUCT_RULE_CODE));
    when(productRuleRepository.findByProductAndRuleCodes(foundProducts, PRODUCT_RULES, NOW))
        .thenReturn(ImmutableList.of(product1Rule, product2Rule));

    final Product foundProductWithInterestTiers1 =
        foundProduct1
            .toBuilder()
            .interestTier(foundInterestTier1a)
            .interestTier(foundInterestTier1b)
            .build();

    final Product foundProductWithInterestTiers2 =
        foundProduct2.toBuilder().interestTier(foundInterestTier2a).build();

    final ProductDetailsResponse mappedProductDetailsResponse1 =
        ProductDetailsResponse.builder().productIdentifier(PRODUCT_IDENTIFIER_1).build();
    final ProductDetailsResponse mappedProductDetailsResponse2 =
        ProductDetailsResponse.builder().productIdentifier(PRODUCT_IDENTIFIER_2).build();
    when(productDetailsResponseMapper.map(
            foundProductWithInterestTiers1,
            new ActiveProductRules(ImmutableList.of(product1Rule)),
            NOW))
        .thenReturn(mappedProductDetailsResponse1);
    when(productDetailsResponseMapper.map(
            foundProductWithInterestTiers2,
            new ActiveProductRules(ImmutableList.of(product2Rule)),
            NOW))
        .thenReturn(mappedProductDetailsResponse2);

    final Page<ProductDetailsResponse> responsePage =
        testSubject.searchProducts(searchCriteria, pageable);

    assertThat(responsePage.getNumber(), is(pageNumber));
    assertThat(responsePage.getSize(), is(pageSize));
    assertThat(responsePage.getTotalPages(), is(1));
    assertThat(responsePage.getTotalElements(), is(2L));
    assertThat(
        responsePage.getContent(),
        contains(mappedProductDetailsResponse1, mappedProductDetailsResponse2));
  }

  @Test
  void searchProductsPrivateShouldFindAndMapPageOfProducts() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1, PRODUCT_IDENTIFIER_2))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY);

    final Product foundProduct1 = product(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final Product foundProduct2 = product(PRODUCT_SYSID_2, PRODUCT_IDENTIFIER_2);
    final ImmutableList<Product> foundProducts = ImmutableList.of(foundProduct1, foundProduct2);
    when(productRepository.findAll(searchCriteria, pageable))
        .thenReturn(new PageImpl<>(foundProducts, pageable, 2));

    final InterestTier foundInterestTier1a =
        InterestTier.builder().sysid(1L).product(foundProduct1).build();
    final InterestTier foundInterestTier1b =
        InterestTier.builder().sysid(2L).product(foundProduct1).build();
    final InterestTier foundInterestTier2a =
        InterestTier.builder().sysid(3L).product(foundProduct2).build();

    when(interestTierRepository.findAllActive(Arrays.asList(PRODUCT_SYSID_1, PRODUCT_SYSID_2), NOW))
        .thenReturn(Arrays.asList(foundInterestTier1a, foundInterestTier1b, foundInterestTier2a));

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    final ProductRule product1Rule =
        productRule(foundProduct1, availableProductRule(PRODUCT_RULE_CODE));
    final ProductRule product2Rule =
        productRule(foundProduct2, availableProductRule(PRODUCT_RULE_CODE));
    when(productRuleRepository.findByProductAndRuleCodes(foundProducts, PRODUCT_RULES, NOW))
        .thenReturn(ImmutableList.of(product1Rule, product2Rule));

    final Product foundProductWithInterestTiers1 =
        foundProduct1
            .toBuilder()
            .interestTier(foundInterestTier1a)
            .interestTier(foundInterestTier1b)
            .build();

    final Product foundProductWithInterestTiers2 =
        foundProduct2.toBuilder().interestTier(foundInterestTier2a).build();

    final ProductDetailsResponsePrivate mappedProductDetailsResponse1 =
        ProductDetailsResponsePrivate.builder().productIdentifier(PRODUCT_IDENTIFIER_1).build();
    final ProductDetailsResponsePrivate mappedProductDetailsResponse2 =
        ProductDetailsResponsePrivate.builder().productIdentifier(PRODUCT_IDENTIFIER_2).build();
    when(productDetailsResponseMapper.mapPrivate(
            foundProductWithInterestTiers1,
            new ActiveProductRules(ImmutableList.of(product1Rule)),
            NOW))
        .thenReturn(mappedProductDetailsResponse1);
    when(productDetailsResponseMapper.mapPrivate(
            foundProductWithInterestTiers2,
            new ActiveProductRules(ImmutableList.of(product2Rule)),
            NOW))
        .thenReturn(mappedProductDetailsResponse2);

    final Page<ProductDetailsResponsePrivate> responsePage =
        testSubject.searchProductsPrivate(searchCriteria, pageable);

    assertThat(responsePage.getNumber(), is(pageNumber));
    assertThat(responsePage.getSize(), is(pageSize));
    assertThat(responsePage.getTotalPages(), is(1));
    assertThat(responsePage.getTotalElements(), is(2L));
    assertThat(
        responsePage.getContent(),
        contains(mappedProductDetailsResponse1, mappedProductDetailsResponse2));
  }

  @Test
  void searchProductsShouldFindAndMapPageOfProductsWhenNoInterestTiersFound() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1, PRODUCT_IDENTIFIER_2))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY);

    final Product foundProduct1 = product(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final Product foundProduct2 = product(PRODUCT_SYSID_2, PRODUCT_IDENTIFIER_2);
    final ImmutableList<Product> foundProducts = ImmutableList.of(foundProduct1, foundProduct2);
    when(productRepository.findAll(searchCriteria, pageable))
        .thenReturn(new PageImpl<>(foundProducts, pageable, 2));

    when(interestTierRepository.findAllActive(Arrays.asList(PRODUCT_SYSID_1, PRODUCT_SYSID_2), NOW))
        .thenReturn(Collections.emptyList());

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    final ProductRule product1Rule =
        productRule(foundProduct1, availableProductRule(PRODUCT_RULE_CODE));
    final ProductRule product2Rule =
        productRule(foundProduct2, availableProductRule(PRODUCT_RULE_CODE));
    when(productRuleRepository.findByProductAndRuleCodes(foundProducts, PRODUCT_RULES, NOW))
        .thenReturn(ImmutableList.of(product1Rule, product2Rule));

    final Product foundProductWithInterestTiers1 =
        foundProduct1.toBuilder().interestTiers(Collections.emptyList()).build();

    final Product foundProductWithInterestTiers2 =
        foundProduct2.toBuilder().interestTiers(Collections.emptyList()).build();

    final ProductDetailsResponse mappedProductDetailsResponse1 =
        ProductDetailsResponse.builder().productIdentifier(PRODUCT_IDENTIFIER_1).build();
    final ProductDetailsResponse mappedProductDetailsResponse2 =
        ProductDetailsResponse.builder().productIdentifier(PRODUCT_IDENTIFIER_2).build();
    when(productDetailsResponseMapper.map(
            foundProductWithInterestTiers1,
            new ActiveProductRules(ImmutableList.of(product1Rule)),
            NOW))
        .thenReturn(mappedProductDetailsResponse1);
    when(productDetailsResponseMapper.map(
            foundProductWithInterestTiers2,
            new ActiveProductRules(ImmutableList.of(product2Rule)),
            NOW))
        .thenReturn(mappedProductDetailsResponse2);

    final Page<ProductDetailsResponse> responsePage =
        testSubject.searchProducts(searchCriteria, pageable);

    assertThat(responsePage.getNumber(), is(pageNumber));
    assertThat(responsePage.getSize(), is(pageSize));
    assertThat(responsePage.getTotalPages(), is(1));
    assertThat(responsePage.getTotalElements(), is(2L));
    assertThat(
        responsePage.getContent(),
        contains(mappedProductDetailsResponse1, mappedProductDetailsResponse2));
  }

  @Test
  void searchProductsPrivateShouldFindAndMapPageOfProductsWhenNoInterestTiersFound() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1, PRODUCT_IDENTIFIER_2))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY);

    final Product foundProduct1 = product(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final Product foundProduct2 = product(PRODUCT_SYSID_2, PRODUCT_IDENTIFIER_2);
    final ImmutableList<Product> foundProducts = ImmutableList.of(foundProduct1, foundProduct2);
    when(productRepository.findAll(searchCriteria, pageable))
        .thenReturn(new PageImpl<>(foundProducts, pageable, 2));

    when(interestTierRepository.findAllActive(Arrays.asList(PRODUCT_SYSID_1, PRODUCT_SYSID_2), NOW))
        .thenReturn(Collections.emptyList());

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    final ProductRule product1Rule =
        productRule(foundProduct1, availableProductRule(PRODUCT_RULE_CODE));
    final ProductRule product2Rule =
        productRule(foundProduct2, availableProductRule(PRODUCT_RULE_CODE));
    when(productRuleRepository.findByProductAndRuleCodes(foundProducts, PRODUCT_RULES, NOW))
        .thenReturn(ImmutableList.of(product1Rule, product2Rule));

    final Product foundProductWithInterestTiers1 =
        foundProduct1.toBuilder().interestTiers(Collections.emptyList()).build();

    final Product foundProductWithInterestTiers2 =
        foundProduct2.toBuilder().interestTiers(Collections.emptyList()).build();

    final ProductDetailsResponsePrivate mappedProductDetailsResponse1 =
        ProductDetailsResponsePrivate.builder().productIdentifier(PRODUCT_IDENTIFIER_1).build();
    final ProductDetailsResponsePrivate mappedProductDetailsResponse2 =
        ProductDetailsResponsePrivate.builder().productIdentifier(PRODUCT_IDENTIFIER_2).build();
    when(productDetailsResponseMapper.mapPrivate(
            foundProductWithInterestTiers1,
            new ActiveProductRules(ImmutableList.of(product1Rule)),
            NOW))
        .thenReturn(mappedProductDetailsResponse1);
    when(productDetailsResponseMapper.mapPrivate(
            foundProductWithInterestTiers2,
            new ActiveProductRules(ImmutableList.of(product2Rule)),
            NOW))
        .thenReturn(mappedProductDetailsResponse2);

    final Page<ProductDetailsResponsePrivate> responsePage =
        testSubject.searchProductsPrivate(searchCriteria, pageable);

    assertThat(responsePage.getNumber(), is(pageNumber));
    assertThat(responsePage.getSize(), is(pageSize));
    assertThat(responsePage.getTotalPages(), is(1));
    assertThat(responsePage.getTotalElements(), is(2L));
    assertThat(
        responsePage.getContent(),
        contains(mappedProductDetailsResponse1, mappedProductDetailsResponse2));
  }

  @Test
  void searchProductsShouldFindAndMapPageOfProductsWhenNoProductRulesFound() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY);

    final Product foundProduct1 = product(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final ImmutableList<Product> foundProducts = ImmutableList.of(foundProduct1);
    when(productRepository.findAll(searchCriteria, pageable))
        .thenReturn(new PageImpl<>(foundProducts, pageable, 1));

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    when(productRuleRepository.findByProductAndRuleCodes(foundProducts, PRODUCT_RULES, NOW))
        .thenReturn(Collections.emptyList());

    final ProductDetailsResponse mappedProductDetailsResponse1 =
        ProductDetailsResponse.builder().productIdentifier(PRODUCT_IDENTIFIER_1).build();
    when(productDetailsResponseMapper.map(
            foundProduct1, new ActiveProductRules(Collections.emptyList()), NOW))
        .thenReturn(mappedProductDetailsResponse1);

    final Page<ProductDetailsResponse> responsePage =
        testSubject.searchProducts(searchCriteria, pageable);

    assertThat(responsePage.getNumber(), is(pageNumber));
    assertThat(responsePage.getSize(), is(pageSize));
    assertThat(responsePage.getTotalPages(), is(1));
    assertThat(responsePage.getTotalElements(), is(1L));
    assertThat(responsePage.getContent(), contains(mappedProductDetailsResponse1));
  }

  @Test
  void searchProductsPrivateShouldFindAndMapPageOfProductsWhenNoProductRulesFound() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY);

    final Product foundProduct1 = product(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final ImmutableList<Product> foundProducts = ImmutableList.of(foundProduct1);
    when(productRepository.findAll(searchCriteria, pageable))
        .thenReturn(new PageImpl<>(foundProducts, pageable, 1));

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    when(productRuleRepository.findByProductAndRuleCodes(foundProducts, PRODUCT_RULES, NOW))
        .thenReturn(Collections.emptyList());

    final ProductDetailsResponsePrivate mappedProductDetailsResponse1 =
        ProductDetailsResponsePrivate.builder().productIdentifier(PRODUCT_IDENTIFIER_1).build();
    when(productDetailsResponseMapper.mapPrivate(
            foundProduct1, new ActiveProductRules(Collections.emptyList()), NOW))
        .thenReturn(mappedProductDetailsResponse1);

    final Page<ProductDetailsResponsePrivate> responsePage =
        testSubject.searchProductsPrivate(searchCriteria, pageable);

    assertThat(responsePage.getNumber(), is(pageNumber));
    assertThat(responsePage.getSize(), is(pageSize));
    assertThat(responsePage.getTotalPages(), is(1));
    assertThat(responsePage.getTotalElements(), is(1L));
    assertThat(responsePage.getContent(), contains(mappedProductDetailsResponse1));
  }

  @Test
  void searchProductsShouldFindAndMapEmptyPageOfProducts() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1, PRODUCT_IDENTIFIER_2))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY);

    when(productRepository.findAll(searchCriteria, pageable))
        .thenReturn(new PageImpl<>(Collections.emptyList(), pageable, 0));

    final Page<ProductDetailsResponse> responsePage =
        testSubject.searchProducts(searchCriteria, pageable);

    verify(productRuleRepository, never()).findByProductAndRuleCodes(any(), any(), any());
    verify(tessaYearCalculator, never()).getTessaYear(any());
    verify(productDetailsResponseMapper, never()).map(any(), any(), any());

    assertThat(responsePage.getNumber(), is(pageNumber));
    assertThat(responsePage.getSize(), is(pageSize));
    assertThat(responsePage.getTotalPages(), is(0));
    assertThat(responsePage.getTotalElements(), is(0L));
    assertThat(responsePage.getContent(), emptyIterable());
  }

  @Test
  void searchProductsPrivateShouldFindAndMapEmptyPageOfProducts() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1, PRODUCT_IDENTIFIER_2))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY);

    when(productRepository.findAll(searchCriteria, pageable))
        .thenReturn(new PageImpl<>(Collections.emptyList(), pageable, 0));

    final Page<ProductDetailsResponsePrivate> responsePage =
        testSubject.searchProductsPrivate(searchCriteria, pageable);

    verify(productRuleRepository, never()).findByProductAndRuleCodes(any(), any(), any());
    verify(tessaYearCalculator, never()).getTessaYear(any());
    verify(productDetailsResponseMapper, never()).mapPrivate(any(), any(), any());

    assertThat(responsePage.getNumber(), is(pageNumber));
    assertThat(responsePage.getSize(), is(pageSize));
    assertThat(responsePage.getTotalPages(), is(0));
    assertThat(responsePage.getTotalElements(), is(0L));
    assertThat(responsePage.getContent(), emptyIterable());
  }

  @Test
  void searchProductsShouldAddDefaultSortOrderToSearchCriteriaToEnsureConsistentOrdering() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize);

    when(productRepository.findAll(any(ProductSearchCriteria.class), any()))
        .thenReturn(new PageImpl<>(Collections.emptyList(), pageable, 0));

    testSubject.searchProducts(searchCriteria, pageable);

    verify(productRepository)
        .findAll(
            searchCriteria, PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY));
  }

  @Test
  void searchProductsPrivateShouldAddDefaultSortOrderToSearchCriteriaToEnsureConsistentOrdering() {
    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER_1))
            .build();
    final int pageNumber = 0;
    final int pageSize = 100;
    final Pageable pageable = PageRequest.of(pageNumber, pageSize);

    when(productRepository.findAll(any(ProductSearchCriteria.class), any()))
        .thenReturn(new PageImpl<>(Collections.emptyList(), pageable, 0));

    testSubject.searchProductsPrivate(searchCriteria, pageable);

    verify(productRepository)
        .findAll(
            searchCriteria, PageRequest.of(pageNumber, pageSize, Direction.ASC, SYSID_PROPERTY));
  }

  private Product product(final Long sysid, final String productIdentifier) {
    return Product.builder().sysid(sysid).productIdentifier(productIdentifier).build();
  }

  private AvailableProductRule availableProductRule(final String code) {
    return AvailableProductRule.builder().code(code).build();
  }

  private ProductRule productRule(
      final Product product, final AvailableProductRule availableProductRule) {
    return ProductRule.builder(product, availableProductRule, LocalDateTime.now()).build();
  }

  private Product stubProduct() {
    final Product product = product(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    when(productRepository.findByProductIdentifier(PRODUCT_IDENTIFIER_1, NOW))
        .thenReturn(Optional.of(product));
    return product;
  }

  private ProductRule stubProductRule(final Product product) {
    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    final ProductRule productRule = productRule(product, availableProductRule(PRODUCT_RULE_CODE));
    when(productRuleRepository.findByProductAndRuleCodes(
            Collections.singletonList(product), PRODUCT_RULES, NOW))
        .thenReturn(ImmutableList.of(productRule));
    return productRule;
  }

  @Test
  void testInvalidDate() {

    final NullPointerException thrown =
        assertThrows(NullPointerException.class, () -> AvailableProductDetails.builder().build());

    assertEquals(thrown.getMessage(), "dateOfBirth is marked non-null but is null");
  }

  @Test
  void testInvalidCountryCode() {

    final NullPointerException thrown =
        assertThrows(
            NullPointerException.class,
            () -> AvailableProductDetails.builder().dateOfBirth("2011-11-30").build());

    assertEquals(thrown.getMessage(), "countryCode is marked non-null but is null");
  }

  @Test
  void normalResult() {

    final CustomerAccountDetails customerAccountDetails1 =
        CustomerAccountDetails.builder().productIdentifier("Foo inc").count(1).build();

    final List<CustomerAccountDetails> products = new ArrayList<>();
    products.add(customerAccountDetails1);
    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder()
            .dateOfBirth("2011-11-30")
            .countryCode("UK")
            .accounts(products)
            .applicationsInProgress(products)
            .build();
    final List<ProductCategory> toReturn = new ArrayList<>();

    final List<uk.co.ybs.digital.product.web.dto.onsale.Product> productsList = new ArrayList<>();

    final ProductCategory theProductCategory =
        ProductCategory.builder()
            .title("Title")
            .subTitle("subtitle")
            .description("description")
            .offlineOnlyProductsAvailable(false)
            .url("/")
            .products(productsList)
            .build();
    toReturn.add(theProductCategory);
    when(productFilterService.filterProducts(
            availableProductDetails, LocalDateTime.now(clock), REQUEST_ID))
        .thenReturn(toReturn);

    final List<ProductCategory> ret =
        testSubject.getAvailableProducts(availableProductDetails, REQUEST_ID);
    assertThat(ret.size(), is(1));
  }
}
