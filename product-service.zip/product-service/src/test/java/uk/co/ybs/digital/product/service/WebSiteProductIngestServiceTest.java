package uk.co.ybs.digital.product.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.mapping.WebSiteProductMapper;
import uk.co.ybs.digital.product.utils.TestHelper;

@ExtendWith(MockitoExtension.class)
class WebSiteProductIngestServiceTest {

  private static final String DOCUMENT_ID = "124";

  private static final UUID REQUEST_ID = UUID.fromString("564e6e5c-7fac-4c68-b721-4e466645c7e3");

  @InjectMocks private WebSiteProductIngestService webSiteProductIngestService;

  @Mock private LiferayService liferayService;

  @Mock private WebSiteProductMapper webSiteProductMapper;

  @Mock private WebSiteProductIngestServiceProperties webSiteProductIngestServiceProperties;

  @Test
  void getShouldReturnWebProduct() {

    final WebSiteProduct webSiteProduct = TestHelper.buildFullWebsiteProductISA();

    final LiferayDocument liferayDocument = LiferayDocument.builder().build();

    final List<WebSiteProduct> expected = Collections.singletonList(webSiteProduct);

    when(webSiteProductIngestServiceProperties.getOnsaleProductListDocumentId())
        .thenReturn(DOCUMENT_ID);

    when(liferayService.getDocument(eq(REQUEST_ID), eq(DOCUMENT_ID))).thenReturn(liferayDocument);

    when(webSiteProductMapper.map(eq(liferayDocument))).thenReturn(expected);

    final List<WebSiteProduct> result = webSiteProductIngestService.get(REQUEST_ID);

    assertThat(result, is(expected));
  }
}
