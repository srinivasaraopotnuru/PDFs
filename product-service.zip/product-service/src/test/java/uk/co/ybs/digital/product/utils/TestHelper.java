package uk.co.ybs.digital.product.utils;

import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;
import lombok.experimental.UtilityClass;
import org.springframework.cache.CacheManager;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Account;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.AdditionalInformation;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Apply;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Help;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Interest;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.InterestRateChanges;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ManageAccount;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Prerequisites;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ProductSummary;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Projections;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Tiers;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Withdrawals;

@UtilityClass
public class TestHelper {

  public static final String PRODUCT_TYPE = "PRDTYP";
  public static final String PAYMENT_ACCOUNT = "PAYACC";
  public static final String WEB_WITHDRAWALS = "WEBWDL";
  public static final String WEB_TRANSACTIONS = "WEBTRN";
  public static final String ISA_HELP_TO_BUY = "ISAFTB";
  public static final String ISA_FLEXIBLE = "ISAFLX";
  public static final String OFFSET_ACCOUNT = "OFFSET";
  public static final String STOP_EXTERNAL_DEPOSITS = "STPREC";
  public static final String ALLOW_BANK_TRANSFER_DEPOSITS = "TRNSFR";
  public static final String ALLOW_DIRECT_DEBIT_DEPOSITS = "ALDDIN";
  public static final String ALLOW_BRANCH_TRANSFERS = "BRTRAN";

  private static final String FORMAT_TEXT = "TEXT";
  private static final String FORMAT_LINK = "LINK";
  private static final String FORMAT_HEADER = "HEADER";
  private static final String TITLE_APPLY = "Apply";
  private static final String YES = "Yes";

  public static String readClassPathResource(final String classPathResource) {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  public static String readClassPathResource(final Resource resource) {
    try {
      return new String(Files.readAllBytes(resource.getFile().toPath()), StandardCharsets.UTF_8);
    } catch (final IOException e) {
      throw new RuntimeException("Error reading " + resource, e);
    }
  }

  public static void clearCacheManager(final CacheManager cacheManager) {
    cacheManager
        .getCacheNames()
        .forEach(name -> Objects.requireNonNull(cacheManager.getCache(name)).invalidate());
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength") // NOPMD
  public static WebSiteProduct buildFullWebsiteProductFixedISA(
      final String taxFree,
      final String accountNameFull,
      final String applyOnline,
      final String maturesIntoProductName,
      final String interestAnnually) {
    return WebSiteProduct.builder()
        .brand("YBS")
        .accountNameFull(accountNameFull)
        .newProduct(YES)
        .accountNameShort("Fixed Rate ISA until 30/09/2022")
        .productID("YB281405B")
        .productCode("YB281405B")
        .equivalentProduct("YB291405W")
        .effectiveDate("12/08/2021")
        .endDate("30/09/2022")
        .monthlyLimit(null)
        .firstMonthLimit(null)
        .regularSaverTerm(null)
        .maxAmountEligibleForBonus(null)
        .maxBalance(null)
        .minOpeningBalance(100)
        .maxOpeningBalance(null)
        .introductoryBonusRate(null)
        .introductoryBonusPeriod(null)
        .interestType("Fixed")
        .interestAnnually(interestAnnually)
        .interestBiannually(null)
        .interestMonthly("")
        .annualGrossT1("1")
        .annualAERT1("1.00")
        .monthlyGrossT1(null)
        .monthlyAERT1(null)
        .minBalanceT1("100")
        .tieredProduct("")
        .annualGrossT2(null)
        .annualAERT2(null)
        .monthlyGrossT2(null)
        .monthlyAERT2(null)
        .minBalanceT2(null)
        .annualGrossT3(null)
        .annualAERT3(null)
        .monthlyGrossT3(null)
        .monthlyAERT3(null)
        .minBalanceT3(null)
        .annualGrossT4(null)
        .annualAERT4(null)
        .monthlyGrossT4(null)
        .monthlyAERT4(null)
        .minBalanceT4(null)
        .annualGrossT5(null)
        .annualAERT5(null)
        .monthlyGrossT5(null)
        .monthlyAERT5(null)
        .minBalanceT5(null)
        .previousRate("")
        .annualGrossT1Previous(null)
        .annualAERT1Previous(null)
        .monthlyGrossT1Previous(null)
        .monthlyAERT1Previous(null)
        .annualGrossT2Previous(null)
        .annualAERT2Previous(null)
        .monthlyGrossT2Previous(null)
        .monthlyAERT2Previous(null)
        .annualGrossT3Previous(null)
        .annualAERT3Previous(null)
        .monthlyGrossT3Previous(null)
        .monthlyAERT3Previous(null)
        .annualGrossT4Previous(null)
        .annualAERT4Previous(null)
        .monthlyGrossT4Previous(null)
        .monthlyAERT4Previous(null)
        .annualGrossT5Previous(null)
        .annualAERT5Previous(null)
        .monthlyGrossT5Previous(null)
        .monthlyAERT5Previous(null)
        .effectiveDatePrevious("")
        .annualGrossT1WithBonus(null)
        .annualAERT1WithBonus(null)
        .monthlyGrossT1WithBonus(null)
        .monthlyAERT1WithBonus(null)
        .applyOnline(applyOnline)
        .applyInBranch(YES)
        .applyInAgency(YES)
        .applyByPost(YES)
        .manageOnline(YES)
        .viewOnline("")
        .manageInBranch(YES)
        .manageInAgency(YES)
        .manageByPost(YES)
        .trusteeAccountsAccepted("")
        .maturesIntoProductName(maturesIntoProductName)
        .noYBSFundsInAllowed(null)
        .accountSwitching(YES)
        .maxAccountHolders(1)
        .minAgeCustomer(16)
        .minAgeNotHeldInTrust(null)
        .maxAgeCustomer(null)
        .interestDateLong1("30 September 2022")
        .interestDateLong2("")
        .interestDateLong3(null)
        .interestDateLong4(null)
        .interestDateLong5(null)
        .maxAccountsPerPerson(null)
        .exampleBalanceT1(BigDecimal.valueOf(1004.32))
        .exampleTermT1(12)
        .exampleStartingAmountT1(1000)
        .exampleOngoingDepositT1(null)
        .exampleBalanceT2(null)
        .exampleTermT2(null)
        .exampleStartingAmountT2(null)
        .exampleOngoingDepositT2(null)
        .exampleBalanceT3(null)
        .exampleTermT3(null)
        .exampleStartingAmountT3(null)
        .exampleOngoingDepositT3(null)
        .exampleBalanceT4(null)
        .exampleTermT4(null)
        .exampleStartingAmountT4(null)
        .exampleOngoingDepositT4(null)
        .exampleBalanceT5(null)
        .exampleTermT5(null)
        .exampleStartingAmountT5(null)
        .exampleOngoingDepositT5(null)
        .regularSaver12MonthExampleGrossInterest(null)
        .taxFree(taxFree)
        .fixedTerm(YES)
        .easyAccess("")
        .regularSaver(null)
        .childrens(null)
        .bond("")
        .cashISA(YES)
        .flexibleISA("")
        .loyalty(null)
        .aTMCard(null)
        .passbook(YES)
        .optionalWithdrawalRestriction(null)
        .withdrawalsPermitted("")
        .minWithdrawalAmount(null)
        .withdrawalDays(null)
        .closurePermitted(YES)
        .cancellationPermitted(YES)
        .lossOfInterest(60)
        .notificationDate(null)
        .notificationRate(null)
        .maturityProduct("")
        .maturityProductOffer(null)
        .withdrawalsUntilDate(null)
        .withdrawalsFromDate(null)
        .investFromDate(null)
        .lastDateForDeposits(null)
        .popularity(7)
        .prodType("Fixed ISA")
        .maturityHoldingPage("Branch ISA")
        .build();
  }

  @SuppressWarnings({
    "PMD.ExcessiveMethodLength",
    "PMD.ExcessiveParameterList",
    "PMD.AvoidDuplicateLiterals"
  })
  public static WebSiteProduct buildFullWebsiteProductVariableISA(
      final String taxFree,
      final String interestMonthly,
      final String interestAnnually,
      final String accountNameShort,
      final String accountNameFull,
      final String cashISA,
      final String maturityProduct,
      final String manageInBranch,
      final String manageOnline,
      final String fixedTerm,
      final String accountSwitching,
      final String withdrawalsPermitted,
      final Integer withdrawalDays,
      final String tieredProduct,
      final String maturesIntoProductName) {
    return WebSiteProduct.builder()
        .brand("YBS")
        .accountNameFull(accountNameFull)
        .newProduct("")
        .accountNameShort(accountNameShort)
        .productID("YB691376W")
        .productCode("YB691376W")
        .equivalentProduct("")
        .effectiveDate("20/05/2021")
        .endDate("")
        .monthlyLimit(10)
        .firstMonthLimit("9000")
        .regularSaverTerm(null)
        .maxAmountEligibleForBonus("300")
        .maxBalance(500000)
        .minOpeningBalance(1)
        .maxOpeningBalance(null)
        .introductoryBonusRate(null)
        .introductoryBonusPeriod(null)
        .interestType("Variable")
        .interestAnnually(interestAnnually)
        .interestBiannually(null)
        .interestMonthly(interestMonthly)
        .annualGrossT1("0.15")
        .annualAERT1("0.15")
        .monthlyGrossT1("0.15")
        .monthlyAERT1("0.15")
        .minBalanceT1("1")
        .tieredProduct(tieredProduct)
        .annualGrossT2("0.25")
        .annualAERT2("0.25")
        .monthlyGrossT2("0.25")
        .monthlyAERT2("0.25")
        .minBalanceT2("1000")
        .annualGrossT3("0.35")
        .annualAERT3("0.35")
        .monthlyGrossT3("0.35")
        .monthlyAERT3("0.35")
        .minBalanceT3("10000")
        .annualGrossT4("0.45")
        .annualAERT4("0.45")
        .monthlyGrossT4("0.45")
        .monthlyAERT4("0.45")
        .minBalanceT4("50000")
        .annualGrossT5("0.55")
        .annualAERT5("0.55")
        .monthlyGrossT5("0.55")
        .monthlyAERT5("0.55")
        .minBalanceT5("80000")
        .previousRate("")
        .annualGrossT1Previous(null)
        .annualAERT1Previous(null)
        .monthlyGrossT1Previous(null)
        .monthlyAERT1Previous(null)
        .annualGrossT2Previous(null)
        .annualAERT2Previous(null)
        .monthlyGrossT2Previous(null)
        .monthlyAERT2Previous(null)
        .annualGrossT3Previous(null)
        .annualAERT3Previous(null)
        .monthlyGrossT3Previous(null)
        .monthlyAERT3Previous(null)
        .annualGrossT4Previous(null)
        .annualAERT4Previous(null)
        .monthlyGrossT4Previous(null)
        .monthlyAERT4Previous(null)
        .annualGrossT5Previous(null)
        .annualAERT5Previous(null)
        .monthlyGrossT5Previous(null)
        .monthlyAERT5Previous(null)
        .effectiveDatePrevious("")
        .annualGrossT1WithBonus(null)
        .annualAERT1WithBonus(null)
        .monthlyGrossT1WithBonus(null)
        .monthlyAERT1WithBonus(null)
        .applyOnline(YES)
        .applyInBranch("")
        .applyInAgency("")
        .applyByPost("")
        .manageOnline(manageOnline)
        .viewOnline(YES)
        .manageInBranch(manageInBranch)
        .manageInAgency("")
        .manageByPost("")
        .trusteeAccountsAccepted("")
        .maturesIntoProductName(maturesIntoProductName)
        .noYBSFundsInAllowed(null)
        .accountSwitching(accountSwitching)
        .maxAccountHolders(1)
        .minAgeCustomer(16)
        .minAgeNotHeldInTrust(null)
        .maxAgeCustomer(null)
        .interestDateLong1("31 March")
        .interestDateLong2("")
        .interestDateLong3(null)
        .interestDateLong4(null)
        .interestDateLong5(null)
        .maxAccountsPerPerson(1)
        .exampleBalanceT1(BigDecimal.valueOf(500.75))
        .exampleTermT1(12)
        .exampleStartingAmountT1(500)
        .exampleOngoingDepositT1("50")
        .exampleBalanceT2(BigDecimal.valueOf(1002.50))
        .exampleTermT2(12)
        .exampleStartingAmountT2(1000)
        .exampleOngoingDepositT2("50")
        .exampleBalanceT3(BigDecimal.valueOf(10035.00))
        .exampleTermT3(12)
        .exampleStartingAmountT3(10000)
        .exampleOngoingDepositT3("50")
        .exampleBalanceT4(BigDecimal.valueOf(50200.00))
        .exampleTermT4(12)
        .exampleStartingAmountT4(50000)
        .exampleOngoingDepositT4("50")
        .exampleBalanceT5(BigDecimal.valueOf(81000.00))
        .exampleTermT5(12)
        .exampleStartingAmountT5(80000)
        .exampleOngoingDepositT5("50")
        .regularSaver12MonthExampleGrossInterest(null)
        .taxFree(taxFree)
        .fixedTerm(fixedTerm)
        .easyAccess("")
        .regularSaver(null)
        .childrens(null)
        .bond("")
        .cashISA(cashISA)
        .flexibleISA(YES)
        .loyalty(null)
        .aTMCard(null)
        .passbook("")
        .optionalWithdrawalRestriction(null)
        .withdrawalsPermitted(withdrawalsPermitted)
        .minWithdrawalAmount(null)
        .withdrawalDays(withdrawalDays)
        .closurePermitted("")
        .cancellationPermitted(YES)
        .lossOfInterest(2)
        .notificationDate(null)
        .notificationRate(null)
        .maturityProduct(maturityProduct)
        .maturityProductOffer(null)
        .withdrawalsUntilDate(null)
        .withdrawalsFromDate(null)
        .investFromDate(null)
        .lastDateForDeposits("12/12/2022")
        .popularity(2)
        .prodType("Instant Access")
        .maturityHoldingPage("")
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  public static WebSiteProduct buildFullWebsiteProductISA() {
    return WebSiteProduct.builder()
        .brand("YBS")
        .accountNameFull("Fixed Rate Cash e-ISA until 31 October 2022")
        .newProduct(null)
        .accountNameShort("Fixed Rate eISA until 31/10/2022")
        .productID("YB291415W")
        .productCode("YB291415W")
        .equivalentProduct("YB281415B")
        .effectiveDate("15/09/2021")
        .endDate("31/10/2022")
        .monthlyLimit(null)
        .firstMonthLimit(null)
        .regularSaverTerm(null)
        .maxAmountEligibleForBonus(null)
        .maxBalance(null)
        .minOpeningBalance(100)
        .maxOpeningBalance(null)
        .introductoryBonusRate(null)
        .introductoryBonusPeriod(null)
        .interestType("Fixed")
        .interestAnnually(YES)
        .interestBiannually(null)
        .interestMonthly("")
        .annualGrossT1("1.00")
        .annualAERT1("1.00")
        .monthlyGrossT1(null)
        .monthlyAERT1(null)
        .minBalanceT1("100.05")
        .tieredProduct("")
        .annualGrossT2(null)
        .annualAERT2(null)
        .monthlyGrossT2(null)
        .monthlyAERT2(null)
        .minBalanceT2(null)
        .annualGrossT3(null)
        .annualAERT3(null)
        .monthlyGrossT3(null)
        .monthlyAERT3(null)
        .minBalanceT3(null)
        .annualGrossT4(null)
        .annualAERT4(null)
        .monthlyGrossT4(null)
        .monthlyAERT4(null)
        .minBalanceT4(null)
        .annualGrossT5(null)
        .annualAERT5(null)
        .monthlyGrossT5(null)
        .monthlyAERT5(null)
        .minBalanceT5(null)
        .previousRate("")
        .annualGrossT1Previous(null)
        .annualAERT1Previous(null)
        .monthlyGrossT1Previous(null)
        .monthlyAERT1Previous(null)
        .annualGrossT2Previous(null)
        .annualAERT2Previous(null)
        .monthlyGrossT2Previous(null)
        .monthlyAERT2Previous(null)
        .annualGrossT3Previous(null)
        .annualAERT3Previous(null)
        .monthlyGrossT3Previous(null)
        .monthlyAERT3Previous(null)
        .annualGrossT4Previous(null)
        .annualAERT4Previous(null)
        .monthlyGrossT4Previous(null)
        .monthlyAERT4Previous(null)
        .annualGrossT5Previous(null)
        .annualAERT5Previous(null)
        .monthlyGrossT5Previous(null)
        .monthlyAERT5Previous(null)
        .effectiveDatePrevious("")
        .annualGrossT1WithBonus(null)
        .annualAERT1WithBonus(null)
        .monthlyGrossT1WithBonus(null)
        .monthlyAERT1WithBonus(null)
        .applyOnline(YES)
        .applyInBranch("")
        .applyInAgency("")
        .applyByPost("")
        .manageOnline(YES)
        .viewOnline("")
        .manageInBranch("")
        .manageInAgency("")
        .manageByPost("Ys")
        .trusteeAccountsAccepted("")
        .maturesIntoProductName("Online Instant Access ISA")
        .noYBSFundsInAllowed(null)
        .accountSwitching(YES)
        .maxAccountHolders(1)
        .minAgeCustomer(16)
        .minAgeNotHeldInTrust(null)
        .maxAgeCustomer(null)
        .interestDateLong1("31 October 2022")
        .interestDateLong2("")
        .interestDateLong3("")
        .interestDateLong4(null)
        .interestDateLong5(null)
        .maxAccountsPerPerson(null)
        .exampleBalanceT1(BigDecimal.valueOf(1005.08))
        .exampleTermT1(12)
        .exampleStartingAmountT1(1000)
        .exampleOngoingDepositT1(null)
        .exampleBalanceT2(null)
        .exampleTermT2(null)
        .exampleStartingAmountT2(null)
        .exampleOngoingDepositT2(null)
        .exampleBalanceT3(null)
        .exampleTermT3(null)
        .exampleStartingAmountT3(null)
        .exampleOngoingDepositT3(null)
        .exampleBalanceT4(null)
        .exampleTermT4(null)
        .exampleStartingAmountT4(null)
        .exampleOngoingDepositT4(null)
        .exampleBalanceT5(null)
        .exampleTermT5(null)
        .exampleStartingAmountT5(null)
        .exampleOngoingDepositT5(null)
        .regularSaver12MonthExampleGrossInterest(null)
        .taxFree(YES)
        .fixedTerm(YES)
        .easyAccess("")
        .regularSaver(null)
        .childrens(null)
        .bond("")
        .cashISA(YES)
        .flexibleISA("")
        .loyalty(null)
        .aTMCard(null)
        .passbook("")
        .optionalWithdrawalRestriction(null)
        .withdrawalsPermitted("")
        .minWithdrawalAmount("2")
        .withdrawalDays(null)
        .closurePermitted(YES)
        .cancellationPermitted(YES)
        .lossOfInterest(60)
        .notificationDate(null)
        .notificationRate(null)
        .maturityProduct("")
        .maturityProductOffer(null)
        .withdrawalsUntilDate(null)
        .withdrawalsFromDate(null)
        .investFromDate(null)
        .lastDateForDeposits(null)
        .popularity(4)
        .prodType("Fixed ISA")
        .maturityHoldingPage("")
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  public static ProductSummary buildExpectedMappingForFixedISA() {
    return ProductSummary.builder()
        .account(
            Account.builder()
                .section(buildSection("0", false, false))
                .title("Account name")
                .name("<bold>Fixed Rate Cash e-ISA until 31 October 2022<bold>")
                .build())
        .interest(
            Interest.builder()
                .section(buildSection("1", true, false))
                .title("What is the interest rate?")
                .summary(
                    "This account pays a <bold>fixed<bold> tiered rate of interest <bold>annually<bold>:")
                .tiers(
                    Collections.singletonList(
                        Tiers.builder()
                            .tax("<bold>1.00%<bold> Tax-free p.a.")
                            .interest("<bold>1.00%<bold> AER")
                            .build()))
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Whether you need to pay tax is dependent on your own personal circumstances and so may be subject to change in the future.")
                            .build(),
                        Content.builder().format(FORMAT_HEADER).text("Payment of interest").build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text("Interest is calculated daily on cleared balances")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Annual interest is paid on 31 October 2022. It can be paid into the Fixed Rate Cash e-ISA until 31 October 2022 account, another Yorkshire Building Society account or another building society or bank account.")
                            .build()))
                .help(
                    Arrays.asList(
                        Help.builder()
                            .header("What does 'Tax-free' mean?")
                            .text("Tax-free means that Interest is not subject to income tax")
                            .section(buildSection("?", true, false))
                            .build(),
                        Help.builder()
                            .header("What does 'AER' mean?")
                            .text(
                                "AER stands for the Annual Equivalent Rate and shows you what the interest rate would be if interest was paid and added each year. This will enable you to compare more easily the return you can expect from your savings over time.")
                            .section(buildSection("?", true, false))
                            .build(),
                        Help.builder()
                            .header("What does 'Fixed Rate' mean?")
                            .text(
                                "Fixed rate of interest means that the interest rate payable on your account will remain the same from the time you open your account until the end of the fixed rate period.")
                            .section(buildSection("?", true, false))
                            .build()))
                .build())
        .interestRateChanges(
            InterestRateChanges.builder()
                .section(buildSection("2", true, true))
                .title("Can Yorkshire Building Society change the interest rate?")
                .content(
                    Arrays.asList(
                        Content.builder().format(FORMAT_TEXT).text("<bold>No<bold>").build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text("The interest rate is fixed until 31 October 2022.")
                            .build()))
                .build())
        .projections(
            Projections.builder()
                .section(buildSection("3", true, true))
                .title(
                    "What would be the estimated balance at the end of the fixed term based on a £1,000 deposit?")
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text("At the end of the fixed term, the balance would be £1,005.08.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "We have worked this out assuming a £1,000 deposit is made on account opening on the first day the product goes on sale, interest earned is added to the account and no further deposits or withdrawals are made throughout the fixed-term.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "This projection is provided for illustrative purposes only and does not take into account your individual circumstances.")
                            .build()))
                .build())
        .manageAccount(
            ManageAccount.builder()
                .section(buildSection("4", true, true))
                .title("How do I open and manage my account?")
                .content(
                    Arrays.asList(
                        Content.builder().format(FORMAT_HEADER).text("Eligibility").build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "You have to be at least 16 years old. You must be a UK resident for tax purposes, or be a qualifying Crown employee or married to, or in a civil partnership with a qualified Crown employee. The account can only be held in your name. You may only subscribe to one Cash ISA in a single tax year.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_HEADER)
                            .text("Account opening and management")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Accounts can be opened with a minimum of £100 online at ybs.co.uk.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "The account can be managed online. You will be able to check your balance, interest rate, make and view transactions on your account online whenever you wish.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "The maximum balance is £20,000 for 2023/24 ISA allowance plus previous years’ ISA transfers. Please check with your existing provider if any charges are applicable on transfer.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Deposits are permitted until the Fixed Rate ISA is withdrawn from sale. Please note that you are only permitted to subscribe to one Cash ISA each tax year. This means that if you do not fully utilise the current year subscription amount in this Cash ISA you will not be able to open another Cash ISA during the same tax year. You are still able to subscribe any unused allowance to a Stocks and Share ISA and or Innovative Finance ISA.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "ISA Transfer In requests (either with us or other providers) are permitted up to 14 days after the Fixed Rate ISA has been withdrawn from sale. For the transfer in request to be accepted, funds must be immediately available. No additional transfers will be accepted.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Please check with your existing ISA provider for any charges applicable on transfer.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_HEADER)
                            .text("Transferring your ISA")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "You can transfer some or all of your money saved in previous tax years into a Cash ISA and/or Stocks & Shares ISA and/or Innovative Finance ISA and/or Lifetime ISA without affecting your annual allowance, subject to the product terms of your account.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "You can also transfer money saved in a Cash ISA for the current tax year into a different ISA with the same or a different provider, although you can only hold one of each type of ISA for each tax year. You must transfer the whole amount saved in the current tax year. Transfer charges may apply, please check with your existing provider. Do not transfer any ISA balance yourself otherwise you’ll lose your tax benefits.")
                            .build()))
                .build())
        .withdrawals(
            Withdrawals.builder()
                .section(buildSection("5", true, true))
                .title("Can I withdraw money?")
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Withdrawals are not permitted during the term other than circumstances covered under the Savings Pledge 2021 for account holder(s) or their immediate family members - critical or terminal illness, death, redundancy, nursing home or elderly care costs, divorce or court order. All withdrawals will result in loss of tax free status. Closure is permitted during the term subject to an amount equivalent to 60 days’ loss of interest on the closing balance. Any loss of interest will be offset against any accrued interest not yet paid. If there is insufficient accrued interest outstanding the charge will be deducted from the account balance prior to closure. Closure for the circumstances detailed above under the Savings Pledge 2021 will not incur a loss of interest on the closing balance. Any early closure (except for transfers to another ISA) will result in loss of tax free status.")
                            .build(),
                        Content.builder().format(FORMAT_HEADER).text("Maturity").build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "On maturity your balance will be automatically transferred into an Online Instant Access ISA. You may have the option to transfer the balance into another Fixed Rate eISA without the need to reapply.")
                            .build()))
                .build())
        .additionalInformation(
            AdditionalInformation.builder()
                .section(buildSection("6", true, true))
                .title("Additional information")
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Interest earned from your ISA is tax-free and does not contribute to your Personal Savings Allowance.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "If you fail to invest in your Cash ISA in a single year, under HM Revenue and Customs rules you will be required to complete a declaration form before you can invest further.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "We will advise you of the forthcoming product maturity, and generally communicate with you via email. It is very important that you notify us if your email address changes.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "You can change your contact details (postal address, email and telephone) when you are logged in. To change your name you will need to write, enclosing proof of the change, to Savings Service, Yorkshire Building Society, Yorkshire House, Bradford, West Yorkshire, BD5 8LJ.")
                            .build()))
                .build())
        .prerequisites(
            Prerequisites.builder()
                .section(buildSection("7", false, false))
                .title("Before you apply")
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Please take time to review the following documents before you apply.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text("Product Terms")
                            .link("https://www.ybs.co.uk/productdata/Factsheet-YB291415W.pdf")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text("General Terms and Conditions")
                            .link(
                                "https://www.ybs.co.uk/productdata/YBM0617_Inline_General_TandCs.pdf")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text("FSCS Information Sheet")
                            .link("https://www.ybs.co.uk/productdata/FSCS.pdf")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text("Charges and Fees")
                            .link("https://www.ybs.co.uk/productdata/Charges_and_Fees.pdf")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text(
                                "When you apply for this account with us, you'll need to <link>verify your identity and address<link>.")
                            .link("https://www.ybs.co.uk/help/verifying-your-identity.html")
                            .build()))
                .build())
        .apply(
            Apply.builder()
                .section(buildSection("8", false, false))
                .title(TITLE_APPLY)
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text("Complete our simple, straightforward application form")
                            .build(),
                        Content.builder().format("BUTTON").text(TITLE_APPLY).build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "If you feel you need additional support before applying for this account, please call us")
                            .build(),
                        Content.builder().format(FORMAT_TEXT).text("0345 1200 100").build(),
                        Content.builder().format(FORMAT_TEXT).text("9am - 5pm Mon-Fri").build(),
                        Content.builder().format(FORMAT_TEXT).text("9am - 1pm Sat").build()))
                .build())
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  public static ProductSummary buildExpectedMappingForEasyAccess() {
    return ProductSummary.builder()
        .account(
            Account.builder()
                .section(buildSection("0", false, false))
                .title("Account name")
                .name("<bold>Internet Saver Plus Issue 9<bold>")
                .build())
        .interest(
            Interest.builder()
                .section(buildSection("1", true, false))
                .title("What is the interest rate?")
                .summary(
                    "This account pays a <bold>variable<bold> tiered rate of interest <bold>annually<bold>:")
                .tiers(
                    Arrays.asList(
                        Tiers.builder()
                            .header("Balances from £1.00 - £999.99")
                            .tax("<bold>0.40%<bold> Gross p.a.")
                            .interest("<bold>0.40%<bold> AER")
                            .build()
                            .toBuilder()
                            .build(),
                        Tiers.builder()
                            .header("Balances from £1,000.00 - £9,999.99")
                            .tax("<bold>0.43%<bold> Gross p.a.")
                            .interest("<bold>0.43%<bold> AER")
                            .build()
                            .toBuilder()
                            .build(),
                        Tiers.builder()
                            .header("Balances from £10,000.00 - £49,999.99")
                            .tax("<bold>0.45%<bold> Gross p.a.")
                            .interest("<bold>0.45%<bold> AER")
                            .build()
                            .toBuilder()
                            .build(),
                        Tiers.builder()
                            .header("Balances from £50,000.00+")
                            .tax("<bold>0.50%<bold> Gross p.a.")
                            .interest("<bold>0.50%<bold> AER")
                            .build()
                            .toBuilder()
                            .build()))
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "The rates we offer in the different tiers can vary and sometimes might be the same.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Whether you need to pay tax is dependent on your own personal circumstances and so may be subject to change in the future.")
                            .build(),
                        Content.builder().format(FORMAT_HEADER).text("Payment of interest").build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text("Interest is calculated daily on cleared balances")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "The rate of interest on this account is tiered. You earn one rate of interest based on the tier your balance falls in.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Annual interest is paid on 31 March. It can be paid into the Internet Saver Plus Issue 9 account, another Yorkshire Building Society account or another building society or bank account.")
                            .build()))
                .help(
                    Arrays.asList(
                        Help.builder()
                            .header("What tax do I pay?")
                            .text(
                                "Interest is paid gross i.e. without tax being taken off on all our savings accounts - ISA accounts pay interest tax-free.")
                            .section(buildSection("?", true, false))
                            .build(),
                        Help.builder()
                            .header("What does 'Tiered' mean?")
                            .text(
                                "Tiered pays interest at different rates as the account balance increases or decreases")
                            .section(buildSection("?", true, false))
                            .build(),
                        Help.builder()
                            .header("What does 'AER' mean?")
                            .text(
                                "AER stands for the Annual Equivalent Rate and shows you what the interest rate would be if interest was paid and added each year. This will enable you to compare more easily the return you can expect from your savings over time.")
                            .section(buildSection("?", true, false))
                            .build(),
                        Help.builder()
                            .header("What does 'Variable' mean?")
                            .text(
                                "Variable rate of interest means that the interest rate payable on your account can change and can move both up and down.")
                            .section(buildSection("?", true, false))
                            .build()))
                .build())
        .interestRateChanges(
            InterestRateChanges.builder()
                .section(buildSection("2", true, true))
                .title("Can Yorkshire Building Society change the interest rate?")
                .content(
                    Arrays.asList(
                        Content.builder().format(FORMAT_TEXT).text("<bold>Yes<bold>").build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "We can make changes to the interest rate on this account for particular reasons. <link>General Terms and Conditions<link> 7 and 8 set out those reasons. Term 11 tells you how we will notify you of the changes.")
                            .link(
                                "https://www.ybs.co.uk/productdata/YBM0617_Inline_General_TandCs.pdf")
                            .build()))
                .build())
        .projections(
            Projections.builder()
                .section(buildSection("3", true, true))
                .title(
                    "What would be the estimated balance after 12 months based on a range of deposits?")
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "If you deposit £500, after 12 months your balance would be £502.00")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "If you deposit £1,000, after 12 months your balance would be £1,004.30")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "If you deposit £10,000, after 12 months your balance would be £10,045.00")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "If you deposit £50,000, after 12 months your balance would be £50,250.00")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "We have worked this out assuming a deposit is made on account opening, no further deposits or withdrawals are made throughout the 12 months, the interest earned is added to the account and no changes made to the current interest rate.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "This projection is provided for illustrative purposes only and does not take into account your individual circumstances.")
                            .build()))
                .build())
        .manageAccount(
            ManageAccount.builder()
                .section(buildSection("4", true, true))
                .title("How do I open and manage my account?")
                .content(
                    Arrays.asList(
                        Content.builder().format(FORMAT_HEADER).text("Eligibility").build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "You have to be at least 16 years old. You must be a UK resident for tax purposes, or be a qualifying Crown employee or married to, or in a civil partnership with a qualified Crown employee. The account can be held on your own or jointly with someone else.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_HEADER)
                            .text("Account opening and management")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Accounts can be opened with a minimum of £1 online at ybs.co.uk.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "The account can be managed online. You will be able to check your balance, interest rate, make and view transactions on your account online whenever you wish.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text("The maximum balance is £500,000.")
                            .build(),
                        Content.builder().format(FORMAT_HEADER).text("Account switching").build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "If you currently have an existing Yorkshire Building Society account it may be possible to transfer to this product, subject to meeting eligibility criteria. Please check with us to see whether this is possible.")
                            .build()))
                .build())
        .withdrawals(
            Withdrawals.builder()
                .section(buildSection("5", true, true))
                .title("Can I withdraw money?")
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "The Internet Saver Plus Issue 9 account allows unlimited instant withdrawals, <link>subject to daily withdrawal limits<link> without loss of interest. If you make a withdrawal that reduces your balance to a lower interest rate tier we will not notify you of this.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Please be aware if a withdrawal is made from the account by CHAPS a charge of £23.50 will be incurred. Proof of name ID will be required.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "For security reasons, online withdrawals are not available for the first 14 days after your account has been opened. After 14 days withdrawals can be made from your account at anytime on condition that there are sufficient cleared funds in your account and that you maintain the minimum balance of £1.")
                            .build()))
                .build())
        .additionalInformation(
            AdditionalInformation.builder()
                .section(buildSection("6", true, true))
                .title("Additional information")
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "We will generally communicate with you via email. It is very important that you notify us if your email address changes.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "You can change your contact details (postal address, email and telephone) when you are logged in. To change your name you will need to write, enclosing proof of the change, to Savings Service, Yorkshire Building Society, Yorkshire House, Bradford, West Yorkshire, BD5 8LJ.")
                            .build()))
                .build())
        .prerequisites(
            Prerequisites.builder()
                .section(buildSection("7", false, false))
                .title("Before you apply")
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "Please take time to review the following documents before you apply.")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text("Product Terms")
                            .link("https://www.ybs.co.uk/productdata/Factsheet-YB681429W.pdf")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text("General Terms and Conditions")
                            .link(
                                "https://www.ybs.co.uk/productdata/YBM0617_Inline_General_TandCs.pdf")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text("FSCS Information Sheet")
                            .link("https://www.ybs.co.uk/productdata/FSCS.pdf")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text("Charges and Fees")
                            .link("https://www.ybs.co.uk/productdata/Charges_and_Fees.pdf")
                            .build(),
                        Content.builder()
                            .format(FORMAT_LINK)
                            .text(
                                "When you apply for this account with us, you'll need to <link>verify your identity and address<link>.")
                            .link("https://www.ybs.co.uk/help/verifying-your-identity.html")
                            .build()))
                .build())
        .apply(
            Apply.builder()
                .section(buildSection("8", false, false))
                .title(TITLE_APPLY)
                .content(
                    Arrays.asList(
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text("Complete our simple, straightforward application form")
                            .build(),
                        Content.builder().format("BUTTON").text(TITLE_APPLY).build(),
                        Content.builder()
                            .format(FORMAT_TEXT)
                            .text(
                                "If you feel you need additional support before applying for this account, please call us")
                            .build(),
                        Content.builder().format(FORMAT_TEXT).text("0345 1200 100").build(),
                        Content.builder().format(FORMAT_TEXT).text("9am - 5pm Mon-Fri").build(),
                        Content.builder().format(FORMAT_TEXT).text("9am - 1pm Sat").build()))
                .build())
        .build();
  }
}
