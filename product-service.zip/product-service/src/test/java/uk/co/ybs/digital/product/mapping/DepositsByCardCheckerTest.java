package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;
import static uk.co.ybs.digital.product.model.AvailableProductRule.NOTICE_DAYS_FOR_WITHDRAWALS;
import static uk.co.ybs.digital.product.model.AvailableProductRule.STOP_DEPOSITS_EXTERNAL;
import static uk.co.ybs.digital.product.model.AvailableProductRule.WEB_TRANSACTIONS;

import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;

class DepositsByCardCheckerTest {

  private final DepositsByCardChecker testSubject = new DepositsByCardChecker();

  @ParameterizedTest
  @MethodSource("productRulesAllowDepositByCard")
  void
      depositsByCardShouldBeSupportedWhenWebTransactionsAllowedAndNoticeIsNotNeededForWithdrawalsAndReceiptsNotStopped(
          final ActiveProductRules activeProductRules) {

    final boolean supported = testSubject.isSupported(activeProductRules);

    assertThat(supported, is(true));
  }

  private static Stream<Arguments> productRulesAllowDepositByCard() {
    final ActiveProductRules webTransactionsYesWithdrawalNoticeAbsentStopReceiptsAbsent =
        createActiveProductRules(TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"));

    final ActiveProductRules webTransactionsYesWithdrawalNoticeAbsentStopReceiptsNo =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));

    final ActiveProductRules webTransactionsYesWithdrawalNoticeZeroStopReceiptsAbsent =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L));

    final ActiveProductRules webTransactionsYesWithdrawalNoticeZeroStopReceiptsNo =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));

    return Stream.of(
        Arguments.of(webTransactionsYesWithdrawalNoticeAbsentStopReceiptsAbsent),
        Arguments.of(webTransactionsYesWithdrawalNoticeAbsentStopReceiptsNo),
        Arguments.of(webTransactionsYesWithdrawalNoticeZeroStopReceiptsAbsent),
        Arguments.of(webTransactionsYesWithdrawalNoticeZeroStopReceiptsNo));
  }

  @ParameterizedTest
  @MethodSource("productRulesWebTransactionsNotAllowed")
  void depositsByCardShouldNotBeSupportedWhenWebTransactionsNotAllowed(
      final ActiveProductRules activeProductRules) {

    final boolean supported = testSubject.isSupported(activeProductRules);

    assertThat(supported, is(false));
  }

  private static Stream<Arguments> productRulesWebTransactionsNotAllowed() {

    final ActiveProductRules webTransactionsAbsentWithdrawalNoticeAbsentStopReceiptsAbsent =
        createActiveProductRules();
    final ActiveProductRules webTransactionsAbsentWithdrawalNoticeAbsentStopReceiptsNo =
        createActiveProductRules(TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));
    final ActiveProductRules webTransactionsAbsentWithdrawalNoticeAbsentStopReceiptsYes =
        createActiveProductRules(TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));

    final ActiveProductRules webTransactionsAbsentWithdrawalNoticeZeroStopReceiptsAbsent =
        createActiveProductRules(TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L));
    final ActiveProductRules webTransactionsAbsentWithdrawalNoticeZeroStopReceiptsNo =
        createActiveProductRules(
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));
    final ActiveProductRules webTransactionsAbsentWithdrawalNoticeZeroStopReceiptsYes =
        createActiveProductRules(
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));

    final ActiveProductRules
        webTransactionsAbsentWithdrawalNoticeGreaterThanZeroStopReceiptsAbsent =
            createActiveProductRules(
                TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L));
    final ActiveProductRules webTransactionsAbsentWithdrawalNoticeGreaterThanZeroStopReceiptsNo =
        createActiveProductRules(
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));
    final ActiveProductRules webTransactionsAbsentWithdrawalNoticeGreaterThanZeroStopReceiptsYes =
        createActiveProductRules(
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));

    final ActiveProductRules webTransactionsNoWithdrawalNoticeAbsentStopReceiptsAbsent =
        createActiveProductRules(TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"));
    final ActiveProductRules webTransactionsNoWithdrawalNoticeAbsentStopReceiptsNo =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));
    final ActiveProductRules webTransactionsNoWithdrawalNoticeAbsentStopReceiptsYes =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));

    final ActiveProductRules webTransactionsNoWithdrawalNoticeZeroStopReceiptsAbsent =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L));
    final ActiveProductRules webTransactionsNoWithdrawalNoticeZeroStopReceiptsNo =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));
    final ActiveProductRules webTransactionsNoWithdrawalNoticeZeroStopReceiptsYes =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));

    final ActiveProductRules webTransactionsNoWithdrawalNoticeGreaterThanZeroStopReceiptsAbsent =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L));
    final ActiveProductRules webTransactionsNoWithdrawalNoticeGreaterThanZeroStopReceiptsNo =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));
    final ActiveProductRules webTransactionsNoWithdrawalNoticeGreaterThanZeroStopReceiptsYes =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));

    return Stream.of(
        Arguments.of(webTransactionsAbsentWithdrawalNoticeAbsentStopReceiptsAbsent),
        Arguments.of(webTransactionsAbsentWithdrawalNoticeAbsentStopReceiptsNo),
        Arguments.of(webTransactionsAbsentWithdrawalNoticeAbsentStopReceiptsYes),
        Arguments.of(webTransactionsAbsentWithdrawalNoticeZeroStopReceiptsAbsent),
        Arguments.of(webTransactionsAbsentWithdrawalNoticeZeroStopReceiptsNo),
        Arguments.of(webTransactionsAbsentWithdrawalNoticeZeroStopReceiptsYes),
        Arguments.of(webTransactionsAbsentWithdrawalNoticeGreaterThanZeroStopReceiptsAbsent),
        Arguments.of(webTransactionsAbsentWithdrawalNoticeGreaterThanZeroStopReceiptsNo),
        Arguments.of(webTransactionsAbsentWithdrawalNoticeGreaterThanZeroStopReceiptsYes),
        Arguments.of(webTransactionsNoWithdrawalNoticeAbsentStopReceiptsAbsent),
        Arguments.of(webTransactionsNoWithdrawalNoticeAbsentStopReceiptsNo),
        Arguments.of(webTransactionsNoWithdrawalNoticeAbsentStopReceiptsYes),
        Arguments.of(webTransactionsNoWithdrawalNoticeZeroStopReceiptsAbsent),
        Arguments.of(webTransactionsNoWithdrawalNoticeZeroStopReceiptsNo),
        Arguments.of(webTransactionsNoWithdrawalNoticeZeroStopReceiptsYes),
        Arguments.of(webTransactionsNoWithdrawalNoticeGreaterThanZeroStopReceiptsAbsent),
        Arguments.of(webTransactionsNoWithdrawalNoticeGreaterThanZeroStopReceiptsNo),
        Arguments.of(webTransactionsNoWithdrawalNoticeGreaterThanZeroStopReceiptsYes));
  }

  @ParameterizedTest
  @MethodSource("productRulesWebTransactionsAllowedButNoticeRequiredForWithdrawals")
  void depositsByCardShouldNotBeSupportedWhenNoticeRequiredForWithdrawals(
      final ActiveProductRules activeProductRules) {

    final boolean supported = testSubject.isSupported(activeProductRules);

    assertThat(supported, is(false));
  }

  private static Stream<Arguments>
      productRulesWebTransactionsAllowedButNoticeRequiredForWithdrawals() {

    final ActiveProductRules webTransactionsYesWithdrawalNoticeGreaterThanZeroStopReceiptsAbsent =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L));
    final ActiveProductRules webTransactionsYesWithdrawalNoticeGreaterThanZeroStopReceiptsNo =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "N"));
    final ActiveProductRules webTransactionsNoWithdrawalNoticeGreaterThanZeroStopReceiptsYes =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 30L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));

    return Stream.of(
        Arguments.of(webTransactionsYesWithdrawalNoticeGreaterThanZeroStopReceiptsAbsent),
        Arguments.of(webTransactionsYesWithdrawalNoticeGreaterThanZeroStopReceiptsNo),
        Arguments.of(webTransactionsNoWithdrawalNoticeGreaterThanZeroStopReceiptsYes));
  }

  @ParameterizedTest
  @MethodSource(
      "productRulesWebTransactionsAllowsNoticeNotRequiredForWithdrawalsButReceiptsStopped")
  void depositsByCardShouldNotBeSupportedWhenReceiptsStopped(
      final ActiveProductRules activeProductRules) {

    final boolean supported = testSubject.isSupported(activeProductRules);

    assertThat(supported, is(false));
  }

  private static Stream<Arguments>
      productRulesWebTransactionsAllowsNoticeNotRequiredForWithdrawalsButReceiptsStopped() {

    final ActiveProductRules webTransactionsYesWithdrawalNoticeAbsentStopReceiptsYes =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));
    final ActiveProductRules webTransactionsYesWithdrawalZeroStopReceiptsYes =
        createActiveProductRules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.longProductRule(NOTICE_DAYS_FOR_WITHDRAWALS, 0L),
            TestDataFactory.charProductRule(STOP_DEPOSITS_EXTERNAL, "Y"));

    return Stream.of(
        Arguments.of(webTransactionsYesWithdrawalNoticeAbsentStopReceiptsYes),
        Arguments.of(webTransactionsYesWithdrawalZeroStopReceiptsYes));
  }
}
