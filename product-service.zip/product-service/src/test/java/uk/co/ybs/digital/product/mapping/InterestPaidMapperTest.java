package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase;

class InterestPaidMapperTest {

  private static final String ANNUAL_PRODUCT_CODE = "123456789A";
  private static final String MONTHLY_PRODUCT_CODE = "123456789M";

  private final InterestPaidMapper testSubject = new InterestPaidMapper();

  @Test
  void shouldMapAnnualInterestWhenEndsInA() {
    final Product product = Product.builder().productIdentifier(ANNUAL_PRODUCT_CODE).build();

    final List<ProductDetailsResponseBase.Interest.InterestDestinationType> permittedDestinations =
        new ArrayList<>();

    final ProductDetailsResponseBase.Interest interest =
        ProductDetailsResponseBase.Interest.builder()
            .interestPaid(ProductDetailsResponseBase.Interest.InterestPaidType.ANNUALLY)
            .permittedInterestDestinations(permittedDestinations)
            .build();

    assertThat(testSubject.map(product), is(interest.getInterestPaid()));
  }

  @Test
  void shouldMapMonthlyInterestWhenEndsInM() {
    final Product product = Product.builder().productIdentifier(MONTHLY_PRODUCT_CODE).build();

    final List<ProductDetailsResponseBase.Interest.InterestDestinationType> permittedDestinations =
        new ArrayList<>();

    final ProductDetailsResponseBase.Interest interest =
        ProductDetailsResponseBase.Interest.builder()
            .interestPaid(ProductDetailsResponseBase.Interest.InterestPaidType.MONTHLY)
            .permittedInterestDestinations(permittedDestinations)
            .build();

    assertThat(testSubject.map(product), is(interest.getInterestPaid()));
  }
}
