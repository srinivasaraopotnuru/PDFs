package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.service.ProductCategoryType;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.Fact;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;

@ExtendWith(MockitoExtension.class)
public class ProductCategoryMapperTest {

  @Mock private ProductCategoryUrlMapper urlMapper;
  @Mock private ProductFilter productFilter;

  @InjectMocks private ProductCategoryMapper testSubject;

  @ParameterizedTest
  @EnumSource(ProductCategoryType.class)
  void shouldMapAllProductCategoryTypes(final ProductCategoryType categoryType) {

    final String url = String.format("%s.url", categoryType.getTitle());
    final List<Product> onlineProducts = Collections.singletonList(buildProduct());
    final List<WebSiteProduct> allProducts =
        Collections.singletonList(buildWebsiteProductAvailableOnline(true));
    final ProductCategory expected =
        ProductCategory.builder()
            .title(categoryType.getTitle())
            .subTitle(categoryType.getSubTitle())
            .description(categoryType.getDescription())
            .products(onlineProducts)
            .unavailableProducts(Collections.emptyList())
            .url(url)
            .offlineOnlyProductsAvailable(false)
            .build();

    when(urlMapper.map(categoryType)).thenReturn(url);

    final ProductCategory actual = testSubject.map(categoryType, onlineProducts, allProducts);

    assertThat(expected, is(actual));
  }

  @ParameterizedTest
  @CsvSource({"true", "false"})
  void shouldMapAvailableOfflineProducts(final boolean offlineAvailable) {

    final String url = "category url";
    final ProductCategoryType categoryType = ProductCategoryType.EASY_ACCESS;
    final List<Product> onlineProducts = Collections.singletonList(buildProduct());
    final WebSiteProduct websiteProduct = buildWebsiteProductAvailableOnline(offlineAvailable);
    final List<WebSiteProduct> allProducts = Collections.singletonList(websiteProduct);
    final ProductCategory expected =
        ProductCategory.builder()
            .title(categoryType.getTitle())
            .subTitle(categoryType.getSubTitle())
            .description(categoryType.getDescription())
            .products(onlineProducts)
            .unavailableProducts(Collections.emptyList())
            .url(url)
            .offlineOnlyProductsAvailable(offlineAvailable)
            .build();

    when(urlMapper.map(categoryType)).thenReturn(url);
    when(productFilter.isOfflineOnlyProduct(websiteProduct)).thenReturn(offlineAvailable);

    final ProductCategory actual = testSubject.map(categoryType, onlineProducts, allProducts);

    assertThat(expected, is(actual));
  }

  private static Product buildProduct() {
    return Product.builder()
        .interestFrequency(InterestFrequency.BIANNUAL)
        .facts(Collections.singletonList(Fact.builder().text("fact text").build()))
        .interestTiers(
            Collections.singletonList(
                InterestTier.builder()
                    .rate("interest rate")
                    .description("interest description")
                    .build()))
        .name("product name")
        .type(ProductType.BOND)
        .url("product url")
        .productCode("product code")
        .build();
  }

  private static WebSiteProduct buildWebsiteProductAvailableOnline(final boolean online) {
    return WebSiteProduct.builder().applyOnline(online ? "Yes" : "No").build();
  }
}
