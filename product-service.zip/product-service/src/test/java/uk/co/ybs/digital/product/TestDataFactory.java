package uk.co.ybs.digital.product;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.experimental.UtilityClass;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Applications;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Balance;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Deposits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestDestinationType;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestPaidType;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Isa;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Withdrawals;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.InterestPrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.IsaPrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.WithdrawalsPrivate;

@UtilityClass
public class TestDataFactory {

  private static final String DUMMY_CHAR_VALUE = "charValue";
  private static final BigDecimal DUMMY_MONEY_VALUE = new BigDecimal("50.00");
  private static final LocalDateTime DUMMY_DATE_VALUE = LocalDateTime.now();
  private static final long DUMMY_NUMBER_VALUE = 25L;

  public static ProductDetailsResponse createProductDetailsResponse() {
    final ProductDetailsResponse.ProductDetailsResponseBuilder<?, ?> builder =
        ProductDetailsResponse.builder();
    populateProductDetailsResponseBase(builder);
    return builder
        .withdrawals(
            Withdrawals.builder()
                .permittedOverWeb(true)
                .limits(
                    Withdrawals.WithdrawalLimits.builder()
                        .number(
                            PeriodLimits.<Long>builder()
                                .month(3L)
                                .year(40L)
                                .anniversaryYear(45L)
                                .taxYear(50L)
                                .productTerm(500L)
                                .build())
                        .build())
                .build())
        .interest(
            Interest.builder()
                .interestPaid(InterestPaidType.ANNUALLY)
                .permittedInterestDestinations(
                    Collections.singletonList(InterestDestinationType.selfCredit))
                .build())
        .isa(Isa.builder().flexible(true).build())
        .smartTiered(true)
        .build();
  }

  public static ProductDetailsResponsePrivate createProductDetailsPrivateResponse() {
    final ProductDetailsResponsePrivate.ProductDetailsResponsePrivateBuilder<?, ?> builder =
        ProductDetailsResponsePrivate.builder();
    populateProductDetailsResponseBase(builder);

    return builder
        .productSysId(123456L)
        .withdrawals(
            WithdrawalsPrivate.builder()
                .permittedOverWeb(true)
                .limits(
                    Withdrawals.WithdrawalLimits.builder()
                        .number(
                            PeriodLimits.<Long>builder()
                                .month(3L)
                                .year(40L)
                                .anniversaryYear(45L)
                                .taxYear(50L)
                                .productTerm(500L)
                                .build())
                        .build())
                .build())
        .interest(
            InterestPrivate.builder()
                .interestPaid(InterestPaidType.ANNUALLY)
                .permittedInterestDestinations(
                    Collections.singletonList(InterestDestinationType.selfCredit))
                .build())
        .isa(IsaPrivate.builder().flexible(true).isaYear(1).build())
        .smartTiered(false)
        .build();
  }

  @SuppressWarnings("PMD.UnusedPrivateMethod")
  private static void populateProductDetailsResponseBase(
      final ProductDetailsResponse.ProductDetailsResponseBaseBuilder<?, ?> builder) {
    builder
        .productIdentifier("ABCD1234")
        .productType("foo")
        .customerDescription("bar")
        .brandCode("YBS")
        .cardAvailable(false)
        .isKycRequired(true)
        .balance(
            Balance.builder().min(new BigDecimal("-20.00")).max(new BigDecimal("50.00")).build())
        .deposits(
            Deposits.builder()
                .permittedExternal(true)
                .permittedInternal(true)
                .limits(
                    Deposits.DepositLimits.builder()
                        .amount(
                            PeriodLimits.<BigDecimal>builder()
                                .month(new BigDecimal("70.00"))
                                .year(new BigDecimal("4000.00"))
                                .anniversaryYear(new BigDecimal("4500.00"))
                                .taxYear(new BigDecimal("5000.00"))
                                .productTerm(new BigDecimal("50000.00"))
                                .build())
                        .build())
                .build())
        .applications(
            Applications.builder()
                .accountNumberSuffix("12")
                .applicationsPermitted(true)
                .fatcaReportable(true)
                .maximumAge(75L)
                .minimumAge(16L)
                .maximumApplicants(2L)
                .nationalInsuranceNumberRequired(true)
                .build());
  }

  public static ActiveProductRules createActiveProductRules(final ProductRule... productRules) {
    return new ActiveProductRules(Arrays.asList(productRules));
  }

  public static ProductRule factoryProductRuleWithDates(
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final Product product,
      final AvailableProductRule availableProductRule) {
    return ProductRule.builder(product, availableProductRule, startDate)
        .endDate(endDate)
        .charValue(DUMMY_CHAR_VALUE)
        .moneyValue(DUMMY_MONEY_VALUE)
        .dateValue(DUMMY_DATE_VALUE)
        .numberValue(DUMMY_NUMBER_VALUE)
        .build();
  }

  public static ProductRule charProductRule(final String code, final String value) {
    return ProductRule.builder()
        .availableProductRule(
            AvailableProductRule.builder()
                .code(code)
                .valueType(AvailableProductRule.ValueType.CHAR)
                .build())
        .charValue(value)
        .build();
  }

  public static ProductRule longProductRule(final String code, final Long value) {
    return ProductRule.builder()
        .availableProductRule(
            AvailableProductRule.builder()
                .code(code)
                .valueType(AvailableProductRule.ValueType.NUMBER)
                .build())
        .numberValue(value)
        .build();
  }

  public static ProductRule moneyProductRule(final String code, final BigDecimal value) {
    return ProductRule.builder()
        .availableProductRule(
            AvailableProductRule.builder()
                .code(code)
                .valueType(AvailableProductRule.ValueType.MONEY)
                .build())
        .moneyValue(value)
        .build();
  }

  public static class ActiveProductRulesBuilder {
    private Map<String, ProductRule> productRulesMap = new HashMap<>();

    public ActiveProductRulesBuilder rules(final ProductRule... rules) {
      productRulesMap = collectToMap(rules);
      return this;
    }

    public ActiveProductRulesBuilder addRules(final ProductRule... rules) {
      productRulesMap.putAll(collectToMap(rules));
      return this;
    }

    public ActiveProductRulesBuilder removeRules(final String... ruleCodes) {
      productRulesMap.keySet().removeAll(Arrays.asList(ruleCodes));
      return this;
    }

    public ActiveProductRulesBuilder changeRule(final String code, final Object value) {
      final ProductRule newRule;
      if (value instanceof String) {
        newRule = charProductRule(code, (String) value);
      } else if (value instanceof Long) {
        newRule = longProductRule(code, (Long) value);
      } else if (value instanceof BigDecimal) {
        newRule = moneyProductRule(code, (BigDecimal) value);
      } else {
        return this;
      }
      productRulesMap.put(code, newRule);
      return this;
    }

    public ActiveProductRules build() {
      return new ActiveProductRules(new ArrayList<>(productRulesMap.values()));
    }

    public static ActiveProductRulesBuilder makeBuilder() {
      return new ActiveProductRulesBuilder();
    }

    private Map<String, ProductRule> collectToMap(final ProductRule[] rules) {
      return Arrays.stream(rules)
          .collect(
              Collectors.toMap(
                  productRule -> productRule.getAvailableProductRule().getCode(),
                  Function.identity()));
    }
  }
}
