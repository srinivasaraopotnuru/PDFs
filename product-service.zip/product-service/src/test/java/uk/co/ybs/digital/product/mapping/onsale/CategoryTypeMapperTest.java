package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import uk.co.ybs.digital.product.service.ProductCategoryType;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.NoValuesSource;

class CategoryTypeMapperTest {

  private static final String YES = "Yes";
  private static final String FIXED_INTEREST_TYPE = "Fixed";
  private static final String VARIABLE_INTEREST_TYPE = "Variable";
  private final CategoryTypeMapper testSubject = new CategoryTypeMapper();

  @ParameterizedTest
  @MethodSource("expectedCategories")
  void shouldMapCorrectCategories(
      final WebSiteProduct webSiteProduct, final ProductCategoryType expected) {
    final List<ProductCategoryType> mapped = testSubject.map(webSiteProduct);

    assertEquals(1, mapped.size());
    assertThat(mapped.get(0), is(expected));
  }

  private static Stream<Arguments> expectedCategories() {
    return Stream.of(
        // Easy Access
        Arguments.of(
            WebSiteProduct.builder().easyAccess(YES).build(), ProductCategoryType.EASY_ACCESS),
        // Bond
        Arguments.of(WebSiteProduct.builder().bond(YES).build(), ProductCategoryType.FIXED_BOND),
        // Variable Cash ISA
        Arguments.of(
            WebSiteProduct.builder().cashISA(YES).interestType(VARIABLE_INTEREST_TYPE).build(),
            ProductCategoryType.ISA_VARIABLE),
        // Fixed Cash ISA
        Arguments.of(
            WebSiteProduct.builder().cashISA(YES).interestType(FIXED_INTEREST_TYPE).build(),
            ProductCategoryType.ISA_FIXED),
        // Children's
        Arguments.of(
            WebSiteProduct.builder().childrens(YES).build(), ProductCategoryType.CHILDRENS),
        // Regular
        Arguments.of(
            WebSiteProduct.builder().regularSaver(YES).build(), ProductCategoryType.REGULAR));
  }

  @ParameterizedTest
  @MethodSource("expectedAllCategories")
  void shouldMapAllCategories(
      final WebSiteProduct webSiteProduct, final List<ProductCategoryType> expected) {
    final List<ProductCategoryType> mapped = testSubject.map(webSiteProduct);

    assertThat(mapped, is(expected));
  }

  private static Stream<Arguments> expectedAllCategories() {
    return Stream.of(
        // Variable
        Arguments.of(
            WebSiteProduct.builder()
                .easyAccess(YES)
                .bond(YES)
                .cashISA(YES)
                .childrens(YES)
                .regularSaver(YES)
                .interestType(VARIABLE_INTEREST_TYPE)
                .build(),
            Arrays.asList(
                ProductCategoryType.EASY_ACCESS,
                ProductCategoryType.FIXED_BOND,
                ProductCategoryType.ISA_VARIABLE,
                ProductCategoryType.CHILDRENS,
                ProductCategoryType.REGULAR)),
        // Fixed
        Arguments.of(
            WebSiteProduct.builder()
                .easyAccess(YES)
                .bond(YES)
                .cashISA(YES)
                .childrens(YES)
                .regularSaver(YES)
                .interestType(FIXED_INTEREST_TYPE)
                .build(),
            Arrays.asList(
                ProductCategoryType.EASY_ACCESS,
                ProductCategoryType.FIXED_BOND,
                ProductCategoryType.ISA_FIXED,
                ProductCategoryType.CHILDRENS,
                ProductCategoryType.REGULAR)));
  }

  @ParameterizedTest
  @NoValuesSource
  void mapShouldHandleNoValues(final String noValue) {
    final WebSiteProduct product =
        WebSiteProduct.builder()
            .easyAccess(noValue)
            .bond(noValue)
            .cashISA(noValue)
            .childrens(noValue)
            .regularSaver(noValue)
            .build();

    final List<ProductCategoryType> mapped = testSubject.map(product);

    assertThat(mapped, is(empty()));
  }

  @ParameterizedTest
  @NullSource
  @ValueSource(strings = {"", "other"})
  void mapShouldHandleUnexpectedInterestType(final String interestType) {
    final WebSiteProduct product =
        WebSiteProduct.builder().cashISA(YES).interestType(interestType).build();

    final List<ProductCategoryType> mapped = testSubject.map(product);

    assertThat(mapped, is(empty()));
  }
}
