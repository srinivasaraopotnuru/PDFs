package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Withdrawals;

public class WithdrawalsBuilderTest {

  private static final String CAN_I_WITHDRAW_MONEY_TITLE = "Can I withdraw money?";
  private WithdrawalsBuilder testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new WithdrawalsBuilder();
  }

  @MethodSource("dataSource")
  @ParameterizedTest
  public void testMapsSuccessfully(
      final WebSiteProduct webSiteProduct, final Withdrawals expected) {
    final Withdrawals result = testSubject.map(webSiteProduct);
    assertThat(result, is(expected));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> dataSource() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "Yes",
                "",
                "",
                "Limited Access Saver ISA",
                "Limited Access Saver ISA",
                "Yes",
                "Yes",
                "Yes",
                "Yes",
                "Yes",
                "Yes",
                "Yes",
                10,
                "Yes",
                "Long Term Saver ISA"),
            buildExpectedWhenMaturityProductAndTieredProductAndWithdrawalsPermittedAndCashIsaAndManageOnlineAndWithdrawalDaysMoreThan1AndAccountNameLimitedAccessSaverISAAndMaturesIntoProductValid()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "Yes",
                "",
                "",
                "Lifetime ISA",
                "Lifetime ISA",
                "No",
                "No",
                "Yes",
                "No",
                "Yes",
                "Yes",
                "No",
                0,
                "No",
                null),
            buildExpectedWhenNotAMaturityProductAndNotATieredProductAndWithdrawalsNotPermittedAndNotACashIsaAnd0WithdrawalDaysAndAccountAndMaturesIntoProductNull()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "Yes",
                "",
                "",
                "Cash ISA",
                "Cash ISA",
                "Yes",
                "No",
                "Yes",
                "No",
                "Yes",
                "Yes",
                "No",
                0,
                "No",
                null),
            buildExpectedWhenNotAMaturityProductAndNotATieredProductAndWithdrawalsNotPermittedAndIsACashIsaAndMaturesIntoProductNull()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "Yes",
                "",
                "",
                "Lifetime ISA",
                "Lifetime ISA",
                "",
                "Yes",
                "Yes",
                "",
                "Yes",
                "Yes",
                "Yes",
                null,
                "",
                null),
            buildExpectedWhenMaturityProductAndNotTieredProductAndWithdrawalsPermittedAndWithdrawalDaysIsNullAndMaturesIntoProductInValid()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "Yes",
                "",
                "",
                "1 Year Limited Access Saver ISA",
                "1 Year Limited Access Saver ISA",
                "No",
                "No",
                "Yes",
                "No",
                "Yes",
                "Yes",
                "Yes",
                2,
                "No",
                null),
            buildExpectedWhenNotAMaturityProductAndNotATieredProductAndWithdrawalsPermittedAndTaxFreeAnd2WithdrawalDaysAndAccountAndMaturesIntoProductNull()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "No",
                "",
                "",
                "Annual Access Account ISA",
                "Help to Buy: ISA",
                "No",
                "No",
                "Yes",
                "No",
                "Yes",
                "Yes",
                "Yes",
                null,
                "Yes",
                ""),
            buildExpectedWhenNotAMaturityProductAndNotATieredProductAndWithdrawalsPermittedAndNotTaxFreeAnd2WithdrawalDaysNullAndAccountAndMaturesIntoProductNull()));
  }

  private static Withdrawals
      buildExpectedWhenMaturityProductAndTieredProductAndWithdrawalsPermittedAndCashIsaAndManageOnlineAndWithdrawalDaysMoreThan1AndAccountNameLimitedAccessSaverISAAndMaturesIntoProductValid() {
    return Withdrawals.builder()
        .section(buildSection("5", true, true))
        .title(CAN_I_WITHDRAW_MONEY_TITLE)
        .content(buildContent1())
        .build();
  }

  private static Withdrawals
      buildExpectedWhenNotAMaturityProductAndNotATieredProductAndWithdrawalsNotPermittedAndNotACashIsaAnd0WithdrawalDaysAndAccountAndMaturesIntoProductNull() {
    return Withdrawals.builder()
        .section(buildSection("5", true, true))
        .title(CAN_I_WITHDRAW_MONEY_TITLE)
        .content(buildContent2())
        .build();
  }

  private static Withdrawals
      buildExpectedWhenMaturityProductAndNotTieredProductAndWithdrawalsPermittedAndWithdrawalDaysIsNullAndMaturesIntoProductInValid() {
    return Withdrawals.builder()
        .section(buildSection("5", true, true))
        .title(CAN_I_WITHDRAW_MONEY_TITLE)
        .content(buildContent3())
        .build();
  }

  private static Withdrawals
      buildExpectedWhenNotAMaturityProductAndNotATieredProductAndWithdrawalsNotPermittedAndIsACashIsaAndMaturesIntoProductNull() {
    return Withdrawals.builder()
        .section(buildSection("5", true, true))
        .title(CAN_I_WITHDRAW_MONEY_TITLE)
        .content(buildContent4())
        .build();
  }

  private static Withdrawals
      buildExpectedWhenNotAMaturityProductAndNotATieredProductAndWithdrawalsPermittedAndTaxFreeAnd2WithdrawalDaysAndAccountAndMaturesIntoProductNull() {
    return Withdrawals.builder()
        .section(buildSection("5", true, true))
        .title(CAN_I_WITHDRAW_MONEY_TITLE)
        .content(buildContent5())
        .build();
  }

  private static Withdrawals
      buildExpectedWhenNotAMaturityProductAndNotATieredProductAndWithdrawalsPermittedAndNotTaxFreeAnd2WithdrawalDaysNullAndAccountAndMaturesIntoProductNull() {
    return Withdrawals.builder()
        .section(buildSection("5", true, true))
        .title(CAN_I_WITHDRAW_MONEY_TITLE)
        .content(buildContent6())
        .build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static List<Content> buildContent1() {
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The Limited Access Saver ISA account allows withdrawals from your account on one day per account year, based on anniversary of account opening. You may also close your account at any time even if you have used your withdrawal day, without loss of interest. Please remember that if you close your account without transferring directly into another ISA you will lose the tax-free status of your savings.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Flexibility means that savings withdrawn from this Cash ISA can be replaced in the same tax year without counting towards your annual ISA allowance. Please note that the tax year runs from 6 April to 5 April the following year.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Please be aware if a withdrawal is made from the account by CHAPS a charge of £23.50 will be incurred. Proof of name ID will be required.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "For security reasons, online withdrawals are not available for the first 14 days after your account has been opened. After 14 days withdrawals can be made from your account at anytime on condition that there are sufficient cleared funds in your account and that you maintain the minimum balance of £1.")
            .build();

    final Content item5 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Maturity").build();

    final Content item6 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "On maturity your balance will be automatically transferred into an Long Term Saver ISA. You may have the option to transfer the balance into another Fixed Rate eISA without the need to reapply.")
            .build();

    return Arrays.asList(item1, item2, item3, item4, item5, item6);
  }

  private static List<Content> buildContent2() {

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Flexibility means that savings withdrawn from this Cash ISA can be replaced in the same tax year without counting towards your annual ISA allowance. Please note that the tax year runs from 6 April to 5 April the following year.")
            .build();

    return Collections.singletonList(item2);
  }

  private static List<Content> buildContent3() {

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The Lifetime ISA account allows unlimited withdrawals, <link>subject to daily withdrawal limits<link>, without loss of interest.")
            .link("https://www.ybs.co.uk/help/payment-guidance/payments-from-my-account.html")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Flexibility means that savings withdrawn from this Cash ISA can be replaced in the same tax year without counting towards your annual ISA allowance. Please note that the tax year runs from 6 April to 5 April the following year.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Please be aware if a withdrawal is made from the account by CHAPS a charge of £23.50 will be incurred. Proof of name ID will be required.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "For security reasons, online withdrawals are not available for the first 14 days after your account has been opened. After 14 days withdrawals can be made from your account at anytime on condition that there are sufficient cleared funds in your account and that you maintain the minimum balance of £1.")
            .build();

    return Arrays.asList(item1, item2, item3, item4);
  }

  private static List<Content> buildContent4() {

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Withdrawals are not permitted during the term other than circumstances covered under the Savings Pledge 2021 for account holder(s) or their immediate family members - critical or terminal illness, death, redundancy, nursing home or elderly care costs, divorce or court order. All withdrawals will result in loss of tax free status. Closure is permitted during the term subject to an amount equivalent to 2 days’ loss of interest on the closing balance. Any loss of interest will be offset against any accrued interest not yet paid. If there is insufficient accrued interest outstanding the charge will be deducted from the account balance prior to closure. Closure for the circumstances detailed above under the Savings Pledge 2021 will not incur a loss of interest on the closing balance. Any early closure (except for transfers to another ISA) will result in loss of tax free status.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Flexibility means that savings withdrawn from this Cash ISA can be replaced in the same tax year without counting towards your annual ISA allowance. Please note that the tax year runs from 6 April to 5 April the following year.")
            .build();

    return Arrays.asList(item1, item2);
  }

  private static List<Content> buildContent5() {

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The 1 Year Limited Access Saver ISA account allows you to withdraw from your account on 2 days per account year, based on the anniversary of the account opening date.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "You can close your account at any time even if you have used your withdrawal day without loss of interest. Please remember that if you close your account without transferring directly into another ISA you will lose the tax-free status of your savings.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Flexibility means that savings withdrawn from this Cash ISA can be replaced in the same tax year without counting towards your annual ISA allowance. Please note that the tax year runs from 6 April to 5 April the following year.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Please be aware if a withdrawal is made from the account by CHAPS a charge of £23.50 will be incurred. Proof of name ID will be required.")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "For security reasons, online withdrawals are not available for the first 14 days after your account has been opened. After 14 days withdrawals can be made from your account at anytime on condition that there are sufficient cleared funds in your account and that you maintain the minimum balance of £1.")
            .build();

    return Arrays.asList(item1, item2, item3, item4, item5);
  }

  private static List<Content> buildContent6() {

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The Help to Buy: ISA account allows unlimited instant withdrawals, <link>subject to daily withdrawal limits<link> without loss of interest. If you make a withdrawal that reduces your balance to a lower interest rate tier we will not notify you of this.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Please note withdrawals and closure will result in the loss of your tax-free status, other than transfers to another ISA. Any withdrawals made will not qualify for the government bonus. This is not a flexible ISA so is subject to subscription limits.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Flexibility means that savings withdrawn from this Cash ISA can be replaced in the same tax year without counting towards your annual ISA allowance. Please note that the tax year runs from 6 April to 5 April the following year.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Please be aware if a withdrawal is made from the account by CHAPS a charge of £23.50 will be incurred. Proof of name ID will be required.")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "For security reasons, online withdrawals are not available for the first 14 days after your account has been opened. After 14 days withdrawals can be made from your account at anytime on condition that there are sufficient cleared funds in your account and that you maintain the minimum balance of £1.")
            .build();

    return Arrays.asList(item1, item2, item3, item4, item5);
  }
}
