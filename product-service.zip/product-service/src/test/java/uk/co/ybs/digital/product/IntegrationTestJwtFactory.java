package uk.co.ybs.digital.product;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.security.Key;
import java.time.Duration;
import java.time.Instant;
import java.time.Period;
import java.util.Date;
import java.util.UUID;
import lombok.experimental.UtilityClass;

@UtilityClass
public class IntegrationTestJwtFactory {

  public static String createJwtWithScope(final String scope, final Key signingKey) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setSubject("my-subject")
        .setAudience("DIGITAL_API")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .claim("scope", scope)
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .signWith(SignatureAlgorithm.RS256, signingKey)
        .compact();
  }

  public static String createSavingsAppJwtWithSessionId(
      final String sessionId, final Key signingKey) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setSubject("my-subject")
        .setAudience("DIGITAL_API")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .claim("scope", "ACCOUNT_READ")
        .claim("sid", sessionId)
        .claim("channel", "SAPP")
        .claim("sub_type", "customer")
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .signWith(SignatureAlgorithm.RS256, signingKey)
        .compact();
  }

  public static String createSavingsAppJwtWithoutSessionId(final Key signingKey) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setSubject("my-subject")
        .setAudience("DIGITAL_API")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .claim("scope", "ACCOUNT_READ")
        .claim("channel", "SAPP")
        .claim("sub_type", "customer")
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .signWith(SignatureAlgorithm.RS256, signingKey)
        .compact();
  }
}
