package uk.co.ybs.digital.product.web.controller;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.request.RequestPostProcessor;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.exception.MissingProductRulesException;
import uk.co.ybs.digital.product.exception.NoProductForIdentifierException;
import uk.co.ybs.digital.product.exception.ProductNotSupportedException;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;
import uk.co.ybs.digital.product.service.OnSaleProductService;
import uk.co.ybs.digital.product.service.ProductCategoryType;
import uk.co.ybs.digital.product.service.ProductDetailsService;
import uk.co.ybs.digital.product.service.ProductReinvestmentService;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.FilterErrorResponseFactory;
import uk.co.ybs.digital.product.web.dto.AvailableProductDetails;
import uk.co.ybs.digital.product.web.dto.CustomerAccountDetails;
import uk.co.ybs.digital.product.web.dto.ErrorResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsPageResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsPageResponsePrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ProductSummary;
import uk.co.ybs.digital.product.web.dto.reinvestment.ProductReinvestmentResponse;
import uk.co.ybs.digital.product.web.dto.reinvestment.ReinvestmentProduct;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest({ProductController.class, ProductControllerPrivate.class})
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter
  RequestVerificationSecurityAutoConfiguration.class,
  FilterErrorResponseFactory.class, // Spring Security
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class // Metrics
})
@ActiveProfiles({"test", "text-logging"})
class ProductControllerTest {

  private static final String PRODUCT_IDENTIFIERS_PARAM = "productIdentifiers";
  private static final String SORT_PARAM = "sort";
  private static final String PRODUCT_IDENTIFIER = "ABCD1234";
  private static final String REINVESTMENT_PRODUCT_IDENTIFIER = "WXYZ4321";
  private static final String PRODUCT_ENDPOINT = "/product";
  private static final String PRODUCT_PRIVATE_ENDPOINT = "/private/product";
  private static final String PRODUCT_BY_ID_URI = "/%s";
  private static final String ON_SALE_PRODUCTS_ENDPOINT = "/on-sale-products";
  private static final String PRODUCT_SUMMARY_IDENTIFIER = "YB291415W";
  private static final String ON_SALE_PRODUCTS_PRIVATE_ENDPOINT = "/private/on-sale-products";
  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private static final String PATH_AVAILABLE_PRODUCTS_PRIVATE = "/private/available-products";
  private static final String REINVEST_PRODUCT_PRIVATE_ENDPOINT =
      "/private/product/%s/reinvestment-products";
  private static final String SCOPE_ACCOUNT_READ = "ACCOUNT_READ";
  private static final String SCOPE_PRODUCT_READ = "PRODUCT_READ";
  private static final String SCOPE_OTHER = "OTHER";
  private static final String UNAVAILABLE = "unavailable";
  private static final String SIZE_QUERY_PARAMETER = "size";
  private static final String RESOURCE_NODE_FOUND_CODE = "404 Not Found";
  private static final String RESOURCE_NOT_FOUND_MESSAGE = "Resource not found";
  private static final String RESOURCE_NOT_FOUND_ERROR_CODE = "Resource.NotFound";
  private static final String CONFLICT_MESSAGE = "Conflict";
  private static final String RULE_MISSING_CONFLICT_CODE = "409 Conflict";
  private static final String RULE_MISSING_ERROR_CODE = "Rule.Missing";
  private static final String RULE_MISSING_ERROR_MESSAGE = "Required product rule missing";
  private static final String BAD_REQUEST_CODE = "400 Bad Request";
  private static final String BAD_REQUEST_MESSAGE = "Bad Request";
  private static final String FIELD_INVALID_ERROR_CODE = "Field.Invalid";
  private static final String METHOD_NOT_ALLOWED_CODE = "405 Method Not Allowed";
  private static final String METHOD_NOT_ALLOWED_MESSAGE = "Method Not Allowed";
  private static final String UNSUPPORTED_METHOD_ERROR_CODE = "Unsupported.Method";
  private static final String UNSUPPORTED_METHOD_MESSAGE = "Unsupported method";
  private static final String UNAUTHORIZED_CODE = "401 Unauthorized";
  private static final String UNAUTHORIZED_MESSAGE = "Unauthorized";
  private static final String UNAUTHORIZED_ERROR_CODE = "Unauthorized";
  private static final String FORBIDDEN_CODE = "403 Forbidden";
  private static final String FORBIDDEN_MESSAGE = "Forbidden";
  private static final String ACCESS_DENIED_ERROR_CODE = "AccessDenied";
  private static final String ACCESS_DENIED_MESSAGE = "Access Denied";
  private static final String INTERNAL_SERVER_ERROR_CODE = "500 Internal Server Error";
  private static final String INTERNAL_SERVER_ERROR_MESSAGE = "Internal Server Error";
  private static final String UNEXPECTED_ERROR_CODE = "UnexpectedError";

  @MockBean private ProductDetailsService productDetailsService;
  @MockBean private ProductReinvestmentService productReinvestmentService;
  @MockBean private OnSaleProductService onSaleProductService;

  @MockBean private RequestSigningVerificationService requestSigningVerificationService;

  @Autowired private MockMvc mvc;

  @Autowired private ObjectMapper objectMapper;

  private UUID requestId;

  @BeforeEach
  void setUp() {
    requestId = UUID.randomUUID();

    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
  }

  @ParameterizedTest
  @CsvSource({
    PRODUCT_ENDPOINT + "," + SCOPE_ACCOUNT_READ,
    PRODUCT_PRIVATE_ENDPOINT + "," + SCOPE_ACCOUNT_READ,
    PRODUCT_ENDPOINT + "," + SCOPE_PRODUCT_READ,
    PRODUCT_PRIVATE_ENDPOINT + "," + SCOPE_PRODUCT_READ
  })
  void getProductShouldReturnProductDetailsWhenCalledWithValidScope(
      final String endpoint, final String scope) throws Exception {
    Object productDetailsResponse = TestDataFactory.createProductDetailsResponse();
    when(productDetailsService.getProductDetailsForIdentifier(PRODUCT_IDENTIFIER))
        .thenReturn((ProductDetailsResponse) productDetailsResponse);
    if (PRODUCT_PRIVATE_ENDPOINT.equals(endpoint)) {
      productDetailsResponse = TestDataFactory.createProductDetailsPrivateResponse();
      when(productDetailsService.getProductDetailsPrivateForIdentifier(PRODUCT_IDENTIFIER))
          .thenReturn((ProductDetailsResponsePrivate) productDetailsResponse);
    }

    mvc.perform(
            MockMvcRequestBuilders.get(
                    String.format(endpoint + PRODUCT_BY_ID_URI, PRODUCT_IDENTIFIER))
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithScope(scope))))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(productDetailsResponse)));
  }

  @Test
  void getProductSummaryShouldReturnProductSummaryWhenCalledWithValidScope() throws Exception {

    final ProductSummary expected = TestHelper.buildExpectedMappingForFixedISA();

    when(onSaleProductService.getProductSummary(PRODUCT_SUMMARY_IDENTIFIER, requestId))
        .thenReturn(expected);

    final Endpoint endpoint = Endpoint.GET_ON_SALE_PRODUCTS_SUMMARY;

    mvc.perform(MockMvcRequestBuilders.get(endpoint.getPath()).headers(standardHeaders()))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expected)));
  }

  @Test
  void getProductSummaryShouldReturn404WhenProductNotFound() throws Exception {

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(RESOURCE_NODE_FOUND_CODE)
            .message(RESOURCE_NOT_FOUND_MESSAGE)
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(RESOURCE_NOT_FOUND_ERROR_CODE)
                        .message(RESOURCE_NOT_FOUND_MESSAGE)
                        .build()))
            .build();

    when(onSaleProductService.getProductSummary(PRODUCT_SUMMARY_IDENTIFIER, requestId))
        .thenThrow(
            new NoProductForIdentifierException(
                "No product found for identifier: " + PRODUCT_SUMMARY_IDENTIFIER));

    final Endpoint endpoint = Endpoint.GET_ON_SALE_PRODUCTS_SUMMARY;

    mvc.perform(MockMvcRequestBuilders.get(endpoint.getPath()).headers(standardHeaders()))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void getProductSummaryShouldReturn400WhenProductNotSupported() throws Exception {

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(BAD_REQUEST_CODE)
            .message(BAD_REQUEST_MESSAGE)
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(FIELD_INVALID_ERROR_CODE)
                        .message("Product type not supported")
                        .build()))
            .build();

    when(onSaleProductService.getProductSummary(PRODUCT_SUMMARY_IDENTIFIER, requestId))
        .thenThrow(new ProductNotSupportedException("Product YB291415W has unsupported type BOND"));

    final Endpoint endpoint = Endpoint.GET_ON_SALE_PRODUCTS_SUMMARY;

    mvc.perform(MockMvcRequestBuilders.get(endpoint.getPath()).headers(standardHeaders()))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {PRODUCT_ENDPOINT, PRODUCT_PRIVATE_ENDPOINT})
  void getProductShouldReturnNotFoundErrorResponseWhenProductDoesNotExist(final String endpoint)
      throws Exception {
    final String invalidProductIdentifier = "invalidProductIdentifier";
    when(productDetailsService.getProductDetailsForIdentifier(invalidProductIdentifier))
        .thenThrow(new NoProductForIdentifierException("oops"));
    when(productDetailsService.getProductDetailsPrivateForIdentifier(invalidProductIdentifier))
        .thenThrow(new NoProductForIdentifierException("oops"));

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(RESOURCE_NODE_FOUND_CODE)
            .message(RESOURCE_NOT_FOUND_MESSAGE)
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(RESOURCE_NOT_FOUND_ERROR_CODE)
                        .message(RESOURCE_NOT_FOUND_MESSAGE)
                        .build()))
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(
                    String.format(endpoint + PRODUCT_BY_ID_URI, invalidProductIdentifier))
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {PRODUCT_ENDPOINT, PRODUCT_PRIVATE_ENDPOINT})
  void getProductShouldReturnBadRequestErrorResponseWhenProductIsNotAlphanumeric(
      final String endpoint) throws Exception {
    final ErrorResponse expectedErrorResponse =
        invalidRequestFieldInvalidResponse(
            "-- is not a valid productIdentifier; value must be alphanumeric");

    mvc.perform(
            MockMvcRequestBuilders.get(String.format(endpoint + PRODUCT_BY_ID_URI, "--"))
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));

    // It should not get as far as the service
    verifyNoMoreInteractions(productDetailsService);
  }

  @Test
  void getReinvestmentProductsShouldReturnOkWhenCalledWithValidScope() throws Exception {
    final Endpoint endpoint = Endpoint.PRIVATE_GET_REINVESTMENT_PRODUCTS;

    final ProductReinvestmentResponse productReinvestmentResponse =
        ProductReinvestmentResponse.builder()
            .reinvestmentProducts(
                Collections.singletonList(
                    ReinvestmentProduct.builder()
                        .productIdentifier(REINVESTMENT_PRODUCT_IDENTIFIER)
                        .build()))
            .build();

    when(productReinvestmentService.getReinvestmentProducts(PRODUCT_IDENTIFIER))
        .thenReturn(productReinvestmentResponse);

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isOk())
        .andExpect(content().json(objectMapper.writeValueAsString(productReinvestmentResponse)));
  }

  @Test
  void getReinvestmentProductsShouldReturnNotFoundWhenProvidedProductIdentifierNotFound()
      throws Exception {
    final Endpoint endpoint = Endpoint.PRIVATE_GET_REINVESTMENT_PRODUCTS;

    doThrow(NoProductForIdentifierException.class)
        .when(productReinvestmentService)
        .getReinvestmentProducts(PRODUCT_IDENTIFIER);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(RESOURCE_NODE_FOUND_CODE)
            .message(RESOURCE_NOT_FOUND_MESSAGE)
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(RESOURCE_NOT_FOUND_ERROR_CODE)
                        .message(RESOURCE_NOT_FOUND_MESSAGE)
                        .build()))
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isNotFound())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void getReinvestmentProductsShouldReturnConflictWhenCurrentProductHasInvalidRules()
      throws Exception {
    final Endpoint endpoint = Endpoint.PRIVATE_GET_REINVESTMENT_PRODUCTS;

    doThrow(MissingProductRulesException.class)
        .when(productReinvestmentService)
        .getReinvestmentProducts(PRODUCT_IDENTIFIER);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(RULE_MISSING_CONFLICT_CODE)
            .message(CONFLICT_MESSAGE)
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(RULE_MISSING_ERROR_CODE)
                        .message(RULE_MISSING_ERROR_MESSAGE)
                        .build()))
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isConflict())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {SCOPE_ACCOUNT_READ, SCOPE_PRODUCT_READ})
  void searchProductDetailsShouldSearchForProductDetailsByProductIdentifiers(final String scope)
      throws Exception {
    final int pageNumber = 0;
    final int pageSize = 1;
    final long totalElements = 20;

    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER, "OTHER"))
            .build();
    final Pageable pageable = PageRequest.of(pageNumber, pageSize);

    final Page<ProductDetailsResponse> foundPage =
        new PageImpl<>(
            ImmutableList.of(TestDataFactory.createProductDetailsResponse()),
            pageable,
            totalElements);
    when(productDetailsService.searchProducts(searchCriteria, pageable)).thenReturn(foundPage);

    final ProductDetailsPageResponse expectedResponse =
        ProductDetailsPageResponse.builder().page(foundPage).build();

    mvc.perform(
            MockMvcRequestBuilders.get(PRODUCT_ENDPOINT)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithScope(scope)))
                .param(PRODUCT_IDENTIFIERS_PARAM, "ABCD1234,OTHER")
                .param(SIZE_QUERY_PARAMETER, String.valueOf(pageSize)))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)))
        .andReturn()
        .getResponse()
        .getContentAsString();
  }

  @ParameterizedTest
  @ValueSource(strings = {SCOPE_ACCOUNT_READ, SCOPE_PRODUCT_READ})
  void searchProductDetailsPrivateShouldSearchForProductDetailsByProductIdentifiers(
      final String scope) throws Exception {
    final int pageNumber = 0;
    final int pageSize = 1;
    final long totalElements = 20;

    final ProductSearchCriteria searchCriteria =
        ProductSearchCriteria.builder()
            .productIdentifiers(ImmutableSet.of(PRODUCT_IDENTIFIER, "OTHER"))
            .build();
    final Pageable pageable = PageRequest.of(pageNumber, pageSize);

    final Page<ProductDetailsResponsePrivate> foundPage =
        new PageImpl<>(
            ImmutableList.of(TestDataFactory.createProductDetailsPrivateResponse()),
            pageable,
            totalElements);
    when(productDetailsService.searchProductsPrivate(searchCriteria, pageable))
        .thenReturn(foundPage);

    final ProductDetailsPageResponsePrivate expectedResponse =
        ProductDetailsPageResponsePrivate.builder().page(foundPage).build();

    mvc.perform(
            MockMvcRequestBuilders.get(PRODUCT_PRIVATE_ENDPOINT)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithScope(scope)))
                .param(PRODUCT_IDENTIFIERS_PARAM, "ABCD1234,OTHER")
                .param(SIZE_QUERY_PARAMETER, String.valueOf(pageSize)))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)))
        .andReturn()
        .getResponse()
        .getContentAsString();
  }

  @Test
  void searchProductDetailsShouldSearchForProductDetailsWithDefaultPageSize() throws Exception {
    final int defaultPageNumber = 0;
    final int defaultPageSize = 20;
    final long totalElements = 0;

    final ProductSearchCriteria searchCriteria = emptySearchCriteria();
    final Pageable pageable = PageRequest.of(defaultPageNumber, defaultPageSize);

    final Page<ProductDetailsResponse> foundPage =
        new PageImpl<>(
            ImmutableList.of(TestDataFactory.createProductDetailsResponse()),
            pageable,
            totalElements);
    when(productDetailsService.searchProducts(any(), any())).thenReturn(foundPage);

    mvc.perform(
            MockMvcRequestBuilders.get(PRODUCT_ENDPOINT)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isOk());

    verify(productDetailsService).searchProducts(searchCriteria, pageable);
  }

  @Test
  void searchProductDetailsPrivateShouldSearchForProductDetailsWithDefaultPageSize()
      throws Exception {
    final int defaultPageNumber = 0;
    final int defaultPageSize = 20;
    final long totalElements = 0;

    final ProductSearchCriteria searchCriteria = emptySearchCriteria();
    final Pageable pageable = PageRequest.of(defaultPageNumber, defaultPageSize);

    final Page<ProductDetailsResponsePrivate> foundPage =
        new PageImpl<>(
            ImmutableList.of(TestDataFactory.createProductDetailsPrivateResponse()),
            pageable,
            totalElements);
    when(productDetailsService.searchProductsPrivate(any(), any())).thenReturn(foundPage);

    mvc.perform(
            MockMvcRequestBuilders.get(PRODUCT_PRIVATE_ENDPOINT)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isOk());

    verify(productDetailsService).searchProductsPrivate(searchCriteria, pageable);
  }

  @Test
  void searchProductDetailsShouldSearchForSortedProductDetails() throws Exception {
    final int defaultPageNumber = 0;
    final int defaultPageSize = 20;
    final long totalElements = 0;

    final ProductSearchCriteria searchCriteria = emptySearchCriteria();
    final Pageable pageable =
        PageRequest.of(defaultPageNumber, defaultPageSize, Direction.DESC, "productIdentifier");

    final Page<ProductDetailsResponse> foundPage =
        new PageImpl<>(Collections.emptyList(), pageable, totalElements);
    when(productDetailsService.searchProducts(any(), any())).thenReturn(foundPage);

    mvc.perform(
            MockMvcRequestBuilders.get(PRODUCT_ENDPOINT)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope()))
                .param(SORT_PARAM, "productIdentifier,DESC"))
        .andExpect(status().isOk());

    verify(productDetailsService).searchProducts(searchCriteria, pageable);
  }

  @Test
  void searchProductDetailsPrivateShouldSearchForSortedProductDetails() throws Exception {
    final int defaultPageNumber = 0;
    final int defaultPageSize = 20;
    final long totalElements = 0;

    final ProductSearchCriteria searchCriteria = emptySearchCriteria();
    final Pageable pageable =
        PageRequest.of(defaultPageNumber, defaultPageSize, Direction.DESC, "productIdentifier");

    final Page<ProductDetailsResponsePrivate> foundPage =
        new PageImpl<>(Collections.emptyList(), pageable, totalElements);
    when(productDetailsService.searchProductsPrivate(any(), any())).thenReturn(foundPage);

    mvc.perform(
            MockMvcRequestBuilders.get(PRODUCT_PRIVATE_ENDPOINT)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope()))
                .param(SORT_PARAM, "productIdentifier,DESC"))
        .andExpect(status().isOk());

    verify(productDetailsService).searchProductsPrivate(searchCriteria, pageable);
  }

  @Test
  void searchProductDetailsShouldSearchForPageOfProductDetails() throws Exception {
    final int pageNumber = 10;
    final int pageSize = 5;
    final long totalElements = 50;

    final ProductSearchCriteria searchCriteria = emptySearchCriteria();
    final Pageable pageable = PageRequest.of(pageNumber, pageSize);

    final Page<ProductDetailsResponse> foundPage =
        new PageImpl<>(Collections.emptyList(), pageable, totalElements);
    when(productDetailsService.searchProducts(any(), any())).thenReturn(foundPage);

    mvc.perform(
            MockMvcRequestBuilders.get(PRODUCT_ENDPOINT)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope()))
                .param("page", String.valueOf(pageNumber))
                .param(SIZE_QUERY_PARAMETER, String.valueOf(pageSize)))
        .andExpect(status().isOk());

    verify(productDetailsService).searchProducts(searchCriteria, pageable);
  }

  @Test
  void searchProductDetailsPrivateShouldSearchForPageOfProductDetails() throws Exception {
    final int pageNumber = 10;
    final int pageSize = 5;
    final long totalElements = 50;

    final ProductSearchCriteria searchCriteria = emptySearchCriteria();
    final Pageable pageable = PageRequest.of(pageNumber, pageSize);

    final Page<ProductDetailsResponsePrivate> foundPage =
        new PageImpl<>(Collections.emptyList(), pageable, totalElements);
    when(productDetailsService.searchProductsPrivate(any(), any())).thenReturn(foundPage);

    mvc.perform(
            MockMvcRequestBuilders.get(PRODUCT_PRIVATE_ENDPOINT)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope()))
                .param("page", String.valueOf(pageNumber))
                .param(SIZE_QUERY_PARAMETER, String.valueOf(pageSize)))
        .andExpect(status().isOk());

    verify(productDetailsService).searchProductsPrivate(searchCriteria, pageable);
  }

  @ParameterizedTest
  @ValueSource(strings = {PRODUCT_ENDPOINT, PRODUCT_PRIVATE_ENDPOINT})
  void searchProductDetailsShouldReturnBadRequestForInvalidSortProperty(final String endpoint)
      throws Exception {
    final ErrorResponse expectedErrorResponse =
        invalidRequestFieldInvalidResponse(
            "Invalid sort field.  Must match pattern: productIdentifier");

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope()))
                .param(SORT_PARAM, "customerDescription"))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));

    verify(productDetailsService, never()).searchProducts(any(), any());
  }

  @ParameterizedTest
  @ValueSource(strings = {PRODUCT_ENDPOINT, PRODUCT_PRIVATE_ENDPOINT})
  void searchProductDetailsShouldReturnBadRequestForEmptyProductIdentifierCriterion(
      final String endpoint) throws Exception {
    final ErrorResponse expectedErrorResponse =
        invalidRequestFieldInvalidResponse("Cannot search for zero productIdentifiers");

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope()))
                .param(PRODUCT_IDENTIFIERS_PARAM, ""))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));

    verify(productDetailsService, never()).searchProducts(any(), any());
  }

  @ParameterizedTest
  @ValueSource(strings = {PRODUCT_ENDPOINT, PRODUCT_PRIVATE_ENDPOINT})
  void searchProductDetailsShouldReturnBadRequestForInvalidProductIdentifiers(final String endpoint)
      throws Exception {
    final ErrorResponse expectedErrorResponse =
        invalidRequestFieldInvalidResponse(
            "' is not a valid productIdentifier; value must be alphanumeric");

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint)
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithValidScope()))
                .param(PRODUCT_IDENTIFIERS_PARAM, "'"))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));

    verify(productDetailsService, never()).searchProducts(any(), any());
  }

  @ParameterizedTest
  @CsvSource({ON_SALE_PRODUCTS_ENDPOINT, ON_SALE_PRODUCTS_PRIVATE_ENDPOINT})
  void getOnSaleProductsShouldReturnResult(final String endpoint) throws Exception {
    final List<ProductCategory> response =
        Arrays.asList(
            buildProductCategory(ProductCategoryType.EASY_ACCESS),
            buildProductCategory(ProductCategoryType.ISA_VARIABLE));

    when(onSaleProductService.getProducts(requestId)).thenReturn(response);

    mvc.perform(MockMvcRequestBuilders.get(endpoint).headers(standardHeaders()))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response)));
  }

  @ParameterizedTest
  @EnumSource
  void endpointShouldReturnBadRequestWhenRequestIdIsNotAUUID(final Endpoint endpoint)
      throws Exception {
    final String badRequestId = "not-a-uuid";

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .header(REQUEST_ID_HEADER, badRequestId)
                .accept(MediaType.APPLICATION_JSON)
                .with(getValidJwtRequestPostProcessor(endpoint)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.id", notNullValue()))
        .andExpect(jsonPath("$.code", is(BAD_REQUEST_CODE)))
        .andExpect(jsonPath("$.message", is(BAD_REQUEST_MESSAGE)))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(REQUEST_ID_HEADER)));

    verifyNoServiceInteractions();
  }

  @ParameterizedTest
  @EnumSource
  void endpointShouldReturnForbiddenWhenRequestSignatureInvalid(final Endpoint endpoint)
      throws Exception {
    final ErrorResponse expectedErrorResponse = invalidRequestSignatureErrorResponse();

    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(false);

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .headers(standardHeaders())
                .with(getValidJwtRequestPostProcessor(endpoint)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));

    verifyNoServiceInteractions();
  }

  @ParameterizedTest
  @EnumSource
  void endpointShouldReturnMethodNotAllowedWhenMethodNotAllowed(final Endpoint endpoint)
      throws Exception {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code(METHOD_NOT_ALLOWED_CODE)
            .id(requestId)
            .message(METHOD_NOT_ALLOWED_MESSAGE)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(UNSUPPORTED_METHOD_ERROR_CODE)
                    .message(UNSUPPORTED_METHOD_MESSAGE)
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.post(endpoint.getPath())
                .headers(standardHeaders())
                .with(getValidJwtRequestPostProcessor(endpoint)))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.GET.name())));

    verifyNoServiceInteractions();
  }

  @ParameterizedTest
  @EnumSource
  void endpointShouldReturnNotAcceptableErrorWhenAcceptNotJson(final Endpoint endpoint)
      throws Exception {
    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .header(REQUEST_ID_HEADER, requestId)
                .accept(MediaType.APPLICATION_XML)
                .with(getValidJwtRequestPostProcessor(endpoint)))
        .andExpect(status().isNotAcceptable())
        .andExpect(content().bytes(new byte[0]));

    verifyNoServiceInteractions();
  }

  @ParameterizedTest
  @EndpointsRequiringAccessTokenSource
  void endpointShouldReturnUnauthorizedWhenCalledWithoutJwt(final Endpoint endpoint)
      throws Exception {
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(UNAUTHORIZED_CODE)
            .message(UNAUTHORIZED_MESSAGE)
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(UNAUTHORIZED_ERROR_CODE)
                        .message(UNAUTHORIZED_MESSAGE)
                        .build()))
            .build();

    mvc.perform(MockMvcRequestBuilders.get(endpoint.getPath()).headers(standardHeaders()))
        .andExpect(status().isUnauthorized())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));

    verifyNoServiceInteractions();
  }

  @ParameterizedTest
  @EndpointsRequiringAccessTokenSource
  void endpointShouldReturnForbiddenWhenCalledWithoutValidScope(final Endpoint endpoint)
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(SCOPE_OTHER);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(FORBIDDEN_CODE)
            .message(FORBIDDEN_MESSAGE)
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ACCESS_DENIED_ERROR_CODE)
                        .message(ACCESS_DENIED_MESSAGE)
                        .build()))
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .headers(standardHeaders())
                .with(jwt().jwt(jwtWithScope)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));

    verifyNoServiceInteractions();
  }

  @ParameterizedTest
  @EnumSource
  void endpointShouldIncludeResponseBodyWhenUnexpectedSpringInternalExceptionThrown(
      final Endpoint endpoint) throws Exception {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(UNEXPECTED_ERROR_CODE)
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    stubServiceException(endpoint, new AsyncRequestTimeoutException());

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .headers(standardHeaders())
                .with(getValidJwtRequestPostProcessor(endpoint)))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @ParameterizedTest
  @EnumSource
  void endpointShouldReturnInternalServerErrorWhenUnexpectedExceptionOccurs(final Endpoint endpoint)
      throws Exception {
    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(INTERNAL_SERVER_ERROR_CODE)
            .message(INTERNAL_SERVER_ERROR_MESSAGE)
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(UNEXPECTED_ERROR_CODE)
                        .message(INTERNAL_SERVER_ERROR_MESSAGE)
                        .build()))
            .build();

    stubServiceException(endpoint, new RuntimeException("unexpected exception"));

    mvc.perform(
            MockMvcRequestBuilders.get(endpoint.getPath())
                .headers(standardHeaders())
                .with(getValidJwtRequestPostProcessor(endpoint)))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void testAvailableProducts(final String endPoint) throws Exception {
    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder().dateOfBirth("2011-11-01").countryCode("UK").build();

    final List<ProductCategory> response =
        Arrays.asList(
            buildProductCategory(ProductCategoryType.EASY_ACCESS),
            buildProductCategory(ProductCategoryType.ISA_VARIABLE));

    when(productDetailsService.getAvailableProducts(availableProductDetails, requestId))
        .thenReturn(response);
    final String json = objectMapper.writeValueAsString(availableProductDetails);

    mvc.perform(
            MockMvcRequestBuilders.post(endPoint)
                .headers(standardHeaders())
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response)));
  }

  @ParameterizedTest
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void testDuffProductsName(final String endPoint) throws Exception {
    final List<CustomerAccountDetails> accounts = new ArrayList<>();

    final CustomerAccountDetails duffAccount =
        CustomerAccountDetails.builder().productIdentifier("Foobar").build();
    accounts.add(duffAccount);
    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder()
            .dateOfBirth("2011-11-01")
            .countryCode("UK")
            .accounts(accounts)
            .build();

    final List<Product> unavailableProducts = new ArrayList<>();
    unavailableProducts.add(buildProduct("Foobar2", ProductType.SAVER));
    final List<ProductCategory> response = new ArrayList<>();

    response.add(
        ProductCategory.builder()
            .title(UNAVAILABLE)
            .url(UNAVAILABLE)
            .subTitle(UNAVAILABLE)
            .description(UNAVAILABLE)
            .products(Collections.emptyList())
            .offlineOnlyProductsAvailable(Boolean.FALSE)
            .unavailableProducts(unavailableProducts)
            .build());

    when(productDetailsService.getAvailableProducts(availableProductDetails, requestId))
        .thenReturn(response);
    final String json = objectMapper.writeValueAsString(availableProductDetails);

    mvc.perform(
            MockMvcRequestBuilders.post(endPoint)
                .headers(standardHeaders())
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response)));
  }

  @ParameterizedTest
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void testDuffProductsCount(final String endPoint) throws Exception {
    final List<CustomerAccountDetails> accounts = new ArrayList<>();
    final CustomerAccountDetails duffAccount =
        CustomerAccountDetails.builder().productIdentifier("Foobar").count(-1).build();
    accounts.add(duffAccount);
    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder()
            .dateOfBirth("2011-11-01")
            .countryCode("UK")
            .accounts(accounts)
            .build();

    final List<Product> unavailableProducts = new ArrayList<>();
    unavailableProducts.add(buildProduct("Foobar", ProductType.SAVER));
    final List<ProductCategory> response = new ArrayList<>();

    response.add(
        ProductCategory.builder()
            .title(UNAVAILABLE)
            .url(UNAVAILABLE)
            .subTitle(UNAVAILABLE)
            .description(UNAVAILABLE)
            .products(Collections.emptyList())
            .offlineOnlyProductsAvailable(Boolean.FALSE)
            .unavailableProducts(unavailableProducts)
            .build());

    when(productDetailsService.getAvailableProducts(availableProductDetails, requestId))
        .thenReturn(response);
    final String json = objectMapper.writeValueAsString(availableProductDetails);

    mvc.perform(
            MockMvcRequestBuilders.post(endPoint)
                .headers(standardHeaders())
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .with(jwt().jwt(jwtWithValidScope())))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response)));
  }

  @AllArgsConstructor
  @Getter
  private enum Endpoint {
    GET_PRODUCT(String.format(PRODUCT_ENDPOINT + PRODUCT_BY_ID_URI, PRODUCT_IDENTIFIER), true),
    PRIVATE_GET_PRODUCT(
        String.format(PRODUCT_PRIVATE_ENDPOINT + PRODUCT_BY_ID_URI, PRODUCT_IDENTIFIER), true),
    SEARCH_PRODUCT(PRODUCT_ENDPOINT + "?" + PRODUCT_IDENTIFIERS_PARAM + "=ABCD1234", true),
    GET_ON_SALE_PRODUCTS(ON_SALE_PRODUCTS_ENDPOINT, false),
    GET_ON_SALE_PRODUCTS_SUMMARY(
        String.format(ON_SALE_PRODUCTS_ENDPOINT + "/" + PRODUCT_SUMMARY_IDENTIFIER + "/summary"),
        false),
    PRIVATE_GET_ON_SALE_PRODUCTS(ON_SALE_PRODUCTS_PRIVATE_ENDPOINT, false),
    PRIVATE_GET_REINVESTMENT_PRODUCTS(
        String.format(REINVEST_PRODUCT_PRIVATE_ENDPOINT, PRODUCT_IDENTIFIER), true);

    private final String path;
    private final boolean requiresAccessToken;
  }

  @EnumSource(
      value = Endpoint.class,
      mode = EnumSource.Mode.EXCLUDE,
      names = {
        "GET_ON_SALE_PRODUCTS",
        "PRIVATE_GET_ON_SALE_PRODUCTS",
        "GET_ON_SALE_PRODUCTS_SUMMARY"
      })
  @Target(ElementType.METHOD)
  @Retention(RetentionPolicy.RUNTIME)
  private @interface EndpointsRequiringAccessTokenSource {}

  private void stubServiceException(final Endpoint endpoint, final Exception exception)
      throws Exception {
    switch (endpoint) {
      case GET_PRODUCT:
        when(productDetailsService.getProductDetailsForIdentifier(any())).thenThrow(exception);
        break;
      case PRIVATE_GET_PRODUCT:
        when(productDetailsService.getProductDetailsPrivateForIdentifier(any()))
            .thenThrow(exception);
        break;
      case SEARCH_PRODUCT:
        when(productDetailsService.searchProducts(any(), any())).thenThrow(exception);
        break;
      case GET_ON_SALE_PRODUCTS:
      case PRIVATE_GET_ON_SALE_PRODUCTS:
        when(onSaleProductService.getProducts(requestId)).thenThrow(exception);
        break;
      case GET_ON_SALE_PRODUCTS_SUMMARY:
        when(onSaleProductService.getProductSummary(any(), eq(requestId))).thenThrow(exception);
        break;
      case PRIVATE_GET_REINVESTMENT_PRODUCTS:
        when(productReinvestmentService.getReinvestmentProducts(any())).thenThrow(exception);
        break;
      default:
        throw new IllegalArgumentException("Unexpected endpoint: " + endpoint);
    }
  }

  private RequestPostProcessor getValidJwtRequestPostProcessor(final Endpoint endpoint) {
    if (endpoint.isRequiresAccessToken()) {
      return jwt().jwt(jwtWithValidScope());
    } else {
      return request -> request; // Processor with no side effect
    }
  }

  private void verifyNoServiceInteractions() {
    verifyNoInteractions(productDetailsService);
    verifyNoInteractions(onSaleProductService);
  }

  private HttpHeaders standardHeaders() {
    final HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.add(REQUEST_ID_HEADER, requestId.toString());
    httpHeaders.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    return httpHeaders;
  }

  private ErrorResponse invalidRequestSignatureErrorResponse() {
    return ErrorResponse.builder()
        .id(requestId)
        .code(FORBIDDEN_CODE)
        .message(FORBIDDEN_MESSAGE)
        .errors(
            Collections.singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message(ACCESS_DENIED_MESSAGE)
                    .build()))
        .build();
  }

  private ErrorResponse invalidRequestFieldInvalidResponse(final String fieldInvalidMessage) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(BAD_REQUEST_CODE)
        .message("Invalid value")
        .errors(
            Collections.singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR_CODE)
                    .message(fieldInvalidMessage)
                    .build()))
        .build();
  }

  private Jwt jwtWithValidScope() {
    return jwtWithScope(SCOPE_ACCOUNT_READ);
  }

  private Jwt jwtWithScope(final String scope) {
    return Jwt.withTokenValue("token")
        .header("kid", "key-id")
        .subject("the-subject")
        .claim("scope", scope)
        .build();
  }

  private ProductSearchCriteria emptySearchCriteria() {
    return ProductSearchCriteria.builder().build();
  }

  private ProductCategory buildProductCategory(final ProductCategoryType type) {
    return ProductCategory.builder()
        .title(type.getTitle())
        .subTitle(type.getSubTitle())
        .description(type.getDescription())
        .url("http://test.com")
        .offlineOnlyProductsAvailable(false)
        .products(Collections.emptyList())
        .build();
  }

  private Product buildProduct(final String name, final ProductType type) {
    return Product.builder()
        .name(name)
        .type(type)
        .url(name)
        .productCode(name)
        .interestTiers(Collections.emptyList())
        .interestFrequency(InterestFrequency.ANNUAL)
        .facts(Collections.emptyList())
        .build();
  }
}
