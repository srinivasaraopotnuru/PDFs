package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.model.InterestTier;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.Tier;

class InterestTiersMapperTest {

  private final InterestTiersMapper testSubject = new InterestTiersMapper();

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void mapShouldReturnMappedAndSortedTiers() {
    final Product product =
        Product.builder()
            .interestTier(
                InterestTier.builder()
                    .sysid(1L)
                    .interestRate(new BigDecimal("0.750"))
                    .rangeHigh(new BigDecimal("14999.99"))
                    .rangeLow(new BigDecimal("0.00"))
                    .build())
            .interestTier(
                InterestTier.builder()
                    .sysid(2L)
                    .interestRate(new BigDecimal("0.850"))
                    .rangeHigh(new BigDecimal("49999.99"))
                    .rangeLow(new BigDecimal("15000.00"))
                    .build())
            .interestTier(
                InterestTier.builder()
                    .sysid(3L)
                    .interestRate(new BigDecimal("0.950"))
                    .rangeHigh(new BigDecimal("999999999.99"))
                    .rangeLow(new BigDecimal("50000.00"))
                    .build())
            .build();

    final List<Tier> tiers = testSubject.map(product);

    assertThat(
        tiers,
        is(
            Arrays.asList(
                Tier.builder()
                    .rate(new BigDecimal("0.750"))
                    .rangeLow(new BigDecimal("0.00"))
                    .rangeHigh(new BigDecimal("14999.99"))
                    .build(),
                Tier.builder()
                    .rate(new BigDecimal("0.850"))
                    .rangeLow(new BigDecimal("15000.00"))
                    .rangeHigh(new BigDecimal("49999.99"))
                    .build(),
                Tier.builder()
                    .rate(new BigDecimal("0.950"))
                    .rangeLow(new BigDecimal("50000.00"))
                    .rangeHigh(new BigDecimal("999999999.99"))
                    .build())));
  }

  @Test
  void mapShouldReturnSortTiersWithSameRangeLowBySysid() {
    final Product product =
        Product.builder()
            .interestTier(
                InterestTier.builder()
                    .sysid(1L)
                    .interestRate(new BigDecimal("0.750"))
                    .rangeHigh(new BigDecimal("14999.99"))
                    .rangeLow(new BigDecimal("0.00"))
                    .build())
            .interestTier(
                InterestTier.builder()
                    .sysid(2L)
                    .interestRate(new BigDecimal("0.850"))
                    .rangeHigh(new BigDecimal("49999.99"))
                    .rangeLow(new BigDecimal("0.00"))
                    .build())
            .interestTier(
                InterestTier.builder()
                    .sysid(3L)
                    .interestRate(new BigDecimal("0.950"))
                    .rangeHigh(new BigDecimal("999999999.99"))
                    .rangeLow(new BigDecimal("0.00"))
                    .build())
            .build();

    final List<Tier> tiers = testSubject.map(product);

    assertThat(
        tiers,
        is(
            Arrays.asList(
                Tier.builder()
                    .rate(new BigDecimal("0.750"))
                    .rangeLow(new BigDecimal("0.00"))
                    .rangeHigh(new BigDecimal("14999.99"))
                    .build(),
                Tier.builder()
                    .rate(new BigDecimal("0.850"))
                    .rangeLow(new BigDecimal("0.00"))
                    .rangeHigh(new BigDecimal("49999.99"))
                    .build(),
                Tier.builder()
                    .rate(new BigDecimal("0.950"))
                    .rangeLow(new BigDecimal("0.00"))
                    .rangeHigh(new BigDecimal("999999999.99"))
                    .build())));
  }
}
