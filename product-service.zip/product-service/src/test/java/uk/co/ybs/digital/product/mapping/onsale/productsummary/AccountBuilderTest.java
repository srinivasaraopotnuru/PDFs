package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Account;

public class AccountBuilderTest {

  private AccountBuilder testSubject;
  private static final String ACCOUNT_NAME_FULL = "Fixed Rate Cash ISA until 30 September 2022";

  @BeforeEach
  public void beforeEach() {
    testSubject = new AccountBuilder();
  }

  @Test
  public void testMapsSuccessfully() {
    final WebSiteProduct webSiteProduct =
        TestHelper.buildFullWebsiteProductFixedISA(
            "Yes", ACCOUNT_NAME_FULL, "", "Fixed Rate ISA", "Yes");

    final Account expected =
        Account.builder()
            .section(buildSection("0", false, false))
            .title("Account name")
            .name("<bold>" + ACCOUNT_NAME_FULL + "<bold>")
            .build();

    final Account result = testSubject.map(webSiteProduct);
    assertThat(result, is(expected));
  }
}
