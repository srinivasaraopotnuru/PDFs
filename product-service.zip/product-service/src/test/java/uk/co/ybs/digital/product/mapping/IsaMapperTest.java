package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.product.TestDataFactory.charProductRule;

import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.TestDataFactory.ActiveProductRulesBuilder;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.service.TessaYearCalculator;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;

@ExtendWith(MockitoExtension.class)
class IsaMapperTest {

  private static final LocalDateTime NOW = LocalDateTime.of(2020, 5, 18, 14, 15, 21);
  private static final int CURRENT_TESSA_YEAR = 22;
  private static final String ISA = "ISA";

  @InjectMocks private IsaMapper testSubject;

  @Mock private TessaYearCalculator tessaYearCalculator;

  @Test
  void shouldMapIsaProductFlexibleAndHelpToBuyRulePresentAndTrue() {
    final ActiveProductRules activeProductRules =
        ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, ISA),
                charProductRule(AvailableProductRule.ISA_FLEXIBLE, "Y"),
                charProductRule(AvailableProductRule.ISA_HELP_TO_BUY, "Y"))
            .build();

    final ProductDetailsResponse.Isa isa = testSubject.map(activeProductRules);
    assertThat(
        isa, is(ProductDetailsResponse.Isa.builder().flexible(true).helpToBuy(true).build()));

    verify(tessaYearCalculator, never()).getTessaYear(any());
  }

  @Test
  void
      shouldMapIsaProductFlexibleRulePresentAndFalseAndShouldNotMapIsaProductHelpToBuyRulePresentAndFalse() {
    final ActiveProductRules activeProductRules =
        ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, ISA),
                charProductRule(AvailableProductRule.ISA_FLEXIBLE, "N"),
                charProductRule(AvailableProductRule.ISA_HELP_TO_BUY, "N"))
            .build();

    final ProductDetailsResponse.Isa isa = testSubject.map(activeProductRules);
    assertThat(isa, is(ProductDetailsResponse.Isa.builder().flexible(false).build()));

    verify(tessaYearCalculator, never()).getTessaYear(any());
  }

  @Test
  void shouldMapIsaProductFlexibleRuleNotPresentAndShouldNotMapIsaProductHelpToBuyRuleNotPresent() {
    final ActiveProductRules activeProductRules =
        ActiveProductRulesBuilder.makeBuilder()
            .addRules(charProductRule(AvailableProductRule.PRODUCT_TYPE, ISA))
            .build();

    final ProductDetailsResponse.Isa isa = testSubject.map(activeProductRules);
    assertThat(isa, is(ProductDetailsResponse.Isa.builder().flexible(false).build()));

    verify(tessaYearCalculator, never()).getTessaYear(any());
  }

  @Test
  void shouldMapNonIsaProduct() {
    final ActiveProductRules activeProductRules = ActiveProductRulesBuilder.makeBuilder().build();

    final ProductDetailsResponse.Isa isa = testSubject.map(activeProductRules);
    assertThat(isa, is(nullValue()));

    verify(tessaYearCalculator, never()).getTessaYear(any());
  }

  @Test
  void shouldMapPrivateIsaProductFlexibleRuleAndIsaProductHelpToBuyPresentAndTrue() {
    final ActiveProductRules activeProductRules =
        ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, ISA),
                charProductRule(AvailableProductRule.ISA_FLEXIBLE, "Y"),
                charProductRule(AvailableProductRule.ISA_HELP_TO_BUY, "Y"))
            .build();

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    final ProductDetailsResponse.Isa isa = testSubject.mapPrivate(activeProductRules, NOW);
    assertThat(
        isa,
        is(
            ProductDetailsResponsePrivate.IsaPrivate.builder()
                .flexible(true)
                .helpToBuy(true)
                .isaYear(CURRENT_TESSA_YEAR)
                .build()));
  }

  @Test
  void
      shouldMapPrivateIsaProductFlexibleRulePresentAndFalseAndShouldNotMapPrivateIsaProductHelpToBuyRulePresentAndFalse() {
    final ActiveProductRules activeProductRules =
        ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, ISA),
                charProductRule(AvailableProductRule.ISA_FLEXIBLE, "N"),
                charProductRule(AvailableProductRule.ISA_HELP_TO_BUY, "N"))
            .build();

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    final ProductDetailsResponse.Isa isa = testSubject.mapPrivate(activeProductRules, NOW);
    assertThat(
        isa,
        is(
            ProductDetailsResponsePrivate.IsaPrivate.builder()
                .flexible(false)
                .isaYear(CURRENT_TESSA_YEAR)
                .build()));
  }

  @Test
  void
      shouldMapPrivateIsaProductFlexibleRuleNotPresentAndShouldNotMapPrivateIsaProductHelpToBuyRuleNotPresent() {
    final ActiveProductRules activeProductRules =
        ActiveProductRulesBuilder.makeBuilder()
            .addRules(charProductRule(AvailableProductRule.PRODUCT_TYPE, ISA))
            .build();

    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(CURRENT_TESSA_YEAR);

    final ProductDetailsResponse.Isa isa = testSubject.mapPrivate(activeProductRules, NOW);
    assertThat(
        isa,
        is(
            ProductDetailsResponsePrivate.IsaPrivate.builder()
                .flexible(false)
                .isaYear(CURRENT_TESSA_YEAR)
                .build()));
  }

  @Test
  void shouldMapPrivateNonIsaProduct() {
    final ActiveProductRules activeProductRules = ActiveProductRulesBuilder.makeBuilder().build();

    final ProductDetailsResponse.Isa isa = testSubject.mapPrivate(activeProductRules, NOW);
    assertThat(isa, is(nullValue()));

    verify(tessaYearCalculator, never()).getTessaYear(any());
  }
}
