package uk.co.ybs.digital.product.mapping;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestDestinationType;

class WebAmendmentsMapperTest {
  private static final LocalDateTime NOW = LocalDateTime.parse("2022-10-05T01:00:00");
  private static final String PRODUCT_IDENTIFIER = "ABCD1234";
  private static final String CHAR_VALUE_Y = "Y";

  private WebAmendmentsMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new WebAmendmentsMapper();
  }

  @ParameterizedTest
  @MethodSource("interestDestinationCombinations")
  void mapShouldReturnTrueWhenProductRulesAreValidAndInterestDestinationsExists(
      final List<InterestDestinationType> interestDestinationTypes) {
    final Product product = buildProduct();
    final ActiveProductRules activeProductRules =
        Stream.of(
                buildProductRule(product, AvailableProductRule.WEB_TRANSACTIONS, CHAR_VALUE_Y),
                buildProductRule(product, AvailableProductRule.WEB_AMENDMENTS, CHAR_VALUE_Y))
            .collect(Collectors.collectingAndThen(Collectors.toList(), ActiveProductRules::new));

    assertTrue(testSubject.map(activeProductRules, interestDestinationTypes));
  }

  @Test
  void mapShouldReturnFalseWithOffsetProductRule() {
    final Product product = buildProduct();
    final ActiveProductRules activeProductRules =
        Stream.of(
                buildProductRule(product, AvailableProductRule.WEB_TRANSACTIONS, CHAR_VALUE_Y),
                buildProductRule(product, AvailableProductRule.WEB_AMENDMENTS, CHAR_VALUE_Y),
                buildProductRule(product, AvailableProductRule.OFFSET_ACCOUNT, CHAR_VALUE_Y))
            .collect(Collectors.collectingAndThen(Collectors.toList(), ActiveProductRules::new));

    final List<InterestDestinationType> interestDestinationTypes =
        Collections.singletonList(InterestDestinationType.selfCredit);

    assertFalse(testSubject.map(activeProductRules, interestDestinationTypes));
  }

  @ParameterizedTest
  @CsvSource({"Y,N", "N,Y", "N,N"})
  void mapShouldReturnFalseWithInvalidProductRules(
      final String webtrnValue, final String webamdValue) {
    final Product product = buildProduct();
    final ActiveProductRules activeProductRules =
        Stream.of(
                buildProductRule(product, AvailableProductRule.WEB_TRANSACTIONS, webtrnValue),
                buildProductRule(product, AvailableProductRule.WEB_AMENDMENTS, webamdValue))
            .collect(Collectors.collectingAndThen(Collectors.toList(), ActiveProductRules::new));

    final List<InterestDestinationType> interestDestinationTypes =
        Collections.singletonList(InterestDestinationType.selfCredit);

    assertFalse(testSubject.map(activeProductRules, interestDestinationTypes));
  }

  @ParameterizedTest
  @ValueSource(strings = {"WEBTRN", "WEBAMD"})
  void mapShouldReturnFalseWithMissingProductRules(final String productRuleCode) {
    final Product product = buildProduct();
    final ActiveProductRules activeProductRules =
        Stream.of(buildProductRule(product, productRuleCode, CHAR_VALUE_Y))
            .collect(Collectors.collectingAndThen(Collectors.toList(), ActiveProductRules::new));

    final List<InterestDestinationType> interestDestinationTypes =
        Collections.singletonList(InterestDestinationType.selfCredit);

    assertFalse(testSubject.map(activeProductRules, interestDestinationTypes));
  }

  @Test
  void mapShouldReturnFalseWithNoPermittedInterestDestinations() {
    final Product product = buildProduct();
    final ActiveProductRules activeProductRules =
        Stream.of(
                buildProductRule(product, AvailableProductRule.WEB_TRANSACTIONS, CHAR_VALUE_Y),
                buildProductRule(product, AvailableProductRule.WEB_AMENDMENTS, CHAR_VALUE_Y))
            .collect(Collectors.collectingAndThen(Collectors.toList(), ActiveProductRules::new));

    final List<InterestDestinationType> interestDestinationTypes = Collections.emptyList();

    assertFalse(testSubject.map(activeProductRules, interestDestinationTypes));
  }

  static Stream<Arguments> interestDestinationCombinations() {
    return Stream.of(
        Arguments.of(Collections.singletonList(InterestDestinationType.selfCredit)),
        Arguments.of(
            Arrays.asList(
                InterestDestinationType.payAwayExternal, InterestDestinationType.payAwayInternal)),
        Arguments.of(
            Arrays.asList(
                InterestDestinationType.selfCredit,
                InterestDestinationType.payAwayExternal,
                InterestDestinationType.payAwayInternal)));
  }

  private Product buildProduct() {
    return Product.builder().sysid(1L).productIdentifier(PRODUCT_IDENTIFIER).build();
  }

  private ProductRule buildProductRule(
      final Product product, final String productRuleCode, final String productRuleValue) {
    return ProductRule.builder(
            product, AvailableProductRule.builder().code(productRuleCode).build(), NOW)
        .charValue(productRuleValue)
        .build();
  }
}
