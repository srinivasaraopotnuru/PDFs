package uk.co.ybs.digital.product.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.product.utils.TestHelper.readClassPathResource;

import java.io.IOException;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.product.config.liferay.LiferayConfig;
import uk.co.ybs.digital.product.exception.LiferayException;
import uk.co.ybs.digital.product.utils.RandomPortInitialiser;

@SpringBootTest(
    classes = {LiferayService.class, LiferayConfig.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = RandomPortInitialiser.class)
@ActiveProfiles({"test", "text-logging"})
class LiferayServiceTest {

  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling Liferay CMS site";
  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX = "Error calling Liferay CMS: ";

  @Autowired private LiferayService testSubject;

  @Value("${uk.co.ybs.digital.product.ybs-port}")
  private int testPort;

  private MockWebServer mockWebServer;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start(testPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void getShouldReturnDocument() throws InterruptedException {
    final String body = readClassPathResource("api/liferay/document.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(body));

    final LiferayDocument liferayDocument = testSubject.getDocument(UUID.randomUUID(), "12345678");

    assertThat(liferayDocument, is(createDocument()));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(
        recordedRequest.getPath(),
        endsWith(
            "/o/headless-delivery/v1.0/documents/12345678?nestedFields=contentValue&fields=contentValue"));
    assertThat(recordedRequest.getMethod(), is(HttpMethod.GET.name()));
  }

  @Test
  void getShouldThrowProductIngestExceptionWhenConnectionErrorConnectingToYbs() throws IOException {
    mockWebServer.shutdown();
    final LiferayException exception =
        assertThrows(
            LiferayException.class, () -> testSubject.getDocument(UUID.randomUUID(), "123456768"));
    assertThat(exception.getMessage(), equalTo(UNEXPECTED_ERROR_MESSAGE));
  }

  @ParameterizedTest
  @MethodSource("productServiceErrorResponses")
  void getShouldThrowProductIngestExceptionWhenServiceReturnsErrorResponse(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final LiferayException exception =
        assertThrows(
            LiferayException.class, () -> testSubject.getDocument(UUID.randomUUID(), "123456768"));

    assertThat(exception.getMessage(), expectedMessage);
    assertThat(exception.getCause(), not(instanceOf(LiferayException.class)));
  }

  private static Stream<Arguments> productServiceErrorResponses() {
    return Stream.of(
        Arguments.of(
            HttpStatus.BAD_GATEWAY,
            MediaType.APPLICATION_JSON,
            "Error Message",
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.BAD_GATEWAY.value()))),
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/liferay/errors/forbidden.json"),
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.FORBIDDEN.value()))),
        Arguments.of(
            HttpStatus.UNAUTHORIZED,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/liferay/errors/unauthorized.json"),
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.UNAUTHORIZED.value()))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/liferay/errors/bad_request.json"),
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.BAD_REQUEST.value()))),
        Arguments.of(
            HttpStatus.INTERNAL_SERVER_ERROR,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/liferay/errors/internal_server_error.json"),
            allOf(
                startsWith(
                    HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.INTERNAL_SERVER_ERROR.value()))),
        Arguments.of(
            HttpStatus.SERVICE_UNAVAILABLE,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/liferay/errors/service_unavailable.json"),
            allOf(
                startsWith(
                    HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.SERVICE_UNAVAILABLE.value()))),
        Arguments.of(
            HttpStatus.NOT_FOUND,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/liferay/errors/document_not_found.json"),
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.NOT_FOUND.value()))));
  }

  private LiferayDocument createDocument() {
    return LiferayDocument.builder().contentValue("WW9QaGlsIQ==").build();
  }
}
