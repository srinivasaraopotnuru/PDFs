package uk.co.ybs.digital.product.validator;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import com.google.common.collect.ImmutableMap;
import javax.validation.ConstraintValidatorContext;
import org.hibernate.validator.internal.util.annotation.AnnotationDescriptor;
import org.hibernate.validator.internal.util.annotation.AnnotationFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;

@ExtendWith(MockitoExtension.class)
class PageableSortValidatorTest {
  private PageableSortValidator testSubject;

  @Mock private ConstraintValidatorContext constraintValidatorContext;

  @BeforeEach
  void beforeEach() {
    testSubject = new PageableSortValidator();
  }

  @Test
  void isValidShouldReturnTrueWhenValueIsNull() {
    assertThat(testSubject.isValid(null, constraintValidatorContext), is(true));
  }

  @Test
  void isValidShouldReturnTrueForAnySortFieldWhenFieldRegexIsDefault() {
    testSubject.initialize(createAnnotation());
    assertThat(
        testSubject.isValid(
            PageRequest.of(1, 1, Direction.ASC, "anyValueValid"), constraintValidatorContext),
        is(true));
  }

  @Test
  void isValidShouldReturnTrueWhenUnsorted() {
    testSubject.initialize(createAnnotation("valid"));
    assertThat(testSubject.isValid(PageRequest.of(1, 1), constraintValidatorContext), is(true));
  }

  @Test
  void isValidShouldReturnTrueWhenAllSortFieldsMatchPattern() {
    testSubject.initialize(createAnnotation("valid\\d"));
    assertThat(
        testSubject.isValid(
            PageRequest.of(1, 1, Direction.ASC, "valid1", "valid2"), constraintValidatorContext),
        is(true));
  }

  @Test
  void isValidShouldReturnFalseWhenAnySortFieldDoesNotMatchPattern() {
    testSubject.initialize(createAnnotation("valid"));
    assertThat(
        testSubject.isValid(
            PageRequest.of(1, 1, Direction.ASC, "valid", "invalid"), constraintValidatorContext),
        is(false));
  }

  private PageableSort createAnnotation(final String regex) {
    final AnnotationDescriptor<PageableSort> descriptor =
        new AnnotationDescriptor.Builder<>(
                PageableSort.class, ImmutableMap.of("fieldRegexp", regex))
            .build();
    return AnnotationFactory.create(descriptor);
  }

  private PageableSort createAnnotation() {
    final AnnotationDescriptor<PageableSort> descriptor =
        new AnnotationDescriptor.Builder<>(PageableSort.class).build();
    return AnnotationFactory.create(descriptor);
  }
}
