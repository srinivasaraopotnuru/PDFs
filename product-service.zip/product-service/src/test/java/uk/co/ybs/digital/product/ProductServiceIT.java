package uk.co.ybs.digital.product;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static uk.co.ybs.digital.product.TestDataFactory.charProductRule;
import static uk.co.ybs.digital.product.TestDataFactory.longProductRule;
import static uk.co.ybs.digital.product.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.math.BigDecimal;
import java.net.URI;
import java.security.PrivateKey;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.persistence.EntityManager;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.SneakyThrows;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureTestEntityManager;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.cache.CacheManager;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.reactive.function.BodyInserters;
import uk.co.ybs.digital.logging.filters.session.SessionIdSourceType;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.ProductRule;
import uk.co.ybs.digital.product.service.LiferayDocument;
import uk.co.ybs.digital.product.service.ProductCategoryType;
import uk.co.ybs.digital.product.utils.RandomPortInitialiser;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.AvailableProductDetails;
import uk.co.ybs.digital.product.web.dto.ErrorResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsPageResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsPageResponsePrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Applications;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Balance;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Deposits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestDestinationType;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestPaidType;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.Tier;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Withdrawals;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.InterestPrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.WithdrawalsPrivate;
import uk.co.ybs.digital.product.web.dto.onsale.Fact;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ProductSummary;
import uk.co.ybs.digital.product.web.dto.reinvestment.ProductReinvestmentResponse;
import uk.co.ybs.digital.product.web.dto.reinvestment.ReinvestmentProduct;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class})
@ContextConfiguration(initializers = RandomPortInitialiser.class)
@ActiveProfiles({"test", "text-logging"})
@AutoConfigureTestEntityManager
class ProductServiceIT {

  private static final int MINIMUM_CUSTOMER_AGE_16 = 16;
  private static final int MAXIMUM_CUSTOMER_AGE_99 = 99;
  private static final int MAXIMUM_NUMBER_OF_ACCOUNTS_1 = 1;
  private static final String PRODUCT_IDENTIFIER = "ABCD123A";
  private static final String PRODUCT_SUMMARY_IDENTIFIER = "YB291415W";
  private static final String PRODUCT_SUMMARY_IDENTIFIER_EASYACCESS = "YB681429W";
  private static final String BRAND_CODE_YBS = "YBS";
  // This derived tessa year needs to correspond to the current time in the IntegrationTestConfig
  // clock
  private static final int CURRENT_TESSA_YEAR = 22;
  private static final String SCOPE_ACCOUNT_READ = "ACCOUNT_READ";
  private static final String BASE_PATH = "/product/";
  private static final String SEARCH_PRODUCT_ENDPOINT = "product?";
  private static final String PRIVATE_SEARCH_PRODUCT_ENDPOINT = "private/product?";
  private static final String PRODUCT_ENDPOINT = "product/";
  private static final String PRODUCT_PRIVATE_ENDPOINT = "private/product/";
  private static final String ON_SALE_PRODUCTS_ENDPOINT = "on-sale-products";
  private static final String ON_SALE_PRODUCTS_PRIVATE_ENDPOINT = "private/on-sale-products";
  private static final String REINVEST_PRIVATE_ENDPOINT = "reinvestment-products";
  private static final String AVAILABLE_PRODUCTS_PRIVATE_ENDPOINT = "private/available-products";
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String PRIVATE_GET_ON_SALE_PRODUCTS_ENDPOINT =
      "PRIVATE_GET_ON_SALE_PRODUCTS";
  private static final String GET_ON_SALE_PRODUCTS_ENDPOINT = "GET_ON_SALE_PRODUCTS";
  private static final String PRIVATE_GET_AVAILABLE_PRODUCTS_ENDPOINT =
      "PRIVATE_GET_AVAILABLE_PRODUCTS";
  private static final String GET_ON_SALE_PRODUCTS_SUMMARY_ENDPOINT =
      "GET_ON_SALE_PRODUCTS_SUMMARY";
  private static final String GET_ON_SALE_PRODUCTS_SUMMARY_EASYACCESS_ENDPOINT =
      "GET_ON_SALE_PRODUCTS_SUMMARY_EASYACCESS";

  @LocalServerPort private String localServerPort;

  @Autowired private WebTestClient signingWebClientPublic;

  @Autowired private WebTestClient signingWebClientPrivate;

  @Autowired private WebTestClient nonSigningWebClient;

  @Autowired private PrivateKey jwtSigningPrivateKey;

  @Autowired private Clock clock;

  @Autowired private TestEntityManager testEntityManager;

  @Autowired private TransactionTemplate transactionTemplate;

  @Autowired private CacheManager cacheManager;

  private MockWebServer mockLiferay;

  private UUID requestId;

  private final ObjectMapper objectMapper = new ObjectMapper();

  @Value("${uk.co.ybs.digital.product.ybs-port}")
  private int testPort;

  @SuppressWarnings("PMD.UnusedPrivateMethod")
  private static void populateProductDetailsResponseBase(
      final ProductDetailsResponse.ProductDetailsResponseBaseBuilder<?, ?> builder,
      final Deposits expectedDeposits) {
    builder
        .productIdentifier(PRODUCT_IDENTIFIER)
        .productType("ISA")
        .customerDescription("bar")
        .brandCode(BRAND_CODE_YBS)
        .cardAvailable(false)
        .isKycRequired(true)
        .saver(null)
        .balance(
            Balance.builder().min(new BigDecimal("-20.00")).max(new BigDecimal("50.00")).build())
        .deposits(expectedDeposits)
        .applications(
            Applications.builder()
                .accountNumberSuffix("12")
                .applicationsPermitted(true)
                .fatcaReportable(true)
                .maximumAge(75L)
                .minimumAge(17L)
                .maximumApplicants(1L)
                .nationalInsuranceNumberRequired(true)
                .build());
  }

  private Deposits buildExpectedDeposits() {
    return buildExpectedDeposits(true, true);
  }

  private Deposits buildExpectedDeposits(
      final boolean expectedDepositsPermittedByCard,
      final boolean expectedDepositsPermittedExternal) {
    return Deposits.builder()
        .permittedExternal(expectedDepositsPermittedExternal)
        .permittedInternal(false)
        .permittedInBranch(true)
        .permittedByCard(expectedDepositsPermittedByCard)
        .limits(
            Deposits.DepositLimits.builder()
                .amount(
                    PeriodLimits.<BigDecimal>builder()
                        .firstMonth(new BigDecimal("50.00"))
                        .month(new BigDecimal("70.00"))
                        .year(new BigDecimal("4000.00"))
                        .anniversaryYear(new BigDecimal("4500.00"))
                        .taxYear(new BigDecimal("5000.00"))
                        .productTerm(new BigDecimal("50000.00"))
                        .build())
                .build())
        .build();
  }

  private static List<Tier> buildInterestTiers() {
    return asList(
        Tier.builder()
            .rate(new BigDecimal("0.750"))
            .rangeLow(new BigDecimal("0.00"))
            .rangeHigh(new BigDecimal("14999.99"))
            .build(),
        Tier.builder()
            .rate(new BigDecimal("0.850"))
            .rangeLow(new BigDecimal("15000.00"))
            .rangeHigh(new BigDecimal("999999999.99"))
            .build());
  }

  @BeforeEach
  void setUp() throws IOException {
    requestId = UUID.randomUUID();
    mockLiferay = new MockWebServer();
    mockLiferay.start(testPort);
    TestHelper.clearCacheManager(cacheManager);
  }

  @AfterEach
  void afterEach() throws IOException {
    tearDownDb();
    mockLiferay.shutdown();
  }

  @Test
  void getProductShouldSucceed() {
    setUpProduct(true);

    final ProductDetailsResponse productRuleResponse = expectedProductDetailsResponse();

    final Endpoint endpoint = Endpoint.GET_PRODUCT;
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductDetailsResponse.class)
        .isEqualTo(productRuleResponse);
  }

  @Test
  void privateGetProductShouldSucceed() {
    setUpProduct(false);

    final ProductDetailsResponsePrivate productRuleResponse =
        expectedProductDetailsResponsePrivate();

    final Endpoint endpoint = Endpoint.PRIVATE_GET_PRODUCT;
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductDetailsResponsePrivate.class)
        .isEqualTo(productRuleResponse);
  }

  @ParameterizedTest
  @MethodSource("productRulesAndExpectedDepositValues")
  void getProductSuccessResponseShouldContainCorrectDepositsPermittedByCardValue(
      final Collection<ProductRule> productRules,
      final boolean expectedDepositsPermittedByCard,
      final boolean expectedDepositsPermittedExternal) {
    setUpProductWithRules(true, productRules);

    final ProductDetailsResponse expectedResponseBody =
        expectedProductDetailsResponse(
            buildExpectedDeposits(
                expectedDepositsPermittedByCard, expectedDepositsPermittedExternal));

    final Endpoint endpoint = Endpoint.GET_PRODUCT;
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductDetailsResponse.class)
        .isEqualTo(expectedResponseBody);
  }

  @ParameterizedTest
  @MethodSource("productRulesAndExpectedDepositValues")
  void getProductSuccessPrivateResponseShouldContainCorrectDepositsPermittedByCardValue(
      final Collection<ProductRule> productRules,
      final boolean expectedDepositsPermittedByCard,
      final boolean expectedDepositsPermittedExternal,
      final boolean expectedWithdrawalsPermittedOnAccountClosure) {
    setUpProductWithRules(false, productRules);

    final ProductDetailsResponsePrivate expectedResponseBody =
        expectedProductDetailsResponsePrivate(
            buildExpectedDeposits(
                expectedDepositsPermittedByCard, expectedDepositsPermittedExternal),
            expectedWithdrawalsPermittedOnAccountClosure);

    final Endpoint endpoint = Endpoint.PRIVATE_GET_PRODUCT;
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductDetailsResponsePrivate.class)
        .isEqualTo(expectedResponseBody);
  }

  private static Stream<Arguments> productRulesAndExpectedDepositValues() {
    return Stream.of(
        // Deposits by card  allowed
        Arguments.of(
            singletonList(charProductRule(AvailableProductRule.WEB_TRANSACTIONS, "Y")),
            true,
            true,
            true),
        Arguments.of(
            asList(
                charProductRule(AvailableProductRule.WEB_TRANSACTIONS, "Y"),
                charProductRule(AvailableProductRule.STOP_DEPOSITS_EXTERNAL, "N")),
            true,
            true,
            true),
        Arguments.of(
            asList(
                charProductRule(AvailableProductRule.WEB_TRANSACTIONS, "Y"),
                longProductRule(AvailableProductRule.NOTICE_DAYS_FOR_WITHDRAWALS, 0L)),
            true,
            true,
            true),
        Arguments.of(
            asList(
                charProductRule(AvailableProductRule.WEB_TRANSACTIONS, "Y"),
                longProductRule(AvailableProductRule.NOTICE_DAYS_FOR_WITHDRAWALS, 0L),
                charProductRule(AvailableProductRule.STOP_DEPOSITS_EXTERNAL, "N")),
            true,
            true,
            true),
        // Deposits by card not allowed because web transactions not allowed
        Arguments.of(Collections.EMPTY_LIST, false, true, false),
        Arguments.of(
            singletonList(charProductRule(AvailableProductRule.WEB_TRANSACTIONS, "N")),
            false,
            true,
            false),
        // Deposits by card not allowed because withdrawal days greater than zero
        Arguments.of(
            asList(
                charProductRule(AvailableProductRule.WEB_TRANSACTIONS, "Y"),
                longProductRule(AvailableProductRule.NOTICE_DAYS_FOR_WITHDRAWALS, 30L)),
            false,
            true,
            true),
        Arguments.of(
            asList(
                charProductRule(AvailableProductRule.WEB_TRANSACTIONS, "Y"),
                longProductRule(AvailableProductRule.NOTICE_DAYS_FOR_WITHDRAWALS, 30L),
                charProductRule(AvailableProductRule.STOP_DEPOSITS_EXTERNAL, "N")),
            false,
            true,
            true),
        // Deposits by card not allowed because receipts stopped
        Arguments.of(
            asList(
                charProductRule(AvailableProductRule.WEB_TRANSACTIONS, "Y"),
                longProductRule(AvailableProductRule.NOTICE_DAYS_FOR_WITHDRAWALS, 0L),
                charProductRule(AvailableProductRule.STOP_DEPOSITS_EXTERNAL, "Y")),
            false,
            false,
            true));
  }

  @Test
  void getProductWithValidSessionIdShouldSucceed() {
    final String jwt = buildSavingsAppJwtWithSessionId(UUID.randomUUID().toString());

    setUpProduct(true);

    final ProductDetailsResponse productRuleResponse = expectedProductDetailsResponse();

    final Endpoint endpoint = Endpoint.GET_PRODUCT;
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductDetailsResponse.class)
        .isEqualTo(productRuleResponse);
  }

  @Test
  void searchProductDetailsShouldSucceed() {
    setUpProduct(true);

    final ProductDetailsPageResponse expectedPageResult =
        ProductDetailsPageResponse.builder()
            .content(singletonList(expectedProductDetailsResponse()))
            .pageNumber(0)
            .pageSize(2)
            .totalElements(1L)
            .totalPages(1)
            .build();

    final Endpoint endpoint = Endpoint.SEARCH_PRODUCT;
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductDetailsPageResponse.class)
        .isEqualTo(expectedPageResult);
  }

  @Test
  void privateSearchProductDetailsShouldSucceed() {
    setUpProduct(false);

    final ProductDetailsPageResponsePrivate expectedPageResult =
        ProductDetailsPageResponsePrivate.builder()
            .content(singletonList(expectedProductDetailsResponsePrivate()))
            .pageNumber(0)
            .pageSize(2)
            .totalElements(1L)
            .totalPages(1)
            .build();

    final Endpoint endpoint = Endpoint.PRIVATE_SEARCH_PRODUCT;
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductDetailsPageResponsePrivate.class)
        .isEqualTo(expectedPageResult);
  }

  @Test
  void getReinvestmentProductsShouldSucceed() {
    setUpProduct(false);

    final ProductReinvestmentResponse expectedResponse =
        ProductReinvestmentResponse.builder()
            .reinvestmentProducts(
                singletonList(
                    ReinvestmentProduct.builder().productIdentifier(PRODUCT_IDENTIFIER).build()))
            .build();

    final Endpoint endpoint = Endpoint.GET_REINVESTMENT_PRODUCTS;
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductReinvestmentResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      names = {GET_ON_SALE_PRODUCTS_ENDPOINT, PRIVATE_GET_ON_SALE_PRODUCTS_ENDPOINT})
  @SuppressWarnings({"PMD.ExcessiveMethodLength", "PMD.AvoidDuplicateLiterals"})
  void getOnSaleProductsShouldSucceed(final Endpoint endpoint) {
    final Product easyISA =
        buildProductDto(
            "Six Access e-Saver ISA Issue 3",
            ProductType.ISA,
            "YB851266W",
            "YB851266W",
            MINIMUM_CUSTOMER_AGE_16,
            MAXIMUM_CUSTOMER_AGE_99,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.20%")
                    .range("£1.00 - £999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("1.00%")
                    .range("£1,000.00 - £10,000.49")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.50%")
                    .range("£10,000.50 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.55%")
                    .range("£50,000.00+")
                    .build()),
            asList(
                "Save from £1 in this Cash ISA",
                "Four tiered interest rates - rate depends on account balance",
                "Cash ISA pays Annual interest",
                "Allows withdrawals on six days per year"));

    final Product easyInternetSaverPlus =
        buildProductDto(
            "Internet Saver Plus Issue 9",
            ProductType.EASY_ACCESS,
            PRODUCT_SUMMARY_IDENTIFIER_EASYACCESS,
            PRODUCT_SUMMARY_IDENTIFIER_EASYACCESS,
            MINIMUM_CUSTOMER_AGE_16,
            null,
            null,
            false,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("0.40%")
                    .range("£1.00 - £999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("0.43%")
                    .range("£1,000.00 - £9,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("0.45%")
                    .range("£10,000.00 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("0.50%")
                    .range("£50,000.00+")
                    .build()),
            asList(
                "Save from £1",
                "Four tiered interest rates - rate depends on account balance",
                "Annual interest",
                "Unlimited withdrawals"));

    final Product easyInternetSaverISAPlus =
        buildProductDto(
            "Internet Saver ISA Plus Issue 9",
            ProductType.ISA,
            "YB691430W",
            "YB691430W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.15%")
                    .range("£1.00 - £999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.25%")
                    .range("£1,000.00 - £9,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.35%")
                    .range("£10,000.00 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.45%")
                    .range("£50,000.00 - £79,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.55%")
                    .range("£80,000.00 - £99,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.65%")
                    .range("£100,000.00 - £149,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.75%")
                    .range("£150,000.00+")
                    .build()),
            asList(
                "Save from £1 in this Cash ISA",
                "Seven tiered interest rates - rate depends on account balance",
                "Cash ISA pays Annual interest",
                "Unlimited withdrawals"));

    final Product easyInternetSaverISAPlusIssue10 =
        buildProductDto(
            "Internet Saver ISA Plus Issue 10",
            ProductType.ISA,
            "YB691501W",
            "YB691501W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable across all tiers")
                    .rate("2.30%")
                    .range("£1.00+")
                    .build()),
            asList(
                "Save from £1 in this Cash ISA",
                "Cash ISA pays Annual interest",
                "Unlimited withdrawals"));

    final Product easyRainyDayAccount =
        buildProductDto(
            "Online Rainy Day Account",
            ProductType.EASY_ACCESS,
            "YB931418W",
            "YB931418W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.ANNUAL,
            singletonList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable")
                    .rate("0.52%")
                    .build()),
            asList(
                "Save from £10",
                "Interest will be paid annually",
                "Allows withdrawals on one day per year based on the anniversary of the account opening date, plus closure at any time if required"));
    final Product easyInternetSaverPlusLoyalty =
        buildProductDto(
            "Loyalty Saver",
            ProductType.EASY_ACCESS,
            "YB681499W",
            "YB681499W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            1,
            true,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("1.00%")
                    .range("£1,000.00 - £24,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("1.05%")
                    .range("£25,000.00 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("1.15%")
                    .range("£50,000.00+")
                    .build()),
            asList(
                "Membership eligibility criteria applies for this 1 year Cash ISA and Save from £10",
                "Three tiered interest rates and interest paid annually",
                "Withdrawals on 6 days/year & closure at any time - Use the ISA transfer process to keep tax-free status"));

    final Product loyaltySixAccessSaverEIsaAccount =
        buildProductDto(
            "Loyalty Six Access Saver ISA Issue 2",
            ProductType.ISA,
            "YB941511W",
            "YB941511W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            1,
            true,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("1.00%")
                    .range("£1,000.00 - £24,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("1.05%")
                    .range("£25,000.00 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("1.15%")
                    .range("£50,000.00+")
                    .build()),
            asList(
                "Membership eligibility criteria applies for this 1 year Cash ISA and Save from £1",
                "Three tiered interest rates and interest paid annually",
                "Withdrawals on 6 days/year & closure at any time - Use the ISA transfer process to keep tax-free status"));

    final Product familySaver =
        buildProductDto(
            "Family eSavings Account",
            ProductType.EASY_ACCESS,
            "YB931546W",
            "YB931546W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.MONTHLY,
            asList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances up to")
                    .rate("1.50%")
                    .range("£10,000.00")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("1.40%")
                    .range("£10,000.01 - £20,000.00")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("1.30%")
                    .range("£20,000.01 - £30,000.00")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances over")
                    .rate("1.00%")
                    .range("£30,000.01")
                    .build()),
            asList(
                "Save from £1 in this three year product",
                "4 tiered variable interest rate and interest paid monthly",
                "Three withdrawal days per year and closure permitted",
                "One account per customer"));

    final Product loyaltySixAccessESaver =
        buildProductDto(
            "Loyalty Six Access eSaver",
            ProductType.EASY_ACCESS,
            "YB951617W",
            "YB951617W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            null,
            true,
            InterestFrequency.ANNUAL,
            singletonList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable")
                    .rate("2.00%")
                    .build()),
            asList(
                "Loyalty eligibility criteria applies & only one account per person",
                "Open from £1 and save up to £500,000 for a year",
                "Annual interest",
                "Six withdrawal days per year, plus closure"));

    final Product onlineRainyDayAccountIssue2 =
        buildProductDto(
            "Online Rainy Day Account Issue 2",
            ProductType.EASY_ACCESS,
            "YB931629W",
            "YB931629W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            1,
            false,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances up to")
                    .rate("2.50%")
                    .range("£5,000.00")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances over")
                    .rate("2.00%")
                    .range("£5,000.01")
                    .build()),
            asList(
                "Save from £1",
                "2 tiered variable interest rate and interest paid annually",
                "Two withdrawal days per year and closure permitted",
                "One account per customer"));
    final Product christmasRegularESaver =
        buildProductDto(
            "Christmas 2023 Regular e-Saver",
            ProductType.SAVER,
            "YB901652W",
            "YB901652W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.ANNUAL,
            singletonList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable")
                    .rate("4.50%")
                    .build()),
            asList(
                "Open with and save from £1 to £300 a month",
                "Interest paid on maturity which is 31 October 2023",
                "Limited access with one withdrawal day for the term of this product, plus closure if required",
                "Only one account per customer"));

    final List<ProductCategory> expected =
        asList(
            buildProductCategory(
                ProductCategoryType.EASY_ACCESS,
                String.format(
                    "http://localhost:%d/easy-access/index.html?display=allWaysToApply", testPort),
                true,
                asList(
                    buildProductDto(
                        "Six Access e-Saver Issue 4",
                        ProductType.EASY_ACCESS,
                        "YB841278W",
                        "YB841278W",
                        MINIMUM_CUSTOMER_AGE_16,
                        MAXIMUM_CUSTOMER_AGE_99,
                        MAXIMUM_NUMBER_OF_ACCOUNTS_1,
                        false,
                        InterestFrequency.ANNUAL,
                        asList(
                            InterestTier.builder()
                                .description("Gross p.a./AER variable on balances of")
                                .rate("0.15%")
                                .range("£1.00 - £999.99")
                                .build(),
                            InterestTier.builder()
                                .description("Gross p.a./AER variable on balances of")
                                .rate("0.25%")
                                .range("£1,000.00 - £9,999.99")
                                .build(),
                            InterestTier.builder()
                                .description("Gross p.a./AER variable on balances of")
                                .rate("0.40%")
                                .range("£10,000.00 - £49,999.99")
                                .build(),
                            InterestTier.builder()
                                .description("Gross p.a./AER variable on balances of")
                                .rate("0.45%")
                                .range("£50,000.00+")
                                .build()),
                        asList(
                            "Save from £1",
                            "Four tiered interest rates - rate depends on account balance",
                            "Annual interest",
                            "Allows withdrawals on six days per year plus closure")),
                    easyISA,
                    easyInternetSaverPlus,
                    easyInternetSaverISAPlus,
                    easyInternetSaverISAPlusIssue10,
                    easyRainyDayAccount,
                    easyInternetSaverPlusLoyalty,
                    loyaltySixAccessSaverEIsaAccount,
                    familySaver,
                    loyaltySixAccessESaver,
                    onlineRainyDayAccountIssue2),
                emptyList()),
            buildProductCategory(
                ProductCategoryType.FIXED_BOND,
                String.format(
                    "http://localhost:%d/fixed-rate-bonds/index.html?display=allWaysToApply",
                    testPort),
                true,
                asList(
                    buildProductDto(
                        "Fixed Rate Bond until 31/12/2021",
                        ProductType.BOND,
                        "YB271280W",
                        "YB271280W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Gross p.a./AER fixed")
                                .rate("0.50%")
                                .build()),
                        asList("Save from £1,000", "Annual interest", "Withdrawals not permitted")),
                    buildProductDto(
                        "Fixed Rate Bond until 31/12/2022",
                        ProductType.BOND,
                        "YB271269W",
                        "YB271269W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Gross p.a./AER fixed")
                                .rate("0.65%")
                                .build()),
                        asList("Save from £1,000", "Annual interest", "Withdrawals not permitted")),
                    buildProductDto(
                        "Fixed Rate Bond until 31/12/2023",
                        ProductType.BOND,
                        "YB271270W",
                        "YB271270W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Gross p.a./AER fixed")
                                .rate("0.65%")
                                .build()),
                        asList("Save from £1,000", "Annual interest", "Withdrawals not permitted")),
                    buildProductDto(
                        "Loyalty Fixed Rate Bond (No Access) until 31/01/2024",
                        ProductType.BOND,
                        "YB131540B",
                        "YB131540B",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        true,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Gross p.a./AER fixed")
                                .rate("2.10%")
                                .build()),
                        asList(
                            "Loyalty eligibility criteria applies",
                            "Save from £1,000",
                            "Interest paid on 31 January 2024",
                            "Withdrawals and closure not permitted")),
                    buildProductDto(
                        "Fixed Rate Bond until 30/09/2023",
                        ProductType.BOND,
                        "YB271618W",
                        "YB271618W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Gross p.a./AER fixed")
                                .rate("2.00%")
                                .build()),
                        asList(
                            "Save from £1,000",
                            "Monthly or annual interest - rate varies for monthly interest",
                            "Online pays annual interest",
                            "Withdrawals not permitted")),
                    buildProductDto(
                        "Energy Saving Awareness eBond (No Access) until 31 January 2024",
                        ProductType.BOND,
                        "YB271653W",
                        "YB271653W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Gross p.a./AER fixed")
                                .rate("3.50%")
                                .build()),
                        asList(
                            "Open from £1,000 and save up to £2 million",
                            "Annual interest",
                            "Withdrawals and closure not permitted",
                            "Receive free independent information in partnership with the Energy Saving Trust"))),
                emptyList()),
            buildProductCategory(
                ProductCategoryType.ISA_FIXED,
                String.format("http://localhost:%d/isas/index.html?display=fixedRate", testPort),
                false,
                asList(
                    buildProductDto(
                        "Fixed Rate ISA until 31/12/2021",
                        ProductType.ISA,
                        "YB291271W",
                        "YB291271W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Tax-free p.a./AER fixed")
                                .rate("0.55%")
                                .build()),
                        asList(
                            "Save from £100 in this Cash ISA",
                            "Cash ISA pays Annual interest",
                            "Withdrawals not permitted",
                            "Closure permitted with 60 days' loss of interest",
                            "You can transfer your ISA from another provider")),
                    buildProductDto(
                        "Fixed Rate ISA until 31/12/2022",
                        ProductType.ISA,
                        "YB291272W",
                        "YB291272W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Tax-free p.a./AER fixed")
                                .rate("0.60%")
                                .build()),
                        asList(
                            "Save from £100 in this Cash ISA",
                            "Cash ISA pays Annual interest",
                            "Withdrawals not permitted",
                            "Closure permitted with 120 days' loss of interest",
                            "You can transfer your ISA from another provider")),
                    buildProductDto(
                        "Fixed Rate ISA until 31/12/2023",
                        ProductType.ISA,
                        "YB291273W",
                        "YB291273W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Tax-free p.a./AER fixed")
                                .rate("0.60%")
                                .build()),
                        asList(
                            "Save from £100 in this Cash ISA",
                            "Cash ISA pays Annual interest",
                            "Withdrawals not permitted",
                            "Closure permitted with 180 days' loss of interest",
                            "You can transfer your ISA from another provider")),
                    buildProductDto(
                        "Fixed Rate eISA until 31/10/2022",
                        ProductType.ISA,
                        PRODUCT_SUMMARY_IDENTIFIER,
                        PRODUCT_SUMMARY_IDENTIFIER,
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Tax-free p.a./AER fixed")
                                .rate("1.00%")
                                .build()),
                        asList(
                            "Save from £100 in this Cash ISA",
                            "Cash ISA pays Annual interest",
                            "Withdrawals not permitted",
                            "Closure permitted with 60 days' loss of interest",
                            "You can transfer your ISA from another provider")),
                    buildProductDto(
                        "Fixed Rate ISA until 30/09/2023",
                        ProductType.ISA,
                        "YB291621W",
                        "YB291621W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Tax-free p.a./AER fixed")
                                .rate("2.10%")
                                .build()),
                        asList(
                            "Save from £100 in this Cash ISA",
                            "Cash ISA pays Monthly or annual interest - rate varies for monthly interest",
                            "Online pays annual interest",
                            "Withdrawals not permitted",
                            "Closure permitted with 60 days' loss of interest",
                            "You can transfer your ISA from another provider"))),
                emptyList()),
            buildProductCategory(
                ProductCategoryType.ISA_VARIABLE,
                String.format("http://localhost:%d/isas/index.html?display=variableRate", testPort),
                true,
                asList(
                    easyISA,
                    easyInternetSaverISAPlus,
                    easyInternetSaverISAPlusIssue10,
                    loyaltySixAccessSaverEIsaAccount),
                emptyList()),
            buildProductCategory(
                ProductCategoryType.REGULAR,
                String.format(
                    "http://localhost:%d/regular-saver/index.html?display=allWaysToApply",
                    testPort),
                true,
                singletonList(christmasRegularESaver),
                emptyList()),
            buildProductCategory(
                ProductCategoryType.CHILDRENS,
                String.format(
                    "http://localhost:%d/childrens-savings/index.html?display=allWaysToApply",
                    testPort),
                true,
                emptyList(),
                emptyList()));

    stubOnSaleProductsYbsSiteResponse(
        new ClassPathResource("/responses/LiferayDocumentWebSiteProductsResponse.json"));
    doGetOnSaleProducts(endpoint, expected);
  }

  @Test
  void getOnSaleProductSummaryOfISAShouldSucceed() {
    stubOnSaleProductsYbsSiteResponse(
        new ClassPathResource("/responses/LiferayDocumentWebSiteProductsResponse.json"));

    final ProductSummary expectedResponse = TestHelper.buildExpectedMappingForFixedISA();
    final Endpoint endpoint = Endpoint.GET_ON_SALE_PRODUCTS_SUMMARY;

    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductSummary.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void getOnSaleProductSummaryOfEasySaverShouldSucceed() {
    stubOnSaleProductsYbsSiteResponse(
        new ClassPathResource("/responses/LiferayDocumentWebSiteProductsResponse.json"));

    final ProductSummary expectedResponse = TestHelper.buildExpectedMappingForEasyAccess();
    final Endpoint endpoint = Endpoint.GET_ON_SALE_PRODUCTS_SUMMARY_EASYACCESS;

    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ProductSummary.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      names = {GET_ON_SALE_PRODUCTS_ENDPOINT, PRIVATE_GET_ON_SALE_PRODUCTS_ENDPOINT})
  void getOnSaleProductsShouldReverseMerge(final Endpoint endpoint) {
    final List<ProductCategory> expected =
        singletonList(
            buildProductCategory(
                ProductCategoryType.FIXED_BOND,
                String.format(
                    "http://localhost:%d/fixed-rate-bonds/index.html?display=allWaysToApply",
                    testPort),
                false,
                singletonList(
                    buildProductDto(
                        "Fixed Rate Bond until 31/12/2021",
                        ProductType.BOND,
                        "YB271280W",
                        "YB271280W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Gross p.a./AER fixed")
                                .rate("0.50%")
                                .build()),
                        asList(
                            "Save from £1,000", "Annual interest", "Withdrawals not permitted"))),
                emptyList()));

    stubOnSaleProductsYbsSiteResponse(
        new ClassPathResource("/responses/LiferayDocumentWebSiteProductsReverseResponse.json"));
    doGetOnSaleProducts(endpoint, expected);
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      names = {GET_ON_SALE_PRODUCTS_ENDPOINT, PRIVATE_GET_ON_SALE_PRODUCTS_ENDPOINT})
  void getOnSaleProductsShouldUseCachedResponse(final Endpoint endpoint) {
    final List<ProductCategory> expected =
        singletonList(
            buildProductCategory(
                ProductCategoryType.FIXED_BOND,
                String.format(
                    "http://localhost:%d/fixed-rate-bonds/index.html?display=allWaysToApply",
                    testPort),
                false,
                singletonList(
                    buildProductDto(
                        "Fixed Rate Bond until 31/12/2021",
                        ProductType.BOND,
                        "YB271280W",
                        "YB271280W",
                        MINIMUM_CUSTOMER_AGE_16,
                        null,
                        null,
                        false,
                        InterestFrequency.ANNUAL,
                        singletonList(
                            InterestTier.builder()
                                .description("Gross p.a./AER fixed")
                                .rate("0.50%")
                                .build()),
                        asList(
                            "Save from £1,000", "Annual interest", "Withdrawals not permitted"))),
                emptyList()));

    stubOnSaleProductsYbsSiteResponse(
        new ClassPathResource("/responses/LiferayDocumentWebSiteProductsReverseResponse.json"));
    doGetOnSaleProducts(endpoint, expected);
    doGetOnSaleProducts(endpoint, expected);
  }

  @ParameterizedTest
  @EnumSource
  void endpointsShouldErrorForIncorrectRequestSigningKey(final Endpoint endpoint) {
    getIncorrectWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(accessDeniedResponseInvalidRequestSignature(requestId));
  }

  @ParameterizedTest
  @EndpointsRequiringAccessTokenSource
  void endpointsShouldErrorWhenMissingAuthorization(final Endpoint endpoint) {
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders())
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .isEqualTo(unauthorizedResponse(requestId));
  }

  @ParameterizedTest
  @EndpointsRequiringAccessTokenSource
  void endpointShouldErrorWhenMissingRequiredScope(final Endpoint endpoint) {
    final String jwt = buildJwtWithScope("OTHER");

    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(accessDeniedResponse(requestId));
  }

  @ParameterizedTest
  @EndpointsRequiringAccessTokenSource
  void endpointShouldErrorWhenInvalidSessionId(final Endpoint endpoint) {
    final String jwt = buildSavingsAppJwtWithSessionId("invalid_session_id");

    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectBody(ErrorResponse.class)
        .isEqualTo(invalidSessionIdResponse(requestId));
  }

  @ParameterizedTest
  @EndpointsRequiringAccessTokenSource
  void endpointShouldErrorWhenSavingsAppJwtMissingSessionId(final Endpoint endpoint) {
    final String jwt = buildSavingsAppJwtWithoutSessionId();

    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectBody(ErrorResponse.class)
        .isEqualTo(missingSessionIdResponse(requestId));
  }

  @ParameterizedTest
  @EnumSource
  void endpointShouldErrorWhenSignatureHeaderMissing(final Endpoint endpoint) {
    nonSigningWebClient
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(invalidRequestSignatureResponse(requestId));
  }

  @ParameterizedTest
  @EnumSource
  void endpointShouldErrorWhenSignatureInvalid(final Endpoint endpoint) {
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .header(HEADER_REQUEST_SIGNATURE, "invalid.signature")
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(invalidRequestSignatureResponse(requestId));
  }

  @Test
  void privateGetAvailableProductsShouldSucceed() {

    stubOnSaleProductsYbsSiteResponse(
        new ClassPathResource("/responses/LiferayDocumentAvailableWebSiteProductsResponse.json"));

    final Endpoint endpoint = Endpoint.PRIVATE_GET_AVAILABLE_PRODUCTS;

    final AvailableProductDetails availableProductDetails =
        AvailableProductDetails.builder().dateOfBirth("1962-10-01").countryCode("UK").build();

    final List<ProductCategory> response = buildAvailableProductCategory();
    getWebClient(endpoint)
        .post()
        .uri(getURI(endpoint))
        .body(BodyInserters.fromValue(availableProductDetails))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(ProductCategory.class)
        .isEqualTo(response);
  }

  private WebTestClient getWebClient(final Endpoint endpoint) {
    switch (endpoint.getType()) {
      case PUBLIC:
        return signingWebClientPublic;
      case PRIVATE:
        return signingWebClientPrivate;
      default:
        throw new IllegalArgumentException("Unexpected endpoint type: " + endpoint.getType());
    }
  }

  private WebTestClient getIncorrectWebClient(final Endpoint endpoint) {
    switch (endpoint.getType()) {
      case PUBLIC:
        return signingWebClientPrivate;
      case PRIVATE:
        return signingWebClientPublic;
      default:
        throw new IllegalArgumentException("Unexpected endpoint type: " + endpoint.getType());
    }
  }

  private URI getURI(final Endpoint endpoint) {
    return URI.create("http://localhost:" + localServerPort + BASE_PATH + endpoint.getPath());
  }

  private String buildJwtWithScope(final String scope) {
    return IntegrationTestJwtFactory.createJwtWithScope(scope, jwtSigningPrivateKey);
  }

  private String buildSavingsAppJwtWithSessionId(final String sessionId) {
    return IntegrationTestJwtFactory.createSavingsAppJwtWithSessionId(
        sessionId, jwtSigningPrivateKey);
  }

  private String buildSavingsAppJwtWithoutSessionId() {
    return IntegrationTestJwtFactory.createSavingsAppJwtWithoutSessionId(jwtSigningPrivateKey);
  }

  private Consumer<HttpHeaders> standardHeaders() {
    return headers -> {
      headers.setAccept(singletonList(MediaType.APPLICATION_JSON));
      headers.set(HEADER_REQUEST_ID, requestId.toString());
    };
  }

  private Consumer<HttpHeaders> standardHeaders(final String jwt) {
    return headers -> {
      standardHeaders().accept(headers);
      headers.setBearerAuth(jwt);
    };
  }

  private Consumer<HttpHeaders> standardHeaders(final Endpoint endpoint) {
    return headers -> {
      standardHeaders().accept(headers);
      if (endpoint.isRequiresAccessToken()) {
        final String jwt = buildJwtWithScope(SCOPE_ACCOUNT_READ);
        headers.setBearerAuth(jwt);
      }
    };
  }

  private ErrorResponse invalidRequestSignatureResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .errors(
            singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message("Access Denied")
                    .build()))
        .build();
  }

  private ErrorResponse accessDeniedResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .errors(
            singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build()))
        .build();
  }

  private ErrorResponse invalidSessionIdResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("400 Bad Request")
        .message("Bad Request")
        .errors(
            singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("SessionId is not a valid UUID")
                    .path(SessionIdSourceType.JWT.toString())
                    .build()))
        .build();
  }

  private ErrorResponse missingSessionIdResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("400 Bad Request")
        .message("Bad Request")
        .errors(
            singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("JWT does not contain a sessionId (sid) claim")
                    .path(SessionIdSourceType.JWT.toString())
                    .build()))
        .build();
  }

  private ErrorResponse accessDeniedResponseInvalidRequestSignature(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .errors(
            singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message("Access Denied")
                    .build()))
        .build();
  }

  private ErrorResponse unauthorizedResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("401 Unauthorized")
        .message("Unauthorized")
        .errors(
            singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Unauthorized")
                    .message("Unauthorized")
                    .build()))
        .build();
  }

  void setUpProduct(final boolean smartTiered) {
    transactionTemplate.executeWithoutResult(
        status -> {
          // create product - PRODUCT_IDENTIFIER
          final long productId = 1L;
          final uk.co.ybs.digital.product.model.Product product =
              testEntityManager.persistAndFlush(
                  uk.co.ybs.digital.product.model.Product.builder()
                      .sysid(productId)
                      .productIdentifier(PRODUCT_IDENTIFIER)
                      .startDate(LocalDateTime.parse("2019-07-11T00:00:00"))
                      .brandCode(BRAND_CODE_YBS)
                      .cardAvailable("N")
                      .fatcaReportable("Y")
                      .smartTiered(smartTiered)
                      .divisorDays(366)
                      .periodEndDate(LocalDateTime.parse("2021-08-31T00:00:00"))
                      .periodEndIndicator("P")
                      .penaltyCode(2)
                      .penaltyDays(30)
                      .build());

          setUpInterestTier(
              product,
              1L,
              new BigDecimal("0.00"),
              new BigDecimal("14999.99"),
              new BigDecimal("0.750"));
          setUpInterestTier(
              product,
              2L,
              new BigDecimal("15000.00"),
              new BigDecimal("999999999.99"),
              new BigDecimal("0.850"));

          setUpCharProductRule(product, AvailableProductRule.STOP_DEPOSITS_EXTERNAL, "N");
          setUpCharProductRule(product, AvailableProductRule.WEB_TRANSACTIONS, "Y");
          setUpProductRulesCommonToAllTests(product);
        });
  }

  void setUpProductWithRules(
      final boolean smartTiered, final Collection<ProductRule> productRules) {
    transactionTemplate.executeWithoutResult(
        status -> {
          // create product - PRODUCT_IDENTIFIER
          final long productId = 1L;
          final uk.co.ybs.digital.product.model.Product product =
              testEntityManager.persistAndFlush(
                  uk.co.ybs.digital.product.model.Product.builder()
                      .sysid(productId)
                      .productIdentifier(PRODUCT_IDENTIFIER)
                      .startDate(LocalDateTime.parse("2019-07-11T00:00:00"))
                      .brandCode(BRAND_CODE_YBS)
                      .cardAvailable("N")
                      .fatcaReportable("Y")
                      .smartTiered(smartTiered)
                      .divisorDays(366)
                      .periodEndDate(LocalDateTime.parse("2021-08-31T00:00:00"))
                      .periodEndIndicator("P")
                      .penaltyCode(2)
                      .penaltyDays(30)
                      .build());

          setUpInterestTier(
              product,
              1L,
              new BigDecimal("0.00"),
              new BigDecimal("14999.99"),
              new BigDecimal("0.750"));
          setUpInterestTier(
              product,
              2L,
              new BigDecimal("15000.00"),
              new BigDecimal("999999999.99"),
              new BigDecimal("0.850"));

          for (ProductRule productRule : productRules) {
            setUpProductRule(product, productRule);
          }

          setUpProductRulesCommonToAllTests(product);
        });
  }

  private void setUpProductRulesCommonToAllTests(
      final uk.co.ybs.digital.product.model.Product product) {
    setUpCharProductRule(product, AvailableProductRule.PRODUCT_TYPE, "ISA");
    setUpCharProductRule(product, AvailableProductRule.WEB_RETENTION, "Y");
    setUpCharProductRule(product, AvailableProductRule.EXISA, "Y");
    setUpCharProductRule(product, AvailableProductRule.EXBOND, "Y");
    setUpCharProductRule(product, AvailableProductRule.CUSTOMER_DESCRIPTION, "bar");
    setUpMoneyProductRule(product, AvailableProductRule.BALANCE_MINIMUM, new BigDecimal("-20"));
    setUpMoneyProductRule(product, AvailableProductRule.BALANCE_MAXIMUM, new BigDecimal("50"));
    setUpCharProductRule(product, AvailableProductRule.WEB_WITHDRAWALS, "Y");
    setUpNumberProductRule(product, AvailableProductRule.WITHDRAWAL_LIMIT_MONTH, 3L);
    setUpNumberProductRule(product, AvailableProductRule.WITHDRAWAL_LIMIT_YEAR, 40L);
    setUpNumberProductRule(product, AvailableProductRule.WITHDRAWAL_LIMIT_ANNIVERSARY_YEAR, 45L);
    setUpNumberProductRule(product, AvailableProductRule.WITHDRAWAL_LIMIT_TAX_YEAR, 50L);
    setUpNumberProductRule(product, AvailableProductRule.WITHDRAWAL_LIMIT_PRODUCT_TERM, 500L);
    setUpCharProductRule(product, AvailableProductRule.ALLOW_BANK_TRANSFER_DEPOSITS, "Y");
    setUpCharProductRule(product, AvailableProductRule.ALLOW_BRANCH_TRANSFERS, "Y");
    setUpMoneyProductRule(
        product, AvailableProductRule.DEPOSIT_LIMIT_FIRST_MONTH, new BigDecimal("50"));
    setUpMoneyProductRule(product, AvailableProductRule.DEPOSIT_LIMIT_MONTH, new BigDecimal("70"));
    setUpMoneyProductRule(product, AvailableProductRule.DEPOSIT_LIMIT_YEAR, new BigDecimal("4000"));
    setUpMoneyProductRule(
        product, AvailableProductRule.DEPOSIT_LIMIT_ANNIVERSARY_YEAR, new BigDecimal("4500"));
    setUpMoneyProductRule(
        product,
        AvailableProductRule.DEPOSIT_LIMIT_TAX_YEAR_PREFIX + CURRENT_TESSA_YEAR,
        new BigDecimal("5000"));
    setUpMoneyProductRule(
        product, AvailableProductRule.DEPOSIT_LIMIT_PRODUCT_TERM, new BigDecimal("50000"));

    setUpNumberProductRule(product, AvailableProductRule.PRODUCT_SUFFIX, 12L);
    setUpCharProductRule(product, AvailableProductRule.MIN_AGE, "17");
    setUpCharProductRule(product, AvailableProductRule.MAX_AGE, "75");
    setUpCharProductRule(product, AvailableProductRule.NI_NUMBER, "Y");

    setUpCharProductRule(product, AvailableProductRule.WEB_SALE, "Y");
    setUpCharProductRule(product, AvailableProductRule.ALLOWABLE_INTEREST_INSTR, "1");

    setUpCharProductRule(product, AvailableProductRule.ISA_FLEXIBLE, "N");
    setUpCharProductRule(product, AvailableProductRule.ISA_HELP_TO_BUY, "Y");

    setUpNumberProductRule(product, AvailableProductRule.EXTERNAL_BENEFICIARIES, 10L);
    setUpNumberProductRule(product, AvailableProductRule.INTERNAL_BENEFICIARIES, 20L);
    setUpCharProductRule(product, AvailableProductRule.KYC_COLLECTION, "Y");
  }

  private void setUpInterestTier(
      final uk.co.ybs.digital.product.model.Product product,
      final Long sysid,
      final BigDecimal rangeLow,
      final BigDecimal rangeHigh,
      final BigDecimal interestRate) {
    testEntityManager.persistAndFlush(
        uk.co.ybs.digital.product.model.InterestTier.builder()
            .sysid(sysid)
            .product(product)
            .startDate(currentTimeToTheSecond())
            .interestRate(interestRate)
            .rangeLow(rangeLow)
            .rangeHigh(rangeHigh)
            .build());
  }

  private void setUpCharProductRule(
      final uk.co.ybs.digital.product.model.Product product,
      final String availableProductRuleCode,
      final String value) {
    final AvailableProductRule availableProductRule =
        setUpAvailableProductRule(availableProductRuleCode, AvailableProductRule.ValueType.CHAR);
    testEntityManager.persistAndFlush(
        ProductRule.builder(product, availableProductRule, currentTimeToTheSecond())
            .charValue(value)
            .build());
  }

  private void setUpMoneyProductRule(
      final uk.co.ybs.digital.product.model.Product product,
      final String availableProductRuleCode,
      final BigDecimal value) {
    final AvailableProductRule availableProductRule =
        setUpAvailableProductRule(availableProductRuleCode, AvailableProductRule.ValueType.MONEY);
    testEntityManager.persistAndFlush(
        ProductRule.builder(product, availableProductRule, currentTimeToTheSecond())
            .moneyValue(value)
            .build());
  }

  private void setUpNumberProductRule(
      final uk.co.ybs.digital.product.model.Product product,
      final String availableProductRuleCode,
      final Long value) {
    final AvailableProductRule availableProductRule =
        setUpAvailableProductRule(availableProductRuleCode, AvailableProductRule.ValueType.NUMBER);
    testEntityManager.persistAndFlush(
        ProductRule.builder(product, availableProductRule, currentTimeToTheSecond())
            .numberValue(value)
            .build());
  }

  private void setUpProductRule(
      final uk.co.ybs.digital.product.model.Product product, final ProductRule productRule) {
    testEntityManager.persistAndFlush(
        ProductRule.builder(
                product,
                setUpAvailableProductRule(productRule.getAvailableProductRule()),
                currentTimeToTheSecond())
            .charValue(productRule.getCharValue())
            .numberValue(productRule.getNumberValue())
            .moneyValue(productRule.getMoneyValue())
            .build());
  }

  private AvailableProductRule setUpAvailableProductRule(
      final String code, final AvailableProductRule.ValueType valueType) {
    return testEntityManager.persistAndFlush(
        AvailableProductRule.builder().code(code).valueType(valueType).build());
  }

  private AvailableProductRule setUpAvailableProductRule(
      final AvailableProductRule availableProductRule) {
    return testEntityManager.persistAndFlush(availableProductRule);
  }

  private LocalDateTime currentTimeToTheSecond() {
    return LocalDateTime.now(clock).withNano(0);
  }

  private ProductDetailsResponse expectedProductDetailsResponse() {
    return expectedProductDetailsResponse(buildExpectedDeposits());
  }

  private ProductDetailsResponse expectedProductDetailsResponse(final Deposits expectedDeposits) {
    final ProductDetailsResponse.ProductDetailsResponseBuilder<?, ?> builder =
        ProductDetailsResponse.builder();
    populateProductDetailsResponseBase(builder, expectedDeposits);
    return builder
        .smartTiered(true)
        .withdrawals(
            Withdrawals.builder()
                .permittedOverWeb(false)
                .limits(
                    Withdrawals.WithdrawalLimits.builder()
                        .number(
                            PeriodLimits.<Long>builder()
                                .month(3L)
                                .year(40L)
                                .anniversaryYear(45L)
                                .taxYear(50L)
                                .productTerm(500L)
                                .build())
                        .build())
                .build())
        .interest(
            uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.builder()
                .interestPaid(InterestPaidType.ANNUALLY)
                .tiers(buildInterestTiers())
                .permittedInterestDestinations(singletonList(InterestDestinationType.selfCredit))
                .build())
        .isa(ProductDetailsResponse.Isa.builder().flexible(false).helpToBuy(true).build())
        .build();
  }

  private ProductDetailsResponsePrivate expectedProductDetailsResponsePrivate() {
    return expectedProductDetailsResponsePrivate(buildExpectedDeposits());
  }

  private ProductDetailsResponsePrivate expectedProductDetailsResponsePrivate(
      final Deposits expectedDeposits) {
    return expectedProductDetailsResponsePrivate(expectedDeposits, true);
  }

  private ProductDetailsResponsePrivate expectedProductDetailsResponsePrivate(
      final Deposits expectedDeposits, final boolean withdrawalsPermittedOnClosure) {
    final ProductDetailsResponsePrivate.ProductDetailsResponsePrivateBuilder<?, ?> builder =
        ProductDetailsResponsePrivate.builder();
    populateProductDetailsResponseBase(builder, expectedDeposits);
    return builder
        .smartTiered(false)
        .productSysId(1L)
        .startDate(LocalDateTime.parse("2019-07-11T00:00:00"))
        .withdrawals(
            WithdrawalsPrivate.builder()
                .interestPenalty(
                    WithdrawalsPrivate.InterestPenalty.builder().code(2).days(30).build())
                .permittedOverWeb(false)
                .permittedOverWebOnAccountClosure(withdrawalsPermittedOnClosure)
                .limits(
                    Withdrawals.WithdrawalLimits.builder()
                        .number(
                            PeriodLimits.<Long>builder()
                                .month(3L)
                                .year(40L)
                                .anniversaryYear(45L)
                                .taxYear(50L)
                                .productTerm(500L)
                                .build())
                        .build())
                .build())
        .interest(
            InterestPrivate.builder()
                .divisorDays(366)
                .periodEndDate(LocalDateTime.parse("2021-08-31T00:00:00"))
                .periodEndIndicator("P")
                .interestPaid(InterestPaidType.ANNUALLY)
                .tiers(buildInterestTiers())
                .permittedInterestDestinations(singletonList(InterestDestinationType.selfCredit))
                .webAmendmentsPermitted(false)
                .build())
        .isa(
            ProductDetailsResponsePrivate.IsaPrivate.builder()
                .flexible(false)
                .helpToBuy(true)
                .isaYear(CURRENT_TESSA_YEAR)
                .build())
        .beneficiaries(
            ProductDetailsResponsePrivate.Beneficiaries.builder()
                .external(10L)
                .internal(20L)
                .build())
        .build();
  }

  @SneakyThrows
  private void stubOnSaleProductsYbsSiteResponse(final ClassPathResource response) {

    LiferayDocument liferayDocument =
        LiferayDocument.builder()
            .contentValue(
                new String(Base64.getEncoder().encode(readClassPathResource(response).getBytes())))
            .build();

    mockLiferay.enqueue(
        new MockResponse()
            .setHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
            .setBody(objectMapper.writeValueAsString(liferayDocument)));
  }

  private void doGetOnSaleProducts(
      final Endpoint endpoint, final List<ProductCategory> expectedResponse) {
    getWebClient(endpoint)
        .get()
        .uri(getURI(endpoint))
        .headers(standardHeaders(endpoint))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(ProductCategory.class)
        .isEqualTo(expectedResponse);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private Product buildProductDto(
      final String productName,
      final ProductType productType,
      final String productId,
      final String productCode,
      final Integer minimumAge,
      final Integer maximumAge,
      final Integer maximumNumberOfAccounts,
      final boolean loyalty,
      final InterestFrequency interestFrequency,
      final List<InterestTier> tiers,
      final List<String> facts) {
    return Product.builder()
        .name(productName)
        .type(productType)
        .url(String.format("http://localhost:%d/product.html?id=%s", testPort, productId))
        .productCode(productCode)
        .interestTiers(tiers)
        .facts(buildFacts(facts))
        .minimumAge(minimumAge)
        .maximumAge(maximumAge)
        .maximumNumberOfAccounts(maximumNumberOfAccounts)
        .loyalty(loyalty)
        .interestFrequency(interestFrequency)
        .build();
  }

  private ProductCategory buildProductCategory(
      final ProductCategoryType type,
      final String url,
      final boolean offlineAvailable,
      final List<Product> products,
      final List<Product> unavailableProducts) {
    return ProductCategory.builder()
        .title(type.getTitle())
        .subTitle(type.getSubTitle())
        .description(type.getDescription())
        .url(url)
        .offlineOnlyProductsAvailable(offlineAvailable)
        .products(products)
        .unavailableProducts(unavailableProducts)
        .build();
  }

  private List<Fact> buildFacts(final List<String> facts) {
    return facts.stream()
        .map(fact -> Fact.builder().text(fact).build())
        .collect(Collectors.toList());
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  private List<ProductCategory> buildAvailableProductCategory() {
    final Product easyISA =
        buildProductDto(
            "Six Access e-Saver ISA Issue 3",
            ProductType.ISA,
            "YB851266W",
            "YB851266W",
            MINIMUM_CUSTOMER_AGE_16,
            MAXIMUM_CUSTOMER_AGE_99,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.20%")
                    .range("£1.00 - £999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("1.00%")
                    .range("£1,000.00 - £10,000.49")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.50%")
                    .range("£10,000.50 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.55%")
                    .range("£50,000.00+")
                    .build()),
            asList(
                "Save from £1 in this Cash ISA",
                "Four tiered interest rates - rate depends on account balance",
                "Cash ISA pays Annual interest",
                "Allows withdrawals on six days per year"));

    final Product easyInternetSaverPlus =
        buildProductDto(
            "Internet Saver Plus Issue 9",
            ProductType.EASY_ACCESS,
            PRODUCT_SUMMARY_IDENTIFIER_EASYACCESS,
            PRODUCT_SUMMARY_IDENTIFIER_EASYACCESS,
            MINIMUM_CUSTOMER_AGE_16,
            null,
            null,
            false,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("0.40%")
                    .range("£1.00 - £999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("0.43%")
                    .range("£1,000.00 - £9,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("0.45%")
                    .range("£10,000.00 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("0.50%")
                    .range("£50,000.00+")
                    .build()),
            asList(
                "Save from £1",
                "Four tiered interest rates - rate depends on account balance",
                "Annual interest",
                "Unlimited withdrawals"));

    final Product easyInternetSaverISAPlus =
        buildProductDto(
            "Internet Saver ISA Plus Issue 9",
            ProductType.ISA,
            "YB691430W",
            "YB691430W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.15%")
                    .range("£1.00 - £999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.25%")
                    .range("£1,000.00 - £9,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.35%")
                    .range("£10,000.00 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.45%")
                    .range("£50,000.00 - £79,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.55%")
                    .range("£80,000.00 - £99,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.65%")
                    .range("£100,000.00 - £149,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.75%")
                    .range("£150,000.00+")
                    .build()),
            asList(
                "Save from £1 in this Cash ISA",
                "Seven tiered interest rates - rate depends on account balance",
                "Cash ISA pays Annual interest",
                "Unlimited withdrawals"));

    final Product easyRainyDayAccount =
        buildProductDto(
            "Online Rainy Day Account",
            ProductType.EASY_ACCESS,
            "YB931418W",
            "YB931418W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            MAXIMUM_NUMBER_OF_ACCOUNTS_1,
            false,
            InterestFrequency.ANNUAL,
            singletonList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable")
                    .rate("0.52%")
                    .build()),
            asList(
                "Save from £10",
                "Interest will be paid annually",
                "Allows withdrawals on one day per year based on the anniversary of the account opening date, plus closure at any time if required"));
    final Product easyInternetSaverPlusLoyalty =
        buildProductDto(
            "Loyalty Saver",
            ProductType.EASY_ACCESS,
            "YB681499W",
            "YB681499W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            1,
            true,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("1.00%")
                    .range("£1,000.00 - £24,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("1.05%")
                    .range("£25,000.00 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Gross p.a./AER variable on balances of")
                    .rate("1.15%")
                    .range("£50,000.00+")
                    .build()),
            asList(
                "Membership eligibility criteria applies for this 1 year Cash ISA and Save from £10",
                "Three tiered interest rates and interest paid annually",
                "Withdrawals on 6 days/year & closure at any time - Use the ISA transfer process to keep tax-free status"));

    final Product loyaltySixAccessSaverEIsaAccount =
        buildProductDto(
            "Loyalty Six Access Saver ISA Issue 2",
            ProductType.ISA,
            "YB941511W",
            "YB941511W",
            MINIMUM_CUSTOMER_AGE_16,
            null,
            1,
            true,
            InterestFrequency.ANNUAL,
            asList(
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("1.00%")
                    .range("£1,000.00 - £24,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("1.05%")
                    .range("£25,000.00 - £49,999.99")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("1.15%")
                    .range("£50,000.00+")
                    .build()),
            asList(
                "Membership eligibility criteria applies for this 1 year Cash ISA and Save from £1",
                "Three tiered interest rates and interest paid annually",
                "Withdrawals on 6 days/year & closure at any time - Use the ISA transfer process to keep tax-free status"));

    return asList(
        buildProductCategory(
            ProductCategoryType.EASY_ACCESS,
            String.format(
                "http://localhost:%d/easy-access/index.html?display=allWaysToApply", testPort),
            true,
            asList(
                buildProductDto(
                    "Six Access e-Saver Issue 4",
                    ProductType.EASY_ACCESS,
                    "YB841278W",
                    "YB841278W",
                    MINIMUM_CUSTOMER_AGE_16,
                    MAXIMUM_CUSTOMER_AGE_99,
                    MAXIMUM_NUMBER_OF_ACCOUNTS_1,
                    false,
                    InterestFrequency.ANNUAL,
                    asList(
                        InterestTier.builder()
                            .description("Gross p.a./AER variable on balances of")
                            .rate("0.15%")
                            .range("£1.00 - £999.99")
                            .build(),
                        InterestTier.builder()
                            .description("Gross p.a./AER variable on balances of")
                            .rate("0.25%")
                            .range("£1,000.00 - £9,999.99")
                            .build(),
                        InterestTier.builder()
                            .description("Gross p.a./AER variable on balances of")
                            .rate("0.40%")
                            .range("£10,000.00 - £49,999.99")
                            .build(),
                        InterestTier.builder()
                            .description("Gross p.a./AER variable on balances of")
                            .rate("0.45%")
                            .range("£50,000.00+")
                            .build()),
                    asList(
                        "Save from £1",
                        "Four tiered interest rates - rate depends on account balance",
                        "Annual interest",
                        "Allows withdrawals on six days per year plus closure")),
                easyISA,
                easyInternetSaverPlus,
                easyInternetSaverISAPlus,
                easyRainyDayAccount,
                easyInternetSaverPlusLoyalty,
                loyaltySixAccessSaverEIsaAccount),
            emptyList()),
        buildProductCategory(
            ProductCategoryType.FIXED_BOND,
            String.format(
                "http://localhost:%d/fixed-rate-bonds/index.html?display=allWaysToApply", testPort),
            true,
            asList(
                buildProductDto(
                    "Fixed Rate Bond until 31/12/2021",
                    ProductType.BOND,
                    "YB271280W",
                    "YB271280W",
                    MINIMUM_CUSTOMER_AGE_16,
                    null,
                    null,
                    false,
                    InterestFrequency.ANNUAL,
                    singletonList(
                        InterestTier.builder()
                            .description("Gross p.a./AER fixed")
                            .rate("0.50%")
                            .build()),
                    asList("Save from £1,000", "Annual interest", "Withdrawals not permitted")),
                buildProductDto(
                    "Fixed Rate Bond until 31/12/2022",
                    ProductType.BOND,
                    "YB271269W",
                    "YB271269W",
                    MINIMUM_CUSTOMER_AGE_16,
                    null,
                    null,
                    false,
                    InterestFrequency.ANNUAL,
                    singletonList(
                        InterestTier.builder()
                            .description("Gross p.a./AER fixed")
                            .rate("0.65%")
                            .build()),
                    asList("Save from £1,000", "Annual interest", "Withdrawals not permitted")),
                buildProductDto(
                    "Fixed Rate Bond until 31/12/2023",
                    ProductType.BOND,
                    "YB271270W",
                    "YB271270W",
                    MINIMUM_CUSTOMER_AGE_16,
                    null,
                    null,
                    false,
                    InterestFrequency.ANNUAL,
                    singletonList(
                        InterestTier.builder()
                            .description("Gross p.a./AER fixed")
                            .rate("0.65%")
                            .build()),
                    asList("Save from £1,000", "Annual interest", "Withdrawals not permitted")),
                buildProductDto(
                    "Loyalty Fixed Rate Bond (No Access) until 31/01/2024",
                    ProductType.BOND,
                    "YB131540B",
                    "YB131540B",
                    MINIMUM_CUSTOMER_AGE_16,
                    null,
                    null,
                    true,
                    InterestFrequency.ANNUAL,
                    singletonList(
                        InterestTier.builder()
                            .description("Gross p.a./AER fixed")
                            .rate("2.10%")
                            .build()),
                    asList(
                        "Loyalty eligibility criteria applies",
                        "Save from £1,000",
                        "Interest paid on 31 January 2024",
                        "Withdrawals and closure not permitted"))),
            emptyList()),
        buildProductCategory(
            ProductCategoryType.ISA_FIXED,
            String.format("http://localhost:%d/isas/index.html?display=fixedRate", testPort),
            false,
            asList(
                buildProductDto(
                    "Fixed Rate ISA until 31/12/2021",
                    ProductType.ISA,
                    "YB291271W",
                    "YB291271W",
                    MINIMUM_CUSTOMER_AGE_16,
                    null,
                    null,
                    false,
                    InterestFrequency.ANNUAL,
                    singletonList(
                        InterestTier.builder()
                            .description("Tax-free p.a./AER fixed")
                            .rate("0.55%")
                            .build()),
                    asList(
                        "Save from £100 in this Cash ISA",
                        "Cash ISA pays Annual interest",
                        "Withdrawals not permitted",
                        "Closure permitted with 60 days' loss of interest",
                        "You can transfer your ISA from another provider")),
                buildProductDto(
                    "Fixed Rate ISA until 31/12/2022",
                    ProductType.ISA,
                    "YB291272W",
                    "YB291272W",
                    MINIMUM_CUSTOMER_AGE_16,
                    null,
                    null,
                    false,
                    InterestFrequency.ANNUAL,
                    singletonList(
                        InterestTier.builder()
                            .description("Tax-free p.a./AER fixed")
                            .rate("0.60%")
                            .build()),
                    asList(
                        "Save from £100 in this Cash ISA",
                        "Cash ISA pays Annual interest",
                        "Withdrawals not permitted",
                        "Closure permitted with 120 days' loss of interest",
                        "You can transfer your ISA from another provider")),
                buildProductDto(
                    "Fixed Rate ISA until 31/12/2023",
                    ProductType.ISA,
                    "YB291273W",
                    "YB291273W",
                    MINIMUM_CUSTOMER_AGE_16,
                    null,
                    null,
                    false,
                    InterestFrequency.ANNUAL,
                    singletonList(
                        InterestTier.builder()
                            .description("Tax-free p.a./AER fixed")
                            .rate("0.60%")
                            .build()),
                    asList(
                        "Save from £100 in this Cash ISA",
                        "Cash ISA pays Annual interest",
                        "Withdrawals not permitted",
                        "Closure permitted with 180 days' loss of interest",
                        "You can transfer your ISA from another provider")),
                buildProductDto(
                    "Fixed Rate eISA until 31/10/2022",
                    ProductType.ISA,
                    PRODUCT_SUMMARY_IDENTIFIER,
                    PRODUCT_SUMMARY_IDENTIFIER,
                    MINIMUM_CUSTOMER_AGE_16,
                    null,
                    null,
                    false,
                    InterestFrequency.ANNUAL,
                    singletonList(
                        InterestTier.builder()
                            .description("Tax-free p.a./AER fixed")
                            .rate("1.00%")
                            .build()),
                    asList(
                        "Save from £100 in this Cash ISA",
                        "Cash ISA pays Annual interest",
                        "Withdrawals not permitted",
                        "Closure permitted with 60 days' loss of interest",
                        "You can transfer your ISA from another provider"))),
            emptyList()),
        buildProductCategory(
            ProductCategoryType.ISA_VARIABLE,
            String.format("http://localhost:%d/isas/index.html?display=variableRate", testPort),
            true,
            asList(easyISA, easyInternetSaverISAPlus, loyaltySixAccessSaverEIsaAccount),
            emptyList()),
        buildProductCategory(
            ProductCategoryType.CHILDRENS,
            String.format(
                "http://localhost:%d/childrens-savings/index.html?display=allWaysToApply",
                testPort),
            true,
            emptyList(),
            emptyList()));
  }

  private void tearDownDb() {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager coreEntityManager = testEntityManager.getEntityManager();
          coreEntityManager.createQuery("delete from ProductRule").executeUpdate();
          coreEntityManager.createQuery("delete from AvailableProductRule").executeUpdate();
          coreEntityManager.createQuery("delete from InterestTier ").executeUpdate();
          coreEntityManager.createQuery("delete from Product").executeUpdate();
        });
  }

  @AllArgsConstructor
  @Getter
  private enum Endpoint {
    GET_PRODUCT(PRODUCT_ENDPOINT + PRODUCT_IDENTIFIER, Type.PUBLIC, true),
    PRIVATE_GET_PRODUCT(PRODUCT_PRIVATE_ENDPOINT + PRODUCT_IDENTIFIER, Type.PRIVATE, true),
    PRIVATE_GET_AVAILABLE_PRODUCTS(AVAILABLE_PRODUCTS_PRIVATE_ENDPOINT, Type.PRIVATE, true),
    SEARCH_PRODUCT(
        SEARCH_PRODUCT_ENDPOINT + "page=0&size=2&productIdentifiers=" + PRODUCT_IDENTIFIER,
        Type.PUBLIC,
        true),
    PRIVATE_SEARCH_PRODUCT(
        PRIVATE_SEARCH_PRODUCT_ENDPOINT + "page=0&size=2&productIdentifiers=" + PRODUCT_IDENTIFIER,
        Type.PRIVATE,
        true),
    GET_ON_SALE_PRODUCTS(ON_SALE_PRODUCTS_ENDPOINT, Type.PUBLIC, false),
    PRIVATE_GET_ON_SALE_PRODUCTS(ON_SALE_PRODUCTS_PRIVATE_ENDPOINT, Type.PRIVATE, false),
    GET_ON_SALE_PRODUCTS_SUMMARY(
        ON_SALE_PRODUCTS_ENDPOINT + "/" + PRODUCT_SUMMARY_IDENTIFIER + "/summary",
        Type.PUBLIC,
        false),
    GET_ON_SALE_PRODUCTS_SUMMARY_EASYACCESS(
        ON_SALE_PRODUCTS_ENDPOINT + "/" + PRODUCT_SUMMARY_IDENTIFIER_EASYACCESS + "/summary",
        Type.PUBLIC,
        false),
    GET_REINVESTMENT_PRODUCTS(
        PRODUCT_PRIVATE_ENDPOINT + PRODUCT_IDENTIFIER + "/" + REINVEST_PRIVATE_ENDPOINT,
        Type.PRIVATE,
        true);

    private final String path;
    private final Type type;
    private final boolean requiresAccessToken;

    private enum Type {
      PUBLIC,
      PRIVATE
    }
  }

  @EnumSource(
      value = Endpoint.class,
      mode = EnumSource.Mode.EXCLUDE,
      names = {
        GET_ON_SALE_PRODUCTS_ENDPOINT,
        PRIVATE_GET_ON_SALE_PRODUCTS_ENDPOINT,
        PRIVATE_GET_AVAILABLE_PRODUCTS_ENDPOINT,
        GET_ON_SALE_PRODUCTS_SUMMARY_ENDPOINT,
        GET_ON_SALE_PRODUCTS_SUMMARY_EASYACCESS_ENDPOINT,
      })
  @Target(ElementType.METHOD)
  @Retention(RetentionPolicy.RUNTIME)
  private @interface EndpointsRequiringAccessTokenSource {}
}
