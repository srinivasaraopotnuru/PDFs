package uk.co.ybs.digital.product.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import java.time.Month;
import org.junit.jupiter.api.Test;

class TessaYearCalculatorTest {

  private final TessaYearCalculator testSubject = new TessaYearCalculator();

  @Test
  void shouldCalculateYear20() {
    final LocalDateTime start = LocalDateTime.of(2018, Month.APRIL, 6, 0, 0, 0);
    final LocalDateTime end = LocalDateTime.of(2019, Month.MARCH, 5, 23, 59, 59);

    assertThat(testSubject.getTessaYear(start), is(20));
    assertThat(testSubject.getTessaYear(end), is(20));
  }

  @Test
  void shouldCalculateYear21() {
    final LocalDateTime start = LocalDateTime.of(2019, Month.APRIL, 6, 0, 0, 0);
    final LocalDateTime end = LocalDateTime.of(2020, Month.MARCH, 5, 23, 59, 59);

    assertThat(testSubject.getTessaYear(start), is(21));
    assertThat(testSubject.getTessaYear(end), is(21));
  }

  @Test
  void shouldCalculateYear22() {
    final LocalDateTime start = LocalDateTime.of(2020, Month.APRIL, 6, 0, 0, 0);
    final LocalDateTime end = LocalDateTime.of(2021, Month.MARCH, 5, 23, 59, 59);

    assertThat(testSubject.getTessaYear(start), is(22));
    assertThat(testSubject.getTessaYear(end), is(22));
  }
}
