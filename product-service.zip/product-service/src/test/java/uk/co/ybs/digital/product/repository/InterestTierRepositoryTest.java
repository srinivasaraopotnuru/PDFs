package uk.co.ybs.digital.product.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.test.context.ActiveProfiles;
import uk.co.ybs.digital.product.config.ProductServiceConfig;
import uk.co.ybs.digital.product.model.InterestTier;
import uk.co.ybs.digital.product.model.Product;

@DataJpaTest
@ActiveProfiles({"test", "text-logging"})
@Import({ProductServiceConfig.class, InterestTierRepositoryTest.TestClockConfig.class})
class InterestTierRepositoryTest {

  private static final ZoneId ZONE_ID = ZoneId.of("Europe/London");
  private static final Instant NOW_INSTANT = Instant.parse("2020-04-23T13:56:15Z");
  private static final LocalDateTime NOW = LocalDateTime.ofInstant(NOW_INSTANT, ZONE_ID);

  private static final Long PRODUCT_SYSID_1 = 1L;
  private static final Long PRODUCT_SYSID_2 = 2L;

  @Autowired private InterestTierRepository testSubject;

  @Autowired private TestEntityManager testEntityManager;

  @Test
  void findByIdShouldReturnInterestTier() {
    final Product product = buildProduct(PRODUCT_SYSID_1);
    final InterestTier tier =
        buildInterestTier(
            1L,
            product,
            new BigDecimal("1.23"),
            new BigDecimal("4.56"),
            NOW,
            null,
            new BigDecimal("1.00"));
    persist(product, tier);

    final Optional<InterestTier> found = testSubject.findById(1L);
    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(tier));
    assertThat(found.get(), samePropertyValuesAs(tier));
  }

  @Test
  void findAllActiveShouldReturnInterestTiers() {
    final Product product1 = buildProduct(PRODUCT_SYSID_1);
    final InterestTier tier1a =
        buildInterestTier(
            1L,
            product1,
            new BigDecimal("1.23"),
            new BigDecimal("4.56"),
            NOW,
            null,
            new BigDecimal("1.00"));
    final InterestTier tier1b =
        buildInterestTier(
            2L,
            product1,
            new BigDecimal("2.23"),
            new BigDecimal("5.56"),
            NOW,
            null,
            new BigDecimal("2.00"));
    final InterestTier tier1c =
        buildInterestTier(
            3L,
            product1,
            new BigDecimal("3.23"),
            new BigDecimal("6.56"),
            NOW,
            null,
            new BigDecimal("3.00"));

    final Product product2 = buildProduct(PRODUCT_SYSID_2);
    final InterestTier tier2a =
        buildInterestTier(
            4L,
            product1,
            new BigDecimal("4.23"),
            new BigDecimal("7.56"),
            NOW,
            null,
            new BigDecimal("4.00"));
    final InterestTier tier2b =
        buildInterestTier(
            5L,
            product1,
            new BigDecimal("5.23"),
            new BigDecimal("8.56"),
            NOW,
            null,
            new BigDecimal("5.00"));

    persist(product1, tier1a, tier1b, tier1c, product2, tier2a, tier2b);

    final Collection<InterestTier> tiers =
        testSubject.findAllActive(Arrays.asList(PRODUCT_SYSID_1, PRODUCT_SYSID_2), NOW);
    assertThat(tiers, containsInAnyOrder(tier1a, tier1b, tier1c, tier2a, tier2b));
    assertThat(
        tiers,
        containsInAnyOrder(
            samePropertyValuesAs(tier1a),
            samePropertyValuesAs(tier1b),
            samePropertyValuesAs(tier1c),
            samePropertyValuesAs(tier2a),
            samePropertyValuesAs(tier2b)));
  }

  @ParameterizedTest
  @CsvSource({"1,true", "2,false"})
  void findAllActiveShouldFilterByProduct(final Long productSysid, final boolean expectFind) {
    findAllActiveShouldFilter(productSysid, NOW, null, expectFind);
  }

  @ParameterizedTest
  @CsvSource({"-100,true", "-2,true", "-1,true", "0,true", "1,false", "2,false", "100,false"})
  void findAllActiveShouldFilterByStartDate(
      final Long startDateAdjustmentSeconds, final boolean expectFind) {
    findAllActiveShouldFilter(
        PRODUCT_SYSID_1, NOW.plusSeconds(startDateAdjustmentSeconds), null, expectFind);
  }

  @ParameterizedTest
  @CsvSource(
      value = {
        "-100,false",
        "-2,false",
        "-1,false",
        "0,false",
        "1,true",
        "2,true",
        "100,true",
        "null,true"
      },
      nullValues = "null")
  void findAllActiveShouldFilterByEndDate(
      final Long endDateAdjustmentSeconds, final boolean expectFind) {
    final LocalDateTime endDate =
        endDateAdjustmentSeconds == null ? null : NOW.plusSeconds(endDateAdjustmentSeconds);
    findAllActiveShouldFilter(PRODUCT_SYSID_1, NOW, endDate, expectFind);
  }

  private void findAllActiveShouldFilter(
      final Long productSysid,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final boolean expectFind) {
    final Product product = buildProduct(productSysid);
    final InterestTier tier =
        buildInterestTier(
            1L,
            product,
            new BigDecimal("1.23"),
            new BigDecimal("4.56"),
            startDate,
            endDate,
            new BigDecimal("1.00"));
    persist(product, tier);

    final Collection<InterestTier> tiers =
        testSubject.findAllActive(Collections.singletonList(PRODUCT_SYSID_1), NOW);
    if (expectFind) {
      assertThat(tiers, containsInAnyOrder(tier));
    } else {
      assertThat(tiers, is(empty()));
    }
  }

  private void persist(final Object... objects) {
    for (final Object object : objects) {
      testEntityManager.persist(object);
    }
    testEntityManager.flush();
    testEntityManager.clear();
  }

  private Product buildProduct(final Long sysId) {
    return Product.builder()
        .sysid(sysId)
        .startDate(NOW)
        .divisorDays(365)
        .penaltyCode(2)
        .penaltyDays(30)
        .periodEndIndicator("P")
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private InterestTier buildInterestTier(
      final Long sysid,
      final Product product,
      final BigDecimal rangeLow,
      final BigDecimal rangeHigh,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final BigDecimal interestRate) {
    return InterestTier.builder()
        .sysid(sysid)
        .product(product)
        .rangeLow(rangeLow)
        .rangeHigh(rangeHigh)
        .startDate(startDate)
        .endDate(endDate)
        .interestRate(interestRate)
        .build();
  }

  static class TestClockConfig {
    @Primary
    @Bean
    public Clock testClock() {
      return Clock.fixed(NOW_INSTANT, ZONE_ID);
    }
  }
}
