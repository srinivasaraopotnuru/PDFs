package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

public class InterestRangeMapperTest {

  private static final String FAMILY_SAVINGS_ACCOUNT_NAME_SHORT = "Family eSavings Account";
  private static final String ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT = "Online Rainy Day Account";
  private static final String ACCOUNT_SHORT_NAME = "accountShortName";

  private final InterestRangeMapper testSubject = new InterestRangeMapper();

  @ParameterizedTest
  @MethodSource("mappingValues")
  void shouldMap(
      final boolean tiered,
      final String minTierValue,
      final String nextTierValue,
      final String accountShortName,
      final int index,
      final String expected) {
    final String range =
        testSubject.map(tiered, false, minTierValue, nextTierValue, accountShortName, index);
    assertThat(range, is(expected));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> mappingValues() {
    return Stream.of(
        Arguments.of(true, "1", null, ACCOUNT_SHORT_NAME, 0, "£1.00+"),
        Arguments.of(true, "0", null, ACCOUNT_SHORT_NAME, 0, "£0.00+"),
        Arguments.of(true, "1000", null, ACCOUNT_SHORT_NAME, 0, "£1,000.00+"),
        Arguments.of(true, "1", "100", ACCOUNT_SHORT_NAME, 0, "£1.00 - £99.99"),
        Arguments.of(true, "0", "10", ACCOUNT_SHORT_NAME, 0, "£0.00 - £9.99"),
        Arguments.of(true, "1000", "20000", ACCOUNT_SHORT_NAME, 0, "£1,000.00 - £19,999.99"),
        Arguments.of(true, "500000", "1000000", ACCOUNT_SHORT_NAME, 0, "£500,000.00 - £999,999.99"),
        Arguments.of(false, "1", null, ACCOUNT_SHORT_NAME, 0, ""),
        Arguments.of(false, "1", "100", ACCOUNT_SHORT_NAME, 0, ""),
        Arguments.of(false, null, null, ACCOUNT_SHORT_NAME, 0, ""),
        Arguments.of(false, null, "100", ACCOUNT_SHORT_NAME, 0, ""),
        Arguments.of(true, "1", "100", FAMILY_SAVINGS_ACCOUNT_NAME_SHORT, 0, "£99.99"),
        Arguments.of(true, "100", "200", FAMILY_SAVINGS_ACCOUNT_NAME_SHORT, 1, "£100.00 - £199.99"),
        Arguments.of(true, "200", null, FAMILY_SAVINGS_ACCOUNT_NAME_SHORT, 2, "£200.00"),
        Arguments.of(true, "1", "5000.01", ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT, 0, "£5,000.00"),
        Arguments.of(true, "5000.01", null, ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT, 2, "£5,000.01"));
  }
}
