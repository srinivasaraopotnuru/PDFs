package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.sameInstance;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestDestinationType;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestPaidType;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.Tier;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.InterestPrivate;

@ExtendWith(MockitoExtension.class)
class InterestMapperTest {

  @InjectMocks private InterestMapper testSubject;

  @Mock private InterestPaidMapper interestPaidMapper;

  @Mock private PermittedInterestDestinationsMapper permittedInterestDestinationsMapper;

  @Mock private InterestTiersMapper interestTiersMapper;

  @Mock private WebAmendmentsMapper webAmendmentsMapper;

  @Test
  void shouldMap() {
    final Product product = Product.builder().build();
    final InterestPaidType interestPaidType = InterestPaidType.MONTHLY;
    when(interestPaidMapper.map(same(product))).thenReturn(interestPaidType);

    final ActiveProductRules activeProductRules = new ActiveProductRules(Collections.emptyList());
    final List<InterestDestinationType> permittedInterestDestinations = new ArrayList<>();
    when(permittedInterestDestinationsMapper.map(same(activeProductRules)))
        .thenReturn(permittedInterestDestinations);

    final List<Tier> tiers = new ArrayList<>();
    when(interestTiersMapper.map(same(product))).thenReturn(tiers);

    final Interest interest = testSubject.map(product, activeProductRules);
    assertThat(interest.getInterestPaid(), sameInstance(interestPaidType));
    assertThat(
        interest.getPermittedInterestDestinations(), sameInstance(permittedInterestDestinations));
    assertThat(interest.getTiers(), sameInstance(tiers));
  }

  @Test
  void shouldMapPrivate() {
    final String periodEndIndicator = "P";
    final LocalDateTime periodEndDate = LocalDateTime.parse("2021-08-31T00:00:00");
    final int divisorDays = 366;
    final int previousDivisorDays = 365;

    final Product product =
        Product.builder()
            .periodEndIndicator(periodEndIndicator)
            .periodEndDate(periodEndDate)
            .divisorDays(divisorDays)
            .previousDivisorDays(previousDivisorDays)
            .build();
    final InterestPaidType interestPaidType = InterestPaidType.MONTHLY;
    when(interestPaidMapper.map(same(product))).thenReturn(interestPaidType);

    final ActiveProductRules activeProductRules = new ActiveProductRules(Collections.emptyList());
    final List<InterestDestinationType> permittedInterestDestinations = new ArrayList<>();
    when(permittedInterestDestinationsMapper.map(same(activeProductRules)))
        .thenReturn(permittedInterestDestinations);

    final List<Tier> tiers = new ArrayList<>();
    when(interestTiersMapper.map(product)).thenReturn(tiers);

    final Boolean webAmendmentsPermitted = true;
    when(webAmendmentsMapper.map(activeProductRules, permittedInterestDestinations))
        .thenReturn(webAmendmentsPermitted);

    final InterestPrivate interest = testSubject.mapPrivate(product, activeProductRules);
    assertThat(interest.getInterestPaid(), sameInstance(interestPaidType));
    assertThat(
        interest.getPermittedInterestDestinations(), sameInstance(permittedInterestDestinations));
    assertThat(interest.getTiers(), sameInstance(tiers));

    assertThat(interest.getPeriodEndIndicator(), is(periodEndIndicator));
    assertThat(interest.getPeriodEndDate(), is(periodEndDate));
    assertThat(interest.getDivisorDays(), is(divisorDays));
    assertThat(interest.getPreviousPeriodDivisorDays(), is(previousDivisorDays));
    assertThat(interest.getWebAmendmentsPermitted(), is(webAmendmentsPermitted));
  }
}
