package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.when;

import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.config.onsale.OnSaleProductProperties;
import uk.co.ybs.digital.product.service.ProductCategoryType;

@ExtendWith(MockitoExtension.class)
public class ProductCategoryUrlMapperTest {

  private static final String BASE_URI = "localhost://savings";
  @Mock private OnSaleProductProperties onSaleProductProperties;
  @InjectMocks private ProductCategoryUrlMapper testSubject;

  private static Stream<Arguments> validCategoriesAndUrls() {
    return Stream.of(
        Arguments.of(
            ProductCategoryType.EASY_ACCESS,
            String.format("%s/easy-access/index.html?display=allWaysToApply", BASE_URI)),
        Arguments.of(
            ProductCategoryType.FIXED_BOND,
            String.format("%s/fixed-rate-bonds/index.html?display=allWaysToApply", BASE_URI)),
        Arguments.of(
            ProductCategoryType.ISA_FIXED,
            String.format("%s/isas/index.html?display=fixedRate", BASE_URI)),
        Arguments.of(
            ProductCategoryType.ISA_VARIABLE,
            String.format("%s/isas/index.html?display=variableRate", BASE_URI)),
        Arguments.of(
            ProductCategoryType.CHILDRENS,
            String.format("%s/childrens-savings/index.html?display=allWaysToApply", BASE_URI)),
        Arguments.of(
            ProductCategoryType.REGULAR,
            String.format("%s/regular-saver/index.html?display=allWaysToApply", BASE_URI)));
  }

  @ParameterizedTest
  @MethodSource("validCategoriesAndUrls")
  public void productCategoryUrlMapperShouldHandleAllProductCategories(
      final ProductCategoryType type, final String expectedUrl) {
    when(onSaleProductProperties.getBaseUri()).thenReturn(BASE_URI);

    final String actual = testSubject.map(type);

    assertThat(expectedUrl, is(actual));
  }

  @ParameterizedTest
  @EnumSource(ProductCategoryType.class)
  // This test acts as guard for when new items are added to ProductCategoryType
  // If mapping is not implemented for them this test will fail.
  public void productCategoryUrlMapperShouldThrowExceptionWithUnknownCategory(
      final ProductCategoryType type) {
    assertDoesNotThrow(() -> testSubject.map(type));
  }
}
