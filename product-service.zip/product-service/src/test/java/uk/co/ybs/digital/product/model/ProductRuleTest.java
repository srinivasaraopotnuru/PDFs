package uk.co.ybs.digital.product.model;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class ProductRuleTest {

  @ValueSource(strings = {"y", "Y", "true", "TRUE"})
  @ParameterizedTest
  void getBooleanValueShouldReturnTrueWhenCharValueIsTrue(final String value) {
    final ProductRule rule = ProductRule.builder().charValue(value).build();
    assertThat(rule.getBooleanValue(), is(Boolean.TRUE));
  }

  @ValueSource(strings = {"n", "N", "false", "FALSE"})
  @ParameterizedTest
  void getBooleanValueShouldReturnFalseWhenCharValueIsFalse(final String value) {
    final ProductRule rule = ProductRule.builder().charValue(value).build();
    assertThat(rule.getBooleanValue(), is(Boolean.FALSE));
  }

  @ValueSource(strings = {"", "what?"})
  @ParameterizedTest
  void getBooleanValueShouldReturnNullWhenUnexpectedCharValue(final String value) {
    final ProductRule rule = ProductRule.builder().charValue(value).build();
    assertThat(rule.getBooleanValue(), is(nullValue()));
  }

  @Test
  void getBooleanValueShouldReturnNullWhenNullCharValue() {
    final ProductRule rule = ProductRule.builder().build();
    assertThat(rule.getBooleanValue(), is(nullValue()));
  }
}
