package uk.co.ybs.digital.product.model;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.stream.Stream;
import org.hamcrest.core.Is;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.TestDataFactory;

class ActiveProductRulesTest {

  private static final String CHAR = "CHAR";
  private static final String MONEY = "MONEY";
  private static final String NUMBER = "NUMBER";
  private static final String UNKNOWN = "UNKNOWN";
  private static final String BOOL = "BOOL";
  private static final String PRDTYP_CODE = "PRDTYP";
  private static final String PAYACC_CODE = "PAYACC";
  private static final String ZERO = "ZERO";
  private static final String VALUE_123 = "123";

  @Test
  void shouldGetStringValue() {
    final ActiveProductRules rules =
        TestDataFactory.createActiveProductRules(
            charProductRule(availableProductRule(CHAR), VALUE_123),
            moneyProductRule(availableProductRule(MONEY), BigDecimal.TEN),
            numberProductRule(availableProductRule(NUMBER), 2L));

    assertThat(rules.getStringValue(CHAR), is(VALUE_123));
    assertThat(rules.getStringValue(MONEY), is(nullValue()));
    assertThat(rules.getStringValue(NUMBER), is(nullValue()));
    assertThat(rules.getStringValue(UNKNOWN), is(nullValue()));
  }

  @Test
  void shouldGetBooleanValue() {
    final ActiveProductRules rules =
        TestDataFactory.createActiveProductRules(
            charProductRule(availableProductRule(BOOL), "Y"),
            charProductRule(availableProductRule(CHAR), "ABC"),
            moneyProductRule(availableProductRule(MONEY), BigDecimal.TEN),
            numberProductRule(availableProductRule(NUMBER), 2L));

    assertThat(rules.getBooleanValue(BOOL), is(Boolean.TRUE));
    assertThat(rules.getBooleanValue(CHAR), is(nullValue()));
    assertThat(rules.getBooleanValue(MONEY), is(nullValue()));
    assertThat(rules.getBooleanValue(NUMBER), is(nullValue()));
    assertThat(rules.getBooleanValue(UNKNOWN), is(nullValue()));
  }

  @ParameterizedTest
  @MethodSource("booleanProductRules")
  void shouldGetBooleanWithDefault(
      final ActiveProductRules rules, final boolean defaultValue, final boolean expected) {
    assertThat(rules.getBooleanWithDefault(BOOL, defaultValue), is(expected));
  }

  private static Stream<Arguments> booleanProductRules() {
    final ActiveProductRules rulesWithTrue =
        TestDataFactory.createActiveProductRules(charProductRule(availableProductRule(BOOL), "Y"));
    final ActiveProductRules emptyRules = TestDataFactory.createActiveProductRules();
    return Stream.of(
        Arguments.of(rulesWithTrue, false, true), Arguments.of(emptyRules, false, false));
  }

  @Test
  void shouldGetMoneyValue() {
    final ActiveProductRules rules =
        TestDataFactory.createActiveProductRules(
            charProductRule(availableProductRule(CHAR), VALUE_123),
            moneyProductRule(availableProductRule(MONEY), BigDecimal.TEN),
            numberProductRule(availableProductRule(NUMBER), 2L));

    assertThat(rules.getMoneyValue(MONEY), is(BigDecimal.TEN));
    assertThat(rules.getMoneyValue(CHAR), is(nullValue()));
    assertThat(rules.getMoneyValue(NUMBER), is(nullValue()));
    assertThat(rules.getMoneyValue(UNKNOWN), is(nullValue()));
  }

  @Test
  void shouldGetNonZeroNumberValue() {
    final ActiveProductRules rules =
        TestDataFactory.createActiveProductRules(
            charProductRule(availableProductRule(CHAR), VALUE_123),
            moneyProductRule(availableProductRule(MONEY), BigDecimal.TEN),
            numberProductRule(availableProductRule(NUMBER), 2L),
            numberProductRule(availableProductRule(ZERO), 0L));

    assertThat(rules.getNonZeroNumberValue(NUMBER), is(2L));
    assertThat(rules.getNonZeroNumberValue(ZERO), is(nullValue()));
    assertThat(rules.getNonZeroNumberValue(CHAR), is(nullValue()));
    assertThat(rules.getNonZeroNumberValue(MONEY), is(nullValue()));
    assertThat(rules.getNonZeroNumberValue(UNKNOWN), is(nullValue()));
  }

  @Test
  void shouldGetNumberValueWithDefault() {
    final ActiveProductRules rules =
        TestDataFactory.createActiveProductRules(
            charProductRule(availableProductRule(CHAR), VALUE_123),
            moneyProductRule(availableProductRule(MONEY), BigDecimal.TEN),
            numberProductRule(availableProductRule(NUMBER), 2L),
            numberProductRule(availableProductRule(ZERO), 0L));

    assertThat(rules.getNumberValueWithDefault(NUMBER, 0L), is(2L));
    assertThat(rules.getNumberValueWithDefault(ZERO, 0L), is(0L));
    assertThat(rules.getNumberValueWithDefault(CHAR, 0L), is(0L));
    assertThat(rules.getNumberValueWithDefault(MONEY, 0L), is(0L));
    assertThat(rules.getNumberValueWithDefault(UNKNOWN, 0L), is(0L));
  }

  @ParameterizedTest
  @MethodSource("paymentAccountProductRules")
  void shouldIdentifyPaymentProduct(final ActiveProductRules rules, final boolean expectedValue) {
    assertThat(rules.isPaymentProduct(), Is.is(expectedValue));
  }

  private static Stream<Arguments> paymentAccountProductRules() {
    final ActiveProductRules payAccSetToYProductRules =
        TestDataFactory.createActiveProductRules(TestDataFactory.charProductRule(PAYACC_CODE, "Y"));

    final ActiveProductRules payAccSetNProductRules =
        TestDataFactory.createActiveProductRules(TestDataFactory.charProductRule(PAYACC_CODE, "N"));

    final ActiveProductRules noPayAccProductRules = TestDataFactory.createActiveProductRules();
    return Stream.of(
        Arguments.of(payAccSetToYProductRules, true),
        Arguments.of(payAccSetNProductRules, false),
        Arguments.of(noPayAccProductRules, false));
  }

  @ParameterizedTest
  @CsvSource({"SAVER,true", "ISA,false", "FBOND,false"})
  void shouldIdentifySaverProduct(final String productType, final boolean expectedValue) {
    final ActiveProductRules rules =
        TestDataFactory.createActiveProductRules(
            TestDataFactory.charProductRule(PRDTYP_CODE, productType));
    assertThat(rules.isSaverProduct(), Is.is(expectedValue));
  }

  @ParameterizedTest
  @MethodSource("supportedProductRules")
  void shouldIdentifySupportedProduct(
      final String label, final ActiveProductRules rules, final boolean expectedValue) {
    assertThat(rules.isSupportedProduct(), Is.is(expectedValue));
  }

  private static Stream<Arguments> supportedProductRules() {
    return Stream.of(
        Arguments.of(
            "saver",
            TestDataFactory.createActiveProductRules(
                TestDataFactory.charProductRule(PRDTYP_CODE, "SAVER")),
            true),
        Arguments.of(
            "payAcc",
            TestDataFactory.createActiveProductRules(
                TestDataFactory.charProductRule(PAYACC_CODE, "Y"),
                TestDataFactory.charProductRule(PRDTYP_CODE, "FBOND")),
            true),
        Arguments.of(
            "saver and payAcc",
            TestDataFactory.createActiveProductRules(
                TestDataFactory.charProductRule(PAYACC_CODE, "Y"),
                TestDataFactory.charProductRule(PRDTYP_CODE, "SAVER")),
            true),
        Arguments.of(
            "isa",
            TestDataFactory.createActiveProductRules(
                TestDataFactory.charProductRule(PRDTYP_CODE, "ISA")),
            true),
        Arguments.of(
            "isa - help to buy",
            TestDataFactory.createActiveProductRules(
                TestDataFactory.charProductRule(PRDTYP_CODE, "ISA"),
                TestDataFactory.charProductRule("ISAFTB", "Y")),
            true),
        Arguments.of(
            "isa - flexible",
            TestDataFactory.createActiveProductRules(
                TestDataFactory.charProductRule(PRDTYP_CODE, "ISA"),
                TestDataFactory.charProductRule("ISAFLX", "Y")),
            true),
        Arguments.of(
            "fbond",
            TestDataFactory.createActiveProductRules(
                TestDataFactory.charProductRule(PRDTYP_CODE, "FBOND")),
            true),
        Arguments.of(
            "none",
            TestDataFactory.createActiveProductRules(
                TestDataFactory.charProductRule(PRDTYP_CODE, "some-product-type")),
            false));
  }

  private static Product product() {
    return Product.builder().productIdentifier("foo").sysid(1).brandCode("YBS").build();
  }

  private static AvailableProductRule availableProductRule(final String code) {
    return AvailableProductRule.builder()
        .code(code)
        .valueType(AvailableProductRule.ValueType.CHAR)
        .build();
  }

  private static ProductRule charProductRule(
      final AvailableProductRule availableProductRule, final String value) {
    return productRuleBuilder(availableProductRule).charValue(value).build();
  }

  private static ProductRule moneyProductRule(
      final AvailableProductRule availableProductRule, final BigDecimal value) {
    return productRuleBuilder(availableProductRule).moneyValue(value).build();
  }

  private static ProductRule numberProductRule(
      final AvailableProductRule availableProductRule, final Long value) {
    return productRuleBuilder(availableProductRule).numberValue(value).build();
  }

  private static ProductRule.ProductRuleBuilder productRuleBuilder(
      final AvailableProductRule availableProductRule) {
    final Product product = product();
    return ProductRule.builder(product, availableProductRule, LocalDateTime.now());
  }
}
