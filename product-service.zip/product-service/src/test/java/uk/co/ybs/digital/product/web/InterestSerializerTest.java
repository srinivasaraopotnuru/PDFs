package uk.co.ybs.digital.product.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class InterestSerializerTest {

  private final InterestSerializer testSubject = new InterestSerializer();

  @Mock private JsonGenerator jsonGenerator;

  @Mock private SerializerProvider serializerProvider;

  @ParameterizedTest
  @CsvSource({"123,123.000", "123.4,123.400", "123.45,123.450", "123.456,123.456"})
  void serializeShouldWriteJsonString(final String bigDecimalString, final String expected)
      throws IOException {
    testSubject.serialize(new BigDecimal(bigDecimalString), jsonGenerator, serializerProvider);

    verify(jsonGenerator).writeString(expected);
    verifyNoInteractions(serializerProvider);
  }

  @Test
  void serializeShouldThrowExceptionWhenRoundingNecessary() {
    final ArithmeticException exception =
        assertThrows(
            ArithmeticException.class,
            () ->
                testSubject.serialize(
                    new BigDecimal("123.4567"), jsonGenerator, serializerProvider));

    assertThat(exception.getMessage(), is("Rounding necessary"));

    verifyNoInteractions(jsonGenerator);
    verifyNoInteractions(serializerProvider);
  }
}
