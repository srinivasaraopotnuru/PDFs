package uk.co.ybs.digital.product;

import java.net.URI;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class})
@ActiveProfiles("test")
class SwaggerIT {

  @LocalServerPort private int port;

  @Autowired private WebTestClient nonSigningWebClient;

  @ValueSource(
      strings = {"/product/swagger-resources", "/product/v2/api-docs", "/product/swagger-ui.html"})
  @ParameterizedTest
  void shouldReturnOkForSwaggerEndpointsWithNoSignature(final String path) {
    nonSigningWebClient
        .get()
        .uri(getInfoURI(path))
        .accept(MediaType.ALL)
        .exchange()
        .expectStatus()
        .isOk();
  }

  @Test
  void apiDocsShouldContainNonEmptyPathsObject() {
    nonSigningWebClient
        .get()
        .uri(getInfoURI("/product/v2/api-docs"))
        .accept(MediaType.ALL)
        .exchange()
        .expectBody()
        .jsonPath("paths")
        .exists()
        .jsonPath("paths")
        .isNotEmpty();
  }

  private URI getInfoURI(final String path) {
    return URI.create("http://localhost:" + port + path);
  }
}
