package uk.co.ybs.digital.product.utils;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.junit.jupiter.params.provider.CsvSource;

@CsvSource(
    value = {"1;1", "999;999", "1000;1,000", "1999;1,999", "10000;10,000"},
    delimiterString = ";")
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface FormattedMoneySource {}
