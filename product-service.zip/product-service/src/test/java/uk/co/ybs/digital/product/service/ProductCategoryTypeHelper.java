package uk.co.ybs.digital.product.service;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ProductCategoryTypeHelper {
  EASY_ACCESS(
      "Easy Access", "Manage your money with greater freedom.", "Straightforward and flexible"),
  FIXED_BOND(
      "Fixed Rate Bonds",
      "Put your money away for a fixed term.",
      "Potentially earn a higher rate of interest"),
  ISA_FIXED(
      "Cash ISA Fixed",
      "Put your money away for a fixed term.",
      "Save up to £20,000 per year, tax-free"),
  ISA_VARIABLE(
      "Cash ISA Variable",
      "A range of withdrawal options to suit different needs.",
      "Save up to £20,000 per year, tax-free"),
  REGULAR(
      "Regular Savings",
      "Keep on track of your goals with limited withdrawals allowed per year.",
      "Save for something special"),
  CHILDRENS(
      "Children's Accounts",
      "Begin saving now. It's never too early to get started.",
      "Give your child a good start in life");

  private final String title;
  private final String subTitle;
  private final String description;
}
