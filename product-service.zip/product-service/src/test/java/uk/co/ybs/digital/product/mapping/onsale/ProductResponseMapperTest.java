package uk.co.ybs.digital.product.mapping.onsale;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.product.service.ProductCategoryType.CHILDRENS;
import static uk.co.ybs.digital.product.service.ProductCategoryType.EASY_ACCESS;
import static uk.co.ybs.digital.product.service.ProductCategoryType.FIXED_BOND;
import static uk.co.ybs.digital.product.service.ProductCategoryType.ISA_FIXED;
import static uk.co.ybs.digital.product.service.ProductCategoryType.ISA_VARIABLE;
import static uk.co.ybs.digital.product.service.ProductCategoryType.REGULAR;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.service.ProductCategoryType;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;

@ExtendWith(MockitoExtension.class)
class ProductResponseMapperTest {

  @InjectMocks private ProductResponseMapper testSubject;
  @Mock private ProductCombiner productCombiner;
  @Mock private CategoryTypeMapper categoryMapper;
  @Mock private ProductMapper productMapper;
  @Mock private ProductCategoryMapper productCategoryMapper;

  @Test
  void mapShouldCombineProducts() throws ParseException {
    final WebSiteProduct product = websiteProductBuilderHelper("A");
    final WebSiteProduct otherProduct = websiteProductBuilderHelper("B");

    final List<WebSiteProduct> inputProducts = asList(product, otherProduct);
    final List<WebSiteProduct> combinedProducts = singletonList(product);

    final Product mappedProduct = productBuilderHelper("Mapped Product A", "http://exampleA.com");
    final ProductCategory mappedProductCategory =
        productCategoryBuilderHelper(EASY_ACCESS, singletonList(mappedProduct), false);

    when(productCombiner.combineMultiChannel(inputProducts)).thenReturn(combinedProducts);
    when(categoryMapper.map(product)).thenReturn(singletonList(EASY_ACCESS));
    when(productMapper.map(product)).thenReturn(Optional.of(mappedProduct));
    when(productCategoryMapper.map(EASY_ACCESS, singletonList(mappedProduct), combinedProducts))
        .thenReturn(mappedProductCategory);

    final List<ProductCategory> mapped = testSubject.map(inputProducts);

    final List<ProductCategory> expected = singletonList(mappedProductCategory);

    assertThat(mapped, is(expected));
  }

  @Test
  void mapShouldFilterNonYBSProducts() {
    final WebSiteProduct product = websiteProductBuilderHelper("A");
    final WebSiteProduct otherProduct = websiteProductBuilderHelper("B");
    final List<WebSiteProduct> inputProducts = asList(product, otherProduct);

    final List<ProductCategory> mapped = testSubject.map(inputProducts);

    assertThat(mapped, is(empty()));
    verifyNoInteractions(categoryMapper);
    verifyNoInteractions(productMapper);
    verifyNoInteractions(productCategoryMapper);
  }

  @Test
  void mapShouldReturnAnEmpty() throws ParseException {
    final WebSiteProduct product = websiteProductBuilderHelper("A");

    final List<WebSiteProduct> inputProducts = singletonList(product);
    final ProductCategory mappedProductCategory =
        productCategoryBuilderHelper(EASY_ACCESS, emptyList(), false);

    when(productCombiner.combineMultiChannel(inputProducts)).thenReturn(inputProducts);
    when(categoryMapper.map(product)).thenReturn(singletonList(EASY_ACCESS));
    when(productMapper.map(product)).thenReturn(Optional.empty());
    when(productCategoryMapper.map(EASY_ACCESS, emptyList(), inputProducts))
        .thenReturn(mappedProductCategory);

    final List<ProductCategory> mapped = testSubject.map(inputProducts);

    final List<ProductCategory> expected = singletonList(mappedProductCategory);

    assertThat(mapped, is(expected));
  }

  @Test
  void mapShouldGroupProductsByCategory() throws ParseException {
    final WebSiteProduct productA = websiteProductBuilderHelper("A");
    final WebSiteProduct productB = websiteProductBuilderHelper("B");
    final WebSiteProduct productC = websiteProductBuilderHelper("C");

    final List<WebSiteProduct> inputProducts = asList(productA, productB, productC);

    final Product mappedProductA = productBuilderHelper("Mapped Product A", "http://exampleA.com");
    final Product mappedProductB = productBuilderHelper("Mapped Product B", "http://exampleB.com");
    final Product mappedProductC = productBuilderHelper("Mapped Product C", "http://exampleC.com");

    final ProductCategory mappedProductCategoryA =
        productCategoryBuilderHelper(EASY_ACCESS, asList(mappedProductA, mappedProductB), false);
    final ProductCategory mappedProductCategoryB =
        productCategoryBuilderHelper(FIXED_BOND, asList(mappedProductA, mappedProductC), false);

    when(productCombiner.combineMultiChannel(inputProducts)).thenReturn(inputProducts);
    when(categoryMapper.map(productA)).thenReturn(asList(EASY_ACCESS, FIXED_BOND));
    when(categoryMapper.map(productB)).thenReturn(singletonList(EASY_ACCESS));
    when(categoryMapper.map(productC)).thenReturn(singletonList(FIXED_BOND));

    when(productMapper.map(productA)).thenReturn(Optional.of(mappedProductA));
    when(productMapper.map(productB)).thenReturn(Optional.of(mappedProductB));
    when(productMapper.map(productC)).thenReturn(Optional.of(mappedProductC));

    when(productCategoryMapper.map(
            EASY_ACCESS, asList(mappedProductA, mappedProductB), asList(productA, productB)))
        .thenReturn(mappedProductCategoryA);
    when(productCategoryMapper.map(
            FIXED_BOND, asList(mappedProductA, mappedProductC), asList(productA, productC)))
        .thenReturn(mappedProductCategoryB);

    final List<ProductCategory> mapped = testSubject.map(inputProducts);

    final List<ProductCategory> expected = asList(mappedProductCategoryA, mappedProductCategoryB);

    assertThat(mapped, is(expected));
  }

  @Test
  void mapShouldSortCategories() throws ParseException {
    final WebSiteProduct productA = websiteProductBuilderHelper("A");
    final WebSiteProduct productB = websiteProductBuilderHelper("B");
    final WebSiteProduct productC = websiteProductBuilderHelper("C");
    final WebSiteProduct productD = websiteProductBuilderHelper("D");
    final WebSiteProduct productE = websiteProductBuilderHelper("E");
    final WebSiteProduct productF = websiteProductBuilderHelper("F");

    final List<WebSiteProduct> inputProducts =
        asList(productA, productB, productC, productD, productE, productF);

    final Product mappedProductA = productBuilderHelper("Mapped Product A", "http://exampleA.com");
    final Product mappedProductB = productBuilderHelper("Mapped Product B", "http://exampleB.com");
    final Product mappedProductC = productBuilderHelper("Mapped Product C", "http://exampleC.com");
    final Product mappedProductD = productBuilderHelper("Mapped Product D", "http://exampleD.com");
    final Product mappedProductE = productBuilderHelper("Mapped Product E", "http://exampleE.com");
    final Product mappedProductF = productBuilderHelper("Mapped Product F", "http://exampleF.com");

    final ProductCategory mappedProductCategoryA =
        productCategoryBuilderHelper(EASY_ACCESS, singletonList(mappedProductA), false);
    final ProductCategory mappedProductCategoryB =
        productCategoryBuilderHelper(FIXED_BOND, singletonList(mappedProductB), false);
    final ProductCategory mappedProductCategoryC =
        productCategoryBuilderHelper(ISA_FIXED, singletonList(mappedProductC), false);
    final ProductCategory mappedProductCategoryD =
        productCategoryBuilderHelper(ISA_VARIABLE, singletonList(mappedProductD), false);
    final ProductCategory mappedProductCategoryE =
        productCategoryBuilderHelper(REGULAR, singletonList(mappedProductE), false);
    final ProductCategory mappedProductCategoryF =
        productCategoryBuilderHelper(CHILDRENS, singletonList(mappedProductF), false);

    when(productCombiner.combineMultiChannel(inputProducts)).thenReturn(inputProducts);

    when(categoryMapper.map(productA)).thenReturn(singletonList(EASY_ACCESS));
    when(categoryMapper.map(productB)).thenReturn(singletonList(FIXED_BOND));
    when(categoryMapper.map(productC)).thenReturn(singletonList(ISA_FIXED));
    when(categoryMapper.map(productD)).thenReturn(singletonList(ISA_VARIABLE));
    when(categoryMapper.map(productE)).thenReturn(singletonList(REGULAR));
    when(categoryMapper.map(productF)).thenReturn(singletonList(CHILDRENS));

    when(productMapper.map(productA)).thenReturn(Optional.of(mappedProductA));
    when(productMapper.map(productB)).thenReturn(Optional.of(mappedProductB));
    when(productMapper.map(productC)).thenReturn(Optional.of(mappedProductC));
    when(productMapper.map(productD)).thenReturn(Optional.of(mappedProductD));
    when(productMapper.map(productE)).thenReturn(Optional.of(mappedProductE));
    when(productMapper.map(productF)).thenReturn(Optional.of(mappedProductF));

    when(productCategoryMapper.map(
            EASY_ACCESS, singletonList(mappedProductA), singletonList(productA)))
        .thenReturn(mappedProductCategoryA);
    when(productCategoryMapper.map(
            FIXED_BOND, singletonList(mappedProductB), singletonList(productB)))
        .thenReturn(mappedProductCategoryB);
    when(productCategoryMapper.map(
            ISA_FIXED, singletonList(mappedProductC), singletonList(productC)))
        .thenReturn(mappedProductCategoryC);
    when(productCategoryMapper.map(
            ISA_VARIABLE, singletonList(mappedProductD), singletonList(productD)))
        .thenReturn(mappedProductCategoryD);
    when(productCategoryMapper.map(REGULAR, singletonList(mappedProductE), singletonList(productE)))
        .thenReturn(mappedProductCategoryE);
    when(productCategoryMapper.map(
            CHILDRENS, singletonList(mappedProductF), singletonList(productF)))
        .thenReturn(mappedProductCategoryF);

    final List<ProductCategory> mapped = testSubject.map(inputProducts);

    final List<ProductCategory> expected =
        asList(
            mappedProductCategoryA,
            mappedProductCategoryB,
            mappedProductCategoryC,
            mappedProductCategoryD,
            mappedProductCategoryE,
            mappedProductCategoryF);
    assertThat(mapped, is(expected));
  }

  private static WebSiteProduct websiteProductBuilderHelper(final String productCode) {
    return WebSiteProduct.builder().brand("YBS").productCode(productCode).build();
  }

  private static Product productBuilderHelper(final String productName, final String productUrl) {
    return Product.builder()
        .name(productName)
        .type(ProductType.DEFERRED)
        .url(productUrl)
        .productCode("YBS345SA")
        .interestFrequency(InterestFrequency.ANNUAL)
        .facts(emptyList())
        .interestTiers(emptyList())
        .build();
  }

  private static ProductCategory productCategoryBuilderHelper(
      final ProductCategoryType categoryType, final List<Product> product, final boolean offline) {
    return ProductCategory.builder()
        .title(categoryType.getTitle())
        .subTitle(categoryType.getSubTitle())
        .description(categoryType.getDescription())
        .products(product)
        .url("category url")
        .offlineOnlyProductsAvailable(offline)
        .build();
  }
}
