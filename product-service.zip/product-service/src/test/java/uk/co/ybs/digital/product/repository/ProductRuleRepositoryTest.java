package uk.co.ybs.digital.product.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyIterable;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

import com.google.common.collect.ImmutableList;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductRule;

@DataJpaTest
@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
class ProductRuleRepositoryTest {

  private static final List<String> KNOWN_PRODUCT_RULES =
      Arrays.asList(
          "PRDTYP", "PAYACC", "CUSDES", "WEBWDL", "MAXBAL", "MINABL", "MAXDPC", "MAXDPA", "MAXDPP",
          "NOWDLM", "NOWDLC", "ANNWDL", "NOWDLI", "NOWDLP", "MAXPAY", "MAXNPD", "KYCCOL");

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-18T13:39:12");

  @Autowired ProductRuleRepository productRuleRepository;

  @Autowired TestEntityManager testEntityManager;

  @ParameterizedTest
  @MethodSource("productRulesStartAndEndDates")
  void findByProductAndRuleCodesShouldFilterProductRulesByStartAndEndDate(
      final ProductRule rule, final boolean shouldFind) {
    final Product product = persist(rule);

    final List<ProductRule> foundProductRules =
        productRuleRepository.findByProductAndRuleCodes(
            Collections.singletonList(product), KNOWN_PRODUCT_RULES, NOW);

    if (shouldFind) {
      assertThat(foundProductRules, hasSize(1));
      assertThat(foundProductRules.get(0).getId(), is(rule.getId()));
    } else {
      assertThat(foundProductRules, emptyIterable());
    }
  }

  private Stream<Arguments> productRulesStartAndEndDates() {
    final Product product = fooProduct();
    final AvailableProductRule availableProductRule = availableProductRule();

    final ProductRule startedAndHasNoEndedDate =
        TestDataFactory.factoryProductRuleWithDates(NOW, null, product, availableProductRule);
    final ProductRule startedAndEndsInFuture =
        TestDataFactory.factoryProductRuleWithDates(
            NOW, NOW.plusDays(4), product, availableProductRule);
    final ProductRule startsInFuture =
        TestDataFactory.factoryProductRuleWithDates(
            NOW.plusDays(1), null, product, availableProductRule);
    final ProductRule endedInPast =
        TestDataFactory.factoryProductRuleWithDates(
            NOW.minusDays(5), NOW.minusDays(1), product, availableProductRule);

    return Stream.of(
        Arguments.of(startedAndHasNoEndedDate, true),
        Arguments.of(startedAndEndsInFuture, true),
        Arguments.of(startsInFuture, false),
        Arguments.of(endedInPast, false));
  }

  @ParameterizedTest
  @MethodSource("productRulesCodes")
  void findByProductAndRuleCodesShouldFilterProductRulesByCode(
      final ProductRule rule, final boolean shouldFind) {
    final Product product = persist(rule);

    final List<ProductRule> foundProductRules =
        productRuleRepository.findByProductAndRuleCodes(
            Collections.singletonList(product), KNOWN_PRODUCT_RULES, NOW);

    if (shouldFind) {
      assertThat(foundProductRules, hasSize(1));
      assertThat(foundProductRules.get(0).getId(), is(rule.getId()));
    } else {
      assertThat(foundProductRules, emptyIterable());
    }
  }

  private Stream<Arguments> productRulesCodes() {
    final Product product = fooProduct();

    final LocalDateTime ruleStartDate = NOW;

    final ProductRule ruleExactMatch =
        TestDataFactory.factoryProductRuleWithDates(
            ruleStartDate, null, product, availableProductRule(KNOWN_PRODUCT_RULES.get(0)));
    final ProductRule ruleNoMatch =
        TestDataFactory.factoryProductRuleWithDates(
            ruleStartDate, null, product, availableProductRule("UNKNOW"));

    return Stream.of(Arguments.of(ruleExactMatch, true), Arguments.of(ruleNoMatch, false));
  }

  @Test
  void findByProductAndRuleCodesShouldFilterProductRulesByProduct() {
    final LocalDateTime now = NOW;
    final LocalDateTime future = NOW.plusDays(1);

    final Product fooProduct = fooProduct();
    testEntityManager.persist(fooProduct);

    final Product barProduct = barProduct();
    testEntityManager.persist(barProduct);

    final Product bazProduct = bazProduct();
    testEntityManager.persist(bazProduct);

    final AvailableProductRule availableProductRule = availableProductRule();
    testEntityManager.persist(availableProductRule);

    final ProductRule productRuleShouldBeFoundFoo =
        TestDataFactory.factoryProductRuleWithDates(now, future, fooProduct, availableProductRule);
    testEntityManager.persist(productRuleShouldBeFoundFoo);

    final ProductRule productRuleShouldBeFoundBar =
        TestDataFactory.factoryProductRuleWithDates(now, future, barProduct, availableProductRule);
    testEntityManager.persist(productRuleShouldBeFoundBar);

    final ProductRule productRuleShouldNotBeFound =
        TestDataFactory.factoryProductRuleWithDates(now, future, bazProduct, availableProductRule);
    testEntityManager.persist(productRuleShouldNotBeFound);

    testEntityManager.flush();

    final List<ProductRule> foundRules =
        productRuleRepository.findByProductAndRuleCodes(
            ImmutableList.of(barProduct, fooProduct), KNOWN_PRODUCT_RULES, NOW);
    assertThat(
        foundRules, containsInAnyOrder(ruleForProduct(fooProduct), ruleForProduct(barProduct)));
  }

  private Matcher<ProductRule> ruleForProduct(final Product product) {
    return hasProperty("product", is(product));
  }

  @Test
  void findByProductAndRuleCodesShouldReturnEmptyListIfProductHasNoRules() {
    final Product fooProduct = fooProduct();
    testEntityManager.persist(fooProduct);

    final List<ProductRule> foundRules =
        productRuleRepository.findByProductAndRuleCodes(
            Collections.singletonList(fooProduct), KNOWN_PRODUCT_RULES, NOW);
    assertThat(foundRules, emptyIterable());
  }

  private AvailableProductRule availableProductRule() {
    return availableProductRule(KNOWN_PRODUCT_RULES.get(0));
  }

  private AvailableProductRule availableProductRule(final String code) {
    return AvailableProductRule.builder()
        .code(code)
        .valueType(AvailableProductRule.ValueType.MONEY)
        .build();
  }

  private Product fooProduct() {
    return buildProduct(1, "foo");
  }

  private Product barProduct() {
    return buildProduct(2, "bar");
  }

  private Product bazProduct() {
    return buildProduct(3, "baz");
  }

  private Product buildProduct(final long sysId, final String productIdentifier) {
    return Product.builder()
        .sysid(sysId)
        .productIdentifier(productIdentifier)
        .startDate(NOW)
        .brandCode("YBS")
        .penaltyDays(30)
        .divisorDays(365)
        .penaltyCode(2)
        .periodEndIndicator("P")
        .build();
  }

  private Product persist(final ProductRule rule) {
    final Product product = rule.getProduct();
    testEntityManager.persistAndFlush(product);
    testEntityManager.persistAndFlush(rule.getAvailableProductRule());
    testEntityManager.persistAndFlush(rule);
    return product;
  }
}
