package uk.co.ybs.digital.product.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class ProductDetailsResponsePrivateJsonTest {
  @Autowired private JacksonTester<ProductDetailsResponsePrivate> json;

  @Value("classpath:/responses/ProductDetailsResponsePrivate.json")
  private Resource file;

  private ProductDetailsResponsePrivate fullyPopulated;

  @BeforeEach
  void setup() {
    fullyPopulated = createProductDetailsResponse();
  }

  @Test
  void canSerializeProductRuleResponse() throws Exception {
    assertThat(json.write(fullyPopulated)).isEqualToJson(file, JSONCompareMode.STRICT);
  }

  @Test
  void canDeserializeProductRuleResponse() throws Exception {
    assertThat(json.read(file)).isEqualTo(fullyPopulated);
  }

  @Test
  void serializationOmitsNullFields() throws Exception {
    final ProductDetailsResponsePrivate emptyResponse =
        ProductDetailsResponsePrivate.builder().build();

    assertThat(json.write(emptyResponse))
        .isEqualToJson("{cardAvailable: false}", JSONCompareMode.STRICT);
  }

  private static ProductDetailsResponsePrivate createProductDetailsResponse() {
    return ProductDetailsResponsePrivate.builder()
        .applications(
            ProductDetailsResponse.Applications.builder()
                .accountNumberSuffix("bar")
                .applicationsPermitted(true)
                .fatcaReportable(true)
                .maximumAge(105L)
                .maximumApplicants(2L)
                .minimumAge(16L)
                .nationalInsuranceNumberRequired(true)
                .build())
        .productType("foo")
        .productIdentifier("INTSAV")
        .customerDescription("bar")
        .cardAvailable(true)
        .maximumNumberOfAccounts(2)
        .isKycRequired(true)
        .brandCode("YBS")
        .interest(
            ProductDetailsResponsePrivate.InterestPrivate.builder()
                .divisorDays(366)
                .interestPaid(ProductDetailsResponse.Interest.InterestPaidType.MONTHLY)
                .periodEndIndicator("P")
                .periodEndDate(LocalDateTime.parse("2021-08-31T00:00:00"))
                .permittedInterestDestinations(
                    Collections.singletonList(
                        ProductDetailsResponse.Interest.InterestDestinationType.payAwayExternal))
                .previousPeriodDivisorDays(365)
                .tiers(
                    Arrays.asList(
                        ProductDetailsResponseBase.Interest.Tier.builder()
                            .rate(new BigDecimal("0.750"))
                            .rangeLow(new BigDecimal("0.00"))
                            .rangeHigh(new BigDecimal("14999.99"))
                            .build(),
                        ProductDetailsResponseBase.Interest.Tier.builder()
                            .rate(new BigDecimal("0.850"))
                            .rangeLow(new BigDecimal("15000.00"))
                            .rangeHigh(new BigDecimal("999999999.99"))
                            .build()))
                .webAmendmentsPermitted(false)
                .build())
        .balance(
            ProductDetailsResponse.Balance.builder()
                .min(new BigDecimal("-20.00"))
                .max(new BigDecimal("50.00"))
                .build())
        .withdrawals(
            ProductDetailsResponsePrivate.WithdrawalsPrivate.builder()
                .interestPenalty(
                    ProductDetailsResponsePrivate.WithdrawalsPrivate.InterestPenalty.builder()
                        .code(2)
                        .days(30)
                        .balanceUpperBound(new BigDecimal("999999999.99"))
                        .build())
                .permittedOverWeb(true)
                .permittedOverWebOnAccountClosure(true)
                .limits(
                    ProductDetailsResponse.Withdrawals.WithdrawalLimits.builder()
                        .number(
                            ProductDetailsResponse.PeriodLimits.<Long>builder()
                                .firstMonth(1L)
                                .month(3L)
                                .year(40L)
                                .anniversaryYear(45L)
                                .taxYear(50L)
                                .productTerm(500L)
                                .build())
                        .build())
                .build())
        .deposits(
            ProductDetailsResponse.Deposits.builder()
                .permittedExternal(true)
                .permittedInternal(false)
                .limits(
                    ProductDetailsResponse.Deposits.DepositLimits.builder()
                        .amount(
                            ProductDetailsResponse.PeriodLimits.<BigDecimal>builder()
                                .year(new BigDecimal("4000.00"))
                                .firstMonth(new BigDecimal("20.00"))
                                .month(new BigDecimal("70.00"))
                                .anniversaryYear(new BigDecimal("4500.00"))
                                .taxYear(new BigDecimal("5000.00"))
                                .productTerm(new BigDecimal("50000.00"))
                                .build())
                        .build())
                .build())
        .productSysId(123456L)
        .startDate(LocalDateTime.parse("2020-07-11T00:00:00"))
        .isa(
            ProductDetailsResponsePrivate.IsaPrivate.builder()
                .flexible(false)
                .helpToBuy(true)
                .isaYear(1)
                .build())
        .saver(ProductDetailsResponseBase.Saver.builder().regular(false).build())
        .beneficiaries(
            ProductDetailsResponsePrivate.Beneficiaries.builder()
                .external(10L)
                .internal(20L)
                .build())
        .build();
  }
}
