package uk.co.ybs.digital.product.web.dto;

import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.math.BigDecimal;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class ProductDetailsResponseTest {

  @Test
  void getsMaximumMonthlyPaymentValueFromDepositLimits() {
    final ProductDetailsResponse response =
        ProductDetailsResponse.builder()
            .deposits(
                ProductDetailsResponse.Deposits.builder()
                    .limits(
                        ProductDetailsResponse.Deposits.DepositLimits.builder()
                            .amount(
                                ProductDetailsResponse.PeriodLimits.<BigDecimal>builder()
                                    .month(BigDecimal.ONE)
                                    .build())
                            .build())
                    .build())
            .build();

    assertThat(response.getMaximumMonthlyPayment(), is(BigDecimal.ONE));
  }

  @Test
  void handlesNullDeposit() {
    final ProductDetailsResponse response = ProductDetailsResponse.builder().build();
    final BigDecimal maximumMonthlyPayment = assertDoesNotThrow(response::getMaximumMonthlyPayment);
    assertThat(maximumMonthlyPayment, nullValue());
  }

  @ParameterizedTest(name = "{0} should not throw nullPointer exception")
  @MethodSource("nullDepositValues")
  void handlesAllNullDepositChildValues(
      final String description, final ProductDetailsResponse response) {
    final BigDecimal maximumMonthlyPayment = assertDoesNotThrow(response::getMaximumMonthlyPayment);
    assertThat(maximumMonthlyPayment, nullValue());
  }

  private static Stream<Arguments> nullDepositValues() {
    final ProductDetailsResponse nullDeposit = ProductDetailsResponse.builder().build();
    final ProductDetailsResponse nullLimits =
        ProductDetailsResponse.builder()
            .deposits(ProductDetailsResponse.Deposits.builder().build())
            .build();
    final ProductDetailsResponse nullAmount =
        ProductDetailsResponse.builder()
            .deposits(
                ProductDetailsResponse.Deposits.builder()
                    .limits(ProductDetailsResponse.Deposits.DepositLimits.builder().build())
                    .build())
            .build();

    final ProductDetailsResponse nullMonth =
        ProductDetailsResponse.builder()
            .deposits(
                ProductDetailsResponse.Deposits.builder()
                    .limits(
                        ProductDetailsResponse.Deposits.DepositLimits.builder()
                            .amount(
                                ProductDetailsResponse.PeriodLimits.<BigDecimal>builder().build())
                            .build())
                    .build())
            .build();
    return Stream.of(
        Arguments.of("null Deposit", nullDeposit),
        Arguments.of("null limits", nullLimits),
        Arguments.of("null amount", nullAmount),
        Arguments.of("null month", nullMonth));
  }
}
