package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Help;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Interest;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Tiers;

public class InterestBuilderTest {

  private InterestBuilder testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new InterestBuilder();
  }

  @MethodSource("dataSource")
  @ParameterizedTest
  public void testMapsSuccessfully(final WebSiteProduct webSiteProduct, final Interest expected) {
    final Interest result = testSubject.map(webSiteProduct);
    assertThat(result, is(expected));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> dataSource() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildFullWebsiteProductFixedISA(
                "Yes", "Another ISA", "", "Fixed Rate ISA", "Yes"),
            buildExpectedWhenProductHasAnnualInterestAndTaxFreeAndNotTieredAndNotLimitedAccessSaver()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "",
                "Yes",
                "",
                "Limited Access Saver ISA",
                "Internet Saver ISA Plus Issue 8",
                "Yes",
                "",
                "",
                "Yes",
                "",
                "Yes",
                "Yes",
                0,
                "Yes",
                ""),
            buildExpectedWhenProductHasMonthlyInterestAndNotTaxFreeAndTieredAndLimitedAccessSaver()),
        Arguments.of(
            TestHelper.buildFullWebsiteProductVariableISA(
                "No",
                "",
                "Yes",
                "Another ISA",
                "Another ISA",
                "Yes",
                "",
                "",
                "Yes",
                "",
                "Yes",
                "Yes",
                0,
                "Yes",
                "Fixed Rate ISA"),
            buildExpectedWhenProductHasAnnualInterestAndNotTaxFreeAndTieredProduct()));
  }

  private static Interest
      buildExpectedWhenProductHasAnnualInterestAndTaxFreeAndNotTieredAndNotLimitedAccessSaver() {
    return Interest.builder()
        .section(buildSection("1", true, false))
        .title("What is the interest rate?")
        .summary(
            "This account pays a <bold>fixed<bold> tiered rate of interest <bold>annually<bold>:")
        .content(contentForScenario1())
        .help(helpForScenario1())
        .tiers(tierForScenario1())
        .build();
  }

  private static List<Content> contentForScenario1() {

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Whether you need to pay tax is dependent on your own personal circumstances and so may be subject to change in the future.")
            .build();

    final Content item2 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Payment of interest").build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Interest is calculated daily on cleared balances")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Annual interest is paid on 30 September 2022. It can be paid into the Another ISA account, another Yorkshire Building Society account or another building society or bank account.")
            .build();

    return Arrays.asList(item1, item2, item3, item4);
  }

  private static List<Tiers> tierForScenario1() {
    final Tiers item1 =
        Tiers.builder()
            .tax("<bold>1.00%<bold> Tax-free p.a.")
            .interest("<bold>1.00%<bold> AER")
            .build();
    return Collections.singletonList(item1);
  }

  private static List<Help> helpForScenario1() {
    final Help item1 =
        Help.builder()
            .header("What does 'Tax-free' mean?")
            .text("Tax-free means that Interest is not subject to income tax")
            .section(buildSection("?", true, false))
            .build();
    final Help item2 =
        Help.builder()
            .header("What does 'AER' mean?")
            .text(
                "AER stands for the Annual Equivalent Rate and shows you what the interest rate would be if interest was paid and added each year. This will enable you to compare more easily the return you can expect from your savings over time.")
            .section(buildSection("?", true, false))
            .build();

    final Help item3 =
        Help.builder()
            .header("What does 'Fixed Rate' mean?")
            .text(
                "Fixed rate of interest means that the interest rate payable on your account will remain the same from the time you open your account until the end of the fixed rate period.")
            .section(buildSection("?", true, false))
            .build();

    return Arrays.asList(item1, item2, item3);
  }

  private static Interest
      buildExpectedWhenProductHasMonthlyInterestAndNotTaxFreeAndTieredAndLimitedAccessSaver() {
    return Interest.builder()
        .section(buildSection("1", true, false))
        .title("What is the interest rate?")
        .summary(
            "This account pays a <bold>variable<bold> tiered rate of interest <bold>monthly<bold>:")
        .content(contentForScenario2())
        .help(helpForScenario2())
        .tiers(tierForScenario2())
        .build();
  }

  private static List<Content> contentForScenario2() {

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The rates we offer in the different tiers can vary and sometimes might be the same.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Whether you need to pay tax is dependent on your own personal circumstances and so may be subject to change in the future.")
            .build();

    final Content item3 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Payment of interest").build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Interest is calculated daily on cleared balances")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The rate of interest on this account is tiered. You earn one rate of interest based on the tier your balance falls in.")
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Monthly interest is paid on the last day of each month. It must be paid into another Yorkshire Building Society account or another building society or bank account.")
            .build();

    return Arrays.asList(item1, item2, item3, item4, item5, item6);
  }

  private static List<Tiers> tierForScenario2() {
    final Tiers item1 =
        Tiers.builder()
            .header("Balances from £1.00 - £999.99")
            .tax("<bold>0.15%<bold> Gross p.a.")
            .interest("<bold>0.15%<bold> AER")
            .build();

    final Tiers item2 =
        Tiers.builder()
            .header("Balances from £1,000.00 - £9,999.99")
            .tax("<bold>0.25%<bold> Gross p.a.")
            .interest("<bold>0.25%<bold> AER")
            .build();

    final Tiers item3 =
        Tiers.builder()
            .header("Balances from £10,000.00 - £49,999.99")
            .tax("<bold>0.35%<bold> Gross p.a.")
            .interest("<bold>0.35%<bold> AER")
            .build();

    final Tiers item4 =
        Tiers.builder()
            .header("Balances from £50,000.00 - £79,999.99")
            .tax("<bold>0.45%<bold> Gross p.a.")
            .interest("<bold>0.45%<bold> AER")
            .build();

    final Tiers item5 =
        Tiers.builder()
            .header("Balances from £80,000.00+")
            .tax("<bold>0.55%<bold> Gross p.a.")
            .interest("<bold>0.55%<bold> AER")
            .build();

    return Arrays.asList(item1, item2, item3, item4, item5);
  }

  private static List<Help> helpForScenario2() {
    final Help item1 =
        Help.builder()
            .header("What tax do I pay?")
            .text(
                "Interest is paid gross i.e. without tax being taken off on all our savings accounts - ISA accounts pay interest tax-free.")
            .section(buildSection("?", true, false))
            .build();

    final Help item2 =
        Help.builder()
            .header("What does 'Tiered' mean?")
            .text(
                "Tiered pays interest at different rates as the account balance increases or decreases")
            .section(buildSection("?", true, false))
            .build();

    final Help item3 =
        Help.builder()
            .header("What does 'AER' mean?")
            .text(
                "AER stands for the Annual Equivalent Rate and shows you what the interest rate would be if interest was paid and added each year. This will enable you to compare more easily the return you can expect from your savings over time.")
            .section(buildSection("?", true, false))
            .build();

    final Help item4 =
        Help.builder()
            .header("What does 'Variable' mean?")
            .text(
                "Variable rate of interest means that the interest rate payable on your account can change and can move both up and down.")
            .section(buildSection("?", true, false))
            .build();

    return Arrays.asList(item1, item2, item3, item4);
  }

  private static Interest buildExpectedWhenProductHasAnnualInterestAndNotTaxFreeAndTieredProduct() {
    return Interest.builder()
        .section(buildSection("1", true, false))
        .title("What is the interest rate?")
        .summary(
            "This account pays a <bold>variable<bold> tiered rate of interest <bold>annually<bold>:")
        .content(contentForScenario3())
        .help(helpForScenario3())
        .tiers(tierForScenario3())
        .build();
  }

  private static List<Content> contentForScenario3() {

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The rates we offer in the different tiers can vary and sometimes might be the same.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Whether you need to pay tax is dependent on your own personal circumstances and so may be subject to change in the future.")
            .build();

    final Content item3 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Payment of interest").build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Interest is calculated daily on cleared balances")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "The rate of interest on this account is tiered. You earn one rate of interest based on the tier your balance falls in.")
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Annual interest is paid on 31 March. It can be paid into the Another ISA account, another Yorkshire Building Society account or another building society or bank account.")
            .build();

    return Arrays.asList(item1, item2, item3, item4, item5, item6);
  }

  private static List<Tiers> tierForScenario3() {
    final Tiers item1 =
        Tiers.builder()
            .header("Balances from £1.00 - £999.99")
            .tax("<bold>0.15%<bold> Gross p.a.")
            .interest("<bold>0.15%<bold> AER")
            .build();

    final Tiers item2 =
        Tiers.builder()
            .header("Balances from £1,000.00 - £9,999.99")
            .tax("<bold>0.25%<bold> Gross p.a.")
            .interest("<bold>0.25%<bold> AER")
            .build();

    final Tiers item3 =
        Tiers.builder()
            .header("Balances from £10,000.00 - £49,999.99")
            .tax("<bold>0.35%<bold> Gross p.a.")
            .interest("<bold>0.35%<bold> AER")
            .build();

    final Tiers item4 =
        Tiers.builder()
            .header("Balances from £50,000.00 - £79,999.99")
            .tax("<bold>0.45%<bold> Gross p.a.")
            .interest("<bold>0.45%<bold> AER")
            .build();

    final Tiers item5 =
        Tiers.builder()
            .header("Balances from £80,000.00+")
            .tax("<bold>0.55%<bold> Gross p.a.")
            .interest("<bold>0.55%<bold> AER")
            .build();

    return Arrays.asList(item1, item2, item3, item4, item5);
  }

  private static List<Help> helpForScenario3() {
    final Help item1 =
        Help.builder()
            .header("What tax do I pay?")
            .text(
                "Interest is paid gross i.e. without tax being taken off on all our savings accounts - ISA accounts pay interest tax-free.")
            .section(buildSection("?", true, false))
            .build();

    final Help item2 =
        Help.builder()
            .header("What does 'Tiered' mean?")
            .text(
                "Tiered pays interest at different rates as the account balance increases or decreases")
            .section(buildSection("?", true, false))
            .build();

    final Help item3 =
        Help.builder()
            .header("What does 'AER' mean?")
            .text(
                "AER stands for the Annual Equivalent Rate and shows you what the interest rate would be if interest was paid and added each year. This will enable you to compare more easily the return you can expect from your savings over time.")
            .section(buildSection("?", true, false))
            .build();

    final Help item4 =
        Help.builder()
            .header("What does 'Variable' mean?")
            .text(
                "Variable rate of interest means that the interest rate payable on your account can change and can move both up and down.")
            .section(buildSection("?", true, false))
            .build();

    return Arrays.asList(item1, item2, item3, item4);
  }
}
