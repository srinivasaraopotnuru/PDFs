package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;

import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase;

class PermittedInterestDestinationsMapperTest {

  private static final String ALLOWABLE_INTEREST_INSTR = "ALLWII";

  private final PermittedInterestDestinationsMapper testSubject =
      new PermittedInterestDestinationsMapper();

  @Test
  void shouldMapSelfCreditWheInterestSelfCredit() {
    final ActiveProductRules productRules =
        createActiveProductRules(TestDataFactory.charProductRule(ALLOWABLE_INTEREST_INSTR, "1"));
    final List<ProductDetailsResponseBase.Interest.InterestDestinationType> permittedDestinations =
        new ArrayList<>();
    permittedDestinations.add(
        ProductDetailsResponseBase.Interest.InterestDestinationType.selfCredit);

    final ProductDetailsResponseBase.Interest interest =
        ProductDetailsResponseBase.Interest.builder()
            .interestPaid(ProductDetailsResponseBase.Interest.InterestPaidType.MONTHLY)
            .permittedInterestDestinations(permittedDestinations)
            .build();

    assertThat(testSubject.map(productRules), is(interest.getPermittedInterestDestinations()));
  }

  @Test
  void shouldMapAllPermittedDestinationsWhenInterestAllOptions() {
    final ActiveProductRules productRules =
        createActiveProductRules(TestDataFactory.charProductRule(ALLOWABLE_INTEREST_INSTR, "145"));
    final List<ProductDetailsResponseBase.Interest.InterestDestinationType> permittedDestinations =
        new ArrayList<>();
    permittedDestinations.add(
        ProductDetailsResponseBase.Interest.InterestDestinationType.selfCredit);
    permittedDestinations.add(
        ProductDetailsResponseBase.Interest.InterestDestinationType.payAwayInternal);
    permittedDestinations.add(
        ProductDetailsResponseBase.Interest.InterestDestinationType.payAwayExternal);
    final ProductDetailsResponseBase.Interest interest =
        ProductDetailsResponseBase.Interest.builder()
            .interestPaid(ProductDetailsResponseBase.Interest.InterestPaidType.MONTHLY)
            .permittedInterestDestinations(permittedDestinations)
            .build();

    assertThat(testSubject.map(productRules), is(interest.getPermittedInterestDestinations()));
  }

  @Test
  void shouldMapSelfCreditWhenInterestDestinationNotSet() {
    final ActiveProductRules productRules =
        createActiveProductRules(TestDataFactory.charProductRule(ALLOWABLE_INTEREST_INSTR, ""));
    final List<ProductDetailsResponseBase.Interest.InterestDestinationType> permittedDestinations =
        new ArrayList<>();

    final ProductDetailsResponseBase.Interest interest =
        ProductDetailsResponseBase.Interest.builder()
            .interestPaid(ProductDetailsResponseBase.Interest.InterestPaidType.MONTHLY)
            .permittedInterestDestinations(permittedDestinations)
            .build();

    assertThat(testSubject.map(productRules), is(interest.getPermittedInterestDestinations()));
  }

  @Test
  void shouldMapSelfCreditWhenInterestDestinationNotPresent() {
    final ActiveProductRules productRules = createActiveProductRules();
    final List<ProductDetailsResponseBase.Interest.InterestDestinationType> permittedDestinations =
        new ArrayList<>();

    final ProductDetailsResponseBase.Interest interest =
        ProductDetailsResponseBase.Interest.builder()
            .interestPaid(ProductDetailsResponseBase.Interest.InterestPaidType.MONTHLY)
            .permittedInterestDestinations(permittedDestinations)
            .build();

    assertThat(testSubject.map(productRules), is(interest.getPermittedInterestDestinations()));
  }
}
