package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Prerequisites;

public class PrerequisitesBuilderTest {
  private PrerequisitesBuilder testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new PrerequisitesBuilder();
  }

  @Test
  public void testMapsSuccessfully() {
    final WebSiteProduct webSiteProduct =
        TestHelper.buildFullWebsiteProductFixedISA(
            "Yes", "Fixed Rate Cash ISA until 30 September 2022", "", "Fixed Rate ISA", "Yes");

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Please take time to review the following documents before you apply.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text("Product Terms")
            .link("https://www.ybs.co.uk/productdata/Factsheet-YB281405B.pdf")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text("General Terms and Conditions")
            .link("https://www.ybs.co.uk/productdata/YBM0617_Inline_General_TandCs.pdf")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text("FSCS Information Sheet")
            .link("https://www.ybs.co.uk/productdata/FSCS.pdf")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text("Charges and Fees")
            .link("https://www.ybs.co.uk/productdata/Charges_and_Fees.pdf")
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text(
                "When you apply for this account with us, you'll need to <link>verify your identity and address<link>.")
            .link("https://www.ybs.co.uk/help/verifying-your-identity.html")
            .build();

    final Prerequisites expected =
        Prerequisites.builder()
            .section(buildSection("7", false, false))
            .title("Before you apply")
            .content(Arrays.asList(item1, item2, item3, item4, item5, item6))
            .build();

    final Prerequisites result = testSubject.map(webSiteProduct);
    assertThat(result, is(expected));
  }
}
