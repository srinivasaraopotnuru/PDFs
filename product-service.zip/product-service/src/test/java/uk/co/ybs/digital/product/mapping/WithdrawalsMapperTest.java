package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.Matchers.sameInstance;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;
import static uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.WithdrawalsPrivate.InterestPenalty;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Withdrawals;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.WithdrawalsPrivate;

@ExtendWith(MockitoExtension.class)
class WithdrawalsMapperTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2019-09-10T00:30:00.0");

  @InjectMocks private WithdrawalsMapper testSubject;
  @Mock private WithdrawalLimitsMapper withdrawalLimitsMapper;
  @Mock private WithdrawalsPermittedOverWebMapper withdrawalsPermittedOverWebMapper;
  @Mock private WithdrawalsInterestPenaltyMapper withdrawalsInterestPenaltyMapper;

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void shouldMap(final boolean permittedOverWeb) {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules = createActiveProductRules();

    when(withdrawalLimitsMapper.map(productRules)).thenReturn(Optional.empty());
    when(withdrawalsPermittedOverWebMapper.map(
            same(product), same(productRules), isNull(), same(NOW)))
        .thenReturn(permittedOverWeb);

    final Withdrawals withdrawals = testSubject.map(product, productRules, NOW);
    assertThat(withdrawals.getLimits(), is(nullValue()));
    assertThat(withdrawals.isPermittedOverWeb(), is(permittedOverWeb));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void shouldMapWithWithdrawalLimits(final boolean permittedOverWeb) {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules = createActiveProductRules();

    final Withdrawals.WithdrawalLimits withdrawalLimits =
        Withdrawals.WithdrawalLimits.builder()
            .number(PeriodLimits.<Long>builder().month(1L).build())
            .build();
    when(withdrawalLimitsMapper.map(productRules)).thenReturn(Optional.of(withdrawalLimits));
    when(withdrawalsPermittedOverWebMapper.map(
            same(product), same(productRules), same(withdrawalLimits), same(NOW)))
        .thenReturn(permittedOverWeb);

    final Withdrawals withdrawals = testSubject.map(product, productRules, NOW);
    assertThat(withdrawals.getLimits(), sameInstance(withdrawalLimits));
    assertThat(withdrawals.isPermittedOverWeb(), is(permittedOverWeb));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void shouldMapPrivate(final boolean permittedOverWeb) {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules = createActiveProductRules();

    when(withdrawalLimitsMapper.map(productRules)).thenReturn(Optional.empty());
    when(withdrawalsPermittedOverWebMapper.map(
            same(product), same(productRules), isNull(), same(NOW)))
        .thenReturn(permittedOverWeb);
    when(withdrawalsPermittedOverWebMapper.mapOnAccountClosure(same(productRules)))
        .thenReturn(permittedOverWeb);
    when(withdrawalsInterestPenaltyMapper.map(same(product))).thenReturn(Optional.empty());

    final WithdrawalsPrivate withdrawals = testSubject.mapPrivate(product, productRules, NOW);
    assertThat(withdrawals.getLimits(), is(nullValue()));
    assertThat(withdrawals.isPermittedOverWeb(), is(permittedOverWeb));
    assertThat(withdrawals.getInterestPenalty(), is(nullValue()));
    assertThat(withdrawals.isPermittedOverWebOnAccountClosure(), is(permittedOverWeb));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void shouldMapPrivateWithWithdrawalLimits(final boolean permittedOverWeb) {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules = createActiveProductRules();

    final Withdrawals.WithdrawalLimits withdrawalLimits =
        Withdrawals.WithdrawalLimits.builder()
            .number(PeriodLimits.<Long>builder().month(1L).build())
            .build();
    when(withdrawalLimitsMapper.map(productRules)).thenReturn(Optional.of(withdrawalLimits));
    when(withdrawalsPermittedOverWebMapper.map(
            same(product), same(productRules), same(withdrawalLimits), same(NOW)))
        .thenReturn(permittedOverWeb);
    when(withdrawalsPermittedOverWebMapper.mapOnAccountClosure(same(productRules)))
        .thenReturn(permittedOverWeb);
    when(withdrawalsInterestPenaltyMapper.map(same(product))).thenReturn(Optional.empty());

    final WithdrawalsPrivate withdrawals = testSubject.mapPrivate(product, productRules, NOW);
    assertThat(withdrawals.getLimits(), sameInstance(withdrawalLimits));
    assertThat(withdrawals.isPermittedOverWeb(), is(permittedOverWeb));
    assertThat(withdrawals.getInterestPenalty(), is(nullValue()));
    assertThat(withdrawals.isPermittedOverWebOnAccountClosure(), is(permittedOverWeb));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void shouldMapPrivateWithInterestPenaltyPresent(final boolean permittedOverWeb) {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules = createActiveProductRules();
    final InterestPenalty interestPenalty = InterestPenalty.builder().build();

    when(withdrawalLimitsMapper.map(productRules)).thenReturn(Optional.empty());
    when(withdrawalsPermittedOverWebMapper.map(
            same(product), same(productRules), isNull(), same(NOW)))
        .thenReturn(permittedOverWeb);
    when(withdrawalsPermittedOverWebMapper.mapOnAccountClosure(same(productRules)))
        .thenReturn(permittedOverWeb);
    when(withdrawalsInterestPenaltyMapper.map(same(product)))
        .thenReturn(Optional.of(interestPenalty));

    final WithdrawalsPrivate withdrawals = testSubject.mapPrivate(product, productRules, NOW);
    assertThat(withdrawals.getLimits(), is(nullValue()));
    assertThat(withdrawals.isPermittedOverWeb(), is(permittedOverWeb));
    assertThat(withdrawals.getInterestPenalty(), sameInstance(interestPenalty));
    assertThat(withdrawals.isPermittedOverWebOnAccountClosure(), is(permittedOverWeb));
  }

  @Test
  void shouldMapPrivateWhenWithdrawalsNotPermittedAndWithdrawalsOnAccountClosurePermitted() {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules = createActiveProductRules();
    final boolean permittedOverWeb = false;
    final boolean permittedOverWebOnAccountClosure = true;

    when(withdrawalLimitsMapper.map(productRules)).thenReturn(Optional.empty());
    when(withdrawalsPermittedOverWebMapper.map(
            same(product), same(productRules), isNull(), same(NOW)))
        .thenReturn(permittedOverWeb);
    when(withdrawalsPermittedOverWebMapper.mapOnAccountClosure(same(productRules)))
        .thenReturn(permittedOverWebOnAccountClosure);
    when(withdrawalsInterestPenaltyMapper.map(same(product))).thenReturn(Optional.empty());

    final WithdrawalsPrivate withdrawals = testSubject.mapPrivate(product, productRules, NOW);
    assertThat(withdrawals.getLimits(), is(nullValue()));
    assertThat(withdrawals.isPermittedOverWeb(), is(permittedOverWeb));
    assertThat(withdrawals.getInterestPenalty(), is(nullValue()));
    assertThat(
        withdrawals.isPermittedOverWebOnAccountClosure(), is(permittedOverWebOnAccountClosure));
  }

  private Product.ProductBuilder activeProduct() {
    return Product.builder().penaltyDays(0);
  }
}
