package uk.co.ybs.digital.product.web.dto.onsale;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.product.service.ProductCategoryType;

@JsonTest
public class ProductCategoryJsonTest {

  private static final String TEST_URL = "http://test.com";

  @Autowired private JacksonTester<ProductCategory> json;

  @Value("classpath:/responses/ProductCategoryResponse.json")
  private Resource file;

  @Value("classpath:/responses/ProductCategoryNullsOmittedResponse.json")
  private Resource nullsOmittedFile;

  @Test
  void canSerializeProductCategoriesResponse() throws Exception {

    final ProductCategory populated = createProductCategoriesResponse();

    assertThat(json.write(populated)).isEqualToJson(file, JSONCompareMode.STRICT);
  }

  @Test
  void canDeserializeProductCategoriesResponse() throws Exception {

    final ProductCategory populated = createProductCategoriesResponse();

    assertThat(json.read(file)).isEqualTo(populated);
  }

  @Test
  void serializationOmitsNullFields() throws Exception {

    final ProductCategory populated = createProductCategoriesResponseRequiredFieldsOnly();

    assertThat(json.write(populated)).isEqualToJson(nullsOmittedFile, JSONCompareMode.STRICT);
  }

  private static ProductCategory createProductCategoriesResponse() {
    final List<Product> products =
        Collections.singletonList(
            Product.builder()
                .name("Product A")
                .type(ProductType.SAVER)
                .url(TEST_URL)
                .productCode("YBS345SA")
                .minimumAge(16)
                .maximumAge(99)
                .maximumNumberOfAccounts(1)
                .interestFrequency(InterestFrequency.ANNUAL)
                .interestTiers(
                    Collections.singletonList(
                        InterestTier.builder()
                            .rate("0.1%")
                            .description("Gross p.a./AER variable on balances of")
                            .range("£1 - £999")
                            .build()))
                .facts(Collections.singletonList(Fact.builder().text("fact").build()))
                .build());
    return ProductCategory.builder()
        .title(ProductCategoryType.EASY_ACCESS.getTitle())
        .subTitle(ProductCategoryType.EASY_ACCESS.getSubTitle())
        .description(ProductCategoryType.EASY_ACCESS.getDescription())
        .url(TEST_URL)
        .offlineOnlyProductsAvailable(false)
        .products(products)
        .build();
  }

  private static ProductCategory createProductCategoriesResponseRequiredFieldsOnly() {
    final List<Product> products =
        Collections.singletonList(
            Product.builder()
                .name("Product A")
                .type(ProductType.SAVER)
                .url(TEST_URL)
                .productCode("YBS345SA")
                .interestFrequency(InterestFrequency.ANNUAL)
                .interestTiers(
                    Collections.singletonList(
                        InterestTier.builder()
                            .rate("0.1%")
                            .description("Gross p.a./AER variable on balances of")
                            .build()))
                .facts(Collections.singletonList(Fact.builder().text("fact").build()))
                .build());
    return ProductCategory.builder()
        .title(ProductCategoryType.EASY_ACCESS.getTitle())
        .subTitle(ProductCategoryType.EASY_ACCESS.getSubTitle())
        .description(ProductCategoryType.EASY_ACCESS.getDescription())
        .url(TEST_URL)
        .offlineOnlyProductsAvailable(false)
        .products(products)
        .build();
  }
}
