package uk.co.ybs.digital.product.mapping;

import static com.spotify.hamcrest.optional.OptionalMatchers.emptyOptional;
import static com.spotify.hamcrest.optional.OptionalMatchers.optionalWithValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;

import java.math.BigDecimal;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Balance;

class BalanceMapperTest {
  private static final String MAX_BAL_CODE = "MAXBAL";
  private static final String MIN_BAL_CODE = "MINABL";

  private BalanceMapper testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new BalanceMapper();
  }

  @Test
  void shouldMapToEmptyOptionalWhenProductRulesDoNotIncludeAnyBalanceRules() {
    final ActiveProductRules productRules = createActiveProductRules();

    assertThat(testSubject.map(productRules), emptyOptional());
  }

  @Test
  void shouldMapWhenProductRulesContainsMinAndMaxBalance() {
    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.moneyProductRule(MIN_BAL_CODE, BigDecimal.ONE),
            TestDataFactory.moneyProductRule(MAX_BAL_CODE, BigDecimal.TEN));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(is(Balance.builder().min(BigDecimal.ONE).max(BigDecimal.TEN).build())));
  }

  @Test
  void shouldMapWhenProductRulesContainsMinBalanceOnly() {
    final ActiveProductRules productRules =
        createActiveProductRules(TestDataFactory.moneyProductRule(MIN_BAL_CODE, BigDecimal.ONE));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(is(Balance.builder().min(BigDecimal.ONE).build())));
  }

  @Test
  void shouldMapWhenProductRulesContainsMaxBalanceOnly() {
    final ActiveProductRules productRules =
        createActiveProductRules(TestDataFactory.moneyProductRule(MAX_BAL_CODE, BigDecimal.TEN));

    assertThat(
        testSubject.map(productRules),
        optionalWithValue(is(Balance.builder().max(BigDecimal.TEN).build())));
  }
}
