package uk.co.ybs.digital.product.web.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableSet;
import java.lang.reflect.Method;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.MethodParameter;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.data.domain.Pageable;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.bind.support.DefaultDataBinderFactory;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;

@ExtendWith(MockitoExtension.class)
class ProductSearchCriteriaArgumentResolverTest {

  private ProductSearchCriteriaArgumentResolver testSubject;

  @Mock private ConversionService conversionService;

  @BeforeEach
  void beforeEach() {
    testSubject = new ProductSearchCriteriaArgumentResolver(conversionService);
  }

  @Test
  void shouldSupportMethodParameterThatIsProductSearchCriteria() throws NoSuchMethodException {
    assertThat(
        testSubject.supportsParameter(new MethodParameter(searchCriteriaMethod(), 0)), is(true));
  }

  @Test
  void shouldNotSupportMethodParameterThatIsNotProductSearchCriteria()
      throws NoSuchMethodException {
    assertThat(
        testSubject.supportsParameter(new MethodParameter(searchCriteriaMethod(), 1)),
        is(false)); // Pageable
  }

  @Test
  void shouldResolveArgument() throws Exception {
    final String productIdentifiersParamValue = "A,B,C";

    final MockHttpServletRequest request = new MockHttpServletRequest();
    request.addParameter("productIdentifiers", productIdentifiersParamValue);

    final Set<String> productIdentifiers = ImmutableSet.of("A", "B", "C");
    when(conversionService.convert(
            productIdentifiersParamValue,
            TypeDescriptor.valueOf(String.class),
            TypeDescriptor.collection(Set.class, TypeDescriptor.valueOf(String.class))))
        .thenReturn(productIdentifiers);

    final ModelAndViewContainer mavContainer = new ModelAndViewContainer();
    final NativeWebRequest webRequest = new ServletWebRequest(request);
    final WebDataBinderFactory binderFactory = new DefaultDataBinderFactory(null);

    final Object result =
        testSubject.resolveArgument(
            new MethodParameter(searchCriteriaMethod(), 0),
            mavContainer,
            webRequest,
            binderFactory);
    assertThat(
        result, is(ProductSearchCriteria.builder().productIdentifiers(productIdentifiers).build()));
  }

  private Method searchCriteriaMethod() throws NoSuchMethodException {
    return ProductController.class.getDeclaredMethod(
        "searchProductDetails", ProductSearchCriteria.class, Pageable.class);
  }
}
