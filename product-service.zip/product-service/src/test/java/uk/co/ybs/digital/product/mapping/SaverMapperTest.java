package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static uk.co.ybs.digital.product.TestDataFactory.charProductRule;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase;

@ExtendWith(MockitoExtension.class)
public class SaverMapperTest {

  private static final String SAVER_PRODUCT_TYPE = "SAVER";
  @InjectMocks private SaverMapper testSubject;

  @Test
  void shouldMapSaverProductSingleDepositAndMonthlySubscriptionPresentAndTrue() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE),
                charProductRule(AvailableProductRule.REGULAR_SAVER_MONTHLY_SUBSCRIPTION, "Y"),
                charProductRule(AvailableProductRule.REGULAR_SAVER_SINGLE_DEPOSIT, "Y"))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(true).build()));
  }

  @Test
  void shouldMapSaverProductSingleDepositPresentAndFalseAndMonthlySubscriptionPresentAndTrue() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE),
                charProductRule(AvailableProductRule.REGULAR_SAVER_MONTHLY_SUBSCRIPTION, "Y"),
                charProductRule(AvailableProductRule.REGULAR_SAVER_SINGLE_DEPOSIT, "N"))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(true).build()));
  }

  @Test
  void shouldMapSaverProductSingleDepositPresentAndTrueAndMonthlySubscriptionPresentAndFalse() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE),
                charProductRule(AvailableProductRule.REGULAR_SAVER_MONTHLY_SUBSCRIPTION, "N"),
                charProductRule(AvailableProductRule.REGULAR_SAVER_SINGLE_DEPOSIT, "Y"))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(true).build()));
  }

  @Test
  void shouldMapSaverProductSingleDepositPresentAndFalseAndMonthlySubscriptionPresentAndFalse() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE),
                charProductRule(AvailableProductRule.REGULAR_SAVER_MONTHLY_SUBSCRIPTION, "N"),
                charProductRule(AvailableProductRule.REGULAR_SAVER_SINGLE_DEPOSIT, "N"))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(false).build()));
  }

  @Test
  void shouldMapNonSaverProduct() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder().build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(nullValue()));
  }

  @Test
  void shouldMapSaverProductSingleDepositAndMonthlySubscriptionNotPresent() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(false).build()));
  }

  @Test
  void shouldMapSaverProductSingleDepositPresentAndTrueAndMonthlySubscriptionNotPresent() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE),
                charProductRule(AvailableProductRule.REGULAR_SAVER_SINGLE_DEPOSIT, "Y"))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(true).build()));
  }

  @Test
  void shouldMapSaverProductSingleDepositPresentAndFalseAndMonthlySubscriptionNotPresent() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE),
                charProductRule(AvailableProductRule.REGULAR_SAVER_SINGLE_DEPOSIT, "N"))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(false).build()));
  }

  @Test
  void shouldMapSaverProductSingleDepositNotPresentAndMonthlySubscriptionPresentAndTrue() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE),
                charProductRule(AvailableProductRule.REGULAR_SAVER_MONTHLY_SUBSCRIPTION, "Y"))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(true).build()));
  }

  @Test
  void shouldMapSaverProductSingleDepositNotPresentAndMonthlySubscriptionPresentAndFalse() {
    final ActiveProductRules activeProductRules =
        TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
            .addRules(
                charProductRule(AvailableProductRule.PRODUCT_TYPE, SAVER_PRODUCT_TYPE),
                charProductRule(AvailableProductRule.REGULAR_SAVER_MONTHLY_SUBSCRIPTION, "N"))
            .build();

    final ProductDetailsResponseBase.Saver saver = testSubject.map(activeProductRules);
    assertThat(saver, is(ProductDetailsResponseBase.Saver.builder().regular(false).build()));
  }
}
