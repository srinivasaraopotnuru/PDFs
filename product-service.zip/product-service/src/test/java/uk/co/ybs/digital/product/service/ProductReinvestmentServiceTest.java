package uk.co.ybs.digital.product.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.exception.MissingProductRulesException;
import uk.co.ybs.digital.product.exception.NoProductForIdentifierException;
import uk.co.ybs.digital.product.mapping.ReinvestmentResponseMapper;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductRule;
import uk.co.ybs.digital.product.repository.ProductRepository;
import uk.co.ybs.digital.product.repository.ProductRuleRepository;
import uk.co.ybs.digital.product.web.dto.reinvestment.ProductReinvestmentResponse;
import uk.co.ybs.digital.product.web.dto.reinvestment.ReinvestmentProduct;

@ExtendWith(MockitoExtension.class)
class ProductReinvestmentServiceTest {
  private static final String ISA_PRODUCT_TYPE = "ISA";
  private static final String BOND_PRODUCT_TYPE = "BOND";
  private static final String CHAR_VALUE_Y = "Y";
  private static final String CHAR_VALUE_N = "N";
  private static final String PRODUCT_IDENTIFIER_1 = "foo";
  private static final String PRODUCT_IDENTIFIER_2 = "bar";
  private static final ZoneId ZONE_ID = ZoneId.of("Europe/London");
  private static final Instant NOW_INSTANT = Instant.parse("2020-05-18T13:15:21Z");
  private static final LocalDateTime NOW = LocalDateTime.ofInstant(NOW_INSTANT, ZONE_ID);
  private static final Long PRODUCT_SYSID_1 = 1L;
  private static final Long PRODUCT_SYSID_2 = 2L;
  private static final List<String> REQUIRED_CURRENT_PRODUCT_RULES =
      Arrays.asList(
          AvailableProductRule.EXISA,
          AvailableProductRule.EXBOND,
          AvailableProductRule.PRODUCT_TYPE);

  @Mock private ProductRepository productRepository;
  @Mock private ProductRuleRepository productRuleRepository;
  @Mock private ReinvestmentResponseMapper reinvestmentResponseMapper;

  private ProductReinvestmentService testSubject;

  private final Clock clock = Clock.fixed(NOW_INSTANT, ZONE_ID);

  @BeforeEach
  void beforeEach() {
    testSubject =
        new ProductReinvestmentService(
            clock, productRepository, productRuleRepository, reinvestmentResponseMapper);
  }

  @ParameterizedTest
  @ValueSource(strings = {"ISA", "BOND"})
  void getReinvestmentProductsShouldSucceedWithValidProductIdentifierAndType(
      final String productType) {
    final Product foundProduct = buildProduct(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final List<ProductRule> productRules =
        buildValidProductRulesForProduct(foundProduct, productType);

    when(productRepository.findByProductIdentifier(PRODUCT_IDENTIFIER_1, NOW))
        .thenReturn(Optional.of(foundProduct));
    when(productRuleRepository.findByProductAndRuleCodes(any(), any(), any()))
        .thenReturn(productRules);

    final List<Product> eligibleProducts =
        Collections.singletonList(buildProduct(PRODUCT_SYSID_2, PRODUCT_IDENTIFIER_2));

    when(productRepository.findReinvestableProducts(any(), any())).thenReturn(eligibleProducts);
    when(reinvestmentResponseMapper.map(any())).thenCallRealMethod();

    final ProductReinvestmentResponse expected =
        ProductReinvestmentResponse.builder()
            .reinvestmentProducts(
                Collections.singletonList(
                    ReinvestmentProduct.builder().productIdentifier(PRODUCT_IDENTIFIER_2).build()))
            .build();

    assertEquals(testSubject.getReinvestmentProducts(PRODUCT_IDENTIFIER_1), expected);

    final LocalDateTime now = LocalDateTime.now(clock);

    verify(productRepository).findByProductIdentifier(PRODUCT_IDENTIFIER_1, now);
    verify(productRuleRepository)
        .findByProductAndRuleCodes(
            Collections.singletonList(foundProduct), REQUIRED_CURRENT_PRODUCT_RULES, now);
    verify(productRepository).findReinvestableProducts(productType, now);
    verify(reinvestmentResponseMapper).map(eligibleProducts);
  }

  @Test
  void getReinvestmentProductsShouldThrowExceptionWhenProductNotFound() {
    when(productRepository.findByProductIdentifier(any(), any())).thenReturn(Optional.empty());

    assertThrows(
        NoProductForIdentifierException.class,
        () -> testSubject.getReinvestmentProducts(PRODUCT_IDENTIFIER_1));

    final LocalDateTime now = LocalDateTime.now(clock);

    verify(productRepository).findByProductIdentifier(PRODUCT_IDENTIFIER_1, now);
    verifyNoInteractions(productRuleRepository);
    verifyNoMoreInteractions(productRepository);
    verifyNoInteractions(reinvestmentResponseMapper);
  }

  @Test
  void getReinvestmentProductsShouldReturnEmptyListInResponseWhenNoEligibleProductsFound() {
    final Product foundProduct = buildProduct(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final List<ProductRule> productRules =
        buildValidProductRulesForProduct(foundProduct, ISA_PRODUCT_TYPE);

    when(productRepository.findByProductIdentifier(PRODUCT_IDENTIFIER_1, NOW))
        .thenReturn(Optional.of(foundProduct));
    when(productRuleRepository.findByProductAndRuleCodes(any(), any(), any()))
        .thenReturn(productRules);
    when(productRepository.findReinvestableProducts(any(), any()))
        .thenReturn(Collections.emptyList());
    when(reinvestmentResponseMapper.map(any())).thenCallRealMethod();

    final ProductReinvestmentResponse expected =
        ProductReinvestmentResponse.builder().reinvestmentProducts(Collections.emptyList()).build();

    assertEquals(testSubject.getReinvestmentProducts(PRODUCT_IDENTIFIER_1), expected);

    final LocalDateTime now = LocalDateTime.now(clock);

    verify(productRepository).findByProductIdentifier(PRODUCT_IDENTIFIER_1, now);
    verify(productRuleRepository)
        .findByProductAndRuleCodes(
            Collections.singletonList(foundProduct), REQUIRED_CURRENT_PRODUCT_RULES, now);
    verify(productRepository).findReinvestableProducts(ISA_PRODUCT_TYPE, now);
    verify(reinvestmentResponseMapper).map(Collections.emptyList());
  }

  @ParameterizedTest
  @MethodSource("invalidProductRuleCodes")
  void getReinvestmentProductsShouldThrowExceptionWithInvalidProductRules(
      final List<String> ruleCodes, final List<String> ruleValues) {
    final Product foundProduct = buildProduct(PRODUCT_SYSID_1, PRODUCT_IDENTIFIER_1);
    final List<ProductRule> productRules =
        buildProductRulesForProduct(foundProduct, ruleCodes, ruleValues);

    when(productRepository.findByProductIdentifier(PRODUCT_IDENTIFIER_1, NOW))
        .thenReturn(Optional.of(foundProduct));
    when(productRuleRepository.findByProductAndRuleCodes(any(), any(), any()))
        .thenReturn(productRules);

    assertThrows(
        MissingProductRulesException.class,
        () -> testSubject.getReinvestmentProducts(PRODUCT_IDENTIFIER_1));

    final LocalDateTime now = LocalDateTime.now(clock);

    verify(productRepository).findByProductIdentifier(PRODUCT_IDENTIFIER_1, now);
    verify(productRuleRepository)
        .findByProductAndRuleCodes(
            Collections.singletonList(foundProduct), REQUIRED_CURRENT_PRODUCT_RULES, now);
    verifyNoMoreInteractions(productRepository);
    verifyNoInteractions(reinvestmentResponseMapper);
  }

  static Stream<Arguments> invalidProductRuleCodes() {
    return Stream.of(
        // Just product type
        Arguments.of(
            Collections.singletonList(AvailableProductRule.PRODUCT_TYPE),
            Collections.singletonList(ISA_PRODUCT_TYPE)),
        Arguments.of(
            Collections.singletonList(AvailableProductRule.PRODUCT_TYPE),
            Collections.singletonList(BOND_PRODUCT_TYPE)),
        // No PRDTYP rule
        Arguments.of(
            Collections.singletonList(AvailableProductRule.EXBOND),
            Collections.singletonList(CHAR_VALUE_Y)),
        // Invalid EXBOND/EXISA value
        Arguments.of(
            Arrays.asList(AvailableProductRule.PRODUCT_TYPE, AvailableProductRule.EXISA),
            Arrays.asList(ISA_PRODUCT_TYPE, CHAR_VALUE_N)),
        Arguments.of(
            Arrays.asList(AvailableProductRule.PRODUCT_TYPE, AvailableProductRule.EXBOND),
            Arrays.asList(BOND_PRODUCT_TYPE, CHAR_VALUE_N)));
  }

  private Product buildProduct(final Long sysid, final String productIdentifier) {
    return Product.builder().sysid(sysid).productIdentifier(productIdentifier).build();
  }

  private List<ProductRule> buildValidProductRulesForProduct(
      final Product product, final String productType) {
    final String ruleCode =
        ISA_PRODUCT_TYPE.equals(productType)
            ? AvailableProductRule.EXISA
            : AvailableProductRule.EXBOND;
    return Stream.of(
            buildProductRule(product, ruleCode, CHAR_VALUE_Y),
            buildProductRule(product, AvailableProductRule.PRODUCT_TYPE, productType))
        .collect(Collectors.toList());
  }

  private List<ProductRule> buildProductRulesForProduct(
      final Product product, final List<String> ruleCodes, final List<String> ruleValues) {
    return IntStream.range(0, ruleCodes.size())
        .mapToObj(i -> buildProductRule(product, ruleCodes.get(i), ruleValues.get(i)))
        .collect(Collectors.toList());
  }

  private ProductRule buildProductRule(
      final Product product, final String ruleCode, final String charValue) {
    return ProductRule.builder()
        .product(product)
        .availableProductRule(
            AvailableProductRule.builder()
                .code(ruleCode)
                .valueType(AvailableProductRule.ValueType.CHAR)
                .build())
        .charValue(charValue)
        .build();
  }
}
