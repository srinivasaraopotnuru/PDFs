package uk.co.ybs.digital.product.mapping;

import static com.spotify.hamcrest.optional.OptionalMatchers.emptyOptional;
import static com.spotify.hamcrest.optional.OptionalMatchers.optionalWithValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.service.TessaYearCalculator;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Deposits.DepositLimits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;

@ExtendWith(MockitoExtension.class)
class DepositLimitsMapperTest {
  private static final String CALENDAR_YEAR_CODE = "MAXDPC";
  private static final String ANNIVERSARY_YEAR_CODE = "MAXDPA";
  private static final String PRODUCT_TERM_CODE = "MAXDPP";
  private static final String TAX_YEAR_CODE_PREFIX = "MXYR";
  private static final String MONTH_CODE = "MAXPAY";
  private static final String FIRST_MONTH_CODE = "MXPYFM";

  private static final LocalDateTime NOW = LocalDateTime.parse("2019-09-10T00:30:00.0");

  @InjectMocks private DepositLimitsMapper testSubject;

  @Mock private TessaYearCalculator tessaYearCalculator;

  @MethodSource("basicMappingArguments")
  @ParameterizedTest
  void shouldMap(final ActiveProductRules productRules, final DepositLimits expected) {
    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(22);

    final Optional<DepositLimits> mapped = testSubject.map(productRules, NOW);
    assertThat(mapped, optionalWithValue(is(expected)));
  }

  private static Stream<Arguments> basicMappingArguments() {
    return Stream.of(
        // First Month only
        Arguments.of(
            createActiveProductRules(
                TestDataFactory.moneyProductRule(FIRST_MONTH_CODE, BigDecimal.ONE)),
            DepositLimits.builder()
                .amount(PeriodLimits.<BigDecimal>builder().firstMonth(BigDecimal.ONE).build())
                .build()),
        // Month only
        Arguments.of(
            createActiveProductRules(TestDataFactory.moneyProductRule(MONTH_CODE, BigDecimal.ONE)),
            DepositLimits.builder()
                .amount(PeriodLimits.<BigDecimal>builder().month(BigDecimal.ONE).build())
                .build()),
        // Calendar year only
        Arguments.of(
            createActiveProductRules(
                TestDataFactory.moneyProductRule(CALENDAR_YEAR_CODE, BigDecimal.ONE)),
            DepositLimits.builder()
                .amount(PeriodLimits.<BigDecimal>builder().year(BigDecimal.ONE).build())
                .build()),
        // Anniversary year only
        Arguments.of(
            createActiveProductRules(
                TestDataFactory.moneyProductRule(ANNIVERSARY_YEAR_CODE, BigDecimal.ONE)),
            DepositLimits.builder()
                .amount(PeriodLimits.<BigDecimal>builder().anniversaryYear(BigDecimal.ONE).build())
                .build()),
        // Tax year only
        Arguments.of(
            createActiveProductRules(
                TestDataFactory.moneyProductRule(TAX_YEAR_CODE_PREFIX + 22, BigDecimal.ONE)),
            DepositLimits.builder()
                .amount(PeriodLimits.<BigDecimal>builder().taxYear(BigDecimal.ONE).build())
                .build()),
        // Product term only
        Arguments.of(
            createActiveProductRules(
                TestDataFactory.moneyProductRule(PRODUCT_TERM_CODE, BigDecimal.ONE)),
            DepositLimits.builder()
                .amount(PeriodLimits.<BigDecimal>builder().productTerm(BigDecimal.ONE).build())
                .build()),
        // All limits
        Arguments.of(
            createActiveProductRules(
                TestDataFactory.moneyProductRule(FIRST_MONTH_CODE, BigDecimal.ONE),
                TestDataFactory.moneyProductRule(MONTH_CODE, new BigDecimal(2)),
                TestDataFactory.moneyProductRule(CALENDAR_YEAR_CODE, new BigDecimal(4)),
                TestDataFactory.moneyProductRule(ANNIVERSARY_YEAR_CODE, new BigDecimal(8)),
                TestDataFactory.moneyProductRule(PRODUCT_TERM_CODE, new BigDecimal(16)),
                TestDataFactory.moneyProductRule(TAX_YEAR_CODE_PREFIX + 22, new BigDecimal(32))),
            DepositLimits.builder()
                .amount(
                    PeriodLimits.<BigDecimal>builder()
                        .firstMonth(BigDecimal.ONE)
                        .month(new BigDecimal(2))
                        .year(new BigDecimal(4))
                        .anniversaryYear(new BigDecimal(8))
                        .productTerm(new BigDecimal(16))
                        .taxYear(new BigDecimal(32))
                        .build())
                .build()));
  }

  @Test
  void shouldMapToEmptyOptionalWhenProductRulesDoNotIncludeAnyDepositLimitRules() {
    when(tessaYearCalculator.getTessaYear(NOW)).thenReturn(22);

    final ActiveProductRules productRules = createActiveProductRules();
    final Optional<DepositLimits> mapped = testSubject.map(productRules, NOW);
    assertThat(mapped, emptyOptional());
  }
}
