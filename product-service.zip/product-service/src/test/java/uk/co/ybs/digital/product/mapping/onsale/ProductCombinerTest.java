package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import uk.co.ybs.digital.product.service.WebSiteProduct;

class ProductCombinerTest {

  private static final String YES = "Yes";
  private final ProductCombiner testSubject = new ProductCombiner();

  @Test
  void combineMultiChannelShouldNotAlterSingleChannelProducts() {
    final List<WebSiteProduct> products =
        Arrays.asList(
            webSiteProductBuilder().productCode("A").build(),
            webSiteProductBuilder().productCode("B").build(),
            webSiteProductBuilder().productCode("C").build());

    final List<WebSiteProduct> combinedProducts = testSubject.combineMultiChannel(products);

    assertThat(combinedProducts, is(products));
  }

  @Test
  void combineMultiChannelShouldCombineAddSingleChannelProductsFirst() {
    final List<WebSiteProduct> products =
        Arrays.asList(
            webSiteProductBuilder().productCode("C").equivalentProduct("D").build(),
            webSiteProductBuilder().productCode("A").build(),
            webSiteProductBuilder().productCode("B").build());

    final List<WebSiteProduct> expectedCombinedProducts =
        Arrays.asList(
            webSiteProductBuilder().productCode("A").build(),
            webSiteProductBuilder().productCode("B").build(),
            webSiteProductBuilder().productCode("C").equivalentProduct("D").build());

    final List<WebSiteProduct> combinedProducts = testSubject.combineMultiChannel(products);

    assertThat(combinedProducts, is(expectedCombinedProducts));
  }

  @ParameterizedTest
  @MethodSource("branchOptions")
  void combineMultiChannelShouldCombineWebProductIntoBranchProduct(
      final Consumer<WebSiteProduct.WebSiteProductBuilder> branchOptions) {
    final List<WebSiteProduct> products =
        Arrays.asList(
            webSiteProductBuilder()
                .productCode("A")
                .equivalentProduct("B")
                .accountNameFull("Branch Name Full A")
                .accountNameShort("Branch Name Short A")
                .accept(branchOptions)
                .build(),
            webSiteProductBuilder()
                .productCode("B")
                .equivalentProduct("A")
                .accountNameFull("Online Name Full B")
                .accountNameShort("Online Name Short B")
                .applyOnline(YES)
                .build());

    final List<WebSiteProduct> expectedCombinedProducts =
        Collections.singletonList(
            webSiteProductBuilder()
                .productCode("B")
                .equivalentProduct("B")
                .accountNameFull("Branch Name Full A")
                .accountNameShort("Branch Name Short A")
                .accept(branchOptions)
                .applyOnline(YES)
                .build());

    final List<WebSiteProduct> combinedProducts = testSubject.combineMultiChannel(products);

    assertThat(combinedProducts, is(expectedCombinedProducts));
  }

  @ParameterizedTest
  @CsvSource({"YB921546B,YB931546W", "YB901552B,YB901552W"})
  void combineMultiChannelShouldNotCombineCertainProducts(
      final String branchProductCode, final String onlineProductCode) {
    final List<WebSiteProduct> products =
        Arrays.asList(
            webSiteProductBuilder()
                .productCode(branchProductCode)
                .equivalentProduct(onlineProductCode)
                .accountNameFull("Branch Name Full A")
                .accountNameShort("Branch Name Short A")
                .build(),
            webSiteProductBuilder()
                .productCode(onlineProductCode)
                .equivalentProduct(branchProductCode)
                .accountNameFull("Online Name Full B")
                .accountNameShort("Online Name Short B")
                .applyOnline(YES)
                .build());

    final List<WebSiteProduct> combinedProducts = testSubject.combineMultiChannel(products);

    assertThat(combinedProducts, is(products));
  }

  @ParameterizedTest
  @MethodSource("branchOptions")
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void combineMultiChannelShouldCombineBranchProductIntoWebProduct(
      final Consumer<WebSiteProduct.WebSiteProductBuilder> branchOptions) {
    final List<WebSiteProduct> products =
        Arrays.asList(
            webSiteProductBuilder()
                .productCode("A")
                .equivalentProduct("B")
                .accountNameFull("Online Name Full A")
                .accountNameShort("Online Name Short A")
                .applyOnline(YES)
                .build(),
            webSiteProductBuilder()
                .productCode("B")
                .equivalentProduct("A")
                .accountNameFull("Branch Name Full B")
                .accountNameShort("Branch Name Short B")
                .accept(branchOptions)
                .build());

    final List<WebSiteProduct> expectedCombinedProducts =
        Collections.singletonList(
            webSiteProductBuilder()
                .productCode("A")
                .equivalentProduct("B")
                .accountNameFull("Branch Name Full B")
                .accountNameShort("Branch Name Short B")
                .applyOnline(YES)
                .accept(branchOptions)
                .build());

    final List<WebSiteProduct> combinedProducts = testSubject.combineMultiChannel(products);

    assertThat(combinedProducts, is(expectedCombinedProducts));
  }

  @ParameterizedTest
  @NullSource
  @ValueSource(strings = {"", "No"})
  void
      combineMultiChannelShouldCombineBranchProductWithVariousNegativeApplyOnlineValuesIntoWebProduct(
          final String applyOnline) {
    final List<WebSiteProduct> products =
        Arrays.asList(
            webSiteProductBuilder()
                .productCode("A")
                .equivalentProduct("B")
                .accountNameFull("Online Name Full A")
                .accountNameShort("Online Name Short A")
                .applyOnline(YES)
                .build(),
            webSiteProductBuilder()
                .productCode("B")
                .equivalentProduct("A")
                .accountNameFull("Branch Name Full B")
                .accountNameShort("Branch Name Short B")
                .applyInBranch(YES)
                .applyOnline(applyOnline)
                .build());

    final List<WebSiteProduct> expectedCombinedProducts =
        Collections.singletonList(
            webSiteProductBuilder()
                .productCode("A")
                .equivalentProduct("B")
                .accountNameFull("Branch Name Full B")
                .accountNameShort("Branch Name Short B")
                .applyOnline(YES)
                .applyInBranch(YES)
                .build());

    final List<WebSiteProduct> combinedProducts = testSubject.combineMultiChannel(products);

    assertThat(combinedProducts, is(expectedCombinedProducts));
  }

  @Test
  void combineMultiChannelShouldCombineSingleAndMultiChannelProducts() {
    final List<WebSiteProduct> products =
        Arrays.asList(
            // Squash web into branch
            webSiteProductBuilder()
                .productCode("C")
                .equivalentProduct("D")
                .accountNameFull("Branch Name Full C")
                .accountNameShort("Branch Name Short C")
                .applyInBranch(YES)
                .build(),
            webSiteProductBuilder()
                .productCode("D")
                .equivalentProduct("C")
                .accountNameFull("Online Name Full D")
                .accountNameShort("Online Name Short D")
                .applyOnline(YES)
                .build(),
            // Squash branch into web
            webSiteProductBuilder()
                .productCode("E")
                .equivalentProduct("F")
                .accountNameFull("Online Name Full E")
                .accountNameShort("Online Name Short E")
                .applyOnline(YES)
                .build(),
            webSiteProductBuilder()
                .productCode("F")
                .equivalentProduct("E")
                .accountNameFull("Branch Name Full F")
                .accountNameShort("Branch Name Short F")
                .applyInBranch(YES)
                .build(),
            // Single channel products
            WebSiteProduct.builder()
                .productCode("A")
                .accountNameFull("Single Name Full A")
                .accountNameShort("Single Name Short A")
                .build(),
            WebSiteProduct.builder()
                .productCode("B")
                .accountNameFull("Single Name Full B")
                .accountNameShort("Single Name Short B")
                .build());

    final List<WebSiteProduct> expectedCombinedProducts =
        Arrays.asList(
            WebSiteProduct.builder()
                .productCode("A")
                .accountNameFull("Single Name Full A")
                .accountNameShort("Single Name Short A")
                .build(),
            WebSiteProduct.builder()
                .productCode("B")
                .accountNameFull("Single Name Full B")
                .accountNameShort("Single Name Short B")
                .build(),
            webSiteProductBuilder()
                .productCode("D")
                .equivalentProduct("D")
                .accountNameFull("Branch Name Full C")
                .accountNameShort("Branch Name Short C")
                .applyInBranch(YES)
                .applyOnline(YES)
                .build(),
            webSiteProductBuilder()
                .productCode("E")
                .equivalentProduct("F")
                .accountNameFull("Branch Name Full F")
                .accountNameShort("Branch Name Short F")
                .applyInBranch(YES)
                .applyOnline(YES)
                .build());

    final List<WebSiteProduct> combinedProducts = testSubject.combineMultiChannel(products);

    assertThat(combinedProducts, is(expectedCombinedProducts));
  }

  private static Stream<Consumer<WebSiteProduct.WebSiteProductBuilder>> branchOptions() {
    return Stream.of(
        builder -> builder.applyInBranch(YES),
        builder -> builder.applyInAgency(YES),
        builder -> builder.applyByPost(YES),
        builder -> builder.applyInBranch(YES).applyInAgency(YES).applyByPost(YES));
  }

  private static WebSiteProduct.WebSiteProductBuilder webSiteProductBuilder() {
    return WebSiteProduct.builder()
        .applyOnline("")
        .applyInBranch("")
        .applyInAgency("")
        .applyByPost("");
  }
}
