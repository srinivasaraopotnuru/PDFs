package uk.co.ybs.digital.product.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.same;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cache.CacheManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import uk.co.ybs.digital.product.config.onsale.CachingConfiguration;
import uk.co.ybs.digital.product.exception.NoProductForIdentifierException;
import uk.co.ybs.digital.product.exception.ProductNotSupportedException;
import uk.co.ybs.digital.product.mapping.onsale.ProductResponseMapper;
import uk.co.ybs.digital.product.mapping.onsale.TypeMapper;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.AccountBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.AdditionalInformationBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.ApplyBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.InterestBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.InterestRateChangesBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.ManageAccountBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.PrerequisitesBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.ProjectionsBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.WithdrawalsBuilder;
import uk.co.ybs.digital.product.utils.TestHelper;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ProductSummary;

@ExtendWith({SpringExtension.class})
@ContextConfiguration(
    classes = {
      OnSaleProductService.class,
      CachingConfiguration.class,
      TypeMapper.class,
      AccountBuilder.class,
      InterestRateChangesBuilder.class,
      ApplyBuilder.class,
      AdditionalInformationBuilder.class,
      PrerequisitesBuilder.class,
      InterestBuilder.class,
      ManageAccountBuilder.class,
      ProjectionsBuilder.class,
      WithdrawalsBuilder.class
    })
class OnSaleProductServiceTest {

  private static final List<ProductCategory> EXPECTED_RESPONSE =
      Collections.singletonList(
          buildProductCategory(ProductCategoryType.EASY_ACCESS, Collections.emptyList()));

  private static final UUID REQUEST_ID = UUID.fromString("564e6e5c-7fac-4c68-b721-4e466645c7e3");

  @Autowired private OnSaleProductService testSubject;

  @MockBean private WebSiteProductIngestService webSiteProductIngestService;

  @MockBean private ProductResponseMapper productResponseMapper;

  @MockBean private TypeMapper typeMapper;

  @Autowired private CacheManager cacheManager;

  @BeforeEach
  void setUp() {
    TestHelper.clearCacheManager(cacheManager);
  }

  @Test
  void getProductsShouldGetWebSiteProductsAndMapResponse() {
    stubGetProducts();
    doGetProducts(1);
  }

  @Test
  void getProductsShouldCacheResponse() {
    stubGetProducts();
    doGetProducts(1);

    doGetProducts(1);
  }

  @Test
  void clearCacheShouldResultInGetProductsRebuildingCachedResponse() {
    stubGetProducts();
    doGetProducts(1);

    testSubject.clearCache();

    doGetProducts(2);
  }

  @Test
  void shouldThrowProductNotFoundExceptionWhenProductNotFound() {
    assertThrows(
        NoProductForIdentifierException.class,
        () -> testSubject.getProductSummary("unknown", REQUEST_ID));
  }

  @Test
  void shouldThrowProductNotUnsupportedWhenProductIsNotISA() {
    stubGetProducts();

    when(typeMapper.map(any())).thenReturn(ProductType.BOND);
    assertThrows(
        ProductNotSupportedException.class, () -> testSubject.getProductSummary("1", REQUEST_ID));
  }

  @Test
  void shouldGetProductSummary() throws Exception {
    final WebSiteProduct webSiteProduct = TestHelper.buildFullWebsiteProductISA();
    when(webSiteProductIngestService.get(REQUEST_ID))
        .thenReturn(Collections.singletonList(webSiteProduct));
    when(typeMapper.map(webSiteProduct)).thenReturn(ProductType.ISA);
    final ProductSummary expected = TestHelper.buildExpectedMappingForFixedISA();
    final ProductSummary result = testSubject.getProductSummary("YB291415W", REQUEST_ID);
    assertThat(result, is(expected));
  }

  private void stubGetProducts() {
    final List<WebSiteProduct> productList =
        Collections.singletonList(
            WebSiteProduct.builder().easyAccess("Yes").productID("1").build());

    when(webSiteProductIngestService.get(REQUEST_ID)).thenReturn(productList);
    when(productResponseMapper.map(same(productList))).thenReturn(EXPECTED_RESPONSE);
  }

  private void doGetProducts(final int expectedInvocations) {
    assertThat(testSubject.getProducts(REQUEST_ID), is(EXPECTED_RESPONSE));
    verify(webSiteProductIngestService, times(expectedInvocations)).get(REQUEST_ID);
    verify(productResponseMapper, times(expectedInvocations)).map(any());
  }

  private static ProductCategory buildProductCategory(
      final ProductCategoryType type, final List<Product> products) {
    return ProductCategory.builder()
        .title(type.getTitle())
        .subTitle(type.getSubTitle())
        .description(type.getDescription())
        .url("http://test.com")
        .offlineOnlyProductsAvailable(false)
        .products(products)
        .build();
  }
}
