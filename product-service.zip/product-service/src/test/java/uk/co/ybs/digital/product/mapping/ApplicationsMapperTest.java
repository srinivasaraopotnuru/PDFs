package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.product.TestDataFactory.createActiveProductRules;

import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;

class ApplicationsMapperTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2019-09-10T00:30:00.0");
  private static final String VALUE_123 = "123";

  private ApplicationsMapper testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new ApplicationsMapper();
  }

  @Test
  void shouldMapApplicationsArePermitted() {
    final Product product = Product.builder().startDate(NOW).build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(
                AvailableProductRule.ALLOWABLE_INTEREST_INSTR, VALUE_123),
            TestDataFactory.longProductRule(AvailableProductRule.PRODUCT_SUFFIX, 30L),
            TestDataFactory.charProductRule(AvailableProductRule.WEB_SALE, "Y"));
    assertThat(testSubject.map(product, productRules, NOW).isApplicationsPermitted(), is(true));
  }

  @Test
  void shouldMapApplicationsNotPermittedNoStartDate() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(
                AvailableProductRule.ALLOWABLE_INTEREST_INSTR, VALUE_123),
            TestDataFactory.longProductRule(AvailableProductRule.PRODUCT_SUFFIX, 30L),
            TestDataFactory.charProductRule(AvailableProductRule.WEB_SALE, "Y"));
    assertThat(testSubject.map(product, productRules, NOW).isApplicationsPermitted(), is(false));
  }

  @Test
  void shouldMapApplicationsAreNotPermittedNoWebSal() {
    final Product product = Product.builder().startDate(NOW).build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(
                AvailableProductRule.ALLOWABLE_INTEREST_INSTR, VALUE_123),
            TestDataFactory.longProductRule(AvailableProductRule.PRODUCT_SUFFIX, 30L));
    assertThat(testSubject.map(product, productRules, NOW).isApplicationsPermitted(), is(false));
  }

  @Test
  void shouldMapApplicationsAreNotPermittedNoAllwi() {
    final Product product = Product.builder().startDate(NOW).build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.longProductRule(AvailableProductRule.PRODUCT_SUFFIX, 30L),
            TestDataFactory.charProductRule(AvailableProductRule.WEB_SALE, "Y"));
    assertThat(testSubject.map(product, productRules, NOW).isApplicationsPermitted(), is(false));
  }

  @Test
  void shouldMapApplicationsAreNotPermittedNoProductSuffix() {
    final Product product = Product.builder().startDate(NOW).build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(
                AvailableProductRule.ALLOWABLE_INTEREST_INSTR, VALUE_123),
            TestDataFactory.charProductRule(AvailableProductRule.WEB_SALE, "Y"));
    assertThat(testSubject.map(product, productRules, NOW).isApplicationsPermitted(), is(false));
  }

  @Test
  void shouldMapFatacaReportable() {
    final Product product = Product.builder().fatcaReportable("Y").build();

    final ActiveProductRules productRules = createActiveProductRules();
    assertThat(testSubject.map(product, productRules, NOW).isFatcaReportable(), is(true));
  }

  @Test
  void shouldMapFatacaNotReportable() {
    final Product product = Product.builder().build();
    final ActiveProductRules productRules = createActiveProductRules();

    assertThat(testSubject.map(product, productRules, NOW).isFatcaReportable(), is(false));
  }

  @Test
  void shouldMapNIRequired() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(AvailableProductRule.NI_NUMBER, "Y"));
    assertThat(
        testSubject.map(product, productRules, NOW).isNationalInsuranceNumberRequired(), is(true));
  }

  @Test
  void shouldMapNINotRequired() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(AvailableProductRule.NI_NUMBER, "W"));
    assertThat(
        testSubject.map(product, productRules, NOW).isNationalInsuranceNumberRequired(), is(false));
  }

  @Test
  void shouldMapMinAgeLessThanDefault() {
    final Product product = Product.builder().startDate(NOW).fatcaReportable("Y").build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(
                AvailableProductRule.ALLOWABLE_INTEREST_INSTR, VALUE_123),
            TestDataFactory.longProductRule(AvailableProductRule.PRODUCT_SUFFIX, 30L),
            TestDataFactory.charProductRule(AvailableProductRule.WEB_SALE, "Y"),
            TestDataFactory.charProductRule(AvailableProductRule.NI_NUMBER, "Y"),
            TestDataFactory.longProductRule(AvailableProductRule.MIN_AGE, 2L));

    assertThat(testSubject.map(product, productRules, NOW).getMinimumAge(), is(16L));
  }

  @Test
  void shouldMapMinAgeGreaterThanDefault() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(AvailableProductRule.MIN_AGE, "24"));
    assertThat(testSubject.map(product, productRules, NOW).getMinimumAge(), is(24L));
  }

  @Test
  void shouldMapMaxAgeLessThanDefault() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(AvailableProductRule.MAX_AGE, "25"));
    assertThat(testSubject.map(product, productRules, NOW).getMaximumAge(), is(25L));
  }

  @Test
  void shouldMapMaxAgeGreaterThanDefault() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(AvailableProductRule.MAX_AGE, "112"));

    assertThat(testSubject.map(product, productRules, NOW).getMaximumAge(), is(105L));
  }

  @Test
  void shouldMapOneApplicantForIsa() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(AvailableProductRule.PRODUCT_TYPE, "ISA"));
    assertThat(testSubject.map(product, productRules, NOW).getMaximumApplicants(), is(1L));
  }

  @Test
  void shouldMapTwoApplicantNotIsa() {
    final Product product = Product.builder().build();

    final ActiveProductRules productRules =
        createActiveProductRules(
            TestDataFactory.charProductRule(AvailableProductRule.PRODUCT_TYPE, "I"));
    assertThat(testSubject.map(product, productRules, NOW).getMaximumApplicants(), is(2L));
  }
}
