package uk.co.ybs.digital.product.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.product.utils.TestHelper.ISA_FLEXIBLE;
import static uk.co.ybs.digital.product.utils.TestHelper.ISA_HELP_TO_BUY;
import static uk.co.ybs.digital.product.utils.TestHelper.OFFSET_ACCOUNT;
import static uk.co.ybs.digital.product.utils.TestHelper.PAYMENT_ACCOUNT;
import static uk.co.ybs.digital.product.utils.TestHelper.PRODUCT_TYPE;
import static uk.co.ybs.digital.product.utils.TestHelper.WEB_TRANSACTIONS;
import static uk.co.ybs.digital.product.utils.TestHelper.WEB_WITHDRAWALS;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.product.TestDataFactory;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase;

@ExtendWith(MockitoExtension.class)
class WithdrawalsPermittedOverWebMapperTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2019-09-10T00:30:00.0");

  @InjectMocks private WithdrawalsPermittedOverWebMapper testSubject;

  @Mock private PeriodLimitsChecker periodLimitsChecker;

  @Test
  void
      shouldAllowWebWithdrawalsWhenSavingsProductActiveAndWebWithdrawalsAvailableAndProductTypeSaverAndWithdrawalLimitsAbsent() {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder().build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(true));
  }

  @ParameterizedTest
  @MethodSource("withdrawalsPermittedOverWebProductTypeRules")
  void shouldAllowWebWithdrawalsWhenSupportedProductAndWebWithdrawalsAvailable(
      final ActiveProductRules productRules) {
    final Product product = activeProduct().build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(true));
  }

  private static Stream<ActiveProductRules> withdrawalsPermittedOverWebProductTypeRules() {
    return Stream.of(
        // Payment product
        withdrawalsActiveProductRulesBuilder()
            .addRules(TestDataFactory.charProductRule(PAYMENT_ACCOUNT, "Y"))
            .build(),
        // Saver product
        withdrawalsActiveProductRulesBuilder()
            .addRules(TestDataFactory.charProductRule(PRODUCT_TYPE, "SAVER"))
            .build(),
        // ISA product - Classic
        withdrawalsActiveProductRulesBuilder()
            .addRules(TestDataFactory.charProductRule(PRODUCT_TYPE, "ISA"))
            .build(),
        // ISA product - Help to buy
        withdrawalsActiveProductRulesBuilder()
            .addRules(
                TestDataFactory.charProductRule(PRODUCT_TYPE, "ISA"),
                TestDataFactory.charProductRule(ISA_HELP_TO_BUY, "Y"))
            .build(),
        // ISA product - Flexible
        withdrawalsActiveProductRulesBuilder()
            .addRules(
                TestDataFactory.charProductRule(PRODUCT_TYPE, "ISA"),
                TestDataFactory.charProductRule(ISA_FLEXIBLE, "Y"))
            .build());
  }

  @ParameterizedTest
  @MethodSource("withdrawalsNotPermittedOverWebProductTypeRules")
  void shouldNotAllowWebWithdrawalsWhenNotSupportedProductAndWebWithdrawalsAvailable(
      final ActiveProductRules productRules) {
    final Product product = activeProduct().build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(false));
  }

  private static Stream<ActiveProductRules> withdrawalsNotPermittedOverWebProductTypeRules() {
    return Stream.of(
        // No product type rules
        withdrawalsActiveProductRulesBuilder().build(),
        // Invalid product type rule values
        withdrawalsActiveProductRulesBuilder()
            .addRules(
                TestDataFactory.charProductRule(PAYMENT_ACCOUNT, "N"),
                TestDataFactory.charProductRule(PRODUCT_TYPE, "OTHER"))
            .build());
  }

  @Test
  void shouldNotAllowWebWithdrawalsWhenNeitherProductTypeSavingsOrPaymentAccountTrue() {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder()
            .changeRule(PRODUCT_TYPE, "some-product-type")
            .build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(false));
  }

  @Test
  void shouldNotAllowWebWithdrawalsWhenWebWithdrawalProductRuleIsFalse() {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder()
            .changeRule(WEB_WITHDRAWALS, "N")
            .build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(false));
  }

  @Test
  void shouldNotAllowWebWithdrawalsWhenWebWithdrawalProductRuleIsAbsent() {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder()
            .removeRules(WEB_WITHDRAWALS)
            .build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(false));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void shouldAllowWebWithdrawalsWhenLimitsAreSupported(final boolean supported) {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder().build();
    final ProductDetailsResponseBase.Withdrawals.WithdrawalLimits withdrawalLimits =
        ProductDetailsResponseBase.Withdrawals.WithdrawalLimits.builder()
            .number(ProductDetailsResponseBase.PeriodLimits.<Long>builder().build())
            .build();
    final SupportedPeriodLimits expectedSupportedPeriodLimits =
        SupportedPeriodLimits.builder().anniversaryYear(true).build();

    when(periodLimitsChecker.isSupported(
            same(withdrawalLimits.getNumber()), eq(expectedSupportedPeriodLimits)))
        .thenReturn(supported);

    final boolean permittedOverWeb = testSubject.map(product, productRules, withdrawalLimits, NOW);
    assertThat(permittedOverWeb, is(supported));
  }

  @CsvSource({
    "2019-09-10T00:29:00,false",
    "2019-09-10T00:30:00,true",
    "2019-09-10T00:31:00,true",
    ",true"
  })
  @ParameterizedTest
  void shouldNotAllowWebWithdrawalsWhenEndedDateIsBeforeNow(
      final LocalDateTime endedDate, final boolean expectedPermittedOverWeb) {
    final Product product = activeProduct().endedDate(endedDate).build();

    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder().build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(expectedPermittedOverWeb));
  }

  @CsvSource({
    "2019-09-10T00:29:00,false",
    "2019-09-10T00:30:00,true",
    "2019-09-10T00:31:00,true",
    ",true"
  })
  @ParameterizedTest
  void shouldNotAllowWebWithdrawalsWhenDateObsoleteIsBeforeNow(
      final LocalDateTime dateObsolete, final boolean expectedPermittedOverWeb) {
    final Product product = activeProduct().dateObsolete(dateObsolete).build();

    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder().build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(expectedPermittedOverWeb));
  }

  @ValueSource(ints = {0, 1, 1000})
  @ParameterizedTest
  void shouldAllowWebWithdrawalsWhenProductHasPenaltyDays(final int penaltyDays) {
    final Product product = activeProduct().penaltyDays(penaltyDays).build();

    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder().build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(true));
  }

  @Test
  void shouldNotAllowWithdrawalsWhenWebTransactionsAreNotPermitted() {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder()
            .changeRule(WEB_TRANSACTIONS, "N")
            .build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(false));
  }

  @Test
  void shouldNotAllowWithdrawalsWhenWebTransactionsRuleDoesNotExist() {
    final Product product = activeProduct().build();
    final ActiveProductRules productRules =
        validSaverAccountWithdrawalsActiveProductRulesBuilder()
            .removeRules(WEB_TRANSACTIONS)
            .build();

    final boolean permittedOverWeb = testSubject.map(product, productRules, null, NOW);
    assertThat(permittedOverWeb, is(false));
  }

  @ParameterizedTest
  @MethodSource("validProductRulesForAccountClosure")
  void mapOnAccountClosureShouldReturnTrueWithValidProductRules(
      final ActiveProductRules productRules) {
    assertTrue(testSubject.mapOnAccountClosure(productRules));
  }

  @ParameterizedTest
  @MethodSource("invalidProductRulesForAccountClosure")
  void mapOnAccountClosureShouldReturnFalseWithInvalidProductRules(
      final ActiveProductRules productRules) {
    assertFalse(testSubject.mapOnAccountClosure(productRules));
  }

  private static Stream<Arguments> validProductRulesForAccountClosure() {
    return Stream.of(
        Arguments.of(withdrawalsActiveProductRulesBuilder().build()),
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
                    TestDataFactory.charProductRule(WEB_WITHDRAWALS, "Y"),
                    TestDataFactory.charProductRule(OFFSET_ACCOUNT, "N"))
                .build()),
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
                    TestDataFactory.charProductRule(WEB_WITHDRAWALS, "Y"),
                    TestDataFactory.charProductRule(OFFSET_ACCOUNT, "Y"))
                .build()),
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(TestDataFactory.charProductRule(OFFSET_ACCOUNT, "Y"))
                .build()),
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
                    TestDataFactory.charProductRule(WEB_WITHDRAWALS, "N"),
                    TestDataFactory.charProductRule(OFFSET_ACCOUNT, "Y"))
                .build()),
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
                    TestDataFactory.charProductRule(WEB_WITHDRAWALS, "N"),
                    TestDataFactory.charProductRule(OFFSET_ACCOUNT, "Y"))
                .build()),
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
                    TestDataFactory.charProductRule(WEB_WITHDRAWALS, "Y"),
                    TestDataFactory.charProductRule(OFFSET_ACCOUNT, "Y"))
                .build()));
  }

  private static Stream<Arguments> invalidProductRulesForAccountClosure() {
    return Stream.of(
        // WEBTRN & WEBWDL rules present but both 'N'
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
                    TestDataFactory.charProductRule(WEB_WITHDRAWALS, "N"))
                .build()),
        // WEBWDL rule present but 'N'
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
                    TestDataFactory.charProductRule(WEB_WITHDRAWALS, "N"))
                .build()),
        // WEBTRN rule present but 'N'
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule(WEB_TRANSACTIONS, "N"),
                    TestDataFactory.charProductRule(WEB_WITHDRAWALS, "Y"))
                .build()),
        // OFFSET rule present but 'N'
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(TestDataFactory.charProductRule(OFFSET_ACCOUNT, "N"))
                .build()),
        // WEBWDL not present
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"))
                .build()),
        // WEBTRN not present
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(TestDataFactory.charProductRule(WEB_WITHDRAWALS, "Y"))
                .build()),
        // Other product rules present and 'Y' without OFFSET
        Arguments.of(
            TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
                .rules(
                    TestDataFactory.charProductRule("OTHER_RULE", "Y"),
                    TestDataFactory.charProductRule("OTHER_RULE_2", "Y"))
                .build()),
        // No product rules present
        Arguments.of(new ActiveProductRules(Collections.emptyList())));
  }

  private Product.ProductBuilder activeProduct() {
    return Product.builder().penaltyDays(0);
  }

  private static TestDataFactory.ActiveProductRulesBuilder
      validSaverAccountWithdrawalsActiveProductRulesBuilder() {
    return TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
        .rules(
            TestDataFactory.charProductRule(PRODUCT_TYPE, "SAVER"),
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.charProductRule(WEB_WITHDRAWALS, "Y"));
  }

  private static TestDataFactory.ActiveProductRulesBuilder withdrawalsActiveProductRulesBuilder() {
    return TestDataFactory.ActiveProductRulesBuilder.makeBuilder()
        .rules(
            TestDataFactory.charProductRule(WEB_TRANSACTIONS, "Y"),
            TestDataFactory.charProductRule(WEB_WITHDRAWALS, "Y"));
  }
}
