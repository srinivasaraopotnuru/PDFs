package uk.co.ybs.digital.product.mapping.onsale;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.product.service.WebSiteProduct;

class ProductFilterTest {

  private static final String ACCOUNT_SHORT_NAME = "accountShortName";
  private final ProductFilter testSubject = new ProductFilter();

  @Test
  void includeProductShouldIncludeMatchingProduct() {
    final WebSiteProduct product =
        matchingProductBuilder().productID("1").accountNameShort(ACCOUNT_SHORT_NAME).build();
    final boolean includeProduct = testSubject.includeProduct(product);
    assertThat(includeProduct, is(true));
  }

  @ParameterizedTest
  @CsvSource({"YBS,true", ",false", "'',false", "other,false"})
  void includeProductShouldFilterByBranch(final String brand, final boolean expectFind) {
    final WebSiteProduct product =
        matchingProductBuilder()
            .brand(brand)
            .productID("1")
            .accountNameShort(ACCOUNT_SHORT_NAME)
            .build();
    final boolean includeProduct = testSubject.includeProduct(product);
    assertThat(includeProduct, is(expectFind));
  }

  @ParameterizedTest
  @CsvSource({",true", "'',true", "No,true", "Yes,false"})
  void includeProductShouldFilterByMaturityProduct(
      final String maturityProduct, final boolean expectFind) {
    final WebSiteProduct product =
        matchingProductBuilder()
            .maturityProduct(maturityProduct)
            .accountNameShort(ACCOUNT_SHORT_NAME)
            .build();
    final boolean includeProduct = testSubject.includeProduct(product);
    assertThat(includeProduct, is(expectFind));
  }

  @ParameterizedTest
  @CsvSource({"Yes,true", ",false", "'',false", "No,false"})
  void includeProductShouldFilterByApplyOnline(final String applyOnline, final boolean expectFind) {
    final WebSiteProduct product =
        matchingProductBuilder()
            .applyOnline(applyOnline)
            .accountNameShort(ACCOUNT_SHORT_NAME)
            .build();
    final boolean includeProduct = testSubject.includeProduct(product);
    assertThat(includeProduct, is(expectFind));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> products() {
    return Stream.of(
        Arguments.of("Yes", "", "", "True"),
        Arguments.of("Yes", "", "Yes", "False"),
        Arguments.of("Yes", "Yes", "", "True"),
        Arguments.of("Yes", "Yes", "Yes", "False"),
        Arguments.of("", "Yes", "", "True"),
        Arguments.of("", "Yes", "Yes", "False"),
        Arguments.of("", "", "Yes", "False"));
  }

  @ParameterizedTest
  @MethodSource("products")
  void includeProductShouldFilterByInterestFrequency(
      final String interestAnnually,
      final String interestMonthly,
      final String interestBiAnnually,
      final boolean expectFind) {
    final WebSiteProduct product =
        matchingProductBuilder()
            .interestAnnually(interestAnnually)
            .interestMonthly(interestMonthly)
            .interestBiannually(interestBiAnnually)
            .build();
    final boolean includeProduct = testSubject.includeProduct(product);
    assertThat(includeProduct, is(expectFind));
  }

  @ParameterizedTest
  @CsvSource({",true", "'',true", "No,true", "Yes,false"})
  void isOfflineOnlyProductShouldFilterApplyOnlineProducts(
      final String applyOnline, final boolean expectFind) {
    final WebSiteProduct product =
        matchingProductBuilder()
            .applyOnline(applyOnline)
            .productID("1")
            .accountNameShort(ACCOUNT_SHORT_NAME)
            .build();
    final boolean includeProduct = testSubject.isOfflineOnlyProduct(product);
    assertThat(includeProduct, is(expectFind));
  }

  private WebSiteProduct.WebSiteProductBuilder matchingProductBuilder() {
    return WebSiteProduct.builder().brand("YBS").applyOnline("Yes").interestAnnually("Yes");
  }
}
