package uk.co.ybs.digital.product.mapping;

import java.time.LocalDateTime;
import java.util.Optional;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Applications;

@Component
public class ApplicationsMapper {

  public Applications map(
      final Product product, final ActiveProductRules productRules, final LocalDateTime now) {
    return Applications.builder()
        .applicationsPermitted(isApplicationsPermitted(product, productRules, now))
        .accountNumberSuffix(getAccountNumberSuffix(productRules))
        .fatcaReportable(BooleanUtils.toBoolean(product.getFatcaReportable()))
        .minimumAge(getMinAge(productRules))
        .maximumAge(getMaxAge(productRules))
        .maximumApplicants(getMaxApplicants(productRules))
        .nationalInsuranceNumberRequired(
            productRules.getBooleanWithDefault(AvailableProductRule.NI_NUMBER, false))
        .build();
  }

  private boolean isApplicationsPermitted(
      final Product product, final ActiveProductRules productRules, final LocalDateTime now) {
    return product.isOpenAt(now)
        && productRules.getBooleanWithDefault(AvailableProductRule.WEB_SALE, false)
        && Optional.ofNullable(
                productRules.getStringValue(AvailableProductRule.ALLOWABLE_INTEREST_INSTR))
            .isPresent()
        && Optional.ofNullable(
                productRules.getNonZeroNumberValue(AvailableProductRule.PRODUCT_SUFFIX))
            .isPresent();
  }

  private long getMaxApplicants(final ActiveProductRules productRules) {
    return "ISA".equals(productRules.getStringValue(AvailableProductRule.PRODUCT_TYPE)) ? 1 : 2;
  }

  private long getMaxAge(final ActiveProductRules productRules) {
    return Long.min(
        105,
        Long.parseLong(
            Optional.ofNullable(productRules.getStringValue(AvailableProductRule.MAX_AGE))
                .orElse("105")));
  }

  private long getMinAge(final ActiveProductRules productRules) {
    return Long.max(
        16,
        Long.parseLong(
            Optional.ofNullable(productRules.getStringValue(AvailableProductRule.MIN_AGE))
                .orElse("16")));
  }

  private String getAccountNumberSuffix(final ActiveProductRules productRules) {
    return String.format(
        "%02d", productRules.getNonZeroNumberValue(AvailableProductRule.PRODUCT_SUFFIX));
  }
}
