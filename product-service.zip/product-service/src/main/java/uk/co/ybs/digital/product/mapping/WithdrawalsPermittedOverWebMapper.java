package uk.co.ybs.digital.product.mapping;

import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Withdrawals.WithdrawalLimits;

@Component
@RequiredArgsConstructor
@Slf4j
public class WithdrawalsPermittedOverWebMapper {

  private static final SupportedPeriodLimits SUPPORTED_PERIOD_LIMITS =
      SupportedPeriodLimits.builder().anniversaryYear(true).build();

  private final PeriodLimitsChecker periodLimitsChecker;

  public boolean map(
      final Product product,
      final ActiveProductRules productRules,
      final WithdrawalLimits withdrawalLimits,
      final LocalDateTime now) {
    final boolean supportedProduct = productRules.isSupportedProduct();
    final boolean productActive = product.isActiveAt(now);
    final boolean webTransactionsAllowed =
        productRules.getBooleanWithDefault(AvailableProductRule.WEB_TRANSACTIONS, false);
    final boolean webWithdrawalsAllowed =
        productRules.getBooleanWithDefault(AvailableProductRule.WEB_WITHDRAWALS, false);
    final boolean supportedWithdrawalLimits =
        withdrawalLimits == null || isSupportedWithdrawalLimits(withdrawalLimits);

    final boolean permittedOverWeb =
        supportedProduct
            && productActive
            && webTransactionsAllowed
            && webWithdrawalsAllowed
            && supportedWithdrawalLimits;

    if (!permittedOverWeb) {
      log.info(
          "Product {} does not support withdrawals over the API. "
              + "supportedProduct: {}, "
              + "productActive: {}, "
              + "webTransactionsAllowed: {}, "
              + "webWithdrawalsAllowed: {}, "
              + "supportedWithdrawalLimits: {}, ",
          product.getProductIdentifier(),
          supportedProduct,
          productActive,
          webTransactionsAllowed,
          webWithdrawalsAllowed,
          supportedWithdrawalLimits);
    }

    return permittedOverWeb;
  }

  public boolean mapOnAccountClosure(final ActiveProductRules productRules) {
    return productRules.getBooleanWithDefault(AvailableProductRule.OFFSET_ACCOUNT, false)
        || (productRules.getBooleanWithDefault(AvailableProductRule.WEB_TRANSACTIONS, false)
            && productRules.getBooleanWithDefault(AvailableProductRule.WEB_WITHDRAWALS, false));
  }

  private boolean isSupportedWithdrawalLimits(final WithdrawalLimits withdrawalLimits) {
    final ProductDetailsResponse.PeriodLimits<Long> periodLimits = withdrawalLimits.getNumber();
    return periodLimitsChecker.isSupported(periodLimits, SUPPORTED_PERIOD_LIMITS);
  }
}
