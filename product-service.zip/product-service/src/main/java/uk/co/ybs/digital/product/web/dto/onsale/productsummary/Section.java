package uk.co.ybs.digital.product.web.dto.onsale.productsummary;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Section {

  @ApiModelProperty(example = "1")
  String icon;

  @ApiModelProperty(example = "false")
  boolean displayIcon;

  @ApiModelProperty(example = "true")
  boolean collapsible;
}
