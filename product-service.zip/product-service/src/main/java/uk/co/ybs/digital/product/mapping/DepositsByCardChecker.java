package uk.co.ybs.digital.product.mapping;

import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;

@Component
public class DepositsByCardChecker {

  public boolean isSupported(final ActiveProductRules productRules) {
    final boolean webTransactionsAllowed =
        productRules.getBooleanWithDefault(AvailableProductRule.WEB_TRANSACTIONS, false);

    final boolean noticeRequiredForWithdrawals =
        productRules.getNumberValueWithDefault(AvailableProductRule.NOTICE_DAYS_FOR_WITHDRAWALS, 0L)
            > 0;

    final boolean receiptsStopped =
        productRules.getBooleanWithDefault(AvailableProductRule.STOP_DEPOSITS_EXTERNAL, false);

    return webTransactionsAllowed && !noticeRequiredForWithdrawals && !receiptsStopped;
  }
}
