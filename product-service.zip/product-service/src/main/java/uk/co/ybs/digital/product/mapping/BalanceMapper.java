package uk.co.ybs.digital.product.mapping;

import java.math.BigDecimal;
import java.util.Optional;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Balance;

@Component
public class BalanceMapper {

  public Optional<Balance> map(final ActiveProductRules productRules) {
    final BigDecimal min = productRules.getMoneyValue(AvailableProductRule.BALANCE_MINIMUM);
    final BigDecimal max = productRules.getMoneyValue(AvailableProductRule.BALANCE_MAXIMUM);

    if (ObjectUtils.anyNotNull(min, max)) {
      return Optional.of(Balance.builder().min(min).max(max).build());
    } else {
      return Optional.empty();
    }
  }
}
