package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;
import static uk.co.ybs.digital.product.service.OnSaleProductService.formatAsMoney;

import java.time.Year;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ManageAccount;

@Component
public class ManageAccountBuilder {

  private static final String HELP_TO_BUY_ISA_ACCOUNT = "Help to Buy: ISA";
  private static final String INTERNET_SAVER_ISA_PLUS_SHORT_ACCOUNT = "Internet Saver ISA Plus";
  private static final String LOYALTY_SIX_ACCESS_SAVER_ISA_ACCOUNT = "Loyalty Six Access Saver ISA";
  private static final String SIX_ACCESS_SAVER_ISA_ISSUE_3_ACCOUNT = "Six Access Saver ISA Issue 3";
  private static final String ANNUAL_ACCESS_ACCOUNT_ISA_ACCOUNT = "Annual Access Account ISA";
  private static final String LIMITED_ACCESS_SAVER_ISA_ACCOUNT = "Limited Access Saver ISA";
  private static final String YBS_HOME_LINK = "ybs.co.uk.";
  private static final String YBS_REGISTRATION_LINK =
      "https://www.ybs.co.uk/help/online/registration.html";
  private static final String MAXIMUM_BALANCE = "£20,000";
  private static final String DAYS_ALLOWED = "14";

  @SuppressWarnings("PMD.NPathComplexity")
  public ManageAccount map(final WebSiteProduct webSiteProduct) {
    final boolean taxFree = checkYesValue(webSiteProduct.getTaxFree());
    final boolean maturityProduct = checkYesValue(webSiteProduct.getMaturityProduct());
    final boolean cashISA = checkYesValue(webSiteProduct.getCashISA());
    final boolean manageInBranch = checkYesValue(webSiteProduct.getManageInBranch());
    final boolean atmCard = checkYesValue(webSiteProduct.getATMCard());
    final boolean manageOnline = checkYesValue(webSiteProduct.getManageOnline());
    final boolean viewOnline = checkYesValue(webSiteProduct.getViewOnline());
    final boolean fixedTerm = checkYesValue(webSiteProduct.getFixedTerm());
    final boolean ybsFundsInAllowed = checkYesValue(webSiteProduct.getNoYBSFundsInAllowed());
    final boolean accountSwitching = checkYesValue(webSiteProduct.getAccountSwitching());
    final boolean easyAccess = checkYesValue(webSiteProduct.getEasyAccess());
    final String accountNameShort = webSiteProduct.getAccountNameShort();
    final String accountNameFull = webSiteProduct.getAccountNameFull();
    final Integer monthlyLimit = webSiteProduct.getMonthlyLimit();
    final Integer maxBalance =
        webSiteProduct.getMaxBalance() != null
            ? webSiteProduct.getMaxBalance()
            : Integer.valueOf(0);
    final Year currentYear = Year.now();
    final String nextYear = (currentYear.plusYears(1).toString());
    final String date = currentYear + "/" + nextYear.substring(2);

    final List<Content> contentList = new ArrayList<>();

    final Content item1 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Eligibility").build();
    contentList.add(item1);

    if (LOYALTY_SIX_ACCESS_SAVER_ISA_ACCOUNT.equals(accountNameShort)) {
      contentList.addAll(sixAccessSaverContent(accountNameShort));
    }

    if (taxFree) {
      contentList.addAll(taxFreeContent(webSiteProduct, accountNameShort));
    }
    if (easyAccess) {
      contentList.addAll(easyAccessContent(webSiteProduct, accountNameShort));
    }

    if (HELP_TO_BUY_ISA_ACCOUNT.equals(accountNameShort)) {
      contentList.addAll(helpToBuyIsaContent(accountNameFull));
    }

    if (ANNUAL_ACCESS_ACCOUNT_ISA_ACCOUNT.equals(accountNameShort)) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "You can only hold one account in your name. If you are named on more than one %s the most recent account opened will be transferred to the Easy ISA.",
                      accountNameFull))
              .build();
      contentList.add(item);
    }

    final Content item4 =
        Content.builder()
            .format(FormatType.HEADER.getFormat())
            .text("Account opening and management")
            .build();
    contentList.add(item4);

    if (SIX_ACCESS_SAVER_ISA_ISSUE_3_ACCOUNT.equals(accountNameFull)) {
      final Content item5 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "At maturity, the funds from your Loyalty Six Access Saver ISA will automatically be transferred into this %s",
                      accountNameFull))
              .build();
      final Content item6 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text("The minimum balance is £1.")
              .build();
      contentList.addAll(Arrays.asList(item5, item6));
    }

    contentList.add(
        maturityProductContent(
            maturityProduct, cashISA, accountNameShort, accountNameFull, webSiteProduct));

    contentList.addAll(
        manageAccountContent(
            manageInBranch,
            manageOnline,
            atmCard,
            viewOnline,
            easyAccess,
            maxBalance,
            accountNameShort));

    if (easyAccess && !INTERNET_SAVER_ISA_PLUS_SHORT_ACCOUNT.equals(accountNameShort)) {
      final Content item7 =
          Content.builder().format(FormatType.HEADER.getFormat()).text("Account switching").build();
      final Content item8 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "If you currently have an existing Yorkshire Building Society account it may be possible to transfer to this product, subject to meeting eligibility criteria. Please check with us to see whether this is possible.")
              .build();
      contentList.addAll(Arrays.asList(item7, item8));
    }

    if (cashISA) {
      contentList.addAll(
          cashISAContent(
              webSiteProduct, accountNameFull, monthlyLimit, date, fixedTerm, maturityProduct));
    }

    /* Currently commented out in web but keeping the logic just in case
    contentList.addAll(
    accountSwitchingContent(
    accountSwitching, accountNameShort, taxFree, ybsFundsInAllowed, monthlyLimit));
    */

    if (taxFree) {
      contentList.addAll(taxFreeContentMore(accountNameShort));
    }

    return ManageAccount.builder()
        .section(buildSection("4", true, true))
        .title("How do I open and manage my account?")
        .content(contentList)
        .build();
  }

  private List<Content> helpToBuyIsaContent(final String accountNameFull) {

    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "To qualify for a Help to Buy: ISA you must be an “Eligible Customer” as defined in the Scheme Rules but in brief:")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.LIST.getFormat())
            .list(
                Arrays.asList(
                    "have a valid National Insurance number",
                    "be a first time buyer, and never owned a residential property anywhere in the world",
                    "For full details of the scheme rules please visit http://www.helptobuy.gov.uk/isa",
                    String.format(
                        "Each %s account holder can only have one %s. If we identify that a second account is held with us this account will be closed and the latest issue Instant ISA will be opened with these funds on your behalf.",
                        accountNameFull, accountNameFull)))
            .build();

    return new ArrayList<>(Arrays.asList(item1, item2));
  }

  private List<Content> taxFreeContentMore(final String accountNameShort) {
    final List<Content> contentList = new ArrayList<>();

    if (HELP_TO_BUY_ISA_ACCOUNT.equals(accountNameShort)) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "Transfer charges may apply, please check with your existing provider. Do not transfer any ISA balance yourself otherwise you’ll lose your tax benefit.")
              .build();
      contentList.add(item);
    } else {
      final Content item1 =
          Content.builder()
              .format(FormatType.HEADER.getFormat())
              .text("Transferring your ISA")
              .build();

      final Content item2 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "You can transfer some or all of your money saved in previous tax years into a Cash ISA and/or Stocks & Shares ISA and/or Innovative Finance ISA and/or Lifetime ISA without affecting your annual allowance, subject to the product terms of your account.")
              .build();

      final Content item3 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "You can also transfer money saved in a Cash ISA for the current tax year into a different ISA with the same or a different provider, although you can only hold one of each type of ISA for each tax year. You must transfer the whole amount saved in the current tax year. Transfer charges may apply, please check with your existing provider. Do not transfer any ISA balance yourself otherwise you’ll lose your tax benefits.")
              .build();

      contentList.addAll(Arrays.asList(item1, item2, item3));
    }
    return contentList;
  }

  private List<Content> cashISAContent(
      final WebSiteProduct webSiteProduct,
      final String accountNameFull,
      final Integer monthlyLimit,
      final String date,
      final boolean fixedTerm,
      final boolean maturityProduct) {
    final List<Content> contentList = new ArrayList<>();

    if (HELP_TO_BUY_ISA_ACCOUNT.equals(accountNameFull)) {

      final Content item1 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "£%s is required to maintain the account after it has been opened",
                      webSiteProduct.getMinBalanceT1()))
              .build();

      final Content item2 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "There is no maximum balance for this account but the maximum amount eligible for a bonus is £%s",
                      webSiteProduct.getMaxAmountEligibleForBonus()))
              .build();

      final Content item3 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "A maximum of £%s can be saved in each calendar month apart from the first calendar month of account opening when a further £%s may be added.",
                      monthlyLimit, webSiteProduct.getFirstMonthLimit()))
              .build();

      final Content item4 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "If more than the maximum monthly contribution of £%s is received the funds will be removed and we will return the overpayment by cheque.",
                      monthlyLimit))
              .build();

      final Content item5 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "The calendar month commences when the first deposit is received to the account and runs from the first to last day of each month. You do not need to save every month or save the same amount every month. If you set up a standing order to pay a monthly contribution, we recommend you set the date prior to the 24th each month to ensure that we receive the funds in time.")
              .build();

      contentList.addAll(Arrays.asList(item1, item2, item3, item4, item5));
    } else {
      final Content item6 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "The maximum balance is %s for %s ISA allowance plus previous years’ ISA transfers. Please check with your existing provider if any charges are applicable on transfer.",
                      MAXIMUM_BALANCE, date))
              .build();
      contentList.add(item6);
    }

    if (fixedTerm) {
      if (maturityProduct) {
        final Content item7 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "Deposits for the %s tax year’s unused ISA allowance, and internal transfers from other Yorkshire Building Society accounts, are permitted until the Fixed Rate Cash e-ISA is withdrawn from sale. ISA transfers in requests (either with us or from other providers) are permitted up to %s. Please check with your existing ISA provider for any charges applicable on transfer. Any deposits received after these timescales will be returned to you.",
                        date, webSiteProduct.getLastDateForDeposits()))
                .build();
        contentList.add(item7);
      }
      if (!HELP_TO_BUY_ISA_ACCOUNT.equals(accountNameFull)) {
        final Content item8 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    "Deposits are permitted until the Fixed Rate ISA is withdrawn from sale. Please note that you are only permitted to subscribe to one Cash ISA each tax year. This means that if you do not fully utilise the current year subscription amount in this Cash ISA you will not be able to open another Cash ISA during the same tax year. You are still able to subscribe any unused allowance to a Stocks and Share ISA and or Innovative Finance ISA.")
                .build();

        final Content item9 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "ISA Transfer In requests (either with us or other providers) are permitted up to %s days after the Fixed Rate ISA has been withdrawn from sale. For the transfer in request to be accepted, funds must be immediately available. No additional transfers will be accepted.",
                        DAYS_ALLOWED))
                .build();

        final Content item10 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    "Please check with your existing ISA provider for any charges applicable on transfer.")
                .build();
        contentList.addAll(Arrays.asList(item8, item9, item10));
      }

    } else if (!HELP_TO_BUY_ISA_ACCOUNT.equals(accountNameFull)) {
      final Content item11 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "Deposits for the current tax year’s ISA allowance can be made at any time. External transfers for any used ISA allowances, including both previous years’ and current years’ subscriptions are permitted.")
              .build();
      contentList.add(item11);
    }
    return contentList;
  }

  private List<Content> taxFreeContent(
      final WebSiteProduct webSiteProduct, final String accountNameShort) {

    final List<Content> contentList = new ArrayList<>();

    if (LIMITED_ACCESS_SAVER_ISA_ACCOUNT.equals(accountNameShort)) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "The balance held in your 1 Year %s account will be transferred to the %s at maturity. You may only subscribe to one Cash ISA in a single tax year.",
                      accountNameShort, accountNameShort))
              .build();
      contentList.add(item);
    } else {

      final String text;
      if (ANNUAL_ACCESS_ACCOUNT_ISA_ACCOUNT.equals(accountNameShort)) {
        text = "You may only subscribe to one Cash ISA in a single tax year.";
      } else {
        text =
            "The account can only be held in your name. You may only subscribe to one Cash ISA in a single tax year.";
      }
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "You have to be at least %s years old. You must be a UK resident for tax purposes, or be a qualifying Crown employee or married to, or in a civil partnership with a qualified Crown employee. %s",
                      webSiteProduct.getMinAgeCustomer(), text))
              .build();
      contentList.add(item);
    }
    return contentList;
  }

  private List<Content> easyAccessContent(
      final WebSiteProduct webSiteProduct, final String accountNameShort) {

    final List<Content> contentList = new ArrayList<>();
    final String text;

    if (INTERNET_SAVER_ISA_PLUS_SHORT_ACCOUNT.equals(accountNameShort)) {
      text =
          "The account can only be held in your name. You may only subscribe to one Cash ISA in a single tax year.";
    } else if ("Online Rainy Day Account".equals(accountNameShort)) {
      text =
          "The account can be held on your own or jointly with someone else. Only 1 account can be opened per person.";
    } else {
      text = "The account can be held on your own or jointly with someone else.";
    }
    if (!(INTERNET_SAVER_ISA_PLUS_SHORT_ACCOUNT.equals(accountNameShort))) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "You have to be at least %s years old. You must be a UK resident for tax purposes, or be a qualifying Crown employee or married to, or in a civil partnership with a qualified Crown employee. %s",
                      webSiteProduct.getMinAgeCustomer(), text))
              .build();
      contentList.add(item);
    }
    return contentList;
  }

  private List<Content> sixAccessSaverContent(final String accountNameShort) {
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                String.format(
                    "You have to be at least 16 years old. You must be a UK resident for tax purposes, or be a qualifying Crown employee or married to, or in a civil partnership with a qualified Crown employee. The account can only be held in your name and you can only hold one account. You may only subscribe to one Cash ISA in a single tax year. If you are named on more than one %s the most recent account opened will be transferred to the Six Access Saver ISA Issue 3.",
                    accountNameShort))
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                String.format(
                    "You must have had a continuous membership with Yorkshire Building Society starting on or before the 1st January 2020 with an open account (Savings or Mortgage) with Yorkshire Building Society or Chelsea Building Society or YBS SharePlans, as either Main Holder, Other Holder or Trustee to be eligible for the %s account. Attorneys on an existing accounts will not be eligible.",
                    accountNameShort))
            .build();
    return Arrays.asList(item1, item2);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private List<Content> manageAccountContent(
      final boolean manageInBranch,
      final boolean manageOnline,
      final boolean atmCard,
      final boolean viewOnline,
      final boolean easyAccess,
      final int maxBalance,
      final String accountNameShort) {
    final List<Content> contentList = new ArrayList<>();

    if (manageInBranch && manageOnline) {

      String text = "";
      if (atmCard) {
        text = " or at an ATM";
      }
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "The account can be managed in branch, at an agency or by post%s. You can also <link>register<link> to manage your account online.",
                      text))
              .link(YBS_REGISTRATION_LINK)
              .build();
      contentList.add(item);
    }

    if (manageInBranch && !manageOnline) {
      String text = null;
      if (viewOnline) {
        text = "You can also view this account online.";
      }
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "The account can be managed in branch, at an agency or by post. %s", text))
              .build();
      contentList.add(item);
    }

    if (!manageInBranch && manageOnline) {
      Content item;
      if (LIMITED_ACCESS_SAVER_ISA_ACCOUNT.equals(accountNameShort)) {
        item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    "You will be able to check your balance, interest rate, make and view transactions on your account online whenever you wish.")
                .build();
      } else {
        item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    "The account can be managed online. You will be able to check your balance, interest rate, make and view transactions on your account online whenever you wish.")
                .build();
      }
      contentList.add(item);
      if (easyAccess && !INTERNET_SAVER_ISA_PLUS_SHORT_ACCOUNT.equals(accountNameShort)) {
        item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(String.format("The maximum balance is £%s.", formatAsMoney(maxBalance)))
                .build();
        contentList.add(item);
      }
    }
    return contentList;
  }

  private Content maturityProductContent(
      final boolean maturityProduct,
      final boolean cashISA,
      final String accountNameShort,
      final String accountNameFull,
      final WebSiteProduct webSiteProduct) {
    if (maturityProduct) {
      if (cashISA) {
        if ("Easy Saver eISA Plus".equals(accountNameShort)) {
          return Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "At maturity, the funds from your Online Single Access Saver ISA will automatically be transferred into this %s",
                      accountNameFull))
              .build();
        } else if (LIMITED_ACCESS_SAVER_ISA_ACCOUNT.equals(accountNameShort)) {
          return Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "The minimum balance is £%s", webSiteProduct.getMinOpeningBalance()))
              .build();
        } else {
          return Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "Accounts can be opened with a minimum of £%s by logging into your online account.",
                      webSiteProduct.getMinOpeningBalance()))
              .build();
        }
      }
    } else {
      return Content.builder()
          .format(FormatType.TEXT.getFormat())
          .text(
              String.format(
                  "Accounts can be opened with a minimum of £%s online at %s",
                  webSiteProduct.getMinOpeningBalance(), YBS_HOME_LINK))
          .build();
    }
    return null;
  }
}
