package uk.co.ybs.digital.product.exception;

public class ProductIngestException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public ProductIngestException(final String message) {
    super(message);
  }

  public ProductIngestException(final String message, final Throwable ex) {
    super(message, ex);
  }
}
