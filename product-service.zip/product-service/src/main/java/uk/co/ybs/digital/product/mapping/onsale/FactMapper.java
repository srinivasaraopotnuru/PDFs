package uk.co.ybs.digital.product.mapping.onsale;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;
import static uk.co.ybs.digital.product.service.OnSaleProductService.formatAsLongDate;
import static uk.co.ybs.digital.product.service.OnSaleProductService.formatAsMoney;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.Fact;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;

@Component
@AllArgsConstructor
public class FactMapper {

  private static final String ONLINE_RAINY_DAY_ACCOUNT_ACCOUNT_SHORT_NAME =
      "Online Rainy Day Account";
  private static final String SIX_ACCESS_E_SAVER_ACCOUNT_SHORT_NAME = "Six Access e-Saver";
  private static final String SIX_ACCESS_E_SAVER_ISA_ACCOUNT_SHORT_NAME = "Six Access e-Saver ISA";
  private static final String INTERNET_SAVER_PLUS_ACCOUNT_SHORT_NAME = "Internet Saver Plus";
  private static final String INTERNET_SAVER_ISA_PLUS_ACCOUNT_SHORT_NAME =
      "Internet Saver ISA Plus";
  private static final String ANNUAL_ACCESS_ACCOUNT_ACCOUNT_SHORT_NAME = "Annual Access Account";
  private static final String ANNUAL_ACCESS_ACCOUNT_ISA_ACCOUNT_SHORT_NAME =
      "Annual Access Account ISA";
  private static final String THIRTY_DAY_NOTICE_ACCOUNT_SHORT_NAME = "30 Day Notice";
  private static final String NINETY_DAY_NOTICE_ACCOUNT_SHORT_NAME = "90 Day Notice";
  private static final String LIMITED_ACCESS_SAVER_ACCOUNT_SHORT_NAME = "Limited Access Saver";
  private static final String LIMITED_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME =
      "Limited Access Saver ISA";
  private static final String MAKE_ME_A_SAVER_ACCOUNT_SHORT_NAME = "Make Me A Saver";
  private static final String FREEDOM_ACCOUNT_ACCOUNT_SHORT_NAME = "Freedom Account";
  private static final String LOYALTY_BOND_ACCOUNT_NAME_SHORT =
      "Loyalty Fixed Rate Bond (No Access) until 31/01/2024";

  private static final String LOYALTY_EBOND_ACCOUNT_NAME_SHORT =
      "Loyalty Fixed Rate eBond (No Access) until 31/01/2024";

  private static final String LOYALTY_REGULAR_SAVER_NAME_SHORT = "Loyalty Regular eSaver";

  private static final String FAMILY_SAVINGS_ACCOUNT_NAME_SHORT = "Family eSavings Account";

  private static final String ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT = "Online Rainy Day Account";

  private static final String LOYALTY_SIX_ACCESS_ESAVER_NAME_SHORT = "Loyalty Six Access eSaver";

  private static final String ENERGY_SAVING_AWARENESS_EBOND_NAME_SHORT =
      "Energy Saving Awareness Fixed Rate eBond until 31/01/2024";

  private static final String CHRISTMAS_REGULAR_ESAVER_NAME_SHORT =
      "Christmas 2023 Regular e-Saver";

  public List<Fact> map(final WebSiteProduct webSiteProduct, final List<InterestTier> interestTiers)
      throws ParseException {
    final List<Fact> facts = new ArrayList<>();
    final String accountNameShort = webSiteProduct.getAccountNameShort();

    final boolean cashIsa = checkYesValue(webSiteProduct.getCashISA());
    final boolean bond = checkYesValue(webSiteProduct.getBond());
    final boolean maturityProductOffer = checkYesValue(webSiteProduct.getMaturityProductOffer());
    final boolean tiered = checkYesValue(webSiteProduct.getTieredProduct());
    final boolean smartTiered = checkYesValue(webSiteProduct.getSmartTiered());
    final boolean withdrawalsPermitted = checkYesValue(webSiteProduct.getWithdrawalsPermitted());
    final boolean taxFree = checkYesValue(webSiteProduct.getTaxFree());
    final boolean fixedTerm = checkYesValue(webSiteProduct.getFixedTerm());
    final boolean monthlyInterest = checkYesValue(webSiteProduct.getInterestMonthly());
    final boolean annualInterest = checkYesValue(webSiteProduct.getInterestAnnually());
    final boolean biannualInterest = checkYesValue(webSiteProduct.getInterestBiannually());
    final boolean noYbsFundsInAllowed = checkYesValue(webSiteProduct.getNoYBSFundsInAllowed());
    final boolean loyalty = checkYesValue(webSiteProduct.getLoyalty());
    final Integer monthlyLimit = webSiteProduct.getMonthlyLimit();
    final Integer maxBalance = webSiteProduct.getMaxBalance();
    final String endDate = webSiteProduct.getEndDate();

    // Check if product is a Loyalty fixed rate (e)bond
    final Optional<Fact> eligibility = checkLoyaltyRateBondEligibility(accountNameShort);
    eligibility.ifPresent(facts::add);

    // Check to see if there is a minimum opening balance
    if (!Arrays.asList(
            ENERGY_SAVING_AWARENESS_EBOND_NAME_SHORT, CHRISTMAS_REGULAR_ESAVER_NAME_SHORT)
        .contains(accountNameShort)) {
      final Optional<Fact> saveFromFact =
          checkSaveFrom(webSiteProduct.getMinOpeningBalance(), cashIsa, loyalty, accountNameShort);
      saveFromFact.ifPresent(facts::add);
    }

    // Add Openfrom fact in case of certain loyalty products
    if (Arrays.asList(
            LOYALTY_REGULAR_SAVER_NAME_SHORT,
            LOYALTY_SIX_ACCESS_ESAVER_NAME_SHORT,
            ENERGY_SAVING_AWARENESS_EBOND_NAME_SHORT,
            CHRISTMAS_REGULAR_ESAVER_NAME_SHORT)
        .contains(accountNameShort)) {
      final Optional<Fact> openFromFact =
          checkOpenFrom(
              webSiteProduct.getMinOpeningBalance(), monthlyLimit, maxBalance, accountNameShort);
      openFromFact.ifPresent(facts::add);
    }
    // Checks if it is a tiered product
    final Optional<Fact> tierFact =
        checkTieredInterest(
            tiered, smartTiered, interestTiers, loyalty, accountNameShort, annualInterest);
    tierFact.ifPresent(facts::add);

    // Interest Frequency is always displayed except when it is a loyalty product (covered in tier
    // fact)
    final Optional<Fact> interestFrequency =
        addInterestFrequency(
            monthlyInterest,
            annualInterest,
            biannualInterest,
            accountNameShort,
            cashIsa,
            loyalty,
            smartTiered,
            endDate);
    interestFrequency.ifPresent(facts::add);

    final Optional<Fact> onlinePaysAnnualInterest =
        addOnlinePaysAnnualInterest(monthlyInterest, annualInterest);
    onlinePaysAnnualInterest.ifPresent(facts::add);

    // A withdrawal condition is always displayed
    final Fact withdrawalFact =
        addWithdrawalCondition(
            withdrawalsPermitted,
            webSiteProduct.getWithdrawalDays(),
            bond,
            maturityProductOffer,
            webSiteProduct.getLossOfInterest(),
            accountNameShort,
            webSiteProduct.getAccountNameFull(),
            loyalty,
            smartTiered);
    facts.add(withdrawalFact);

    // Check if closure is permitted
    final Optional<Fact> closureFact =
        checkClosurePermitted(taxFree, fixedTerm, webSiteProduct.getLossOfInterest());
    closureFact.ifPresent(facts::add);

    // Check if YBS funds are not allowed to be transferred in
    final Optional<Fact> ybsFundsInFact =
        checkNoYbsFundsAllowedIn(noYbsFundsInAllowed, accountNameShort);
    ybsFundsInFact.ifPresent(facts::add);

    // Check if product is an Annual Access Account
    final Optional<Fact> annualFact = checkAnnualAccessAccount(accountNameShort);
    annualFact.ifPresent(facts::add);

    // Check if product is a Oneday Access Account
    final Optional<Fact> oneDayFact =
        checkOneDayAccount(accountNameShort, webSiteProduct.getMaxAgeCustomer());
    oneDayFact.ifPresent(facts::add);

    // Check if product is a Freedom Access Account
    final Optional<Fact> freedomFact = checkFreedomAccount(accountNameShort);
    freedomFact.ifPresent(facts::add);

    // Check if product permits an ISA transfer from another provider
    final Optional<Fact> isaTransferFact = checkIsaTransferPermitted(taxFree, fixedTerm);
    isaTransferFact.ifPresent(facts::add);

    // Check if product has a monthly limit until a date
    final Optional<Fact> monthlyLimitUntilDateFact =
        checkMakeMeASaver(accountNameShort, monthlyLimit, endDate);
    monthlyLimitUntilDateFact.ifPresent(facts::add);

    // Check if product is Family Savings Account
    final Optional<Fact> maxAccountsPerCustomer =
        checkMaxAccountsPerCustomer(
            accountNameShort, smartTiered, webSiteProduct.getMaxAccountsPerPerson());
    maxAccountsPerCustomer.ifPresent(facts::add);

    // Check if product is Energy Saving Awareness Bond
    final Optional<Fact> energySavingAwarenessFact =
        checkEnergySavingAwarenessBond(accountNameShort);
    energySavingAwarenessFact.ifPresent(facts::add);
    return facts;
  }

  private Optional<Fact> checkSaveFrom(
      final Integer openingBalance,
      final boolean cashIsa,
      final boolean loyalty,
      final String accountNameShort) {
    final int openBal = Optional.ofNullable(openingBalance).orElse(0);

    if (openBal > 0) {
      final StringBuilder text = new StringBuilder(128);

      text.append("Save from £").append(formatAsMoney(openBal));

      if (loyalty
          && (Arrays.asList(LOYALTY_REGULAR_SAVER_NAME_SHORT, LOYALTY_SIX_ACCESS_ESAVER_NAME_SHORT)
              .contains(accountNameShort))) {
        text.setLength(0);
        text.append("Loyalty eligibility criteria applies & only one account per person");
      } else if (loyalty
          && (!LOYALTY_BOND_ACCOUNT_NAME_SHORT.equals(accountNameShort)
              && !LOYALTY_EBOND_ACCOUNT_NAME_SHORT.equals(accountNameShort))) {
        text.insert(0, "Membership eligibility criteria applies for this 1 year Cash ISA and ");
      } else if (cashIsa) {
        text.append(" in this Cash ISA");
      } else if (FAMILY_SAVINGS_ACCOUNT_NAME_SHORT.equals(accountNameShort)) {
        text.append(" in this three year product");
      }
      return Optional.of(Fact.builder().text(text.toString()).build());
    }

    return Optional.empty();
  }

  private Optional<Fact> checkOpenFrom(
      final Integer openingBalance,
      final Integer monthlyLimit,
      final Integer maxBalance,
      final String accountNameShort) {

    final StringBuilder text = new StringBuilder(64);

    if (CHRISTMAS_REGULAR_ESAVER_NAME_SHORT.equals(accountNameShort)) {
      text.append("Open with and save from £")
          .append(formatAsMoney(openingBalance))
          .append(" to £")
          .append(monthlyLimit)
          .append(" a month");
    } else {
      text.append("Open from £").append(formatAsMoney(openingBalance));
      if (ENERGY_SAVING_AWARENESS_EBOND_NAME_SHORT.equals(accountNameShort)) {
        text.append(" and save up to £").append(maxBalance / 1_000_000).append(" million");
      } else if (monthlyLimit != null) {
        text.append(" and save up to £").append(monthlyLimit).append(" a month for a year");
      } else if (maxBalance != null) {
        text.append(" and save up to £").append(formatAsMoney(maxBalance)).append(" for a year");
      }
    }

    return Optional.of(Fact.builder().text(text.toString()).build());
  }

  private Optional<Fact> checkTieredInterest(
      final boolean tiered,
      final boolean smartTiered,
      final List<InterestTier> interestTiers,
      final boolean loyalty,
      final String accountNameShort,
      final boolean annualInterest) {
    if (tiered || smartTiered) {
      final String dayWord = StringUtils.capitalize(getWordForNumber(interestTiers.size()));

      if (loyalty) {
        return Optional.of(
            Fact.builder()
                .text(String.format("%s tiered interest rates and interest paid annually", dayWord))
                .build());
      } else if (Arrays.asList(
              FAMILY_SAVINGS_ACCOUNT_NAME_SHORT, ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT)
          .contains(accountNameShort)) {
        return Optional.of(
            Fact.builder()
                .text(
                    String.format(
                        "%d tiered variable interest rate and interest paid %s",
                        interestTiers.size(), annualInterest ? "annually" : "monthly"))
                .build());
      } else if (interestTiers.stream().map(InterestTier::getRate).distinct().count() > 1) {
        return Optional.of(
            Fact.builder()
                .text(
                    String.format(
                        "%s tiered interest rates - rate depends on account balance", dayWord))
                .build());
      }
    }

    return Optional.empty();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private Optional<Fact> addInterestFrequency(
      final boolean monthly,
      final boolean annual,
      final boolean biannual,
      final String accountNameShort,
      final boolean cashISA,
      final boolean loyalty,
      final boolean smartTiered,
      final String endDate)
      throws ParseException {

    final StringBuilder text = new StringBuilder();

    if (CHRISTMAS_REGULAR_ESAVER_NAME_SHORT.equals(accountNameShort)) {
      text.append("Interest paid on maturity which is ").append(formatAsLongDate(endDate));
    } else if (Arrays.asList(LOYALTY_BOND_ACCOUNT_NAME_SHORT, LOYALTY_EBOND_ACCOUNT_NAME_SHORT)
        .contains(accountNameShort)) {
      text.append("Interest paid on ").append(formatAsLongDate(endDate));
    } else if (smartTiered
        && Arrays.asList(FAMILY_SAVINGS_ACCOUNT_NAME_SHORT, ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT)
            .contains(accountNameShort)) {
      return Optional.empty();
    } else if (loyalty
        && Arrays.asList(LOYALTY_REGULAR_SAVER_NAME_SHORT, LOYALTY_SIX_ACCESS_ESAVER_NAME_SHORT)
            .contains(accountNameShort)) {
      text.append("Annual interest");
    } else if (!loyalty) {
      if (cashISA) {
        text.append("Cash ISA pays ");
      }
      if (annual && monthly) {
        text.append("Monthly or annual interest - rate varies for monthly interest");
      } else if (monthly) {
        text.append("Monthly interest");
      } else if (biannual) {
        text.append("Biannual interest");
      } else if (annual && (ONLINE_RAINY_DAY_ACCOUNT_ACCOUNT_SHORT_NAME.equals(accountNameShort))) {
        text.append("Interest will be paid annually");
      } else {
        text.append("Annual interest");
      }
    } else {
      return Optional.empty();
    }

    return Optional.of(Fact.builder().text(text.toString()).build());
  }

  private Optional<Fact> addOnlinePaysAnnualInterest(final boolean monthly, final boolean annual) {

    if (annual && monthly) {
      return Optional.of(Fact.builder().text("Online pays annual interest").build());
    }

    return Optional.empty();
  }

  @SuppressWarnings({"PMD.ExcessiveParameterList", "PMD.NPathComplexity"})
  private Fact addWithdrawalCondition(
      final boolean withdrawalsPermitted,
      final Integer withdrawalDays,
      final boolean bond,
      final boolean maturityProductOffer,
      final Integer lossOfInterest,
      final String accountNameShort,
      final String accountNameFull,
      final boolean loyalty,
      final boolean smartTiered) {
    final StringBuilder text = new StringBuilder(256);

    if (withdrawalsPermitted) {
      final int days = Optional.ofNullable(withdrawalDays).orElse(0);

      if (LOYALTY_REGULAR_SAVER_NAME_SHORT.equals(accountNameShort)) {
        text.append("One withdrawal day per year, plus closure.");
      } else if (smartTiered
          && Arrays.asList(FAMILY_SAVINGS_ACCOUNT_NAME_SHORT, ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT)
              .contains(accountNameShort)) {
        final String dayWord = StringUtils.capitalize(getWordForNumber(days));
        final String dayText = days == 1 ? "day" : "days";
        text.append(
            String.format("%s withdrawal %s per year and closure permitted", dayWord, dayText));
      } else if (LOYALTY_SIX_ACCESS_ESAVER_NAME_SHORT.equals(accountNameShort)) {
        final String dayWord = StringUtils.capitalize(getWordForNumber(days));
        final String dayText = days == 1 ? " day" : " days";
        text.append(dayWord)
            .append(" withdrawal")
            .append(dayText)
            .append(" per year, plus closure");
      } else if (loyalty) {
        text.append(
            "Withdrawals on 6 days/year & closure at any time - Use the ISA transfer process to keep tax-free status");
      } else if (CHRISTMAS_REGULAR_ESAVER_NAME_SHORT.equalsIgnoreCase(accountNameShort)) {
        final String dayWord = getWordForNumber(days);
        final String dayText = days == 1 ? " day" : " days";
        text.append("Limited access with ")
            .append(dayWord)
            .append(" withdrawal")
            .append(dayText)
            .append(" for the term of this product, plus closure if required");
      } else if (days > 0) {
        final String dayWord = getWordForNumber(days);
        final String dayText = days == 1 ? " day" : " days";
        text.append("Allows withdrawals on ").append(dayWord).append(dayText).append(" per year");

        if (ONLINE_RAINY_DAY_ACCOUNT_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
          text.append(
              " based on the anniversary of the account opening date, plus closure at any time if required");
        }

        if (SIX_ACCESS_E_SAVER_ACCOUNT_SHORT_NAME.equals(accountNameShort)
            || SIX_ACCESS_E_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameFull)) {
          text.append(" plus closure");
        }
      } else if (bond) {
        if (maturityProductOffer) {
          text.append(
              String.format(
                  "Withdrawals and closure are permitted during the term, subject to %s days loss of interest on the amount withdrawn.",
                  lossOfInterest));
        } else if (THIRTY_DAY_NOTICE_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
          text.append("Withdrawals Require 30 Days Notice");
        } else if (NINETY_DAY_NOTICE_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
          text.append("Withdrawals Require 90 Days Notice");
        } else if (LIMITED_ACCESS_SAVER_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
          text.append(
              "Unlimited withdrawals on one day per account year based on the anniversary of the account opening date. The account can be closed at any time.");
        } else if (LIMITED_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
          text.append(
              "Unlimited withdrawals, on any one day per account year based on the anniversary of the account opening date, subject to daily withdrawal limits.");
        } else {
          text.append("Unlimited withdrawals");
        }
      }
    } else {
      if (LOYALTY_BOND_ACCOUNT_NAME_SHORT.equals(accountNameShort)
          || LOYALTY_EBOND_ACCOUNT_NAME_SHORT.equals(accountNameShort)
          || ENERGY_SAVING_AWARENESS_EBOND_NAME_SHORT.equals(accountNameShort)) {
        text.append("Withdrawals and closure not permitted");
      } else {
        text.append("Withdrawals not permitted");
      }
    }

    if (INTERNET_SAVER_PLUS_ACCOUNT_SHORT_NAME.equals(accountNameShort)
        || INTERNET_SAVER_ISA_PLUS_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
      text.append("Unlimited withdrawals");
    }

    if (MAKE_ME_A_SAVER_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
      text.append(
          "Unlimited instant withdrawals, subject to daily withdrawal limits, without loss of interest, plus closure.");
    }

    return Fact.builder().text(text.toString()).build();
  }

  private Optional<Fact> checkClosurePermitted(
      final boolean taxFree, final boolean fixedTerm, final Integer lossOfInterest) {
    if (taxFree && fixedTerm && lossOfInterest != null) {
      return Optional.of(
          Fact.builder()
              .text(
                  String.format("Closure permitted with %s days' loss of interest", lossOfInterest))
              .build());
    }

    return Optional.empty();
  }

  private Optional<Fact> checkIsaTransferPermitted(final boolean taxFree, final boolean fixedTerm) {
    if (taxFree && fixedTerm) {
      return Optional.of(
          Fact.builder().text("You can transfer your ISA from another provider").build());
    }
    return Optional.empty();
  }

  private Optional<Fact> checkNoYbsFundsAllowedIn(
      final boolean noYbsFundsAllowed, final String accountNameShort) {
    if (noYbsFundsAllowed) {
      if (ANNUAL_ACCESS_ACCOUNT_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
        return Optional.of(
            Fact.builder()
                .text(
                    "You can't move money from existing Yorkshire Building Society Group accounts to open or add to this product")
                .build());
      } else {
        return Optional.of(
            Fact.builder()
                .text("You can't fund the account from an existing YBS Group account")
                .build());
      }
    }

    return Optional.empty();
  }

  private Optional<Fact> checkAnnualAccessAccount(final String accountNameShort) {
    if (ANNUAL_ACCESS_ACCOUNT_ACCOUNT_SHORT_NAME.equals(accountNameShort)
        || ANNUAL_ACCESS_ACCOUNT_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
      return Optional.of(Fact.builder().text("1 year term").build());
    }

    return Optional.empty();
  }

  private Optional<Fact> checkOneDayAccount(
      final String accountNameShort, final Integer maxAgeCustomer) {
    if (accountNameShort.equals("One Day Account") && maxAgeCustomer != null) {
      return Optional.of(
          Fact.builder()
              .text(
                  String.format("Available to account holders under %s years old", maxAgeCustomer))
              .build());
    }

    return Optional.empty();
  }

  private Optional<Fact> checkLoyaltyRateBondEligibility(final String accountNameShort) {
    if (LOYALTY_BOND_ACCOUNT_NAME_SHORT.equals(accountNameShort)
        || LOYALTY_EBOND_ACCOUNT_NAME_SHORT.equals(accountNameShort)) {
      return Optional.of(Fact.builder().text("Loyalty eligibility criteria applies").build());
    }

    return Optional.empty();
  }

  private Optional<Fact> checkFreedomAccount(final String accountNameShort) {
    if (FREEDOM_ACCOUNT_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
      return Optional.of(Fact.builder().text("Open to 12 to 20 year olds").build());
    }

    return Optional.empty();
  }

  private Optional<Fact> checkMakeMeASaver(
      final String accountNameShort, final Integer monthlyLimit, final String endDate)
      throws ParseException {
    if (Arrays.asList(MAKE_ME_A_SAVER_ACCOUNT_SHORT_NAME).contains(accountNameShort)) {

      return Optional.of(
          Fact.builder()
              .text(
                  String.format(
                      "Save up to £%s per month until %s",
                      formatAsMoney(monthlyLimit), formatAsLongDate(endDate)))
              .build());
    }
    return Optional.empty();
  }

  private Optional<Fact> checkEnergySavingAwarenessBond(final String accountNameShort) {
    if (ENERGY_SAVING_AWARENESS_EBOND_NAME_SHORT.equals(accountNameShort)) {

      return Optional.of(
          Fact.builder()
              .text(
                  "Receive free independent information in partnership with the Energy Saving Trust")
              .build());
    }
    return Optional.empty();
  }

  private Optional<Fact> checkMaxAccountsPerCustomer(
      final String accountNameShort,
      final boolean smartTiered,
      final Integer maxAccountsPerPerson) {

    if (maxAccountsPerPerson != null) {
      final String numberWord = StringUtils.capitalize(getWordForNumber(maxAccountsPerPerson));
      final String plural = maxAccountsPerPerson > 1 ? "s" : Strings.EMPTY;

      if (smartTiered
          && Arrays.asList(FAMILY_SAVINGS_ACCOUNT_NAME_SHORT, ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT)
              .contains(accountNameShort)) {

        return Optional.of(
            Fact.builder()
                .text(String.format("%s account%s per customer", numberWord, plural))
                .build());

      } else if (CHRISTMAS_REGULAR_ESAVER_NAME_SHORT.equals(accountNameShort)) {

        return Optional.of(
            Fact.builder()
                .text(
                    String.format(
                        "Only %s account%s per customer",
                        numberWord.toLowerCase(Locale.ROOT), plural))
                .build());
      }
    }

    return Optional.empty();
  }

  private static String getWordForNumber(final int numToConvert) {
    switch (numToConvert) {
      case 1:
        return "one";
      case 2:
        return "two";
      case 3:
        return "three";
      case 4:
        return "four";
      case 5:
        return "five";
      case 6:
        return "six";
      case 7:
        return "seven";
      case 8:
        return "eight";
      case 9:
        return "nine";
      case 10:
        return "ten";
      default:
        return String.valueOf(numToConvert);
    }
  }
}
