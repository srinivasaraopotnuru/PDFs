package uk.co.ybs.digital.product.mapping;

import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.reinvestment.ProductReinvestmentResponse;
import uk.co.ybs.digital.product.web.dto.reinvestment.ReinvestmentProduct;

@Component
@RequiredArgsConstructor
public class ReinvestmentResponseMapper {

  public ProductReinvestmentResponse map(final List<Product> eligibleProducts) {
    return ProductReinvestmentResponse.builder()
        .reinvestmentProducts(
            eligibleProducts.stream()
                .map(
                    eligibleProduct ->
                        ReinvestmentProduct.builder()
                            .productIdentifier(eligibleProduct.getProductIdentifier())
                            .build())
                .collect(Collectors.toList()))
        .build();
  }
}
