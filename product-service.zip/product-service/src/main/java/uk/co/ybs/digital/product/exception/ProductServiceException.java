package uk.co.ybs.digital.product.exception;

public class ProductServiceException extends RuntimeException {

  private static final long serialVersionUID = 5902884234275928012L;

  public ProductServiceException(final String message) {
    super(message);
  }

  public ProductServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
