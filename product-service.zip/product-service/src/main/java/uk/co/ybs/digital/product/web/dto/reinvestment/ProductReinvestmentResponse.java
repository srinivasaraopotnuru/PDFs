package uk.co.ybs.digital.product.web.dto.reinvestment;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class ProductReinvestmentResponse {

  @ApiModelProperty(required = true)
  private List<ReinvestmentProduct> reinvestmentProducts;
}
