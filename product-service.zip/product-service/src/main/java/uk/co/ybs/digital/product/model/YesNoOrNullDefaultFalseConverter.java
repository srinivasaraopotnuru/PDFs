package uk.co.ybs.digital.product.model;

import javax.persistence.AttributeConverter;

public class YesNoOrNullDefaultFalseConverter implements AttributeConverter<Boolean, String> {
  @Override
  public String convertToDatabaseColumn(final Boolean bool) {
    if (bool == null) {
      return null;
    }

    return bool ? "Y" : "N";
  }

  @Override
  public Boolean convertToEntityAttribute(final String value) {

    if (value == null) {
      return false;
    }

    return "Y".equalsIgnoreCase(value);
  }
}
