package uk.co.ybs.digital.product.web.dto.onsale.productsummary;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@FieldDefaults(makeFinal = true, level = AccessLevel.PROTECTED)
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Builder
@Setter
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Projections {
  Section section;

  @ApiModelProperty(example = "Can Yorkshire Building Society change the interest rate?")
  String title;

  List<Content> content;
}
