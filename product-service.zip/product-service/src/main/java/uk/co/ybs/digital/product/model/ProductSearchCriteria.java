package uk.co.ybs.digital.product.model;

import java.util.Set;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;
import uk.co.ybs.digital.product.validator.ProductIdentifier;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ProductSearchCriteria {

  @Size(min = 1, message = "Cannot search for zero productIdentifiers")
  Set<@ProductIdentifier String> productIdentifiers;
}
