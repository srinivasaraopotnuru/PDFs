package uk.co.ybs.digital.product.service;

import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.product.mapping.WebSiteProductMapper;

@Service
@RequiredArgsConstructor
public class WebSiteProductIngestService {

  @Autowired private final LiferayService liferayService;
  @Autowired private final WebSiteProductMapper mapper;

  private final WebSiteProductIngestServiceProperties webSiteProductIngestServiceProperties;

  public List<WebSiteProduct> get(final UUID requestId) {

    return mapper.map(
        liferayService.getDocument(
            requestId, webSiteProductIngestServiceProperties.getOnsaleProductListDocumentId()));
  }
}
