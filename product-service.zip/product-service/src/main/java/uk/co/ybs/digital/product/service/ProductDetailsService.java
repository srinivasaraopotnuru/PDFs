package uk.co.ybs.digital.product.service;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import uk.co.ybs.digital.product.exception.NoProductForIdentifierException;
import uk.co.ybs.digital.product.mapping.ProductDetailsResponseMapper;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.InterestTier;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductRule;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;
import uk.co.ybs.digital.product.repository.InterestTierRepository;
import uk.co.ybs.digital.product.repository.ProductRepository;
import uk.co.ybs.digital.product.repository.ProductRuleRepository;
import uk.co.ybs.digital.product.web.dto.AvailableProductDetails;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;

@Service
@RequiredArgsConstructor
public class ProductDetailsService {

  private final Clock clock;
  private final ProductRepository productRepository;
  private final InterestTierRepository interestTierRepository;
  private final ProductRuleRepository productRuleRepository;
  private final ProductDetailsResponseMapper productDetailsResponseMapper;
  private final TessaYearCalculator tessaYearCalculator;
  private final ProductFilterService productFilterService;

  public Page<ProductDetailsResponse> searchProducts(
      final ProductSearchCriteria searchCriteria, final Pageable pageable) {
    final LocalDateTime now = LocalDateTime.now(clock);

    final Pageable consistentOrderPageable;

    // Ensure the query produces consistent ordering by including primary key in the sort order.
    final Sort requestedSort = pageable.getSort();
    if (requestedSort.getOrderFor(Product.PRIMARY_KEY_ATTRIBUTE_NAME) == null) {
      final Sort consistentOrderSort =
          requestedSort.and(Sort.by(Sort.Direction.ASC, Product.PRIMARY_KEY_ATTRIBUTE_NAME));
      consistentOrderPageable =
          PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), consistentOrderSort);
    } else {
      consistentOrderPageable = pageable;
    }

    final Page<Product> products =
        productRepository.findAll(searchCriteria, consistentOrderPageable);
    cacheInterestTiers(products.getContent(), now);

    final Map<Product, ActiveProductRules> activeProductRules =
        findActiveProductRules(products.getContent(), now);

    return products.map(product -> mapSingleProduct(product, activeProductRules, now));
  }

  public Page<ProductDetailsResponsePrivate> searchProductsPrivate(
      final ProductSearchCriteria searchCriteria, final Pageable pageable) {
    final LocalDateTime now = LocalDateTime.now(clock);

    final Pageable consistentOrderPageable;

    // Ensure the query produces consistent ordering by including primary key in the sort order.
    final Sort requestedSort = pageable.getSort();
    if (requestedSort.getOrderFor(Product.PRIMARY_KEY_ATTRIBUTE_NAME) == null) {
      final Sort consistentOrderSort =
          requestedSort.and(Sort.by(Sort.Direction.ASC, Product.PRIMARY_KEY_ATTRIBUTE_NAME));
      consistentOrderPageable =
          PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), consistentOrderSort);
    } else {
      consistentOrderPageable = pageable;
    }

    final Page<Product> products =
        productRepository.findAll(searchCriteria, consistentOrderPageable);
    cacheInterestTiers(products.getContent(), now);

    final Map<Product, ActiveProductRules> activeProductRules =
        findActiveProductRules(products.getContent(), now);

    return products.map(product -> mapSingleProductPrivate(product, activeProductRules, now));
  }

  public ProductDetailsResponse getProductDetailsForIdentifier(final String productIdentifier) {
    final LocalDateTime now = LocalDateTime.now(clock);

    final Product product =
        productRepository
            .findByProductIdentifier(productIdentifier, now)
            .orElseThrow(
                () ->
                    new NoProductForIdentifierException(
                        String.format("No product found for identifier: %s", productIdentifier)));

    final Map<Product, ActiveProductRules> activeProductRules =
        findActiveProductRules(Collections.singletonList(product), now);

    return mapSingleProduct(product, activeProductRules, now);
  }

  public ProductDetailsResponsePrivate getProductDetailsPrivateForIdentifier(
      final String productIdentifier) {
    final LocalDateTime now = LocalDateTime.now(clock);

    final Product product =
        productRepository
            .findByProductIdentifier(productIdentifier, now)
            .orElseThrow(
                () ->
                    new NoProductForIdentifierException(
                        String.format("No product found for identifier: %s", productIdentifier)));

    final Map<Product, ActiveProductRules> activeProductRules =
        findActiveProductRules(Collections.singletonList(product), now);

    return mapPrivateSingleProduct(product, activeProductRules, now);
  }

  private ProductDetailsResponse mapSingleProduct(
      final Product product,
      final Map<Product, ActiveProductRules> activeProductRules,
      final LocalDateTime now) {
    final ActiveProductRules activeProductRulesForProduct =
        Optional.ofNullable(activeProductRules.get(product))
            .orElseGet(() -> new ActiveProductRules(Collections.emptyList()));

    return productDetailsResponseMapper.map(product, activeProductRulesForProduct, now);
  }

  private ProductDetailsResponsePrivate mapSingleProductPrivate(
      final Product product,
      final Map<Product, ActiveProductRules> activeProductRules,
      final LocalDateTime now) {
    final ActiveProductRules activeProductRulesForProduct =
        Optional.ofNullable(activeProductRules.get(product))
            .orElseGet(() -> new ActiveProductRules(Collections.emptyList()));

    return productDetailsResponseMapper.mapPrivate(product, activeProductRulesForProduct, now);
  }

  private ProductDetailsResponsePrivate mapPrivateSingleProduct(
      final Product product,
      final Map<Product, ActiveProductRules> activeProductRules,
      final LocalDateTime now) {
    final ActiveProductRules activeProductRulesForProduct =
        Optional.ofNullable(activeProductRules.get(product))
            .orElseGet(() -> new ActiveProductRules(Collections.emptyList()));

    return productDetailsResponseMapper.mapPrivate(product, activeProductRulesForProduct, now);
  }

  private Map<Product, ActiveProductRules> findActiveProductRules(
      final Collection<Product> products, final LocalDateTime now) {
    if (products.isEmpty()) {
      return Collections.emptyMap();
    } else {
      final String depositLimitTaxYearRule =
          AvailableProductRule.DEPOSIT_LIMIT_TAX_YEAR_PREFIX
              + tessaYearCalculator.getTessaYear(now);
      final List<String> rules =
          Stream.concat(
                  AvailableProductRule.KNOWN_PRODUCT_RULES.stream(),
                  Stream.of(depositLimitTaxYearRule))
              .collect(Collectors.toList());
      return productRuleRepository.findByProductAndRuleCodes(products, rules, now).stream()
          .collect(
              Collectors.groupingBy(
                  ProductRule::getProduct,
                  Collectors.collectingAndThen(Collectors.toList(), ActiveProductRules::new)));
    }
  }

  private void cacheInterestTiers(final Collection<Product> products, final LocalDateTime now) {
    final List<Long> productSysids =
        products.stream().map(Product::getSysid).collect(Collectors.toList());

    final Collection<InterestTier> tiers = interestTierRepository.findAllActive(productSysids, now);
    final Map<Long, Set<InterestTier>> tiersByProduct =
        tiers.stream()
            .collect(Collectors.groupingBy(InterestTier::getProductSysid, Collectors.toSet()));

    products.forEach(
        product -> {
          final Set<InterestTier> tiersForProduct =
              tiersByProduct.getOrDefault(product.getSysid(), Collections.emptySet());
          product.setInterestTiers(tiersForProduct);
        });
  }

  public List<ProductCategory> getAvailableProducts(
      @Validated final AvailableProductDetails availableProductsRequest, final UUID requestId) {

    final LocalDateTime now = LocalDateTime.now(clock);
    return productFilterService.filterProducts(availableProductsRequest, now, requestId);
  }
}
