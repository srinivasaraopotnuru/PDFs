package uk.co.ybs.digital.product.web.controller;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import java.text.ParseException;
import java.util.List;
import java.util.UUID;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;
import uk.co.ybs.digital.product.service.OnSaleProductService;
import uk.co.ybs.digital.product.service.ProductDetailsService;
import uk.co.ybs.digital.product.validator.PageableSort;
import uk.co.ybs.digital.product.validator.ProductIdentifier;
import uk.co.ybs.digital.product.web.dto.ProductDetailsPageResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ProductSummary;

@RestController
@RequiredArgsConstructor
@Validated
public class ProductController {
  private static final String READ_CONSTRAINTS =
      "hasAuthority('SCOPE_ACCOUNT_READ') or hasAuthority('SCOPE_PRODUCT_READ')";

  private final ProductDetailsService productDetailsService;
  private final OnSaleProductService onSaleProductService;

  @GetMapping(path = "/product", produces = MediaType.APPLICATION_JSON_VALUE)
  @ApiOperation(value = "Search for products")
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "page",
        dataType = "int",
        paramType = "query",
        defaultValue = "0",
        value = "Results page you want to retrieve (0..N)"),
    @ApiImplicitParam(
        name = "size",
        dataType = "int",
        paramType = "query",
        defaultValue = "20",
        value = "Number of records per page."),
    @ApiImplicitParam(
        name = "sort",
        allowMultiple = true,
        dataType = "string",
        paramType = "query",
        value =
            "Sorting criteria in the format: property(,asc|desc). Multiple sort criteria are supported.",
        allowableValues = "productIdentifier")
  })
  @PreAuthorize(READ_CONSTRAINTS)
  public ProductDetailsPageResponse searchProductDetails(
      @Valid final ProductSearchCriteria searchCriteria,
      @PageableDefault(page = 0, size = 20)
          @ApiIgnore
          @PageableSort(fieldRegexp = "productIdentifier")
          final Pageable pageable) {
    return ProductDetailsPageResponse.builder()
        .page(productDetailsService.searchProducts(searchCriteria, pageable))
        .build();
  }

  @ApiOperation(value = "Request product rules for a supplied product code")
  @GetMapping(path = "/product/{productIdentifier}", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(READ_CONSTRAINTS)
  public ProductDetailsResponse getProductDetails(
      @PathVariable @ProductIdentifier final String productIdentifier) {
    return productDetailsService.getProductDetailsForIdentifier(productIdentifier);
  }

  @ApiOperation(value = "Retrieve on-sale products")
  @GetMapping(path = "/on-sale-products", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<ProductCategory> getOnSaleProducts(
      @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME) final UUID requestId) {
    return onSaleProductService.getProducts(requestId);
  }

  @ApiOperation(value = "Returns details of a product on-sale.")
  @GetMapping(
      path = "/on-sale-products/{productIdentifier}/summary",
      produces = MediaType.APPLICATION_JSON_VALUE)
  public ProductSummary getProductSummary(
      @PathVariable @ProductIdentifier final String productIdentifier,
      @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME) final UUID requestId)
      throws ParseException {
    return onSaleProductService.getProductSummary(productIdentifier, requestId);
  }
}
