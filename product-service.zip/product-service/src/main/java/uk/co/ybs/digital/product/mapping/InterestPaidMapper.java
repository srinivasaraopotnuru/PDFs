package uk.co.ybs.digital.product.mapping;

import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestPaidType;

@Component
public class InterestPaidMapper {

  public InterestPaidType map(final Product product) {
    if (product.getProductIdentifier().endsWith("M")) {
      return InterestPaidType.MONTHLY;
    } else {
      return InterestPaidType.ANNUALLY;
    }
  }
}
