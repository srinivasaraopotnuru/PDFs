package uk.co.ybs.digital.product.web.dto.onsale;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = ProductCategory.ProductCategoryBuilder.class)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ProductCategory {
  @ApiModelProperty(required = true)
  @NonNull
  String title;

  @ApiModelProperty(required = true)
  @NonNull
  String subTitle;

  @ApiModelProperty(required = true)
  @NonNull
  String description;

  @ApiModelProperty(required = true)
  @NonNull
  List<Product> products;

  @ApiModelProperty(required = true)
  @NonNull
  Boolean offlineOnlyProductsAvailable;

  @ApiModelProperty(required = true)
  @NonNull
  String url;

  List<Product> unavailableProducts;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ProductCategoryBuilder {}
}
