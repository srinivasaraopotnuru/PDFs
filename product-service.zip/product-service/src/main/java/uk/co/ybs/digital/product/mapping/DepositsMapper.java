package uk.co.ybs.digital.product.mapping;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Deposits;

@AllArgsConstructor
@Component
@Slf4j
public class DepositsMapper {

  private static final SupportedPeriodLimits SUPPORTED_PERIOD_LIMITS =
      SupportedPeriodLimits.builder().month(true).taxYear(true).build();

  // Special case: Allow help to buy ISAs with first month rule even though we have not implemented
  // support for first
  // month limits. We can do this because these are no longer available and no one is still in their
  // first month.
  private static final SupportedPeriodLimits SUPPORTED_PERIOD_LIMITS_HELP_TO_BUY_ISA =
      SUPPORTED_PERIOD_LIMITS.toBuilder().firstMonth(true).build();

  @NonNull private final DepositLimitsMapper limitsMapper;
  @NonNull private final PeriodLimitsChecker periodLimitsChecker;
  @NonNull private final DepositsByCardChecker depositsByCardChecker;

  public Deposits map(
      final Product product, final ActiveProductRules productRules, final LocalDateTime now) {
    final Optional<Deposits.DepositLimits> limits = limitsMapper.map(productRules, now);

    final boolean supportedProduct = productRules.isSupportedProduct();
    final boolean productActive = product.isActiveAt(now);
    final boolean webTransactionsAllowed =
        productRules.getBooleanWithDefault(AvailableProductRule.WEB_TRANSACTIONS, false);
    final boolean allowDepositsInternal =
        productRules.getBooleanWithDefault(
            AvailableProductRule.ALLOW_BANK_TRANSFER_DEPOSITS, false);
    final boolean supportedDepositLimits =
        limits
            .map(limitsUnwrapped -> isSupportedDepositLimits(productRules, limitsUnwrapped))
            .orElse(true);
    // We don't yet support including recent direct debit transaction in the calculation of the
    // remaining available
    // deposit limit, so for now don't allow deposits for accounts which support direct debits with
    // any deposit limit.
    final boolean allowDirectDebitsIn =
        productRules.getBooleanWithDefault(AvailableProductRule.ALLOW_DIRECT_DEBIT_DEPOSITS, false);
    final boolean directDebitsPreventDeposits = allowDirectDebitsIn && limits.isPresent();

    final boolean internalDepositsPermitted =
        supportedProduct
            && productActive
            && webTransactionsAllowed
            && allowDepositsInternal
            && supportedDepositLimits
            && !directDebitsPreventDeposits;

    if (!internalDepositsPermitted) {
      log.info(
          "Product {} does not support internal deposits over the API. "
              + "supportedProduct: {}, "
              + "productActive: {}, "
              + "webTransactionsAllowed: {}, "
              + "allowDepositsInternal: {}, "
              + "supportedDepositLimits: {}, "
              + "directDebitsPreventDeposits: {}",
          product.getProductIdentifier(),
          supportedProduct,
          productActive,
          webTransactionsAllowed,
          allowDepositsInternal,
          supportedDepositLimits,
          directDebitsPreventDeposits);
    }

    final boolean depositsPermittedByCard = depositsByCardChecker.isSupported(productRules);

    final ProductDetailsResponse.Deposits.DepositsBuilder builder =
        ProductDetailsResponse.Deposits.builder()
            .permittedInternal(internalDepositsPermitted)
            .permittedExternal(
                !productRules.getBooleanWithDefault(
                        AvailableProductRule.STOP_DEPOSITS_EXTERNAL, false)
                    && productRules.getBooleanWithDefault(
                        AvailableProductRule.ALLOW_BANK_TRANSFER_DEPOSITS, true))
            .permittedInBranch(
                productRules.getBooleanWithDefault(
                    AvailableProductRule.ALLOW_BRANCH_TRANSFERS, true))
            .permittedByCard(depositsPermittedByCard);

    limits.ifPresent(builder::limits);

    return builder.build();
  }

  private boolean isSupportedDepositLimits(
      final ActiveProductRules productRules, final Deposits.DepositLimits depositLimits) {
    final SupportedPeriodLimits supportedPeriodLimits;
    if (productRules.isIsaProduct()
        && productRules.getBooleanWithDefault(AvailableProductRule.ISA_HELP_TO_BUY, false)) {
      supportedPeriodLimits = SUPPORTED_PERIOD_LIMITS_HELP_TO_BUY_ISA;
    } else {
      supportedPeriodLimits = SUPPORTED_PERIOD_LIMITS;
    }

    final ProductDetailsResponse.PeriodLimits<BigDecimal> periodLimits = depositLimits.getAmount();
    return periodLimitsChecker.isSupported(periodLimits, supportedPeriodLimits);
  }
}
