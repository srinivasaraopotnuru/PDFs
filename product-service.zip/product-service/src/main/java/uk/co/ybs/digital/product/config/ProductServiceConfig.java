package uk.co.ybs.digital.product.config;

import java.time.Clock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import uk.co.ybs.digital.product.config.onsale.OnSaleProductProperties;
import uk.co.ybs.digital.product.service.WebSiteProductIngestServiceProperties;
import uk.co.ybs.digital.product.web.controller.ProductController;

@Configuration
@EnableConfigurationProperties({
  OnSaleProductProperties.class,
  WebSiteProductIngestServiceProperties.class
})
@EnableAspectJAutoProxy
@EnableJpaRepositories("uk.co.ybs.digital.product")
@EnableTransactionManagement
@Slf4j
public class ProductServiceConfig {

  @Bean
  public Docket api() {
    return new Docket(DocumentationType.SWAGGER_2)
        .select()
        .apis(RequestHandlerSelectors.basePackage(ProductController.class.getPackage().getName()))
        .paths(PathSelectors.any())
        .build();
  }

  @Bean
  public Clock clock() {
    // The application should be run in UK timezone for consistency with other
    // YBS timezone handling.
    final Clock systemClock = Clock.systemDefaultZone();
    log.info("System clock is: {}", systemClock);
    return systemClock;
  }
}
