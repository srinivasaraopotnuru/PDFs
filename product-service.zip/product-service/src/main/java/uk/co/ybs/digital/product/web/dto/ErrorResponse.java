package uk.co.ybs.digital.product.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import java.util.UUID;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Singular;
import lombok.Value;
import org.springframework.http.HttpStatus;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonDeserialize(builder = ErrorResponse.ErrorResponseBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public final class ErrorResponse {
  @NonNull UUID id;

  @NonNull String code;

  @NonNull String message;

  @Singular List<? extends ErrorItem> errors;

  public static ErrorResponseBuilder builder() {
    return new ErrorResponseBuilder();
  }

  public static ErrorResponseBuilder builder(final HttpStatus status) {
    return builder()
        .code(String.format("%s %s", status.value(), status.getReasonPhrase()))
        .message(status.getReasonPhrase());
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ErrorResponseBuilder {}

  @Value
  @Builder
  @AllArgsConstructor(access = AccessLevel.PRIVATE)
  @JsonDeserialize(builder = ErrorItem.ErrorItemBuilder.class)
  @SuppressWarnings("PMD.CommentDefaultAccessModifier")
  public static final class ErrorItem {
    public static final String ACCESS_DENIED = "AccessDenied";
    public static final String RULE_MISSING = "Rule.Missing";
    public static final String INVALID_REQUEST_SIGNATURE = "AccessDenied.InvalidRequestSignature";
    public static final String FIELD_INVALID = "Field.Invalid";
    public static final String FIELD_MISSING = "Field.Missing";
    public static final String HEADER_INVALID = "Header.Invalid";
    public static final String RESOURCE_NOT_FOUND = "Resource.NotFound";
    public static final String UNAUTHORIZED = "Unauthorized";
    public static final String UNEXPECTED_ERROR = "UnexpectedError";
    public static final String UNSUPPORTED_METHOD = "Unsupported.Method";

    @NonNull String errorCode;

    @NonNull String message;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String path;

    @JsonPOJOBuilder(withPrefix = "")
    public static class ErrorItemBuilder {}
  }
}
