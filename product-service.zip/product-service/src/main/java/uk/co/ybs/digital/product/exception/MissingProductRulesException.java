package uk.co.ybs.digital.product.exception;

public class MissingProductRulesException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public MissingProductRulesException(final String message) {
    super(message);
  }
}
