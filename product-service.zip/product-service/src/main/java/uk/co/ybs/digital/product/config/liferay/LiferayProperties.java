package uk.co.ybs.digital.product.config.liferay;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.validation.annotation.Validated;

@ConfigurationProperties(prefix = "liferay.svc")
@ConstructorBinding
@AllArgsConstructor
@Getter
@Validated
public class LiferayProperties {

  @NotNull private final String baseUri;

  @NotNull private final String username;

  @NotNull private final String password;
}
