package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Account;

@Component
public class AccountBuilder {

  public Account map(final WebSiteProduct webSiteProduct) {
    return Account.builder()
        .section(buildSection("0", false, false))
        .title("Account name")
        .name(String.format("<bold>%s<bold>", webSiteProduct.getAccountNameFull()))
        .build();
  }
}
