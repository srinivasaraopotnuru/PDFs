package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.Arrays;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Prerequisites;

@Component
public class PrerequisitesBuilder {

  private static final String TERMS_AND_CONDITIONS_LINK =
      "https://www.ybs.co.uk/productdata/YBM0617_Inline_General_TandCs.pdf";
  private static final String FSCS_LINK = "https://www.ybs.co.uk/productdata/FSCS.pdf";
  private static final String CHARGE_AND_FEES_LINK =
      "https://www.ybs.co.uk/productdata/Charges_and_Fees.pdf";
  private static final String IDENTITY_LINK =
      "https://www.ybs.co.uk/help/verifying-your-identity.html";

  public Prerequisites map(final WebSiteProduct webSiteProduct) {
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Please take time to review the following documents before you apply.")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text("Product Terms")
            .link(
                String.format(
                    "https://www.ybs.co.uk/productdata/Factsheet-%s.pdf",
                    webSiteProduct.getProductCode()))
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text("General Terms and Conditions")
            .link(TERMS_AND_CONDITIONS_LINK)
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text("FSCS Information Sheet")
            .link(FSCS_LINK)
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text("Charges and Fees")
            .link(CHARGE_AND_FEES_LINK)
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.LINK.getFormat())
            .text(
                "When you apply for this account with us, you'll need to <link>verify your identity and address<link>.")
            .link(IDENTITY_LINK)
            .build();

    return Prerequisites.builder()
        .section(buildSection("7", false, false))
        .title("Before you apply")
        .content(Arrays.asList(item1, item2, item3, item4, item5, item6))
        .build();
  }
}
