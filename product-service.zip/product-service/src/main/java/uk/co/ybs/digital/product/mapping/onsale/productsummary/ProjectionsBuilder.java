package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;
import static uk.co.ybs.digital.product.service.OnSaleProductService.formatAsMoney;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Projections;

@Component
public class ProjectionsBuilder {

  private static final String HELP_TO_BUY_ISA_ACCOUNT = "Help to Buy: ISA";

  public Projections map(final WebSiteProduct webSiteProduct) {
    final boolean fixedTerm = checkYesValue(webSiteProduct.getFixedTerm());
    final String accountNameFull = webSiteProduct.getAccountNameFull();
    final String title;
    final List<Content> contentList = new ArrayList<>();

    if (fixedTerm) {

      title =
          "What would be the estimated balance at the end of the fixed term based on a £1,000 deposit?";
      final Content item1 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "At the end of the fixed term, the balance would be £%s.",
                      formatAsMoney(webSiteProduct.getExampleBalanceT1())))
              .build();

      final Content item2 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "We have worked this out assuming a £%s deposit is made on account opening on the first day the product goes on sale, interest earned is added to the account and no further deposits or withdrawals are made throughout the fixed-term.",
                      formatAsMoney(webSiteProduct.getExampleStartingAmountT1())))
              .build();

      final Content item3 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "This projection is provided for illustrative purposes only and does not take into account your individual circumstances.")
              .build();

      contentList.addAll(Arrays.asList(item1, item2, item3));

    } else if (HELP_TO_BUY_ISA_ACCOUNT.equals(accountNameFull)) {
      title = "What would be the estimated balance after 12 months based on a range of deposits?";

      final Content item1 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "£%s as an initial deposit and £%s each subsequent month saved at tax-free p.a./AER would lead to a balance of £%s at the end of the first %s months.",
                      formatAsMoney(webSiteProduct.getExampleStartingAmountT1()),
                      webSiteProduct.getExampleOngoingDepositT1(),
                      formatAsMoney(webSiteProduct.getExampleBalanceT1()),
                      webSiteProduct.getExampleTermT1()))
              .build();

      final Content item2 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "This projection is provided for illustrative purposes only and does not take into account your individual circumstances")
              .build();

      contentList.addAll(Arrays.asList(item1, item2));

    } else {

      title = "What would be the estimated balance after 12 months based on a range of deposits?";

      for (int currentTier = 1;
          currentTier <= getMaximumProductTiers(webSiteProduct);
          currentTier++) {

        final Content item1 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "If you deposit £%s, after %s months your balance would be £%s",
                        formatAsMoney(getExampleStartingAmount(currentTier, webSiteProduct)),
                        getExampleTerm(currentTier, webSiteProduct),
                        formatAsMoney(getExampleBalance(currentTier, webSiteProduct))))
                .build();

        contentList.add(item1);
      }

      final Content item2 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "We have worked this out assuming a deposit is made on account opening, no further deposits or withdrawals are made throughout the %s months, the interest earned is added to the account and no changes made to the current interest rate.",
                      webSiteProduct.getExampleTermT1()))
              .build();

      final Content item3 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "This projection is provided for illustrative purposes only and does not take into account your individual circumstances.")
              .build();

      contentList.addAll(Arrays.asList(item2, item3));
    }

    return Projections.builder()
        .section(buildSection("3", true, true))
        .title(title)
        .content(contentList)
        .build();
  }

  private int getExampleStartingAmount(final int tier, final WebSiteProduct webSiteProduct) {

    switch (tier) {
      case 1:
        return webSiteProduct.getExampleStartingAmountT1();
      case 2:
        return webSiteProduct.getExampleStartingAmountT2();
      case 3:
        return webSiteProduct.getExampleStartingAmountT3();
      case 4:
        return webSiteProduct.getExampleStartingAmountT4();
      case 5:
        return webSiteProduct.getExampleStartingAmountT5();
      default:
        return 0;
    }
  }

  private int getExampleTerm(final int tier, final WebSiteProduct webSiteProduct) {

    switch (tier) {
      case 1:
        return webSiteProduct.getExampleTermT1();
      case 2:
        return webSiteProduct.getExampleTermT2();
      case 3:
        return webSiteProduct.getExampleTermT3();
      case 4:
        return webSiteProduct.getExampleTermT4();
      case 5:
        return webSiteProduct.getExampleTermT5();
      default:
        return 0;
    }
  }

  private BigDecimal getExampleBalance(final int tier, final WebSiteProduct webSiteProduct) {

    switch (tier) {
      case 1:
        return webSiteProduct.getExampleBalanceT1();
      case 2:
        return webSiteProduct.getExampleBalanceT2();
      case 3:
        return webSiteProduct.getExampleBalanceT3();
      case 4:
        return webSiteProduct.getExampleBalanceT4();
      case 5:
        return webSiteProduct.getExampleBalanceT5();
      default:
        return BigDecimal.ZERO;
    }
  }

  private int getMaximumProductTiers(final WebSiteProduct webSiteProduct) {
    if (webSiteProduct.getExampleStartingAmountT5() != null
        && webSiteProduct.getExampleBalanceT5() != null) {
      return 5;
    }
    if (webSiteProduct.getExampleStartingAmountT4() != null
        && webSiteProduct.getExampleBalanceT4() != null) {
      return 4;
    }
    if (webSiteProduct.getExampleStartingAmountT3() != null
        && webSiteProduct.getExampleBalanceT3() != null) {
      return 3;
    }
    if (webSiteProduct.getExampleStartingAmountT2() != null
        && webSiteProduct.getExampleBalanceT2() != null) {
      return 2;
    }
    return 1;
  }
}
