package uk.co.ybs.digital.product.service;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.product.exception.MissingProductRulesException;
import uk.co.ybs.digital.product.exception.NoProductForIdentifierException;
import uk.co.ybs.digital.product.mapping.ReinvestmentResponseMapper;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.repository.ProductRepository;
import uk.co.ybs.digital.product.repository.ProductRuleRepository;
import uk.co.ybs.digital.product.web.dto.reinvestment.ProductReinvestmentResponse;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductReinvestmentService {
  private static final String CHAR_VALUE_Y = "Y";
  private static final List<String> REQUIRED_CURRENT_PRODUCT_RULES =
      Arrays.asList(
          AvailableProductRule.EXISA,
          AvailableProductRule.EXBOND,
          AvailableProductRule.PRODUCT_TYPE);

  private final Clock clock;
  private final ProductRepository productRepository;
  private final ProductRuleRepository productRuleRepository;
  private final ReinvestmentResponseMapper reinvestmentResponseMapper;

  public ProductReinvestmentResponse getReinvestmentProducts(final String productIdentifier) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final Product product =
        productRepository
            .findByProductIdentifier(productIdentifier, now)
            .orElseThrow(
                () ->
                    new NoProductForIdentifierException(
                        String.format("No product found for identifier: %s", productIdentifier)));

    final ActiveProductRules activeProductRules = findActiveProductRules(product, now);
    final String productType = activeProductRules.getStringValue(AvailableProductRule.PRODUCT_TYPE);

    if (productType == null || !productHasRequiredActiveProductRules(activeProductRules)) {
      throw new MissingProductRulesException(
          String.format("Required product rules missing for identifier: %s", productIdentifier));
    }

    final List<Product> eligibleProducts =
        productRepository.findReinvestableProducts(productType, now);

    if (eligibleProducts.isEmpty()) {
      log.info("No eligible reinvestment products found for identifier: {}", productIdentifier);
    }

    return reinvestmentResponseMapper.map(eligibleProducts);
  }

  private ActiveProductRules findActiveProductRules(
      final Product product, final LocalDateTime now) {
    return productRuleRepository
        .findByProductAndRuleCodes(
            Collections.singletonList(product), REQUIRED_CURRENT_PRODUCT_RULES, now)
        .stream()
        .collect(Collectors.collectingAndThen(Collectors.toList(), ActiveProductRules::new));
  }

  private boolean productHasRequiredActiveProductRules(
      final ActiveProductRules activeProductRules) {
    return CHAR_VALUE_Y.equals(activeProductRules.getStringValue(AvailableProductRule.EXISA))
        || CHAR_VALUE_Y.equals(activeProductRules.getStringValue(AvailableProductRule.EXBOND));
  }
}
