package uk.co.ybs.digital.product.mapping;

import java.util.List;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestDestinationType;

@Component
public class WebAmendmentsMapper {
  private static final String CHAR_VALUE_Y = "Y";

  public boolean map(
      final ActiveProductRules productRules,
      final List<InterestDestinationType> interestDestinationTypes) {
    return CHAR_VALUE_Y.equals(productRules.getStringValue(AvailableProductRule.WEB_TRANSACTIONS))
        && CHAR_VALUE_Y.equals(productRules.getStringValue(AvailableProductRule.WEB_AMENDMENTS))
        && !CHAR_VALUE_Y.equals(productRules.getStringValue(AvailableProductRule.OFFSET_ACCOUNT))
        && !interestDestinationTypes.isEmpty();
  }
}
