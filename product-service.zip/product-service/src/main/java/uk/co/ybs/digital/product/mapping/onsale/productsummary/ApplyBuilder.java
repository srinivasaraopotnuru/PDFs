package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.Arrays;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Apply;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;

@Component
public class ApplyBuilder {

  private static final String TELEPHONE_NUMBER = "0345 1200 100";
  private static final String OPENING_TIMES = "9am - 5pm Mon-Fri";
  private static final String OPENING_TIMES_WEEKEND = "9am - 1pm Sat";

  public Apply map() {
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Complete our simple, straightforward application form")
            .build();

    final Content item2 =
        Content.builder().format(FormatType.BUTTON.getFormat()).text("Apply").build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "If you feel you need additional support before applying for this account, please call us")
            .build();

    final Content item4 =
        Content.builder().format(FormatType.TEXT.getFormat()).text(TELEPHONE_NUMBER).build();

    final Content item5 =
        Content.builder().format(FormatType.TEXT.getFormat()).text(OPENING_TIMES).build();

    final Content item6 =
        Content.builder().format(FormatType.TEXT.getFormat()).text(OPENING_TIMES_WEEKEND).build();

    return Apply.builder()
        .section(buildSection("8", false, false))
        .title("Apply")
        .content(Arrays.asList(item1, item2, item3, item4, item5, item6))
        .build();
  }
}
