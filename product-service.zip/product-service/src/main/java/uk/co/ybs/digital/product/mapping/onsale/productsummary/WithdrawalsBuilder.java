package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Withdrawals;

@Component
public class WithdrawalsBuilder {

  private static final String PAYMENT_GUIDE_LINK =
      "https://www.ybs.co.uk/help/payment-guidance/payments-from-my-account.html";

  private static final String CHAPS_FEE = "£23.50";
  private static final String LOYALTY_SIX_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME =
      "Loyalty Six Access Saver ISA";
  private static final String YEAR_LIMITED_ACCESS_SAVER_ISA_ISSUE_3_ACCOUNT_SHORT_NAME =
      "1 Year Limited Access Saver ISA Issue 3";
  private static final String YEAR_LIMITED_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME =
      "1 Year Limited Access Saver ISA";
  private static final String EASY_SAVER_E_ISA_PLUS_ACCOUNT_SHORT_NAME = "Easy Saver eISA Plus";
  private static final String EASY_E_SAVER_PLUS_ACCOUNT_SHORT_NAME = "Easy eSaver Plus";
  private static final String LOYALTY_SIX_ACCESS_SAVER_ACCOUNT_SHORT_NAME =
      "Loyalty Six Access Saver";
  private static final String ANNUAL_ACCESS_ACCOUNT_ISA_ACCOUNT_SHORT_NAME =
      "Annual Access Account ISA";
  private static final String LIMITED_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME =
      "Limited Access Saver ISA";
  private static final String SIX_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME = "Six Access Saver ISA";
  private static final String HELP_TO_BUY_ISA_ACCOUNT_SHORT_NAME = "Help to Buy: ISA";

  public Withdrawals map(final WebSiteProduct webSiteProduct) {
    final List<Content> contentList = new ArrayList<>();

    final boolean cashISA = checkYesValue(webSiteProduct.getCashISA());
    final boolean flexibleIsa = checkYesValue(webSiteProduct.getFlexibleISA());
    final boolean applyOnline = checkYesValue(webSiteProduct.getApplyOnline());
    final boolean maturityProduct = checkYesValue(webSiteProduct.getMaturityProduct());
    final boolean maturityProductOffer = checkYesValue(webSiteProduct.getMaturityProductOffer());
    final boolean taxFree = checkYesValue(webSiteProduct.getTaxFree());
    final boolean tieredProduct = checkYesValue(webSiteProduct.getTieredProduct());
    final boolean withdrawalsPermitted = checkYesValue(webSiteProduct.getWithdrawalsPermitted());
    final boolean fixedTerm = checkYesValue(webSiteProduct.getFixedTerm());
    final boolean optionalWithdrawalRestriction =
        checkYesValue(webSiteProduct.getOptionalWithdrawalRestriction());

    final String accountNameShort = webSiteProduct.getAccountNameShort();
    final String accountNameFull = webSiteProduct.getAccountNameFull();
    final Integer withdrawalDays = webSiteProduct.getWithdrawalDays();
    final Integer lossOfInterest = webSiteProduct.getLossOfInterest();
    final String minimumWithdrawalAmount = webSiteProduct.getMinWithdrawalAmount();
    final String maturesIntoProductName = webSiteProduct.getMaturesIntoProductName();

    if (withdrawalsPermitted) {

      contentList.addAll(
          withdrawalsPermittedContent(
              webSiteProduct,
              maturityProduct,
              taxFree,
              tieredProduct,
              accountNameShort,
              accountNameFull,
              withdrawalDays,
              minimumWithdrawalAmount));
    } else {
      contentList.addAll(
          withdrawalsNotPermittedContent(
              cashISA, maturityProduct, maturityProductOffer, lossOfInterest));
    }

    if (flexibleIsa) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "Flexibility means that savings withdrawn from this Cash ISA can be replaced in the same tax year without counting towards your annual ISA allowance. Please note that the tax year runs from 6 April to 5 April the following year.")
              .build();
      contentList.add(item);
    }

    if (withdrawalsPermitted) {

      if (!EASY_SAVER_E_ISA_PLUS_ACCOUNT_SHORT_NAME.equals(accountNameShort)
          && !EASY_E_SAVER_PLUS_ACCOUNT_SHORT_NAME.equals(accountNameShort)
          && !LOYALTY_SIX_ACCESS_SAVER_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
        final Content item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "Please be aware if a withdrawal is made from the account by CHAPS a charge of %s will be incurred. Proof of name ID will be required.",
                        CHAPS_FEE))
                .build();
        contentList.add(item);
      }

      if (applyOnline) {
        final Content item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "For security reasons, online withdrawals are not available for the first 14 days after your account has been opened. After 14 days withdrawals can be made from your account at anytime on condition that there are sufficient cleared funds in your account and that you maintain the minimum balance of £%s.",
                        webSiteProduct.getMinBalanceT1()))
                .build();
        contentList.add(item);
      }
    }

    if (optionalWithdrawalRestriction) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text("A parent or guardian can specify a monthly withdrawal limit for under 18s.")
              .build();
      contentList.add(item);
    }

    if (isValid(maturesIntoProductName)) {
      contentList.addAll(
          maturesIntoProductContent(
              cashISA, applyOnline, fixedTerm, accountNameShort, maturesIntoProductName));
    }

    return Withdrawals.builder()
        .section(buildSection("5", true, true))
        .title("Can I withdraw money?")
        .content(contentList)
        .build();
  }

  private List<Content> maturesIntoProductContent(
      final boolean cashISA,
      final boolean applyOnline,
      final boolean fixedTerm,
      final String accountNameShort,
      final String maturesIntoProductName) {
    final List<Content> contentList = new ArrayList<>();
    final Content item =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Maturity").build();
    contentList.add(item);

    if (LOYALTY_SIX_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
      final Content item1 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "On the anniversary of your account opening, your savings will be transferred to the %s account and you will have easy access to your funds.",
                      maturesIntoProductName))
              .build();
      contentList.add(item1);
    } else if (YEAR_LIMITED_ACCESS_SAVER_ISA_ISSUE_3_ACCOUNT_SHORT_NAME.equals(accountNameShort)
        || YEAR_LIMITED_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
      final Content item1 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "On the first anniversary of your account opening, your savings will be transferred to %s",
                      maturesIntoProductName))
              .build();
      contentList.add(item1);
    } else if (ANNUAL_ACCESS_ACCOUNT_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
      final Content item1 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "On the anniversary of your account opening your savings will be transferred to the latest issue of the Easy ISA")
              .build();
      contentList.add(item1);
    } else if (cashISA) {

      if (fixedTerm) {

        final Content item1;
        if (applyOnline) {
          item1 =
              Content.builder()
                  .format(FormatType.TEXT.getFormat())
                  .text(
                      String.format(
                          "On maturity your balance will be automatically transferred into an %s. You may have the option to transfer the balance into another Fixed Rate eISA without the need to reapply.",
                          maturesIntoProductName))
                  .build();
        } else {
          item1 =
              Content.builder()
                  .format(FormatType.TEXT.getFormat())
                  .text(
                      String.format(
                          "This Fixed Rate ISA will mature into another %s that will be of no greater term than this %s. At maturity and during the first month after maturity, you will be able to withdraw all or part of your savings and have full access to them without incurring any loss of interest. Thereafter, you will only be permitted to close your ISA but this will be subject to a number of days loss of interest on the closing balance. The number of days’ loss of interest will be no more than the number of days under the terms of this %s. Further partial withdrawals will not be permitted. Early closure will result in the loss of your tax free status, other than transfers to another ISA. We will send to you by post full details of the new %s at least 14 days prior to the maturity of this Fixed Rate ISA.",
                          maturesIntoProductName,
                          maturesIntoProductName,
                          maturesIntoProductName,
                          maturesIntoProductName))
                  .build();
        }
        contentList.add(item1);
      }
    }
    return contentList;
  }

  private List<Content> withdrawalsNotPermittedContent(
      final boolean cashISA,
      final boolean maturityProduct,
      final boolean maturityProductOffer,
      final Integer lossOfInterest) {
    final List<Content> contentList = new ArrayList<>();
    if (maturityProduct) {
      if (cashISA) {
        if (maturityProductOffer) {
          final Content item =
              Content.builder()
                  .format(FormatType.TEXT.getFormat())
                  .text(
                      String.format(
                          "Withdrawals are not permitted. Closure is permitted during the term subject to an amount equivalent to %s days’ loss of interest on the closing balance. Early closure will result in the loss of your tax free status, other than transfers to another ISA.",
                          lossOfInterest))
                  .build();
          contentList.add(item);
        }
      }
    } else {
      if (cashISA) {
        final Content item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "Withdrawals are not permitted during the term other than circumstances covered under the Savings Pledge 2021 for account holder(s) or their immediate family members - critical or terminal illness, death, redundancy, nursing home or elderly care costs, divorce or court order. All withdrawals will result in loss of tax free status. Closure is permitted during the term subject to an amount equivalent to %s days’ loss of interest on the closing balance. Any loss of interest will be offset against any accrued interest not yet paid. If there is insufficient accrued interest outstanding the charge will be deducted from the account balance prior to closure. Closure for the circumstances detailed above under the Savings Pledge 2021 will not incur a loss of interest on the closing balance. Any early closure (except for transfers to another ISA) will result in loss of tax free status.",
                        lossOfInterest))
                .build();
        contentList.add(item);
      }
    }
    return contentList;
  }

  @SuppressWarnings({"PMD.ExcessiveParameterList", "PMD.ExcessiveMethodLength"})
  private List<Content> withdrawalsPermittedContent(
      final WebSiteProduct webSiteProduct,
      final boolean maturityProduct,
      final boolean taxFree,
      final boolean tieredProduct,
      final String accountNameShort,
      final String accountNameFull,
      final Integer withdrawalDays,
      final String minimumWithdrawalAmount) {
    final List<Content> contentList = new ArrayList<>();

    if (maturityProduct) {

      if (EASY_SAVER_E_ISA_PLUS_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {

        final Content item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "The %s account allows instant withdrawals, without loss of interest. If you make a withdrawal that reduces your balance to a lower interest rate tier we will not notify you of this.",
                        accountNameFull))
                .build();

        contentList.add(item);

      } else if (LIMITED_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {

        String text = "";
        if (withdrawalDays == null) {
          text = " unlimited";
        }
        final Content item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "The %s account allows%s withdrawals from your account on one day per account year, based on anniversary of account opening. You may also close your account at any time even if you have used your withdrawal day, without loss of interest. Please remember that if you close your account without transferring directly into another ISA you will lose the tax-free status of your savings.",
                        accountNameFull, text))
                .build();

        contentList.add(item);
      } else if (SIX_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {

        final Content item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "The %s account allows you to withdraw from your account on six days per account year,  based on the anniversary of account opening. You may also close your account at any time even if you have used all your withdrawal days. If you make a withdrawal that reduces your balance to a lower interest rate tier we will not notify you of this.",
                        accountNameFull))
                .build();

        contentList.add(item);
      } else {
        final String text;
        if (withdrawalDays == null) {
          text = " unlimited";
        } else {
          text = " minimum £" + webSiteProduct.getMinWithdrawalAmount();
        }

        final Content item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "The %s account allows%s withdrawals, <link>subject to daily withdrawal limits<link>, without loss of interest.",
                        accountNameFull, text))
                .link(PAYMENT_GUIDE_LINK)
                .build();

        contentList.add(item);
      }

    } else {

      if (withdrawalDays != null) {
        final String day = withdrawalDays == 1 ? "day" : "days";

        if (YEAR_LIMITED_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
          final Content item =
              Content.builder()
                  .format(FormatType.TEXT.getFormat())
                  .text(
                      String.format(
                          "The %s account allows you to withdraw from your account on %s %s per account year, based on the anniversary of the account opening date.",
                          accountNameFull, withdrawalDays, day))
                  .build();

          contentList.add(item);
        } else if (LOYALTY_SIX_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
          final Content item =
              Content.builder()
                  .format(FormatType.TEXT.getFormat())
                  .text(
                      String.format(
                          "The %s account allows you to withdraw from your account on %s %s per account year, based on the anniversary of the account opening date. You may also close your account at any time even if you have used all your withdrawal days. If you make a withdrawal that reduces your balance to a lower interest rate tier we will not notify you of this. Closure will result in the loss of the tax free status other than transfers to another ISA.",
                          accountNameFull, withdrawalDays, day))
                  .build();

          contentList.add(item);
        } else {
          final Content item =
              Content.builder()
                  .format(FormatType.TEXT.getFormat())
                  .text(
                      String.format(
                          "The %s account allows you withdrawals from your account, without losing any interest, on any %s %s per year based on the anniversary of the account opening date. Withdrawals are instant and <link>subject to daily withdrawal limits<link>",
                          accountNameFull, withdrawalDays, day))
                  .link(PAYMENT_GUIDE_LINK)
                  .build();

          contentList.add(item);
        }
        if (taxFree) {
          String text = "";
          if (YEAR_LIMITED_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameFull)) {
            text = " even if you have used your withdrawal day without loss of interest";
          }
          final Content item;
          if (!LOYALTY_SIX_ACCESS_SAVER_ISA_ACCOUNT_SHORT_NAME.equals(accountNameShort)) {
            item =
                Content.builder()
                    .format(FormatType.TEXT.getFormat())
                    .text(
                        String.format(
                            "You can close your account at any time%s. Please remember that if you close your account without transferring directly into another ISA you will lose the tax-free status of your savings.",
                            text))
                    .build();

          } else {
            item =
                Content.builder()
                    .format(FormatType.TEXT.getFormat())
                    .text(
                        "You may also close your account at any time even if you have made a withdrawal.")
                    .build();
          }
          contentList.add(item);
        }
      } else {
        final String text;
        if (!isValid(minimumWithdrawalAmount)) {
          text = "unlimited";
        } else {
          text = " minimum £" + minimumWithdrawalAmount;
        }
        String tieredText = "";
        if (tieredProduct) {
          tieredText =
              " If you make a withdrawal that reduces your balance to a lower interest rate tier we will not notify you of this.";
        }
        final Content item =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "The %s account allows %s instant withdrawals, <link>subject to daily withdrawal limits<link> without loss of interest.%s",
                        accountNameFull, text, tieredText))
                .build();

        contentList.add(item);

        if (HELP_TO_BUY_ISA_ACCOUNT_SHORT_NAME.equals(accountNameFull)) {
          final Content item2 =
              Content.builder()
                  .format(FormatType.TEXT.getFormat())
                  .text(
                      "Please note withdrawals and closure will result in the loss of your tax-free status, other than transfers to another ISA. Any withdrawals made will not qualify for the government bonus. This is not a flexible ISA so is subject to subscription limits.")
                  .build();

          contentList.add(item2);
        }
      }
    }
    return contentList;
  }

  private boolean isValid(final String string) {
    return (string != null && !string.isEmpty());
  }
}
