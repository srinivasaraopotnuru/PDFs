package uk.co.ybs.digital.product.web.dto.onsale;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = Product.ProductBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Product {
  @ApiModelProperty(required = true)
  @NonNull
  String name;

  @ApiModelProperty(required = true)
  @NonNull
  ProductType type;

  @ApiModelProperty(required = true)
  @NonNull
  String url;

  @ApiModelProperty(required = true)
  @NonNull
  String productCode;

  @ApiModelProperty(example = "16")
  Integer minimumAge;

  @ApiModelProperty(example = "75")
  Integer maximumAge;

  @ApiModelProperty(example = "1")
  Integer maximumNumberOfAccounts;

  @ApiModelProperty(required = true)
  Boolean loyalty;

  @ApiModelProperty(required = true)
  @NonNull
  List<InterestTier> interestTiers;

  @ApiModelProperty(required = true)
  @NonNull
  InterestFrequency interestFrequency;

  @ApiModelProperty(required = true)
  @NonNull
  List<Fact> facts;

  List<Warning> warnings;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ProductBuilder {}
}
