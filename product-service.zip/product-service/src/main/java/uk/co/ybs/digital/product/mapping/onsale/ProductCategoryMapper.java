package uk.co.ybs.digital.product.mapping.onsale;

import java.util.Collections;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.ProductCategoryType;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;

@Component
@AllArgsConstructor
public class ProductCategoryMapper {

  private final ProductCategoryUrlMapper urlMapper;
  private final ProductFilter productfilter;

  public ProductCategory map(
      final ProductCategoryType categoryType,
      final List<Product> onlineProducts,
      final List<WebSiteProduct> allProducts) {
    final Boolean hasOfflineOnlyProducts =
        allProducts.stream().anyMatch(productfilter::isOfflineOnlyProduct);

    return ProductCategory.builder()
        .title(categoryType.getTitle())
        .subTitle(categoryType.getSubTitle())
        .description(categoryType.getDescription())
        .products(onlineProducts)
        .unavailableProducts(Collections.emptyList())
        .url(urlMapper.map(categoryType))
        .offlineOnlyProductsAvailable(hasOfflineOnlyProducts)
        .build();
  }
}
