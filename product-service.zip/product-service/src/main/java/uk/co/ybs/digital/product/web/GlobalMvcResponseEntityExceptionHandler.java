package uk.co.ybs.digital.product.web;

import java.util.Set;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import uk.co.ybs.digital.product.web.dto.ErrorResponse;
import uk.co.ybs.digital.product.web.dto.ErrorResponse.ErrorItem;

@ControllerAdvice
@Order(
    Ordered.HIGHEST_PRECEDENCE) // Consult this ControllerAdvice first, before any service specific
// advice
public class GlobalMvcResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

  @Override
  protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
      final HttpRequestMethodNotSupportedException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    pageNotFoundLogger.warn(ex.getMessage());

    final Set<HttpMethod> supportedMethods = ex.getSupportedHttpMethods();
    if (!CollectionUtils.isEmpty(supportedMethods)) {
      headers.setAllow(supportedMethods);
    }

    final ErrorResponse body =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNSUPPORTED_METHOD)
                    .message("Unsupported method")
                    .build())
            .build();

    return handleExceptionInternal(ex, body, headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleExceptionInternal(
      final Exception ex,
      Object body,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    if (body == null && !HttpStatus.NOT_ACCEPTABLE.equals(status)) {
      // Put a generic error response body in with the right status
      body =
          ErrorResponse.builder(status)
              .id(RequestIdHelper.getRequestId(request))
              .error(
                  ErrorItem.builder()
                      .errorCode(ErrorItem.UNEXPECTED_ERROR)
                      .message("Unexpected Error")
                      .build())
              .build();
    }

    return super.handleExceptionInternal(ex, body, headers, status, request);
  }
}
