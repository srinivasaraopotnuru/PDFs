package uk.co.ybs.digital.product.web.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
public class ProductDetailsResponse extends ProductDetailsResponseBase {

  private Withdrawals withdrawals;

  @ApiModelProperty(required = true)
  private Interest interest;

  private Isa isa;
}
