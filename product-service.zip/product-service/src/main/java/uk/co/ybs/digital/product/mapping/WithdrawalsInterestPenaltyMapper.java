package uk.co.ybs.digital.product.mapping;

import java.util.Optional;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.WithdrawalsPrivate.InterestPenalty;

@Component
public class WithdrawalsInterestPenaltyMapper {

  public Optional<InterestPenalty> map(final Product product) {
    if (product.getPenaltyDays() <= 0) {
      return Optional.empty();
    }

    return Optional.of(
        InterestPenalty.builder()
            .code(product.getPenaltyCode())
            .days(product.getPenaltyDays())
            .balanceUpperBound(product.getPenaltyAmount())
            .build());
  }
}
