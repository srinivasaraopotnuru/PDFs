package uk.co.ybs.digital.product.mapping.onsale;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;

import java.util.Objects;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;

@Component
public class ProductFilter {

  public boolean includeProduct(final WebSiteProduct webSiteProduct) {
    // Non-YBS products are filtered when displaying products on the website. The JSON doesn't
    // appear to contain
    // any which aren't for YBS, but it's probably safest to do the same as what the website does.
    return Objects.equals(webSiteProduct.getBrand(), "YBS")
        &&
        // Maturity products are filtered when displaying products on the website, do the same
        !checkYesValue(webSiteProduct.getMaturityProduct())
        &&
        // Only supporting apply online products initially as this simplifies the rules
        checkYesValue(webSiteProduct.getApplyOnline())
        && checkInterestPeriod(webSiteProduct);
  }

  private boolean checkInterestPeriod(final WebSiteProduct webSiteProduct) {
    return !checkYesValue(webSiteProduct.getInterestBiannually());
  }

  public boolean isOfflineOnlyProduct(final WebSiteProduct webSiteProduct) {
    return !checkYesValue(webSiteProduct.getApplyOnline());
  }
}
