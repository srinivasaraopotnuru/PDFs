package uk.co.ybs.digital.product.web.controller;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import java.util.UUID;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;
import uk.co.ybs.digital.product.service.OnSaleProductService;
import uk.co.ybs.digital.product.service.ProductDetailsService;
import uk.co.ybs.digital.product.service.ProductReinvestmentService;
import uk.co.ybs.digital.product.validator.PageableSort;
import uk.co.ybs.digital.product.validator.ProductIdentifier;
import uk.co.ybs.digital.product.web.dto.AvailableProductDetails;
import uk.co.ybs.digital.product.web.dto.ProductDetailsPageResponsePrivate;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.reinvestment.ProductReinvestmentResponse;

@RestController
@RequestMapping("/private")
@RequiredArgsConstructor
@Validated
public class ProductControllerPrivate {
  private static final String SCOPE_ACCOUNT_READ_OR_PRODUCT_READ =
      "hasAuthority('SCOPE_ACCOUNT_READ') or hasAuthority('SCOPE_PRODUCT_READ')";

  private final ProductDetailsService productDetailsService;
  private final ProductReinvestmentService productReinvestmentService;
  private final OnSaleProductService onSaleProductService;

  @GetMapping(path = "/product", produces = MediaType.APPLICATION_JSON_VALUE)
  @ApiOperation(value = "Search for products")
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "page",
        dataType = "int",
        paramType = "query",
        defaultValue = "0",
        value = "Results page you want to retrieve (0..N)"),
    @ApiImplicitParam(
        name = "size",
        dataType = "int",
        paramType = "query",
        defaultValue = "20",
        value = "Number of records per page."),
    @ApiImplicitParam(
        name = "sort",
        allowMultiple = true,
        dataType = "string",
        paramType = "query",
        value =
            "Sorting criteria in the format: property(,asc|desc). Multiple sort criteria are supported.",
        allowableValues = "productIdentifier")
  })
  @PreAuthorize(SCOPE_ACCOUNT_READ_OR_PRODUCT_READ)
  public ProductDetailsPageResponsePrivate searchProductDetails(
      @Valid final ProductSearchCriteria searchCriteria,
      @PageableDefault(page = 0, size = 20)
          @ApiIgnore
          @PageableSort(fieldRegexp = "productIdentifier")
          final Pageable pageable) {
    return ProductDetailsPageResponsePrivate.builder()
        .page(productDetailsService.searchProductsPrivate(searchCriteria, pageable))
        .build();
  }

  @ApiOperation(
      value = "Request product rules for a supplied product code",
      response = ProductDetailsResponsePrivate.class)
  @GetMapping(path = "/product/{productIdentifier}", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ_OR_PRODUCT_READ)
  public ProductDetailsResponsePrivate getProductDetails(
      @PathVariable @ProductIdentifier final String productIdentifier) {
    return productDetailsService.getProductDetailsPrivateForIdentifier(productIdentifier);
  }

  @ApiOperation(
      value = "Request eligible reinvestment products for a provided product identifier",
      response = ProductReinvestmentResponse.class)
  @GetMapping(
      path = "/product/{productIdentifier}/reinvestment-products",
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ_OR_PRODUCT_READ)
  public ProductReinvestmentResponse getReinvestmentProducts(
      @PathVariable @ProductIdentifier final String productIdentifier) {
    return productReinvestmentService.getReinvestmentProducts(productIdentifier);
  }

  @ApiOperation(value = "Retrieve on-sale products")
  @GetMapping(path = "/on-sale-products", produces = MediaType.APPLICATION_JSON_VALUE)
  public List<ProductCategory> getOnSaleProducts(
      @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME) final UUID requestId) {
    return onSaleProductService.getProducts(requestId);
  }

  @ApiOperation(value = "Get available products for a customer")
  @PostMapping(
      value = "/available-products",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ_OR_PRODUCT_READ)
  public List<ProductCategory> getAvailableProducts(
      @Validated @RequestBody final AvailableProductDetails availableProductsRequest,
      @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME) final UUID requestId) {

    return productDetailsService.getAvailableProducts(availableProductsRequest, requestId);
  }
}
