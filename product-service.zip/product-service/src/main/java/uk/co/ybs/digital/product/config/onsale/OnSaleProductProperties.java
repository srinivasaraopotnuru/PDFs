package uk.co.ybs.digital.product.config.onsale;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.validation.annotation.Validated;

@ConfigurationProperties(prefix = "uk.co.ybs.digital.product.on-sale-product")
@ConstructorBinding
@AllArgsConstructor
@Getter
@Validated
public class OnSaleProductProperties {
  @NotNull private final String baseUri;
}
