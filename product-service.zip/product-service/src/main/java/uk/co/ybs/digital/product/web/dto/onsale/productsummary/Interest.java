package uk.co.ybs.digital.product.web.dto.onsale.productsummary;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@FieldDefaults(makeFinal = true, level = AccessLevel.PROTECTED)
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Builder
@Setter
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Interest {
  Section section;

  @ApiModelProperty(example = "Account Name")
  String title;

  @ApiModelProperty(example = "This account pays a variable tiered rate of interest annually")
  String summary;

  List<Content> content;

  List<Tiers> tiers;

  List<Help> help;
}
