package uk.co.ybs.digital.product.mapping;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.InterestTier;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.Tier;

@Component
public class InterestTiersMapper {

  public List<Tier> map(final Product product) {
    return product.getInterestTiers().stream()
        .sorted(
            Comparator.comparing(InterestTier::getRangeLow).thenComparing(InterestTier::getSysid))
        .map(
            interestTier ->
                Tier.builder()
                    .rate(interestTier.getInterestRate())
                    .rangeLow(interestTier.getRangeLow())
                    .rangeHigh(interestTier.getRangeHigh())
                    .build())
        .collect(Collectors.toList());
  }
}
