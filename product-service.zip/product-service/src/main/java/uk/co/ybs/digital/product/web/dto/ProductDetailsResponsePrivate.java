package uk.co.ybs.digital.product.web.dto;

import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class ProductDetailsResponsePrivate extends ProductDetailsResponseBase {

  @ApiModelProperty(required = true)
  private Long productSysId;

  @ApiModelProperty(required = true)
  private LocalDateTime startDate;

  private WithdrawalsPrivate withdrawals;

  @ApiModelProperty(required = true)
  private InterestPrivate interest;

  private IsaPrivate isa;

  @ApiModelProperty(required = true)
  private Beneficiaries beneficiaries;

  @Data
  @SuperBuilder
  @EqualsAndHashCode(callSuper = true)
  @ToString(callSuper = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class WithdrawalsPrivate extends Withdrawals {
    private InterestPenalty interestPenalty;
    private boolean permittedOverWebOnAccountClosure;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class InterestPenalty {
      @ApiModelProperty(required = true)
      private Integer code;

      @ApiModelProperty(required = true)
      private Integer days;

      private BigDecimal balanceUpperBound;
    }
  }

  @Data
  @SuperBuilder
  @EqualsAndHashCode(callSuper = true)
  @ToString(callSuper = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class InterestPrivate extends Interest {
    @ApiModelProperty(required = true)
    private String periodEndIndicator;

    private LocalDateTime periodEndDate;

    @ApiModelProperty(required = true)
    private Integer divisorDays;

    private Integer previousPeriodDivisorDays;

    private Boolean webAmendmentsPermitted;
  }

  @Data
  @SuperBuilder
  @EqualsAndHashCode(callSuper = true)
  @ToString(callSuper = true)
  @NoArgsConstructor
  @AllArgsConstructor
  public static class IsaPrivate extends Isa {
    @ApiModelProperty(required = true)
    private Integer isaYear;
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Beneficiaries {
    @ApiModelProperty(required = true)
    private Long external;

    @ApiModelProperty(required = true)
    private Long internal;
  }
}
