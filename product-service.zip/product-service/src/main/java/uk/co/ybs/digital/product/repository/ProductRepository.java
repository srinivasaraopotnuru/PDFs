package uk.co.ybs.digital.product.repository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import javax.persistence.criteria.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;

public interface ProductRepository
    extends JpaRepository<Product, Long>, JpaSpecificationExecutor<Product> {

  @Query(
      "FROM Product prod "
          + "LEFT OUTER JOIN prod.interestTiers tiers "
          + "ON tiers.startDate <= :interestTierActiveDate AND (tiers.endDate IS NULL OR tiers.endDate > :interestTierActiveDate)"
          + "WHERE prod.productIdentifier = :productIdentifier")
  @EntityGraph(attributePaths = "interestTiers")
  Optional<Product> findByProductIdentifier(
      @Param("productIdentifier") String productIdentifier,
      @Param("interestTierActiveDate") LocalDateTime interestTierActiveDate);

  default Page<Product> findAll(
      final ProductSearchCriteria searchCriteria, final Pageable pageable) {

    @SuppressWarnings("serial")
    final Specification<Product> spec =
        (root, query, cb) -> {
          final List<Predicate> predicates = new ArrayList<>();

          final Set<String> productIdentifiers = searchCriteria.getProductIdentifiers();
          if (productIdentifiers != null && productIdentifiers.size() > 0) {
            predicates.add(root.get("productIdentifier").in(productIdentifiers));
          }

          return cb.and(predicates.toArray(new Predicate[0]));
        };

    return findAll(spec, pageable);
  }

  @Query(
      "SELECT prod FROM Product prod "
          + "WHERE EXISTS "
          + "   (SELECT pr.product.sysid FROM ProductRule pr "
          + "     WHERE pr.product.sysid = prod.sysid "
          + "     AND pr.availableProductRule.code = 'WEBRET' AND pr.charValue = 'Y' "
          + "     AND (pr.endDate IS NULL  OR pr.endDate > :dateTime)) "
          + "AND EXISTS "
          + "   (SELECT pr.product.sysid FROM ProductRule pr "
          + "     WHERE pr.product.sysid = prod.sysid "
          + "     AND pr.availableProductRule.code = 'PRDTYP' AND pr.charValue = :productType "
          + "     AND (pr.endDate IS NULL  OR pr.endDate > :dateTime)) "
          + "AND NOT EXISTS "
          + "   (SELECT pr.product.sysid FROM ProductRule pr "
          + "     WHERE pr.product.sysid = prod.sysid "
          + "     AND pr.availableProductRule.code ='STPREC' AND pr.charValue = 'Y' "
          + "     AND (pr.endDate IS NULL  OR pr.endDate > :dateTime)) ")
  List<Product> findReinvestableProducts(
      @Param("productType") String productType, @Param("dateTime") LocalDateTime dateTime);
}
