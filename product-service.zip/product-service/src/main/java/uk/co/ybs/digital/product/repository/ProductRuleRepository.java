package uk.co.ybs.digital.product.repository;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.EntityGraph.EntityGraphType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.model.ProductRule;

public interface ProductRuleRepository extends JpaRepository<ProductRule, Long> {

  @Query(
      "SELECT pr FROM ProductRule pr "
          + "WHERE pr.product IN :products "
          + "AND pr.id.startDate <= :dateTime "
          + "AND (pr.endDate IS NULL OR pr.endDate > :dateTime) "
          + "AND pr.availableProductRule.code IN :ruleCodes")
  @EntityGraph(
      attributePaths = {"availableProductRule"},
      type = EntityGraphType.LOAD)
  List<ProductRule> findByProductAndRuleCodes(
      @Param("products") Collection<Product> products,
      @Param("ruleCodes") Collection<String> ruleCodes,
      @Param("dateTime") LocalDateTime dateTime);
}
