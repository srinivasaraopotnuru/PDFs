package uk.co.ybs.digital.product.web.dto.onsale.productsummary;

import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@FieldDefaults(makeFinal = true, level = AccessLevel.PROTECTED)
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Builder
@Setter
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Account {
  Section section;

  @ApiModelProperty(example = "Account Name")
  String title;

  @ApiModelProperty(example = "Fixed Rate Cash e-ISA until 30 September 2022")
  String name;
}
