package uk.co.ybs.digital.product.mapping.onsale;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;
import static uk.co.ybs.digital.product.service.OnSaleProductService.stringToDecimalNoComma;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;

@Component("onSaleInterestMapper")
@AllArgsConstructor
@Slf4j
public class InterestMapper {

  private static final String FAMILY_SAVINGS_ACCOUNT_NAME_SHORT = "Family eSavings Account";

  private final InterestTierDescriptionMapper descriptionMapper;
  private final InterestRangeMapper rangeMapper;

  private static final String[] ALLOWED_MONTHLY_INTEREST_PRODUCT_SHORT_NAMES = {
    FAMILY_SAVINGS_ACCOUNT_NAME_SHORT
  };

  public List<InterestTier> map(final WebSiteProduct webSiteProduct) {
    final boolean annualInterest = checkYesValue(webSiteProduct.getInterestAnnually());

    if (!annualInterest
        && !Arrays.asList(ALLOWED_MONTHLY_INTEREST_PRODUCT_SHORT_NAMES)
            .contains(webSiteProduct.getAccountNameShort())) {
      log.warn(
          "Cannot map non annual products which are not in "
              + Arrays.toString(ALLOWED_MONTHLY_INTEREST_PRODUCT_SHORT_NAMES));
      return Collections.emptyList();
    }

    final boolean tiered = checkYesValue(webSiteProduct.getTieredProduct());
    final boolean smartTiered = checkYesValue(webSiteProduct.getSmartTiered());
    final boolean taxFree = checkYesValue(webSiteProduct.getTaxFree());
    final String interestType = webSiteProduct.getInterestType();

    if (!tiered && !smartTiered) {
      final int tierIndex = 0;
      final String nextBalance = null;

      return Collections.singletonList(
          InterestTier.builder()
              .description(
                  descriptionMapper.map(
                      taxFree,
                      interestType,
                      tiered,
                      smartTiered,
                      nextBalance,
                      webSiteProduct.getAccountNameShort(),
                      tierIndex,
                      false))
              .range(
                  rangeMapper.map(
                      tiered,
                      smartTiered,
                      webSiteProduct.getMinBalanceT1(),
                      nextBalance,
                      webSiteProduct.getAccountNameShort(),
                      tierIndex))
              .rate(formatRate(stringToDecimalNoComma(webSiteProduct.getAnnualGrossT1())))
              .build());
    }

    final List<ImmutablePair<String, String>> tierBalances =
        getTierBalances(webSiteProduct, annualInterest);

    final List<InterestTier> interestTiers = new ArrayList<>();
    for (int idx = 0; idx < tierBalances.size(); idx++) {
      final ImmutablePair<String, String> currentItem = tierBalances.get(idx);
      final String nextBalance =
          idx + 1 == tierBalances.size() ? null : tierBalances.get(idx + 1).left;

      interestTiers.add(
          InterestTier.builder()
              .description(
                  descriptionMapper.map(
                      taxFree,
                      interestType,
                      tiered,
                      smartTiered,
                      nextBalance,
                      webSiteProduct.getAccountNameShort(),
                      idx,
                      false))
              .range(
                  rangeMapper.map(
                      tiered,
                      smartTiered,
                      currentItem.left,
                      nextBalance,
                      webSiteProduct.getAccountNameShort(),
                      idx))
              .rate(formatRate(currentItem.right))
              .build());

      if (nextBalance == null) {
        break;
      }
    }

    return interestTiers;
  }

  private List<ImmutablePair<String, String>> getTierBalances(
      final WebSiteProduct webSiteProduct, final boolean annualInterest) {

    final List<ImmutablePair<String, String>> tierBalances;

    if (annualInterest) {

      tierBalances =
          Arrays.asList(
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT1(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT1())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT2(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT2())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT3(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT3())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT4(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT4())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT5(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT5())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT6(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT6())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT7(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT7())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT8(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT8())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT9(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT9())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT10(),
                  stringToDecimalNoComma(webSiteProduct.getAnnualGrossT10())));
    } else {
      tierBalances =
          Arrays.asList(
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT1(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT1())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT2(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT2())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT3(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT3())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT4(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT4())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT5(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT5())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT6(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT6())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT7(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT7())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT8(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT8())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT9(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT9())),
              new ImmutablePair<>(
                  webSiteProduct.getMinBalanceT10(),
                  stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT10())));
    }
    return tierBalances;
  }

  private static String formatRate(final String rate) {
    return rate + "%";
  }

  public List<InterestTier> consolidate(
      final WebSiteProduct webSiteProduct, final List<InterestTier> interestTiers) {

    if (interestTiers.size() == 1
        || interestTiers.stream().map(InterestTier::getRate).distinct().count() > 1) {
      return interestTiers;
    }

    final boolean taxFree = checkYesValue(webSiteProduct.getTaxFree());
    final String interestType = webSiteProduct.getInterestType();
    final boolean tiered = checkYesValue(webSiteProduct.getTieredProduct());
    final boolean smartTiered = checkYesValue(webSiteProduct.getSmartTiered());

    return Collections.singletonList(
        InterestTier.builder()
            .description(
                descriptionMapper.map(
                    taxFree,
                    interestType,
                    tiered,
                    smartTiered,
                    null,
                    webSiteProduct.getAccountNameShort(),
                    0,
                    true))
            .range(
                rangeMapper.map(
                    tiered,
                    smartTiered,
                    webSiteProduct.getMinBalanceT1(),
                    null,
                    webSiteProduct.getAccountNameShort(),
                    0))
            .rate(interestTiers.get(0).getRate())
            .build());
  }
}
