package uk.co.ybs.digital.product.web.dto.onsale;

public enum InterestFrequency {
  ANNUAL,
  MONTHLY,
  BIANNUAL
}
