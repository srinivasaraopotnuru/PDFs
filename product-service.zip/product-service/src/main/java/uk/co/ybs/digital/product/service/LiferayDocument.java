package uk.co.ybs.digital.product.service;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class LiferayDocument {

  String contentValue;
}
