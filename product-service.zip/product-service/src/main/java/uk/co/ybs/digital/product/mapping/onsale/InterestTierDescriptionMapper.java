package uk.co.ybs.digital.product.mapping.onsale;

import java.util.Arrays;
import java.util.Locale;
import org.springframework.stereotype.Component;

@Component
public class InterestTierDescriptionMapper {

  private static final String FAMILY_SAVINGS_ACCOUNT_NAME_SHORT = "Family eSavings Account";
  private static final String ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT = "Online Rainy Day Account";

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public String map(
      final boolean taxFree,
      final String interestType,
      final boolean tiered,
      final boolean smartTiered,
      final String nextBalance,
      final String accountShortName,
      final int tierIndex,
      final boolean consolidatedTiers) {

    final StringBuilder str = new StringBuilder(64);

    if (taxFree) {
      str.append("Tax-free p.a./AER ");
    } else {
      str.append("Gross p.a./AER ");
    }

    str.append(interestType.toLowerCase(Locale.ROOT));

    if (consolidatedTiers) {
      str.append(" across all tiers");
    } else if (smartTiered
        && Arrays.asList(FAMILY_SAVINGS_ACCOUNT_NAME_SHORT, ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT)
            .contains(accountShortName)) {
      if (tierIndex == 0) {
        str.append(" on balances up to");
      } else if (nextBalance == null) {
        str.append(" on balances over");
      } else {
        str.append(" on balances of");
      }
    } else if (tiered || smartTiered) {
      str.append(" on balances of");
    }

    return str.toString();
  }
}
