package uk.co.ybs.digital.product.web.dto.onsale;

import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class InterestTier {
  @ApiModelProperty(required = true)
  @NonNull
  String rate;

  @ApiModelProperty(required = true)
  @NonNull
  String description;

  @JsonInclude(JsonInclude.Include.NON_EMPTY)
  String range;
}
