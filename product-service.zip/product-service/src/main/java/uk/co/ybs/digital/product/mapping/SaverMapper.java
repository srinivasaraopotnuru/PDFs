package uk.co.ybs.digital.product.mapping;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Saver;

@Component
@RequiredArgsConstructor
public class SaverMapper {

  public Saver map(final ActiveProductRules productRules) {
    if (!productRules.isSaverProduct()) {
      return null;
    }

    return Saver.builder().regular(getRegularSaver(productRules)).build();
  }

  private Boolean getRegularSaver(final ActiveProductRules productRules) {
    return productRules.getBooleanWithDefault(
            AvailableProductRule.REGULAR_SAVER_MONTHLY_SUBSCRIPTION, false)
        || productRules.getBooleanWithDefault(
            AvailableProductRule.REGULAR_SAVER_SINGLE_DEPOSIT, false);
  }
}
