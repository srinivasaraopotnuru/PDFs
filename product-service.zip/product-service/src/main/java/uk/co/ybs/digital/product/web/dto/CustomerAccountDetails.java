package uk.co.ybs.digital.product.web.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.Positive;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.product.validator.NonEmptyString;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class CustomerAccountDetails {
  @NonNull
  @NonEmptyString(message = "product identifier must contain at least one non-whitespace character")
  @ApiModelProperty(required = true, example = "ERE")
  String productIdentifier;

  @Positive long count;
}
