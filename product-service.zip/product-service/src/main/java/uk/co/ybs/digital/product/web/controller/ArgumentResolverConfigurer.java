package uk.co.ybs.digital.product.web.controller;

import java.util.List;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Component
@SuppressWarnings("PMD.BeanMembersShouldSerialize")
public class ArgumentResolverConfigurer implements WebMvcConfigurer {

  private final ConversionService conversionService;

  public ArgumentResolverConfigurer(@Lazy final ConversionService conversionService) {
    this.conversionService = conversionService;
  }

  @Override
  public void addArgumentResolvers(final List<HandlerMethodArgumentResolver> resolvers) {
    resolvers.add(new ProductSearchCriteriaArgumentResolver(conversionService));
  }
}
