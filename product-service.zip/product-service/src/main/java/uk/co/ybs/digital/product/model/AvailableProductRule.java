package uk.co.ybs.digital.product.model;

import java.util.Arrays;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "AVLBL_SAV_PROD_RULES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class AvailableProductRule {
  public static final String PRODUCT_TYPE = "PRDTYP";
  public static final String OFFSET_ACCOUNT = "OFFSET";
  public static final String PAYMENT_ACCOUNT = "PAYACC";
  public static final String CUSTOMER_DESCRIPTION = "CUSDES";

  public static final String WEB_TRANSACTIONS = "WEBTRN";
  public static final String WEB_WITHDRAWALS = "WEBWDL";
  public static final String WEB_AMENDMENTS = "WEBAMD";

  public static final String BALANCE_MAXIMUM = "MAXBAL";
  public static final String BALANCE_MINIMUM = "MINABL";

  public static final String DEPOSIT_LIMIT_FIRST_MONTH = "MXPYFM";
  public static final String DEPOSIT_LIMIT_MONTH = "MAXPAY";
  public static final String DEPOSIT_LIMIT_YEAR = "MAXDPC";
  public static final String DEPOSIT_LIMIT_ANNIVERSARY_YEAR = "MAXDPA";
  public static final String DEPOSIT_LIMIT_PRODUCT_TERM = "MAXDPP";
  public static final String DEPOSIT_LIMIT_TAX_YEAR_PREFIX = "MXYR";

  public static final String WITHDRAWAL_LIMIT_MONTH = "NOWDLM";
  public static final String WITHDRAWAL_LIMIT_YEAR = "NOWDLC";
  public static final String WITHDRAWAL_LIMIT_ANNIVERSARY_YEAR = "ANNWDL";
  public static final String WITHDRAWAL_LIMIT_TAX_YEAR = "NOWDLI";
  public static final String WITHDRAWAL_LIMIT_PRODUCT_TERM = "NOWDLP";

  public static final String NOTICE_DAYS_FOR_WITHDRAWALS = "WITHDR";

  public static final String WEB_SALE = "WEBSAL";
  public static final String MIN_AGE = "MINAGE";
  public static final String MAX_AGE = "MAXAGE";
  public static final String NI_NUMBER = "NATINS";
  public static final String PRODUCT_SUFFIX = "PRDSFX";
  public static final String ALLOWABLE_INTEREST_INSTR = "ALLWII";
  public static final String STOP_DEPOSITS_EXTERNAL = "STPREC";
  public static final String ALLOW_BANK_TRANSFER_DEPOSITS = "TRNSFR";
  public static final String ALLOW_DIRECT_DEBIT_DEPOSITS = "ALDDIN";
  public static final String ALLOW_BRANCH_TRANSFERS = "BRTRAN";

  public static final String ISA_FLEXIBLE = "ISAFLX";
  public static final String ISA_HELP_TO_BUY = "ISAFTB";

  public static final String EXTERNAL_BENEFICIARIES = "WEBEXD";
  public static final String INTERNAL_BENEFICIARIES = "WEBIND";

  public static final String KYC_COLLECTION = "KYCCOL";

  public static final String MAXIMUM_NUMBER_OF_ACCOUNTS = "MAXNPD";

  public static final String REGULAR_SAVER_SINGLE_DEPOSIT = "REGSAS";

  public static final String REGULAR_SAVER_MONTHLY_SUBSCRIPTION = "REGSAM";

  public static final String WEB_RETENTION = "WEBRET";
  public static final String EXISA = "EXISA";
  public static final String EXBOND = "EXBOND";

  public static final List<String> KNOWN_PRODUCT_RULES =
      Arrays.asList(
          PRODUCT_TYPE,
          OFFSET_ACCOUNT,
          PAYMENT_ACCOUNT,
          CUSTOMER_DESCRIPTION,
          WEB_WITHDRAWALS,
          BALANCE_MAXIMUM,
          BALANCE_MINIMUM,
          DEPOSIT_LIMIT_FIRST_MONTH,
          DEPOSIT_LIMIT_MONTH,
          DEPOSIT_LIMIT_YEAR,
          DEPOSIT_LIMIT_ANNIVERSARY_YEAR,
          DEPOSIT_LIMIT_PRODUCT_TERM,
          WITHDRAWAL_LIMIT_MONTH,
          WITHDRAWAL_LIMIT_YEAR,
          WITHDRAWAL_LIMIT_ANNIVERSARY_YEAR,
          WITHDRAWAL_LIMIT_TAX_YEAR,
          WITHDRAWAL_LIMIT_PRODUCT_TERM,
          NOTICE_DAYS_FOR_WITHDRAWALS,
          WEB_SALE,
          MIN_AGE,
          MAX_AGE,
          NI_NUMBER,
          PRODUCT_SUFFIX,
          ALLOWABLE_INTEREST_INSTR,
          STOP_DEPOSITS_EXTERNAL,
          ALLOW_BANK_TRANSFER_DEPOSITS,
          ALLOW_BRANCH_TRANSFERS,
          WEB_TRANSACTIONS,
          WEB_AMENDMENTS,
          ISA_FLEXIBLE,
          ISA_HELP_TO_BUY,
          ALLOW_DIRECT_DEBIT_DEPOSITS,
          EXTERNAL_BENEFICIARIES,
          INTERNAL_BENEFICIARIES,
          MAXIMUM_NUMBER_OF_ACCOUNTS,
          KYC_COLLECTION,
          REGULAR_SAVER_SINGLE_DEPOSIT,
          REGULAR_SAVER_MONTHLY_SUBSCRIPTION);

  public enum ValueType {
    MONEY,
    NUMBER,
    CHAR,
    DATE
  }

  @Id @EqualsAndHashCode.Include private String code;

  @Enumerated(EnumType.STRING)
  private ValueType valueType;
}
