package uk.co.ybs.digital.product.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.BooleanUtils;

@Entity
@Data
@Table(name = "PRODUCT_RULES")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ProductRule {
  @EmbeddedId @EqualsAndHashCode.Include private ProductRuleId id;

  @ManyToOne
  @JoinColumn(name = "SPRD_SYSID", insertable = false, updatable = false)
  private Product product;

  @ManyToOne
  @JoinColumn(name = "APRULE_CODE", insertable = false, updatable = false)
  private AvailableProductRule availableProductRule;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "DATE_VALUE")
  private LocalDateTime dateValue;

  @Column(name = "CHAR_VALUE")
  private String charValue;

  @Column(name = "MONEY_VALUE")
  private BigDecimal moneyValue;

  @Column(name = "NUMBER_VALUE")
  private Long numberValue;

  public Boolean getBooleanValue() {
    return BooleanUtils.toBooleanObject(getCharValue());
  }

  public static ProductRule.ProductRuleBuilder builder(
      final Product product,
      final AvailableProductRule availableProductRule,
      final LocalDateTime startDate) {
    return builder()
        .id(
            ProductRuleId.builder()
                .apruleCode(availableProductRule.getCode())
                .sprdSysid(product.getSysid())
                .startDate(startDate)
                .build())
        .availableProductRule(availableProductRule)
        .product(product);
  }

  public static ProductRule.ProductRuleBuilder builder() {
    return new ProductRule.ProductRuleBuilder();
  }

  @Embeddable
  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  public static class ProductRuleId implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "APRULE_CODE")
    private String apruleCode;

    @Column(name = "SPRD_SYSID")
    private long sprdSysid;

    @Column(name = "START_DATE")
    private LocalDateTime startDate;
  }
}
