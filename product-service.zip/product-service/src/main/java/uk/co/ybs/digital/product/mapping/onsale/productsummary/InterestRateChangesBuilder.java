package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.InterestRateChanges;

@Component
public class InterestRateChangesBuilder {

  private static final String CURRENT_DATE_FORMAT = "dd/MM/yyyy";
  private static final String NEW_DATE_FORMAT = "dd MMMM yyyy";
  private static final String TERMS_AND_CONDITIONS_LINK =
      "https://www.ybs.co.uk/productdata/YBM0617_Inline_General_TandCs.pdf";

  public InterestRateChanges map(final WebSiteProduct webSiteProduct) throws ParseException {
    final String interestType = webSiteProduct.getInterestType();

    final Content item1;
    final Content item2;

    if ("Variable".equals(interestType)) {
      item1 = Content.builder().format(FormatType.TEXT.getFormat()).text("<bold>Yes<bold>").build();

      item2 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "We can make changes to the interest rate on this account for particular reasons. <link>General Terms and Conditions<link> 7 and 8 set out those reasons. Term 11 tells you how we will notify you of the changes.")
              .link(TERMS_AND_CONDITIONS_LINK)
              .build();

    } else {
      final Date date =
          new SimpleDateFormat(CURRENT_DATE_FORMAT, Locale.ROOT).parse(webSiteProduct.getEndDate());
      final String formattedDate = new SimpleDateFormat(NEW_DATE_FORMAT, Locale.ROOT).format(date);

      item1 = Content.builder().format(FormatType.TEXT.getFormat()).text("<bold>No<bold>").build();

      item2 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(String.format("The interest rate is fixed until %s.", formattedDate))
              .build();
    }

    return InterestRateChanges.builder()
        .section(buildSection("2", true, true))
        .title("Can Yorkshire Building Society change the interest rate?")
        .content(Arrays.asList(item1, item2))
        .build();
  }
}
