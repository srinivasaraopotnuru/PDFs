package uk.co.ybs.digital.product.web.dto.reinvestment;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class ReinvestmentProduct {

  @ApiModelProperty(required = true)
  private String productIdentifier;
}
