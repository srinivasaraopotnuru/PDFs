package uk.co.ybs.digital.product.mapping;

import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
class SupportedPeriodLimits {
  boolean firstMonth;
  boolean month;
  boolean year;
  boolean anniversaryYear;
  boolean taxYear;
  boolean productTerm;
}
