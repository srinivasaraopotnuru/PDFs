package uk.co.ybs.digital.product.exception;

public class LiferayException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public LiferayException(final String message) {
    super(message);
  }

  public LiferayException(final String message, final Throwable ex) {
    super(message, ex);
  }
}
