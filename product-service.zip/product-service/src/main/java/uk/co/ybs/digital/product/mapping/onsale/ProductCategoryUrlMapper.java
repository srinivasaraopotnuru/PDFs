package uk.co.ybs.digital.product.mapping.onsale;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.config.onsale.OnSaleProductProperties;
import uk.co.ybs.digital.product.service.ProductCategoryType;

@Component
@AllArgsConstructor
public class ProductCategoryUrlMapper {

  private final OnSaleProductProperties onSaleProductProperties;

  private static final String EASY_ACCESS = "/easy-access/index.html?display=allWaysToApply";
  private static final String FIXED_BOND = "/fixed-rate-bonds/index.html?display=allWaysToApply";
  private static final String ISA_PREFIX = "/isas/index.html?display=";
  private static final String REGULAR = "/regular-saver/index.html?display=allWaysToApply";
  private static final String CHILDRENS = "/childrens-savings/index.html?display=allWaysToApply";
  private static final String ISA_FIXED_RATE = "fixedRate";
  private static final String ISA_VARIABLE_RATE = "variableRate";

  public String map(final ProductCategoryType productCategoryType) {

    final String baseURI = onSaleProductProperties.getBaseUri();

    switch (productCategoryType) {
      case EASY_ACCESS:
        return baseURI + EASY_ACCESS;
      case FIXED_BOND:
        return baseURI + FIXED_BOND;
      case ISA_FIXED:
        return baseURI + ISA_PREFIX + ISA_FIXED_RATE;
      case ISA_VARIABLE:
        return baseURI + ISA_PREFIX + ISA_VARIABLE_RATE;
      case REGULAR:
        return baseURI + REGULAR;
      case CHILDRENS:
        return baseURI + CHILDRENS;

      default:
        throw new IllegalStateException(
            String.format(
                "No url mapping implemented for category %s", productCategoryType.getTitle()));
    }
  }
}
