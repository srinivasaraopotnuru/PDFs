package uk.co.ybs.digital.product.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "TIERS")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class InterestTier {

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private Long sysid;

  @ManyToOne
  @JoinColumn(name = "SPRD_SYSID", nullable = false)
  @ToString.Exclude
  private Product product;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "INT_RATE", nullable = false)
  private BigDecimal interestRate;

  @Column(name = "RANGE_LOW", nullable = false)
  private BigDecimal rangeLow;

  @Column(name = "RANGE_HIGH", nullable = false)
  private BigDecimal rangeHigh;

  /*
   * Prevent circular toString reference
   */
  @ToString.Include(name = "productSysid")
  public Long getProductSysid() {
    return product.getSysid();
  }
}
