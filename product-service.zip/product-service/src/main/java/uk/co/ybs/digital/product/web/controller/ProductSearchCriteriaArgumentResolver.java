package uk.co.ybs.digital.product.web.controller;

import java.util.Set;
import lombok.AllArgsConstructor;
import org.springframework.core.MethodParameter;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import uk.co.ybs.digital.product.model.ProductSearchCriteria;

@AllArgsConstructor
public class ProductSearchCriteriaArgumentResolver implements HandlerMethodArgumentResolver {
  private final ConversionService conversionService;

  @Override
  public boolean supportsParameter(final MethodParameter parameter) {
    return parameter.getParameterType().equals(ProductSearchCriteria.class);
  }

  @SuppressWarnings("unchecked")
  @Override
  public Object resolveArgument(
      final MethodParameter parameter,
      final ModelAndViewContainer mavContainer,
      final NativeWebRequest webRequest,
      final WebDataBinderFactory binderFactory) {
    return ProductSearchCriteria.builder()
        .productIdentifiers(
            (Set<String>)
                conversionService.convert(
                    webRequest.getParameter("productIdentifiers"),
                    TypeDescriptor.valueOf(String.class),
                    TypeDescriptor.collection(Set.class, TypeDescriptor.valueOf(String.class))))
        .build();
  }
}
