package uk.co.ybs.digital.product.web.dto.onsale;

public enum ProductType {
  ISA,
  BOND,
  EASY_ACCESS,
  CHILDRENS,
  SAVER,
  DEFERRED
}
