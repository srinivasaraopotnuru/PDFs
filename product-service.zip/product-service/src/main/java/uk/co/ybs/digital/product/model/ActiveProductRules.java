package uk.co.ybs.digital.product.model;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode
public class ActiveProductRules {
  private static final Predicate<Long> IS_ZERO = Long.valueOf(0)::equals;
  private static final Predicate<Long> NOT_ZERO = IS_ZERO.negate();

  private final Map<String, ProductRule> productRules;

  public ActiveProductRules(final List<ProductRule> productRules) {
    this.productRules =
        Collections.unmodifiableMap(
            productRules.stream()
                .collect(
                    Collectors.toMap(
                        rule -> rule.getAvailableProductRule().getCode(), Function.identity())));
  }

  public String getStringValue(final String code) {
    return getProductRule(code).map(ProductRule::getCharValue).orElse(null);
  }

  public Boolean getBooleanValue(final String code) {
    return getProductRule(code).map(ProductRule::getBooleanValue).orElse(null);
  }

  public boolean getBooleanWithDefault(final String code, final boolean defaultValue) {
    return getProductRule(code).map(ProductRule::getBooleanValue).orElse(defaultValue);
  }

  public BigDecimal getMoneyValue(final String code) {
    return getProductRule(code).map(ProductRule::getMoneyValue).orElse(null);
  }

  public Long getNonZeroNumberValue(final String code) {
    return getProductRule(code).map(ProductRule::getNumberValue).filter(NOT_ZERO).orElse(null);
  }

  public Long getNumberValueWithDefault(final String code, final Long defaultValue) {
    return getProductRule(code).map(ProductRule::getNumberValue).orElse(defaultValue);
  }

  private Optional<ProductRule> getProductRule(final String code) {
    return Optional.ofNullable(productRules.get(code));
  }

  public Map<String, ProductRule> getProductRules() {
    return productRules;
  }

  public boolean isPaymentProduct() {
    return getBooleanWithDefault(AvailableProductRule.PAYMENT_ACCOUNT, false);
  }

  public boolean isSaverProduct() {
    return Objects.equals(getStringValue(AvailableProductRule.PRODUCT_TYPE), "SAVER");
  }

  public boolean isIsaProduct() {
    return Objects.equals(getStringValue(AvailableProductRule.PRODUCT_TYPE), "ISA");
  }

  public boolean isFBondProduct() {
    return Objects.equals(getStringValue(AvailableProductRule.PRODUCT_TYPE), "FBOND");
  }

  public boolean isSupportedProduct() {
    return isSaverProduct() || isPaymentProduct() || isIsaProduct() || isFBondProduct();
  }
}
