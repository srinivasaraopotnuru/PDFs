package uk.co.ybs.digital.product.web.dto.onsale.productsummary;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum FormatType {
  TEXT("TEXT"),
  BUTTON("BUTTON"),
  LINK("LINK"),
  HEADER("HEADER"),
  LIST("LIST");

  @JsonValue private final String format;
}
