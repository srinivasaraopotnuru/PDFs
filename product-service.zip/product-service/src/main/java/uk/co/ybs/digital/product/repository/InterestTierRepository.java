package uk.co.ybs.digital.product.repository;

import java.time.LocalDateTime;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.product.model.InterestTier;

public interface InterestTierRepository extends JpaRepository<InterestTier, Long> {

  @Query(
      "FROM InterestTier tier "
          + "JOIN FETCH tier.product product "
          + "WHERE product.sysid IN :productSysids "
          + "AND tier.startDate <= :activeDate "
          + "AND (tier.endDate IS NULL OR tier.endDate > :activeDate)")
  Collection<InterestTier> findAllActive(
      @Param("productSysids") Collection<Long> productSysids,
      @Param("activeDate") LocalDateTime activeDate);
}
