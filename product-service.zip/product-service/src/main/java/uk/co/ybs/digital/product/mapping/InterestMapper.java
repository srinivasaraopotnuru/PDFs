package uk.co.ybs.digital.product.mapping;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestDestinationType;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.InterestPrivate;

@Component
@RequiredArgsConstructor
public class InterestMapper {

  private final InterestPaidMapper interestPaidMapper;
  private final PermittedInterestDestinationsMapper permittedInterestDestinationsMapper;
  private final InterestTiersMapper interestTiersMapper;
  private final WebAmendmentsMapper webAmendmentsMapper;

  public Interest map(final Product product, final ActiveProductRules productRules) {
    return Interest.builder()
        .interestPaid(interestPaidMapper.map(product))
        .permittedInterestDestinations(permittedInterestDestinationsMapper.map(productRules))
        .tiers(interestTiersMapper.map(product))
        .build();
  }

  public InterestPrivate mapPrivate(final Product product, final ActiveProductRules productRules) {
    final List<InterestDestinationType> interestDestinationTypes =
        permittedInterestDestinationsMapper.map(productRules);

    return InterestPrivate.builder()
        .interestPaid(interestPaidMapper.map(product))
        .permittedInterestDestinations(interestDestinationTypes)
        .tiers(interestTiersMapper.map(product))
        .periodEndIndicator(product.getPeriodEndIndicator())
        .periodEndDate(product.getPeriodEndDate())
        .divisorDays(product.getDivisorDays())
        .previousPeriodDivisorDays(product.getPreviousDivisorDays())
        .webAmendmentsPermitted(webAmendmentsMapper.map(productRules, interestDestinationTypes))
        .build();
  }
}
