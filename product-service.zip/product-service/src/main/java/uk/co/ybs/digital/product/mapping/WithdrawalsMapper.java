package uk.co.ybs.digital.product.mapping;

import java.time.LocalDateTime;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Withdrawals;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.WithdrawalsPrivate;

@Slf4j
@Component
@RequiredArgsConstructor
public class WithdrawalsMapper {

  @NonNull private final WithdrawalLimitsMapper withdrawalLimitsMapper;
  @NonNull private final WithdrawalsPermittedOverWebMapper withdrawalsPermittedOverWebMapper;
  @NonNull private final WithdrawalsInterestPenaltyMapper withdrawalsInterestPenaltyMapper;

  public Withdrawals map(
      final Product product, final ActiveProductRules productRules, final LocalDateTime now) {
    final Withdrawals.WithdrawalLimits withdrawalLimits =
        withdrawalLimitsMapper.map(productRules).orElse(null);

    return Withdrawals.builder()
        .permittedOverWeb(
            withdrawalsPermittedOverWebMapper.map(product, productRules, withdrawalLimits, now))
        .limits(withdrawalLimits)
        .build();
  }

  public WithdrawalsPrivate mapPrivate(
      final Product product, final ActiveProductRules productRules, final LocalDateTime now) {
    final Withdrawals.WithdrawalLimits withdrawalLimits =
        withdrawalLimitsMapper.map(productRules).orElse(null);

    return WithdrawalsPrivate.builder()
        .interestPenalty(withdrawalsInterestPenaltyMapper.map(product).orElse(null))
        .permittedOverWeb(
            withdrawalsPermittedOverWebMapper.map(product, productRules, withdrawalLimits, now))
        .permittedOverWebOnAccountClosure(
            withdrawalsPermittedOverWebMapper.mapOnAccountClosure(productRules))
        .limits(withdrawalLimits)
        .build();
  }
}
