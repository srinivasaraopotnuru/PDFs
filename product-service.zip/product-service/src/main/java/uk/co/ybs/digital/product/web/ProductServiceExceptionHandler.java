package uk.co.ybs.digital.product.web;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.product.exception.MissingProductRulesException;
import uk.co.ybs.digital.product.exception.NoProductForIdentifierException;
import uk.co.ybs.digital.product.exception.ProductNotSupportedException;
import uk.co.ybs.digital.product.web.dto.ErrorResponse;
import uk.co.ybs.digital.product.web.dto.ErrorResponse.ErrorItem;

@ControllerAdvice
@Slf4j
public class ProductServiceExceptionHandler {

  @ExceptionHandler(RuntimeException.class)
  public ResponseEntity<ErrorResponse> handleUnknownErrors(
      final RuntimeException exception, final WebRequest request) {
    log.error(
        "Unhandled exception thrown. Returning 500 Internal Error. {}",
        exception.getMessage(),
        exception);
    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    final ErrorResponse response =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Internal Server Error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorItem.UNEXPECTED_ERROR)
                    .message("Internal Server Error")
                    .build())
            .build();

    return ResponseEntity.status(status).body(response);
  }

  @ExceptionHandler(AccessDeniedException.class)
  public void handleAccessDeniedException(final AccessDeniedException exception) {
    // Let spring security handle it.
    throw exception;
  }

  @ExceptionHandler(NoProductForIdentifierException.class)
  public ResponseEntity<ErrorResponse> productNotFound(
      final NoProductForIdentifierException exception, final WebRequest request) {
    final HttpStatus status = HttpStatus.NOT_FOUND;
    log.info(
        "Caught unhandled NoProductForIdentifierException, returning status {}.  Message: {}",
        status,
        exception.toString());

    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Resource not found")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.RESOURCE_NOT_FOUND)
                    .message("Resource not found")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(ProductNotSupportedException.class)
  public ResponseEntity<ErrorResponse> productNotSupported(
      final ProductNotSupportedException exception, final WebRequest request) {
    final HttpStatus status = HttpStatus.BAD_REQUEST;
    log.info(
        "Caught unhandled ProductNotSupportedException, returning status {}.  Message: {}",
        status,
        exception.toString());

    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Bad Request")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.FIELD_INVALID)
                    .message("Product type not supported")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(MissingProductRulesException.class)
  public ResponseEntity<ErrorResponse> missingProductRules(
      final MissingProductRulesException exception, final WebRequest request) {
    final HttpStatus status = HttpStatus.CONFLICT;
    log.info(
        "Caught unhandled MissingProductRulesException, returning status {}.  Message: {}",
        status,
        exception.toString());

    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Conflict")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.RULE_MISSING)
                    .message("Required product rule missing")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(ConstraintViolationException.class)
  public ResponseEntity<ErrorResponse> constraintViolated(
      final ConstraintViolationException exception, final WebRequest webrequest) {
    final HttpStatus status = HttpStatus.BAD_REQUEST;

    final List<ErrorItem> errorItems =
        exception.getConstraintViolations().stream()
            .map(
                constraintViolation -> {
                  final String errorCode =
                      constraintViolation.getInvalidValue() == null
                          ? ErrorItem.FIELD_MISSING
                          : ErrorItem.FIELD_INVALID;
                  return ErrorItem.builder()
                      .errorCode(errorCode)
                      .message(constraintViolation.getMessage())
                      .build();
                })
            .collect(Collectors.toList());

    final UUID requestId = RequestIdHelper.getRequestId(webrequest);
    final ErrorResponse response =
        ErrorResponse.builder(status)
            .id(requestId)
            .message("Invalid value")
            .errors(errorItems)
            .build();
    return ResponseEntity.status(status).body(response);
  }
}
