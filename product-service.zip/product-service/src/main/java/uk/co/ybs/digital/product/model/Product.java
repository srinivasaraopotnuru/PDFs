package uk.co.ybs.digital.product.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Singular;

@Entity
@Table(name = "SAVING_PRODUCTS")
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Product {
  public static final String PRIMARY_KEY_ATTRIBUTE_NAME = "sysid";

  @Id
  @Column(name = "SYSID")
  private long sysid;

  @EqualsAndHashCode.Include
  @Column(name = "PRODUCT_IDENTIFIER")
  private String productIdentifier;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Column(name = "DATE_OBSOLETE")
  private LocalDateTime dateObsolete;

  @Column(name = "BRAND_CODE")
  private String brandCode;

  @Column(name = "PENALTY_DAYS", nullable = false)
  private Integer penaltyDays;

  @Column(name = "FATCA_REPORTABLE")
  private String fatcaReportable;

  @Column(name = "CARD_AVLBL")
  private String cardAvailable;

  @Column(name = "CALC_YEAR_DIVISOR", nullable = false)
  private Integer divisorDays;

  @Column(name = "PREV_PEND_DIVISOR")
  private Integer previousDivisorDays;

  @Column(name = "PERIOD_END_DATE")
  private LocalDateTime periodEndDate;

  @Column(name = "PENALTY_CODE", nullable = false)
  private Integer penaltyCode;

  @Column(name = "PENALTY_AMOUNT")
  private BigDecimal penaltyAmount;

  @Column(name = "PERIOD_END_IND", nullable = false)
  private String periodEndIndicator;

  @Column(name = "SMART_TIER_IND")
  @Convert(converter = YesNoOrNullDefaultFalseConverter.class)
  private Boolean smartTiered;

  @OneToMany(mappedBy = "product")
  @Singular
  private Set<InterestTier> interestTiers;

  public boolean isActiveAt(final LocalDateTime candidate) {
    return (endedDate == null || !candidate.isAfter(endedDate))
        && (dateObsolete == null || !candidate.isAfter(dateObsolete));
  }

  public boolean isOpenAt(final LocalDateTime candidate) {
    return isActiveAt(candidate)
        && Optional.ofNullable(startDate).isPresent()
        && (candidate.equals(startDate) || candidate.isAfter(startDate));
  }
}
