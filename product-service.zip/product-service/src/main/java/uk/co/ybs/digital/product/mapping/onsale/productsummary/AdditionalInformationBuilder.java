package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.AdditionalInformation;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;

@Component
public class AdditionalInformationBuilder {

  private static final String ADDRESS =
      "Savings Service, Yorkshire Building Society, Yorkshire House, Bradford, West Yorkshire, BD5 8LJ.";

  public AdditionalInformation map(final WebSiteProduct webSiteProduct) {
    final boolean taxFree = checkYesValue(webSiteProduct.getTaxFree());
    final boolean applyOnline = checkYesValue(webSiteProduct.getApplyOnline());
    final String accountNameFull = webSiteProduct.getAccountNameFull();

    final List<Content> contentList = new ArrayList<>();
    if (taxFree) {

      if ("Help to Buy: ISA".equals(accountNameFull)) {

        contentList.addAll(helpToBuyContent(accountNameFull));
      } else {

        final Content item1 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    "Interest earned from your ISA is tax-free and does not contribute to your Personal Savings Allowance.")
                .build();

        final Content item2 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    "If you fail to invest in your Cash ISA in a single year, under HM Revenue and Customs rules you will be required to complete a declaration form before you can invest further.")
                .build();

        contentList.addAll(Arrays.asList(item1, item2));
      }
    }
    if (applyOnline) {
      contentList.addAll(applyOnlineContent(webSiteProduct));
    }
    return AdditionalInformation.builder()
        .section(buildSection("6", true, true))
        .title("Additional information")
        .content(!contentList.isEmpty() ? contentList : null) // NOPMD
        .build();
  }

  private List<Content> helpToBuyContent(final String accountNameFull) {

    final Content item1 =
        Content.builder()
            .format(FormatType.HEADER.getFormat())
            .text("Conditions for bonus payment")
            .build();

    final Content item2 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("The bonus is paid by the scheme administrators, on behalf of HM Treasury.")
            .build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "When you are ready to buy your new home you will need to close your Help to Buy: ISA rather than simply withdrawing the balance. Closing the account will generate a Closing Letter. This letter will contain all the information that your conveyancer or solicitor dealing with the purchase of your new home will need to claim the bonus on your behalf.")
            .build();

    final Content item4 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("You must operate your account within the scheme rules.")
            .build();

    final Content item5 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("The property you are buying must:")
            .build();

    final Content item6 =
        Content.builder()
            .format(FormatType.LIST.getFormat())
            .list(
                Arrays.asList(
                    "be in the UK and be a residential property",
                    "cost up to £250,000, or up to £450,000 if you are buying in London",
                    "not be a second home or a buy-to-let property",
                    "not be rented out after you buy it",
                    "you must claim your bonus within 12 months of closing your Help to Buy: ISA",
                    String.format(
                        "be purchased with a mortgage. You can choose from a wide range of mortgages that are generally available in the market. If you choose to apply for a mortgage with us, holding a Yorkshire Building Society %s is not a guarantee that you will be approved for a mortgage with us.",
                        accountNameFull)))
            .build();

    final Content item7 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                String.format(
                    "The %s can be re-opened if a house purchase falls through and is evidenced within 12 months of the event occurring. Your conveyancer or solicitor will be able to provide a letter of re-instatement to undertake this.",
                    accountNameFull))
            .build();

    return new ArrayList<>(Arrays.asList(item1, item2, item3, item4, item5, item6, item7));
  }

  private List<Content> applyOnlineContent(final WebSiteProduct webSiteProduct) {
    final ArrayList<Content> contentList = new ArrayList<>();

    if (webSiteProduct.getMaturesIntoProductName() != null
        && !webSiteProduct.getMaturesIntoProductName().isEmpty()) {
      final Content item1 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "We will advise you of the forthcoming product maturity, and generally communicate with you via email. It is very important that you notify us if your email address changes.")
              .build();

      contentList.add(item1);
    } else {
      final Content item2 =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "We will generally communicate with you via email. It is very important that you notify us if your email address changes.")
              .build();

      contentList.add(item2);
    }

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "You can change your contact details (postal address, email and telephone) when you are logged in. To change your name you will need to write, enclosing proof of the change, to "
                    + ADDRESS)
            .build();
    contentList.add(item3);

    return contentList;
  }
}
