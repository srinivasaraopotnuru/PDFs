package uk.co.ybs.digital.product.mapping.onsale;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.config.onsale.OnSaleProductProperties;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.Fact;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;
import uk.co.ybs.digital.product.web.dto.onsale.InterestTier;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;

@Component
@AllArgsConstructor
@Slf4j
public class ProductMapper {

  private static final String ANNUAL_INTEREST_PRODUCT_SUFFIX = "A";
  private static final String MONTHLY_INTEREST_PRODUCT_SUFFIX = "M";

  private static final String ENERGY_SAVING_AWARENESS_EBOND_NAME_SHORT =
      "Energy Saving Awareness Fixed Rate eBond until 31/01/2024";

  @Qualifier("onSaleInterestMapper")
  private final InterestMapper interestMapper;

  private final FactMapper factMapper;
  private final TypeMapper typeMapper;
  private final InterestFrequencyMapper interestFrequencyMapper;

  private final OnSaleProductProperties onSaleProductProperties;
  private final ProductFilter productFilter;

  public Optional<Product> map(final WebSiteProduct webSiteProduct) throws ParseException {
    if (!productFilter.includeProduct(webSiteProduct)) {
      return Optional.empty();
    }
    log.info("Mapping website product {}", webSiteProduct);

    final List<InterestTier> interestTiers = interestMapper.map(webSiteProduct);
    final List<Fact> productFacts = factMapper.map(webSiteProduct, interestTiers);
    final ProductType type = typeMapper.map(webSiteProduct);
    final String productName = getProductName(webSiteProduct);
    final InterestFrequency interestFrequency = interestFrequencyMapper.map(webSiteProduct);

    final String productUrl =
        getProductUrl(onSaleProductProperties.getBaseUri(), webSiteProduct.getProductCode());

    // Tiers are consolidated as a last action as the unconsolidated details are used to generate
    // the facts
    final List<InterestTier> consolidatedTiers =
        interestMapper.consolidate(webSiteProduct, interestTiers);

    return Optional.of(
        Product.builder()
            .facts(productFacts)
            .interestTiers(consolidatedTiers)
            .name(productName)
            .type(type)
            .url(productUrl)
            .productCode(webSiteProduct.getProductCode())
            .minimumAge(webSiteProduct.getMinAgeCustomer())
            .maximumAge(webSiteProduct.getMaxAgeCustomer())
            .maximumNumberOfAccounts(webSiteProduct.getMaxAccountsPerPerson())
            .loyalty(checkYesValue(webSiteProduct.getLoyalty()))
            .interestFrequency(interestFrequency)
            .build());
  }

  private static String getProductName(final WebSiteProduct webSiteProduct) {
    if (ENERGY_SAVING_AWARENESS_EBOND_NAME_SHORT.equals(webSiteProduct.getAccountNameShort())) {
      return webSiteProduct.getAccountNameFull();
    }
    if (checkYesValue(webSiteProduct.getFixedTerm())) {
      return webSiteProduct.getAccountNameShort();
    } else {
      return webSiteProduct.getAccountNameFull();
    }
  }

  private static String getProductUrl(final String baseUri, String productId) {
    final String lastCharacter = productId.substring(productId.length() - 1);

    if (ANNUAL_INTEREST_PRODUCT_SUFFIX.equals(lastCharacter)
        || MONTHLY_INTEREST_PRODUCT_SUFFIX.equals(lastCharacter)) {
      productId = productId.substring(0, productId.length() - 1);
    }

    return String.format("%s/product.html?id=%s", baseUri, productId);
  }
}
