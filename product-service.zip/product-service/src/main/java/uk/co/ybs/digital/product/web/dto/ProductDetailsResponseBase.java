package uk.co.ybs.digital.product.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import uk.co.ybs.digital.product.web.InterestSerializer;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
/*
 * All the BigDecimal datatypes actually become strings to two decimal places because of BigDecimalSerializer, unless
 * overridden explicitly for a given field.
 * eg. 70 --> "70.00"
 */
public class ProductDetailsResponseBase {

  private String productType;

  private Number maximumNumberOfAccounts;

  @ApiModelProperty(required = true)
  private Balance balance;

  private Deposits deposits;

  @ApiModelProperty(required = true)
  private String customerDescription;

  @ApiModelProperty(required = true)
  private String brandCode;

  @ApiModelProperty(required = true)
  private String productIdentifier;

  private boolean cardAvailable;

  @ApiModelProperty(required = true)
  private Boolean smartTiered;

  @ApiModelProperty(required = true)
  private Applications applications;

  private Boolean isKycRequired;

  private Saver saver;

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Balance {
    private BigDecimal min;
    private BigDecimal max;
  }

  @Data
  @SuperBuilder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Withdrawals {
    private boolean permittedOverWeb;
    private WithdrawalLimits limits;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class WithdrawalLimits {
      private PeriodLimits<Long> number;
    }
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Deposits {
    private boolean permittedExternal;
    private boolean permittedInternal;
    private boolean permittedInBranch;
    private boolean permittedByCard;

    private DepositLimits limits;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DepositLimits {
      private PeriodLimits<BigDecimal> amount;
    }
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class PeriodLimits<T> {
    private T firstMonth;
    private T month;
    private T year;
    private T anniversaryYear;
    private T taxYear;
    private T productTerm;
  }

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Applications {
    @ApiModelProperty(required = true)
    private boolean applicationsPermitted;

    @ApiModelProperty(required = true)
    private Long minimumAge;

    @ApiModelProperty(required = true)
    private Long maximumAge;

    @ApiModelProperty(required = true)
    private Long maximumApplicants;

    @ApiModelProperty(required = true)
    private boolean fatcaReportable;

    @ApiModelProperty(required = true)
    private String accountNumberSuffix;

    @ApiModelProperty(required = true)
    private boolean nationalInsuranceNumberRequired;
  }

  @Data
  @SuperBuilder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Interest {
    @ApiModelProperty(required = true)
    private InterestPaidType interestPaid;

    @ApiModelProperty(required = true)
    private List<InterestDestinationType> permittedInterestDestinations;

    @ApiModelProperty(required = true)
    private List<Tier> tiers;

    @SuppressWarnings("PMD.FieldNamingConventions")
    public enum InterestDestinationType {
      selfCredit,
      payAwayExternal,
      payAwayInternal
    }

    public enum InterestPaidType {
      MONTHLY,
      ANNUALLY
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Tier {
      @JsonSerialize(using = InterestSerializer.class)
      private BigDecimal rate;

      private BigDecimal rangeLow;
      private BigDecimal rangeHigh;
    }
  }

  @Data
  @SuperBuilder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Isa {
    @ApiModelProperty(required = true)
    private Boolean flexible;

    private Boolean helpToBuy;
  }

  @Data
  @SuperBuilder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Saver {
    @ApiModelProperty(required = true)
    private Boolean regular;
  }

  @ApiModelProperty(notes = "DEPRECATED - see deposits.limits.amount.month")
  @Deprecated
  public BigDecimal getMaximumMonthlyPayment() {
    return Optional.ofNullable(deposits)
        .map(Deposits::getLimits)
        .map(Deposits.DepositLimits::getAmount)
        .map(PeriodLimits::getMonth)
        .orElse(null);
  }
}
