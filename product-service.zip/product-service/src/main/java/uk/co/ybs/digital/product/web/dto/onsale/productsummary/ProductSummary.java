package uk.co.ybs.digital.product.web.dto.onsale.productsummary;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ProductSummary {
  Account account;
  InterestRateChanges interestRateChanges;
  Apply apply;
  AdditionalInformation additionalInformation;
  Prerequisites prerequisites;
  Interest interest;
  ManageAccount manageAccount;
  Projections projections;
  Withdrawals withdrawals;
}
