package uk.co.ybs.digital.product.mapping;

import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.service.TessaYearCalculator;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Isa;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.IsaPrivate;

@Component
@RequiredArgsConstructor
public class IsaMapper {

  private final TessaYearCalculator tessaYearCalculator;

  public Isa map(final ActiveProductRules productRules) {
    if (!productRules.isIsaProduct()) {
      return null;
    }

    return Isa.builder()
        .flexible(getFlexibleIsa(productRules))
        .helpToBuy(getHelpToBuyIsa(productRules))
        .build();
  }

  public IsaPrivate mapPrivate(final ActiveProductRules productRules, final LocalDateTime now) {
    if (!productRules.isIsaProduct()) {
      return null;
    }

    return IsaPrivate.builder()
        .flexible(getFlexibleIsa(productRules))
        .helpToBuy(getHelpToBuyIsa(productRules))
        .isaYear(tessaYearCalculator.getTessaYear(now))
        .build();
  }

  private Boolean getFlexibleIsa(final ActiveProductRules productRules) {
    return productRules.getBooleanWithDefault(AvailableProductRule.ISA_FLEXIBLE, false);
  }

  private Boolean getHelpToBuyIsa(final ActiveProductRules productRules) {
    return productRules.getBooleanWithDefault(AvailableProductRule.ISA_HELP_TO_BUY, false)
        ? true
        : null;
  }
}
