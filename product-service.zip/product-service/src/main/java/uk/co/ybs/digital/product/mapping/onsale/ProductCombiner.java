package uk.co.ybs.digital.product.mapping.onsale;

import static java.util.stream.Collectors.partitioningBy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;

/*
 * Implements logic similar to that in:
 * https://www.ybs.co.uk/assets/js/YBS_R_Savings_Product_Finder_v2.23.js
 * In particular, see function combineEquivalentProducts.
 *
 * The goal is to combine web and branch products which are similar in to a single entry. These web and branch product
 * pairs will have different identifiers and slightly different names, but otherwise should be basically the same. On
 * the website they display as a single entry, but the apply by web/branch buttons will take the user to the landing
 * page with the appropriate product identifier.
 *
 * The ordering of the JSON is important. As it stands, it would appear that each branch product appears first so that
 * its corresponding web product is squashed in to it. But it is also possible for this to be the other way around. In
 * this case the squashing overrides the web product's name with the branch product name. The end result of this is
 * that the branch product name always takes precedent, regardless of the ordering.
 */
@Component
@Slf4j
public class ProductCombiner {

  private static final String FAMILY_SAVINGS_ACCOUNT_PRODUCT_CODE = "YB931546W";
  private static final String LOYALTY_REGULAR_SAVER_ACCOUNT_PRODUCT_CODE = "YB901552W";
  private static final String LOYALTY_SIX_ACCESS_ESAVER = "YB951617W";
  private static final String ENERGY_SAVING_AWARENESS_EBOND_PRODUCT_CODE = "YB271653W";

  private static final String ONLINE_RAINY_DAY_ISSUE_2_PRODUCT_CODE = "YB931629W";

  private static final String CHRISTMAS_REGULAR_ESAVER_PRODUCT_CODE = "YB901652W";

  private static final String[] OVERRIDE_BRANCH_PRODUCTS_PRODUCT_CODES = {
    LOYALTY_REGULAR_SAVER_ACCOUNT_PRODUCT_CODE,
    FAMILY_SAVINGS_ACCOUNT_PRODUCT_CODE,
    LOYALTY_SIX_ACCESS_ESAVER,
    ONLINE_RAINY_DAY_ISSUE_2_PRODUCT_CODE,
    ENERGY_SAVING_AWARENESS_EBOND_PRODUCT_CODE,
    CHRISTMAS_REGULAR_ESAVER_PRODUCT_CODE
  };

  public List<WebSiteProduct> combineMultiChannel(final List<WebSiteProduct> products) {
    final Map<Boolean, List<WebSiteProduct>> partitioned =
        products.stream()
            .collect(partitioningBy(product -> Strings.isNotEmpty(product.getEquivalentProduct())));

    final List<WebSiteProduct> singleChannel = partitioned.get(Boolean.FALSE);
    final List<WebSiteProduct> multiChannel = partitioned.get(Boolean.TRUE);
    final List<WebSiteProduct> multiChannelCombined = combineFilteredMultiChannel(multiChannel);

    return Stream.concat(singleChannel.stream(), multiChannelCombined.stream())
        .collect(Collectors.toList());
  }

  private List<WebSiteProduct> combineFilteredMultiChannel(
      final List<WebSiteProduct> multiChannel) {
    final Map<String, WebSiteProduct> productByEquivalentCode = new LinkedHashMap<>();
    for (final WebSiteProduct product : multiChannel) {
      final WebSiteProduct firstProduct = productByEquivalentCode.get(product.getProductCode());
      if (firstProduct == null) {
        productByEquivalentCode.put(product.getEquivalentProduct(), product);
      } else {
        final WebSiteProduct combinedProduct = combine(firstProduct, product);
        productByEquivalentCode.put(combinedProduct.getEquivalentProduct(), combinedProduct);
      }
    }
    return new ArrayList<>(productByEquivalentCode.values());
  }

  private WebSiteProduct combine(
      final WebSiteProduct firstProduct, final WebSiteProduct secondProduct) {
    log.info(
        "Combining {} (apply online: {}) into {}",
        secondProduct.getProductCode(),
        secondProduct.getApplyOnline(),
        firstProduct.getProductCode());
    if (Objects.equals(secondProduct.getApplyOnline(), "Yes")) {
      // In theory firstProduct will have been a branch product, so we supplement it with the fact
      // that it is
      // available online, and override the product identifier.
      // This is possible because we only support applying for web products currently. If we allow
      // branch
      // only/branch and web products, we'll need to handle having multiple identifiers for a given
      // product.

      if (Arrays.asList(OVERRIDE_BRANCH_PRODUCTS_PRODUCT_CODES)
          .contains(secondProduct.getProductCode())) {
        return secondProduct;
      }

      return firstProduct
          .toBuilder()
          .applyOnline(secondProduct.getApplyOnline())
          .productCode(secondProduct.getProductCode())
          .build();
    } else {
      // In theory firstProduct will have been a web product, so we override the name with branch
      // products name
      // for consistency (branch names always seems to be favoured).
      // Note we are leaving the product identifier alone, because we are only support web products
      // initially.
      return firstProduct
          .toBuilder()
          .applyInBranch(secondProduct.getApplyInBranch())
          .applyInAgency(secondProduct.getApplyInAgency())
          .applyByPost(secondProduct.getApplyByPost())
          .accountNameFull(secondProduct.getAccountNameFull())
          .accountNameShort(secondProduct.getAccountNameShort())
          .build();
    }
  }
}
