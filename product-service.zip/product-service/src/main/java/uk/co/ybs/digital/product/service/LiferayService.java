package uk.co.ybs.digital.product.service;

import io.micrometer.core.annotation.Timed;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.logging.calls.CallLogged;
import uk.co.ybs.digital.product.exception.LiferayException;
import uk.co.ybs.digital.product.web.dto.ErrorResponse;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "liferay-cms"})
@CallLogged(logParameters = true)
public class LiferayService {

  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling Liferay CMS site";

  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT = "Error calling Liferay CMS: %s";

  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private final WebClient liferayWebClient;

  public LiferayDocument getDocument(final UUID requestId, final String documentId) {
    return liferayWebClient
        .get()
        .uri(
            "/o/headless-delivery/v1.0/documents/"
                + documentId
                + "?nestedFields=contentValue&fields=contentValue")
        .accept(MediaType.APPLICATION_JSON)
        .header(REQUEST_ID_HEADER, requestId.toString())
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .bodyToMono(LiferayDocument.class)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new LiferayException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .block();
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof LiferayException);
  }

  private Mono<LiferayException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new LiferayException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new LiferayException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new LiferayException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
