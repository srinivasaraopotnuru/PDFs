package uk.co.ybs.digital.product.mapping.onsale;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;

@Component
@AllArgsConstructor
public class TypeMapper {

  public ProductType map(final WebSiteProduct webSiteProduct) {
    final boolean cashIsa = checkYesValue(webSiteProduct.getCashISA());
    final boolean flexibleIsa = checkYesValue(webSiteProduct.getFlexibleISA());
    final boolean easyAccess = checkYesValue(webSiteProduct.getEasyAccess());
    final boolean regularSaver = checkYesValue(webSiteProduct.getRegularSaver());
    final boolean childrens = checkYesValue(webSiteProduct.getChildrens());
    final boolean bond = checkYesValue(webSiteProduct.getBond());

    if (cashIsa || flexibleIsa) {
      return ProductType.ISA;
    }
    if (bond) {
      return ProductType.BOND;
    }
    if (regularSaver) {
      return ProductType.SAVER;
    }
    if (easyAccess) {
      return ProductType.EASY_ACCESS;
    }
    if (childrens) {
      return ProductType.CHILDRENS;
    }

    return ProductType.DEFERRED;
  }
}
