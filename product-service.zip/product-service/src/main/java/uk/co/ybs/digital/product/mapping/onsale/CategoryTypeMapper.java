package uk.co.ybs.digital.product.mapping.onsale;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.ProductCategoryType;
import uk.co.ybs.digital.product.service.WebSiteProduct;

@Component
@AllArgsConstructor
public class CategoryTypeMapper {

  private static final String INTEREST_TYPE_VARIABLE = "Variable";
  private static final String INTEREST_TYPE_FIXED = "Fixed";

  public List<ProductCategoryType> map(final WebSiteProduct webSiteProduct) {
    final List<ProductCategoryType> categoryList = new ArrayList<>();

    if (checkYesValue(webSiteProduct.getEasyAccess())) {
      categoryList.add(ProductCategoryType.EASY_ACCESS);
    }
    if (checkYesValue(webSiteProduct.getBond())) {
      categoryList.add(ProductCategoryType.FIXED_BOND);
    }
    if (checkYesValue(webSiteProduct.getCashISA())
        && Objects.equals(webSiteProduct.getInterestType(), INTEREST_TYPE_VARIABLE)) {
      categoryList.add(ProductCategoryType.ISA_VARIABLE);
    }
    if (checkYesValue(webSiteProduct.getCashISA())
        && Objects.equals(webSiteProduct.getInterestType(), INTEREST_TYPE_FIXED)) {
      categoryList.add(ProductCategoryType.ISA_FIXED);
    }
    if (checkYesValue(webSiteProduct.getChildrens())) {
      categoryList.add(ProductCategoryType.CHILDRENS);
    }
    if (checkYesValue(webSiteProduct.getRegularSaver())) {
      categoryList.add(ProductCategoryType.REGULAR);
    }

    return categoryList;
  }
}
