package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Section;

@Component
@SuppressWarnings("PMD.UseUtilityClass")
public class SectionBuilder {

  public static Section buildSection(
      final String icon, final boolean displayIcon, final boolean collapsible) {
    return Section.builder().icon(icon).collapsible(collapsible).displayIcon(displayIcon).build();
  }
}
