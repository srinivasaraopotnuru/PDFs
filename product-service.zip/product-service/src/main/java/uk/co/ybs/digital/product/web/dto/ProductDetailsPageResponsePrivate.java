package uk.co.ybs.digital.product.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import org.springframework.data.domain.Page;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonDeserialize(
    builder = ProductDetailsPageResponsePrivate.ProductDetailsPageResponsePrivateBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ProductDetailsPageResponsePrivate {
  private List<ProductDetailsResponsePrivate> content;
  private int pageSize;
  private int pageNumber;
  private int totalPages;
  private long totalElements;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ProductDetailsPageResponsePrivateBuilder {
    @JsonIgnore
    public ProductDetailsPageResponsePrivateBuilder page(
        final Page<ProductDetailsResponsePrivate> page) {
      return content(page.getContent())
          .pageSize(page.getSize())
          .pageNumber(page.getNumber())
          .totalPages(page.getTotalPages())
          .totalElements(page.getTotalElements());
    }
  }
}
