package uk.co.ybs.digital.product.web.dto;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.product.validator.NonEmptyString;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AvailableProductDetails {
  @NonNull
  @NonEmptyString(message = "Date Of Birth must contain at least one non-whitespace character")
  @ApiModelProperty(required = true, example = "1980-12-12")
  String dateOfBirth;

  @NonNull
  @NonEmptyString(message = "Country code must contain at least one non-whitespace character")
  @ApiModelProperty(required = true, example = "UK")
  String countryCode;

  List<CustomerAccountDetails> accounts;
  List<CustomerAccountDetails> applicationsInProgress;
}
