package uk.co.ybs.digital.product.web.dto.onsale;

public enum WarningCode {
  NON_UK_ADDRESS,
  MAX_NO_OF_ACCOUNTS,
  APPLICANT_AGE,
  INVALID_PARMETERS,
}
