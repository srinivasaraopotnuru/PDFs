package uk.co.ybs.digital.product.service;

import lombok.NonNull;
import lombok.Value;
import lombok.experimental.NonFinal;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.validation.annotation.Validated;

@Value
@NonFinal
@ConstructorBinding
@ConfigurationProperties(prefix = "uk.co.ybs.digital.product")
@Validated
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WebSiteProductIngestServiceProperties {

  @NonNull String onsaleProductListDocumentId;
}
