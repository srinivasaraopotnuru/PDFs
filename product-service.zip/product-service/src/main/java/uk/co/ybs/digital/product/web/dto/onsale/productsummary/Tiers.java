package uk.co.ybs.digital.product.web.dto.onsale.productsummary;

import io.swagger.annotations.ApiModelProperty;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@FieldDefaults(makeFinal = true, level = AccessLevel.PROTECTED)
@AllArgsConstructor
@ToString
@EqualsAndHashCode
@Builder(toBuilder = true)
@Setter
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Tiers {

  @ApiModelProperty(example = "Balances from £100")
  String header;

  @ApiModelProperty(example = "Tax-free p.a. 1%")
  String tax;

  @ApiModelProperty(example = "AER 2%")
  String interest;
}
