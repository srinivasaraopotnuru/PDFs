package uk.co.ybs.digital.product.mapping;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Interest.InterestDestinationType;

@Component
public class PermittedInterestDestinationsMapper {

  public List<InterestDestinationType> map(final ActiveProductRules productRules) {
    final String destinationsRaw =
        productRules.getStringValue(AvailableProductRule.ALLOWABLE_INTEREST_INSTR);

    final List<InterestDestinationType> permittedDestinations = new ArrayList<>();
    if (destinationsRaw != null) {
      if (destinationsRaw.contains("1")) {
        permittedDestinations.add(InterestDestinationType.selfCredit);
      }
      if (destinationsRaw.contains("4")) {
        permittedDestinations.add(InterestDestinationType.payAwayInternal);
      }
      if (destinationsRaw.contains("5")) {
        permittedDestinations.add(InterestDestinationType.payAwayExternal);
      }
    }
    return permittedDestinations;
  }
}
