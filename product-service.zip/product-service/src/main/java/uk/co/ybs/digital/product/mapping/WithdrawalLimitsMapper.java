package uk.co.ybs.digital.product.mapping;

import java.util.Optional;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Withdrawals;

@Component
public class WithdrawalLimitsMapper {

  public Optional<Withdrawals.WithdrawalLimits> map(final ActiveProductRules productRules) {
    final Long month =
        productRules.getNonZeroNumberValue(AvailableProductRule.WITHDRAWAL_LIMIT_MONTH);
    final Long year =
        productRules.getNonZeroNumberValue(AvailableProductRule.WITHDRAWAL_LIMIT_YEAR);
    final Long anniversaryYear =
        productRules.getNonZeroNumberValue(AvailableProductRule.WITHDRAWAL_LIMIT_ANNIVERSARY_YEAR);
    final Long taxYear =
        productRules.getNonZeroNumberValue(AvailableProductRule.WITHDRAWAL_LIMIT_TAX_YEAR);
    final Long productTerm =
        productRules.getNonZeroNumberValue(AvailableProductRule.WITHDRAWAL_LIMIT_PRODUCT_TERM);

    if (ObjectUtils.anyNotNull(month, year, anniversaryYear, taxYear, productTerm)) {
      final PeriodLimits<Long> numberLimits =
          PeriodLimits.<Long>builder()
              .month(month)
              .year(year)
              .anniversaryYear(anniversaryYear)
              .taxYear(taxYear)
              .productTerm(productTerm)
              .build();
      return Optional.of(Withdrawals.WithdrawalLimits.builder().number(numberLimits).build());
    } else {
      return Optional.empty();
    }
  }
}
