package uk.co.ybs.digital.product.mapping;

import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate.Beneficiaries;

@Component
public class BeneficiariesMapper {
  public Beneficiaries mapPrivate(final ActiveProductRules productRules) {
    return Beneficiaries.builder()
        .external(getExternalBeneficiaries(productRules))
        .internal(getInternalBeneficiaries(productRules))
        .build();
  }

  private Long getExternalBeneficiaries(final ActiveProductRules productRules) {
    return productRules.getNumberValueWithDefault(AvailableProductRule.EXTERNAL_BENEFICIARIES, 0L);
  }

  private Long getInternalBeneficiaries(final ActiveProductRules productRules) {
    return productRules.getNumberValueWithDefault(AvailableProductRule.INTERNAL_BENEFICIARIES, 0L);
  }
}
