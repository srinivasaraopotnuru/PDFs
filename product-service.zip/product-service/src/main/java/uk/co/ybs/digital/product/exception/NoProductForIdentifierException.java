package uk.co.ybs.digital.product.exception;

public class NoProductForIdentifierException extends RuntimeException {

  private static final long serialVersionUID = -3044665928632012178L;

  public NoProductForIdentifierException(final String message) {
    super(message);
  }
}
