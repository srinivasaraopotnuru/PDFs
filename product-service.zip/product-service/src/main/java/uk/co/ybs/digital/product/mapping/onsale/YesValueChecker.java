package uk.co.ybs.digital.product.mapping.onsale;

import java.util.Objects;
import lombok.experimental.UtilityClass;

@UtilityClass
public class YesValueChecker {

  public static boolean checkYesValue(final Object value) {
    return Objects.equals(value, "Yes");
  }
}
