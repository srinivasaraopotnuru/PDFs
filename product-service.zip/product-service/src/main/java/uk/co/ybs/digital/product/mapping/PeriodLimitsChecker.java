package uk.co.ybs.digital.product.mapping;

import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase;

@Component
public class PeriodLimitsChecker {

  public boolean isSupported(
      final ProductDetailsResponseBase.PeriodLimits<?> periodLimits,
      final SupportedPeriodLimits supportedPeriodLimits) {
    return (supportedPeriodLimits.isFirstMonth() || periodLimits.getFirstMonth() == null)
        && (supportedPeriodLimits.isMonth() || periodLimits.getMonth() == null)
        && (supportedPeriodLimits.isYear() || periodLimits.getYear() == null)
        && (supportedPeriodLimits.isAnniversaryYear() || periodLimits.getAnniversaryYear() == null)
        && (supportedPeriodLimits.isTaxYear() || periodLimits.getTaxYear() == null)
        && (supportedPeriodLimits.isProductTerm() || periodLimits.getProductTerm() == null);
  }
}
