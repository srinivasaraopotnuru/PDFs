package uk.co.ybs.digital.product.exception;

public class ProductNotSupportedException extends RuntimeException {

  private static final long serialVersionUID = 5859207878191925695L;

  public ProductNotSupportedException(final String message) {
    super(message);
  }
}
