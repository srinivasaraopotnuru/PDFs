package uk.co.ybs.digital.product.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import uk.co.ybs.digital.product.exception.ProductServiceException;
import uk.co.ybs.digital.product.web.dto.AvailableProductDetails;
import uk.co.ybs.digital.product.web.dto.CustomerAccountDetails;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.Warning;
import uk.co.ybs.digital.product.web.dto.onsale.WarningCode;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductFilterService {

  private final OnSaleProductService onSaleProductService;
  private static final String PRODUCT_SUFFIX_WEB = "W";
  private static final String PRODUCT_SUFFIX_ANNUAL_INTEREST = "A";
  private static final String PRODUCT_SUFFIX_MONTHLY_INTEREST = "M";
  private static final String COUNTRY_CODE = "UK";

  public List<ProductCategory> filterProducts(
      @Validated final AvailableProductDetails availableProductsRequest,
      final LocalDateTime now,
      final UUID requestId) {
    final boolean eligibleAddress = COUNTRY_CODE.equals(availableProductsRequest.getCountryCode());

    final int age =
        calculateAge(convertDate(availableProductsRequest.getDateOfBirth()), now.toLocalDate());

    final List<ProductCategory> onSaleProducts = onSaleProductService.getProducts(requestId);
    final List<ProductCategory> filteredProductCategories = new ArrayList<>();

    onSaleProducts.forEach(
        productCategory -> {
          final List<Product> availableProducts = new ArrayList<>();
          final List<Product> unavailableProducts = new ArrayList<>();

          productCategory
              .getProducts()
              .forEach(
                  product -> {
                    final List<Warning> warnings = new ArrayList<>();
                    checkEligibleAddress(eligibleAddress, warnings);
                    checkAgeConstraints(age, product, warnings);
                    checkParmeters(availableProductsRequest, warnings);
                    checkMaxNumberOfAccountsConstraints(
                        availableProductsRequest, product, warnings);
                    if (warnings.isEmpty()) {
                      availableProducts.add(product);
                    } else {

                      unavailableProducts.add(product.toBuilder().warnings(warnings).build());
                    }
                  });

          filteredProductCategories.add(
              productCategory
                  .toBuilder()
                  .products(availableProducts)
                  .unavailableProducts(unavailableProducts)
                  .build());
        });

    return filteredProductCategories;
  }

  private static LocalDate convertDate(final String dateStr) throws ProductServiceException {
    try {
      return LocalDate.parse(dateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    } catch (final Exception e) {
      throw new ProductServiceException(e.getMessage());
    }
  }

  private void checkEligibleAddress(final boolean eligibleAddress, final List<Warning> warnings) {
    if (!eligibleAddress) {
      warnings.add(
          Warning.builder()
              .code(WarningCode.NON_UK_ADDRESS)
              .message("Customer has Non UK Address.")
              .build());
    }
  }

  private void checkAgeConstraints(
      final int age, final Product product, final List<Warning> warnings) {
    if ((product.getMinimumAge() != null && age < product.getMinimumAge())
        || (product.getMaximumAge() != null && age > product.getMaximumAge())) {
      warnings.add(
          Warning.builder()
              .code(WarningCode.APPLICANT_AGE)
              .message("Product age Constraints not met")
              .build());
    }
  }

  private void checkParmeters(
      final AvailableProductDetails availableProductsRequest, final List<Warning> warnings) {

    if (Optional.ofNullable(availableProductsRequest.getAccounts()).isPresent()) {

      for (final CustomerAccountDetails cad : availableProductsRequest.getAccounts()) {
        if (cad.getCount() < 0 || cad.getProductIdentifier().isEmpty()) {

          warnings.add(
              Warning.builder()
                  .code(WarningCode.INVALID_PARMETERS)
                  .message(
                      "Invalid data count or name count "
                          + cad.getCount()
                          + " name "
                          + cad.getProductIdentifier())
                  .build());
        }
      }
    }
  }

  private void checkMaxNumberOfAccountsConstraints(
      final AvailableProductDetails availableProductsRequest,
      final Product product,
      final List<Warning> warnings) {

    // Some product data has null values in this field, so it just assumed that this product is
    // available.
    if (product.getMaximumNumberOfAccounts() == null) {
      return;
    }

    if (Optional.ofNullable(availableProductsRequest.getAccounts()).isPresent()) {
      // this counts the number of i

      final long numOfAccounts =
          availableProductsRequest.getAccounts().stream()
              .filter(
                  cad ->
                      cad.getCount() > 0
                          && cad.getProductIdentifier().equals(getProductCodeIdentifier(product)))
              .mapToLong(CustomerAccountDetails::getCount)
              .sum();
      long numOfApplicationsInProgress = 0;

      if (Optional.ofNullable(availableProductsRequest.getApplicationsInProgress()).isPresent()) {
        numOfApplicationsInProgress =
            availableProductsRequest.getApplicationsInProgress().stream()
                .filter(
                    cad ->
                        cad.getCount() > 0
                            && cad.getProductIdentifier().equals(getProductCodeIdentifier(product)))
                .mapToLong(CustomerAccountDetails::getCount)
                .sum();
      }

      if (numOfAccounts + numOfApplicationsInProgress >= product.getMaximumNumberOfAccounts()) {
        warnings.add(
            Warning.builder()
                .code(WarningCode.MAX_NO_OF_ACCOUNTS)
                .message(
                    "Exceeded maximum number of Accounts. "
                        + numOfAccounts
                        + " open accounts, "
                        + numOfApplicationsInProgress
                        + " applications in progress")
                .build());
      }
    }
  }

  private static String getProductCodeIdentifier(final Product product) {

    final String productIdentifier = product.getProductCode();

    if (productIdentifier.endsWith(PRODUCT_SUFFIX_WEB)) {
      if (product.getInterestFrequency().equals(InterestFrequency.ANNUAL)) {
        return productIdentifier + PRODUCT_SUFFIX_ANNUAL_INTEREST;
      } else if (product.getInterestFrequency().equals(InterestFrequency.MONTHLY)) {
        return productIdentifier + PRODUCT_SUFFIX_MONTHLY_INTEREST;
      }
    }
    return productIdentifier;
  }

  private int calculateAge(final LocalDate birthDate, final LocalDate currentDate) {
    return Period.between(birthDate, currentDate).getYears();
  }
}
