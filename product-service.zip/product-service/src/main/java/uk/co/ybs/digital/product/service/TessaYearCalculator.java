package uk.co.ybs.digital.product.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class TessaYearCalculator {

  private static final LocalDate TESSA_YEAR_1_START = LocalDate.of(1999, Month.APRIL, 6);

  public int getTessaYear(final LocalDateTime now) {
    final LocalDate today = now.toLocalDate();
    final int tessaYearIndex = Period.between(TESSA_YEAR_1_START, today).getYears();
    final int tessaYear = tessaYearIndex + 1;
    log.info("Current date of {} maps to tessaYear {}", today, tessaYear);
    return tessaYear;
  }
}
