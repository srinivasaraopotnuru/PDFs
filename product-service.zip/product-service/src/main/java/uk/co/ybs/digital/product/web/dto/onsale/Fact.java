package uk.co.ybs.digital.product.web.dto.onsale;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Fact.FactBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Fact {
  @ApiModelProperty(required = true)
  @NonNull
  String text;

  @JsonPOJOBuilder(withPrefix = "")
  public static class FactBuilder {}
}
