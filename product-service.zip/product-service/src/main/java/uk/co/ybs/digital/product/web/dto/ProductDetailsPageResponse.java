package uk.co.ybs.digital.product.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import org.springframework.data.domain.Page;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonDeserialize(builder = ProductDetailsPageResponse.ProductDetailsPageResponseBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ProductDetailsPageResponse {
  private List<ProductDetailsResponse> content;
  private int pageSize;
  private int pageNumber;
  private int totalPages;
  private long totalElements;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ProductDetailsPageResponseBuilder {
    @JsonIgnore
    public ProductDetailsPageResponseBuilder page(final Page<ProductDetailsResponse> page) {
      return content(page.getContent())
          .pageSize(page.getSize())
          .pageNumber(page.getNumber())
          .totalPages(page.getTotalPages())
          .totalElements(page.getTotalElements());
    }
  }
}
