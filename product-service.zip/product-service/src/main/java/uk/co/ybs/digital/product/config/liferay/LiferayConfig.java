package uk.co.ybs.digital.product.config.liferay;

import lombok.AllArgsConstructor;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.ExchangeFilterFunctions;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
@EnableConfigurationProperties(LiferayProperties.class)
@AllArgsConstructor
public class LiferayConfig {

  private final LiferayProperties liferayProperties;

  @Bean
  public WebClient liferayWebClient(final WebClient.Builder builder) {
    return builder
        .baseUrl(liferayProperties.getBaseUri())
        .filter(
            ExchangeFilterFunctions.basicAuthentication(
                liferayProperties.getUsername(), liferayProperties.getPassword()))
        .exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(codecs -> codecs.defaultCodecs().maxInMemorySize(-1))
                .build())
        .build();
  }
}
