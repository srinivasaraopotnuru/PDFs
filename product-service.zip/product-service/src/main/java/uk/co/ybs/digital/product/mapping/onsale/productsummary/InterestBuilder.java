package uk.co.ybs.digital.product.mapping.onsale.productsummary;

import static uk.co.ybs.digital.product.mapping.onsale.YesValueChecker.checkYesValue;
import static uk.co.ybs.digital.product.mapping.onsale.productsummary.SectionBuilder.buildSection;
import static uk.co.ybs.digital.product.service.OnSaleProductService.stringToDecimal;
import static uk.co.ybs.digital.product.service.OnSaleProductService.stringToDecimalMinusAPenny;
import static uk.co.ybs.digital.product.service.OnSaleProductService.stringToDecimalNoComma;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Content;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.FormatType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Help;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Interest;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.Tiers;

@Component
public class InterestBuilder {

  private static final String TAX_FREE_INTEREST_TEMPLATE = "<bold>%s%%<bold> Tax-free p.a.";
  private static final String AER_INTEREST_TEMPLATE = "<bold>%s%%<bold> AER";
  private static final String GROSS_INTEREST_TEMPLATE = "<bold>%s%%<bold> Gross p.a.";

  public Interest map(final WebSiteProduct webSiteProduct) {
    final boolean annualInterest = checkYesValue(webSiteProduct.getInterestAnnually());
    final boolean biannualInterest = checkYesValue(webSiteProduct.getInterestBiannually());
    final boolean monthlyInterest = checkYesValue(webSiteProduct.getInterestMonthly());
    final boolean tieredProduct = checkYesValue(webSiteProduct.getTieredProduct());
    final boolean taxFree = checkYesValue(webSiteProduct.getTaxFree());
    final String interestType = webSiteProduct.getInterestType();

    final List<Tiers> tiersList = new ArrayList<>();
    final List<Content> contentList = new ArrayList<>();
    final List<Help> helpList = new ArrayList<>();

    if (annualInterest || biannualInterest) {
      tiersList.addAll(annualTiers(tieredProduct, taxFree, webSiteProduct));
    }
    if (monthlyInterest) {
      tiersList.addAll(monthlyTiers(tieredProduct, taxFree, webSiteProduct));
    }

    if (tieredProduct) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "The rates we offer in the different tiers can vary and sometimes might be the same.")
              .build();
      contentList.add(item);
    }
    final Content item1 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text(
                "Whether you need to pay tax is dependent on your own personal circumstances and so may be subject to change in the future.")
            .build();

    final Content item2 =
        Content.builder().format(FormatType.HEADER.getFormat()).text("Payment of interest").build();

    final Content item3 =
        Content.builder()
            .format(FormatType.TEXT.getFormat())
            .text("Interest is calculated daily on cleared balances")
            .build();

    contentList.addAll(Arrays.asList(item1, item2, item3));

    if (tieredProduct) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "The rate of interest on this account is tiered. You earn one rate of interest based on the tier your balance falls in.")
              .build();
      contentList.add(item);
    }

    contentList.addAll(
        interestContent(annualInterest, monthlyInterest, biannualInterest, webSiteProduct));

    helpList.add(taxFreeHelp(taxFree));

    if (tieredProduct) {
      final Help helpItem =
          Help.builder()
              .header("What does 'Tiered' mean?")
              .text(
                  "Tiered pays interest at different rates as the account balance increases or decreases")
              .section(buildSection("?", true, false))
              .build();
      helpList.add(helpItem);
    }

    final Help helpItem =
        Help.builder()
            .header("What does 'AER' mean?")
            .text(
                "AER stands for the Annual Equivalent Rate and shows you what the interest rate would be if interest was paid and added each year. This will enable you to compare more easily the return you can expect from your savings over time.")
            .section(buildSection("?", true, false))
            .build();
    helpList.add(helpItem);

    helpList.add(fixedAndVariableHelp(interestType));

    return Interest.builder()
        .section(buildSection("1", true, false))
        .title("What is the interest rate?")
        .summary(getSummaryText(biannualInterest, monthlyInterest, interestType))
        .tiers(tiersList)
        .content(contentList)
        .help(helpList)
        .build();
  }

  private String getSummaryText(
      final boolean biannualInterest, final boolean monthlyInterest, final String interestType) {
    return String.format(
        "This account pays a <bold>%s<bold> tiered rate of interest <bold>%s<bold>:",
        interestType.toLowerCase(Locale.ROOT),
        getInterestFrequencyText(biannualInterest, monthlyInterest));
  }

  private String getInterestFrequencyText(
      final boolean biannualInterest, final boolean monthlyInterest) {
    if (biannualInterest) {
      return "biannually";
    } else if (monthlyInterest) {
      return "monthly";
    } else {
      return "annually";
    }
  }

  private Help taxFreeHelp(final boolean taxFree) {
    final Help item;
    if (taxFree) {
      item =
          Help.builder()
              .header("What does 'Tax-free' mean?")
              .text("Tax-free means that Interest is not subject to income tax")
              .section(buildSection("?", true, false))
              .build();
    } else {
      item =
          Help.builder()
              .header("What tax do I pay?")
              .text(
                  "Interest is paid gross i.e. without tax being taken off on all our savings accounts - ISA accounts pay interest tax-free.")
              .section(buildSection("?", true, false))
              .build();
    }
    return item;
  }

  private Help fixedAndVariableHelp(final String interestType) {
    final Help help;
    if ("Variable".equals(interestType)) {
      help =
          Help.builder()
              .header("What does 'Variable' mean?")
              .text(
                  "Variable rate of interest means that the interest rate payable on your account can change and can move both up and down.")
              .section(buildSection("?", true, false))
              .build();
    } else {
      help =
          Help.builder()
              .header("What does 'Fixed Rate' mean?")
              .text(
                  "Fixed rate of interest means that the interest rate payable on your account will remain the same from the time you open your account until the end of the fixed rate period.")
              .section(buildSection("?", true, false))
              .build();
    }
    return help;
  }

  private List<Content> interestContent(
      final boolean annualInterest,
      final boolean monthlyInterest,
      final boolean biannualInterest,
      final WebSiteProduct webSiteProduct) {
    final List<Content> contentList = new ArrayList<>();
    if (annualInterest) {

      final String text;
      if ("Limited Access Saver ISA".equals(webSiteProduct.getAccountNameShort())) {
        text = String.format("It will be paid into the %s", webSiteProduct.getAccountNameShort());
      } else {
        text =
            String.format(
                "It can be paid into the %s account, another Yorkshire Building Society account or another building society or bank account.",
                webSiteProduct.getAccountNameFull());
      }
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  String.format(
                      "Annual interest is paid on %s. %s",
                      webSiteProduct.getInterestDateLong1(), text))
              .build();
      contentList.add(item);
    }
    if (monthlyInterest) {
      final Content item =
          Content.builder()
              .format(FormatType.TEXT.getFormat())
              .text(
                  "Monthly interest is paid on the last day of each month. It must be paid into another Yorkshire Building Society account or another building society or bank account.")
              .build();
      contentList.add(item);
    }
    if (biannualInterest) {
      final Content item5;
      if ("Limited Access Saver ISA".equals(webSiteProduct.getAccountNameShort())) {
        item5 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "It will be paid into the %s", webSiteProduct.getAccountNameShort()))
                .build();
      } else {
        item5 =
            Content.builder()
                .format(FormatType.TEXT.getFormat())
                .text(
                    String.format(
                        "Interest is paid biannually on %s each year. It can be paid into the %s, another Yorkshire Building Society account or another building society or bank account.",
                        webSiteProduct.getInterestDateLong1(), webSiteProduct.getAccountNameFull()))
                .build();
      }
      contentList.add(item5);
    }
    return contentList;
  }

  private List<Tiers> annualTiers(
      final boolean tieredProduct, final boolean taxFree, final WebSiteProduct webSiteProduct) {

    if (tieredProduct) {

      final List<Tiers> tiersList = new ArrayList<>();
      final int tierCount = getMaximumProductTiers(webSiteProduct);

      for (int currentTier = 1; currentTier <= tierCount; currentTier++) {

        final boolean finalTier = currentTier == tierCount;
        final Tiers tierItem;
        if (taxFree) {
          tierItem =
              Tiers.builder()
                  .header(getBalance(currentTier, finalTier, webSiteProduct))
                  .tax(
                      String.format(
                          TAX_FREE_INTEREST_TEMPLATE,
                          stringToDecimalNoComma(getAnnualTax(currentTier, webSiteProduct))))
                  .interest(
                      String.format(
                          AER_INTEREST_TEMPLATE,
                          stringToDecimalNoComma(getAnnualInterest(currentTier, webSiteProduct))))
                  .build();

        } else {
          tierItem =
              Tiers.builder()
                  .header(getBalance(currentTier, finalTier, webSiteProduct))
                  .tax(
                      String.format(
                          GROSS_INTEREST_TEMPLATE,
                          stringToDecimalNoComma(getAnnualTax(currentTier, webSiteProduct))))
                  .interest(
                      String.format(
                          AER_INTEREST_TEMPLATE,
                          stringToDecimalNoComma(getAnnualTax(currentTier, webSiteProduct))))
                  .build();
        }
        tiersList.add(tierItem);
      }
      return tiersList;

    } else {

      final Tiers tierItem;
      if (taxFree) {
        tierItem =
            Tiers.builder()
                .tax(
                    String.format(
                        TAX_FREE_INTEREST_TEMPLATE,
                        stringToDecimalNoComma(webSiteProduct.getAnnualGrossT1())))
                .interest(
                    String.format(
                        AER_INTEREST_TEMPLATE,
                        stringToDecimalNoComma(webSiteProduct.getAnnualAERT1())))
                .build();
      } else {
        tierItem =
            Tiers.builder()
                .tax(
                    String.format(
                        GROSS_INTEREST_TEMPLATE,
                        stringToDecimalNoComma(webSiteProduct.getAnnualGrossT1())))
                .interest(
                    String.format(
                        AER_INTEREST_TEMPLATE,
                        stringToDecimalNoComma(webSiteProduct.getAnnualAERT1())))
                .build();
      }
      return Collections.singletonList(tierItem);
    }
  }

  private List<Tiers> monthlyTiers(
      final boolean tieredProduct, final boolean taxFree, final WebSiteProduct webSiteProduct) {

    if (tieredProduct) {

      final List<Tiers> tiersList = new ArrayList<>();
      final int tierCount = getMaximumProductTiers(webSiteProduct);

      for (int currentTier = 1; currentTier <= tierCount; currentTier++) {
        final boolean finalTier = currentTier == tierCount;

        final Tiers tierItem;
        if (taxFree) {
          tierItem =
              Tiers.builder()
                  .header(getBalance(currentTier, finalTier, webSiteProduct))
                  .tax(
                      String.format(
                          TAX_FREE_INTEREST_TEMPLATE,
                          stringToDecimalNoComma(getMonthlyTax(currentTier, webSiteProduct))))
                  .interest(
                      String.format(
                          AER_INTEREST_TEMPLATE,
                          stringToDecimalNoComma(getMonthlyInterest(currentTier, webSiteProduct))))
                  .build();
        } else {
          tierItem =
              Tiers.builder()
                  .header(getBalance(currentTier, finalTier, webSiteProduct))
                  .tax(
                      String.format(
                          GROSS_INTEREST_TEMPLATE,
                          stringToDecimalNoComma(getMonthlyTax(currentTier, webSiteProduct))))
                  .interest(
                      String.format(
                          AER_INTEREST_TEMPLATE,
                          stringToDecimalNoComma(getMonthlyInterest(currentTier, webSiteProduct))))
                  .build();
        }
        tiersList.add(tierItem);
      }
      return tiersList;

    } else {

      final Tiers tierItem;
      if (taxFree) {
        tierItem =
            Tiers.builder()
                .tax(
                    String.format(
                        TAX_FREE_INTEREST_TEMPLATE,
                        stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT1())))
                .interest(
                    String.format(
                        AER_INTEREST_TEMPLATE,
                        stringToDecimalNoComma(webSiteProduct.getMonthlyAERT1())))
                .build();
      } else {
        tierItem =
            Tiers.builder()
                .tax(
                    String.format(
                        GROSS_INTEREST_TEMPLATE,
                        stringToDecimalNoComma(webSiteProduct.getMonthlyGrossT1())))
                .interest(
                    String.format(
                        AER_INTEREST_TEMPLATE,
                        stringToDecimalNoComma(webSiteProduct.getMonthlyAERT1())))
                .build();
      }
      return Collections.singletonList(tierItem);
    }
  }

  private String getBalance(
      final int currentTier, final boolean lastTier, final WebSiteProduct webSiteProduct) {
    if (lastTier) {
      return String.format(
          "Balances from £%s+", stringToDecimal(getMinBalance(currentTier, webSiteProduct)));
    }
    final String minBalanceForTier = getMinBalance(currentTier, webSiteProduct);
    return String.format(
        "Balances from £%s - £%s",
        stringToDecimal(minBalanceForTier),
        (stringToDecimalMinusAPenny(getMinBalance(currentTier + 1, webSiteProduct))));
  }

  private String getMinBalance(final int tier, final WebSiteProduct webSiteProduct) {

    switch (tier) {
      case 1:
        return webSiteProduct.getMinBalanceT1();
      case 2:
        return webSiteProduct.getMinBalanceT2();
      case 3:
        return webSiteProduct.getMinBalanceT3();
      case 4:
        return webSiteProduct.getMinBalanceT4();
      case 5:
        return webSiteProduct.getMinBalanceT5();
      default:
        return "0";
    }
  }

  private String getAnnualTax(final int tier, final WebSiteProduct webSiteProduct) {

    switch (tier) {
      case 1:
        return webSiteProduct.getAnnualGrossT1();
      case 2:
        return webSiteProduct.getAnnualGrossT2();
      case 3:
        return webSiteProduct.getAnnualGrossT3();
      case 4:
        return webSiteProduct.getAnnualGrossT4();
      case 5:
        return webSiteProduct.getAnnualGrossT5();
      default:
        return "0";
    }
  }

  private String getAnnualInterest(final int tier, final WebSiteProduct webSiteProduct) {

    switch (tier) {
      case 1:
        return webSiteProduct.getAnnualAERT1();
      case 2:
        return webSiteProduct.getAnnualAERT2();
      case 3:
        return webSiteProduct.getAnnualAERT3();
      case 4:
        return webSiteProduct.getAnnualAERT4();
      case 5:
        return webSiteProduct.getAnnualAERT5();
      default:
        return "0";
    }
  }

  private String getMonthlyTax(final int tier, final WebSiteProduct webSiteProduct) {

    switch (tier) {
      case 1:
        return webSiteProduct.getMonthlyGrossT1();
      case 2:
        return webSiteProduct.getMonthlyGrossT2();
      case 3:
        return webSiteProduct.getMonthlyGrossT3();
      case 4:
        return webSiteProduct.getMonthlyGrossT4();
      case 5:
        return webSiteProduct.getMonthlyGrossT5();
      default:
        return "0";
    }
  }

  private String getMonthlyInterest(final int tier, final WebSiteProduct webSiteProduct) {

    switch (tier) {
      case 1:
        return webSiteProduct.getMonthlyAERT1();
      case 2:
        return webSiteProduct.getMonthlyAERT2();
      case 3:
        return webSiteProduct.getMonthlyAERT3();
      case 4:
        return webSiteProduct.getMonthlyAERT4();
      case 5:
        return webSiteProduct.getMonthlyAERT5();
      default:
        return "0";
    }
  }

  private int getMaximumProductTiers(final WebSiteProduct webSiteProduct) {
    int count = 0;
    count += (webSiteProduct.getMinBalanceT1() != null ? 1 : 0);
    count += (webSiteProduct.getMinBalanceT2() != null ? 1 : 0);
    count += (webSiteProduct.getMinBalanceT3() != null ? 1 : 0);
    count += (webSiteProduct.getMinBalanceT4() != null ? 1 : 0);
    count += (webSiteProduct.getMinBalanceT5() != null ? 1 : 0);
    return count;
  }
}
