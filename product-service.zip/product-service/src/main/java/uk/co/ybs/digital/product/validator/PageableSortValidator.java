package uk.co.ybs.digital.product.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;

public class PageableSortValidator implements ConstraintValidator<PageableSort, Pageable> {

  private transient Pattern fieldPattern;

  @Override
  public void initialize(final PageableSort constraintAnnotation) {
    fieldPattern = Pattern.compile(constraintAnnotation.fieldRegexp());
  }

  @Override
  public boolean isValid(final Pageable value, final ConstraintValidatorContext context) {
    if (value == null) {
      return true;
    } else {
      final Sort sort = value.getSort();
      return sort.isUnsorted()
          || sort.stream()
              .map(Order::getProperty)
              .map(fieldPattern::matcher)
              .allMatch(Matcher::matches);
    }
  }
}
