package uk.co.ybs.digital.product.mapping;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Base64;
import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.exception.ProductIngestException;
import uk.co.ybs.digital.product.service.LiferayDocument;
import uk.co.ybs.digital.product.service.WebSiteProduct;

@Component
@AllArgsConstructor
public class WebSiteProductMapper {

  @Autowired private ObjectMapper mapper;

  public List<WebSiteProduct> map(final LiferayDocument liferayDocument) {

    try {
      byte[] decodedBytes = Base64.getDecoder().decode(liferayDocument.getContentValue());

      String decodedString = new String(decodedBytes);

      return mapper.readValue(decodedString, new TypeReference<List<WebSiteProduct>>() {});
    } catch (final Exception ex) {
      throw new ProductIngestException("Unable to deserialize product info", ex);
    }
  }
}
