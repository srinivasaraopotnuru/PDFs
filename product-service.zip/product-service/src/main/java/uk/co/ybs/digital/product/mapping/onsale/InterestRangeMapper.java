package uk.co.ybs.digital.product.mapping.onsale;

import static uk.co.ybs.digital.product.service.OnSaleProductService.stringToDecimal;
import static uk.co.ybs.digital.product.service.OnSaleProductService.stringToDecimalMinusAPenny;

import java.util.Arrays;
import org.springframework.stereotype.Component;

@Component
public class InterestRangeMapper {

  private static final String FAMILY_SAVINGS_ACCOUNT_SHORT_NAME = "Family eSavings Account";
  private static final String ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT = "Online Rainy Day Account";

  public String map(
      final boolean tiered,
      final boolean smartTiered,
      final String minTierValue,
      final String nextTierValue,
      final String accountShortName,
      final int tierIndex) {

    final StringBuilder str = new StringBuilder();

    if ((tiered || smartTiered) && minTierValue != null) {

      if (Arrays.asList(FAMILY_SAVINGS_ACCOUNT_SHORT_NAME, ONLINE_RAINY_DAY_ACCOUNT_NAME_SHORT)
          .contains(accountShortName)) {
        if (tierIndex == 0) {
          str.append(String.format("£%s", stringToDecimalMinusAPenny(nextTierValue)));
        } else if (nextTierValue == null) {
          str.append(String.format("£%s", stringToDecimal(minTierValue)));
        } else {
          str.append(
              String.format(
                  "£%s - £%s",
                  stringToDecimal(minTierValue), stringToDecimalMinusAPenny(nextTierValue)));
        }
      } else {
        if (nextTierValue == null) {
          str.append(String.format("£%s+", stringToDecimal(minTierValue)));
        } else {
          str.append(
              String.format(
                  "£%s - £%s",
                  stringToDecimal(minTierValue), stringToDecimalMinusAPenny(nextTierValue)));
        }
      }
    }
    return str.toString();
  }
}
