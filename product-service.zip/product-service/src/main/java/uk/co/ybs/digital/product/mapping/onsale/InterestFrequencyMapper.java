package uk.co.ybs.digital.product.mapping.onsale;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.exception.ProductNotSupportedException;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.InterestFrequency;

@Component
@AllArgsConstructor
public class InterestFrequencyMapper {

  public InterestFrequency map(final WebSiteProduct webSiteProduct) {

    // Note: Currently there is a product filter in place which only allows products with Annual
    // Interest

    if (YesValueChecker.checkYesValue(webSiteProduct.getInterestAnnually())) {
      return InterestFrequency.ANNUAL;
    }

    if (YesValueChecker.checkYesValue(webSiteProduct.getInterestMonthly())) {
      return InterestFrequency.MONTHLY;
    }

    if (YesValueChecker.checkYesValue(webSiteProduct.getInterestBiannually())) {
      return InterestFrequency.BIANNUAL;
    }

    throw new ProductNotSupportedException(
        "Unable to decode interest frequency for product " + webSiteProduct.getProductCode());
  }
}
