package uk.co.ybs.digital.product.web;

import java.util.UUID;
import lombok.experimental.UtilityClass;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;

@UtilityClass
public class RequestIdHelper {

  public static UUID getRequestId(final WebRequest request) {
    return (UUID)
        request.getAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME, WebRequest.SCOPE_REQUEST);
  }
}
