package uk.co.ybs.digital.product.mapping;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.model.Product;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponse;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponsePrivate;

@AllArgsConstructor
@Component
public class ProductDetailsResponseMapper {

  @NonNull private final WithdrawalsMapper withdrawalsMapper;
  @NonNull private final DepositsMapper depositsMapper;
  @NonNull private final BalanceMapper balanceMapper;
  @NonNull private final ApplicationsMapper applicationsMapper;
  @NonNull private final InterestMapper interestMapper;
  @NonNull private final IsaMapper isaMapper;
  @NonNull private final SaverMapper saverMapper;
  @NonNull private final BeneficiariesMapper beneficiariesMapper;

  public ProductDetailsResponse map(
      final Product product, final ActiveProductRules productRules, final LocalDateTime now) {
    final ProductDetailsResponse.ProductDetailsResponseBuilder<?, ?> builder =
        ProductDetailsResponse.builder();
    map(product, productRules, now, builder);
    return builder
        .withdrawals(withdrawalsMapper.map(product, productRules, now))
        .interest(interestMapper.map(product, productRules))
        .isa(isaMapper.map(productRules))
        .saver(saverMapper.map(productRules))
        .build();
  }

  public ProductDetailsResponsePrivate mapPrivate(
      final Product product, final ActiveProductRules productRules, final LocalDateTime now) {
    final ProductDetailsResponsePrivate.ProductDetailsResponsePrivateBuilder<?, ?> builder =
        ProductDetailsResponsePrivate.builder();
    map(product, productRules, now, builder);
    return builder
        .productSysId(product.getSysid())
        .startDate(product.getStartDate())
        .withdrawals(withdrawalsMapper.mapPrivate(product, productRules, now))
        .interest(interestMapper.mapPrivate(product, productRules))
        .isa(isaMapper.mapPrivate(productRules, now))
        .saver(saverMapper.map(productRules))
        .beneficiaries(beneficiariesMapper.mapPrivate(productRules))
        .build();
  }

  private void map(
      final Product product,
      final ActiveProductRules productRules,
      final LocalDateTime now,
      final ProductDetailsResponseBase.ProductDetailsResponseBaseBuilder<?, ?> builder) {
    builder
        .brandCode(product.getBrandCode())
        .productIdentifier(product.getProductIdentifier())
        .cardAvailable(BooleanUtils.toBoolean(product.getCardAvailable()))
        .productType(productRules.getStringValue(AvailableProductRule.PRODUCT_TYPE))
        .maximumNumberOfAccounts(
            productRules.getNonZeroNumberValue(AvailableProductRule.MAXIMUM_NUMBER_OF_ACCOUNTS))
        .customerDescription(productRules.getStringValue(AvailableProductRule.CUSTOMER_DESCRIPTION))
        .deposits(depositsMapper.map(product, productRules, now))
        .smartTiered(product.getSmartTiered())
        .isKycRequired(productRules.getBooleanValue(AvailableProductRule.KYC_COLLECTION))
        .applications(applicationsMapper.map(product, productRules, now));

    balanceMapper.map(productRules).ifPresent(builder::balance);
  }
}
