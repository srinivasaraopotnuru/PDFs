package uk.co.ybs.digital.product.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.product.exception.NoProductForIdentifierException;
import uk.co.ybs.digital.product.exception.ProductNotSupportedException;
import uk.co.ybs.digital.product.mapping.onsale.ProductResponseMapper;
import uk.co.ybs.digital.product.mapping.onsale.TypeMapper;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.AccountBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.AdditionalInformationBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.ApplyBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.InterestBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.InterestRateChangesBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.ManageAccountBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.PrerequisitesBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.ProjectionsBuilder;
import uk.co.ybs.digital.product.mapping.onsale.productsummary.WithdrawalsBuilder;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;
import uk.co.ybs.digital.product.web.dto.onsale.ProductType;
import uk.co.ybs.digital.product.web.dto.onsale.productsummary.ProductSummary;

@Service
@RequiredArgsConstructor
@Slf4j
public class OnSaleProductService {

  private final WebSiteProductIngestService webSiteProductIngestService;

  private final ProductResponseMapper productResponseMapper;
  private final TypeMapper typeMapper;
  private final AccountBuilder accountBuilder;
  private final InterestRateChangesBuilder interestRateChangesBuilder;
  private final ApplyBuilder applyBuilder;
  private final AdditionalInformationBuilder additionalInformationBuilder;
  private final PrerequisitesBuilder prerequisitesBuilder;
  private final InterestBuilder interestBuilder;
  private final ManageAccountBuilder manageAccountBuilder;
  private final ProjectionsBuilder projectionsBuilder;
  private final WithdrawalsBuilder withdrawalsBuilder;

  private static final String CURRENT_DATE_FORMAT = "dd/MM/yyyy";
  private static final String NEW_DATE_FORMAT = "dd MMMM yyyy";

  @Cacheable(value = "on-sale-products", key = "'default'")
  public List<ProductCategory> getProducts(final UUID requestId) {
    return productResponseMapper.map(webSiteProductIngestService.get(requestId));
  }

  @Scheduled(fixedRateString = "PT1H")
  @CacheEvict(value = "on-sale-products", key = "'default'")
  public void clearCache() {}

  public ProductSummary getProductSummary(final String productIdentifier, final UUID requestId)
      throws ParseException {
    final List<WebSiteProduct> webSiteProducts = webSiteProductIngestService.get(requestId);
    final WebSiteProduct webSiteProduct =
        webSiteProducts.stream()
            .filter(p -> p != null && p.getProductID().equals(productIdentifier))
            .findFirst()
            .orElseThrow(
                () ->
                    new NoProductForIdentifierException(
                        String.format("No product found for identifier: %s", productIdentifier)));

    final String productId = webSiteProduct.getProductID();

    final ProductType productType = typeMapper.map(webSiteProduct);
    if (!(productType.equals(ProductType.ISA)) && !(productType.equals(ProductType.EASY_ACCESS))) {
      throw new ProductNotSupportedException(
          String.format("Product %s has unsupported type %s", productId, productType));
    }
    log.info("Mapping website product: {}, {}", productType, productId);
    return ProductSummary.builder()
        .account(accountBuilder.map(webSiteProduct))
        .interestRateChanges(interestRateChangesBuilder.map(webSiteProduct))
        .projections(projectionsBuilder.map(webSiteProduct))
        .prerequisites(prerequisitesBuilder.map(webSiteProduct))
        .interest(interestBuilder.map(webSiteProduct))
        .manageAccount(manageAccountBuilder.map(webSiteProduct))
        .withdrawals(withdrawalsBuilder.map(webSiteProduct))
        .additionalInformation(additionalInformationBuilder.map(webSiteProduct))
        .apply(applyBuilder.map())
        .build();
  }

  public static String stringToDecimal(final String value) {
    final BigDecimal result = new BigDecimal(value).setScale(2, RoundingMode.UNNECESSARY);
    return String.format("%,.2f", result);
  }

  public static String stringToDecimalNoComma(final String value) {
    if (value != null) {
      final BigDecimal result = new BigDecimal(value).setScale(2, RoundingMode.UNNECESSARY);
      return String.format("%.2f", result);
    }
    return null;
  }

  public static String stringToDecimalMinusAPenny(final String value) {
    BigDecimal result = new BigDecimal(value).setScale(2, RoundingMode.UNNECESSARY);
    result = result.subtract(new BigDecimal("0.01"));
    return String.format("%,.2f", result);
  }

  public static String formatAsMoney(final int value) {
    return String.format("%,d", value);
  }

  public static String formatAsMoney(final String value) {
    return String.format("%,d", value);
  }

  public static String formatAsMoney(final BigDecimal value) {
    return String.format("%,.2f", value.setScale(2, RoundingMode.CEILING));
  }

  public static String formatAsLongDate(final String value) throws ParseException {

    final Date date = new SimpleDateFormat(CURRENT_DATE_FORMAT, Locale.ROOT).parse(value);

    return new SimpleDateFormat(NEW_DATE_FORMAT, Locale.ROOT).format(date);
  }
}
