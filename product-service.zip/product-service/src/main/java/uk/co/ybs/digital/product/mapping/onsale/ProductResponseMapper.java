package uk.co.ybs.digital.product.mapping.onsale;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;

import java.text.ParseException;
import java.util.AbstractMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.service.ProductCategoryType;
import uk.co.ybs.digital.product.service.WebSiteProduct;
import uk.co.ybs.digital.product.web.dto.onsale.Product;
import uk.co.ybs.digital.product.web.dto.onsale.ProductCategory;

@Component
@AllArgsConstructor
public class ProductResponseMapper {

  private final ProductCombiner productCombiner;
  private final CategoryTypeMapper categoryMapper;
  private final ProductMapper productMapper;
  private final ProductCategoryMapper productCategoryMapper;

  public List<ProductCategory> map(final List<WebSiteProduct> webSiteProducts) {
    final List<WebSiteProduct> combinedWebSiteProducts =
        productCombiner.combineMultiChannel(webSiteProducts);
    final Map<ProductCategoryType, List<WebSiteProduct>> webSiteProductsByType =
        combinedWebSiteProducts.stream()
            .filter(webSiteProduct -> Objects.equals(webSiteProduct.getBrand(), "YBS"))
            .flatMap(
                webSiteProduct -> {
                  final List<ProductCategoryType> productCategoryTypes =
                      categoryMapper.map(webSiteProduct);
                  return productCategoryTypes.stream()
                      .map(
                          productCategoryType ->
                              new AbstractMap.SimpleEntry<>(productCategoryType, webSiteProduct));
                })
            .collect(groupingBy(Map.Entry::getKey, mapping(Map.Entry::getValue, toList())));

    return webSiteProductsByType.entrySet().stream()
        .sorted(Map.Entry.comparingByKey())
        .map(
            entry -> {
              final List<Product> products =
                  entry.getValue().stream()
                      .map(
                          websiteProduct -> {
                            try {
                              return productMapper.map(websiteProduct);
                            } catch (final ParseException e) {
                              throw new RuntimeException("Error parsing date " + e.getMessage());
                            }
                          })
                      .filter(Optional::isPresent)
                      .map(Optional::get)
                      .collect(toList());

              return productCategoryMapper.map(entry.getKey(), products, entry.getValue());
            })
        .collect(toList());
  }
}
