package uk.co.ybs.digital.product.mapping;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.product.model.ActiveProductRules;
import uk.co.ybs.digital.product.model.AvailableProductRule;
import uk.co.ybs.digital.product.service.TessaYearCalculator;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.Deposits;
import uk.co.ybs.digital.product.web.dto.ProductDetailsResponseBase.PeriodLimits;

@Component
@RequiredArgsConstructor
public class DepositLimitsMapper {

  private final TessaYearCalculator tessaYearCalculator;

  public Optional<Deposits.DepositLimits> map(
      final ActiveProductRules productRules, final LocalDateTime now) {
    final BigDecimal firstMonth =
        productRules.getMoneyValue(AvailableProductRule.DEPOSIT_LIMIT_FIRST_MONTH);
    final BigDecimal month = productRules.getMoneyValue(AvailableProductRule.DEPOSIT_LIMIT_MONTH);
    final BigDecimal year = productRules.getMoneyValue(AvailableProductRule.DEPOSIT_LIMIT_YEAR);
    final BigDecimal anniversaryYear =
        productRules.getMoneyValue(AvailableProductRule.DEPOSIT_LIMIT_ANNIVERSARY_YEAR);
    final BigDecimal taxYear =
        productRules.getMoneyValue(
            AvailableProductRule.DEPOSIT_LIMIT_TAX_YEAR_PREFIX
                + tessaYearCalculator.getTessaYear(now));
    final BigDecimal productTerm =
        productRules.getMoneyValue(AvailableProductRule.DEPOSIT_LIMIT_PRODUCT_TERM);

    if (ObjectUtils.anyNotNull(firstMonth, month, year, anniversaryYear, taxYear, productTerm)) {
      final PeriodLimits<BigDecimal> amountLimits =
          PeriodLimits.<BigDecimal>builder()
              .firstMonth(firstMonth)
              .month(month)
              .year(year)
              .anniversaryYear(anniversaryYear)
              .taxYear(taxYear)
              .productTerm(productTerm)
              .build();
      return Optional.of((Deposits.DepositLimits.builder().amount(amountLimits).build()));
    } else {
      return Optional.empty();
    }
  }
}
