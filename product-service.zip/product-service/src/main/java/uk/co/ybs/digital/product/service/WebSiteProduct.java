package uk.co.ybs.digital.product.service;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.math.BigDecimal;
import java.util.function.Consumer;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = WebSiteProduct.WebSiteProductBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WebSiteProduct {

  @JsonProperty("Brand")
  String brand;

  @JsonProperty("Account Name Full")
  String accountNameFull;

  @JsonProperty("New Product")
  String newProduct;

  @JsonProperty("Account Name Short")
  String accountNameShort;

  @JsonProperty("Product ID")
  String productID;

  @JsonProperty("Product Code")
  String productCode;

  @JsonProperty("Equivalent Product")
  String equivalentProduct;

  @JsonProperty("Effective Date")
  String effectiveDate;

  @JsonProperty("End Date")
  String endDate;

  @JsonProperty("Monthly Limit")
  Integer monthlyLimit;

  @JsonProperty("First Month Limit")
  String firstMonthLimit;

  @JsonProperty("Regular Saver Term")
  String regularSaverTerm;

  @JsonProperty("Max Amount Eligible For Bonus")
  String maxAmountEligibleForBonus;

  @JsonProperty("Max Balance")
  Integer maxBalance;

  @JsonProperty("Min Opening Balance")
  Integer minOpeningBalance;

  @JsonProperty("Max Opening Balance")
  Integer maxOpeningBalance;

  @JsonProperty("Introductory Bonus Rate")
  String introductoryBonusRate;

  @JsonProperty("Introductory Bonus Period")
  String introductoryBonusPeriod;

  @JsonProperty("Interest Type")
  String interestType;

  @JsonProperty("Interest Annually")
  String interestAnnually;

  @JsonProperty("Interest Biannually")
  String interestBiannually;

  @JsonProperty("Interest Monthly")
  String interestMonthly;

  @JsonProperty("Annual Gross T1")
  String annualGrossT1;

  @JsonProperty("Annual AER T1")
  String annualAERT1;

  @JsonProperty("Monthly Gross T1")
  String monthlyGrossT1;

  @JsonProperty("Monthly AER T1")
  String monthlyAERT1;

  @JsonProperty("Min Balance T1")
  String minBalanceT1;

  @JsonProperty("Tiered Product")
  String tieredProduct;

  @JsonProperty("Annual Gross T2")
  String annualGrossT2;

  @JsonProperty("Annual AER T2")
  String annualAERT2;

  @JsonProperty("Monthly Gross T2")
  String monthlyGrossT2;

  @JsonProperty("Monthly AER T2")
  String monthlyAERT2;

  @JsonProperty("Min Balance T2")
  String minBalanceT2;

  @JsonProperty("Annual Gross T3")
  String annualGrossT3;

  @JsonProperty("Annual AER T3")
  String annualAERT3;

  @JsonProperty("Monthly Gross T3")
  String monthlyGrossT3;

  @JsonProperty("Monthly AER T3")
  String monthlyAERT3;

  @JsonProperty("Min Balance T3")
  String minBalanceT3;

  @JsonProperty("Annual Gross T4")
  String annualGrossT4;

  @JsonProperty("Annual AER T4")
  String annualAERT4;

  @JsonProperty("Monthly Gross T4")
  String monthlyGrossT4;

  @JsonProperty("Monthly AER T4")
  String monthlyAERT4;

  @JsonProperty("Min Balance T4")
  String minBalanceT4;

  @JsonProperty("Annual Gross T5")
  String annualGrossT5;

  @JsonProperty("Annual AER T5")
  String annualAERT5;

  @JsonProperty("Monthly Gross T5")
  String monthlyGrossT5;

  @JsonProperty("Monthly AER T5")
  String monthlyAERT5;

  @JsonProperty("Min Balance T5")
  String minBalanceT5;

  @JsonProperty("Annual Gross T6")
  String annualGrossT6;

  @JsonProperty("Annual AER T6")
  String annualAERT6;

  @JsonProperty("Monthly Gross T6")
  String monthlyGrossT6;

  @JsonProperty("Monthly AER T6")
  String monthlyAERT6;

  @JsonProperty("Min Balance T6")
  String minBalanceT6;

  @JsonProperty("Annual Gross T7")
  String annualGrossT7;

  @JsonProperty("Annual AER T7")
  String annualAERT7;

  @JsonProperty("Monthly Gross T7")
  String monthlyGrossT7;

  @JsonProperty("Monthly AER T7")
  String monthlyAERT7;

  @JsonProperty("Min Balance T7")
  String minBalanceT7;

  @JsonProperty("Annual Gross T8")
  String annualGrossT8;

  @JsonProperty("Annual AER T8")
  String annualAERT8;

  @JsonProperty("Monthly Gross T8")
  String monthlyGrossT8;

  @JsonProperty("Monthly AER T8")
  String monthlyAERT8;

  @JsonProperty("Min Balance T8")
  String minBalanceT8;

  @JsonProperty("Annual Gross T9")
  String annualGrossT9;

  @JsonProperty("Annual AER T9")
  String annualAERT9;

  @JsonProperty("Monthly Gross T9")
  String monthlyGrossT9;

  @JsonProperty("Monthly AER T9")
  String monthlyAERT9;

  @JsonProperty("Min Balance T9")
  String minBalanceT9;

  @JsonProperty("Annual Gross T10")
  String annualGrossT10;

  @JsonProperty("Annual AER T10")
  String annualAERT10;

  @JsonProperty("Monthly Gross T10")
  String monthlyGrossT10;

  @JsonProperty("Monthly AER T10")
  String monthlyAERT10;

  @JsonProperty("Min Balance T10")
  String minBalanceT10;

  @JsonProperty("Previous Rate")
  String previousRate;

  @JsonProperty("Annual Gross T1 Previous")
  String annualGrossT1Previous;

  @JsonProperty("Annual AER T1 Previous")
  String annualAERT1Previous;

  @JsonProperty("Monthly Gross T1 Previous")
  String monthlyGrossT1Previous;

  @JsonProperty("Monthly AER T1 Previous")
  String monthlyAERT1Previous;

  @JsonProperty("Annual Gross T2 Previous")
  String annualGrossT2Previous;

  @JsonProperty("Annual AER T2 Previous")
  String annualAERT2Previous;

  @JsonProperty("Monthly Gross T2 Previous")
  String monthlyGrossT2Previous;

  @JsonProperty("Monthly AER T2 Previous")
  String monthlyAERT2Previous;

  @JsonProperty("Annual Gross T3 Previous")
  String annualGrossT3Previous;

  @JsonProperty("Annual AER T3 Previous")
  String annualAERT3Previous;

  @JsonProperty("Monthly Gross T3 Previous")
  String monthlyGrossT3Previous;

  @JsonProperty("Monthly AER T3 Previous")
  String monthlyAERT3Previous;

  @JsonProperty("Annual Gross T4 Previous")
  String annualGrossT4Previous;

  @JsonProperty("Annual AER T4 Previous")
  String annualAERT4Previous;

  @JsonProperty("Monthly Gross T4 Previous")
  String monthlyGrossT4Previous;

  @JsonProperty("Monthly AER T4 Previous")
  String monthlyAERT4Previous;

  @JsonProperty("Annual Gross T5 Previous")
  String annualGrossT5Previous;

  @JsonProperty("Annual AER T5 Previous")
  String annualAERT5Previous;

  @JsonProperty("Monthly Gross T5 Previous")
  String monthlyGrossT5Previous;

  @JsonProperty("Monthly AER T5 Previous")
  String monthlyAERT5Previous;

  @JsonProperty("Annual Gross T6 Previous")
  String annualGrossT6Previous;

  @JsonProperty("Annual AER T6 Previous")
  String annualAERT6Previous;

  @JsonProperty("Monthly Gross T6 Previous")
  String monthlyGrossT6Previous;

  @JsonProperty("Monthly AER T6 Previous")
  String monthlyAERT6Previous;

  @JsonProperty("Annual Gross T7 Previous")
  String annualGrossT7Previous;

  @JsonProperty("Annual AER T7 Previous")
  String annualAERT7Previous;

  @JsonProperty("Monthly Gross T7 Previous")
  String monthlyGrossT7Previous;

  @JsonProperty("Monthly AER T7 Previous")
  String monthlyAERT7Previous;

  @JsonProperty("Annual Gross T8 Previous")
  String annualGrossT8Previous;

  @JsonProperty("Annual AER T8 Previous")
  String annualAERT8Previous;

  @JsonProperty("Monthly Gross T8 Previous")
  String monthlyGrossT8Previous;

  @JsonProperty("Monthly AER T8 Previous")
  String monthlyAERT8Previous;

  @JsonProperty("Annual Gross T9 Previous")
  String annualGrossT9Previous;

  @JsonProperty("Annual AER T9 Previous")
  String annualAERT9Previous;

  @JsonProperty("Monthly Gross T9 Previous")
  String monthlyGrossT9Previous;

  @JsonProperty("Monthly AER T9 Previous")
  String monthlyAERT9Previous;

  @JsonProperty("Annual Gross T10 Previous")
  String annualGrossT10Previous;

  @JsonProperty("Annual AER T10 Previous")
  String annualAERT10Previous;

  @JsonProperty("Monthly Gross T10 Previous")
  String monthlyGrossT10Previous;

  @JsonProperty("Monthly AER T10 Previous")
  String monthlyAERT10Previous;

  @JsonProperty("Effective Date Previous")
  String effectiveDatePrevious;

  @JsonProperty("Annual Gross T1 With Bonus")
  String annualGrossT1WithBonus;

  @JsonProperty("Annual AER T1 With Bonus")
  String annualAERT1WithBonus;

  @JsonProperty("Monthly Gross T1 With Bonus")
  String monthlyGrossT1WithBonus;

  @JsonProperty("Monthly AER T1 With Bonus")
  String monthlyAERT1WithBonus;

  @JsonProperty("Apply Online")
  String applyOnline;

  @JsonProperty("Apply In Branch")
  String applyInBranch;

  @JsonProperty("Apply In Agency")
  String applyInAgency;

  @JsonProperty("Apply By Post")
  String applyByPost;

  @JsonProperty("Manage Online")
  String manageOnline;

  @JsonProperty("View Online ")
  String viewOnline;

  @JsonProperty("Manage In Branch")
  String manageInBranch;

  @JsonProperty("Manage In Agency")
  String manageInAgency;

  @JsonProperty("Manage By Post")
  String manageByPost;

  @JsonProperty("Trustee Accounts Accepted")
  String trusteeAccountsAccepted;

  @JsonProperty("Matures Into Product Name")
  String maturesIntoProductName;

  @JsonProperty("No YBS Funds In Allowed")
  String noYBSFundsInAllowed;

  @JsonProperty("Account Switching")
  String accountSwitching;

  @JsonProperty("Max Account Holders")
  Integer maxAccountHolders;

  @JsonProperty("Min Age Customer")
  Integer minAgeCustomer;

  @JsonProperty("Min Age Not Held In Trust")
  Integer minAgeNotHeldInTrust;

  @JsonProperty("Max Age Customer")
  Integer maxAgeCustomer;

  @JsonProperty("Interest Date Long 1")
  String interestDateLong1;

  @JsonProperty("Interest Date Long 2")
  String interestDateLong2;

  @JsonProperty("Interest Date Long 3")
  String interestDateLong3;

  @JsonProperty("Interest Date Long 4")
  String interestDateLong4;

  @JsonProperty("Interest Date Long 5")
  String interestDateLong5;

  @JsonProperty("Interest Date Long 6")
  String interestDateLong6;

  @JsonProperty("Interest Date Long 7")
  String interestDateLong7;

  @JsonProperty("Interest Date Long 8")
  String interestDateLong8;

  @JsonProperty("Interest Date Long 9")
  String interestDateLong9;

  @JsonProperty("Interest Date Long 10")
  String interestDateLong10;

  @JsonProperty("Max Accounts Per Person")
  Integer maxAccountsPerPerson;

  @JsonProperty("Example Balance T1")
  BigDecimal exampleBalanceT1;

  @JsonProperty("Example Term T1")
  Integer exampleTermT1;

  @JsonProperty("Example Starting Amount T1")
  Integer exampleStartingAmountT1;

  @JsonProperty("Example Ongoing Deposit T1")
  String exampleOngoingDepositT1;

  @JsonProperty("Example Balance T2")
  BigDecimal exampleBalanceT2;

  @JsonProperty("Example Term T2")
  Integer exampleTermT2;

  @JsonProperty("Example Starting Amount T2")
  Integer exampleStartingAmountT2;

  @JsonProperty("Example Ongoing Deposit T2")
  String exampleOngoingDepositT2;

  @JsonProperty("Example Balance T3")
  BigDecimal exampleBalanceT3;

  @JsonProperty("Example Term T3")
  Integer exampleTermT3;

  @JsonProperty("Example Starting Amount T3")
  Integer exampleStartingAmountT3;

  @JsonProperty("Example Ongoing Deposit T3")
  String exampleOngoingDepositT3;

  @JsonProperty("Example Balance T4")
  BigDecimal exampleBalanceT4;

  @JsonProperty("Example Term T4")
  Integer exampleTermT4;

  @JsonProperty("Example Starting Amount T4")
  Integer exampleStartingAmountT4;

  @JsonProperty("Example Ongoing Deposit T4")
  String exampleOngoingDepositT4;

  @JsonProperty("Example Balance T5")
  BigDecimal exampleBalanceT5;

  @JsonProperty("Example Term T5")
  Integer exampleTermT5;

  @JsonProperty("Example Starting Amount T5")
  Integer exampleStartingAmountT5;

  @JsonProperty("Example Ongoing Deposit T5")
  String exampleOngoingDepositT5;

  @JsonProperty("Example Balance T6")
  BigDecimal exampleBalanceT6;

  @JsonProperty("Example Term T6")
  Integer exampleTermT6;

  @JsonProperty("Example Starting Amount T6")
  Integer exampleStartingAmountT6;

  @JsonProperty("Example Ongoing Deposit T6")
  String exampleOngoingDepositT6;

  @JsonProperty("Example Balance T7")
  BigDecimal exampleBalanceT7;

  @JsonProperty("Example Term T7")
  Integer exampleTermT7;

  @JsonProperty("Example Starting Amount T7")
  Integer exampleStartingAmountT7;

  @JsonProperty("Example Ongoing Deposit T7")
  String exampleOngoingDepositT7;

  @JsonProperty("Example Balance T8")
  BigDecimal exampleBalanceT8;

  @JsonProperty("Example Term T8")
  Integer exampleTermT8;

  @JsonProperty("Example Starting Amount T8")
  Integer exampleStartingAmountT8;

  @JsonProperty("Example Ongoing Deposit T8")
  String exampleOngoingDepositT8;

  @JsonProperty("Example Balance T9")
  BigDecimal exampleBalanceT9;

  @JsonProperty("Example Term T9")
  Integer exampleTermT9;

  @JsonProperty("Example Starting Amount T9")
  Integer exampleStartingAmountT9;

  @JsonProperty("Example Ongoing Deposit T9")
  String exampleOngoingDepositT9;

  @JsonProperty("Example Balance T10")
  BigDecimal exampleBalanceT10;

  @JsonProperty("Example Term T10")
  Integer exampleTermT10;

  @JsonProperty("Example Starting Amount T10")
  Integer exampleStartingAmountT10;

  @JsonProperty("Example Ongoing Deposit T10")
  String exampleOngoingDepositT10;

  @JsonProperty("Regular Saver 12 Month Example Gross Interest")
  String regularSaver12MonthExampleGrossInterest;

  @JsonProperty("Tax-free")
  String taxFree;

  @JsonProperty("Fixed-term")
  String fixedTerm;

  @JsonProperty("Easy Access")
  String easyAccess;

  @JsonProperty("Regular Saver")
  String regularSaver;

  @JsonProperty("Childrens")
  String childrens;

  @JsonProperty("Bond")
  String bond;

  @JsonProperty("Cash ISA")
  String cashISA;

  @JsonProperty("Flexible ISA")
  String flexibleISA;

  @JsonProperty("Loyalty")
  String loyalty;

  @JsonProperty("ATM Card")
  String aTMCard;

  @JsonProperty("Passbook")
  String passbook;

  @JsonProperty("Optional Withdrawal Restriction")
  String optionalWithdrawalRestriction;

  @JsonProperty("Withdrawals Permitted")
  String withdrawalsPermitted;

  @JsonProperty("Min Withdrawal Amount")
  String minWithdrawalAmount;

  @JsonProperty("Withdrawal Days")
  Integer withdrawalDays;

  @JsonProperty("Closure Permitted")
  String closurePermitted;

  @JsonProperty("Cancellation Permitted")
  String cancellationPermitted;

  @JsonProperty("Loss Of Interest")
  Integer lossOfInterest;

  @JsonProperty("Notification Date")
  String notificationDate;

  @JsonProperty("Notification Rate")
  String notificationRate;

  @JsonProperty("Maturity Product")
  String maturityProduct;

  @JsonProperty("Maturity Product Offer")
  String maturityProductOffer;

  @JsonProperty("Withdrawals Until Date")
  String withdrawalsUntilDate;

  @JsonProperty("Withdrawals From Date")
  String withdrawalsFromDate;

  @JsonProperty("Invest From Date")
  String investFromDate;

  @JsonProperty("Last Date For Deposits")
  String lastDateForDeposits;

  @JsonProperty("Popularity")
  Integer popularity;

  @JsonProperty("Prod Type")
  String prodType;

  @JsonProperty("Smart-tiered")
  String smartTiered;

  @JsonProperty("Maturity Holding Page")
  String maturityHoldingPage;

  public static class WebSiteProductBuilder {
    public WebSiteProductBuilder accept(final Consumer<WebSiteProductBuilder> consumer) {
      consumer.accept(this);
      return this;
    }
  }
}
