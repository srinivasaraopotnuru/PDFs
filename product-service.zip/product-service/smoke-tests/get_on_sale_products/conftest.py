import pytest

on_sale_path = '/on-sale-products'
on_sale_private_path = '/private' + on_sale_path


@pytest.fixture(scope="module")
def on_sale_response_from_api(request_id, make_request_account_read):
    return make_request_account_read(request_id, on_sale_path, jwt=None)


@pytest.fixture(scope="module")
def private_on_sale_response_from_api(request_id, private_make_request_account_read):
    return private_make_request_account_read(request_id, on_sale_private_path, jwt=None)


@pytest.fixture(scope="module")
def on_sale_product_summary_response_from_api(request_id, make_request_account_read):
    return make_request_account_read(request_id, on_sale_path + "/YB691501W/summary", jwt=None)
