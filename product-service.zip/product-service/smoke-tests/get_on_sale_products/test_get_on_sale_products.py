import jsonschema

_on_sale_product_interest_tiers_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["rate", "description"],
            "properties": {
                "rate": {"type": "string"},
                "description": {"type": "string"},
                "range": {"type": "string"}
            }
        }
    ]
}

_on_sale_product_facts_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["text"],
            "properties": {
                "text": {"type": "string"}
            }
        }
    ]
}

_on_sale_product_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["name", "type", "url", "loyalty", "interestFrequency", "interestTiers", "facts"],
            "properties": {
                "name": {"type": "string"},
                "type": {"type": "string"},
                "url": {"type": "string"},
                "loyalty": {"type": "boolean"},
                "interestFrequency": {"type": "string"},
                "interestTiers": _on_sale_product_interest_tiers_schema,
                "facts": _on_sale_product_facts_schema
            }
        }
    ]
}

_on_sale_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "subTitle": {"type": "string"},
                "description": {"type": "string"},
                "offlineOnlyProductsAvailable": {"type": "boolean"},
                "url": {"type": "string"},
                "products": _on_sale_product_schema
            },
            "required": ["title", "subTitle", "description", "products", "url", "offlineOnlyProductsAvailable"]
        }
    ]
}

_product_summary_section_schema = {
    "type": "object",
    "required": ["icon", "displayIcon", "collapsible"],
    "properties": {
        "icon": {
            "type": "string"
        },
        "displayIcon": {
            "type": "boolean"
        },
        "collapsible": {
            "type": "boolean"
        },
    }
}

available_product_interest_tiers_schema = {
  "type": "array",
  "items": [
    {
      "type": "object",
      "required": ["rate", "description"],
      "properties": {
        "rate": {"type": "string"},
        "description": {"type": "string"},
        "range": {"type": "string"}
      }
    }
  ]
}


_product_summary_content_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["format", "text"],
            "properties": {
                "format": {"type": "string"},
                "text": {"type": "string"},
                "link": {"type": "string"}
            }
        }
    ]
}

_product_summary_tiers_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["tax", "interest"],
            "properties": {
                "header": {"type": "string"},
                "tax": {"type": "string"},
                "interest": {"type": "string"}
            }
        }
    ]
}

_product_summary_help_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["header", "text", "section"],
            "properties": {
                "header": {"type": "string"},
                "text": {"type": "string"},
                "section": _product_summary_section_schema
            }
        }
    ]
}

_on_sale_product_summary_schema = {
    "type": "object",
    "required": ["account"],
    "properties": {
        "account": {
            "type": "object",
            "properties": {
                "section": _product_summary_section_schema,
                "title": {
                    "type": "string"
                },
                "name": {
                    "type": "string"
                }
            }
        },
        "interest": {
            "type": "object",
            "properties": {
                "section": _product_summary_section_schema,
                "tiers": _product_summary_tiers_schema,
                "content": _product_summary_content_schema,
                "help": _product_summary_help_schema
            }
        },
        "interestRateChanges": {
            "type": "object",
            "properties": {
                "section":  _product_summary_section_schema,
                "title": {
                    "type": "string"
                },
                "content": _product_summary_content_schema
            }
        },
        "projections": {
            "type": "object",
            "properties": {
                "section": _product_summary_section_schema,
                "title": {
                    "type": "string"
                },
                "content":  _product_summary_content_schema
            }
        },
        "manageAccount": {
            "type": "object",
            "properties": {
                "section": _product_summary_section_schema,
                "title": {
                    "type": "string"
                },
                "content": _product_summary_content_schema
            }
        },
        "withdrawals": {
            "type": "object",
            "properties": {
                "section": _product_summary_section_schema,
                "title": {
                    "type": "string"
                },
                "content": _product_summary_content_schema
            }
        },
        "additionalInformation": {
            "type": "object",
            "properties": {
                "section": _product_summary_section_schema,
                "title": {
                    "type": "string"
                },
                "content": _product_summary_content_schema
            }
        },
        "prerequisites": {
            "type": "object",
            "properties": {
                "section": _product_summary_section_schema,
                "title": {
                    "type": "string"
                },
                "content": _product_summary_content_schema
            }
        },
        "apply": {
            "type": "object",
            "properties": {
                "section": _product_summary_section_schema,
                "title": {
                    "type": "string"
                },
                "content": _product_summary_content_schema
            }
        }
    }
}


def test_get_on_sale_products_returns_success(on_sale_response_from_api):
    assert on_sale_response_from_api.status_code == 200
    jsonschema.validate(on_sale_response_from_api.json(), _on_sale_schema)


def test_private_get_on_sale_products_returns_success(private_on_sale_response_from_api):
    assert private_on_sale_response_from_api.status_code == 200
    jsonschema.validate(private_on_sale_response_from_api.json(), _on_sale_schema)


def test_get_on_sale_product_summary_returns_success(on_sale_product_summary_response_from_api):
    assert on_sale_product_summary_response_from_api.status_code == 200
    jsonschema.validate(on_sale_product_summary_response_from_api.json(), _on_sale_product_summary_schema)
