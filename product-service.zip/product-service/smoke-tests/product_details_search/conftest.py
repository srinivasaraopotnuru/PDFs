import pytest

search_path = '/product?productIdentifiers=INTSAV,EGG302A&page=0&size=5&sort=productIdentifier'
search_private_path = '/private' + search_path


@pytest.fixture(scope="module")
def search_by_product_identifiers_response_from_api(request_id, make_request_account_read):
    return make_request_account_read(request_id, search_path)

@pytest.fixture(scope="module")
def private_search_by_product_identifiers_response_from_api(request_id, private_make_request_account_read):
    return private_make_request_account_read(request_id, search_private_path)

