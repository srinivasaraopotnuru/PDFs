import jsonschema


def test_search_product_details_returns_success(search_by_product_identifiers_response_from_api):
    assert search_by_product_identifiers_response_from_api.status_code == 200

def test_private_search_product_details_returns_success(private_search_by_product_identifiers_response_from_api):
    assert private_search_by_product_identifiers_response_from_api.status_code == 200


def test_search_product_details_returns_page_with_2_items(search_by_product_identifiers_response_from_api):
    page = search_by_product_identifiers_response_from_api.json()
    assert page['pageNumber'] == 0
    assert page['pageSize'] == 5
    assert page['totalPages'] == 1
    assert page['totalElements'] == 2

def test_private_search_product_details_returns_page_with_2_items(private_search_by_product_identifiers_response_from_api):
    page = private_search_by_product_identifiers_response_from_api.json()
    assert page['pageNumber'] == 0
    assert page['pageSize'] == 5
    assert page['totalPages'] == 1
    assert page['totalElements'] == 2


def test_search_product_details_returns_content_sorted_by_product_identifier(search_by_product_identifiers_response_from_api):
    page = search_by_product_identifiers_response_from_api.json()
    assert len(page['content']) == 2
    assert page['content'][0]['productIdentifier'] == 'EGG302A'
    assert page['content'][1]['productIdentifier'] == 'INTSAV'

def test_private_search_product_details_returns_content_sorted_by_product_identifier(private_search_by_product_identifiers_response_from_api):
    page = private_search_by_product_identifiers_response_from_api.json()
    assert len(page['content']) == 2
    assert page['content'][0]['productIdentifier'] == 'EGG302A'
    assert page['content'][1]['productIdentifier'] == 'INTSAV'


def test_schema_is_valid(search_by_product_identifiers_response_from_api, product_details_search_schema):
    jsonschema.validate(search_by_product_identifiers_response_from_api.json(), product_details_search_schema)
