import pytest

product_identifier = 'WXYZ1234'
reinvestment_path = '/product/' + product_identifier + '/reinvestment-products'
reinvestment_private_path = '/private' + reinvestment_path

@pytest.fixture(scope="module")
def private_reinvestment_response_from_api(request_id, private_make_request_account_read):
    return private_make_request_account_read(request_id, reinvestment_private_path, jwt=None)
