import config
import json
import ecdsa
import hashlib
import os
import pytest
import uuid
from jwt import (
    JWT,
    jwk_from_pem,
)
from signer import Signer

from time import time

import requests

# Apigee signed jwt:
jwt_alg = 'RS256'
host = os.getenv('SERVICE_HOST', default='localhost:8082')
protocol = os.getenv('SERVICE_PROTOCOL', default='http://')
base_path = '/product'
host_presented = host
public_key_id = 'apigee-nonprod-1'
private_key_id = 'account-service-nonprod-1'
signer = Signer({
    public_key_id: ecdsa.SigningKey.from_pem(config.request_signing_private_key_public, hashlib.sha256),
    private_key_id: ecdsa.SigningKey.from_pem(config.request_signing_private_key_private, hashlib.sha256)
})

_product_applications_schema = {
    "type": "object",
    "required": [
        "accountNumberSuffix",
        "applicationsPermitted",
        "fatcaReportable",
        "maximumAge",
        "maximumApplicants",
        "minimumAge",
        "nationalInsuranceNumberRequired"
    ],
    "additionalProperties": False,
    "properties": {
        "accountNumberSuffix": {
            "type": "string"
        },
        "applicationsPermitted": {
            "type": "boolean"
        },
        "fatcaReportable": {
            "type": "boolean"
        },
        "maximumAge": {
            "type": "integer",
            "format": "int64"
        },
        "maximumApplicants": {
            "type": "integer",
            "format": "int64"
        },
        "minimumAge": {
            "type": "integer",
            "format": "int64"
        },
        "nationalInsuranceNumberRequired": {
            "type": "boolean"
        }
    },
    "title": "Applications"
}

_product_balance_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "max": {
            "type": "string"
        },
        "min": {
            "type": "string"
        }
    },
    "title": "Balance"
}

_product_deposits_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "limits": {
            "type": "object",
            "properties": {
                "number": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "anniversaryYear": {
                            "type": "integer",
                            "format": "int64"
                        },
                        "month": {
                            "type": "integer",
                            "format": "int64"
                        },
                        "productTerm": {
                            "type": "integer",
                            "format": "int64"
                        },
                        "taxYear": {
                            "type": "integer",
                            "format": "int64"
                        },
                        "year": {
                            "type": "integer",
                            "format": "int64"
                        }
                    },
                    "title": "PeriodLimits\u00ablong\u00bb"
                }
            },
            "title": "Limits"
        },
        "permittedExternal": {
            "type": "boolean"
        },
        "permittedInternal": {
            "type": "boolean"
        },
        "permittedInBranch": {
            "type": "boolean"
        }
    },
    "title": "Deposits"
}

_product_interest_tiers_schema = {
    "type": "array",
    "items": {
        "type": "object",
        "required": [
            "rangeHigh",
            "rangeLow",
            "rate"
        ],
        "additionalProperties": False,
        "properties": {
            "rangeHigh": {
                "type": "string"
            },
            "rangeLow": {
                "type": "string"
            },
            "rate": {
                "type": "string"
            }
        }
    }
}

_product_interest_schema = {
    "type": "object",
    "required": [
        "interestPaid",
        "tiers",
        "permittedInterestDestinations"
    ],
    "additionalProperties": False,
    "properties": {
        "interestPaid": {
            "type": "string"
        },
        "tiers": _product_interest_tiers_schema,
        "permittedInterestDestinations": {
            "type": "array",
            "items": {
                "type": "string"
            }
        }
    },
    "title": "Interest"
}

_product_interest_private_schema = {
    "type": "object",
    "required": [
        "divisorDays",
        "interestPaid",
        "tiers",
        "periodEndIndicator",
        "permittedInterestDestinations",
        "webAmendmentsPermitted"
    ],
    "additionalProperties": False,
    "properties": {
        "divisorDays": {
            "type": "integer"
        },
        "interestPaid": {
            "type": "string"
        },
        "tiers": _product_interest_tiers_schema,
        "periodEndDate": {
            "type": "string"
        },
        "periodEndIndicator": {
            "type": "string"
        },
        "permittedInterestDestinations": {
            "type": "array",
            "items": {
                "type": "string"
            }
        },
        "previousPeriodDivisorDays": {
            "type": "integer"
        },
        "webAmendmentsPermitted": {
            "type": "boolean"
        }
    },
    "title": "Interest"
}

_product_withdrawals_limits_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "number": {
            "type": "object",
            "properties": {
                "anniversaryYear": {
                    "type": "string"
                },
                "month": {
                    "type": "string"
                },
                "productTerm": {
                    "type": "string"
                },
                "taxYear": {
                    "type": "string"
                },
                "year": {
                    "type": "string"
                }
            },
            "title": "PeriodLimits\u00abBigDecimal\u00bb"
        }
    }
}

_product_withdrawals_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "limits": _product_withdrawals_limits_schema,
        "permittedOverWeb": {
            "type": "boolean"
        }
    },
    "title": "Withdrawals"
}

_product_withdrawals_private_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "interestPenalty": {
            "type": "object",
            "additionalProperties": False,
            "required": [
                "code",
                "days"
            ],
            "properties": {
                "balanceUpperBound": {
                    "type": "string"
                },
                "code": {
                    "type": "integer"
                },
                "days": {
                    "type": "integer"
                }
            }
        },
        "limits": _product_withdrawals_limits_schema,
        "permittedOverWeb": {
            "type": "boolean"
        }
    },
    "title": "Withdrawals"
}

_product_saver_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "regular": {
            "type": "boolean"
        }
    },
    "title": "saver"
}

_product_isa_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "flexible": {
            "type": "boolean"
        },
        "helpToBuy": {
            "type": "boolean"
        },
        "isaYear": {
            "type": "integer"
        }
    },
    "title": "isa"
}

_product_beneficiaries_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "external": {
            "type": "integer"
        },
        "internal": {
            "type": "integer"
        }
    },
    "title": "beneficiaries"
}


@pytest.fixture(scope="module")
def product_details_schema():
    return {
        "type": "object",
        "required": [
            "applications",
            "balance",
            "customerDescription",
            "interest",
            "productIdentifier",
            "smartTiered"
        ],
        "additionalProperties": False,
        "properties": {
            "applications": _product_applications_schema,
            "balance": _product_balance_schema,
            "saver": _product_saver_schema,
            "brandCode": {
                "type": "string"
            },
            "isKycRequired": {
                "type": "boolean"
            },
            "cardAvailable": {
                "type": "boolean"
            },
            "maximumNumberOfAccounts": {
                "type": "number"
            },
            "smartTiered": {
                "type": "boolean"
            },
            "customerDescription": {
                "type": "string"
            },
            "deposits": _product_deposits_schema,
            "interest": _product_interest_schema,
            "maximumMonthlyPayment": {
                "type": "number"
            },
            "productIdentifier": {
                "type": "string"
            },
            "productType": {
                "type": "string"
            },
            "withdrawals": _product_withdrawals_schema
        },
        "title": "ProductDetailsResponse",
        "$schema": "http://json-schema.org/schema#"
    }


@pytest.fixture(scope="module")
def product_details_private_schema():
    return {
        "type": "object",
        "required": [
            "applications",
            "balance",
            "beneficiaries",
            "customerDescription",
            "interest",
            "productIdentifier",
            "productSysId",
            "startDate",
            "smartTiered"

        ],
        "additionalProperties": False,
        "properties": {
            "applications": _product_applications_schema,
            "balance": _product_balance_schema,
            "saver": _product_saver_schema,
            "beneficiaries": _product_beneficiaries_schema,
            "brandCode": {
                "type": "string"
            },
            "isKycRequired": {
                "type": "boolean"
            },
            "cardAvailable": {
                "type": "boolean"
            },
            "maximumNumberOfAccounts": {
                "type": "number"
            },
            "smartTiered": {
                "type": "boolean"
            },
            "customerDescription": {
                "type": "string"
            },
            "deposits": _product_deposits_schema,
            "interest": _product_interest_private_schema,
            "isa": _product_isa_schema,
            "maximumMonthlyPayment": {
                "type": "number"
            },
            "productIdentifier": {
                "type": "string"
            },
            "productType": {
                "type": "string"
            },
            "productSysId": {
                "type": "number"
            },
            "startDate": {
                "type": "string"
            },
            "withdrawals": _product_withdrawals_private_schema
        },
        "title": "ProductDetailsResponsePrivate",
        "$schema": "http://json-schema.org/schema#"
    }


@pytest.fixture(scope="module")
def product_details_search_schema(product_details_schema):
    return {
        "type": "object",
        "required": [
            "pageNumber",
            "pageSize",
            "totalPages",
            "totalElements",
            "content"
        ],
        "additionalProperties": False,
        "properties": {
            "pageNumber": {
                "type": "integer"
            },
            "pageSize": {
                "type": "integer"
            },
            "totalPages": {
                "type": "integer"
            },
            "totalElements": {
                "type": "integer",
                "format": "int64"
            },
            "content": {
                "type": "array",
                "items": product_details_schema
            }
        },
        "title": "ProductDetailsSearchResponse",
        "$schema": "http://json-schema.org/schema#"
    }


@pytest.fixture(scope="module")
def available_products_schema():
    return {
        "type": "object",
        "required": [
            "pageNumber",
            "pageSize",
            "totalPages",
            "totalElements",
            "content"
        ],
        "additionalProperties": False,
        "properties": {
            "pageNumber": {
                "type": "integer"
            },
            "pageSize": {
                "type": "integer"
            },
            "totalPages": {
                "type": "integer"
            },
            "totalElements": {
                "type": "integer",
                "format": "int64"
            },
            "content": {
                "type": "array",
                "items": product_details_schema
            }
        },
        "title": "ProductDetailsSearchResponse",
        "$schema": "http://json-schema.org/schema#"
    }


@pytest.fixture(scope="module")
def request_id():
    return str(uuid.uuid4())


def create_authorization(bearer_token):
    return 'Bearer ' + bearer_token

def create_avp_post():
    return {
           "dateOfBirth":"2001-11-01",
           "countryCode":"UK",
           "accounts": [
               {
                   "productIdentifier":"YB901552W",
                   "count":1
               }
           ]
    }

def create_jwt(scope):
    signing_key = jwk_from_pem(config.jwt_private_key.encode())
    jwt = JWT()

    headers = {
        'kid': 'OPAa9voYNByjE_lpbtHanOFKiV4',
        'alg': jwt_alg
    }

    message = {
        'sub': 'my-customer-id',
        'iat': time(),
        'aud': 'DIGITAL_API',
        'brand_code': 'YBS',
        'scope': scope
    }

    return jwt.encode(message, signing_key, jwt_alg, headers)


@pytest.fixture(scope="module")
def make_request_account_read():
    return make_request('ACCOUNT_READ', public_key_id,'GET',None,sign=True)


@pytest.fixture(scope="module")
def private_make_request_account_read():
    return make_request('ACCOUNT_READ', private_key_id,'GET',None,sign=True)

@pytest.fixture(scope="module")
def private_make_request_account_read_post():
    return make_request('ACCOUNT_READ', private_key_id,'POST',json.dumps(create_avp_post()),sign=True)

@pytest.fixture(scope="module")
def make_request_product_read(verb='GET',data=None):
    return make_request('PRODUCT_READ', private_key_id,verb,None,sign=True)


def make_request(jwt_scope, key_id,verb,data,sign=True):
    def _make_request(request_id, path, jwt=create_authorization(create_jwt(jwt_scope)), signed=sign):
        headers = {
            'x-ybs-request-id': request_id,
            'x-ybs-request-signature-key-id': key_id,
            'Host': host_presented,
            'Content-type':'application/json'
        }
        print("ZZSEc JWT " + jwt_scope)
        print("Path  JWT2 " + path)
        if jwt is not None:
            headers['Authorization'] = jwt

        url = protocol + host + base_path + path
        print("URL " + url)
        request = requests.Request(
            verb,
            url,
            headers=headers,
	    data=data
        ).prepare()

        if signed:
            signer.sign_request(request)


        return requests.session().send(request, verify=False)
    return _make_request
