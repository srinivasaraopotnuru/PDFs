# Smoke tests
From the root directory (/ybs-product-service/.) run:
```
pipenv install
pipenv run pytest
```

NB: You need to have the product service running at http://localhost:8080

### Notes
- To see the output of print statements, you can run ```pipenv run pytest -s```
- The tests use environment variables to for the url, so will run against
ec2-63-32-102-15.eu-west-1.compute.amazonaws.com:8090 in CI. 
