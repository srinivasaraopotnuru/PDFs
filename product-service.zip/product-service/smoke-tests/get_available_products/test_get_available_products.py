import os

def test_get_available_products_returns_success(available_products_from_api):
    assert available_products_from_api.status_code == 200

def test_invalid_jwt_returns_error(request_id, response_for_invalid_jwt):
    assert response_for_invalid_jwt.status_code == 401
    assert response_for_invalid_jwt.json() == {
        "id": request_id,
        "code": "401 Unauthorized",
        "message": "Unauthorized",
        "errors": [
            {
                "errorCode": "Unauthorized",
                "message": "Unauthorized"
            }
        ]
    }

def test_invalid_signature_returns_error(request_id, response_for_invalid_signature):
    assert response_for_invalid_signature.status_code == 403
    assert response_for_invalid_signature.json() == {
        "id": request_id,
        "code": "403 Forbidden",
        "message": "Forbidden",
        "errors": [
            {
                "errorCode": "AccessDenied.InvalidRequestSignature",
                "message": "Access Denied"
            }
        ]
    }


def test_invalid_product_returns_error(invalid_product_response_from_api):
    assert invalid_product_response_from_api.status_code == 405


# Helpers
def get_expected_avp_json():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(script_dir, "data/avp_expected.json")) as expected_avp_file:
        return json.load(expected_avp_file)
