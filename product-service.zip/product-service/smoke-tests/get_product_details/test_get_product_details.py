import json
import jsonschema
import os


def test_get_product_returns_success(intsav_response_from_api):
    assert intsav_response_from_api.status_code == 200


def test_private_get_product_returns_success(private_intsav_response_from_api):
    assert private_intsav_response_from_api.status_code == 200


def test_get_product_returns_success_product_read(intsav_response_from_api_product_read):
    assert intsav_response_from_api_product_read.status_code == 200


def test_intsav_has_correct_rules(intsav_response_from_api):
    data = intsav_response_from_api.json()
    assert data == get_expected_intsav_json()


def test_invalid_product_returns_error(invalid_product_response_from_api):
    assert invalid_product_response_from_api.status_code == 404


def test_invalid_jwt_returns_error(request_id, response_for_invalid_jwt):
    assert response_for_invalid_jwt.status_code == 401
    assert response_for_invalid_jwt.json() == {
        "id": request_id,
        "code": "401 Unauthorized",
        "message": "Unauthorized",
        "errors": [
            {
                "errorCode": "Unauthorized",
                "message": "Unauthorized"
            }
        ]
    }


def test_invalid_signature_returns_error(request_id, response_for_invalid_signature):
    assert response_for_invalid_signature.status_code == 403
    assert response_for_invalid_signature.json() == {
        "id": request_id,
        "code": "403 Forbidden",
        "message": "Forbidden",
        "errors": [
            {
                "errorCode": "AccessDenied.InvalidRequestSignature",
                "message": "Access Denied"
            }
        ]
    }


def test_product_details_schema_is_valid(intsav_response_from_api, product_details_schema):
    jsonschema.validate(intsav_response_from_api.json(), product_details_schema)


def test_product_details_private_schema_is_valid(private_intsav_response_from_api, product_details_private_schema):
    jsonschema.validate(private_intsav_response_from_api.json(), product_details_private_schema)


# Helpers
def get_expected_intsav_json():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(script_dir, "data/intsav_expected.json")) as expected_intsav_file:
        return json.load(expected_intsav_file)
