import pytest

intsav_path = '/product/INTSAV'
intsav_private_path = '/private' + intsav_path


@pytest.fixture(scope="module")
def intsav_response_from_api(request_id, make_request_account_read):
    return make_request_account_read(request_id, intsav_path)


@pytest.fixture(scope="module")
def private_intsav_response_from_api(request_id, private_make_request_account_read):
    return private_make_request_account_read(request_id, intsav_private_path)


@pytest.fixture(scope="module")
def intsav_response_from_api_product_read(request_id, make_request_product_read):
    return make_request_product_read(request_id, intsav_path)


@pytest.fixture(scope="module")
def invalid_product_response_from_api(request_id, make_request_account_read):
    invalid_path = '/product/foo'
    return make_request_account_read(request_id, invalid_path)


@pytest.fixture(scope="module")
def response_for_invalid_jwt(request_id, make_request_account_read):
    invalid_jwt = "Bearer INVALIDQiOiJPUEFhOXZvWU5CeWpFX2xwYnRIYW5PRktpVjQiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJEaWdpdGFsQVBJIiwiYXVkIjoiU2F2aW5nc0FwcCIsImV4cCI6MTU5MTM3MjEwNCwiYnJhbmRfY29kZSI6IllCUyIsImN1c3RvbWVyX2xhc3RfbmFtZSI6IlNtaXRoIiwiY3VzdG9tZXJfbnVtYmVyIjoiMTgyMTU0OCIsImN1c3RvbWVyX2ZpcnN0X25hbWUiOiJBbGljZSIsInNjb3BlIjoiUkVBRCIsInJlZ2lzdHJhdGlvbl9pZCI6ImI1MzM4MzRlLTczZjUtNGE1Ni1iMmFhLWUxNTcyMzMyODRiMyIsImlhdCI6MTU1OTMxNzcwNCwianRpIjoiYzY1ZWQ5OTktNTZiNi00ZDM4LTg4ZWEtN2IyMGU1ZDM3ODg5In0.CBDnDKTOtprpWxlxvy1beUk3y0CPAS-yKkD1xp7cxve3bdL1CN8C4yh4B94nZ49BBzD4aMTyS19L0qb1jLqrCSNUDChfrUAN0xdtY2P_LsXKl29qZiitypt8CFqaSsJd2sn-4uK8AXYXFh6ic1L6YPUW1sqVFSrXYmuA8Uzfhc6jZ01akpFdrCATNhx-cUBMQKkt6TMaofMq6iD8PaoTOsj19GeQ6HKYBS0Sqodn_H2mIsI7xts1_VpJ6vf1obWr4GMkppwh1x9gG3KXSgbz0AU5h5bA0KRwzspQFJwtnvTB2PDGkjo5rUA_kp8l7R4xQtJcoE65Bx5siPsNIr9CPQ"
    return make_request_account_read(request_id, intsav_path, jwt=invalid_jwt)


@pytest.fixture(scope="module")
def response_for_invalid_signature(request_id, make_request_account_read):
    return make_request_account_read(request_id, intsav_path, signed=False)
