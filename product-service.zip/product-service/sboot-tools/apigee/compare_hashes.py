'''provides utilities for finding differences between sets of hashes'''
import sys
import json
import git_utils
import hashing


def extract_hash(entry):
    '''if the entry is a string it just returns it, otherwise it looks for a
    'hash' entry in the dictionary'''
    if entry is None:
        return None

    return entry if isinstance(entry, str) else entry['hash']


def diff_hashes(old, new):
    '''returns the hashes which have changed and those that have been removed
    in a tuple. new hashes are considered changed'''
    removed = old.keys() - new.keys()
    changed = {}

    for directory, value in new.items():
        new_hash = extract_hash(value)

        try:
            old_hash = extract_hash(old[directory])
            if old_hash is not None and new_hash != old_hash:
                changed[directory] = new_hash
        except KeyError:
            changed[directory] = new_hash

    return changed


def compare_with(old, *directories, subdir=None):
    '''compares the current hashes with the old ones returns any differences'''
    new = hashing.hash_directories(*directories, subdir=subdir, list_function=git_utils.list_files)
    return diff_hashes(old, new)

def compare_with_zip(old, *zips):
    '''compares the current hashes with the old ones returns any differences'''
    new = hashing.hash_zips(*zips)
    return diff_hashes(old, new)


def main():
    '''main entry point into module if invoked as an executable'''
    with open(sys.argv[1], 'r') as old:
        hashes = compare_with(json.load(old)['apiproxies'], sys.argv[2:])
        hashes = {
            'changed': list(hashes[0]),
            'removed': list(hashes[1]),
        }
        json.dump(hashes, sys.stdout, indent=4)


if __name__ == '__main__':
    main()
