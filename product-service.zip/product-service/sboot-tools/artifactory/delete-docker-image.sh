#!/usr/bin/env bash
#Gives you the command to delete a docker image from artifactory.
#You must specify a param, The path to the docker image.
#Expected format:
#ybsg/calculators/maxborrowing-service/0.1.0-SNAPSHOT
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
. "$gwd/sboot-tools/local/gradle-env.sh"
echo pwd=`pwd`

if [ "" == "$AD_USERNAME" ]; then
  echo "INFO: Run: \`. ./sboot-tools/set-env.sh\` to persist env vars in this shell"
  . $gwd/sboot-tools/set-env.sh
fi
export ARTIFACTORY_USERNAME=$AD_USERNAME
export ARTIFACTORY_PASSWORD=`echo -n $AD_PASSWORD_B64 | base64 --decode`

IMAGE_URL=https://artifactory.ybs.com/artifactory/docker-local/$1

if [ "" != "$1" ]; then
  echo "Deleting: $IMAGE_URL"
  echo "Use the following command:"
  echo "curl -u$ARTIFACTORY_USERNAME:$ARTIFACTORY_PASSWORD -X DELETE \"$IMAGE_URL\""
else
  echo "ERROR: Please specify image path parameter"
fi

##Clean up env vars
export ARTIFACTORY_USERNAME=
export ARTIFACTORY_PASSWORD=
