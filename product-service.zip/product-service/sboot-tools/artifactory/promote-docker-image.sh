#!/usr/bin/env bash
#A sample of the command to promote a docker image from artifactory.
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
. "$gwd/sboot-tools/local/gradle-env.sh"
echo pwd=`pwd`

if [ "" == "$AD_USERNAME" ]; then
  echo "INFO: Run: \`. ./sboot-tools/set-env.sh\` to persist env vars in this shell"
  . $gwd/sboot-tools/set-env.sh
fi
export ARTIFACTORY_USERNAME=$AD_USERNAME
export ARTIFACTORY_PASSWORD=`echo -n $AD_PASSWORD_B64 | base64 --decode`
export VERSION=`cat $gwd/build/version.txt`

if [ "" != "$ARTIFACTORY_HOST" ] && [ "" != "$DOCKER_NAME" ] && [ "" != "$VERSION" ]; then
echo curl -u$ARTIFACTORY_USERNAME:******** \
 -v -X POST \"https://$ARTIFACTORY_HOST/artifactory/api/docker/digital-docker-nonprod-local/v2/promote\" \
 -H \"Content-Type: application/json\" -d \@\- \<\<\'EOF\' \
'
{
    "targetRepo" : "digital-docker-prod-local", 
    "dockerRepository" : "'"$DOCKER_NAME"'", 
    "tag" : "'"$VERSION"'", 
    "targetTag" : "'"$VERSION"'", 
    "copy": false 
}
EOF'
else
  echo "ARTIFACTORY_HOST, DOCKER_NAME & VERSION must be defined before promoting"
  exit 1
fi

##Clean up env vars
export ARTIFACTORY_USERNAME=
export ARTIFACTORY_PASSWORD=
