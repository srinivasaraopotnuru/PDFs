#!/usr/bin/env sh

set -e

echo ""
echo "Attempting to tag build with version: "$VERSION
echo ""

if [ "$VERSION" == "$CI_COMMIT_TAG" ]; then
    echo ""
    echo "$VERSION built from existing tag - no tagging required"
    echo ""
else
    export GIT_AUTHOR_NAME=$GITLAB_USER_NAME
    export GIT_AUTHOR_EMAIL=$GITLAB_USER_EMAIL
    export GIT_COMMITTER_NAME=$GITLAB_USER_NAME
    export GIT_COMMITTER_EMAIL=$GITLAB_USER_EMAIL
    export GIT_SSL_NO_VERIFY=true
    git tag -a $VERSION -m "CI tagged version $VERSION"
    git push --push-option=ci.skip $PROJECT_GIT_URL $VERSION
fi