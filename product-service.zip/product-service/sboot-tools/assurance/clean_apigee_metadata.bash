#!/usr/bin/env bash

clean_metadata() {
	local xml_file=$1/*/*.xml
	echo clean $xml_file
	sed -b -E -i \
		-e "/<CreatedAt>/d" \
		-e "/<CreatedBy>/d" \
		-e "/<LastModifiedAt>/d" \
		-e "/<LastModifiedBy>/d" \
		-e "/<ManifestVersion>/d" \
		-e "/<HostedManifestVersion>/d" \
		-e 's/(<(APIProxy|SharedFlowBundle)\S*)[[:space:]]+revision[[:space:]]*=[[:space:]]*"[0-9]+"[[:space:]]+(.+)/\1 \3/g' $xml_file
}

for bundle in apiproxies/*/* sharedflows/*/*; do
	if [ -d "$bundle" ]; then
		clean_metadata "$bundle"
	fi
done 
echo metadata cleaned. please check the changes with '`git diff`' before commiting
