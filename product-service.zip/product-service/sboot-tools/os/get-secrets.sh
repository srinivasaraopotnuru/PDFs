#!/usr/bin/env bash
#Gets all Opaque secrets and decodes them. Then prints them to cmd line.
#If you specify a param (a filter string), it will only output secret values containing this text.

set -e
START=$SECONDS

OPENSHIFT_DEPLOY_HOST=$OPENSHIFT_DEPLOY_SUBDOMAIN.$OPENSHIFT_DEPLOY_DOMAIN
if [ "" != "$OPENSHIFT_DEPLOY_PASSWD_B64" ]; then
    OPENSHIFT_DEPLOY_PASSWD=$(echo -n "$OPENSHIFT_DEPLOY_PASSWD_B64" | base64 --decode)
fi
echo "Connecting to $OPENSHIFT_DEPLOY_HOST as $OPENSHIFT_DEPLOY_USER"
oc login --insecure-skip-tls-verify=true -u "$OPENSHIFT_DEPLOY_USER" -p "$OPENSHIFT_DEPLOY_PASSWD" "$OPENSHIFT_DEPLOY_HOST"

PROJECTS=$(oc get projects | awk '{print $1}' | tr '\n' ' ')

for PROJECT in $PROJECTS
do
    if [ "$PROJECT" == "NAME" ];
    then
        continue
    fi

    echo ""
    oc project "$PROJECT"
    PROJECT_RESULTS=$(oc get secrets --field-selector type=Opaque -o jsonpath="{range .items[*]}SECNAME={.metadata.name} {..data.*} {end}" | tr -s '[[:space:]]' '\n' | uniq)
    echo "Gathered secrets"
    RESULTS="$RESULTS [$PROJECT] $PROJECT_RESULTS"
done

for RESULT in $RESULTS
do
    if expr $RESULT : [\[].*[\]] &> /dev/null; then
        RESULT="${RESULT//]}"
        RESULT="${RESULT//[}"
        PROJECT=$RESULT
        echo ""
        echo "Project: $PROJECT"
        continue
    fi
    if [[ $RESULT =~ ^SECNAME=.* ]];
    then
        echo "$RESULT"
        continue
    fi

    if [ "$RESULT" != "" ] && [ "$RESULT" != "<nil>" ]; then
      #Clear the value
      VALUE=
      DECODED=$(echo -n "$RESULT" | base64 --decode)
      if [ "" != "$1" ]; then
          if echo "$DECODED" | grep -i "$1" &> /dev/null; then
              VALUE=$DECODED
          fi
      else
          VALUE=$DECODED
      fi
      if [ "" != "$VALUE" ]; then
          echo "VALUE = $VALUE"
      fi
    fi
done

echo ""
DURATION=$(( SECONDS - START ))
echo "Completed in $DURATION seconds"
