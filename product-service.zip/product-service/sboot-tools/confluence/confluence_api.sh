
CreatePage() {
    #$1 = page name
    #$2 = parent ID
    #$3 = page body
    URL="https://atlassian-confluence.ybs.com/rest/api/content"
    VERB="POST"
    PAYLOAD='{
  "type":"page",
  "status": "current",
  "title":"'"$1"'",
  "space":{"key":"'"$CONFLUENCE_SPACE"'"},
  "ancestors": [
    {
      "id": "'"$2"'"
    }
  ],
  "body":{
    "storage":{
      "value":"'"$3"'",
      "representation":"storage"
    }
  }
}'
    ApiCall "$URL" "$VERB" "$PAYLOAD"
}

UpdatePage() {
    #$1 = page name
    #$2 = page ID
    #$3 = version
    #$4 = update messge
    #$5 = page body
    URL="https://atlassian-confluence.ybs.com/rest/api/content/$2"
    VERB="PUT"
    PAYLOAD='{
  "type":"page",
  "status": "current",
  "version": {"number": "'"$3"'", "minorEdit": "true", "message": "'"$4"'"},
  "title":"'"$1"'",
  "space":{"key":"'"$CONFLUENCE_SPACE"'"},
  "body":{
    "storage":{
      "value":"'"$5"'",
      "representation":"storage"
    }
  }
}'
    ApiCall "$URL" "$VERB" "$PAYLOAD"
}

AddLabel() {
    #$1 = page ID
    #$2 = label value
    URL="https://atlassian-confluence.ybs.com/rest/api/content/$1/label"
    VERB="POST"
    PAYLOAD='[{"prefix": "global", "name": "'"$2"'"}]'
    ApiCall "$URL" "$VERB" "$PAYLOAD"
}

ApiCall() {
    #$1 = URL to call
    #$2 = HTTP verb
    #$3 = PAYLOAD
    RESP=$(curl -k --write-out ''%{http_code}'' -u$CONFLUENCE_USERNAME:$CONFLUENCE_PASSWORD \
        -v -X "$2" "$1" \
        -H "Content-Type: application/json" -d "$3") || true
    HTTP_CODE="${RESP:${#RESP}-3}"
    BODY="${RESP:0:${#RESP}-3}"
    if [ ! "${HTTP_CODE:0:2}" = "20" ]; then
        echo "HTTP_CODE=$HTTP_CODE" >&2
        echo "BODY=$BODY" >&2
        exit 1
    fi
    NEW_PAGE_ID=$(echo $BODY | jq -r '.id')
    echo $NEW_PAGE_ID
}
