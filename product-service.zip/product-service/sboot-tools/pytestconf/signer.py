import hashlib
from base64 import b64encode

from ecdsa import SigningKey, util
from requests import PreparedRequest

STANDARD_HEADERS = {"accept", "authorization", "host"}

class Signer:

    def __init__(self, keys: {str: SigningKey}):
        self.keys = keys

    def sign_request(self, request: PreparedRequest):
        return self._sign_request(request)

    def create_ecdsa_signature(self, key_id: str, message: str):
        sig = self.keys[key_id].sign(message.encode('utf-8'), hashfunc=hashlib.sha256,
                                     sigencode=util.sigencode_der)
        sig = b64encode(sig).decode('utf-8')
        return sig

    def _sign_request(self, request: PreparedRequest):
        payload = f'(request-target): {request.method.lower()} {request.path_url}'

        for header in sorted(request.headers.keys()):
            header: str = header.lower()
            if header in STANDARD_HEADERS or (header.startswith("x-ybs-") and header != 'x-ybs-request-signature'):
                payload += f'\n{header}: {request.headers[header]}'

        if request.body:
            payload += f'\n(body): {request.body}'

        print('signing payload:')
        print(payload)

        key_id = request.headers.get('x-ybs-request-signature-key-id')

        request.headers['x-ybs-request-signature'] = self.create_ecdsa_signature(key_id, payload)

        return request
