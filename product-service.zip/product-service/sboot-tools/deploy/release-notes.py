# The release-notes module is deprecated, please use the release-notes image instead
import argparse
import re
from pathlib import Path

import os
import git as _git
import requests
import warnings
warnings.warn("The release-notes module is deprecated, please use the release-notes image instead", DeprecationWarning, stacklevel=2)

JIRA_REF_RE = re.compile(r'\[([A-Za-z]+-\d+).*\]', re.I)


def main(project_id, environment_name, private_token):
    deployments = [deployment['sha'] for deployment in get_deployments(project_id, private_token) if deployment['environment']['name'] == environment_name and deployment['status'] == 'success']

    repo = get_git()
    print(f'Version being deployed: {repo.git.describe(repo.head)}')
    rev_range = 'HEAD'

    if len(deployments) == 0:

      print('Version last deployed: Unreleased')

    else:

      last_deployed_commit = deployments[0]
      print(f'Version last deployed: {repo.git.describe(last_deployed_commit)}')
      rev_range = f'{last_deployed_commit}..HEAD' if last_deployed_commit else None

      proj_path = "[project-path]"
      ci_proj_path = os.getenv('CI_PROJECT_PATH')
      if ci_proj_path is not None:
        proj_path = ci_proj_path
      print("https://ecommgit.ybs.com/{}/-/compare/{}...{}".format(proj_path, last_deployed_commit, repo.git.describe(repo.head)))

    print_jira_refs(repo.git.log(rev_range, pretty='%s'))
    print("----------")
    try:
      print_code_changes(repo.git.log(rev_range, '--no-merges', pretty='%cE', shortstat=True))
    except Exception as e:
      print("Error retrieving changes", e)


def print_jira_refs(git_response):
    
    print('Jira ticket references:')

    jira_refs = set([ref.group(1) for ref in [JIRA_REF_RE.search(ref) for ref in git_response.splitlines()] if ref])
    refs_list = sorted(jira_refs, key=str.lower)
    for ref in refs_list:
        print(ref)


def print_code_changes(git_response):

    print('Code changes:')
    git_response = re.sub('\@.*', '', git_response)
    git_response = re.sub('\n\n', '\n', git_response)
    changes_list = []
    for line in git_response.splitlines():
      if "changed" in line or "insertion" in line or "deletion" in line:
        changes_list[len(changes_list)-1] = changes_list[len(changes_list)-1] + line
      else:
        changes_list.append(line)
    changes_list.sort()

    aggregate_list = []
    cur_name = ""
    cur_changes = 0
    cur_inserts = 0
    cur_deletes = 0
    for change in changes_list:

      matches = re.search("([A-Za-z]+) (\d+) files? changed(, (\d+) insertions?\(\+\))?(, (\d+) deletion)?", change)
      if matches is not None:
        name = matches.group(1)
        changes = matches.group(2)
        inserts = matches.group(4)
        if inserts is None:
          inserts = 0
        deletes = matches.group(6)
        if deletes is None:
          deletes = 0

        if cur_name == "" or name.lower() == cur_name.lower():
          cur_name = name
          cur_changes += int(changes)
          cur_inserts += int(inserts)
          cur_deletes += int(deletes)
        else:
          aggregate_list.append(cur_name + ": " + str(cur_changes) + " files changed, " + str(cur_inserts) + " insertions(+), " + str(cur_deletes) + " deletions(-), " + str(cur_inserts - cur_deletes) + " net")
          cur_name = name
          cur_changes = int(changes)
          cur_inserts = int(inserts)
          cur_deletes = int(deletes)
    aggregate_list.append(cur_name + ": " + str(cur_changes) + " files changed, " + str(cur_inserts) + " insertions(+), " + str(cur_deletes) + " deletions(-), " + str(cur_inserts - cur_deletes) + " net")

    for aggregate_change in aggregate_list:
      print(aggregate_change)


def get_deployments(project_id, private_token):
    headers = {'PRIVATE-TOKEN': private_token}
    url = f'https://ecommgit.ybs.com/api/v4/projects/{project_id}/deployments?sort=desc&per_page=100'
    response = requests.get(url, headers=headers, verify=False)

    if response.status_code != 200:
        print(f'Response Code: {response.status_code}. Response Content: {response.content}')
        return []

    return response.json()


def get_git():
    path = Path.cwd()
    current = path.resolve()
    while str(current) != path.root:
        if (current / '.git').exists():
            return _git.Repo(current)

        current = current.parent

    raise (_git.InvalidGitRepositoryError(f'unable to find .git directory in any parent of {path}'))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Build environment specific service definition')
    parser.add_argument('project_id', help='ID of the project on ecommgit')
    parser.add_argument('environment_name', help='Name of the target environment')
    parser.add_argument('private_token', help='private gitlab token')
    args = parser.parse_args()
    main(args.project_id, args.environment_name, args.private_token)
