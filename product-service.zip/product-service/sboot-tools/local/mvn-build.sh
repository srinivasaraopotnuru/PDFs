#!/usr/bin/env sh
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
. "$gwd/sboot-tools/local/mvn-env.sh"

cd "$gwd/sboot-tools/maven"
echo `pwd`
echo $gwd

$gwd/sboot-tools/maven/mvnw install -f $gwd "$@"
