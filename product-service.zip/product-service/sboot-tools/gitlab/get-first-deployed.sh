#!/usr/bin/env bash
set -e

# Get a GITLAB_TOKEN token and export to GITLAB_TOKEN before running this script
if [ "$GITLAB_TOKEN" = "" ]; then
  echo "Please export your GitLab API token as GITLAB_TOKEN" >&2
  exit
fi
mkdir -p target

# Source the gitlab utils
. $(dirname "$0")/gitlab-utils.sh
GetAllDomainProjects

FROM_DATE=$1
TILL_DATE=$2

if [ "$FROM_DATE" == "" ]; then
  FROM_DATE="0000-00-00"
fi
if [ "$TILL_DATE" == "" ]; then
  TILL_DATE="9999-99-99"
fi

echo "Filtering first deployed pipelines between: $FROM_DATE to $TILL_DATE"

for PROJ_ID in $PROJ_IDS
do
  TAG=$(curl -s --request GET --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/repository/tags" | jq -r '.[0] | .name')
  if [ ! "$TAG" = 'null' ]; then
    PROJECT_NAME=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID" | jq -r '"\(.name) : \(.path_with_namespace)"')
    FIRST_DEPLOYED_DATE=""
    JOBS_PAGE=1
    JOBS_JSON=""
    while [ "$JOBS_JSON" != "[]" ]
    do
      JOBS_JSON=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/jobs?scope=success&page=$JOBS_PAGE&per_page=100")
      JOBS_PAGE=$(($JOBS_PAGE +1))
      DEPLOYED_DATE=$(echo "$JOBS_JSON" | jq -r '[.[] | select(.name == "deploy-prod" or .name == "deploy-to-prod")][0] | .finished_at')
      if [ "$DEPLOYED_DATE" != 'null' ]; then
        FIRST_DEPLOYED_DATE=$DEPLOYED_DATE
      fi
    done
    # echo "$PROJECT_NAME ($PROJ_ID)"
    if [[ "$FIRST_DEPLOYED_DATE" > "$FROM_DATE" || "$FIRST_DEPLOYED_DATE" == "$FROM_DATE" ]] && [[ "$FIRST_DEPLOYED_DATE" < "$TILL_DATE" ]]; then
      echo "$PROJECT_NAME ($PROJ_ID)"
      echo "FIRST_DEPLOYED_DATE=$FIRST_DEPLOYED_DATE"
    fi
  fi
done
