#!/usr/bin/env bash
set -e

# Get a GITLAB_TOKEN token and export to GITLAB_TOKEN before running this script
if [ "$GITLAB_TOKEN" = "" ]; then
  echo "Please export your GitLab API token as GITLAB_TOKEN" >&2
  exit
fi
mkdir -p target

# Source the gitlab utils
. $(dirname "$0")/gitlab-utils.sh
GetAllDomainProjects

# Get the job to highlight
jobPrefix=$1

for PROJ_ID in $PROJ_IDS
do
  PIPELINES=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/pipelines?status=running")
  if [ "$PIPELINES" != "[]" ]; then
    PROJECT_NAME=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID" | jq -r '.name')
    PIPELINE_IDS=$(echo "$PIPELINES" | jq '.[].id')
    for PIPELINE_ID in $PIPELINE_IDS
    do
      PIPELINE=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/pipelines/$PIPELINE_ID")
      STARTED_BY=$(echo "$PIPELINE" | jq -r '.user.name')
      PIPELINE_LINK=$(echo "$PIPELINE" | jq -r '.web_url')
      RUNNING_JOBS=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/pipelines/$PIPELINE_ID/jobs?scope[]=pending&scope[]=running" | jq '.[]')
      if [ "$RUNNING_JOBS" != "" ]; then
        echo "Found pipeline: $PIPELINE_ID, started by: $STARTED_BY, in project: $PROJECT_NAME; $PIPELINE_LINK"
        echo "$RUNNING_JOBS" | jq -r 'select(.name|test("^'"$jobPrefix"'")) | " ** \(.name) is \(.status) on \(.runner.description): \(.web_url)"'
        echo "$RUNNING_JOBS" | jq -r 'select(.name|test("^(?!'"$jobPrefix"')")) | "    \(.name) is \(.status) on \(.runner.description): \(.web_url)"'
      fi
    done
  fi
done
