#!/usr/bin/env bash
set -e

# Get a GITLAB_TOKEN token and export to GITLAB_TOKEN before running this script
if [ "$GITLAB_TOKEN" = "" ]; then
  echo "Please export your GitLab API token as GITLAB_TOKEN" >&2
  exit
fi
mkdir -p target

# Param 1 must be the CI/CD variables key you want to update.
VAR_KEY=$1
# Param 2 must be the regex to filter on values you want to update.
OLD_VALUE_REGEX=$2
# Param 3 must be the the new value you want to update.
NEW_VALUE=$3

if [ "$VAR_KEY" = "" ]; then
  echo "Please provide a VAR key that you want to find / update" >&2
  exit 1
fi
if [ "$NEW_VALUE" = "" ]; then
  echo "Finding vars with key: $VAR_KEY (filter regex: $OLD_VALUE_REGEX)"
else
  echo "Updating vars with key: $VAR_KEY (filter regex: $OLD_VALUE_REGEX)"
fi

# Source the gitlab utils
. $(dirname "$0")/gitlab-utils.sh
GetAllGroups
GetAllProjects

# Function to update CI/CD vars in either GitLab group or project
UpdateCiVariable() {
  #$1 = project or group type
  #$2 = project or group ID
  #$3 = variable key
  #$4 = variable value regex
  #$5 = variable new value
  VARIABLES=$(curl -ks --write-out ''%{http_code}'' --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/$1s/$2/variables/$3")
  HTTP_CODE="${VARIABLES:${#VARIABLES}-3}"
  VARS_JSON="${VARIABLES:0:${#VARIABLES}-3}"
  #echo "$HTTP_CODE"
  if [ "$HTTP_CODE" = "200" ] && [ "$VARS_JSON" != "[]" ]; then
    PROJ_NAME=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/$1s/$2" | jq -r '.name')
    echo "${1^}: $PROJ_NAME (ID: $2)"
    oldValue=$(echo "$VARS_JSON" | jq -r '.value')
    if [[ "$oldValue" =~ $4 ]]; then
      echo "$VARS_JSON"
      if [ "$5" != "" ]; then
        curl -ks -X PUT --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/$1s/$2/variables/$3" --form "value=$5"
        echo ""
        echo "Updated to new value"
      fi
    fi
  fi
}

for GROUP_ID in $GROUP_IDS
do
  UpdateCiVariable "group" "$GROUP_ID" "$VAR_KEY" "$OLD_VALUE_REGEX" "$NEW_VALUE"
done

for PROJ_ID in $PROJ_IDS
do
  UpdateCiVariable "project" "$PROJ_ID" "$VAR_KEY" "$OLD_VALUE_REGEX" "$NEW_VALUE"
done
