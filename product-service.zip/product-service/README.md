# Product Service
### What it's for
The Product Service provides information about the configuration of the
 products available to customers. This includes things like the minimum and
 maximum balances, the interest rate, the number of withdrawals and deposits
 permitted and so on.

### JWT validation
This service validates all requests received, by inspecting the "Authorization" header 
and unpacking the signed JWT therein. There are tests which create signed JWTs if you're 
curious about the structure of the JWT the service expects to receive. We check that the 
JWT is signed by Apigee by means of a public key in PEM format which we expect to find
as a property or environment variable. There's one in the application.properties file which 
will illustrate how to provide it to the service. Note that it MUST contain newlines otherwise 
it is considered invalid. 
Once we've established that the JWT was signed by Apigee's private key, then we
proceed to check the audience, subject, brand-code, scope and valid-from date before
allowing the request to continue

### Secret environment variables
Secret environment variables can be exported in a script mounted at '/usr/src/load_secrets.sh'
In order to start up, this service expects the following secret environment variables:
* PRODUCT_DB_PASSWORD = password for connecting to the product db

### E2E tests against the API are run as part of the pipeline

### Building locally
* The developer will need to create their own Artifatory API Key for local builds (see https://www.jfrog.com/confluence/display/JFROG/User+Profile#UserProfile-APIKey)
* The developer will need to set the following in the $HOME/.gradle/gradle.properties:
  * artifactory_username=[Your uXXXXXX username]
  * artifactory_password=[Your API Key]
  * artifactory_contextUrl=https://artifactory.ybs.com/artifactory

## GitLab pipeline
The pipeline inherits from a shared pipeline.
See the [README](https://ecommgit.ybs.com/ybs/enterprise/digital/shared-pipeline-library#services-pipeline) for more information

## Setting up IntelliJ

Note that these instructions won't work properly until the service is changed to build using
Java 11. This is due to the latest version of the formatter not supporting Java 8, so the build
runs an older version, whilst the plugin runs the latest version in the IDE Java 11 runtime which 
results in slightly different output. For now the formatter must be invoked via Gradle:
`./gradlew spotlessJavaApply`

1. Install the [google-java-format](https://plugins.jetbrains.com/plugin/8527-google-java-format) plugin.
2. Add intellij format file for import order:
    1. Go to `Preferences/Settings > Editor > Code Style > Java`
    2. Click the cog next to the Scheme drop down
    3. Go to `Import Scheme > Intellij IDEA code style XML`
    4. Import `assurance/intellij-java-google-style.xml`

## Setting up Git

### Check for formatting before commit

create the file `.git/hooks/pre-commit` with the contents:

```
#!/bin/sh

# Stash instaged changes so they trigger a potential failure
git stash --keep-index > /dev/null

./gradlew spotlessJavaCheck > /dev/null
result=$?

if [ $result -ne 0 ]; then
	echo Commit failed: staged code is not formatted correctly. Please run ./gradlew spotlessJavaApply and stage the changes before commiting
fi

# Reapply stashed changes
git stash pop > /dev/null

exit $result
```

and make sure it's executable bit is set for your user:

```
chmod u+x .git/hooks/pre-commit
```

### Ignore large formatting changes in git blame
git config blame.ignoreRevsFile .git-blame-ignore-revs
