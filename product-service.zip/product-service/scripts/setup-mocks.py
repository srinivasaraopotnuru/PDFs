import base64
import json
import logging
import os
import requests

logging.basicConfig(level=logging.DEBUG)
env_name = os.getenv('ENVIRONMENT_NAME').split("/", 1)[-1]


def load_mock(mock_name):
    with open('mocks/' + mock_name) as f:
        file_data = f.read()

    data_bytes = file_data.encode('ascii')
    base64_bytes = base64.b64encode(data_bytes)
    base64_data = base64_bytes.decode('ascii')

    return base64_data


GET_LIFERAY_PRODUCTLIST_DOCUMENT = {
  "id": "liferay-productlist-dflt",
  "httpRequest": {
    "path": "/liferay-cms/v1/o/headless-delivery/v1.0/documents/1734932",
  },
  "httpResponse": {
    "headers": {
      "content-type": ["application/json"]
    },
    "body": {
      "contentValue": load_mock(
        f'website/{env_name}/product-list.json')
    }
  },
  "times": {
    "unlimited": True
  },
  "timeToLive": {
    "unlimited": True
  },
  "priority": -1000
}

if env_name == 'dev' or env_name == 'test':
    # Add each exception to array
    expectations = [GET_LIFERAY_PRODUCTLIST_DOCUMENT]

    # Set all Expectations in 1 put request
    requests.put(
      url=f"https://ds-mocks-{env_name}.apps.ostest.ybs.com"
          f"/mockserver/expectation",
      data=json.dumps(expectations), allow_redirects=False,
      verify=False)
