import base64
import hashlib
import json
import os
import uuid

import jsonschema
import requests
from ecdsa import SigningKey

import config
from signer import Signer

protocol = os.getenv('SERVICE_PROTOCOL', 'http://')
host = os.getenv('SERVICE_HOST', 'localhost:8080')
registration_service_protocol = os.getenv('REGISTRATION_SERVICE_PROTOCOL', protocol)
registration_service_host = os.getenv('REGISTRATION_SERVICE_HOST', host)
registration_service_host = registration_service_host.replace("authentication-", "registration-")

request_id = 'b5620cac-8541-4459-b8c5-8fba67054395'  # static request id makes it easier to trace requests in the logs
party_id = 3656867

request_signing_key_id_public = 'apigee-nonprod-1'
request_signing_key_id_private = 'yoa-psd2-nonprod-1'
sca_signing_key_id = 'sca-key'
request_signing_private_key_public = SigningKey.from_pem(config.request_signing_private_key_public, hashlib.sha256)
request_signing_private_key_private = SigningKey.from_pem(config.request_signing_private_key_private, hashlib.sha256)
sca_private_key = SigningKey.from_pem(config.sca_private_key, hashlib.sha256)

signer = Signer({
    request_signing_key_id_public: request_signing_private_key_public,
    request_signing_key_id_private: request_signing_private_key_private,
    sca_signing_key_id: sca_private_key
})

get_assertion_response_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "publicKey": {
            "type": "object",
            "required": ["challenge", "rpId", "timeout"],
            "properties": {
                "challenge": {"type": "string"},
                "rpId": {"type": "string"},
                "timeout": {"type": "integer"}
            }
        }
    }
}

expected_customer_json_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "customerNumber": {
            "pattern": str(party_id)
        },
        "partyId": {
            "pattern": str(party_id)
        },
        "forename": {
            "type": "string"
        },
        "surname": {
            "type": "string"
        },
        "title": {
            "type": "string"
        }
    },
    "additionalProperties": True
}


# Ensure our party has a valid registration before we run the tests
def register_public_key():
    registration_id = str(uuid.uuid4())
    base_url = f'{registration_service_protocol}{registration_service_host}/registration'
    print("base_url", base_url)

    headers = {
        'x-ybs-request-signature-key-id': request_signing_key_id_public,
        'x-ybs-request-id': request_id,
        'x-ybs-channel': 'SAPP',
        'x-ybs-brand-code': 'YBS',
        'host': registration_service_host,
        'accept': 'application/json'
    }

    url = f'{base_url}/register'
    body = {
        "registrationId": registration_id,
        "partyId": party_id,
        "appCode": "SAPP"
    }
    request = requests.Request('post', url, headers=headers, json=body).prepare()
    signer.sign_request(request)
    response = requests.session().send(request, verify=False)

    assert response.status_code == 200, f'failed to register party [{party_id}]: {response.text}'

    public_key = sca_private_key.get_verifying_key().to_pem().decode('utf-8')
    url = f'{base_url}/certificates'
    body = {
        **body,
        "apiKey": public_key,
        "scaKey": public_key,
        "sessionId": str(uuid.uuid4()),
        "verificationMethod": "BIOMETRIC",
        "customer": {
            "title": "Mr",
            "firstName": "John",
            "lastName": "Smith",
            "email": "YBSSavingsApp@ybs.co.uk"
        }
    }
    request = requests.Request('post', url, headers=headers, json=body).prepare()
    signer.sign_request(request)
    response = requests.session().send(request, verify=False)

    assert response.status_code == 200, f'failed to register public keys'

    return registration_id


def test_report_failure_successful():
    registration_id = register_public_key()
    get_assertion_base_url = f'{protocol}{host}/auth/assertion/{party_id}'
    validate_assertion_base_url = f'{protocol}{host}/auth/assertion'
    report_failure_base_url = f'{protocol}{host}/auth/failure'

    headers = {
        'x-ybs-request-signature-key-id': request_signing_key_id_public,
        'x-ybs-request-id': request_id,
        'x-ybs-channel': 'SAPP',
        'x-ybs-brand-code': 'YBS',
        'host': host,
        'accept': 'application/json'
    }

    challenge_parameters = {'response_type': 'code', 'client_id': 'foobar'}

    request = requests.Request('get', get_assertion_base_url, headers=headers, params=challenge_parameters).prepare()
    signer.sign_request(request)
    response = requests.session().send(request, verify=False)

    assert response.status_code == 200, response.text

    response = response.json()

    challenge = response['publicKey']['challenge']
    signature = signer.create_ecdsa_signature(sca_signing_key_id, challenge)

    client_data = {
        'verificationMethod': 'BIOMETRIC',
        'challenge': challenge,
        'origin': 'digital-api.ybs.com',
        'type': 'webauthn.get'
    }
    client_data_json = base64.b64encode(json.dumps(client_data).encode('utf-8')).decode('utf-8')
    body = {
        'id': registration_id,
        'type': 'public-key',
        'response': {
            'signature': signature,
            'clientDataJson': client_data_json
        }
    }

    request = requests.Request('post', validate_assertion_base_url, headers=headers, json=body).prepare()
    signer.sign_request(request)
    response = requests.session().send(request, verify=False)

    assert response.status_code == 400, response.text

    body = {
        'registrationId': register_public_key(),
        'challenge': challenge,
        'verificationMethod': 'BIOMETRIC'
    }

    request = requests.Request('post', report_failure_base_url, headers=headers, json=body).prepare()
    signer.sign_request(request)
    response = requests.session().send(request, verify=False)

    assert response.status_code == 204, response.text


def test_successful_login():
    successful_login(f'{protocol}{host}/auth/assertion/{party_id}',
                     f'{protocol}{host}/auth/assertion',
                     request_signing_key_id_public,
                     {'response_type': 'code', 'client_id': 'foobar'},
                     None)


def test_private_successful_login():
    successful_login(f'{protocol}{host}/auth/private/assertion/{party_id}',
                     f'{protocol}{host}/auth/private/assertion',
                     request_signing_key_id_private,
                     {'request_digest': 'requestDigestValue'},
                     {'request_digest': 'requestDigestValue'})


def successful_login(endpoint_get_assertion, endpoint_validation_assertion, request_signing_key_id,
                     challenge_parameters, challenge_validation_data):
    registration_id = register_public_key()

    headers = {
        'x-ybs-request-signature-key-id': request_signing_key_id,
        'x-ybs-request-id': request_id,
        'x-ybs-channel': 'SAPP',
        'x-ybs-brand-code': 'YBS',
        'host': host,
        'accept': 'application/json'
    }

    request = requests.Request('get', endpoint_get_assertion, headers=headers, params=challenge_parameters).prepare()
    signer.sign_request(request)
    response = requests.session().send(request, verify=False)

    assert response.status_code == 200, response.text

    response = response.json()

    jsonschema.validate(response, get_assertion_response_schema)

    assert response['publicKey']['timeout'] == 60000
    assert response['publicKey']['rpId'] == 'ybs.co.uk'

    challenge = response['publicKey']['challenge']
    signature = signer.create_ecdsa_signature(sca_signing_key_id, challenge)

    client_data = {
        'verificationMethod': 'BIOMETRIC',
        'challenge': challenge,
        'origin': 'digital-api.ybs.co.uk',
        'type': 'webauthn.get'
    }
    client_data_json = base64.b64encode(json.dumps(client_data).encode('utf-8')).decode('utf-8')
    body = {
        'id': registration_id,
        'type': 'public-key',
        'response': {
            'signature': signature,
            'clientDataJson': client_data_json
        }
    }
    if challenge_validation_data:
        body['challengeValidationData'] = challenge_validation_data

    request = requests.Request('post', endpoint_validation_assertion, headers=headers, json=body).prepare()
    signer.sign_request(request)
    response = requests.session().send(request, verify=False)

    assert response.status_code == 200, response.text

    response = response.json()

    assert response['sessionId'] is not None, 'no session id returned'
    assert response['registrationId'] == registration_id, 'invalid registration id returned'
    assert response['verificationMethod'] == 'BIOMETRIC', 'unexpected verification method returned'
    assert response['challengeParameters'] == challenge_parameters, 'original challenge parameters not returned'
    assert response['brandCode'] == 'YBS', 'unexpected brand code returned'
    assert response['channel'] == 'SAPP', 'unexpected channel returned'

    login_details = response['login']

    assert login_details['partyId'] is not None, 'no party id returned'
    assert login_details['loginTime'] is not None, 'no login time returned'
    assert login_details['lastLoginTime'] is not None, 'no last login time returned'

    customer_details = response['customer']

    jsonschema.validate(customer_details, expected_customer_json_schema)

    print(response)
