# Smoke tests

From the smoke-tests directory run the following to install the required dependencies:

```
pipenv install
```

## Running against hosted service

test environment:
```
SMOKE_TARGET_ENV=test SERVICE_HOST=ds-login-test.nonprod.services.ybs.co.uk SERVICE_PROTOCOL=https:// pipenv run pytest
```

flex environment
```
SMOKE_TARGET_ENV=flex SERVICE_HOST=ds-login-flex.nonprod.services.ybs.co.uk SERVICE_PROTOCOL=https:// pipenv run pytest
```

## Running against a local service

The default target is `http://localhost:8080`, however this service needs to
interact with the Registration Service before it the tests run. By default the
registration target is the same as the registration target.

In order to run the test locally, you should specify the registration target e.g.

```
SMOKE_TARGET_ENV=test REGISTRATION_SERVICE_HOST=ds-login-test.nonprod.services.ybs.co.uk REGISTRATION_SERVICE_PROTOCOL=https:// pipenv run pytest
```

You can also specify the `SERVICE_HOST` as well if you are running the service
on a different port e.g.

```
SMOKE_TARGET_ENV=test SERVICE_HOST=localhost:8083 REGISTRATION_SERVICE_HOST=ds-login-test.nonprod.services.ybs.co.uk REGISTRATION_SERVICE_PROTOCOL=https:// pipenv run pytest
```

### Notes
- To see the output of print statements, you can run ```pipenv run pytest -s```
- The tests use environment variables to for the url
