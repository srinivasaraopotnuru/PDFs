#!/bin/bash
. ./sboot-tools/set-env.sh

export ARTIFACTORY_USERNAME=$AD_USERNAME
ARTIFACTORY_PASSWORD=$(echo -n "$AD_PASSWORD_B64" | base64 --decode)
export ARTIFACTORY_PASSWORD

set -a
. ./services/dev.env
set +a
intellij-idea-community .

##Clean up env vars
export ARTIFACTORY_USERNAME=
export ARTIFACTORY_PASSWORD=
