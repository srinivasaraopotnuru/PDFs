package uk.co.ybs.digital.authentication.service.challenge;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.google.common.collect.ImmutableMap;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;
import uk.co.ybs.digital.authentication.web.dto.request.ChallengeValidationData;

@ExtendWith(MockitoExtension.class)
class ChallengePayloadValidatorTest {

  private static final Long PARTY_ID = 123456L;

  private Clock clock = Clock.fixed(Instant.now(), ZoneId.systemDefault());

  private ChallengePayloadValidator challengePayloadValidator;

  @BeforeEach
  void setUp() {
    challengePayloadValidator = new ChallengePayloadValidator(clock);
  }

  @Test
  void shouldValidatePayload() {
    final ChallengePayload payload =
        ChallengePayload.builder()
            .sessionId(UUID.randomUUID())
            .partyId(PARTY_ID)
            .expiresAt(clock.instant().plusMillis(1))
            .parameters(buildChallengeParameters())
            .build();

    assertDoesNotThrow(() -> challengePayloadValidator.validate(payload, null));
  }

  @Test
  void shouldValidatePayloadWithChallengeValidationData() {
    final ChallengePayload payload =
        ChallengePayload.builder()
            .sessionId(UUID.randomUUID())
            .partyId(PARTY_ID)
            .expiresAt(clock.instant().plusMillis(1))
            .parameters(buildChallengeParameters())
            .build();
    final ChallengeValidationData challengeValidationData = buildChallengeValidationData();

    assertDoesNotThrow(() -> challengePayloadValidator.validate(payload, challengeValidationData));
  }

  @ParameterizedTest
  @ValueSource(longs = {0, 1})
  void validatePayloadShouldThrowChallengeValidationExceptionIfChallengeHasExpired(
      final long millis) {
    final ChallengePayload payload =
        ChallengePayload.builder()
            .sessionId(UUID.randomUUID())
            .partyId(PARTY_ID)
            .expiresAt(clock.instant().minusMillis(millis))
            .parameters(buildChallengeParameters())
            .build();
    final ChallengeValidationData challengeValidationData = buildChallengeValidationData();

    final ChallengeExpiredException ex =
        assertThrows(
            ChallengeExpiredException.class,
            () -> challengePayloadValidator.validate(payload, challengeValidationData));
    assertThat(ex.getMessage(), equalTo("Challenge has expired"));
  }

  @Test
  void validatePayloadShouldThrowChallengeValidationDataExceptionForMissingKey() {
    final ChallengePayload payload =
        ChallengePayload.builder()
            .sessionId(UUID.randomUUID())
            .partyId(PARTY_ID)
            .expiresAt(clock.instant().plusMillis(1))
            .parameters(buildChallengeParameters())
            .build();
    final ChallengeValidationData challengeValidationData =
        new ChallengeValidationData(
            ImmutableMap.<String, String>builder().put("new_key", "new_key_value").build());

    final ChallengeDataValidationFailedException ex =
        assertThrows(
            ChallengeDataValidationFailedException.class,
            () -> challengePayloadValidator.validate(payload, challengeValidationData));
    assertThat(ex.getMessage(), equalTo("No challenge parameter for key [new_key]"));
  }

  @Test
  void validatePayloadShouldThrowChallengeValidationDataExceptionForUnexpectedValue() {
    final ChallengePayload payload =
        ChallengePayload.builder()
            .sessionId(UUID.randomUUID())
            .partyId(PARTY_ID)
            .expiresAt(clock.instant().plusMillis(1))
            .parameters(buildChallengeParameters())
            .build();
    final ChallengeValidationData challengeValidationData =
        new ChallengeValidationData(
            ImmutableMap.<String, String>builder()
                .put("key1", "key1_value")
                .put("key2", "key2_value_modified")
                .build());

    final ChallengeDataValidationFailedException ex =
        assertThrows(
            ChallengeDataValidationFailedException.class,
            () -> challengePayloadValidator.validate(payload, challengeValidationData));
    assertThat(
        ex.getMessage(),
        equalTo(
            "Expected challenge parameter [key2_value_modified] for key [key2] but got [key2_value]"));
  }

  private ChallengeParameters buildChallengeParameters() {
    return new ChallengeParameters(
        ImmutableMap.<String, String>builder()
            .put("key1", "key1_value")
            .put("key2", "key2_value")
            .build());
  }

  private ChallengeValidationData buildChallengeValidationData() {
    return new ChallengeValidationData(
        ImmutableMap.<String, String>builder()
            .put("key1", "key1_value")
            .put("key2", "key2_value")
            .build());
  }
}
