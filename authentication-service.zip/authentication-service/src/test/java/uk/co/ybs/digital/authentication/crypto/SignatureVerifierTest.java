package uk.co.ybs.digital.authentication.crypto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.io.StringReader;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.util.Random;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.authentication.TestHelper;

class SignatureVerifierTest {
  @BeforeAll
  static void setUp() {
    Security.addProvider(new BouncyCastleProvider());
  }

  private static final String SECURITY_ALGORITHM = "SHA256WithECDSA";

  @Test
  void signatureVerifierShouldReturnTrueIfSignatureIsCorrect() throws Exception {
    byte[] payload = new byte[20]; // NOPMD
    new Random().nextBytes(payload);

    String privatePem = TestHelper.readResource("crypto/ec-private.pem");
    PEMKeyPair keyPair = (PEMKeyPair) new PEMParser(new StringReader(privatePem)).readObject();
    PrivateKey privateKey = BouncyCastleProvider.getPrivateKey(keyPair.getPrivateKeyInfo());
    PublicKey publicKey = BouncyCastleProvider.getPublicKey(keyPair.getPublicKeyInfo());
    Signature signer = Signature.getInstance(SECURITY_ALGORITHM, "BC");
    signer.initSign(privateKey);
    signer.update(payload);
    byte[] signature = signer.sign();

    assertTrue(new SignatureVerifier(signer, publicKey).verify(payload, signature));
  }

  @Test
  void signatureVerifierShouldReturnFalseIfSignatureIsIncorrect() throws Exception {
    byte[] payload = new byte[20]; // NOPMD

    new Random().nextBytes(payload);

    String privatePem = TestHelper.readResource("crypto/ec-different-private.pem");
    String publicPem = TestHelper.readResource("crypto/ec-public.pem");

    PEMKeyPair keyPair = (PEMKeyPair) new PEMParser(new StringReader(privatePem)).readObject();
    SubjectPublicKeyInfo publicKeyInfo =
        (SubjectPublicKeyInfo) new PEMParser(new StringReader(publicPem)).readObject();

    PrivateKey privateKey = BouncyCastleProvider.getPrivateKey(keyPair.getPrivateKeyInfo());
    PublicKey publicKey = BouncyCastleProvider.getPublicKey(publicKeyInfo);

    Signature signer = Signature.getInstance(SECURITY_ALGORITHM, "BC");
    signer.initSign(privateKey);
    signer.update(payload);
    byte[] signature = signer.sign();

    assertFalse(new SignatureVerifier(signer, publicKey).verify(payload, signature));
  }

  @Test
  void signatureShouldReturnFalseIfSignatureDecodingFails() throws Exception {
    byte[] payload = new byte[20]; // NOPMD
    byte[] signature = new byte[20]; // NOPMD

    Random random = new Random();
    random.nextBytes(payload);
    random.nextBytes(signature);

    String publicPem = TestHelper.readResource("crypto/ec-public.pem");
    SubjectPublicKeyInfo publicKeyInfo =
        (SubjectPublicKeyInfo) new PEMParser(new StringReader(publicPem)).readObject();
    PublicKey publicKey = BouncyCastleProvider.getPublicKey(publicKeyInfo);

    assertFalse(
        new SignatureVerifier(Signature.getInstance(SECURITY_ALGORITHM), publicKey)
            .verify(payload, signature));
  }

  @Test
  void signatureShouldThrowCryptoExceptionIfPublicKeyDoesNotWorkWithTheAlgorithm()
      throws Exception {
    byte[] payload = new byte[20]; // NOPMD
    byte[] signature = new byte[20]; // NOPMD

    Random random = new Random();
    random.nextBytes(payload);
    random.nextBytes(signature);

    String publicPem = TestHelper.readResource("crypto/rsa-public.pem");
    SubjectPublicKeyInfo publicKeyInfo =
        (SubjectPublicKeyInfo) new PEMParser(new StringReader(publicPem)).readObject();
    PublicKey publicKey = BouncyCastleProvider.getPublicKey(publicKeyInfo);

    CryptoException ex =
        assertThrows(
            CryptoException.class,
            () ->
                new SignatureVerifier(Signature.getInstance(SECURITY_ALGORITHM), publicKey)
                    .verify(payload, signature));
    assertThat(ex.getMessage(), equalTo("Attempted to validate signature with invalid key"));
  }
}
