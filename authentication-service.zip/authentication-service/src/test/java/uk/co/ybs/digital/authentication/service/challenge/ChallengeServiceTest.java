package uk.co.ybs.digital.authentication.service.challenge;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.doReturn;

import com.google.common.collect.ImmutableMap;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneId;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.authentication.crypto.JwsCodec;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;

@ExtendWith(MockitoExtension.class)
class ChallengeServiceTest {

  private static final Long PARTY_ID = 123456L;

  @Mock private JwsCodec jwsCodec;

  private Clock clock = Clock.fixed(Instant.now(), ZoneId.systemDefault());

  private ChallengeService challengeService;

  @BeforeEach
  void setUp() {
    challengeService = new ChallengeService(jwsCodec, clock);
  }

  @Test
  void getChallengeShouldSerializeAndEncodeTheQueryParameters() {
    final UUID sessionId = UUID.randomUUID();
    final ChallengeParameters challengeParameters = buildChallengeParameters();

    final ChallengePayload payload =
        ChallengePayload.builder()
            .sessionId(sessionId)
            .partyId(PARTY_ID)
            .expiresAt(clock.instant().plusMillis(1))
            .parameters(challengeParameters)
            .build();

    final String encoded = "encoded";

    doReturn(encoded).when(jwsCodec).encode(payload);

    final String challenge =
        challengeService.getChallenge(
            sessionId, PARTY_ID, challengeParameters, Duration.ofMillis(1));
    assertThat(challenge, is(encoded));
  }

  @Test
  void verifyChallengeShouldReturnChallengePayloadIfChallengeIsValid() {
    final ChallengePayload payload =
        ChallengePayload.builder()
            .sessionId(UUID.randomUUID())
            .partyId(PARTY_ID)
            .expiresAt(clock.instant().plusMillis(1))
            .parameters(buildChallengeParameters())
            .build();

    final String encoded = "encoded";

    doReturn(payload).when(jwsCodec).decode(encoded, ChallengePayload.class);

    assertThat(challengeService.verifyChallenge(encoded), equalTo(payload));
  }

  private ChallengeParameters buildChallengeParameters() {
    return new ChallengeParameters(
        ImmutableMap.<String, String>builder()
            .put("client_id", "SavingsApp")
            .put("response_type", "code")
            .build());
  }
}
