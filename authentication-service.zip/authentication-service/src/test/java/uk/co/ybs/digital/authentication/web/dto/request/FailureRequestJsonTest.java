package uk.co.ybs.digital.authentication.web.dto.request;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.authentication.VerificationMethod;

@JsonTest
class FailureRequestJsonTest {

  @Autowired private JacksonTester<FailureRequest> jacksonTester;

  @Value("classpath:api/request/failure-request.json")
  private Resource expectedJson;

  @Test
  void deserializes() throws IOException {
    final FailureRequest request =
        FailureRequest.builder()
            .registrationId(UUID.fromString("feeabc1d-3a12-4ab1-b51d-6e74f1e38cb3"))
            .challenge("TheChallenge")
            .verificationMethod(VerificationMethod.BIOMETRIC)
            .build();

    assertThat(jacksonTester.read(expectedJson)).isEqualTo(request);
  }
}
