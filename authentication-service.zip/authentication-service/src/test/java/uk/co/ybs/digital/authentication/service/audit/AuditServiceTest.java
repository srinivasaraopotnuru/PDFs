package uk.co.ybs.digital.authentication.service.audit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.authentication.TestHelper.readResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.authentication.VerificationMethod;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginChallengeRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginFailureRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginSuccessRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.LoginFailureReason;
import uk.co.ybs.digital.authentication.service.audit.dto.UserSession;
import uk.co.ybs.digital.authentication.service.audit.dto.UserSessionBasic;

@JsonTest
class AuditServiceTest {

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Audit service returned error status: ";

  private AuditService auditService;
  private MockWebServer mockWebServer;

  private static final String FAILED_RESPONSE = "400";

  @Autowired // The Spring-configured ObjectMapper is configured to (de)serialize Instants
  private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();

    final WebClient webClient =
        WebClient.builder()
            .baseUrl("http://localhost:" + mockWebServer.getPort())
            .exchangeStrategies(
                config ->
                    config.codecs(
                        codecs -> {
                          codecs
                              .defaultCodecs()
                              .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                          codecs
                              .defaultCodecs()
                              .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                        }))
            .build();
    auditService = new AuditService(webClient);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void shouldAuditLoginChallenge() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final AuditLoginChallengeRequest request = buildValidAuditLoginChallengeRequest();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditLoginChallenge(request, requestId);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/login/challenge"));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));

    final String expectedBody = readResource("api/audit/login/request/challenge.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditLoginSuccess() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final AuditLoginSuccessRequest request = buildValidAuditLoginSuccessRequest();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditLoginSuccess(request, requestId);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/login/success"));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));

    final String expectedBody = readResource("api/audit/login/request/success.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditLoginFailure() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final AuditLoginFailureRequest request = buildValidAuditLoginFailureRequest();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditLoginFailure(request, requestId);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/login/failure"));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));

    final String expectedBody = readResource("api/audit/login/request/failure.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("auditMethods")
  void shouldThrowAuditServiceExceptionForConnectionError(
      final Function<AuditService, Executable> auditMethod) throws IOException {
    mockWebServer.shutdown();

    final AuditServiceException exception =
        assertThrows(AuditServiceException.class, auditMethod.apply(auditService));
    assertThat(exception.getMessage(), is(equalTo("Error calling audit service")));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  private static Stream<Function<AuditService, Executable>> auditMethods() {
    final UUID requestId = UUID.randomUUID();
    return Stream.of(
        service ->
            () -> service.auditLoginChallenge(buildValidAuditLoginChallengeRequest(), requestId),
        service -> () -> service.auditLoginSuccess(buildValidAuditLoginSuccessRequest(), requestId),
        service ->
            () -> service.auditLoginFailure(buildValidAuditLoginFailureRequest(), requestId));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses")
  void auditLoginChallengeShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final UUID requestId = UUID.randomUUID();
    final AuditLoginChallengeRequest auditRequest = buildValidAuditLoginChallengeRequest();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditLoginChallenge(auditRequest, requestId));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses")
  void auditLoginSuccessShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final UUID requestId = UUID.randomUUID();
    final AuditLoginSuccessRequest auditRequest = buildValidAuditLoginSuccessRequest();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditLoginSuccess(auditRequest, requestId));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses")
  void auditLoginFailureShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final UUID requestId = UUID.randomUUID();
    final AuditLoginFailureRequest auditRequest = buildValidAuditLoginFailureRequest();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditLoginFailure(auditRequest, requestId));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  private static Stream<Arguments> auditServiceErrorResponses() throws IOException {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readResource("api/audit/login/response/error-response-invalid-signature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readResource("api/audit/login/response/error-response-bad-request.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_RESPONSE),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readResource("api/audit/login/response/unexpected-response.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_RESPONSE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readResource("api/audit/login/response/empty-response.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_RESPONSE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readResource("api/audit/login/response/text-response.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_RESPONSE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readResource("api/audit/login/response/text-response.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_RESPONSE)));
  }

  private static AuditLoginChallengeRequest buildValidAuditLoginChallengeRequest() {
    return AuditLoginChallengeRequest.builder()
        .ipAddress("12.66.53.145")
        .userSession(
            UserSessionBasic.builderBasic()
                .sessionId(UUID.fromString("79c1ee70-6771-4bc5-8004-de707b582b69"))
                .partyId(1234567890L)
                .channel("SAPP")
                .brandCode("YBS")
                .build())
        .build();
  }

  private static AuditLoginSuccessRequest buildValidAuditLoginSuccessRequest() {
    return AuditLoginSuccessRequest.builder()
        .ipAddress("12.66.53.145")
        .userSession(
            UserSession.builder()
                .sessionId(UUID.fromString("79c1ee70-6771-4bc5-8004-de707b582b69"))
                .partyId(1234567890L)
                .channel("SAPP")
                .brandCode("YBS")
                .registrationId(UUID.fromString("597fa3f7-7e8d-45fc-a7c7-dfc8d5b83360"))
                .verificationMethod(VerificationMethod.BIOMETRIC)
                .build())
        .build();
  }

  private static AuditLoginFailureRequest buildValidAuditLoginFailureRequest() {
    return AuditLoginFailureRequest.builder()
        .reason(LoginFailureReason.BUSINESS)
        .message("Invalid Challenge Response")
        .ipAddress("12.66.53.145")
        .userSession(
            UserSession.builder()
                .sessionId(UUID.fromString("79c1ee70-6771-4bc5-8004-de707b582b69"))
                .partyId(1234567890L)
                .channel("SAPP")
                .brandCode("YBS")
                .registrationId(UUID.fromString("597fa3f7-7e8d-45fc-a7c7-dfc8d5b83360"))
                .verificationMethod(VerificationMethod.BIOMETRIC)
                .build())
        .build();
  }
}
