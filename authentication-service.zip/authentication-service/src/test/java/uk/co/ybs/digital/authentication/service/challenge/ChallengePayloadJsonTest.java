package uk.co.ybs.digital.authentication.service.challenge;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.common.collect.ImmutableMap;
import java.io.IOException;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;

@JsonTest
class ChallengePayloadJsonTest {

  @Autowired private JacksonTester<ChallengePayload> json;

  @Value("classpath:api/response/challenge-payload.json")
  private Resource expectedJson;

  private final ChallengePayload response =
      ChallengePayload.builder()
          .sessionId(UUID.fromString("a3575068-17bc-4ca9-b320-715b88501961"))
          .partyId(123456789L)
          .expiresAt(Instant.EPOCH)
          .parameters(
              new ChallengeParameters(
                  ImmutableMap.<String, String>builder()
                      .put("response_type", "code")
                      .put("client_id", "clientId")
                      .put("code_challenge", "codeChallenge")
                      .put("code_challenge_method", "S256")
                      .put("scope", "ACCOUNT_READ PAYMENT")
                      .put("state", "some-state")
                      .build()))
          .build();

  @Test
  void serialize() throws IOException {
    assertThat(json.write(response)).isEqualToJson(expectedJson, JSONCompareMode.STRICT);
  }

  @Test
  void deserialize() throws IOException {
    assertThat(json.read(expectedJson)).isEqualTo(response);
  }
}
