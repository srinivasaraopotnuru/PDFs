package uk.co.ybs.digital.authentication.service.audit.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class AuditLoginChallengeRequestJsonTest {
  @Autowired private JacksonTester<AuditLoginChallengeRequest> tester;

  @Value("classpath:api/audit/login/request/challenge.json")
  private Resource requestFile;

  private AuditLoginChallengeRequest request;

  @BeforeEach
  void beforeEach() {
    request =
        AuditLoginChallengeRequest.builder()
            .ipAddress("12.66.53.145")
            .userSession(
                UserSessionBasic.builderBasic()
                    .sessionId(UUID.fromString("79c1ee70-6771-4bc5-8004-de707b582b69"))
                    .partyId(1234567890L)
                    .channel("SAPP")
                    .brandCode("YBS")
                    .build())
            .build();
  }

  @Test
  void objectMapperSerializes() throws IOException {
    assertThat(tester.write(request)).isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }
}
