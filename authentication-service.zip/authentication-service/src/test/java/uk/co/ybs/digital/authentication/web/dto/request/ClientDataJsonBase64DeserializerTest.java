package uk.co.ybs.digital.authentication.web.dto.request;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import uk.co.ybs.digital.authentication.VerificationMethod;

@JsonTest
class ClientDataJsonBase64DeserializerTest {

  @Autowired ObjectMapper objectMapper;

  private ClientDataJsonBase64Deserializer deserializer;

  @BeforeEach
  private void setUp() { // NOPMD
    deserializer = new ClientDataJsonBase64Deserializer(objectMapper);
  }

  @Test
  void shouldParseValidClientDataJson() throws Exception {
    final ClientDataJson clientDataJson =
        ClientDataJson.builder()
            .type("public-key")
            .origin("digital-api.ybs.co.uk")
            .verificationMethod(VerificationMethod.BIOMETRIC)
            .challenge("TheChallenge")
            .build();

    final byte[] json = objectMapper.writeValueAsBytes(clientDataJson);

    JsonParser parser = buildParser(json); // NOPMD

    ClientDataJson result = deserializer.deserialize(parser, null);

    assertThat(result, equalTo(clientDataJson));
  }

  @Test
  void shouldThrowInvalidClientDataJsonExceptionIfValuesIsNotValidJson() throws IOException {
    JsonParser parser = objectMapper.getFactory().createParser("unquoted-string"); // NOPMD

    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class, () -> deserializer.deserialize(parser, null));

    assertThat(ex.getMessage(), startsWith("Unable to parse clientDataJson value"));
  }

  @Test
  void shouldThrowInvalidClientDataJsonExceptionIfValuesIsNotBase64Encoded() throws IOException {
    JsonParser parser = // NOPMD
        objectMapper.getFactory().createParser("\"non-base64 encoded string\"");

    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class, () -> deserializer.deserialize(parser, null));

    assertThat(ex.getMessage(), equalTo("clientDataJson is not a valid base64 encoded string"));
  }

  @Test
  void shouldThrowInvalidClientDataJsonExceptionIfDecodedPayloadIsNotValidJSON()
      throws IOException {
    JsonParser parser = buildParser("unquoted-string".getBytes(UTF_8)); // NOPMD

    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class, () -> deserializer.deserialize(parser, null));

    assertThat(ex.getMessage(), startsWith("Unable to parse clientDataJson:"));
  }

  @Test
  void shouldThrowInvalidClientDataJsonExceptionIfDecodedPayloadHasInvalidVerificationMethod()
      throws IOException {
    Map<String, String> payload = Collections.singletonMap("verificationMethod", "FOOBAR");
    JsonParser parser = buildParser(objectMapper.writeValueAsBytes(payload)); // NOPMD

    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class, () -> deserializer.deserialize(parser, null));

    assertThat(ex.getMessage(), equalTo("Unable to handle clientDataJson value: FOOBAR"));
  }

  @Test
  void shouldThrowInvalidClientDataJsonExceptionIfDecodedPayloadIfFieldIsMissing()
      throws IOException {
    Map<String, String> payload = Collections.emptyMap();
    JsonParser parser = buildParser(objectMapper.writeValueAsBytes(payload)); // NOPMD

    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class, () -> deserializer.deserialize(parser, null));

    assertThat(ex.getMessage(), startsWith("Unable to handle clientDataJson field"));
  }

  private JsonParser buildParser(final byte[] json) throws IOException {
    String encoded = Base64.getEncoder().encodeToString(json);
    return objectMapper.getFactory().createParser("\"" + encoded + "\"");
  }
}
