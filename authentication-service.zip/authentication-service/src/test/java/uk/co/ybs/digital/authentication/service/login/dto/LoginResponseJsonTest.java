package uk.co.ybs.digital.authentication.service.login.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.time.Instant;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
class LoginResponseJsonTest {

  private static final long PARTY_ID = 1234567890L;
  private static final String FORENAME = "John";
  private static final String SURNAME = "Smith";
  private static final String TITLE = "Mr";
  private static final String EMAIL = "john.smith@gmail.com";

  @Autowired private JacksonTester<LoginResponse> tester;

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void deserialize(final LoginResponse response, final ClassPathResource file) throws IOException {
    assertThat(tester.read(file)).isEqualTo(response);
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(
            buildLoginResponse(), new ClassPathResource("api/login/response/login-response.json")),
        Arguments.of(
            buildLoginResponseWithoutEmailAndTitle(),
            new ClassPathResource("api/login/response/login-response-without-email.json")));
  }

  private static LoginResponse buildLoginResponse() {
    return LoginResponse.builder()
        .customer(
            CustomerDetails.builder()
                .partyId(PARTY_ID)
                .forename(FORENAME)
                .surname(SURNAME)
                .title(TITLE)
                .email(EMAIL)
                .build())
        .login(
            LoginDetails.builder()
                .loginTime(Instant.parse("2019-04-02T10:21:41.894Z"))
                .lastLoginTime(Instant.parse("2019-04-01T23:35:04.329Z"))
                .build())
        .build();
  }

  private static LoginResponse buildLoginResponseWithoutEmailAndTitle() {
    return LoginResponse.builder()
        .customer(
            CustomerDetails.builder().partyId(PARTY_ID).forename(FORENAME).surname(SURNAME).build())
        .login(
            LoginDetails.builder()
                .loginTime(Instant.parse("2019-04-02T10:21:41.894Z"))
                .lastLoginTime(Instant.parse("2019-04-01T23:35:04.329Z"))
                .build())
        .build();
  }
}
