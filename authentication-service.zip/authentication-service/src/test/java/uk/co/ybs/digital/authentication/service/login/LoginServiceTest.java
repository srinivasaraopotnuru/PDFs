package uk.co.ybs.digital.authentication.service.login;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.models.HttpMethod;
import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.authentication.service.login.dto.CustomerDetails;
import uk.co.ybs.digital.authentication.service.login.dto.LoginDetails;
import uk.co.ybs.digital.authentication.service.login.dto.LoginResponse;
import uk.co.ybs.digital.authentication.web.dto.response.ErrorResponse;

@JsonTest
class LoginServiceTest {

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final UUID REQUEST_ID = UUID.randomUUID();

  private MockWebServer mockWebServer;
  private LoginService loginService;

  private static final String CONTENT_TYPE = "Content-Type";
  private static final String APPLICATION_JSON = "application/json";
  private static final String CUST_LOGIN_DENIED = "Customer login denied";

  @Autowired // The Spring-configured ObjectMapper is configured to (de)serialize Instants
  private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();
    WebClient webClient =
        WebClient.builder()
            .baseUrl("http://localhost:" + mockWebServer.getPort())
            .exchangeStrategies(
                config ->
                    config.codecs(
                        codecs -> {
                          codecs
                              .defaultCodecs()
                              .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                          codecs
                              .defaultCodecs()
                              .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                        }))
            .build();
    loginService = new LoginService(webClient);
  }

  @AfterEach
  void teardown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void loginServiceShouldReturnLoginDetailsOnSuccessfulLogin() throws Exception {
    final LoginRequest request = buildLoginRequest();
    final LoginResponse response = buildLoginDetails(request);

    final String body = objectMapper.writeValueAsString(response);
    mockWebServer.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final LoginResponse actual = loginService.login(REQUEST_ID, request);
    assertThat(actual, equalTo(response));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/login"));
    assertThat(recordedRequest.getHeader(REQUEST_ID_HEADER), is(REQUEST_ID.toString()));
    assertThat(
        objectMapper.readValue(recordedRequest.getBody().readUtf8(), LoginRequest.class),
        is(request));
  }

  @ParameterizedTest
  @MethodSource("loginDeniedErrorCodes")
  void loginServiceShouldReturnLoginDeniedExceptionIfResponseCodeIs403(
      final String errorCode, final LoginDeniedException.Reason reason)
      throws JsonProcessingException {
    LoginRequest request = buildLoginRequest();
    ErrorResponse response =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(UUID.randomUUID())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(errorCode)
                    .message(CUST_LOGIN_DENIED)
                    .build())
            .build();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(objectMapper.writeValueAsString(response))
            .setResponseCode(403));

    LoginDeniedException ex =
        assertThrows(LoginDeniedException.class, () -> loginService.login(REQUEST_ID, request));
    assertThat(ex.getReason(), is(reason));
    assertThat(
        ex.getMessage(), is(String.format("Login denied for partyId %s", request.getPartyId())));
  }

  private static Stream<Arguments> loginDeniedErrorCodes() {
    return Stream.of(
        Arguments.of(
            "AccessDenied.LoginDenied.CustomerNotFoundCustomerHub",
            LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_CUSTOMER_HUB),
        Arguments.of(
            "AccessDenied.LoginDenied.CustomerNotFoundLdap",
            LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_LDAP),
        Arguments.of(
            "AccessDenied.LoginDenied.CustomerDeceased",
            LoginDeniedException.Reason.CUSTOMER_DECEASED),
        Arguments.of(
            "AccessDenied.LoginDenied.CustomerInvalidGroup",
            LoginDeniedException.Reason.CUSTOMER_INVALID_GROUP),
        Arguments.of(
            "AccessDenied.LoginDenied.CustomerInvalidPasswordState",
            LoginDeniedException.Reason.CUSTOMER_INVALID_PASSWORD_STATE));
  }

  @Test
  void loginServiceShouldThrowLoginServiceExceptionWhenMoreThatOneErrorCodeExpectedErrorCode()
      throws JsonProcessingException {
    LoginRequest request = buildLoginRequest();
    ErrorResponse response =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(UUID.randomUUID())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.LoginDenied.CustomerDeceased")
                    .message(CUST_LOGIN_DENIED)
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.LoginDenied.CustomerDeceased")
                    .message(CUST_LOGIN_DENIED)
                    .build())
            .build();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(objectMapper.writeValueAsString(response))
            .setResponseCode(HttpStatus.FORBIDDEN.value()));

    LoginServiceException ex =
        assertThrows(LoginServiceException.class, () -> loginService.login(REQUEST_ID, request));
    assertThat(
        ex.getMessage(),
        equalTo(String.format("Unexpected response from Login Service: %s", response)));
  }

  @Test
  void loginServiceShouldThrowLoginServiceExceptionWhenNoErrorCodes()
      throws JsonProcessingException {
    LoginRequest request = buildLoginRequest();
    ErrorResponse response =
        ErrorResponse.builder(HttpStatus.FORBIDDEN).id(UUID.randomUUID()).build();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(objectMapper.writeValueAsString(response))
            .setResponseCode(403));

    LoginServiceException ex =
        assertThrows(LoginServiceException.class, () -> loginService.login(REQUEST_ID, request));
    assertThat(
        ex.getMessage(),
        equalTo(String.format("Unexpected response from Login Service: %s", response)));
  }

  @ParameterizedTest
  @EnumSource(
      value = HttpStatus.class,
      names = {"FORBIDDEN", "SERVICE_UNAVAILABLE", "BAD_REQUEST", "NOT_FOUND"})
  void loginServiceShouldReturnLoginServiceExceptionIfResponseCodeIsNot200WithErrorResponse(
      final HttpStatus status) throws JsonProcessingException {
    LoginRequest request = buildLoginRequest();
    ErrorResponse response =
        ErrorResponse.builder(status)
            .id(UUID.randomUUID())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Error.Code")
                    .message(CUST_LOGIN_DENIED)
                    .build())
            .build();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(objectMapper.writeValueAsString(response))
            .setResponseCode(status.value()));

    LoginServiceException ex =
        assertThrows(LoginServiceException.class, () -> loginService.login(REQUEST_ID, request));
    assertThat(
        ex.getMessage(),
        equalTo(String.format("Unexpected response from Login Service: %s", response)));
  }

  @ParameterizedTest
  @EnumSource(
      value = HttpStatus.class,
      names = {"SERVICE_UNAVAILABLE", "BAD_REQUEST", "NOT_FOUND", "FORBIDDEN"})
  void loginServiceShouldReturnLoginServiceExceptionIfResponseCodeIsNot200WithoutErrorResponse(
      final HttpStatus status) {
    LoginRequest request = buildLoginRequest();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setResponseCode(status.value()));

    LoginServiceException ex =
        assertThrows(LoginServiceException.class, () -> loginService.login(REQUEST_ID, request));
    assertThat(
        ex.getMessage(),
        equalTo(String.format("Unexpected status code from Login Service: %s", status)));
  }

  @Test
  void loginServiceShouldReturnLoginServiceErrorIfResponseContentTypeIsNotJson() throws Exception {
    LoginRequest request = buildLoginRequest();
    LoginResponse response = buildLoginDetails(request);

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, "application/text")
            .setBody(objectMapper.writeValueAsString(response)));

    LoginServiceException ex =
        assertThrows(LoginServiceException.class, () -> loginService.login(REQUEST_ID, request));
    assertThat(
        ex.getMessage(),
        containsString(
            "Content type 'application/text' not supported for bodyType=uk.co.ybs.digital.authentication.service.login.dto.LoginResponse"));
  }

  @Test
  void loginServiceShouldReturnLoginServiceExceptionIfResponseIsNotAValidLoginResponseObject()
      throws Exception {
    LoginRequest request = buildLoginRequest();

    mockWebServer.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody("{}"));

    LoginServiceException ex =
        assertThrows(LoginServiceException.class, () -> loginService.login(REQUEST_ID, request));
    assertThat(
        ex.getMessage(),
        startsWith("Unhandled error when calling Login Service: JSON decoding error"));
  }

  @Test
  void loginServiceShouldReturnLoginServiceExceptionIfResponseBodyDoesNotExist() throws Exception {
    LoginRequest request = buildLoginRequest();

    mockWebServer.enqueue(new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON));

    LoginServiceException ex =
        assertThrows(LoginServiceException.class, () -> loginService.login(REQUEST_ID, request));
    assertThat(
        ex.getMessage(), startsWith("Received successful response but no body from login service"));
  }

  private static LoginResponse buildLoginDetails(final LoginRequest request) {
    Instant now = Instant.now();
    return LoginResponse.builder()
        .customer(
            CustomerDetails.builder()
                .partyId(request.getPartyId())
                .title("Mr")
                .forename("Joe")
                .surname("Bloggs")
                .email("joe.bloggs@gmail.com")
                .build())
        .login(
            LoginDetails.builder()
                .loginTime(now)
                .lastLoginTime(now.minus(Duration.ofDays(1)))
                .build())
        .build();
  }

  private static LoginRequest buildLoginRequest() {
    return LoginRequest.builder().partyId(new Random().nextLong()).brandCode("YBS").build();
  }
}
