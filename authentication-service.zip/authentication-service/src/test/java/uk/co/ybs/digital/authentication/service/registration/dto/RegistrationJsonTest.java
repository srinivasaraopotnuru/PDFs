package uk.co.ybs.digital.authentication.service.registration.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class RegistrationJsonTest {

  @Autowired private JacksonTester<Registration> tester;

  @Value("classpath:api/registration/response/registration-response.json")
  private Resource file;

  private Registration registration;

  @BeforeEach
  void setUp() {
    registration =
        Registration.builder()
            .partyId(1234567890L)
            .registrationId(UUID.fromString("cd428499-10f8-4362-8051-7338d7d5cd1e"))
            .status("REGISTERED")
            .scaKey("pem")
            .build();
  }

  @Test
  void deserialize() throws IOException {
    assertThat(tester.read(file)).isEqualTo(registration);
  }
}
