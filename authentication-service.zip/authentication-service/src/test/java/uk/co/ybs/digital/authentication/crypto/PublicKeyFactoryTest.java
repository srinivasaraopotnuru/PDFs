package uk.co.ybs.digital.authentication.crypto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.authentication.TestHelper.readResource;

import java.security.PublicKey;
import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class PublicKeyFactoryTest {
  @BeforeAll
  static void setUp() {
    Security.addProvider(new BouncyCastleProvider());
  }

  @Test
  void publicKeyFactoryShouldBuildPublicKeyFromValidPEM() throws Exception {
    String pem = readResource("crypto/ec-public.pem");
    PublicKey key = new PublicKeyFactory().fromPem(pem);
    assertThat(key.getAlgorithm(), equalTo("EC"));
  }

  @Test
  void publicKeyFactoryShouldThrowExceptionIfPemIsNull() {
    CryptoException ex =
        assertThrows(CryptoException.class, () -> new PublicKeyFactory().fromPem(null));
    assertThat(
        ex.getMessage(), equalTo("Unexpected error occurred when attempting to build public key"));
  }

  @Test
  void publicKeyFactoryShouldThrowCryptoExceptionIfKeyIsNotInPemFormat() {
    CryptoException ex =
        assertThrows(CryptoException.class, () -> new PublicKeyFactory().fromPem("foobar"));
    assertThat(
        ex.getMessage(), equalTo("Unexpected error occurred when attempting to build public key"));
  }
}
