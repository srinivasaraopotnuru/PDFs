package uk.co.ybs.digital.authentication.web;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.core.IsNull.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import io.micrometer.core.instrument.simple.SimpleMeterRegistry;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import uk.co.ybs.digital.authentication.ClientJsonDataBase64Serializer;
import uk.co.ybs.digital.authentication.TestHelper;
import uk.co.ybs.digital.authentication.VerificationMethod;
import uk.co.ybs.digital.authentication.service.AssertionService;
import uk.co.ybs.digital.authentication.service.RequestMetadata;
import uk.co.ybs.digital.authentication.util.UUIDGenerator;
import uk.co.ybs.digital.authentication.web.dto.request.ClientAssertionPayload;
import uk.co.ybs.digital.authentication.web.dto.request.ClientDataJson;
import uk.co.ybs.digital.authentication.web.dto.request.ValidateAssertionRequest;
import uk.co.ybs.digital.authentication.web.dto.response.CustomerDetails;
import uk.co.ybs.digital.authentication.web.dto.response.ErrorResponse;
import uk.co.ybs.digital.authentication.web.dto.response.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.authentication.web.dto.response.GetAssertionResponse;
import uk.co.ybs.digital.authentication.web.dto.response.LoginDetails;
import uk.co.ybs.digital.authentication.web.dto.response.PublicKeyAssertion;
import uk.co.ybs.digital.authentication.web.dto.response.ValidateAssertionResponse;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(AuthenticationControllerPrivate.class)
@Import({
  RequestVerificationSecurityAutoConfiguration.class,
  ServiceLoggingAutoConfiguration.class,
  ErrorResponseFactory.class,
  SimpleMeterRegistry.class
})
@ActiveProfiles("test")
class AuthenticationControllerPrivateTest {

  private static final String PATH_BASE = "/private";
  private static final String PATH_GET_ASSERTION = PATH_BASE + "/assertion/{partyId}";
  private static final String PATH_VALIDATE_ASSERTION = PATH_BASE + "/assertion";

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_CHANNEL = "x-ybs-channel";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";

  private static final Long PARTY_ID = 1234567890L;
  private static final UUID SESSION_ID = UUID.fromString("f9627c60-95f3-432c-8688-83bf9d3bf473");
  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String CHANNEL = "SAPP";
  private static final String BRAND_CODE = "YBS";

  private static final String CHALLENGE = "challenge";
  private static final String CODE = "code";
  private static final String RESPONSE_TYPE = "response_type";
  private static final String CLIENT_ID = "client_id";

  @Autowired private MockMvc mvc;

  @Autowired private ObjectMapper objectMapper;

  @MockBean private AssertionService assertionService;

  @MockBean private UUIDGenerator uuidGenerator;

  @MockBean private RequestSigningVerificationService requestSigningVerificationService;

  @BeforeEach
  void beforeEach() {
    doReturn(true).when(requestSigningVerificationService).verifyRequest(any(), any());
  }

  @Test
  void getAssertionShouldReturnAssertionResponse() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Long timeout = 10_000L;

    final PublicKeyAssertion response =
        PublicKeyAssertion.builder().challenge(CHALLENGE).timeout(timeout).build();

    doReturn(SESSION_ID).when(uuidGenerator).generateId();

    doReturn(response)
        .when(assertionService)
        .getAssertion(
            SESSION_ID,
            PARTY_ID,
            buildChallengeParameters(),
            buildRequestMetadata(requestId),
            false);

    mvc.perform(
            get(PATH_GET_ASSERTION, PARTY_ID)
                .queryParam(RESPONSE_TYPE, CODE)
                .queryParam(CLIENT_ID, "clientId")
                .headers(standardHeaders(requestId)))
        .andExpect(status().isOk())
        .andExpect(header().string("x-ybs-session-id", SESSION_ID.toString()))
        .andExpect(
            header()
                .string(
                    "x-ybs-puid",
                    "c775e7b757ede630cd0aa1113bd102661ab38829ca52a6422ab782862f268646"))
        .andExpect(
            content()
                .json(objectMapper.writeValueAsString(new GetAssertionResponse(response)), true));
  }

  @ParameterizedTest
  @ValueSource(strings = {HEADER_CHANNEL, HEADER_BRAND_CODE})
  void getAssertionShouldReturnBadRequestForMissingHeader(final String header) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.HEADER_MISSING)
                    .message("Header missing")
                    .path(header)
                    .build())
            .build();

    final HttpHeaders headers = standardHeaders(requestId);
    headers.remove(header);

    mvc.perform(
            get(PATH_GET_ASSERTION, PARTY_ID)
                .queryParam(RESPONSE_TYPE, CODE)
                .queryParam(CLIENT_ID, "clientId")
                .headers(headers))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response), true));
  }

  @Test
  void getAssertionShouldReturnNotFoundIfPartyIdIsNotANumber() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String partyId = "partyId";

    mvc.perform(
            get(PATH_GET_ASSERTION, partyId)
                .headers(standardHeaders(requestId))
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isNotFound());
    // FIXME: Check response body when we have a solution to NoHandlerExceptions and swagger-ui.html
    // conflict (AS-486)
  }

  @Test
  void validateAssertionShouldReturnValidateAssertionResponse() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ValidateAssertionRequest request = buildValidateAssertionRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(requestId);
    final ChallengeParameters challengeParameters = buildChallengeParameters();

    final ValidateAssertionResponse response =
        ValidateAssertionResponse.builder()
            .verificationMethod(VerificationMethod.BIOMETRIC)
            .registrationId(request.getId())
            .customer(
                CustomerDetails.builder()
                    .partyId(PARTY_ID)
                    .forename("John")
                    .surname("Smith")
                    .title("Mr")
                    .email("john.smith@gmail.com")
                    .build())
            .login(
                LoginDetails.builder()
                    .partyId(PARTY_ID)
                    .loginTime(Instant.now())
                    .lastLoginTime(Instant.now())
                    .build())
            .challengeParameters(challengeParameters)
            .brandCode(BRAND_CODE)
            .channel(CHANNEL)
            .sessionId(UUID.randomUUID())
            .build();

    when(assertionService.validationAssertion(request, requestMetadata, false))
        .thenReturn(response);

    mvc.perform(
            post(PATH_VALIDATE_ASSERTION)
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response), true));
  }

  @ParameterizedTest
  @ValueSource(strings = {HEADER_CHANNEL, HEADER_BRAND_CODE})
  void validateAssertionShouldReturnBadRequestForMissingHeader(final String header)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.HEADER_MISSING)
                    .message("Header missing")
                    .path(header)
                    .build())
            .build();

    final HttpHeaders headers = standardHeaders(requestId);
    headers.remove(header);

    mvc.perform(
            post(PATH_VALIDATE_ASSERTION)
                .headers(headers)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(buildValidateAssertionRequest())))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response), true));
  }

  @Test
  void validateAssertionShouldReturnBadRequestForInvalidRequest() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String request = "";
    final ErrorResponse response =
        ErrorResponse.builder()
            .code("400 Bad Request")
            .id(requestId)
            .message("Unable to parse request body")
            .error(
                ErrorItem.builder()
                    .errorCode("Resource.InvalidFormat")
                    .message(
                        "An unexpected error occurred when attempting to parse the request body")
                    .build())
            .build();

    mvc.perform(
            post(PATH_VALIDATE_ASSERTION)
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(request))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response), true));
  }

  @Test
  void validateAssertionShouldReturnBadRequestForInvalidRequestClientDataJson() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String request =
        TestHelper.readResource(
            "api/request/public-key-assertion-request-non-base64-clientDataJson.json");
    final ErrorResponse response =
        ErrorResponse.builder()
            .code("400 Bad Request")
            .id(requestId)
            .message("Unable to process clientDataJson")
            .error(
                ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("clientDataJson is not a valid base64 encoded string")
                    .build())
            .build();

    mvc.perform(
            post(PATH_VALIDATE_ASSERTION)
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(request))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response), true));
  }

  @Test
  void shouldReturnUnsupportedMediaTypeIfMediaTypeNotSupported() throws Exception {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("415 Unsupported Media Type")
            .id(requestId)
            .message("Unsupported Media Type")
            .error(
                ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("Content-Type header is invalid")
                    .path("Content-Type")
                    .build())
            .build();

    mvc.perform(
            post(PATH_VALIDATE_ASSERTION)
                .headers(standardHeaders(requestId))
                .contentType(MediaType.TEXT_PLAIN)
                .content(objectMapper.writeValueAsString(buildValidateAssertionRequest())))
        .andExpect(status().isUnsupportedMediaType())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true))
        .andExpect(header().string(HttpHeaders.ACCEPT, is(MediaType.APPLICATION_JSON_VALUE)));

    verifyNoInteractions(assertionService);
  }

  @Test
  void getAssertionShouldReturnBadRequestIfRequestIdIsNotAUUID() throws Exception {
    final String requestId = "not-a-uuid";

    mvc.perform(
            get(PATH_GET_ASSERTION, PARTY_ID)
                .queryParam(RESPONSE_TYPE, CODE)
                .queryParam(CLIENT_ID, CLIENT_ID)
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            jsonPath(
                "$.id", notNullValue(UUID.class))) // Will be a different value to what we specified
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(HEADER_REQUEST_ID)));

    verifyNoInteractions(assertionService);
  }

  @ParameterizedTest
  @EnumSource(
      value = HttpMethod.class,
      names = {"POST", "PUT", "PATCH", "DELETE"})
  void getAssertionShouldReturnMethodNotAllowedForUnsupportedMethods(final HttpMethod method)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.METHOD_NOT_ALLOWED)
            .id(requestId)
            .message("Method Not Allowed")
            .code("405 Method Not Allowed")
            .error(
                ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method: " + method)
                    .build())
            .build();

    mvc.perform(request(method, PATH_GET_ASSERTION, PARTY_ID).headers(standardHeaders(requestId)))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().json(objectMapper.writeValueAsString(response), true));
  }

  @ParameterizedTest
  @EnumSource(
      value = HttpMethod.class,
      names = {"GET", "PUT", "PATCH", "DELETE"})
  void validateAssertionShouldReturnMethodNotAllowedForUnsupportedMethods(final HttpMethod method)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.METHOD_NOT_ALLOWED)
            .id(requestId)
            .message("Method Not Allowed")
            .code("405 Method Not Allowed")
            .error(
                ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method: " + method)
                    .build())
            .build();

    mvc.perform(request(method, PATH_VALIDATE_ASSERTION).headers(standardHeaders(requestId)))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().json(objectMapper.writeValueAsString(response), true));
  }

  @Test
  void shouldIncludeResponseBodyIfUnexpectedSpringInternalExceptionThrown() throws Exception {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException())
        .when(assertionService)
        .getAssertion(any(), any(), any(), any(), anyBoolean());

    mvc.perform(
            get(PATH_GET_ASSERTION, PARTY_ID)
                .queryParam(RESPONSE_TYPE, CODE)
                .queryParam(CLIENT_ID, CLIENT_ID)
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  private RequestMetadata buildRequestMetadata(final UUID requestId) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .ipAddress(IP_ADDRESS)
        .channel(CHANNEL)
        .brandCode(BRAND_CODE)
        .build();
  }

  private static ValidateAssertionRequest buildValidateAssertionRequest() {
    return ValidateAssertionRequest.builder()
        .id(UUID.randomUUID())
        .type("public-key")
        .response(
            ClientAssertionPayload.builder()
                .signature(new byte[5])
                .clientDataJson(
                    ClientDataJson.builder()
                        .type("webauthn.get")
                        .origin("digital-api.ybs.co.uk")
                        .verificationMethod(VerificationMethod.BIOMETRIC)
                        .challenge("")
                        .build())
                .build())
        .build();
  }

  private ChallengeParameters buildChallengeParameters() {
    return new ChallengeParameters(
        ImmutableMap.<String, String>builder()
            .put(RESPONSE_TYPE, CODE)
            .put(CLIENT_ID, "clientId")
            .build());
  }

  private HttpHeaders standardHeaders(final UUID requestId) {
    return standardHeaders(requestId.toString());
  }

  private HttpHeaders standardHeaders(final String requestId) {
    final HttpHeaders headers = new HttpHeaders();
    headers.add(HEADER_REQUEST_ID, requestId);
    headers.add(HEADER_CHANNEL, CHANNEL);
    headers.add(HEADER_BRAND_CODE, BRAND_CODE);
    headers.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON));
    return headers;
  }

  @TestConfiguration
  static class AuthenticationControllerTestConfiguration {
    @Bean
    Jackson2ObjectMapperBuilderCustomizer jackson2ObjectMapperBuilderCustomizer() {
      return builder ->
          builder.serializerByType(ClientDataJson.class, new ClientJsonDataBase64Serializer());
    }
  }
}
