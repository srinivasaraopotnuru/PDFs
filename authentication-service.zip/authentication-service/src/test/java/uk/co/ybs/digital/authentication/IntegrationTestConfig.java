package uk.co.ybs.digital.authentication;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.file.Files;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.util.Objects;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJson;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.Resource;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.WebTestClientConfigurer;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import uk.co.ybs.digital.authentication.web.dto.request.ClientDataJson;
import uk.co.ybs.digital.security.requestsigning.ClientHttpRequestSigner;
import uk.co.ybs.digital.security.requestsigning.PayloadBuilder;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnector;
import uk.co.ybs.digital.security.requestsigning.RequestSigningKeyRegistry;
import uk.co.ybs.digital.security.requestsigning.SignatureFactory;

@TestConfiguration
@AutoConfigureJson
public class IntegrationTestConfig {

  private static final String REQUEST_SIGNATURE_KEY_ID_PUBLIC = "request-signature-key-id-public";
  private static final String REQUEST_SIGNATURE_KEY_ID_PRIVATE = "request-signature-key-id-private";

  @Value("classpath:crypto/ec-private.pem")
  Resource scaPrivateKeyPem;

  @Value("${test.request-signature.signing.private-key-public}")
  String requestSigningPrivateKeyPemPublic;

  @Value("${test.request-signature.signing.private-key-private}")
  String requestSigningPrivateKeyPemPrivate;

  @Bean
  PEMKeyPair scaKeyPair() throws IOException {
    return buildKeyPair(new String(Files.readAllBytes(scaPrivateKeyPem.getFile().toPath())));
  }

  @Bean
  Jackson2ObjectMapperBuilderCustomizer jackson2ObjectMapperBuilderCustomizer() {
    return builder ->
        builder.serializerByType(ClientDataJson.class, new ClientJsonDataBase64Serializer());
  }

  @Bean
  PrivateKey scaPrivateKey(final PEMKeyPair scaKeyPair) throws IOException {
    return BouncyCastleProvider.getPrivateKey(scaKeyPair.getPrivateKeyInfo());
  }

  @Bean
  PublicKey scaPublicKey(final PEMKeyPair scaKeyPair) throws IOException {
    return BouncyCastleProvider.getPublicKey(scaKeyPair.getPublicKeyInfo());
  }

  @Bean
  String scaPublicKeyPem(final PublicKey scaPublicKey) throws IOException {
    final StringWriter out = new StringWriter();
    try (JcaPEMWriter writer = new JcaPEMWriter(out)) {
      writer.writeObject(scaPublicKey);
      writer.close();
      return out.toString();
    }
  }

  @Bean
  PrivateKey requestSigningPrivateKeyPublic() throws IOException {
    return buildPrivateKey(requestSigningPrivateKeyPemPublic);
  }

  @Bean
  PrivateKey requestSigningPrivateKeyPrivate() throws IOException {
    return buildPrivateKey(requestSigningPrivateKeyPemPrivate);
  }

  @Bean
  WebTestClient nonSigningWebClient(
      final ClientHttpConnector connector, final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(connector).apply(webTestClientConfigurer).build();
  }

  @Bean
  WebTestClient signingWebClientPublic(
      final ClientHttpConnector connector,
      final PrivateKey requestSigningPrivateKeyPublic,
      final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(
            new RequestSigningClientHttpConnector(
                connector,
                new ClientHttpRequestSigner(
                    new SignatureFactory(),
                    new PayloadBuilder(),
                    new RequestSigningKeyRegistry(
                        REQUEST_SIGNATURE_KEY_ID_PUBLIC, requestSigningPrivateKeyPublic))))
        .apply(webTestClientConfigurer)
        .build();
  }

  @Bean
  WebTestClient signingWebClientPrivate(
      final ClientHttpConnector connector,
      final PrivateKey requestSigningPrivateKeyPrivate,
      final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(
            new RequestSigningClientHttpConnector(
                connector,
                new ClientHttpRequestSigner(
                    new SignatureFactory(),
                    new PayloadBuilder(),
                    new RequestSigningKeyRegistry(
                        REQUEST_SIGNATURE_KEY_ID_PRIVATE, requestSigningPrivateKeyPrivate))))
        .apply(webTestClientConfigurer)
        .build();
  }

  /**
   * WebTestClient doesn't seem to get properly configured with the Spring context ObjectMapper.
   * Manually do this.
   */
  @Bean
  WebTestClientConfigurer webTestClientConfigurer(final ObjectMapper objectMapper) {
    return (builder, httpHandlerBuilder, connector) ->
        builder.exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(
                    (configurer) -> {
                      configurer
                          .defaultCodecs()
                          .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                      configurer
                          .defaultCodecs()
                          .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                    })
                .build());
  }

  private PEMKeyPair buildKeyPair(final String pem) throws IOException {
    Security.addProvider(new BouncyCastleProvider());
    try (PEMParser parser = new PEMParser(new StringReader(pem))) {
      return (PEMKeyPair)
          Objects.requireNonNull(parser.readObject(), "Failed to construct key pair from " + pem);
    }
  }

  private PrivateKey buildPrivateKey(final String pem) throws IOException {
    return BouncyCastleProvider.getPrivateKey(buildKeyPair(pem).getPrivateKeyInfo());
  }
}
