package uk.co.ybs.digital.authentication.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.MethodParameter;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.context.request.ServletWebRequest;
import uk.co.ybs.digital.authentication.service.RequestMetadata;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;

class RequestMetadataArgumentResolverTest {

  private static final String HEADER_CHANNEL = "x-ybs-channel";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";

  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String CHANNEL = "SAPP";
  private static final String BRAND_CODE = "YBS";

  private final RequestMetadataArgumentResolver testSubject = new RequestMetadataArgumentResolver();

  private ServletWebRequest servletWebRequest;
  private HttpServletRequest httpServletRequest;

  @BeforeEach
  void setUp() {
    httpServletRequest = mock(HttpServletRequest.class);
    servletWebRequest = new ServletWebRequest(httpServletRequest);

    when(httpServletRequest.getAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME))
        .thenReturn(REQUEST_ID);
    when(httpServletRequest.getRemoteAddr()).thenReturn(IP_ADDRESS);
    when(httpServletRequest.getHeader(HEADER_CHANNEL)).thenReturn(CHANNEL);
    when(httpServletRequest.getHeader(HEADER_BRAND_CODE)).thenReturn(BRAND_CODE);
  }

  @Test
  void shouldResolveArgument() throws Exception {
    final RequestMetadata requestMetadata =
        (RequestMetadata)
            testSubject.resolveArgument(mock(MethodParameter.class), null, servletWebRequest, null);

    assertThat(
        requestMetadata,
        is(
            RequestMetadata.builder()
                .requestId(REQUEST_ID)
                .ipAddress(IP_ADDRESS)
                .channel(CHANNEL)
                .brandCode(BRAND_CODE)
                .build()));
  }

  @Test
  void shouldThrowNullPointerExceptionIfRequestIdMissing() {
    when(httpServletRequest.getAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME))
        .thenReturn(null);

    final NullPointerException exception =
        assertThrows(
            NullPointerException.class,
            () ->
                testSubject.resolveArgument(
                    mock(MethodParameter.class), null, servletWebRequest, null));

    assertThat(exception.getMessage(), is("Request ID is required"));
  }

  @Test
  void shouldThrowMissingRequestHeaderExceptionIfChannelHeaderIsMissing() {
    when(httpServletRequest.getHeader(HEADER_CHANNEL)).thenReturn(null);
    final MethodParameter methodParameter = mock(MethodParameter.class);

    final MissingRequestHeaderException exception =
        assertThrows(
            MissingRequestHeaderException.class,
            () -> testSubject.resolveArgument(methodParameter, null, servletWebRequest, null));

    assertThat(exception.getParameter(), sameInstance(methodParameter));
    assertThat(exception.getHeaderName(), is(HEADER_CHANNEL));
  }

  @Test
  void shouldThrowMissingRequestHeaderExceptionIfBrandCodeHeaderIsMissing() {
    when(httpServletRequest.getHeader(HEADER_BRAND_CODE)).thenReturn(null);
    final MethodParameter methodParameter = mock(MethodParameter.class);

    final MissingRequestHeaderException exception =
        assertThrows(
            MissingRequestHeaderException.class,
            () -> testSubject.resolveArgument(methodParameter, null, servletWebRequest, null));

    assertThat(exception.getParameter(), sameInstance(methodParameter));
    assertThat(exception.getHeaderName(), is(HEADER_BRAND_CODE));
  }

  @Test
  void shouldSupportMethodParameterRequestMetaData() {
    final MethodParameter methodParameter = mock(MethodParameter.class);
    doReturn(RequestMetadata.class).when(methodParameter).getParameterType();

    final boolean supportsParameter = testSubject.supportsParameter(methodParameter);
    assertThat(supportsParameter, is(true));
  }

  @Test
  void shouldNotSupportMethodParameterNotRequestMetaData() {
    final MethodParameter methodParameter = mock(MethodParameter.class);
    doReturn(Object.class).when(methodParameter).getParameterType();

    final boolean supportsParameter = testSubject.supportsParameter(methodParameter);
    assertThat(supportsParameter, is(false));
  }
}
