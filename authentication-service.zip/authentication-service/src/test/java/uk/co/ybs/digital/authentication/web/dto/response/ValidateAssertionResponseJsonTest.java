package uk.co.ybs.digital.authentication.web.dto.response;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.common.collect.ImmutableMap;
import java.time.Instant;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;
import uk.co.ybs.digital.authentication.VerificationMethod;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;

@JsonTest
class ValidateAssertionResponseJsonTest {

  private static final String FORENAME = "John";
  private static final String SURNAME = "Smith";
  private static final String TITLE = "Mr";
  private static final String EMAIL = "john.smith@gmail.com";
  private static final long PARTY_ID = 1234567890L;

  @Autowired private JacksonTester<ValidateAssertionResponse> tester;

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void testSerialize(final CustomerDetails customerDetails, final ClassPathResource file)
      throws Exception {
    ChallengeParameters challengeParameters =
        new ChallengeParameters(
            ImmutableMap.<String, String>builder()
                .put("response_type", "code")
                .put("client_id", "clientId")
                .put("code_challenge", "codeChallenge")
                .put("code_challenge_method", "S256")
                .put("scope", "ACCOUNT_READ PAYMENT")
                .put("state", "some-state")
                .build());

    final ValidateAssertionResponse response =
        ValidateAssertionResponse.builder()
            .sessionId(UUID.fromString("79c1ee70-6771-4bc5-8004-de707b582b69"))
            .registrationId(UUID.fromString("cd428499-10f8-4362-8051-7338d7d5cd1e"))
            .brandCode("YBS")
            .channel("SAPP")
            .verificationMethod(VerificationMethod.BIOMETRIC)
            .customer(customerDetails)
            .login(
                LoginDetails.builder()
                    .partyId(PARTY_ID)
                    .loginTime(Instant.parse("2019-04-02T10:21:41.894Z"))
                    .lastLoginTime(Instant.parse("2019-04-01T23:35:04.329Z"))
                    .build())
            .challengeParameters(challengeParameters)
            .build();

    assertThat(tester.write(response)).isEqualToJson(file, JSONCompareMode.STRICT);
  }

  private static CustomerDetails buildCustomerDetails() {
    return CustomerDetails.builder()
        .partyId(PARTY_ID)
        .forename(FORENAME)
        .surname(SURNAME)
        .title(TITLE)
        .email(EMAIL)
        .build();
  }

  private static CustomerDetails buildCustomerDetailsWithoutTitleAndEmail() {
    return CustomerDetails.builder().partyId(PARTY_ID).forename(FORENAME).surname(SURNAME).build();
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(
            buildCustomerDetails(),
            new ClassPathResource("api/response/validate-assertion-response.json")),
        Arguments.of(
            buildCustomerDetailsWithoutTitleAndEmail(),
            new ClassPathResource(
                "api/response/validate-assertion-without-email-title-response.json")));
  }
}
