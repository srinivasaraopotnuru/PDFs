package uk.co.ybs.digital.authentication.web.dto.request;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.google.common.collect.ImmutableMap;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.authentication.VerificationMethod;

@JsonTest
class ValidateAssertionRequestJsonTest {

  @Autowired JacksonTester<ValidateAssertionRequest> json;

  @Value("classpath:api/request/public-key-assertion-request-valid-in.json")
  Resource validInput;

  @Value(
      "classpath:api/request/public-key-assertion-request-valid-in-with-challenge-validation-data.json")
  Resource validInputWithChallengeValidationData;

  @Value("classpath:api/request/public-key-assertion-request-non-base64-clientDataJson.json")
  Resource nonBase64ClientDataJson;

  @Value("classpath:api/request/public-key-assertion-request-clientDataJson-invalid.json")
  Resource invalidClientDataJson;

  @Value("classpath:api/request/public-key-assertion-request-invalid-verificationMethod.json")
  Resource invalidVerificationMethod;

  @Value("classpath:api/request/public-key-assertion-request-missing-challenge.json")
  Resource missingChallenge;

  @Test
  void deserialize() throws IOException {
    Assertions.assertThat(json.read(validInput))
        .isEqualTo(
            ValidateAssertionRequest.builder()
                .id(UUID.fromString("feeabc1d-3a12-4ab1-b51d-6e74f1e38cb3"))
                .type("public-key")
                .response(
                    ClientAssertionPayload.builder()
                        .clientDataJson(
                            ClientDataJson.builder()
                                .verificationMethod(VerificationMethod.BIOMETRIC)
                                .challenge("challenge")
                                .origin("digital-api.ybs.co.uk")
                                .type("webauthn.get")
                                .build())
                        .signature("signature".getBytes(Charset.defaultCharset()))
                        .build())
                .build());
  }

  @Test
  void deserializeWithChallengeValidationData() throws IOException {
    Assertions.assertThat(json.read(validInputWithChallengeValidationData))
        .isEqualTo(
            ValidateAssertionRequest.builder()
                .id(UUID.fromString("feeabc1d-3a12-4ab1-b51d-6e74f1e38cb3"))
                .type("public-key")
                .response(
                    ClientAssertionPayload.builder()
                        .clientDataJson(
                            ClientDataJson.builder()
                                .verificationMethod(VerificationMethod.BIOMETRIC)
                                .challenge("challenge")
                                .origin("digital-api.ybs.co.uk")
                                .type("webauthn.get")
                                .build())
                        .signature("signature".getBytes(Charset.defaultCharset()))
                        .build())
                .challengeValidationData(
                    new ChallengeValidationData(
                        ImmutableMap.<String, String>builder()
                            .put("request_digest", "requestDigestValue")
                            .put("other_field", "otherFieldValue")
                            .build()))
                .build());
  }

  @Test
  void deserializeShouldErrorIfClientDataJsonIsNotBase64Encoded() {
    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class, () -> json.read(nonBase64ClientDataJson));
    assertThat(ex.getMessage(), equalTo("clientDataJson is not a valid base64 encoded string"));
  }

  @Test
  void deserializeShouldErrorIfUserHandleCannotDeserializeInto() {
    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class, () -> json.read(nonBase64ClientDataJson));
    assertThat(ex.getMessage(), equalTo("clientDataJson is not a valid base64 encoded string"));
  }

  @Test
  void deserializeShouldErrorIfClientDataJsonDecodesToInvalidJSON() {
    InvalidClientDataJsonException ex =
        assertThrows(InvalidClientDataJsonException.class, () -> json.read(invalidClientDataJson));
    assertThat(
        ex.getMessage(),
        equalTo(
            "Unable to parse clientDataJson: Unrecognized token 'invalid': was expecting (JSON String, Number, Array, Object or token 'null', 'true' or 'false')"));
  }

  @Test
  void deserializeShouldErrorIfClientDataJsonContainsInvalidVerificationMethod() {
    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class, () -> json.read(invalidVerificationMethod));
    assertThat(ex.getMessage(), equalTo("Unable to handle clientDataJson value: NONE"));
  }

  @Test
  void deserializeShouldErrorIfClientDataJsonIsMissingARequiredField() {
    InvalidClientDataJsonException ex =
        assertThrows(InvalidClientDataJsonException.class, () -> json.read(missingChallenge));
    assertThat(
        ex.getMessage(),
        equalTo("Unable to handle clientDataJson field: challenge is marked non-null but is null"));
  }
}
