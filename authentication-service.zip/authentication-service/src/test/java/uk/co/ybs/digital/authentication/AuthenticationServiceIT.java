package uk.co.ybs.digital.authentication;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.KeyLengthException;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import io.swagger.models.HttpMethod;
import java.io.IOException;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.DefaultUriBuilderFactory;
import org.springframework.web.util.UriBuilder;
import uk.co.ybs.digital.authentication.crypto.JwsCodec;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginChallengeRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginFailureRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginSuccessRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.LoginFailureReason;
import uk.co.ybs.digital.authentication.service.audit.dto.UserSession;
import uk.co.ybs.digital.authentication.service.challenge.ChallengePayload;
import uk.co.ybs.digital.authentication.service.login.LoginRequest;
import uk.co.ybs.digital.authentication.service.login.dto.LoginResponse;
import uk.co.ybs.digital.authentication.service.registration.dto.Registration;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;
import uk.co.ybs.digital.authentication.web.dto.request.ChallengeValidationData;
import uk.co.ybs.digital.authentication.web.dto.request.ClientAssertionPayload;
import uk.co.ybs.digital.authentication.web.dto.request.ClientDataJson;
import uk.co.ybs.digital.authentication.web.dto.request.FailureRequest;
import uk.co.ybs.digital.authentication.web.dto.request.ValidateAssertionRequest;
import uk.co.ybs.digital.authentication.web.dto.response.CustomerDetails;
import uk.co.ybs.digital.authentication.web.dto.response.ErrorResponse;
import uk.co.ybs.digital.authentication.web.dto.response.GetAssertionResponse;
import uk.co.ybs.digital.authentication.web.dto.response.LoginDetails;
import uk.co.ybs.digital.authentication.web.dto.response.PublicKeyAssertion;
import uk.co.ybs.digital.authentication.web.dto.response.ValidateAssertionResponse;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class})
@ActiveProfiles({"test", "text-logging"})
class AuthenticationServiceIT {

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_CHANNEL = "x-ybs-channel";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";

  private static final String PATH_GET_ASSERTION = "/auth/assertion/{partyId}";
  private static final String PATH_GET_ASSERTION_PRIVATE = "/auth/private/assertion/{partyId}";

  private static final String PATH_VALIDATE_ASSERTION = "/auth/assertion";
  private static final String PATH_VALIDATE_ASSERTION_PRIVATE = "/auth/private/assertion";

  private static final String PATH_AUDIT_LOGIN_CHALLENGE = "/login/challenge";
  private static final String PATH_AUDIT_LOGIN_SUCCESS = "/login/success";
  private static final String PATH_AUDIT_LOGIN_FAILURE = "/login/failure";

  private static final String PATH_REPORT_FAILURE = "/auth/failure";

  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String CHANNEL = "SAPP";
  private static final String BRAND_CODE = "YBS";

  private static final long PARTY_ID = 123456789L;
  private static final long CHALLENGE_PAYLOAD_PARTY_ID = 987654321L;
  private static final UUID SESSION_ID = UUID.randomUUID();
  private static final UUID REGISTRATION_ID = UUID.randomUUID();
  public static final String TITLE = "Mr";
  public static final String EMAIL = "john.smith@ybs.co.uk";
  public static final String SURNAME = "Smith";
  public static final String FORENAME = "John";

  public static final String FORBIDDEN = "Forbidden";
  public static final String ACCESS_DENIED = "Access Denied";
  public static final String REGISTERED = "REGISTERED";
  public static final String UNEXPECTED_ERROR = "Unexpected Error";
  public static final String UNUSED = "unused";

  private final DefaultUriBuilderFactory uriBuilderFactory =
      new DefaultUriBuilderFactory("http://localhost");
  private final MockWebServer loginServer = new MockWebServer();
  private final MockWebServer registrationServer = new MockWebServer();
  private final MockWebServer auditServer = new MockWebServer();

  @Autowired WebTestClient signingWebClientPublic;

  @Autowired WebTestClient signingWebClientPrivate;

  @Autowired WebTestClient nonSigningWebClient;

  @Autowired ObjectMapper objectMapper;

  @Autowired String scaPublicKeyPem;

  @Autowired PrivateKey scaPrivateKey;

  @Autowired JwsCodec jwsCodec;

  @LocalServerPort int port;

  @BeforeEach
  void setUp() throws IOException {
    registrationServer.start(65444);
    loginServer.start(65445);
    auditServer.start(65446);
  }

  @AfterEach
  void teardown() throws IOException {
    registrationServer.shutdown();
    loginServer.shutdown();
    auditServer.shutdown();
  }

  @Test
  void reportFailureShouldReturnNoContent() throws JsonProcessingException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final ChallengePayload challengePayload =
        buildChallenge(Instant.now().plus(Duration.ofDays(1)));
    final String challenge = jwsCodec.encode(challengePayload);

    final FailureRequest request = buildFailureRequest(challenge);

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_REPORT_FAILURE).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isNoContent();

    assertAuditFailure(requestId, LoginFailureReason.BUSINESS, "Invalid Client Credentials");
  }

  @Test
  void reportFailureShouldReturnForbiddenIfRequestIsNotSigned() {
    final UUID requestId = UUID.randomUUID();

    nonSigningWebClient
        .post()
        .uri(baseUrl().path(PATH_REPORT_FAILURE).build())
        .header(HEADER_REQUEST_ID, requestId.toString())
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .value(
            equalTo(
                ErrorResponse.builder(HttpStatus.FORBIDDEN)
                    .id(requestId)
                    .message(FORBIDDEN)
                    .error(
                        ErrorResponse.ErrorItem.builder()
                            .message(ACCESS_DENIED)
                            .errorCode(ErrorResponse.ErrorItem.INVALID_REQUEST_SIGNATURE)
                            .build())
                    .build()));
  }

  @Test
  void reportFailureShouldReturnUnauthorizedIfChallengePayloadIsInvalid() {
    final UUID requestId = UUID.randomUUID();
    final String challenge = jwsCodec.encode("InvalidJson");
    final FailureRequest request = buildFailureRequest(challenge);

    final ErrorResponse response = buildAuthenticationFailedResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_REPORT_FAILURE).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(response));
  }

  @ParameterizedTest
  @MethodSource("invalidJWSSigners")
  void reportFailureShouldReturnUnauthorizedIfChallengeJwsSignatureIsNotValid(
      final JWSAlgorithm alg, final JWSSigner signer)
      throws JOSEException, JsonProcessingException {
    final JWSObject jws =
        new JWSObject(
            new JWSHeader(alg),
            new Payload(
                objectMapper.writeValueAsBytes(
                    buildChallenge(Instant.now().plus(Duration.ofDays(1))))));
    jws.sign(signer);
    final String challenge = jws.serialize();

    final UUID requestId = UUID.randomUUID();
    final FailureRequest request = buildFailureRequest(challenge);

    final ErrorResponse response = buildAuthenticationFailedResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_REPORT_FAILURE).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(response));
  }

  @Test
  void getAssertionShouldReturnChallengeForCustomer() throws Exception {
    getAssertionShouldReturnChallengeForCustomer(PATH_GET_ASSERTION, signingWebClientPublic, true);
  }

  @Test
  void privateGetAssertionShouldReturnChallengeForCustomer() throws Exception {
    getAssertionShouldReturnChallengeForCustomer(
        PATH_GET_ASSERTION_PRIVATE, signingWebClientPrivate, false);
  }

  private void getAssertionShouldReturnChallengeForCustomer(
      final String endpoint, final WebTestClient webTestClient, final boolean audit)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ChallengeParameters challengeParameters = buildChallengeParameters();

    if (audit) {
      auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
    }

    webTestClient
        .get()
        .uri(
            baseUrl()
                .path(endpoint)
                .queryParams(toMultiValueMap(challengeParameters))
                .build(CHALLENGE_PAYLOAD_PARTY_ID))
        .headers(standardHeaders(requestId))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .exists("x-ybs-session-id")
        .expectHeader()
        .exists("x-ybs-puid")
        .expectBody(GetAssertionResponse.class)
        .value(
            result -> {
              PublicKeyAssertion response = Objects.requireNonNull(result).getPublicKey();
              assertThat(response.getRpId(), equalTo("ybs.co.uk"));
              assertThat(response.getTimeout(), equalTo(60_000L));
              assertThat(
                  decode(response.getChallenge()),
                  hasPayload(CHALLENGE_PAYLOAD_PARTY_ID, challengeParameters));
            });

    if (audit) {
      assertAuditChallenge(requestId);
    }
  }

  @Test
  void getAssertionShouldReturnChallengeWithValidSessionId() throws Exception {
    getAssertionShouldReturnChallengeWithValidSessionId(
        PATH_GET_ASSERTION, signingWebClientPublic, true);
  }

  @Test
  void privateGetAssertionShouldReturnChallengeWithValidSessionId() throws Exception {
    getAssertionShouldReturnChallengeWithValidSessionId(
        PATH_GET_ASSERTION_PRIVATE, signingWebClientPrivate, false);
  }

  private void getAssertionShouldReturnChallengeWithValidSessionId(
      final String endpoint, final WebTestClient webTestClient, final boolean audit)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ChallengeParameters challengeParameters = buildChallengeParametersWithSessionId();

    if (audit) {
      auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
    }

    webTestClient
        .get()
        .uri(
            baseUrl()
                .path(endpoint)
                .queryParams(toMultiValueMap(challengeParameters))
                .build(CHALLENGE_PAYLOAD_PARTY_ID))
        .headers(standardHeaders(requestId))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .exists("x-ybs-session-id")
        .expectHeader()
        .exists("x-ybs-puid")
        .expectBody(GetAssertionResponse.class)
        .value(
            result -> {
              PublicKeyAssertion response = Objects.requireNonNull(result).getPublicKey();
              assertThat(response.getRpId(), equalTo("ybs.co.uk"));
              assertThat(response.getTimeout(), equalTo(60_000L));
              assertThat(
                  decode(response.getChallenge()),
                  hasPayload(CHALLENGE_PAYLOAD_PARTY_ID, challengeParameters));
            });

    if (audit) {
      assertAuditChallenge(requestId);
    }
  }

  @Test
  void getAssertionShouldReturnForbiddenForPrivateRequestSigningKey() {
    getAssertionShouldReturnForbiddenForInvalidRequestSigningKey(
        PATH_GET_ASSERTION, signingWebClientPrivate);
  }

  @Test
  void privateGetAssertionShouldReturnForbiddenForPublicRequestSigningKey() {
    getAssertionShouldReturnForbiddenForInvalidRequestSigningKey(
        PATH_GET_ASSERTION_PRIVATE, signingWebClientPublic);
  }

  private void getAssertionShouldReturnForbiddenForInvalidRequestSigningKey(
      final String endpoint, final WebTestClient webTestClient) {
    final UUID requestId = UUID.randomUUID();
    final ChallengeParameters challengeParameters = buildChallengeParameters();

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message(FORBIDDEN)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message(ACCESS_DENIED)
                    .build())
            .build();

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    webTestClient
        .get()
        .uri(
            baseUrl()
                .path(endpoint)
                .queryParams(toMultiValueMap(challengeParameters))
                .build(PARTY_ID))
        .headers(standardHeaders(requestId))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void getAssertionShouldReturnNotFoundIfPartyIdIsNotAllDigits() {
    final UUID requestId = UUID.randomUUID();

    signingWebClientPublic
        .get()
        .uri(baseUrl().path(PATH_GET_ASSERTION).build("foo"))
        .header(HEADER_REQUEST_ID, requestId.toString())
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isNotFound();
    // FIXME: Check response body when we have a solution to NoHandlerExceptions and swagger-ui.html
    // conflict (AS-486)
  }

  @Test
  void getAssertionShouldReturnForbiddenIfRequestIsNotSigned() {
    final UUID requestId = UUID.randomUUID();

    nonSigningWebClient
        .get()
        .uri(
            baseUrl()
                .path(PATH_GET_ASSERTION)
                .queryParam("response_type", "code")
                .queryParam("client_id", "clientId")
                .build(PARTY_ID))
        .header(HEADER_REQUEST_ID, requestId.toString())
        .accept(MediaType.APPLICATION_JSON)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .value(
            equalTo(
                ErrorResponse.builder(HttpStatus.FORBIDDEN)
                    .id(requestId)
                    .message(FORBIDDEN)
                    .error(
                        ErrorResponse.ErrorItem.builder()
                            .message(ACCESS_DENIED)
                            .errorCode(ErrorResponse.ErrorItem.INVALID_REQUEST_SIGNATURE)
                            .build())
                    .build()));
  }

  @Test
  void shouldAuthenticateSuccessfully() throws Exception {
    shouldAuthenticateSuccessfully(
        PATH_GET_ASSERTION,
        PATH_VALIDATE_ASSERTION,
        signingWebClientPublic,
        buildChallengeParameters(),
        null,
        true);
  }

  @Test
  void privateShouldAuthenticateSuccessfully() throws Exception {
    shouldAuthenticateSuccessfully(
        PATH_GET_ASSERTION_PRIVATE,
        PATH_VALIDATE_ASSERTION_PRIVATE,
        signingWebClientPrivate,
        buildChallengeParametersRequestDigest(),
        buildChallengeValidationDataRequestDigest(),
        false);
  }

  private void shouldAuthenticateSuccessfully(
      final String endpointGetAssertion,
      final String endpointValidateAssertion,
      final WebTestClient webTestClient,
      final ChallengeParameters challengeParameters,
      final ChallengeValidationData challengeValidationData,
      final boolean audit)
      throws Exception {
    final UUID requestId = UUID.randomUUID();

    if (audit) {
      auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
    }

    final String challenge =
        webTestClient
            .get()
            .uri(
                baseUrl()
                    .path(endpointGetAssertion)
                    .queryParams(toMultiValueMap(challengeParameters))
                    .build(CHALLENGE_PAYLOAD_PARTY_ID))
            .headers(standardHeaders(requestId))
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(GetAssertionResponse.class)
            .returnResult()
            .getResponseBody()
            .getPublicKey()
            .getChallenge();

    final UUID sessionId;
    if (audit) {
      sessionId = assertAuditChallenge(requestId);
    } else {
      sessionId = UUID.randomUUID();
    }

    final byte[] signature = sign(challenge);

    final ValidateAssertionRequest request;
    if (challengeValidationData != null) {
      request =
          buildValidateAssertionRequest(challenge, signature)
              .toBuilder()
              .challengeValidationData(challengeValidationData)
              .build();
    } else {
      request = buildValidateAssertionRequest(challenge, signature);
    }

    final Registration registrationServerResponse =
        Registration.builder()
            .partyId(CHALLENGE_PAYLOAD_PARTY_ID)
            .registrationId(REGISTRATION_ID)
            .scaKey(scaPublicKeyPem)
            .status(REGISTERED)
            .build();

    stubServerResponse(registrationServer, 200, registrationServerResponse);

    final LoginResponse loginServerResponse =
        stubServerResponse(loginServer, 200, buildLoginResponse());

    if (audit) {
      auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
    }
    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final CustomerDetails customerDetails =
        CustomerDetails.builder()
            .partyId(PARTY_ID)
            .surname(SURNAME)
            .forename(FORENAME)
            .title("Mr")
            .email(EMAIL)
            .build();

    final LoginDetails validateAssertionResponseLoginDetails =
        LoginDetails.builder()
            .partyId(CHALLENGE_PAYLOAD_PARTY_ID)
            .loginTime(loginServerResponse.getLogin().getLoginTime())
            .lastLoginTime(loginServerResponse.getLogin().getLastLoginTime())
            .build();

    final ValidateAssertionResponse expectedResponse =
        ValidateAssertionResponse.builder()
            .sessionId(sessionId)
            .registrationId(REGISTRATION_ID)
            .brandCode(BRAND_CODE)
            .channel(CHANNEL)
            .verificationMethod(VerificationMethod.BIOMETRIC)
            .customer(customerDetails)
            .login(validateAssertionResponseLoginDetails)
            .challengeParameters(challengeParameters)
            .build();

    webTestClient
        .post()
        .uri(baseUrl().path(endpointValidateAssertion).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(ValidateAssertionResponse.class)
        .value(
            response -> {
              if (audit) {
                assertThat(response, is(expectedResponse));
              } else {
                assertThat(response, samePropertyValuesAs(expectedResponse, "sessionId"));
              }
            });

    final RecordedRequest registrationRequest = registrationServer.takeRequest();
    assertThat(registrationRequest.getMethod(), is(HttpMethod.GET.name()));
    assertThat(
        registrationRequest.getPath(),
        is(
            String.format(
                "/registration/%s?partyId=%s", REGISTRATION_ID, CHALLENGE_PAYLOAD_PARTY_ID)));
    assertThat(registrationRequest.getHeader(HEADER_REQUEST_ID), equalTo(requestId.toString()));
    assertThat(registrationRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(registrationRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final RecordedRequest loginRequest = loginServer.takeRequest();
    assertThat(loginRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(loginRequest.getPath(), is("/login"));
    assertThat(loginRequest.getHeader(HEADER_REQUEST_ID), equalTo(requestId.toString()));
    assertThat(loginRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(loginRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());
    assertThat(
        objectMapper.readValue(loginRequest.getBody().readUtf8(), LoginRequest.class),
        is(
            LoginRequest.builder()
                .partyId(CHALLENGE_PAYLOAD_PARTY_ID)
                .brandCode(BRAND_CODE)
                .build()));

    if (audit) {
      assertAuditSuccess(requestId, sessionId);
    }
  }

  @Test
  void validateAssertionShouldReturnForbiddenForPrivateRequestSigningKey() {
    validateAssertionShouldReturnForbiddenForPrivateRequestSigningKey(
        PATH_VALIDATE_ASSERTION, signingWebClientPrivate);
  }

  @Test
  void privateValidateAssertionShouldReturnForbiddenForPublicRequestSigningKey() {
    validateAssertionShouldReturnForbiddenForPrivateRequestSigningKey(
        PATH_VALIDATE_ASSERTION_PRIVATE, signingWebClientPublic);
  }

  private void validateAssertionShouldReturnForbiddenForPrivateRequestSigningKey(
      final String endpoint, final WebTestClient webTestClient) {
    final UUID requestId = UUID.randomUUID();
    final ChallengePayload challengePayload =
        buildChallenge(Instant.now().plus(Duration.ofDays(1)));

    final String challenge = jwsCodec.encode(challengePayload);
    final ValidateAssertionRequest request =
        buildValidateAssertionRequest(challenge, new byte[] {});

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message(FORBIDDEN)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message(ACCESS_DENIED)
                    .build())
            .build();

    webTestClient
        .post()
        .uri(baseUrl().path(endpoint).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturnUnauthorizedIfChallengeDataValidationFails() throws Exception {
    shouldReturnUnauthorizedIfChallengeDataValidationFails(
        PATH_VALIDATE_ASSERTION, signingWebClientPublic, true);
  }

  @Test
  void privateShouldReturnUnauthorizedIfChallengeDataValidationFails() throws Exception {
    shouldReturnUnauthorizedIfChallengeDataValidationFails(
        PATH_VALIDATE_ASSERTION_PRIVATE, signingWebClientPrivate, false);
  }

  private void shouldReturnUnauthorizedIfChallengeDataValidationFails(
      final String endpoint, final WebTestClient webTestClient, final boolean audit)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ChallengePayload challengePayload =
        buildChallenge(Instant.now().plus(Duration.ofDays(1)))
            .toBuilder()
            .parameters(buildChallengeParametersRequestDigest())
            .build();

    final String challenge = jwsCodec.encode(challengePayload);
    final ValidateAssertionRequest request =
        buildValidateAssertionRequest(challenge, new byte[] {})
            .toBuilder()
            .challengeValidationData(
                new ChallengeValidationData(
                    ImmutableMap.<String, String>builder()
                        .put("request_digest", "requestDigestExpected")
                        .build()))
            .build();

    if (audit) {
      auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
    }

    final ErrorResponse response = buildAuthenticationFailedResponse(requestId);

    webTestClient
        .post()
        .uri(baseUrl().path(endpoint).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(response));

    if (audit) {
      assertAuditFailure(
          requestId, LoginFailureReason.BUSINESS, "Challenge Data Validation Failed");
    }
  }

  @Test
  void shouldReturnForbiddenIfRelyingPartyIsInvalid() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final byte[] signature = sign(challenge);
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(REGISTRATION_ID)
            .type("public-key")
            .response(
                ClientAssertionPayload.builder()
                    .signature(signature)
                    .clientDataJson(
                        ClientDataJson.builder()
                            .type("webauthn.get")
                            .origin("example.com") // Should end with 'ybs.co.uk'
                            .verificationMethod(VerificationMethod.BIOMETRIC)
                            .challenge(challenge)
                            .build())
                    .build())
            .build();

    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Unable to process clientDataJson")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message(
                        "response.clientDataJson.origin must be a sub-domain of the Relying Party Id")
                    .build())
            .build();

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectBody(ErrorResponse.class)
        .value(equalTo(response));
  }

  @Test
  void shouldReturnUnauthorizedIfChallengePayloadIsInvalid() {
    final UUID requestId = UUID.randomUUID();
    final String challenge = jwsCodec.encode("InvalidJson");
    final ValidateAssertionRequest request =
        buildValidateAssertionRequest(challenge, new byte[] {});

    final ErrorResponse response = buildAuthenticationFailedResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(response));
  }

  @ParameterizedTest
  @MethodSource("invalidJWSSigners")
  void shouldReturnUnauthorizedIfChallengeJwsSignatureIsNotValid(
      final JWSAlgorithm alg, final JWSSigner signer)
      throws JOSEException, JsonProcessingException {
    final JWSObject jws =
        new JWSObject(
            new JWSHeader(alg),
            new Payload(
                objectMapper.writeValueAsBytes(
                    buildChallenge(Instant.now().plus(Duration.ofDays(1))))));
    jws.sign(signer);
    final String challenge = jws.serialize();

    final UUID requestId = UUID.randomUUID();
    final ValidateAssertionRequest request =
        buildValidateAssertionRequest(challenge, new byte[] {});

    final ErrorResponse response = buildAuthenticationFailedResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(response));
  }

  @Test
  void shouldReturnUnauthorizedIfChallengePayloadHasExpired() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ChallengePayload challengePayload = buildChallenge(Instant.now());

    final String challenge = jwsCodec.encode(challengePayload);
    final ValidateAssertionRequest request =
        buildValidateAssertionRequest(challenge, new byte[] {});

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final ErrorResponse response = buildChallengeExpiredResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(response));

    assertAuditFailure(requestId, LoginFailureReason.BUSINESS, "Challenge Expired");
  }

  @ParameterizedTest
  @MethodSource("unregisteredPartyRegistrationResponses")
  void shouldReturnUnauthorizedWhenPartyIsUnregistered(
      final @SuppressWarnings(UNUSED) String label, final MockResponse response) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final byte[] signature = sign(challenge);
    final ValidateAssertionRequest request = buildValidateAssertionRequest(challenge, signature);

    registrationServer.enqueue(response);

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final ErrorResponse expectedResponse = buildAuthenticationFailedResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(expectedResponse));

    assertAuditFailure(requestId, LoginFailureReason.BUSINESS, "Invalid Device Registration");
  }

  @ParameterizedTest
  @MethodSource("incorrectPublicKeyRegistrationResponses")
  void shouldReturnUnauthorizedWhenChallengeResponseVerificationFails(
      final @SuppressWarnings(UNUSED) String label, final MockResponse response) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final byte[] signature = sign(challenge);
    final ValidateAssertionRequest request = buildValidateAssertionRequest(challenge, signature);

    registrationServer.enqueue(response);

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final ErrorResponse expectedResponse = buildAuthenticationFailedResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(expectedResponse));

    assertAuditFailure(requestId, LoginFailureReason.BUSINESS, "Invalid Challenge Response");
  }

  private ErrorResponse buildAuthenticationFailedResponse(final UUID requestId) {
    return ErrorResponse.builder(HttpStatus.UNAUTHORIZED)
        .id(requestId)
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode(ErrorResponse.ErrorItem.UNAUTHORIZED)
                .message("Authentication failed. Please register via authorization.ybs.co.uk")
                .build())
        .build();
  }

  private ErrorResponse buildChallengeExpiredResponse(final UUID requestId) {
    return ErrorResponse.builder(HttpStatus.UNAUTHORIZED)
        .id(requestId)
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode(ErrorResponse.ErrorItem.UNAUTHORIZED_CHALLENGE_EXPIRED)
                .message("Authentication failed. Challenge expired")
                .build())
        .build();
  }

  @ParameterizedTest
  @MethodSource("invalidRegistrationServiceResponses")
  void shouldReturnInternalServerErrorIfRegistrationServiceReturnsInvalidResponse(
      @SuppressWarnings(UNUSED) final String label, final MockResponse response) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final byte[] signature = sign(challenge);
    final ValidateAssertionRequest request = buildValidateAssertionRequest(challenge, signature);

    registrationServer.enqueue(response);

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.INTERNAL_SERVER_ERROR)
            .id(requestId)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message(UNEXPECTED_ERROR)
                    .build())
            .build();

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectBody(ErrorResponse.class)
        .value(equalTo(expectedResponse));

    assertAuditFailure(requestId, LoginFailureReason.TECHNICAL, "Registration Service Error");
  }

  @ParameterizedTest
  @MethodSource("invalidPublicKeyRegistrationServiceResponses")
  void shouldReturnInternalServerErrorIfRegistrationServiceReturnsInvalidResponsePublicKey(
      @SuppressWarnings(UNUSED) final String label, final MockResponse response) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final byte[] signature = sign(challenge);
    final ValidateAssertionRequest request = buildValidateAssertionRequest(challenge, signature);

    registrationServer.enqueue(response);

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.INTERNAL_SERVER_ERROR)
            .id(requestId)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message(UNEXPECTED_ERROR)
                    .build())
            .build();

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectBody(ErrorResponse.class)
        .value(equalTo(expectedResponse));

    assertAuditFailure(requestId, LoginFailureReason.TECHNICAL, "Authentication Service Error");
  }

  @Test
  void shouldReturnUnauthorizedWhenPartyLoginServiceReturnsLoginForbidden() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final byte[] signature = sign(challenge);
    final ValidateAssertionRequest request = buildValidateAssertionRequest(challenge, signature);

    stubServerResponse(
        registrationServer,
        200,
        Registration.builder()
            .partyId(PARTY_ID)
            .registrationId(REGISTRATION_ID)
            .scaKey(scaPublicKeyPem)
            .status(REGISTERED)
            .build());

    stubServerResponse(
        loginServer,
        403,
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_DECEASED)
                    .message("Customer is deceased")
                    .build())
            .build());

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final ErrorResponse expectedResponse = buildAuthenticationFailedResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectBody(ErrorResponse.class)
        .value(equalTo(expectedResponse));

    assertAuditFailure(requestId, LoginFailureReason.BUSINESS, "Customer Deceased");
  }

  @ParameterizedTest
  @MethodSource("invalidLoginServiceResponses")
  void shouldReturnInternalServerErrorIfLoginServiceReturnsInvalidResponse(
      @SuppressWarnings(UNUSED) final String label, final MockResponse response) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final byte[] signature = sign(challenge);
    final ValidateAssertionRequest request = buildValidateAssertionRequest(challenge, signature);

    stubServerResponse(
        registrationServer,
        200,
        Registration.builder()
            .partyId(PARTY_ID)
            .registrationId(REGISTRATION_ID)
            .scaKey(scaPublicKeyPem)
            .status(REGISTERED)
            .build());

    loginServer.enqueue(response);

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.INTERNAL_SERVER_ERROR)
            .id(requestId)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message(UNEXPECTED_ERROR)
                    .build())
            .build();

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectBody(ErrorResponse.class)
        .value(equalTo(expectedResponse));

    assertAuditFailure(requestId, LoginFailureReason.TECHNICAL, "Login Service Error");
  }

  @Test
  void shouldReturnInternalErrorWhenRegistrationServerIsDown() throws Exception {
    registrationServer.shutdown();
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final ValidateAssertionRequest request = buildValidateAssertionRequest(challenge, new byte[0]);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.INTERNAL_SERVER_ERROR)
            .id(requestId)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNEXPECTED_ERROR)
                    .message(UNEXPECTED_ERROR)
                    .build())
            .build();

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectBody(ErrorResponse.class)
        .value(equalTo(expectedResponse));

    assertAuditFailure(requestId, LoginFailureReason.TECHNICAL, "Registration Service Error");
  }

  @Test
  void shouldReturnInternalErrorWhenLoginServiceIsDown() throws Exception {
    loginServer.shutdown();
    final UUID requestId = UUID.randomUUID();
    final String challenge =
        jwsCodec.encode(buildChallenge(Instant.now().plus(Duration.ofDays(1))));
    final ValidateAssertionRequest request =
        buildValidateAssertionRequest(challenge, sign(challenge));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.INTERNAL_SERVER_ERROR)
            .id(requestId)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNEXPECTED_ERROR)
                    .message(UNEXPECTED_ERROR)
                    .build())
            .build();

    stubServerResponse(
        registrationServer,
        200,
        Registration.builder()
            .partyId(PARTY_ID)
            .registrationId(REGISTRATION_ID)
            .scaKey(scaPublicKeyPem)
            .status(REGISTERED)
            .build());

    auditServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    signingWebClientPublic
        .post()
        .uri(baseUrl().path(PATH_VALIDATE_ASSERTION).build())
        .headers(standardHeaders(requestId))
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectBody(ErrorResponse.class)
        .value(equalTo(expectedResponse));

    assertAuditFailure(requestId, LoginFailureReason.TECHNICAL, "Login Service Error");
  }

  private <T> T stubServerResponse(final MockWebServer server, final int status, final T body)
      throws JsonProcessingException {
    server.enqueue(
        new MockResponse()
            .setResponseCode(status)
            .setHeader("Content-Type", "application/json")
            .setBody(objectMapper.writeValueAsString(body)));
    return body;
  }

  private LoginResponse buildLoginResponse() {
    return LoginResponse.builder()
        .customer(
            uk.co.ybs.digital.authentication.service.login.dto.CustomerDetails.builder()
                .partyId(PARTY_ID)
                .forename(FORENAME)
                .surname(SURNAME)
                .title(TITLE)
                .email(EMAIL)
                .build())
        .login(
            uk.co.ybs.digital.authentication.service.login.dto.LoginDetails.builder()
                .loginTime(Instant.now())
                .lastLoginTime(Instant.now().minusMillis(10000))
                .build())
        .build();
  }

  private ValidateAssertionRequest buildValidateAssertionRequest(
      final String challenge, final byte[] signature) {
    return ValidateAssertionRequest.builder()
        .id(REGISTRATION_ID)
        .type("public-key")
        .response(
            ClientAssertionPayload.builder()
                .signature(signature)
                .clientDataJson(
                    ClientDataJson.builder()
                        .type("webauthn.get")
                        .origin("digital-api.ybs.co.uk")
                        .verificationMethod(VerificationMethod.BIOMETRIC)
                        .challenge(challenge)
                        .build())
                .build())
        .build();
  }

  private byte[] sign(final String challenge) throws Exception {
    Signature signer = Signature.getInstance("SHA256WithECDSA", "BC");
    signer.initSign(scaPrivateKey);
    signer.update(challenge.getBytes(UTF_8));
    return signer.sign();
  }

  private Matcher<ChallengePayload> hasPayload(
      final Long partyId, final ChallengeParameters challengeParameters) {
    return allOf(
        hasProperty("expiresAt", notNullValue()),
        hasProperty("partyId", equalTo(partyId)),
        hasProperty("parameters", equalTo(challengeParameters)));
  }

  private ChallengePayload decode(final String challenge) {
    try {
      JWSObject jws = JWSObject.parse(challenge);
      return objectMapper.readValue(jws.getPayload().toBytes(), ChallengePayload.class);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  private MultiValueMap<String, String> toMultiValueMap(
      final ChallengeParameters challengeParameters) {
    final Map<String, List<String>> mvm =
        challengeParameters.getMap().entrySet().stream()
            .collect(
                Collectors.toMap(Map.Entry::getKey, e -> Collections.singletonList(e.getValue())));

    return CollectionUtils.toMultiValueMap(mvm);
  }

  UriBuilder baseUrl() {
    return uriBuilderFactory.builder().port(port);
  }

  private static ChallengePayload buildChallenge(final Instant expiresAt) {
    return ChallengePayload.builder()
        .sessionId(SESSION_ID)
        .partyId(PARTY_ID)
        .expiresAt(expiresAt)
        .parameters(buildChallengeParameters())
        .build();
  }

  private static ChallengeParameters buildChallengeParameters() {
    return new ChallengeParameters(
        ImmutableMap.<String, String>builder()
            .put("response_type", "code")
            .put("client_id", "clientId")
            .put(
                "code_challenge",
                "3a06d71f26e308132b0c68a02c7aa5ba913ef08cbab313e991fd5fb7efdf1bbb")
            .put("code_challenge_method", "S256")
            .put("scope", "PAYMENT ACCOUNT_READ")
            .put("state", "some-state")
            .build());
  }

  private static ChallengeParameters buildChallengeParametersWithSessionId() {
    return new ChallengeParameters(
        ImmutableMap.<String, String>builder()
            .put("response_type", "code")
            .put("client_id", "clientId")
            .put(
                "code_challenge",
                "3a06d71f26e308132b0c68a02c7aa5ba913ef08cbab313e991fd5fb7efdf1bbb")
            .put("code_challenge_method", "S256")
            .put("scope", "PAYMENT ACCOUNT_READ")
            .put("state", "some-state")
            .put("session_id", SESSION_ID.toString())
            .build());
  }

  private static ChallengeParameters buildChallengeParametersRequestDigest() {
    return new ChallengeParameters(
        ImmutableMap.<String, String>builder().put("request_digest", "requestDigest").build());
  }

  private static ChallengeValidationData buildChallengeValidationDataRequestDigest() {
    return new ChallengeValidationData(
        ImmutableMap.<String, String>builder().put("request_digest", "requestDigest").build());
  }

  private static Stream<Arguments> invalidJWSSigners()
      throws KeyLengthException, NoSuchAlgorithmException {
    final byte[] secret = new byte[32];
    new Random().nextBytes(secret);

    KeyPairGenerator kpGen = KeyPairGenerator.getInstance("RSA");
    kpGen.initialize(2048);
    PrivateKey privateKey = kpGen.generateKeyPair().getPrivate();

    return Stream.of(
        Arguments.of(JWSAlgorithm.HS256, new MACSigner(secret)),
        Arguments.of(JWSAlgorithm.RS256, new RSASSASigner(privateKey)));
  }

  private static Stream<Arguments> invalidRegistrationServiceResponses() throws IOException {
    final ObjectMapper objectMapper = new ObjectMapper(); // NOPMD
    final String validPublicPEM = TestHelper.readResource("crypto/ec-public.pem");

    return Stream.of(
        Arguments.of("500 Internal Server Error", response().setResponseCode(500)),
        Arguments.of(
            "Not a registration object",
            response().setBody(objectMapper.writeValueAsString("\"foobar\""))),
        Arguments.of(
            "Different party Id",
            response()
                .setBody(
                    objectMapper.writeValueAsString(
                        Registration.builder()
                            .partyId(PARTY_ID + 1)
                            .registrationId(REGISTRATION_ID)
                            .status(REGISTERED)
                            .scaKey(validPublicPEM)
                            .build()))));
  }

  private static Stream<Arguments> invalidPublicKeyRegistrationServiceResponses()
      throws IOException {
    final ObjectMapper objectMapper = new ObjectMapper(); // NOPMD
    final String rsaPublicPEM = TestHelper.readResource("crypto/rsa-public.pem");

    return Stream.of(
        Arguments.of(
            "Public key is not a valid PEM object",
            response()
                .setBody(
                    objectMapper.writeValueAsString(
                        Registration.builder()
                            .partyId(PARTY_ID)
                            .registrationId(REGISTRATION_ID)
                            .status(REGISTERED)
                            .scaKey("NOT A PEM")
                            .build()))),
        Arguments.of(
            "Public key is an RSA key",
            response()
                .setBody(
                    objectMapper.writeValueAsString(
                        Registration.builder()
                            .partyId(PARTY_ID)
                            .registrationId(REGISTRATION_ID)
                            .status(REGISTERED)
                            .scaKey(rsaPublicPEM)
                            .build()))));
  }

  private static Stream<Arguments> unregisteredPartyRegistrationResponses() throws IOException {
    final ObjectMapper objectMapper = new ObjectMapper(); // NOPMD
    final String validPublicPEM = TestHelper.readResource("crypto/ec-public.pem");

    return Stream.of(
        Arguments.of("404 Not Found", response().setResponseCode(404)),
        Arguments.of(
            "Registration in INITIAL state",
            response()
                .setBody(
                    objectMapper.writeValueAsString(
                        Registration.builder()
                            .partyId(PARTY_ID)
                            .registrationId(REGISTRATION_ID)
                            .status("INITIAL")
                            .scaKey(validPublicPEM)
                            .build()))));
  }

  private static Stream<Arguments> incorrectPublicKeyRegistrationResponses() throws IOException {
    final ObjectMapper objectMapper = new ObjectMapper(); // NOPMD
    final String differentPublicPEM = TestHelper.readResource("crypto/ec-different-public.pem");
    final String differentKeyLengthPEM =
        TestHelper.readResource("crypto/ec-different-key-length-public.pem");

    return Stream.of(
        Arguments.of(
            "Public is valid but not derived from private key",
            response()
                .setBody(
                    objectMapper.writeValueAsString(
                        Registration.builder()
                            .partyId(PARTY_ID)
                            .registrationId(REGISTRATION_ID)
                            .status(REGISTERED)
                            .scaKey(differentPublicPEM)
                            .build()))),
        Arguments.of(
            "Public key uses EC curve smaller prime field",
            response()
                .setBody(
                    objectMapper.writeValueAsString(
                        Registration.builder()
                            .partyId(PARTY_ID)
                            .registrationId(REGISTRATION_ID)
                            .status(REGISTERED)
                            .scaKey(differentKeyLengthPEM)
                            .build()))));
  }

  private static Stream<Arguments> invalidLoginServiceResponses() throws Exception {
    ObjectMapper objectMapper = new ObjectMapper(); // NOPMD

    ErrorResponse response =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(UUID.randomUUID())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.LoginDenied")
                    .message("Customer login denied")
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidSignature")
                    .message("Invalid signature")
                    .build())
            .build();

    return Stream.of(
        Arguments.of("500 Internal Server Error", response().setResponseCode(500)),
        Arguments.of(
            "Not a login details object",
            response().setBody(objectMapper.writeValueAsString("\"foobar\""))),
        Arguments.of(
            "Error Response with non Login.Denied Error",
            response().setBody(objectMapper.writeValueAsString(response))));
  }

  private static MockResponse response() {
    return new MockResponse().setHeader("Content-Type", "application/json");
  }

  private Consumer<HttpHeaders> standardHeaders(final UUID requestId) {
    return headers -> {
      headers.add(HEADER_REQUEST_ID, requestId.toString());
      headers.add(HEADER_CHANNEL, CHANNEL);
      headers.add(HEADER_BRAND_CODE, BRAND_CODE);
      headers.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON));
    };
  }

  private UUID assertAuditChallenge(final UUID requestId)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = auditServer.takeRequest();
    assertThat(request.getMethod(), is(HttpMethod.POST.name()));
    assertThat(request.getPath(), is(PATH_AUDIT_LOGIN_CHALLENGE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditLoginChallengeRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditLoginChallengeRequest.class);
    assertThat(actual.getIpAddress(), is(IP_ADDRESS));
    assertThat(actual.getUserSession().getSessionId(), is(notNullValue()));
    assertThat(actual.getUserSession().getPartyId(), is(CHALLENGE_PAYLOAD_PARTY_ID));
    assertThat(actual.getUserSession().getChannel(), is(CHANNEL));
    assertThat(actual.getUserSession().getBrandCode(), is(BRAND_CODE));

    return actual.getUserSession().getSessionId();
  }

  private void assertAuditSuccess(final UUID requestId, final UUID sessionId)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = auditServer.takeRequest();
    assertThat(request.getMethod(), is(HttpMethod.POST.name()));
    assertThat(request.getPath(), is(PATH_AUDIT_LOGIN_SUCCESS));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditLoginSuccessRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditLoginSuccessRequest.class);
    assertThat(
        actual,
        is(
            AuditLoginSuccessRequest.builder()
                .ipAddress(IP_ADDRESS)
                .userSession(
                    UserSession.builder()
                        .sessionId(sessionId)
                        .partyId(CHALLENGE_PAYLOAD_PARTY_ID)
                        .channel(CHANNEL)
                        .brandCode(BRAND_CODE)
                        .registrationId(REGISTRATION_ID)
                        .verificationMethod(VerificationMethod.BIOMETRIC)
                        .build())
                .build()));
  }

  private void assertAuditFailure(
      final UUID requestId, final LoginFailureReason reason, final String message)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest recordedRequest = auditServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is(PATH_AUDIT_LOGIN_FAILURE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditLoginFailureRequest actual =
        objectMapper.readValue(
            recordedRequest.getBody().readUtf8(), AuditLoginFailureRequest.class);
    assertThat(
        actual,
        is(
            AuditLoginFailureRequest.builder()
                .reason(reason)
                .message(message)
                .ipAddress(IP_ADDRESS)
                .userSession(
                    UserSession.builder()
                        .sessionId(SESSION_ID)
                        .partyId(PARTY_ID)
                        .channel(CHANNEL)
                        .brandCode(BRAND_CODE)
                        .registrationId(REGISTRATION_ID)
                        .verificationMethod(VerificationMethod.BIOMETRIC)
                        .build())
                .build()));
  }

  private static FailureRequest buildFailureRequest(final String challenge) {
    return FailureRequest.builder()
        .registrationId(REGISTRATION_ID)
        .challenge(challenge)
        .verificationMethod(VerificationMethod.BIOMETRIC)
        .build();
  }
}
