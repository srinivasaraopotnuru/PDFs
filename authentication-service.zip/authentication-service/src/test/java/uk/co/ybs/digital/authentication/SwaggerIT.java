package uk.co.ybs.digital.authentication;

import java.net.URI;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles({"test", "text-logging"})
class SwaggerIT {

  @Autowired WebTestClient nonSigningWebClient;

  @LocalServerPort private int port;

  @ValueSource(strings = {"swagger-resources", "v2/api-docs", "swagger-ui/"})
  @ParameterizedTest
  void shouldReturnOkForSwaggerEndpoints(final String path) {
    nonSigningWebClient.get().uri(getInfoURI(path)).exchange().expectStatus().isOk();
  }

  @Test
  void apiDocsShouldContainNonEmptyPathsObject() {
    nonSigningWebClient
        .get()
        .uri(getInfoURI("v2/api-docs"))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("paths")
        .isNotEmpty();
  }

  private URI getInfoURI(final String path) {
    return URI.create("http://localhost:" + port + "/auth/" + path);
  }
}
