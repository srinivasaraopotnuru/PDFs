package uk.co.ybs.digital.authentication;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;
import org.junit.jupiter.api.Test;

class ExceptionUtilsTest {

  private static final String ORIGINAL = "original";

  @Test
  void findExactCauseShouldReturnEmptyOptionalIfExceptionIsNotInTheStack() {
    IndexOutOfBoundsException root = new IndexOutOfBoundsException("root");
    IllegalStateException original = new IllegalStateException(ORIGINAL, root);

    Optional<IllegalArgumentException> actual =
        ExceptionUtils.findExactCause(original, IllegalArgumentException.class);

    assertFalse(actual.isPresent());
  }

  @Test
  void findExactCauseShouldReturnExpectedExceptionIfItExists() {
    IndexOutOfBoundsException root = new IndexOutOfBoundsException("root");
    IllegalArgumentException expected = new IllegalArgumentException("expected", root);
    IllegalStateException original = new IllegalStateException(ORIGINAL, expected);

    Optional<IllegalArgumentException> actual =
        ExceptionUtils.findExactCause(original, IllegalArgumentException.class);

    assertTrue(actual.isPresent());
    assertThat(actual.get(), sameInstance(expected));
  }

  @Test
  void findExactCauseShouldReturnFirstExceptionInStack() {
    IllegalArgumentException second = new IllegalArgumentException("second");
    IllegalArgumentException first = new IllegalArgumentException("first", second);
    IllegalStateException original = new IllegalStateException(ORIGINAL, first);

    Optional<IllegalArgumentException> actual =
        ExceptionUtils.findExactCause(original, IllegalArgumentException.class);

    assertTrue(actual.isPresent());
    assertThat(actual.get(), sameInstance(first));
  }

  @Test
  void findExactCauseDoesNotReturnSubclasses() {
    RuntimeException expected = new RuntimeException("expected");
    IllegalArgumentException first = new IllegalArgumentException("first", expected);
    IllegalStateException original = new IllegalStateException(ORIGINAL, first);

    Optional<RuntimeException> actual =
        ExceptionUtils.findExactCause(original, RuntimeException.class);

    assertTrue(actual.isPresent());
    assertThat(actual.get(), sameInstance(expected));
  }
}
