package uk.co.ybs.digital.authentication.service.registration;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.models.HttpMethod;
import java.io.IOException;
import java.util.Random;
import java.util.UUID;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.authentication.service.registration.dto.Registration;

class RegistrationServiceTest {

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final UUID REQUEST_ID = UUID.randomUUID();

  private MockWebServer mockWebServer;
  private RegistrationService registrationService;
  private ObjectMapper objectMapper;

  private static final String CONTENT_TYPE = "Content-Type";
  private static final String APPLICATION_JSON = "application/json";

  @BeforeEach
  void setUp() throws IOException {
    objectMapper = new ObjectMapper();
    mockWebServer = new MockWebServer();
    mockWebServer.start();
    WebClient webClient =
        WebClient.builder().baseUrl("http://localhost:" + mockWebServer.getPort()).build();
    registrationService = new RegistrationService(webClient);
  }

  @AfterEach
  void teardown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void registrationServiceShouldReturnRegistrationThatBelongsToTheParty() throws Exception {
    Registration response = buildRegistration();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(objectMapper.writeValueAsString(response)));

    final Registration actual =
        registrationService.getActiveRegistration(
            REQUEST_ID, response.getPartyId(), response.getRegistrationId());
    assertThat(actual, equalTo(response));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.GET.name()));
    assertThat(
        recordedRequest.getPath(),
        is(
            String.format(
                "/registration/%s?partyId=%s",
                response.getRegistrationId(), response.getPartyId())));
    assertThat(recordedRequest.getHeader(REQUEST_ID_HEADER), is(REQUEST_ID.toString()));
  }

  @Test
  void registrationServiceShouldReturnUnregisteredPartyExceptionIfResponseStatusIs404() {
    UUID registrationId = UUID.randomUUID();
    Long partyId = new Random().nextLong();

    mockWebServer.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setResponseCode(404));

    UnregisteredPartyException ex =
        assertThrows(
            UnregisteredPartyException.class,
            () -> registrationService.getActiveRegistration(REQUEST_ID, partyId, registrationId));
    assertThat(
        ex.getMessage(),
        equalTo(
            String.format(
                "No registration found for Party Id [%s] and Registration Id [%s]",
                partyId, registrationId)));
  }

  @ParameterizedTest
  @EnumSource(
      value = HttpStatus.class,
      names = {"SERVICE_UNAVAILABLE", "BAD_REQUEST", "FORBIDDEN"})
  void registrationServiceShouldReturnRegistrationServiceErrorIfResponseCodeIsNot200Or404(
      final HttpStatus status) {
    UUID registrationId = UUID.randomUUID();
    Long partyId = new Random().nextLong();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setResponseCode(status.value()));

    RegistrationServiceException ex =
        assertThrows(
            RegistrationServiceException.class,
            () -> registrationService.getActiveRegistration(REQUEST_ID, partyId, registrationId));
    assertThat(
        ex.getMessage(),
        equalTo(String.format("Unexpected status code from Registration Service [%s]", status)));
  }

  @Test
  void registrationServiceShouldReturnRegistrationServiceErrorIfResponseContentTypeIsNotJson()
      throws Exception {
    Registration response = buildRegistration();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, "application/text")
            .setBody(objectMapper.writeValueAsString(response)));

    RegistrationServiceException ex =
        assertThrows(
            RegistrationServiceException.class,
            () ->
                registrationService.getActiveRegistration(
                    REQUEST_ID, response.getPartyId(), response.getRegistrationId()));
    assertThat(
        ex.getMessage(),
        containsString(
            "Content type 'application/text' not supported for bodyType=uk.co.ybs.digital.authentication.service.registration.dto.Registration"));
  }

  @Test
  void registrationServiceShouldReturnRegistrationServiceErrorIfResponseIsNotAValidRegistration()
      throws Exception {
    UUID registrationId = UUID.randomUUID();
    Long partyId = new Random().nextLong();

    mockWebServer.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody("{}"));

    RegistrationServiceException ex =
        assertThrows(
            RegistrationServiceException.class,
            () -> registrationService.getActiveRegistration(REQUEST_ID, partyId, registrationId));

    assertThat(
        ex.getMessage(),
        startsWith("Unhandled error when calling Registration Service: JSON decoding error"));
  }

  @Test
  void
      registrationServiceShouldReturnRegistrationServiceExceptionIfRegistrationDoesNotBelongToTheParty()
          throws JsonProcessingException {
    Registration response = buildRegistration();
    Long requestedPartyId = response.getPartyId() + 1;

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(objectMapper.writeValueAsString(response)));

    RegistrationServiceException ex =
        assertThrows(
            RegistrationServiceException.class,
            () ->
                registrationService.getActiveRegistration(
                    REQUEST_ID, requestedPartyId, response.getRegistrationId()));
    assertThat(
        ex.getMessage(),
        equalTo(
            String.format(
                "Registration does not belong to requested partyId - requested: [%s], received: [%s]",
                requestedPartyId, response.getPartyId())));
  }

  @Test
  void
      registrationServiceShouldReturnUnregisteredPartyExceptionIfRegistrationIsNotInARegisteredState()
          throws JsonProcessingException {
    Registration response = buildRegistration("INITIAL");

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(objectMapper.writeValueAsString(response)));

    UnregisteredPartyException ex =
        assertThrows(
            UnregisteredPartyException.class,
            () ->
                registrationService.getActiveRegistration(
                    REQUEST_ID, response.getPartyId(), response.getRegistrationId()));
    assertThat(ex.getMessage(), equalTo("Registration is not in REGISTERED state: INITIAL"));
  }

  @Test
  void registrationServiceShouldReturnRegistrationServiceErrorIfResponseBodyIsMissing()
      throws JsonProcessingException {
    mockWebServer.enqueue(new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON));

    RegistrationServiceException ex =
        assertThrows(
            RegistrationServiceException.class,
            () ->
                registrationService.getActiveRegistration(
                    REQUEST_ID, 12345L, UUID.randomUUID())); // NOPMD
    assertThat(
        ex.getMessage(),
        equalTo("Received successful response but no body from registration service"));
  }

  private static Registration buildRegistration(final String state) {
    UUID registrationId = UUID.randomUUID();
    Long partyId = new Random().nextLong();

    return Registration.builder()
        .partyId(partyId)
        .registrationId(registrationId)
        .status(state)
        .scaKey("pem")
        .build();
  }

  private static Registration buildRegistration() {
    return buildRegistration("REGISTERED");
  }
}
