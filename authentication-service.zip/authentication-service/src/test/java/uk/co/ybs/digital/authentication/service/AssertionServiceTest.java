package uk.co.ybs.digital.authentication.service;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.core.IsEqual.equalTo;
import static org.hamcrest.core.IsSame.sameInstance;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableMap;
import io.micrometer.core.lang.NonNull;
import java.security.PublicKey;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.authentication.VerificationMethod;
import uk.co.ybs.digital.authentication.config.AuthenticationServiceProperties;
import uk.co.ybs.digital.authentication.crypto.CryptoException;
import uk.co.ybs.digital.authentication.crypto.JwsCodec.ChallengeTamperingDetectedException;
import uk.co.ybs.digital.authentication.crypto.PublicKeyFactory;
import uk.co.ybs.digital.authentication.crypto.SignatureVerifier;
import uk.co.ybs.digital.authentication.crypto.SignatureVerifierFactory;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeExpiredException;
import uk.co.ybs.digital.authentication.service.challenge.ChallengePayload;
import uk.co.ybs.digital.authentication.service.challenge.ChallengePayloadValidator;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeService;
import uk.co.ybs.digital.authentication.service.login.LoginDeniedException;
import uk.co.ybs.digital.authentication.service.login.LoginRequest;
import uk.co.ybs.digital.authentication.service.login.LoginService;
import uk.co.ybs.digital.authentication.service.login.dto.LoginResponse;
import uk.co.ybs.digital.authentication.service.registration.RegistrationService;
import uk.co.ybs.digital.authentication.service.registration.UnregisteredPartyException;
import uk.co.ybs.digital.authentication.service.registration.dto.Registration;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;
import uk.co.ybs.digital.authentication.web.dto.request.ClientAssertionPayload;
import uk.co.ybs.digital.authentication.web.dto.request.ClientDataJson;
import uk.co.ybs.digital.authentication.web.dto.request.FailureRequest;
import uk.co.ybs.digital.authentication.web.dto.request.InvalidClientDataJsonException;
import uk.co.ybs.digital.authentication.web.dto.request.ValidateAssertionRequest;
import uk.co.ybs.digital.authentication.web.dto.response.CustomerDetails;
import uk.co.ybs.digital.authentication.web.dto.response.LoginDetails;
import uk.co.ybs.digital.authentication.web.dto.response.PublicKeyAssertion;
import uk.co.ybs.digital.authentication.web.dto.response.ValidateAssertionResponse;

@ExtendWith(MockitoExtension.class)
class AssertionServiceTest {

  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final UUID REGISTRATION_ID = UUID.randomUUID();
  private static final UUID SESSION_ID = UUID.randomUUID();
  private static final String CLIENT_DATA_JSON_TYPE = "webauthn.get";
  private static final String ASSERTION_TYPE = "public-key";
  private static final VerificationMethod USER_AUTHENTICATION_METHOD = VerificationMethod.BIOMETRIC;
  private static final String PEM = "pem";
  private static final int CHALLENGE_TIMEOUT_SECONDS = 60;
  private static final String CHALLENGE = "challenge";
  private static final byte[] SIGNATURE = "signature".getBytes();
  private static final long PARTY_ID = 123456789L;
  private static final long CHALLENGE_PAYLOAD_PARTY_ID = 987654321L;
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String BRAND_CODE = "YBS";
  private static final String CHANNEL = "SAPP";
  public static final String TITLE = "Mr";
  public static final String FORENAME = "John";
  public static final String SURNAME = "Smith";
  public static final String EMAIL = "john.smith@ybs.co.uk";

  @Mock private ChallengeService challengeService;

  @Mock private ChallengePayloadValidator challengePayloadValidator;

  @Mock private RegistrationService registrationService;

  @Mock private LoginService loginService;

  @Mock private PublicKeyFactory publicKeyFactory;

  @Mock private SignatureVerifierFactory signatureVerifierFactory;

  @Mock private AssertionAuditor assertionAuditor;

  @Mock private AuthenticationServiceProperties authenticationServiceProperties;

  @InjectMocks private AssertionService assertionService;

  @Test
  void reportFailureShouldReturnSuccess() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final FailureRequest failureRequest = buildFailureRequest();
    final ChallengePayload challengePayload = buildChallengePayload();

    when(challengeService.verifyChallenge(CHALLENGE)).thenReturn(challengePayload);

    assertionService.reportFailure(failureRequest, requestMetadata);

    verify(assertionAuditor)
        .auditFailure(
            SESSION_ID,
            CHALLENGE_PAYLOAD_PARTY_ID,
            requestMetadata,
            REGISTRATION_ID,
            VerificationMethod.BIOMETRIC,
            new LoginFailureException());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void getAssertionShouldReturnChallengeForPartyId(final boolean audit) {
    final ChallengeParameters challengeParameters = buildChallengeParameters();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    doReturn(CHALLENGE_TIMEOUT_SECONDS)
        .when(authenticationServiceProperties)
        .getChallengeTimeoutSeconds();
    doReturn(CHALLENGE)
        .when(challengeService)
        .getChallenge(any(), eq(PARTY_ID), eq(challengeParameters), eq(Duration.ofMillis(60_000)));

    final PublicKeyAssertion actual =
        assertionService.getAssertion(
            SESSION_ID, PARTY_ID, challengeParameters, requestMetadata, audit);

    final PublicKeyAssertion expected =
        PublicKeyAssertion.builder().challenge(CHALLENGE).timeout(60_000L).build();

    assertThat(actual, equalTo(expected));

    if (audit) {
      verify(assertionAuditor).auditChallenge(any(), eq(PARTY_ID), eq(requestMetadata));
    } else {
      verifyNoInteractions(assertionAuditor);
    }
  }

  @Test
  void getAssertionShouldThrowAnExceptionIfTheChallengeIsNull() {
    final ChallengeParameters challengeParameters = buildChallengeParameters();

    doReturn(CHALLENGE_TIMEOUT_SECONDS)
        .when(authenticationServiceProperties)
        .getChallengeTimeoutSeconds();
    doReturn(null).when(challengeService).getChallenge(any(), any(), any(), any());

    NullPointerException ex =
        assertThrows(
            NullPointerException.class,
            () ->
                assertionService.getAssertion(
                    SESSION_ID, PARTY_ID, challengeParameters, buildRequestMetadata(), true));

    assertThat(ex.getMessage(), equalTo("challenge is marked non-null but is null"));

    verifyNoInteractions(assertionAuditor);
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void validateAssertionShouldReturnValidateAssertionResponseOnSuccessfulLogin(final boolean audit)
      throws InvalidClientDataJsonException {
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(UUID.randomUUID())
            .type(ASSERTION_TYPE)
            .response(buildClientAssertionPayload())
            .build();

    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Registration registration = buildRegistration(request.getId());
    final ChallengePayload challengePayload = buildChallengePayload();
    final LoginResponse loginResponse = buildLoginDetails();
    final LoginRequest loginRequest = buildLoginRequest();

    final PublicKey publicKey = mock(PublicKey.class);
    final SignatureVerifier signatureVerifier = mock(SignatureVerifier.class);

    final CustomerDetails customerDetails =
        CustomerDetails.builder()
            .partyId(PARTY_ID)
            .title(TITLE)
            .forename(FORENAME)
            .surname(SURNAME)
            .email(EMAIL)
            .build();

    final LoginDetails validateAssertionLoginDetails =
        LoginDetails.builder()
            .partyId(CHALLENGE_PAYLOAD_PARTY_ID)
            .loginTime(loginResponse.getLogin().getLoginTime())
            .lastLoginTime(loginResponse.getLogin().getLastLoginTime())
            .build();

    final ValidateAssertionResponse expectedResponse =
        ValidateAssertionResponse.builder()
            .sessionId(SESSION_ID)
            .registrationId(request.getId())
            .brandCode(BRAND_CODE)
            .channel(CHANNEL)
            .verificationMethod(USER_AUTHENTICATION_METHOD)
            .customer(customerDetails)
            .login(validateAssertionLoginDetails)
            .challengeParameters(challengePayload.getParameters())
            .build();

    when(registrationService.getActiveRegistration(
            REQUEST_ID, CHALLENGE_PAYLOAD_PARTY_ID, request.getId()))
        .thenReturn(registration);
    when(challengeService.verifyChallenge(CHALLENGE)).thenReturn(challengePayload);
    when(publicKeyFactory.fromPem(PEM)).thenReturn(publicKey);
    when(signatureVerifierFactory.build(publicKey)).thenReturn(signatureVerifier);
    when(signatureVerifier.verify(CHALLENGE.getBytes(UTF_8), SIGNATURE)).thenReturn(true);
    when(loginService.login(REQUEST_ID, loginRequest)).thenReturn(loginResponse);

    final ValidateAssertionResponse response =
        assertionService.validationAssertion(request, requestMetadata, audit);
    assertThat(response, is(expectedResponse));

    if (audit) {
      verify(assertionAuditor)
          .auditSuccess(
              response.getSessionId(),
              CHALLENGE_PAYLOAD_PARTY_ID,
              requestMetadata,
              request.getId(),
              USER_AUTHENTICATION_METHOD);
    } else {
      verifyNoInteractions(assertionAuditor);
    }
  }

  @Test
  void validateAssertionShouldThrowInvalidAssertionExceptionIfTheRelyingPartyIsInvalid() {
    final ClientAssertionPayload clientAssertionPayload =
        ClientAssertionPayload.builder()
            .signature(SIGNATURE)
            .clientDataJson(
                ClientDataJson.builder()
                    .verificationMethod(USER_AUTHENTICATION_METHOD)
                    .challenge(CHALLENGE)
                    .origin("example.com")
                    .type(CLIENT_DATA_JSON_TYPE)
                    .build())
            .build();

    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(UUID.randomUUID())
            .type(ASSERTION_TYPE)
            .response(clientAssertionPayload)
            .build();

    InvalidClientDataJsonException ex =
        assertThrows(
            InvalidClientDataJsonException.class,
            () -> assertionService.validationAssertion(request, buildRequestMetadata(), true));
    assertThat(
        ex.getMessage(),
        equalTo("response.clientDataJson.origin must be a sub-domain of the Relying Party Id"));

    verifyNoInteractions(assertionAuditor);
  }

  @Test
  void validateAssertionShouldPropagateErrorThrownByChallengeServiceVerifyChallenge() {
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(UUID.randomUUID())
            .type(ASSERTION_TYPE)
            .response(buildClientAssertionPayload())
            .build();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final ChallengeTamperingDetectedException expected =
        new ChallengeTamperingDetectedException("Failed to verify JWS signature");

    when(challengeService.verifyChallenge(any())).thenThrow(expected);

    ChallengeTamperingDetectedException ex =
        assertThrows(
            ChallengeTamperingDetectedException.class,
            () -> assertionService.validationAssertion(request, requestMetadata, true));
    assertThat(ex, sameInstance(expected));

    verifyNoInteractions(assertionAuditor);
  }

  @Test
  void validateAssertionShouldPropagateErrorThrownByChallengePayloadValidator() {
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(REGISTRATION_ID)
            .type(ASSERTION_TYPE)
            .response(buildClientAssertionPayload())
            .build();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final ChallengeExpiredException expected =
        new ChallengeExpiredException("Challenge has expired");

    when(challengeService.verifyChallenge(any())).thenReturn(buildChallengePayload());
    doThrow(expected).when(challengePayloadValidator).validate(any(), any());

    ChallengeExpiredException ex =
        assertThrows(
            ChallengeExpiredException.class,
            () -> assertionService.validationAssertion(request, requestMetadata, true));
    assertThat(ex, sameInstance(expected));

    verify(assertionAuditor)
        .auditFailure(
            any(),
            eq(CHALLENGE_PAYLOAD_PARTY_ID),
            eq(requestMetadata),
            eq(REGISTRATION_ID),
            eq(USER_AUTHENTICATION_METHOD),
            eq(ex));
  }

  @Test
  void validateAssertionShouldPropagateExceptionThrownFromRegistrationService() {
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(REGISTRATION_ID)
            .type(ASSERTION_TYPE)
            .response(buildClientAssertionPayload())
            .build();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final UnregisteredPartyException expected = new UnregisteredPartyException("Unregistered");

    when(challengeService.verifyChallenge(any())).thenReturn(buildChallengePayload());
    when(registrationService.getActiveRegistration(
            REQUEST_ID, CHALLENGE_PAYLOAD_PARTY_ID, request.getId()))
        .thenThrow(expected);

    UnregisteredPartyException ex =
        assertThrows(
            UnregisteredPartyException.class,
            () -> assertionService.validationAssertion(request, requestMetadata, true));
    assertThat(ex, sameInstance(expected));

    verify(assertionAuditor)
        .auditFailure(
            any(),
            eq(CHALLENGE_PAYLOAD_PARTY_ID),
            eq(requestMetadata),
            eq(REGISTRATION_ID),
            eq(USER_AUTHENTICATION_METHOD),
            eq(ex));
  }

  @Test
  void validateAssertionShouldPropagateExceptionThrownFromPublicKeyFactory() {
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(REGISTRATION_ID)
            .type(ASSERTION_TYPE)
            .response(buildClientAssertionPayload())
            .build();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Registration registration = buildRegistration(request.getId());
    final CryptoException expected =
        new CryptoException("Unexpected error occurred when attempting to build public key");

    when(registrationService.getActiveRegistration(
            REQUEST_ID, CHALLENGE_PAYLOAD_PARTY_ID, request.getId()))
        .thenReturn(registration);
    when(challengeService.verifyChallenge(any())).thenReturn(buildChallengePayload());
    when(publicKeyFactory.fromPem(PEM)).thenThrow(expected);

    CryptoException ex =
        assertThrows(
            CryptoException.class,
            () -> assertionService.validationAssertion(request, requestMetadata, true));
    assertThat(ex, sameInstance(expected));

    verify(assertionAuditor)
        .auditFailure(
            any(),
            eq(CHALLENGE_PAYLOAD_PARTY_ID),
            eq(requestMetadata),
            eq(REGISTRATION_ID),
            eq(USER_AUTHENTICATION_METHOD),
            eq(ex));
  }

  @Test
  void validateAssertionShouldPropagateErrorThrownFromSignatureFactory() {
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(REGISTRATION_ID)
            .type(ASSERTION_TYPE)
            .response(buildClientAssertionPayload())
            .build();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Registration registration = buildRegistration(request.getId());
    final PublicKey publicKey = mock(PublicKey.class);

    final CryptoException expected =
        new CryptoException("Error occurred constructing a signature verifier");

    when(registrationService.getActiveRegistration(
            REQUEST_ID, CHALLENGE_PAYLOAD_PARTY_ID, request.getId()))
        .thenReturn(registration);
    when(challengeService.verifyChallenge(any())).thenReturn(buildChallengePayload());
    when(publicKeyFactory.fromPem(PEM)).thenReturn(publicKey);
    when(signatureVerifierFactory.build(publicKey)).thenThrow(expected);

    CryptoException ex =
        assertThrows(
            CryptoException.class,
            () -> assertionService.validationAssertion(request, requestMetadata, true));
    assertThat(ex, sameInstance(expected));

    verify(assertionAuditor)
        .auditFailure(
            any(),
            eq(CHALLENGE_PAYLOAD_PARTY_ID),
            eq(requestMetadata),
            eq(REGISTRATION_ID),
            eq(USER_AUTHENTICATION_METHOD),
            eq(ex));
  }

  @Test
  void validateAssertionShouldPropagateErrorIfSignatureIsNotVerified() {
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(REGISTRATION_ID)
            .type(ASSERTION_TYPE)
            .response(buildClientAssertionPayload())
            .build();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Registration registration = buildRegistration(request.getId());
    final PublicKey publicKey = mock(PublicKey.class);
    final SignatureVerifier signatureVerifier = mock(SignatureVerifier.class);

    when(registrationService.getActiveRegistration(
            REQUEST_ID, CHALLENGE_PAYLOAD_PARTY_ID, request.getId()))
        .thenReturn(registration);
    when(challengeService.verifyChallenge(any())).thenReturn(buildChallengePayload());
    when(publicKeyFactory.fromPem(PEM)).thenReturn(publicKey);
    when(signatureVerifierFactory.build(publicKey)).thenReturn(signatureVerifier);
    when(signatureVerifier.verify(CHALLENGE.getBytes(UTF_8), SIGNATURE)).thenReturn(false);

    SignatureNotVerifiedException ex =
        assertThrows(
            SignatureNotVerifiedException.class,
            () -> assertionService.validationAssertion(request, requestMetadata, true));
    assertThat(ex.getMessage(), equalTo("Signature verification failed"));

    verify(assertionAuditor)
        .auditFailure(
            any(),
            eq(CHALLENGE_PAYLOAD_PARTY_ID),
            eq(requestMetadata),
            eq(REGISTRATION_ID),
            eq(USER_AUTHENTICATION_METHOD),
            eq(ex));
  }

  @Test
  void validateAssertionShouldPropagateExceptionThrownByLoginService() {
    final ValidateAssertionRequest request =
        ValidateAssertionRequest.builder()
            .id(REGISTRATION_ID)
            .type(ASSERTION_TYPE)
            .response(buildClientAssertionPayload())
            .build();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Registration registration = buildRegistration(request.getId());
    final ChallengePayload challengePayload = buildChallengePayload();
    final LoginRequest loginRequest = buildLoginRequest();

    final PublicKey publicKey = mock(PublicKey.class);
    final SignatureVerifier signatureVerifier = mock(SignatureVerifier.class);

    final LoginDeniedException expected =
        new LoginDeniedException(
            LoginDeniedException.Reason.CUSTOMER_DECEASED, "Customer is deceased");

    when(registrationService.getActiveRegistration(
            REQUEST_ID, CHALLENGE_PAYLOAD_PARTY_ID, request.getId()))
        .thenReturn(registration);
    when(challengeService.verifyChallenge(CHALLENGE)).thenReturn(challengePayload);
    when(publicKeyFactory.fromPem(PEM)).thenReturn(publicKey);
    when(signatureVerifierFactory.build(publicKey)).thenReturn(signatureVerifier);
    when(signatureVerifier.verify(CHALLENGE.getBytes(UTF_8), SIGNATURE)).thenReturn(true);
    when(loginService.login(REQUEST_ID, loginRequest)).thenThrow(expected);

    LoginDeniedException ex =
        assertThrows(
            LoginDeniedException.class,
            () -> assertionService.validationAssertion(request, requestMetadata, true));
    assertThat(ex, sameInstance(expected));

    verify(assertionAuditor)
        .auditFailure(
            any(),
            eq(CHALLENGE_PAYLOAD_PARTY_ID),
            eq(requestMetadata),
            eq(REGISTRATION_ID),
            eq(USER_AUTHENTICATION_METHOD),
            eq(ex));
  }

  private @NonNull ClientAssertionPayload buildClientAssertionPayload() {
    return ClientAssertionPayload.builder()
        .signature(SIGNATURE)
        .clientDataJson(buildClientDataJson())
        .build();
  }

  private ClientDataJson buildClientDataJson() {
    return ClientDataJson.builder()
        .verificationMethod(USER_AUTHENTICATION_METHOD)
        .challenge(CHALLENGE)
        .origin("digital-api.ybs.co.uk")
        .type(CLIENT_DATA_JSON_TYPE)
        .build();
  }

  private ChallengePayload buildChallengePayload() {
    return ChallengePayload.builder()
        .sessionId(SESSION_ID)
        .partyId(CHALLENGE_PAYLOAD_PARTY_ID)
        .expiresAt(Instant.now())
        .parameters(buildChallengeParameters())
        .build();
  }

  private LoginRequest buildLoginRequest() {
    return LoginRequest.builder().brandCode(BRAND_CODE).partyId(CHALLENGE_PAYLOAD_PARTY_ID).build();
  }

  private LoginResponse buildLoginDetails() {
    final Instant loginTime = Instant.now();
    final Instant lastLoginTime = loginTime.minus(Duration.ofDays(1));

    return LoginResponse.builder()
        .customer(
            uk.co.ybs.digital.authentication.service.login.dto.CustomerDetails.builder()
                .partyId(PARTY_ID)
                .title(TITLE)
                .forename(FORENAME)
                .surname(SURNAME)
                .email(EMAIL)
                .build())
        .login(
            uk.co.ybs.digital.authentication.service.login.dto.LoginDetails.builder()
                .loginTime(loginTime)
                .lastLoginTime(lastLoginTime)
                .build())
        .build();
  }

  private ChallengeParameters buildChallengeParameters() {
    return new ChallengeParameters(
        ImmutableMap.<String, String>builder()
            .put("client_id", "SavingsApp")
            .put("response_type", "code")
            .build());
  }

  private Registration buildRegistration(final UUID registrationId) {
    return Registration.builder()
        .partyId(PARTY_ID)
        .registrationId(registrationId)
        .status("REGISTERED")
        .scaKey(PEM)
        .build();
  }

  private RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .ipAddress(IP_ADDRESS)
        .channel(CHANNEL)
        .brandCode(BRAND_CODE)
        .build();
  }

  private static FailureRequest buildFailureRequest() {
    return FailureRequest.builder()
        .registrationId(REGISTRATION_ID)
        .challenge(CHALLENGE)
        .verificationMethod(VerificationMethod.BIOMETRIC)
        .build();
  }
}
