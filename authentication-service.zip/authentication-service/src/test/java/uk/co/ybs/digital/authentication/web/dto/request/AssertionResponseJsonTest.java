package uk.co.ybs.digital.authentication.web.dto.request;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.authentication.web.dto.response.GetAssertionResponse;
import uk.co.ybs.digital.authentication.web.dto.response.PublicKeyAssertion;

@JsonTest
class AssertionResponseJsonTest {

  @Autowired private JacksonTester<GetAssertionResponse> json;

  @Value("classpath:api/response/assertion-response.json")
  private Resource expectedJson;

  private GetAssertionResponse response =
      new GetAssertionResponse(
          PublicKeyAssertion.builder()
              .challenge("some-challenge")
              .timeout(60000L) // NOPMD
              .build()); // NOPMD

  @Test
  void serializes() throws IOException {
    assertThat(json.write(response)).isEqualToJson(expectedJson, JSONCompareMode.STRICT);
  }
}
