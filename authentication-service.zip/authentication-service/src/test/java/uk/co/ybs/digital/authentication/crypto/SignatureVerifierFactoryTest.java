package uk.co.ybs.digital.authentication.crypto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.mockito.Mockito.mock;

import java.security.GeneralSecurityException;
import java.security.PublicKey;
import java.security.Security;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class SignatureVerifierFactoryTest {
  @BeforeAll
  static void setUp() {
    Security.addProvider(new BouncyCastleProvider());
  }

  @Test
  void shouldBuildASignatureVerifier() throws GeneralSecurityException {
    PublicKey publicKey = mock(PublicKey.class);
    assertThat(
        new SignatureVerifierFactory().build(publicKey), instanceOf(SignatureVerifier.class));
  }
}
