package uk.co.ybs.digital.authentication.crypto;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import java.security.SecureRandom;
import java.util.Map;
import javax.crypto.spec.SecretKeySpec;
import net.bytebuddy.utility.RandomString;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class JwsCodecTest {

  private final SecureRandom random = new SecureRandom();

  private JwsCodec jwsCodec;

  @BeforeEach
  void setUp() throws JOSEException {
    final byte[] bytes = new byte[32];
    random.nextBytes(bytes);
    final SecretKeySpec secretKeySpec = new SecretKeySpec(bytes, "AES");
    jwsCodec =
        new JwsCodec(
            new ObjectMapper(), new MACSigner(secretKeySpec), new MACVerifier(secretKeySpec));
  }

  @Test
  void decodeShouldDecodeEncodedPayload() {
    final String payload = RandomString.make(20);
    final String encoded = jwsCodec.encode(payload);
    final String decoded = jwsCodec.decode(encoded, String.class);
    assertThat(decoded, equalTo(decoded));
  }

  @Test
  void encodeShouldThrowEncodeExceptionWhenObjectMapperFails() {
    Object object = new Object(); // Object instances are not serializable by default
    final JwsCodec.EncodeException ex =
        assertThrows(JwsCodec.EncodeException.class, () -> jwsCodec.encode(object));
    assertThat(ex.getCause(), instanceOf(JsonProcessingException.class));
  }

  @Test
  void decodeShouldThrowDecodeExceptionWhenInputIsNotValidJWSFormat() {
    JwsCodec.ChallengeTamperingDetectedException ex =
        assertThrows(
            JwsCodec.ChallengeTamperingDetectedException.class,
            () -> jwsCodec.decode("invalid jws", String.class));
    assertThat(
        ex.getMessage(),
        equalTo(
            "Failed to verify or decode JWS object: Invalid serialized unsecured/JWS/JWE object: Missing part delimiters"));
  }

  @Test
  void decodeShouldThrowDecodeExceptionWhenJWSCannotBeVerified() {
    String encoded = jwsCodec.encode("foo");
    String tampered = encoded.replaceFirst("\\.", ".a"); // Add a letter to the payload
    JwsCodec.ChallengeTamperingDetectedException ex =
        assertThrows(
            JwsCodec.ChallengeTamperingDetectedException.class,
            () -> jwsCodec.decode(tampered, String.class));
    assertThat(ex.getMessage(), equalTo("Failed to verify JWS signature"));
  }

  @Test
  void decodeShouldThrowDecodeExceptionWhenDeserializationFails() {
    String encoded = jwsCodec.encode("foo");
    JwsCodec.ChallengeTamperingDetectedException ex =
        assertThrows(
            JwsCodec.ChallengeTamperingDetectedException.class,
            () -> jwsCodec.decode(encoded, Map.class));
    assertThat(ex.getMessage(), startsWith("Failed to parse JWS payload:"));
  }
}
