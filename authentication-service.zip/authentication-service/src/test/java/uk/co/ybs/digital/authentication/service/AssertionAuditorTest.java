package uk.co.ybs.digital.authentication.service;

import static org.mockito.Mockito.verify;

import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.authentication.VerificationMethod;
import uk.co.ybs.digital.authentication.service.audit.AuditService;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginChallengeRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginFailureRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginSuccessRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.LoginFailureReason;
import uk.co.ybs.digital.authentication.service.audit.dto.UserSession;
import uk.co.ybs.digital.authentication.service.audit.dto.UserSessionBasic;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeDataValidationFailedException;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeExpiredException;
import uk.co.ybs.digital.authentication.service.login.LoginDeniedException;
import uk.co.ybs.digital.authentication.service.login.LoginServiceException;
import uk.co.ybs.digital.authentication.service.registration.RegistrationServiceException;
import uk.co.ybs.digital.authentication.service.registration.UnregisteredPartyException;

@ExtendWith(MockitoExtension.class)
class AssertionAuditorTest {

  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final UUID SESSION_ID = UUID.randomUUID();
  private static final UUID REGISTRATION_ID = UUID.randomUUID();
  private static final Long PARTY_ID = 1234567890L;
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String CHANNEL = "SAPP";
  private static final String BRAND_CODE = "YBS";

  @InjectMocks private AssertionAuditor testSubject;

  @Mock private AuditService auditService;

  @Test
  void shouldAuditChallenge() {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AuditLoginChallengeRequest expectedAuditRequest =
        AuditLoginChallengeRequest.builder()
            .ipAddress(IP_ADDRESS)
            .userSession(
                UserSessionBasic.builderBasic()
                    .sessionId(SESSION_ID)
                    .partyId(PARTY_ID)
                    .channel(CHANNEL)
                    .brandCode(BRAND_CODE)
                    .build())
            .build();

    testSubject.auditChallenge(SESSION_ID, PARTY_ID, requestMetadata);

    verify(auditService).auditLoginChallenge(expectedAuditRequest, REQUEST_ID);
  }

  @ParameterizedTest
  @EnumSource(VerificationMethod.class)
  void shouldAuditSuccess(final VerificationMethod verificationMethod) {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AuditLoginSuccessRequest expectedAuditRequest =
        AuditLoginSuccessRequest.builder()
            .ipAddress(IP_ADDRESS)
            .userSession(
                UserSession.builder()
                    .sessionId(SESSION_ID)
                    .partyId(PARTY_ID)
                    .channel(CHANNEL)
                    .brandCode(BRAND_CODE)
                    .registrationId(REGISTRATION_ID)
                    .verificationMethod(verificationMethod)
                    .build())
            .build();

    testSubject.auditSuccess(
        SESSION_ID, PARTY_ID, requestMetadata, REGISTRATION_ID, verificationMethod);

    verify(auditService).auditLoginSuccess(expectedAuditRequest, REQUEST_ID);
  }

  @ParameterizedTest
  @MethodSource({"failureThrowables", "failureLoginDeniedExceptions"})
  void shouldAuditFailure(
      final Throwable throwable, final LoginFailureReason reason, final String message) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    testSubject.auditFailure(
        SESSION_ID,
        PARTY_ID,
        requestMetadata,
        REGISTRATION_ID,
        VerificationMethod.BIOMETRIC,
        throwable);
    shouldAuditFailure(VerificationMethod.BIOMETRIC, reason, message);
  }

  @ParameterizedTest
  @EnumSource(VerificationMethod.class)
  void shouldAuditFailure(final VerificationMethod verificationMethod) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    testSubject.auditFailure(
        SESSION_ID,
        PARTY_ID,
        requestMetadata,
        REGISTRATION_ID,
        verificationMethod,
        new ChallengeExpiredException(""));
    shouldAuditFailure(verificationMethod, LoginFailureReason.BUSINESS, "Challenge Expired");
  }

  private void shouldAuditFailure(
      final VerificationMethod verificationMethod,
      final LoginFailureReason reason,
      final String message) {
    final AuditLoginFailureRequest expectedAuditRequest =
        AuditLoginFailureRequest.builder()
            .reason(reason)
            .message(message)
            .ipAddress(IP_ADDRESS)
            .userSession(
                UserSession.builder()
                    .sessionId(SESSION_ID)
                    .partyId(PARTY_ID)
                    .channel(CHANNEL)
                    .brandCode(BRAND_CODE)
                    .registrationId(REGISTRATION_ID)
                    .verificationMethod(verificationMethod)
                    .build())
            .build();

    verify(auditService).auditLoginFailure(expectedAuditRequest, REQUEST_ID);
  }

  private static Stream<Arguments> failureThrowables() {
    return Stream.of(
        Arguments.of(
            new ChallengeExpiredException(""), LoginFailureReason.BUSINESS, "Challenge Expired"),
        Arguments.of(
            new ChallengeDataValidationFailedException(""),
            LoginFailureReason.BUSINESS,
            "Challenge Data Validation Failed"),
        Arguments.of(
            new SignatureNotVerifiedException(""),
            LoginFailureReason.BUSINESS,
            "Invalid Challenge Response"),
        Arguments.of(
            new UnregisteredPartyException(""),
            LoginFailureReason.BUSINESS,
            "Invalid Device Registration"),
        Arguments.of(
            new LoginFailureException(), LoginFailureReason.BUSINESS, "Invalid Client Credentials"),
        Arguments.of(
            new RegistrationServiceException(""),
            LoginFailureReason.TECHNICAL,
            "Registration Service Error"),
        Arguments.of(
            new LoginServiceException(""), LoginFailureReason.TECHNICAL, "Login Service Error"),
        Arguments.of(
            new Throwable(), LoginFailureReason.TECHNICAL, "Authentication Service Error"));
  }

  private static Stream<Arguments> failureLoginDeniedExceptions() {
    return Stream.of(
        Arguments.of(
            new LoginDeniedException(
                LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_CUSTOMER_HUB, ""),
            LoginFailureReason.TECHNICAL,
            "Customer Not Found (Customer Hub)"),
        Arguments.of(
            new LoginDeniedException(LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_LDAP, ""),
            LoginFailureReason.TECHNICAL,
            "Customer Not Found (LDAP)"),
        Arguments.of(
            new LoginDeniedException(LoginDeniedException.Reason.CUSTOMER_DECEASED, ""),
            LoginFailureReason.BUSINESS,
            "Customer Deceased"),
        Arguments.of(
            new LoginDeniedException(LoginDeniedException.Reason.CUSTOMER_INVALID_GROUP, ""),
            LoginFailureReason.TECHNICAL,
            "Customer Group Invalid"),
        Arguments.of(
            new LoginDeniedException(
                LoginDeniedException.Reason.CUSTOMER_INVALID_PASSWORD_STATE, ""),
            LoginFailureReason.PASSWORD_STATE,
            "Customer Password State Invalid"));
  }

  private RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .ipAddress(IP_ADDRESS)
        .channel(CHANNEL)
        .brandCode(BRAND_CODE)
        .build();
  }
}
