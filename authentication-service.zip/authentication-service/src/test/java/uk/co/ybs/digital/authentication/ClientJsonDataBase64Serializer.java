package uk.co.ybs.digital.authentication;

import static java.nio.charset.StandardCharsets.UTF_8;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdScalarSerializer;
import java.io.IOException;
import java.util.Base64;
import uk.co.ybs.digital.authentication.web.dto.request.ClientDataJson;

public class ClientJsonDataBase64Serializer extends StdScalarSerializer<ClientDataJson> {

  private static final long serialVersionUID = 1L;

  public ClientJsonDataBase64Serializer() {
    super(ClientDataJson.class);
  }

  @Override
  public void serialize(
      final ClientDataJson value, final JsonGenerator gen, final SerializerProvider provider)
      throws IOException {

    String serialized =
        "{"
            + "\"challenge\":\""
            + value.getChallenge()
            + "\","
            + "\"origin\":\""
            + value.getOrigin()
            + "\","
            + "\"verificationMethod\":\""
            + value.getVerificationMethod()
            + "\","
            + "\"type\":\""
            + value.getType()
            + "\""
            + "}";

    gen.writeString(Base64.getEncoder().encodeToString(serialized.getBytes(UTF_8)));
  }
}
