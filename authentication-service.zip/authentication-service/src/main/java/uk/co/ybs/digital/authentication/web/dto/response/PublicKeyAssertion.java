package uk.co.ybs.digital.authentication.web.dto.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = PublicKeyAssertion.PublicKeyAssertionBuilder.class)
public class PublicKeyAssertion {

  public static final String RELYING_PARTY_ID = "ybs.co.uk";

  @NonNull public String challenge;

  @NonNull public Long timeout;

  public String rpId = RELYING_PARTY_ID;

  @JsonPOJOBuilder(withPrefix = "")
  public static class PublicKeyAssertionBuilder {}
}
