package uk.co.ybs.digital.authentication.web;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@ApiImplicitParams({
  @ApiImplicitParam(name = "x-ybs-channel", paramType = "header", required = true),
  @ApiImplicitParam(name = "x-ybs-brand-code", paramType = "header", required = true)
})
@Target({ElementType.METHOD, ElementType.ANNOTATION_TYPE, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ApiRequestMetadata {}
