package uk.co.ybs.digital.authentication.crypto;

public class CryptoException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public CryptoException(final String message) {
    super(message, null);
  }

  public CryptoException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
