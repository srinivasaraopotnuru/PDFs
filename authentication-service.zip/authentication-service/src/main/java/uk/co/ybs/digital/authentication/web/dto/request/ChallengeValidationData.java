package uk.co.ybs.digital.authentication.web.dto.request;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Map;
import lombok.NonNull;
import lombok.Value;

@Value
public class ChallengeValidationData {

  @NonNull Map<String, String> map; // NOPMD

  @JsonCreator
  public ChallengeValidationData(final Map<String, String> map) {
    this.map = map;
  }

  @JsonValue
  public Map<String, String> getMap() {
    return map;
  }
}
