package uk.co.ybs.digital.authentication.service.challenge;

public class ChallengeExpiredException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public ChallengeExpiredException(final String message) {
    super(message);
  }
}
