package uk.co.ybs.digital.authentication.service;

public class SignatureNotVerifiedException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public SignatureNotVerifiedException(final String message) {
    super(message);
  }
}
