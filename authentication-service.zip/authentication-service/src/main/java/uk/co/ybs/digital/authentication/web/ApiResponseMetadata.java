package uk.co.ybs.digital.authentication.web;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ResponseHeader;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@ApiResponses(
    value = {
      @ApiResponse(
          code = 200,
          message = "",
          responseHeaders = {
            @ResponseHeader(
                name = "x-ybs-session-id",
                description = "The SessionID",
                response = String.class),
            @ResponseHeader(name = "x-ybs-puid", description = "The PUID", response = String.class)
          })
    })
@Target({ElementType.METHOD, ElementType.ANNOTATION_TYPE, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ApiResponseMetadata {}
