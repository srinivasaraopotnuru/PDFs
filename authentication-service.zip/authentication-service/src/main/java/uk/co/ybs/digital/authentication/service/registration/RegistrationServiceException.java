package uk.co.ybs.digital.authentication.service.registration;

public class RegistrationServiceException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public RegistrationServiceException(final String message, final Object... args) {
    this(null, message, args);
  }

  public RegistrationServiceException(
      final Throwable cause, final String message, final Object... args) {
    super(String.format(message, args), cause);
  }
}
