package uk.co.ybs.digital.authentication.web.dto.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = CustomerDetails.CustomerDetailsBuilder.class)
public class CustomerDetails {

  @NonNull public Long partyId;

  @NonNull public String forename;

  @NonNull public String surname;

  public String title;

  public String email;

  @JsonPOJOBuilder(withPrefix = "")
  public static class CustomerDetailsBuilder {}
}
