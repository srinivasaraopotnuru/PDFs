package uk.co.ybs.digital.authentication.service.login;

import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.Value;

@Value
@EqualsAndHashCode(callSuper = false)
public class LoginDeniedException extends LoginServiceException {
  private static final long serialVersionUID = 1L;

  @NonNull private final Reason reason;

  public LoginDeniedException(final Reason reason, final String message, final Object... args) {
    super(message, args);
    this.reason = reason;
  }

  public enum Reason {
    CUSTOMER_NOT_FOUND_CUSTOMER_HUB,
    CUSTOMER_NOT_FOUND_LDAP,
    CUSTOMER_DECEASED,
    CUSTOMER_INVALID_GROUP,
    CUSTOMER_INVALID_PASSWORD_STATE
  }
}
