package uk.co.ybs.digital.authentication.service.registration;

import static uk.co.ybs.digital.authentication.config.AuthenticationServiceConfig.REQUEST_ID_HEADER;

import io.micrometer.core.annotation.Timed;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.authentication.service.registration.dto.Registration;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Slf4j
@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class RegistrationService {

  private static final String REGISTERED_STATE = "REGISTERED";
  private final WebClient registrationServiceWebClient;

  public Registration getActiveRegistration(
      final UUID requestId, final Long partyId, final UUID registrationId) {
    return registrationServiceWebClient
        .get()
        .uri("/registration/{registrationId}?partyId={partyId}", registrationId, partyId)
        .header(REQUEST_ID_HEADER, requestId.toString())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(
            RegistrationService::notOK,
            response -> handleStatusNotOK(partyId, registrationId, response))
        .bodyToMono(Registration.class)
        .flatMap(registration -> handlePartyIdMismatch(partyId, registration))
        .flatMap(this::handleInvalidRegistrationState)
        .onErrorMap(
            this::isUnhandledException,
            ex ->
                new RegistrationServiceException(
                    ex, "Unhandled error when calling Registration Service: %s", ex.getMessage()))
        .switchIfEmpty(
            Mono.error(
                new RegistrationServiceException(
                    "Received successful response but no body from registration service")))
        .block();
  }

  private boolean isUnhandledException(final Throwable ex) {
    return !(ex instanceof RegistrationServiceException);
  }

  private static boolean notOK(final HttpStatus status) {
    return status != HttpStatus.OK;
  }

  private Mono<Registration> handleInvalidRegistrationState(final Registration registration) {
    if (!REGISTERED_STATE.equals(registration.getStatus())) {
      return Mono.error(
          new UnregisteredPartyException(
              "Registration is not in %s state: %s", REGISTERED_STATE, registration.getStatus()));
    }
    return Mono.just(registration);
  }

  private Mono<Registration> handlePartyIdMismatch(
      final Long partyId, final Registration registration) {
    if (!registration.getPartyId().equals(partyId)) {
      return Mono.error(
          new RegistrationServiceException(
              "Registration does not belong to requested partyId - requested: [%s], received: [%s]",
              partyId, registration.getPartyId()));
    }
    return Mono.just(registration);
  }

  private Mono<RegistrationServiceException> handleStatusNotOK(
      final Long partyId, final UUID registrationId, final ClientResponse response) {
    if (response.statusCode() == HttpStatus.NOT_FOUND) {
      return Mono.just(
          new UnregisteredPartyException(
              "No registration found for Party Id [%s] and Registration Id [%s]",
              partyId, registrationId));
    }
    return Mono.just(
        new RegistrationServiceException(
            "Unexpected status code from Registration Service [%s]", response.statusCode()));
  }
}
