package uk.co.ybs.digital.authentication.crypto;

import java.security.InvalidKeyException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/** Simple wrapper around a Signature class that wraps */
@Slf4j
@RequiredArgsConstructor
public class SignatureVerifier {
  private final Signature verifier;
  private final PublicKey publicKey;

  public boolean verify(final byte[] payload, final byte[] signature) {
    try {
      verifier.initVerify(publicKey);
      verifier.update(payload);
      return verifier.verify(signature);
    } catch (SignatureException e) {
      log.info(
          "Signature verification failed due to exception [{}]: {}",
          e.getClass().getSimpleName(),
          e.getMessage());
      return false;
    } catch (InvalidKeyException e) {
      throw new CryptoException("Attempted to validate signature with invalid key", e);
    }
  }
}
