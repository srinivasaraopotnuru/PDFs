package uk.co.ybs.digital.authentication.service.registration;

public class UnregisteredPartyException extends RegistrationServiceException {
  private static final long serialVersionUID = 1L;

  public UnregisteredPartyException(final String message, final Object... args) {
    super(String.format(message, args));
  }
}
