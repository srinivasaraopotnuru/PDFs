package uk.co.ybs.digital.authentication.service.login;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class LoginRequest {

  @NonNull public Long partyId;

  @NonNull public String brandCode;
}
