package uk.co.ybs.digital.authentication.service.challenge;

import java.time.Clock;
import java.time.Instant;
import lombok.RequiredArgsConstructor;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;
import uk.co.ybs.digital.authentication.web.dto.request.ChallengeValidationData;

@Component
@RequiredArgsConstructor
public class ChallengePayloadValidator {

  private final Clock clock;

  public void validate(
      final ChallengePayload payload, @Nullable final ChallengeValidationData validationData) {
    validateExpiresAt(payload.getExpiresAt());
    if (validationData != null) {
      validateChallengeParameters(payload.getParameters(), validationData);
    }
  }

  private void validateExpiresAt(final Instant expiresAt) {
    final Instant now = clock.instant();
    if (!now.isBefore(expiresAt)) {
      throw new ChallengeExpiredException("Challenge has expired");
    }
  }

  private void validateChallengeParameters(
      final ChallengeParameters parameters, final ChallengeValidationData validationData) {
    validationData
        .getMap()
        .forEach(
            (key, expectedValue) -> {
              final String value = parameters.getMap().get(key);
              if (value == null) {
                throw new ChallengeDataValidationFailedException(
                    String.format("No challenge parameter for key [%s]", key));
              }

              if (!value.equals(expectedValue)) {
                throw new ChallengeDataValidationFailedException(
                    String.format(
                        "Expected challenge parameter [%s] for key [%s] but got [%s]",
                        expectedValue, key, value));
              }
            });
  }
}
