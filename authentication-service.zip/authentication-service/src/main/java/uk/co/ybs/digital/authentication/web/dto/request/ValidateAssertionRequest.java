package uk.co.ybs.digital.authentication.web.dto.request;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = ValidateAssertionRequest.ValidateAssertionRequestBuilder.class)
public class ValidateAssertionRequest {
  @NonNull
  @ApiModelProperty(
      value = "The key id",
      example = "0306db4a-4a17-4045-a360-efcb478bdaf7",
      required = true)
  public UUID id;

  @NonNull
  @ApiModelProperty(
      value = "The type of assertion",
      allowableValues = "public-key",
      required = true)
  public String type;

  @NonNull
  @ApiModelProperty(required = true)
  public ClientAssertionPayload response;

  @ApiModelProperty(value = "Data to be validated against the challenge")
  public ChallengeValidationData challengeValidationData;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ValidateAssertionRequestBuilder {}
}
