package uk.co.ybs.digital.authentication.service.registration.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = Registration.RegistrationBuilder.class)
public class Registration {

  @NonNull public Long partyId;

  @NonNull public UUID registrationId;

  @NonNull public String status;

  @NonNull public String scaKey;

  @JsonPOJOBuilder(withPrefix = "")
  public static class RegistrationBuilder {}
}
