package uk.co.ybs.digital.authentication.service.login;

public class LoginServiceException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public LoginServiceException(final String message, final Object... args) {
    this(null, message, args);
  }

  public LoginServiceException(final Throwable cause, final String message, final Object... args) {
    super(String.format(message, args), cause);
  }
}
