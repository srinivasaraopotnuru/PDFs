package uk.co.ybs.digital.authentication.service.challenge;

public class ChallengeDataValidationFailedException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public ChallengeDataValidationFailedException(final String message) {
    super(message);
  }
}
