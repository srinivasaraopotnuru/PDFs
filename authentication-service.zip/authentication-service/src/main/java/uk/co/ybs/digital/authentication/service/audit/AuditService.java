package uk.co.ybs.digital.authentication.service.audit;

import io.micrometer.core.annotation.Timed;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginChallengeRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginFailureRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginSuccessRequest;
import uk.co.ybs.digital.authentication.web.dto.response.ErrorResponse;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@Slf4j
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class AuditService {

  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling audit service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Audit service returned error status: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private final WebClient auditServiceWebClient;

  public void auditLoginChallenge(final AuditLoginChallengeRequest request, final UUID requestId) {
    postAudit("/login/challenge", request, requestId);
  }

  public void auditLoginSuccess(final AuditLoginSuccessRequest request, final UUID requestId) {
    postAudit("/login/success", request, requestId);
  }

  public void auditLoginFailure(final AuditLoginFailureRequest request, final UUID requestId) {
    postAudit("/login/failure", request, requestId);
  }

  private void postAudit(final String uri, final Object requestPayload, final UUID requestId) {
    auditServiceWebClient
        .post()
        .uri(uri)
        .header(REQUEST_ID_HEADER, requestId.toString())
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(requestPayload)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .toBodilessEntity()
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AuditServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .block();
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AuditServiceException);
  }

  private Mono<AuditServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new AuditServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
