package uk.co.ybs.digital.authentication.service.login.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.time.Instant;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = LoginDetails.LoginDetailsBuilder.class)
public class LoginDetails {
  @NonNull public Instant loginTime;

  @NonNull public Instant lastLoginTime;

  @JsonPOJOBuilder(withPrefix = "")
  public static class LoginDetailsBuilder {}
}
