package uk.co.ybs.digital.authentication.crypto;

import java.security.GeneralSecurityException;
import java.security.PublicKey;
import java.security.Signature;
import org.springframework.stereotype.Component;

@Component
public class SignatureVerifierFactory {
  public SignatureVerifier build(final PublicKey publicKey) {
    try {
      Signature verifier = Signature.getInstance("SHA256WithECDSA", "BC");
      return new SignatureVerifier(verifier, publicKey);
    } catch (GeneralSecurityException e) {
      throw new CryptoException("Error occurred constructing a signature verifier", e);
    }
  }
}
