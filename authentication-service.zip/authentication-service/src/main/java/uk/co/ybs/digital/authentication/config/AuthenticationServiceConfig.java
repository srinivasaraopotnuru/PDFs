package uk.co.ybs.digital.authentication.config;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.KeyLengthException;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.MACVerifier;
import java.security.Security;
import java.time.Clock;
import java.util.Base64;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import uk.co.ybs.digital.authentication.web.RequestMetadataArgumentResolver;

@Slf4j
@Configuration
@EnableConfigurationProperties(AuthenticationServiceProperties.class)
public class AuthenticationServiceConfig implements WebMvcConfigurer {
  private final transient AuthenticationServiceProperties properties;

  public static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  public AuthenticationServiceConfig(final AuthenticationServiceProperties properties) {
    this.properties = properties;
    Security.addProvider(new BouncyCastleProvider());
  }

  @Override
  public void addArgumentResolvers(final List<HandlerMethodArgumentResolver> resolvers) {
    resolvers.add(new RequestMetadataArgumentResolver());
  }

  @Bean
  public Clock clock() {
    // The application should be run in UK timezone for consistency with other
    // YBS timezone handling.
    final Clock systemClock = Clock.systemDefaultZone();
    log.info("System clock is: {}", systemClock);
    return systemClock;
  }

  @Bean
  public JWSSigner jwsSigner() throws KeyLengthException {
    final byte[] macKey = Base64.getDecoder().decode(properties.getChallengeMACKey());
    return new MACSigner(macKey);
  }

  @Bean
  public JWSVerifier jwsVerifier() throws JOSEException {
    final byte[] macKey = Base64.getDecoder().decode(properties.getChallengeMACKey());
    return new MACVerifier(macKey);
  }
}
