package uk.co.ybs.digital.authentication.config;

import com.fasterxml.classmate.TypeResolver;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Arrays;
import lombok.NonNull;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import uk.co.ybs.digital.authentication.web.AuthenticationController;
import uk.co.ybs.digital.authentication.web.dto.request.ClientAssertionPayload;
import uk.co.ybs.digital.authentication.web.dto.request.ClientDataJson;
import uk.co.ybs.digital.security.HttpHeaderNames;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
  @Bean
  public Docket api(final TypeResolver typeResolver) {
    return new Docket(DocumentationType.SWAGGER_2)
        .directModelSubstitute(ClientAssertionPayload.class, ClientAssertionPayloadStub.class)
        .additionalModels(typeResolver.resolve(ClientDataJson.class))
        .globalOperationParameters(
            Arrays.asList(
                new ParameterBuilder()
                    .name("x-ybs-request-id")
                    .description("Unique identifier for the request")
                    .modelRef(new ModelRef("uuid"))
                    .parameterType("header")
                    .required(false)
                    .build(),
                new ParameterBuilder()
                    .name(HttpHeaderNames.REQUEST_SIGNATURE)
                    .description("Base64 encoded request signature")
                    .modelRef(new ModelRef("string"))
                    .parameterType("header")
                    .required(true)
                    .build(),
                new ParameterBuilder()
                    .name(HttpHeaderNames.REQUEST_SIGNATURE_KEY_ID)
                    .description("Identifier for the key used to sign the request")
                    .modelRef(new ModelRef("string"))
                    .parameterType("header")
                    .required(true)
                    .build()))
        .select()
        .apis(
            RequestHandlerSelectors.basePackage(
                AuthenticationController.class.getPackage().getName()))
        .build();
  }

  @ApiModel(value = "ClientAssertionPayload")
  public interface ClientAssertionPayloadStub {
    @NonNull
    @ApiModelProperty(
        value = "Base64 encoded string representing the signature of the challenge",
        example = "aW52YWxpZCBqc29u",
        required = true)
    byte[] getSignature();

    @NonNull
    @ApiModelProperty(
        value = "Base64 encoded JSON string of the ClientDataJson model",
        example = "ewogICAgICAidXNlclZl=",
        required = true)
    String getClientDataJson();
  }
}
