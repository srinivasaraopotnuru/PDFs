package uk.co.ybs.digital.authentication.web.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import java.util.UUID;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Singular;
import lombok.Value;
import org.springframework.http.HttpStatus;

@Value
@Builder
@JsonDeserialize(builder = ErrorResponse.ErrorResponseBuilder.class)
public final class ErrorResponse {
  @NonNull public UUID id;

  @NonNull public String code;

  @NonNull public String message;

  @Singular public List<? extends ErrorItem> errors;

  public static ErrorResponseBuilder builder() {
    return new ErrorResponseBuilder();
  }

  public static ErrorResponseBuilder builder(final HttpStatus status) {
    return builder()
        .code(String.format("%s %s", status.value(), status.getReasonPhrase()))
        .message(status.getReasonPhrase());
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ErrorResponseBuilder {}

  @Value
  @Builder
  @AllArgsConstructor(access = AccessLevel.PRIVATE)
  @JsonDeserialize(builder = ErrorItem.ErrorItemBuilder.class)
  public static final class ErrorItem {
    public static final String ACCESS_DENIED = "AccessDenied";
    public static final String INVALID_REQUEST_SIGNATURE = "AccessDenied.InvalidRequestSignature";
    public static final String ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_NOT_FOUND_CUSTOMER_HUB =
        "AccessDenied.LoginDenied.CustomerNotFoundCustomerHub";
    public static final String ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_NOT_FOUND_LDAP =
        "AccessDenied.LoginDenied.CustomerNotFoundLdap";
    public static final String ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_DECEASED =
        "AccessDenied.LoginDenied.CustomerDeceased";
    public static final String ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_INVALID_GROUP =
        "AccessDenied.LoginDenied.CustomerInvalidGroup";
    public static final String ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_INVALID_PASSWORD_STATE =
        "AccessDenied.LoginDenied.CustomerInvalidPasswordState";
    public static final String FIELD_INVALID = "Field.Invalid";
    public static final String FIELD_MISSING = "Field.Missing";
    public static final String HEADER_INVALID = "Header.Invalid";
    public static final String HEADER_MISSING = "Header.Missing";
    public static final String RESOURCE_INVALID_FORMAT = "Resource.InvalidFormat";
    public static final String RESOURCE_NOT_FOUND = "Resource.NotFound";
    public static final String UNAUTHORIZED = "Unauthorized";
    public static final String UNAUTHORIZED_CHALLENGE_EXPIRED = "Unauthorized.ChallengeExpired";
    public static final String UNEXPECTED_ERROR = "UnexpectedError";
    public static final String UNSUPPORTED_METHOD = "Unsupported.Method";

    @NonNull public String errorCode;

    @NonNull public String message;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public String path;

    @JsonPOJOBuilder(withPrefix = "")
    public static class ErrorItemBuilder {}
  }
}
