package uk.co.ybs.digital.authentication;

public enum VerificationMethod {
  BIOMETRIC,
  PASSCODE
}
