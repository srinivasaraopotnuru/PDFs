package uk.co.ybs.digital.authentication.service.login;

import static uk.co.ybs.digital.authentication.config.AuthenticationServiceConfig.REQUEST_ID_HEADER;

import com.google.common.collect.ImmutableMap;
import io.micrometer.core.annotation.Timed;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.authentication.service.login.dto.LoginResponse;
import uk.co.ybs.digital.authentication.web.dto.response.ErrorResponse;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@Slf4j
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class LoginService {

  private static final Map<String, LoginDeniedException.Reason> ERROR_CODE_MAP =
      buildErrorCodeMap();

  private final WebClient loginServiceWebClient;

  public LoginResponse login(final UUID requestId, final LoginRequest request) {
    return loginServiceWebClient
        .post()
        .uri("/login")
        .header(REQUEST_ID_HEADER, requestId.toString())
        .bodyValue(request)
        .retrieve()
        .onStatus(LoginService::notOK, response -> handleStatusNotOk(request, response))
        .bodyToMono(LoginResponse.class)
        .onErrorMap(
            this::isUnhandledException,
            ex ->
                new LoginServiceException(
                    ex, "Unhandled error when calling Login Service: %s", ex.getMessage()))
        .switchIfEmpty(
            Mono.error(
                new LoginServiceException(
                    "Received successful response but no body from login service")))
        .block();
  }

  private boolean isUnhandledException(final Throwable ex) {
    return !(ex instanceof LoginServiceException);
  }

  private Mono<LoginServiceException> handleStatusNotOk(
      final LoginRequest request, final ClientResponse clientResponse) {
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .switchIfEmpty(
            Mono.defer(
                () ->
                    Mono.error(
                        new LoginServiceException(
                            "Unexpected status code from Login Service: %s",
                            clientResponse.statusCode()))))
        .flatMap(
            errorResponse ->
                Mono.error(getLoginDeniedException(request, errorResponse, clientResponse)));
  }

  private LoginServiceException getLoginDeniedException(
      final LoginRequest request,
      final ErrorResponse errorResponse,
      final ClientResponse clientResponse) {
    if (clientResponse.statusCode().equals(HttpStatus.FORBIDDEN)) {
      final LoginDeniedException.Reason reason = getLoginDeniedExceptionReason(errorResponse);
      if (reason != null) {
        return new LoginDeniedException(
            reason, String.format("Login denied for partyId %s", request.getPartyId()));
      }
    }
    return new LoginServiceException("Unexpected response from Login Service: %s", errorResponse);
  }

  private LoginDeniedException.Reason getLoginDeniedExceptionReason(
      final ErrorResponse errorResponse) {
    final List<? extends ErrorResponse.ErrorItem> errorItems = errorResponse.getErrors();
    if (errorItems.size() == 1) {
      final ErrorResponse.ErrorItem errorItem = errorItems.get(0);
      return ERROR_CODE_MAP.get(errorItem.getErrorCode());
    }
    return null;
  }

  private static boolean notOK(final HttpStatus status) {
    return status != HttpStatus.OK;
  }

  private static Map<String, LoginDeniedException.Reason> buildErrorCodeMap() {
    return ImmutableMap.<String, LoginDeniedException.Reason>builder()
        .put(
            ErrorResponse.ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_NOT_FOUND_CUSTOMER_HUB,
            LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_CUSTOMER_HUB)
        .put(
            ErrorResponse.ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_NOT_FOUND_LDAP,
            LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_LDAP)
        .put(
            ErrorResponse.ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_DECEASED,
            LoginDeniedException.Reason.CUSTOMER_DECEASED)
        .put(
            ErrorResponse.ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_INVALID_GROUP,
            LoginDeniedException.Reason.CUSTOMER_INVALID_GROUP)
        .put(
            ErrorResponse.ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_INVALID_PASSWORD_STATE,
            LoginDeniedException.Reason.CUSTOMER_INVALID_PASSWORD_STATE)
        .build();
  }
}
