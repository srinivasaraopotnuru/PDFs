package uk.co.ybs.digital.authentication.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.bouncycastle.util.encoders.Hex;
import org.springframework.http.HttpHeaders;

public class AssertionHeaders { // NOPMD

  public static HttpHeaders addHeaders(final String partyId, final String sessionId)
      throws NoSuchAlgorithmException {
    HttpHeaders responseHeaders = new HttpHeaders();
    MessageDigest digest = MessageDigest.getInstance("SHA-256");
    byte[] hash = digest.digest(partyId.getBytes(StandardCharsets.UTF_8));
    String sha256hex = new String(Hex.encode(hash));
    responseHeaders.add("x-ybs-session-id", sessionId);
    responseHeaders.add("x-ybs-puid", sha256hex);
    return responseHeaders;
  }
}
