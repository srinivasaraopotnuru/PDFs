package uk.co.ybs.digital.authentication.service.audit.dto;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class AuditLoginFailureRequest {

  @NonNull private final LoginFailureReason reason;

  @NonNull private final String message;

  @NonNull private final String ipAddress;

  @NonNull private final UserSession userSession;
}
