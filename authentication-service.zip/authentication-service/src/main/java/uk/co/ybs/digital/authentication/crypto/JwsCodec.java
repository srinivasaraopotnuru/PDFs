package uk.co.ybs.digital.authentication.crypto;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.Payload;
import java.io.IOException;
import java.text.ParseException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwsCodec {
  private final ObjectMapper objectMapper;
  private final JWSSigner jwsSigner;
  private final JWSVerifier jwsVerifier;

  public <T> String encode(final T payload) {
    try {
      JWSObject jws =
          new JWSObject(
              new JWSHeader(JWSAlgorithm.HS256),
              new Payload(objectMapper.writeValueAsBytes(payload)));
      jws.sign(jwsSigner);
      return jws.serialize();
    } catch (JsonProcessingException | JOSEException e) {
      throw new EncodeException("Failed to encode payload", e);
    }
  }

  public <T> T decode(final String encoded, final Class<T> type) {
    try {
      JWSObject jws = JWSObject.parse(encoded);

      if (!jws.verify(jwsVerifier)) {
        throw new ChallengeTamperingDetectedException("Failed to verify JWS signature");
      }

      return objectMapper.readValue(jws.getPayload().toBytes(), type);
    } catch (ParseException | JOSEException e) {
      throw new ChallengeTamperingDetectedException(
          "Failed to verify or decode JWS object: " + e.getMessage());
    } catch (IOException e) {
      throw new ChallengeTamperingDetectedException(
          "Failed to parse JWS payload: " + e.getMessage());
    }
  }

  public static class ChallengeTamperingDetectedException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public ChallengeTamperingDetectedException(final String message) {
      super(message);
    }
  }

  public static class EncodeException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public EncodeException(final String message, final Throwable cause) {
      super(message, cause);
    }
  }
}
