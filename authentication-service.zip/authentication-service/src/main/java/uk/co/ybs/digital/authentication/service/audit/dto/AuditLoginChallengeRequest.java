package uk.co.ybs.digital.authentication.service.audit.dto;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class AuditLoginChallengeRequest {

  @NonNull private final String ipAddress;

  @NonNull private final UserSessionBasic userSession;
}
