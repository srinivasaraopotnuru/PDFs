package uk.co.ybs.digital.authentication.web.dto.request;

import java.io.IOException;

public class InvalidClientDataJsonException extends IOException {
  private static final long serialVersionUID = 1L;

  public InvalidClientDataJsonException(final String message, final Throwable throwable) {
    super(message, throwable);
  }

  public InvalidClientDataJsonException(final String message) {
    this(message, null);
  }
}
