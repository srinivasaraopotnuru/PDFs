package uk.co.ybs.digital.authentication.service.audit.dto;

public enum LoginFailureReason {
  BUSINESS,
  PASSWORD_STATE,
  TECHNICAL;
}
