package uk.co.ybs.digital.authentication.web.dto.response;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.authentication.VerificationMethod;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;

@Value
@Builder
@JsonDeserialize(builder = ValidateAssertionResponse.ValidateAssertionResponseBuilder.class)
public class ValidateAssertionResponse {

  @NonNull public UUID sessionId;

  @NonNull public UUID registrationId;

  @NonNull public String brandCode;

  @NonNull public String channel;

  @NonNull public VerificationMethod verificationMethod;

  @NonNull public CustomerDetails customer;

  @NonNull public LoginDetails login;

  @NonNull public ChallengeParameters challengeParameters;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ValidateAssertionResponseBuilder {}
}
