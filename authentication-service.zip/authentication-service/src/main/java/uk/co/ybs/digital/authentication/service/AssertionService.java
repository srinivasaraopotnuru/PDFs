package uk.co.ybs.digital.authentication.service;

import static java.nio.charset.StandardCharsets.UTF_8;
import static uk.co.ybs.digital.authentication.web.dto.response.PublicKeyAssertion.RELYING_PARTY_ID;

import java.security.PublicKey;
import java.time.Duration;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.authentication.config.AuthenticationServiceProperties;
import uk.co.ybs.digital.authentication.crypto.PublicKeyFactory;
import uk.co.ybs.digital.authentication.crypto.SignatureVerifier;
import uk.co.ybs.digital.authentication.crypto.SignatureVerifierFactory;
import uk.co.ybs.digital.authentication.service.challenge.ChallengePayload;
import uk.co.ybs.digital.authentication.service.challenge.ChallengePayloadValidator;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeService;
import uk.co.ybs.digital.authentication.service.login.LoginRequest;
import uk.co.ybs.digital.authentication.service.login.LoginService;
import uk.co.ybs.digital.authentication.service.login.dto.LoginResponse;
import uk.co.ybs.digital.authentication.service.registration.RegistrationService;
import uk.co.ybs.digital.authentication.service.registration.dto.Registration;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;
import uk.co.ybs.digital.authentication.web.dto.request.ClientAssertionPayload;
import uk.co.ybs.digital.authentication.web.dto.request.ClientDataJson;
import uk.co.ybs.digital.authentication.web.dto.request.FailureRequest;
import uk.co.ybs.digital.authentication.web.dto.request.InvalidClientDataJsonException;
import uk.co.ybs.digital.authentication.web.dto.request.ValidateAssertionRequest;
import uk.co.ybs.digital.authentication.web.dto.response.CustomerDetails;
import uk.co.ybs.digital.authentication.web.dto.response.LoginDetails;
import uk.co.ybs.digital.authentication.web.dto.response.PublicKeyAssertion;
import uk.co.ybs.digital.authentication.web.dto.response.ValidateAssertionResponse;

@Slf4j
@Service
@RequiredArgsConstructor
public class AssertionService {

  private final ChallengeService challengeService;
  private final ChallengePayloadValidator challengePayloadValidator;
  private final RegistrationService registrationService;
  private final LoginService loginService;
  private final PublicKeyFactory publicKeyFactory;
  private final SignatureVerifierFactory signatureVerifierFactory;
  private final AssertionAuditor assertionAuditor;
  private final AuthenticationServiceProperties authenticationServiceProperties;

  public PublicKeyAssertion getAssertion(
      final UUID sessionId,
      final Long partyId,
      final ChallengeParameters challengeParameters,
      final RequestMetadata requestMetadata,
      final boolean audit) {
    final Duration challengeTimeout = getChallengeTimeout();

    final String challenge =
        challengeService.getChallenge(sessionId, partyId, challengeParameters, challengeTimeout);

    final PublicKeyAssertion response =
        PublicKeyAssertion.builder()
            .challenge(challenge)
            .timeout(challengeTimeout.toMillis())
            .build();

    if (audit) {
      assertionAuditor.auditChallenge(sessionId, partyId, requestMetadata);
    }

    log.info(
        "Authentication Details - partyId : {} | sessionId : {}",
        partyId.toString(),
        sessionId.toString());

    return response;
  }

  public ValidateAssertionResponse validationAssertion(
      final ValidateAssertionRequest request,
      final RequestMetadata requestMetadata,
      final boolean audit)
      throws InvalidClientDataJsonException {

    final ClientDataJson clientDataJson = request.getResponse().getClientDataJson();
    if (!clientDataJson.getOrigin().endsWith(RELYING_PARTY_ID)) {
      throw new InvalidClientDataJsonException(
          "response.clientDataJson.origin must be a sub-domain of the Relying Party Id");
    }

    final ChallengePayload challengePayload =
        challengeService.verifyChallenge(clientDataJson.getChallenge());
    log.info("Successfully verified challenge");

    try {
      final ValidateAssertionResponse response =
          validationAssertion(request, requestMetadata, challengePayload);

      log.info(
          "Authentication Details - partyId : {} | canonicalPartyId : {} | sessionId : {}",
          response.getLogin().getPartyId(),
          response.getCustomer().getPartyId(),
          response.getSessionId());

      if (audit) {
        assertionAuditor.auditSuccess(
            challengePayload.getSessionId(),
            challengePayload.getPartyId(),
            requestMetadata,
            request.getId(),
            clientDataJson.getVerificationMethod());
      }
      return response;
    } catch (final Throwable throwable) { // NOPMD
      if (audit) {
        assertionAuditor.auditFailure(
            challengePayload.getSessionId(),
            challengePayload.getPartyId(),
            requestMetadata,
            request.getId(),
            clientDataJson.getVerificationMethod(),
            throwable);
      }
      throw throwable;
    }
  }

  private ValidateAssertionResponse validationAssertion(
      final ValidateAssertionRequest request,
      final RequestMetadata requestMetadata,
      final ChallengePayload challengePayload) {

    final ClientAssertionPayload clientAssertion = request.getResponse();
    final ClientDataJson clientDataJson = clientAssertion.getClientDataJson();

    challengePayloadValidator.validate(challengePayload, request.getChallengeValidationData());
    log.info("Successfully validated challenge payload");

    final Registration registration =
        registrationService.getActiveRegistration(
            requestMetadata.getRequestId(), challengePayload.getPartyId(), request.getId());
    log.info(
        "Found registration [{}] belonging to partyId [{}]",
        registration.getRegistrationId(),
        registration.getPartyId());

    if (!verifyChallengeSignature(
        registration, clientDataJson.getChallenge(), clientAssertion.getSignature())) {
      throw new SignatureNotVerifiedException("Signature verification failed");
    }

    log.info("Successfully verified challenge signature");

    final LoginRequest loginRequest =
        LoginRequest.builder()
            .partyId(challengePayload.getPartyId())
            .brandCode(requestMetadata.getBrandCode())
            .build();

    final LoginResponse loginResponse =
        loginService.login(requestMetadata.getRequestId(), loginRequest);
    log.info("PartyId [{}] logged in successfully", challengePayload.getPartyId());

    return ValidateAssertionResponse.builder()
        .sessionId(challengePayload.getSessionId())
        .registrationId(request.getId())
        .brandCode(requestMetadata.getBrandCode())
        .channel(requestMetadata.getChannel())
        .verificationMethod(clientDataJson.getVerificationMethod())
        .customer(
            CustomerDetails.builder()
                .partyId(loginResponse.getCustomer().getPartyId())
                .email(loginResponse.getCustomer().getEmail())
                .title(loginResponse.getCustomer().getTitle())
                .forename(loginResponse.getCustomer().getForename())
                .surname(loginResponse.getCustomer().getSurname())
                .build())
        .login(
            LoginDetails.builder()
                .partyId(challengePayload.getPartyId())
                .loginTime(loginResponse.getLogin().getLoginTime())
                .lastLoginTime(loginResponse.getLogin().getLastLoginTime())
                .build())
        .challengeParameters(challengePayload.getParameters())
        .build();
  }

  public void reportFailure(final FailureRequest request, final RequestMetadata requestMetadata) {
    final ChallengePayload challengePayload =
        challengeService.verifyChallenge(request.getChallenge());

    assertionAuditor.auditFailure(
        challengePayload.getSessionId(),
        challengePayload.getPartyId(),
        requestMetadata,
        request.getRegistrationId(),
        request.getVerificationMethod(),
        new LoginFailureException());
  }

  private boolean verifyChallengeSignature(
      final Registration registration, final String challenge, final byte[] signature) {
    final PublicKey key = publicKeyFactory.fromPem(registration.getScaKey());
    final SignatureVerifier verifier = signatureVerifierFactory.build(key);
    return verifier.verify(challenge.getBytes(UTF_8), signature);
  }

  private Duration getChallengeTimeout() {
    return Duration.ofSeconds(authenticationServiceProperties.getChallengeTimeoutSeconds());
  }
}
