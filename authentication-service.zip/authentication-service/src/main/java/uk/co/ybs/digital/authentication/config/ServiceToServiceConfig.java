package uk.co.ybs.digital.authentication.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnectorFactory;

@Configuration
@RequiredArgsConstructor
@EnableConfigurationProperties(AuthenticationServiceProperties.class)
public class ServiceToServiceConfig {

  private final AuthenticationServiceProperties properties;

  @Bean
  public WebClient auditServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(properties.getAuditServiceUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }

  @Bean
  public WebClient loginServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(properties.getLoginServiceUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }

  @Bean
  public WebClient registrationServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(properties.getRegistrationServiceUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }
}
