package uk.co.ybs.digital.authentication.web;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.security.NoSuchAlgorithmException;
import java.util.Map;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;
import uk.co.ybs.digital.authentication.service.AssertionService;
import uk.co.ybs.digital.authentication.service.RequestMetadata;
import uk.co.ybs.digital.authentication.util.AssertionHeaders;
import uk.co.ybs.digital.authentication.util.UUIDGenerator;
import uk.co.ybs.digital.authentication.web.dto.request.FailureRequest;
import uk.co.ybs.digital.authentication.web.dto.request.InvalidClientDataJsonException;
import uk.co.ybs.digital.authentication.web.dto.request.ValidateAssertionRequest;
import uk.co.ybs.digital.authentication.web.dto.response.GetAssertionResponse;
import uk.co.ybs.digital.authentication.web.dto.response.PublicKeyAssertion;
import uk.co.ybs.digital.authentication.web.dto.response.ValidateAssertionResponse;

@RestController
@RequiredArgsConstructor
public class AuthenticationController {

  private final AssertionService assertionService;
  private final UUIDGenerator uuidGenerator;

  @GetMapping(
      value = {"/assertion/{partyId:\\d+}"},
      produces = APPLICATION_JSON_VALUE)
  @ApiRequestMetadata
  @ApiResponseMetadata
  public ResponseEntity<GetAssertionResponse> getAssertionPublic(
      @PathVariable final Long partyId,
      @RequestParam final Map<String, String> challengeParameters,
      @ApiIgnore final RequestMetadata requestMetadata)
      throws NoSuchAlgorithmException {
    final UUID sessionId = uuidGenerator.generateId();

    final PublicKeyAssertion publicKeyAssertion =
        assertionService.getAssertion(
            sessionId,
            partyId,
            new ChallengeParameters(challengeParameters),
            requestMetadata,
            true);

    GetAssertionResponse response = new GetAssertionResponse(publicKeyAssertion);

    return ResponseEntity.ok()
        .headers(AssertionHeaders.addHeaders(partyId.toString(), sessionId.toString()))
        .body(response);
  }

  @PostMapping(
      value = "/assertion",
      produces = APPLICATION_JSON_VALUE,
      consumes = APPLICATION_JSON_VALUE)
  @ApiRequestMetadata
  public ValidateAssertionResponse validateAssertion(
      @RequestBody final ValidateAssertionRequest request,
      @ApiIgnore final RequestMetadata requestMetadata)
      throws InvalidClientDataJsonException {
    return assertionService.validationAssertion(request, requestMetadata, true);
  }

  @PostMapping(
      value = "/failure",
      produces = APPLICATION_JSON_VALUE,
      consumes = APPLICATION_JSON_VALUE)
  @ApiRequestMetadata
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void reportFailure(
      @RequestBody final FailureRequest request, @ApiIgnore final RequestMetadata requestMetadata) {
    assertionService.reportFailure(request, requestMetadata);
  }
}
