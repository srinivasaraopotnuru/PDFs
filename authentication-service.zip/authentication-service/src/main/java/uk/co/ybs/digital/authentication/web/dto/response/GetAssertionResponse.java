package uk.co.ybs.digital.authentication.web.dto.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Value;

@Value
public class GetAssertionResponse {
  private PublicKeyAssertion publicKey;

  @JsonCreator
  public GetAssertionResponse(@JsonProperty("publicKey") final PublicKeyAssertion publicKey) {
    this.publicKey = publicKey;
  }
}
