package uk.co.ybs.digital.authentication.service.audit.dto;

import java.util.UUID;
import lombok.Builder;
import lombok.Data;
import lombok.NonNull;

@Data
@Builder(builderMethodName = "builderBasic")
public class UserSessionBasic {

  @NonNull private final UUID sessionId;

  @NonNull private final Long partyId;

  @NonNull private final String channel;

  @NonNull private final String brandCode;
}
