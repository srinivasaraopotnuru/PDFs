package uk.co.ybs.digital.authentication.crypto;

import java.io.IOException;
import java.io.StringReader;
import java.security.PublicKey;
import java.util.Objects;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMParser;
import org.springframework.stereotype.Component;

@Component
public class PublicKeyFactory {
  public PublicKey fromPem(final String pem) throws CryptoException {
    try {
      Objects.requireNonNull(pem, "Public key PEM must not be null");

      SubjectPublicKeyInfo keyInfo =
          Objects.requireNonNull(
              (SubjectPublicKeyInfo) new PEMParser(new StringReader(pem)).readObject(),
              () -> "Unable to parse input as PEM-encoded key: " + pem);

      return BouncyCastleProvider.getPublicKey(keyInfo);
    } catch (IOException | NullPointerException ex) { // NOPMD
      throw new CryptoException(
          "Unexpected error occurred when attempting to build public key", ex);
    }
  }
}
