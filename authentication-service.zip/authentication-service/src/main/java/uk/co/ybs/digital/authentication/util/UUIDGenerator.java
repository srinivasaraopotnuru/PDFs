package uk.co.ybs.digital.authentication.util;

import java.util.UUID;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.util.IdGenerator;

@Component
public class UUIDGenerator implements IdGenerator {

  @Override
  @NonNull
  public UUID generateId() {
    return UUID.randomUUID();
  }
}
