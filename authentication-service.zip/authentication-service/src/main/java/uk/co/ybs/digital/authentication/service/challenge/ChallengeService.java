package uk.co.ybs.digital.authentication.service.challenge;

import java.time.Clock;
import java.time.Duration;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.authentication.crypto.JwsCodec;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;

@Service
@RequiredArgsConstructor
public class ChallengeService {

  private final JwsCodec jwsCodec;
  private final Clock clock;

  public String getChallenge(
      final UUID sessionId,
      final Long partyId,
      final ChallengeParameters challengeParameters,
      final Duration timeout) {
    final ChallengePayload payload =
        ChallengePayload.builder()
            .sessionId(sessionId)
            .partyId(partyId)
            .expiresAt(clock.instant().plus(timeout))
            .parameters(challengeParameters)
            .build();

    return jwsCodec.encode(payload);
  }

  public ChallengePayload verifyChallenge(final String encoded) {
    return jwsCodec.decode(encoded, ChallengePayload.class);
  }
}
