package uk.co.ybs.digital.authentication.service.challenge;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.time.Instant;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.authentication.web.ChallengeParameters;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = ChallengePayload.ChallengePayloadBuilder.class)
public class ChallengePayload {

  @NonNull public UUID sessionId;

  @NonNull public Long partyId;

  @NonNull public Instant expiresAt;

  @NonNull public ChallengeParameters parameters;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ChallengePayloadBuilder {}
}
