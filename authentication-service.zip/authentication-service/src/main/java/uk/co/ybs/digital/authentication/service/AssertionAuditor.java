package uk.co.ybs.digital.authentication.service;

import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.authentication.VerificationMethod;
import uk.co.ybs.digital.authentication.service.audit.AuditService;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginChallengeRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginFailureRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.AuditLoginSuccessRequest;
import uk.co.ybs.digital.authentication.service.audit.dto.LoginFailureReason;
import uk.co.ybs.digital.authentication.service.audit.dto.UserSession;
import uk.co.ybs.digital.authentication.service.audit.dto.UserSessionBasic;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeDataValidationFailedException;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeExpiredException;
import uk.co.ybs.digital.authentication.service.login.LoginDeniedException;
import uk.co.ybs.digital.authentication.service.login.LoginServiceException;
import uk.co.ybs.digital.authentication.service.registration.RegistrationServiceException;
import uk.co.ybs.digital.authentication.service.registration.UnregisteredPartyException;

@Service
@AllArgsConstructor
@Slf4j
public class AssertionAuditor {

  private final AuditService auditService;

  public void auditChallenge(
      final UUID sessionId, final Long partyId, final RequestMetadata requestMetadata) {
    final AuditLoginChallengeRequest auditRequest =
        AuditLoginChallengeRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .userSession(
                UserSessionBasic.builderBasic()
                    .sessionId(sessionId)
                    .partyId(partyId)
                    .channel(requestMetadata.getChannel())
                    .brandCode(requestMetadata.getBrandCode())
                    .build())
            .build();

    auditService.auditLoginChallenge(auditRequest, requestMetadata.getRequestId());
  }

  public void auditSuccess(
      final UUID sessionId,
      final Long partyId,
      final RequestMetadata requestMetadata,
      final UUID registrationId,
      final VerificationMethod verificationMethod) {
    final AuditLoginSuccessRequest auditRequest =
        AuditLoginSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .userSession(
                UserSession.builder()
                    .sessionId(sessionId)
                    .partyId(partyId)
                    .channel(requestMetadata.getChannel())
                    .brandCode(requestMetadata.getBrandCode())
                    .registrationId(registrationId)
                    .verificationMethod(verificationMethod)
                    .build())
            .build();

    auditService.auditLoginSuccess(auditRequest, requestMetadata.getRequestId());
  }

  public void auditFailure(
      final UUID sessionId,
      final Long partyId,
      final RequestMetadata requestMetadata,
      final UUID registrationId,
      final VerificationMethod verificationMethod,
      final Throwable throwable) {
    final FailureDetails failureDetails = getFailureDetails(throwable);

    final AuditLoginFailureRequest auditRequest =
        AuditLoginFailureRequest.builder()
            .reason(failureDetails.getReason())
            .message(failureDetails.getMessage())
            .ipAddress(requestMetadata.getIpAddress())
            .userSession(
                UserSession.builder()
                    .sessionId(sessionId)
                    .partyId(partyId)
                    .channel(requestMetadata.getChannel())
                    .brandCode(requestMetadata.getBrandCode())
                    .registrationId(registrationId)
                    .verificationMethod(verificationMethod)
                    .build())
            .build();

    auditService.auditLoginFailure(auditRequest, requestMetadata.getRequestId());
  }

  private FailureDetails getFailureDetails(final Throwable throwable) {
    if (throwable instanceof ChallengeExpiredException) {
      return new FailureDetails(LoginFailureReason.BUSINESS, "Challenge Expired");
    } else if (throwable instanceof ChallengeDataValidationFailedException) {
      return new FailureDetails(LoginFailureReason.BUSINESS, "Challenge Data Validation Failed");
    } else if (throwable instanceof SignatureNotVerifiedException) {
      return new FailureDetails(LoginFailureReason.BUSINESS, "Invalid Challenge Response");
    } else if (throwable instanceof UnregisteredPartyException) {
      return new FailureDetails(LoginFailureReason.BUSINESS, "Invalid Device Registration");
    } else if (throwable instanceof LoginFailureException) {
      return new FailureDetails(LoginFailureReason.BUSINESS, "Invalid Client Credentials");
    } else if (throwable instanceof LoginDeniedException) {
      return getFailureDetails((LoginDeniedException) throwable);
    } else if (throwable instanceof RegistrationServiceException) {
      return new FailureDetails(LoginFailureReason.TECHNICAL, "Registration Service Error");
    } else if (throwable instanceof LoginServiceException) {
      return new FailureDetails(LoginFailureReason.TECHNICAL, "Login Service Error");
    } else {
      log.info("Logging unexpected exception as technical error: {}", throwable.toString());
      return new FailureDetails(LoginFailureReason.TECHNICAL, "Authentication Service Error");
    }
  }

  private FailureDetails getFailureDetails(final LoginDeniedException exception) {
    switch (exception.getReason()) {
      case CUSTOMER_NOT_FOUND_CUSTOMER_HUB:
        return new FailureDetails(
            LoginFailureReason.TECHNICAL, "Customer Not Found (Customer Hub)");
      case CUSTOMER_NOT_FOUND_LDAP:
        return new FailureDetails(LoginFailureReason.TECHNICAL, "Customer Not Found (LDAP)");
      case CUSTOMER_DECEASED:
        return new FailureDetails(LoginFailureReason.BUSINESS, "Customer Deceased");
      case CUSTOMER_INVALID_GROUP:
        return new FailureDetails(LoginFailureReason.TECHNICAL, "Customer Group Invalid");
      case CUSTOMER_INVALID_PASSWORD_STATE:
        return new FailureDetails(
            LoginFailureReason.PASSWORD_STATE, "Customer Password State Invalid");
      default:
        // Unreachable because all enum values are handled above
        log.error("Unexpected LoginDeniedException.Reason: {}", exception.getReason());
        return new FailureDetails(LoginFailureReason.TECHNICAL, "Login Service Error (Unknown)");
    }
  }

  @Value
  @AllArgsConstructor
  private static final class FailureDetails {
    @NonNull private final LoginFailureReason reason;
    @NonNull private final String message;
  }
}
