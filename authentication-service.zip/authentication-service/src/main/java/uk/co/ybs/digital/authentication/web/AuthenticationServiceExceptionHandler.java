package uk.co.ybs.digital.authentication.web;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import uk.co.ybs.digital.authentication.ExceptionUtils;
import uk.co.ybs.digital.authentication.crypto.JwsCodec;
import uk.co.ybs.digital.authentication.service.SignatureNotVerifiedException;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeDataValidationFailedException;
import uk.co.ybs.digital.authentication.service.challenge.ChallengeExpiredException;
import uk.co.ybs.digital.authentication.service.login.LoginDeniedException;
import uk.co.ybs.digital.authentication.service.registration.UnregisteredPartyException;
import uk.co.ybs.digital.authentication.web.dto.request.InvalidClientDataJsonException;
import uk.co.ybs.digital.authentication.web.dto.response.ErrorResponse;
import uk.co.ybs.digital.authentication.web.dto.response.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;

@Slf4j
@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class AuthenticationServiceExceptionHandler extends ResponseEntityExceptionHandler {
  @ExceptionHandler({
    UnregisteredPartyException.class,
    LoginDeniedException.class,
    SignatureNotVerifiedException.class
  })
  public ResponseEntity<Object> handleLoginFailed(final Exception ex, final WebRequest request) {
    log.info("Customer authentication failed: " + ex.getMessage());
    return handleAuthenticationFailed(ex, request);
  }

  @ExceptionHandler({JwsCodec.ChallengeTamperingDetectedException.class})
  public ResponseEntity<Object> handleChallengeTamperingDetected(
      final JwsCodec.ChallengeTamperingDetectedException ex, final WebRequest request) {
    log.warn("Challenge tampering detected - returning Forbidden response: " + ex.getMessage());
    return handleAuthenticationFailed(ex, request);
  }

  @ExceptionHandler(ChallengeExpiredException.class)
  public ResponseEntity<Object> handleChallengeExpired(
      final Exception ex, final WebRequest request) {
    log.info("Customer authentication failed. Challenge expired: " + ex.getMessage());
    final HttpStatus status = HttpStatus.UNAUTHORIZED;
    final ErrorResponse body =
        ErrorResponse.builder(status)
            .id(getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNAUTHORIZED_CHALLENGE_EXPIRED)
                    .message("Authentication failed. Challenge expired")
                    .build())
            .build();

    return this.handleExceptionInternal(ex, body, new HttpHeaders(), status, request);
  }

  @ExceptionHandler(ChallengeDataValidationFailedException.class)
  public ResponseEntity<Object> handleChallengeDataValidationFailed(
      final Exception ex, final WebRequest request) {
    log.info("Challenge data validation failed - returning Forbidden response: " + ex.getMessage());
    return handleAuthenticationFailed(ex, request);
  }

  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(
      final HttpMessageNotReadableException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    return ExceptionUtils.findExactCause(ex, InvalidClientDataJsonException.class)
        .map(cause -> handleInvalidClientDataJson(cause, request))
        .orElseGet(() -> handleHttpMessageNotReadableStandard(ex, headers, status, request));
  }

  private ResponseEntity<Object> handleHttpMessageNotReadableStandard(
      final HttpMessageNotReadableException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    log.error("Handled HttpMessageNotReadableException: {}", ex.toString());

    final ErrorResponse.ErrorResponseBuilder response =
        ErrorResponse.builder(status)
            .id(getRequestId(request))
            .message("Unable to parse request body");

    response.error(
        ErrorResponse.ErrorItem.builder()
            .errorCode(ErrorItem.RESOURCE_INVALID_FORMAT)
            .message("An unexpected error occurred when attempting to parse the request body")
            .build());

    return handleExceptionInternal(ex, response.build(), headers, status, request);
  }

  @ExceptionHandler(InvalidClientDataJsonException.class)
  public ResponseEntity<Object> handleInvalidClientDataJson(
      final InvalidClientDataJsonException ex, final WebRequest request) {
    log.error("Handled InvalidClientDataJsonException: {}", ex.toString());

    final HttpStatus status = HttpStatus.BAD_REQUEST;
    final ErrorResponse body =
        ErrorResponse.builder(status)
            .id(getRequestId(request))
            .message("Unable to process clientDataJson")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.FIELD_INVALID)
                    .message(ex.getMessage())
                    .build())
            .build();

    return this.handleExceptionInternal(ex, body, new HttpHeaders(), status, request);
  }

  @Override
  protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
      final HttpRequestMethodNotSupportedException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    pageNotFoundLogger.warn(ex.getMessage());

    Set<HttpMethod> supportedMethods = ex.getSupportedHttpMethods();
    if (!CollectionUtils.isEmpty(supportedMethods)) {
      headers.setAllow(supportedMethods);
    }

    final ErrorResponse body =
        ErrorResponse.builder(status)
            .id(getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNSUPPORTED_METHOD)
                    .message("Unsupported method: " + ex.getMethod())
                    .build())
            .build();

    return handleExceptionInternal(ex, body, headers, status, request);
  }

  @Override
  public ResponseEntity<Object> handleHttpMediaTypeNotSupported(
      final HttpMediaTypeNotSupportedException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    log.error("Handled HttpMediaTypeNotSupportedException: {}", ex.toString());

    List<MediaType> mediaTypes = ex.getSupportedMediaTypes();
    if (!CollectionUtils.isEmpty(mediaTypes)) {
      headers.setAccept(mediaTypes);
    }

    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.HEADER_INVALID)
                    .message("Content-Type header is invalid")
                    .path(HttpHeaders.CONTENT_TYPE)
                    .build())
            .build();

    return handleExceptionInternal(ex, errorResponse, headers, status, request);
  }

  @ExceptionHandler(Throwable.class)
  public ResponseEntity<Object> handleUnhandledException(
      final Exception ex, final WebRequest request) {
    log.error("Unexpected exception occurred", ex);
    return this.handleExceptionInternal(
        ex, null, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  private ResponseEntity<Object> handleAuthenticationFailed(
      final Exception ex, final WebRequest request) {
    final HttpStatus status = HttpStatus.UNAUTHORIZED;
    final ErrorResponse body =
        ErrorResponse.builder(status)
            .id(getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNAUTHORIZED)
                    .message("Authentication failed. Please register via authorization.ybs.co.uk")
                    .build())
            .build();

    return this.handleExceptionInternal(ex, body, new HttpHeaders(), status, request);
  }

  @Override
  protected ResponseEntity<Object> handleServletRequestBindingException(
      final ServletRequestBindingException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    log.error("Handled ServletRequestBindingException: {}", ex.toString());

    if (ex instanceof MissingRequestHeaderException) {
      final MissingRequestHeaderException missingRequestHeaderException =
          (MissingRequestHeaderException) ex;
      final ErrorResponse errorResponse =
          ErrorResponse.builder(status)
              .id(getRequestId(request))
              .error(
                  ErrorItem.builder()
                      .errorCode(ErrorItem.HEADER_MISSING)
                      .message("Header missing")
                      .path(missingRequestHeaderException.getHeaderName())
                      .build())
              .build();
      return handleExceptionInternal(ex, errorResponse, headers, status, request);
    } else {
      return super.handleServletRequestBindingException(ex, headers, status, request);
    }
  }

  @Override
  protected ResponseEntity<Object> handleExceptionInternal(
      final Exception ex,
      Object body,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    if (body == null && !HttpStatus.NOT_ACCEPTABLE.equals(status)) {
      // Put a generic error response body in with the right status
      body =
          ErrorResponse.builder(status)
              .id(getRequestId(request))
              .error(
                  ErrorItem.builder()
                      .errorCode(ErrorItem.UNEXPECTED_ERROR)
                      .message("Unexpected Error")
                      .build())
              .build();
    }

    return super.handleExceptionInternal(ex, body, headers, status, request);
  }

  private static UUID getRequestId(final WebRequest request) {
    return (UUID)
        request.getAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME, WebRequest.SCOPE_REQUEST);
  }
}
