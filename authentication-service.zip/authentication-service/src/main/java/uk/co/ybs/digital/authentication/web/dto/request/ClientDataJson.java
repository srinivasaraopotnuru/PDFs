package uk.co.ybs.digital.authentication.web.dto.request;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.authentication.VerificationMethod;

@Value
@Builder
@JsonDeserialize(builder = ClientDataJson.ClientDataJsonBuilder.class)
public class ClientDataJson {

  @NonNull
  @ApiModelProperty(
      value = "The method used to unlock the key to sign the challenge",
      allowableValues = "BIOMETRIC, PASSCODE",
      required = true)
  public VerificationMethod verificationMethod;

  @NonNull
  @ApiModelProperty(
      value = "The the challenge received from the GET /assertion endpoint",
      required = true)
  public String challenge;

  @NonNull
  @ApiModelProperty(
      value = "A url that represents the domain of the client app",
      example = "digital-api.ybs.co.uk",
      required = true)
  public String origin;

  @NonNull
  @ApiModelProperty(
      value = "Unused, but required",
      allowableValues = "webauthn.get",
      required = true)
  public String type;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ClientDataJsonBuilder {}
}
