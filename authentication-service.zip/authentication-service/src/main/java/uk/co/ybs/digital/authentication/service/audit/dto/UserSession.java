package uk.co.ybs.digital.authentication.service.audit.dto;

import java.util.UUID;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;
import uk.co.ybs.digital.authentication.VerificationMethod;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class UserSession extends UserSessionBasic {

  @NonNull private final UUID registrationId;

  @NonNull private final VerificationMethod verificationMethod;

  @Builder
  public UserSession(
      final UUID sessionId,
      final Long partyId,
      final String channel,
      final String brandCode,
      final UUID registrationId,
      final VerificationMethod verificationMethod) {
    super(sessionId, partyId, channel, brandCode);
    this.registrationId = registrationId;
    this.verificationMethod = verificationMethod;
  }
}
