package uk.co.ybs.digital.authentication.service.login.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = LoginResponse.LoginResponseBuilder.class)
public class LoginResponse {

  @NonNull public CustomerDetails customer;

  @NonNull public LoginDetails login;

  @JsonPOJOBuilder(withPrefix = "")
  public static class LoginResponseBuilder {}
}
