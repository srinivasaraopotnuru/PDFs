package uk.co.ybs.digital.authentication.web.dto.request;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.databind.exc.ValueInstantiationException;
import java.io.IOException;

class ClientDataJsonBase64Deserializer extends StdScalarDeserializer<ClientDataJson> {
  private static final long serialVersionUID = 1L;

  private final transient ObjectMapper objectMapper;

  protected ClientDataJsonBase64Deserializer(final ObjectMapper objectMapper) {
    super(ClientDataJson.class);
    this.objectMapper = objectMapper;
  }

  @Override
  public ClientDataJson deserialize(
      final JsonParser jsonParser, final DeserializationContext deserializationContext)
      throws InvalidClientDataJsonException {
    byte[] value = base64DecodeValue(jsonParser);
    return deserialize(value);
  }

  private ClientDataJson deserialize(final byte[] value) throws InvalidClientDataJsonException {
    try {
      return objectMapper.readValue(value, ClientDataJson.class);
    } catch (JsonParseException e) {
      throw new InvalidClientDataJsonException(
          "Unable to parse clientDataJson: " + e.getOriginalMessage(), e);
    } catch (ValueInstantiationException e) {
      throw new InvalidClientDataJsonException(
          "Unable to handle clientDataJson field: " + e.getCause().getMessage(), e);
    } catch (InvalidFormatException e) {
      throw new InvalidClientDataJsonException(
          "Unable to handle clientDataJson value: " + e.getValue(), e);
    } catch (IOException e) {
      throw new InvalidClientDataJsonException("Unable to decode clientDataJson", e);
    }
  }

  private byte[] base64DecodeValue(final JsonParser jsonParser)
      throws InvalidClientDataJsonException {
    try {
      return jsonParser.readValueAs(byte[].class);
    } catch (InvalidFormatException e) {
      throw new InvalidClientDataJsonException(
          "clientDataJson is not a valid base64 encoded string", e);
    } catch (JsonParseException e) {
      throw new InvalidClientDataJsonException(
          "Unable to parse clientDataJson value: " + e.getOriginalMessage(), e);
    } catch (IOException e) {
      throw new InvalidClientDataJsonException("Unable to decode clientDataJson value", e);
    }
  }
}
