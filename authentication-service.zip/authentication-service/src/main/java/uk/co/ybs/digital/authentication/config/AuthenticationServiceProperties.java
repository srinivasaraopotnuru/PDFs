package uk.co.ybs.digital.authentication.config;

import java.net.URL;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.lang.NonNull;
import org.springframework.validation.annotation.Validated;

@Getter
@Setter
@Validated
@ConfigurationProperties("uk.co.ybs.digital.authentication")
public class AuthenticationServiceProperties {

  @NonNull private String challengeMACKey;

  @NonNull private URL auditServiceUrl;

  @NonNull private URL loginServiceUrl;

  @NonNull private URL registrationServiceUrl;

  private int challengeTimeoutSeconds = 60; // NOPMD
}
