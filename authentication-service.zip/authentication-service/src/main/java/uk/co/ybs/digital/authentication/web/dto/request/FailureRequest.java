package uk.co.ybs.digital.authentication.web.dto.request;

import io.swagger.annotations.ApiModelProperty;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.authentication.VerificationMethod;

@Value
@Builder
public class FailureRequest {
  @NonNull
  @ApiModelProperty(
      value = "The device registration id",
      example = "0306db4a-4a17-4045-a360-efcb478bdaf7",
      required = true)
  private UUID registrationId;

  @NonNull
  @ApiModelProperty(
      value = "The challenge received from the GET /assertion endpoint",
      required = true)
  private String challenge;

  @NonNull
  @ApiModelProperty(
      value = "The method used to unlock the key to sign the challenge",
      allowableValues = "BIOMETRIC, PASSCODE",
      required = true)
  private VerificationMethod verificationMethod;
}
