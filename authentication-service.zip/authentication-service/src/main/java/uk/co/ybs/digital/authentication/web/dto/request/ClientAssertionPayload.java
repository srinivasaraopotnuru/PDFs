package uk.co.ybs.digital.authentication.web.dto.request;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = ClientAssertionPayload.ClientAssertionPayloadBuilder.class)
public class ClientAssertionPayload {

  @NonNull public byte[] signature;

  @NonNull public ClientDataJson clientDataJson;

  private interface IClientAssertionPayloadBuilder {
    @JsonDeserialize(using = ClientDataJsonBase64Deserializer.class)
    ClientAssertionPayload.ClientAssertionPayloadBuilder clientDataJson(
        ClientDataJson clientDataJson);
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ClientAssertionPayloadBuilder implements IClientAssertionPayloadBuilder {}
}
