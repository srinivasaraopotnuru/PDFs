package uk.co.ybs.digital.authentication;

import java.util.Optional;

@SuppressWarnings("unchecked")
public class ExceptionUtils { // NOPMD
  public static <Cause extends Throwable> Optional<Cause> findExactCause(
      Throwable exception, final Class<Cause> causeClass) {
    while (exception != null && !exception.getClass().equals(causeClass)) {
      exception = exception.getCause();
    }

    // noinspection unchecked: this is safe as exception will be instance of Cause or null
    return Optional.ofNullable((Cause) exception);
  }
}
