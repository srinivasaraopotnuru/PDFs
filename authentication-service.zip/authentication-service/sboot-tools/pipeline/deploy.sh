#!/usr/bin/env bash

set -e

export BASE_PATH=openshift/json
bash sboot-tools/pipeline/templating.sh

OPENSHIFT_DEPLOY_HOST=$OPENSHIFT_DEPLOY_SUBDOMAIN.os.ybs.com
oc login --insecure-skip-tls-verify=true -u $OPENSHIFT_DEPLOY_USER -p $OPENSHIFT_DEPLOY_PASSWD $OPENSHIFT_DEPLOY_HOST >/dev/null 2>&1
oc project $OPENSHIFT_DEPLOY_NAMESPACE
oc status | grep $OPENSHIFT_DEPLOY_NAMESPACE.*$OPENSHIFT_DEPLOY_HOST

FILE_LIST=`find $BASE_PATH -not -path '*/\.*' -and -path '*/*.json' -and -not -path '*/*_template.json' | tr '\r\n' ' '`

echo ""
echo "INFO: Deploying into project "$OPENSHIFT_DEPLOY_NAMESPACE

for FILE in $FILE_LIST;
do
  if echo $FILE | grep _template.json >/dev/null 2>&1;
  then
    continue
  fi

  echo ""
  echo "INFO: Deploying file "$FILE
  if oc get -f $FILE >/dev/null 2>&1;
  then

    if grep PersistentVolumeClaim $FILE >/dev/null 2>&1;
    then
      echo "WARN: Volume already exists, skipping"
      continue
    fi

    if DEPLOYMENT_LOG=`oc apply -f $FILE`;
    then
      if echo $DEPLOYMENT_LOG | grep unchanged >/dev/null 2>&1;
      then
        echo "INFO: Configuration is up to date so remains unchanged"
      elif echo $DEPLOYMENT_LOG | grep configured >/dev/null 2>&1;
      then
        echo "INFO: Configuration has been updated"
      else
        echo "ERROR: Failed to apply configuration"
        exit 1
      fi
    else
      if echo $DEPLOYMENT_LOG | grep -e "Route" -e "field is immutable" >/dev/null 2>&1;
      then
        echo "WARN: Cannot update route hostname, skipping deployment of route"
      fi
    fi
    continue
  fi

  if oc apply -f $FILE | grep created >/dev/null 2>&1;
  then
    echo "INFO: Successfuly deployed"
  else
    echo "ERROR: Failed to deploy"
    exit 1
  fi
done

echo ""
sleep 5

if oc rollout history dc/$APPLICATION | cut -f3 | grep Running >/dev/null 2>&1;
then
  echo "INFO: Deployment already running for "$APPLICATION
elif oc rollout history dc/$APPLICATION | cut -f3 | grep Pending >/dev/null 2>&1;
then
  echo "INFO: Deployment pending for "$APPLICATION
else
  echo "INFO: Triggering deployment of "$APPLICATION
  oc rollout latest dc/$APPLICATION
fi

echo ""

oc rollout status dc/$APPLICATION --request-timeout=180

exit 0
