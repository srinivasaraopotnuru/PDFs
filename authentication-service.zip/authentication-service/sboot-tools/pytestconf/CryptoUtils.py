import base64
import os
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.serialization import load_pem_public_key

import importlib
globconf = importlib.import_module("sboot-tools.pytestconf.globconf")


pubkey_strs = {
    "outsystem-encryption-key-nonprod-1": """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAu2KUvo0dxc8DGx/z8TCi
hOYFHzBcPlHFdGEdr0wtc7p6tolsnDJt4i6lzmpTMkgrnYFX9VCty3hOVV3HTpjh
tWG1i/e6tzkGLLJ4SOU5ErMXMFcpblyLeKkBRwzOFwEN+hFi5JyExQGkEDHEUNgc
vwTqrA/2zN16t/tMCUFeJKvrVQF/ZR/aqqax3R7Vw81UHpnZZzZgQ5YwilxMQyOR
kKvlM9+hDJlR5HtwbwvzO2z6ZnTSNbp0/wU1VDTY5eqlcLCJqCAci05VtTxIj8MZ
nFY/j9OOIu0L+1nHFAfYCHussIonjxqLd0ta+vsexRfh459J43nxFMmfhRiTC5nK
UQIDAQAB
-----END PUBLIC KEY-----""",
    "outsystem-encryption-key-nonprod-2": """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAw7olNxZfrqtapv0Be81y
knC9y9ec0jLyhL6M2TeGBmTHFrSM67JU/+VyfvJcure8ko9xxSf0KMKGJg03iZvn
fJAF/wWwZobwQjnV38H7eC8iGm6B7ZX8qTyE59y2bZm95lzw9Z8DLz8L0NnOxTOO
Aww9eMx+Ie7ZGdHT63UdjQ6S7Y4OUDT5wxuhd/NkpgbfjyrqoNfXdNUFT4T0B0Um
mYRaDkCvTl5tvuqVjhuq6QVN6bNWibrYzcSnMSwnwKrh6bh7iwKSbHdxw90jS0W9
inPKwm6Af7f9Fxu12saOHXr7smhKvkkyCBsnD5SxG1QAm67FNep7CACNpIq26HKu
yQIDAQAB
-----END PUBLIC KEY-----""",
    "outsystem-encryption-key-nonprod": """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAu2KUvo0dxc8DGx/z8TCi
hOYFHzBcPlHFdGEdr0wtc7p6tolsnDJt4i6lzmpTMkgrnYFX9VCty3hOVV3HTpjh
tWG1i/e6tzkGLLJ4SOU5ErMXMFcpblyLeKkBRwzOFwEN+hFi5JyExQGkEDHEUNgc
vwTqrA/2zN16t/tMCUFeJKvrVQF/ZR/aqqax3R7Vw81UHpnZZzZgQ5YwilxMQyOR
kKvlM9+hDJlR5HtwbwvzO2z6ZnTSNbp0/wU1VDTY5eqlcLCJqCAci05VtTxIj8MZ
nFY/j9OOIu0L+1nHFAfYCHussIonjxqLd0ta+vsexRfh459J43nxFMmfhRiTC5nK
UQIDAQAB
-----END PUBLIC KEY-----""",
    "hacker_public_key": """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAug2Fx8OhKc/FajeDRoW3
RlkHZvmiCG/wnKte9l50tyfrm539+0EZqxGanwJ7lJ/plVxFYkBQGQM5hrI9fPQ/
4lGfCWYfUJgFeSoFgo8OTuprwzYLYyD8xfVnG1Ijgmf3w3V2GXhsMFZdNEkK1RpG
ww6x4SWZeocvaWYYYnO2r5+GptlySL4zpWNxTqmmiDtOg6WZod/CEh6f1a//9DU6
qD8ilXR6k/A2zVESbYhNNwaTa+MScVqdaiuQ5rxZmEMvYf+Dg3s43HAa/CsDWMZB
8A0zhy50xQlpywy0Ii+afY/o9+yC1E3HgWynt3gJQrwRdvFd4MJfgWDzUvlHMp5E
7wIDAQAB
-----END PUBLIC KEY-----"""
}


crypto_key_id = os.getenv('CRYPTO_ASYMMETRIC_KEY_ID_' + globconf.get_env_group().upper())
print("crypto_key_id:", crypto_key_id)
crypto_key_pubkey = os.getenv('CRYPTO_ASYMMETRIC_KEY_PUBLICKEY_' + globconf.get_env_group().upper())


def get_crypto_key_id():
    return crypto_key_id


def encrypt_data(message, key_id=None):
    pubkey_str = crypto_key_pubkey
    if key_id:
        pubkey_str = pubkey_strs[key_id]
    pub_key = load_pem_public_key(pubkey_str.encode(), backend=default_backend())
    ciphertext = pub_key.encrypt(
        str(message).encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA1()),
            algorithm=hashes.SHA1(),
            label=None
        )
    )
    return base64.b64encode(ciphertext).decode("utf-8")
