'''scans for changes against merge base and only deploys modified bundles,
this ignores untracked files so these should be added to the index if they
should be included'''

import hashlib
import itertools
import json
import os
import shutil
import stat
import sys
import zlib
from base64 import b64decode
from tempfile import TemporaryDirectory

import urllib3

import compare_hashes
import git_utils
import hashing
import os_utils
from apigee import Apigee

# function that identifies ApiProxy parent dirs.


def hasChild(dir, childName):
    hasChild = False
    if os.path.isdir(dir):
        childDir = os.path.join(dir, childName)
        if os.path.isdir(childDir):
            hasChild = True
    return hasChild


def list_zips(root):
    '''gets the list of zip files in the specified directory'''
    if os.path.isdir(root):
        return list(filter(lambda entry: entry.path.endswith('.zip'), os.scandir(root)))

    return []


def list_api_dirs(root):
    '''Recursively gets the list of api directories in the specified directory'''
    return list_dirs_with_subdir(root, 'apiproxy')


def list_shf_dirs(root):
    '''Recursively gets the list of shared flow directories in the specified directory'''
    return list_dirs_with_subdir(root, 'sharedflowbundle')


def list_dirs_with_subdir(root, subdirName):
    '''Recursively gets a list of directories in the specified directory which have the specified sub-directory'''
    apiDirs = []
    dirIter = os.scandir(root)
    for dir in dirIter:
        if os.path.isdir(dir):
            if hasChild(dir, subdirName):
                apiDirs.append(dir)
            else:
                apiDirs.extend(list_dirs_with_subdir(dir.path, subdirName))
    return apiDirs


def find_bundle(bundles):
    def find(name):
        bundle_name = name + '.zip'
        for bundle in bundles:
            if bundle.name == bundle_name:
                return bundle

        print('ERROR: unable to find', bundle_name, file=sys.stderr)
        return None

    return find


def find_zip_bundle(bundles):
    def find(name):
        bundle_name = name
        for bundle in bundles:
            if bundle.name == bundle_name:
                return bundle

        print('ERROR: unable to find', bundle_name, file=sys.stderr)
        return None

    return find


def extract_bundle_names(root_dir, files):
    def _traverse_dirs(path):
        parent = os.path.dirname(path)
        parentParent = os.path.dirname(parent)
        return os.path.basename(path) if parentParent == root_dir else _traverse_dirs(parent)

    in_root_dir = filter(lambda path: path.startswith(root_dir), files)
    bundle_names = map(_traverse_dirs, in_root_dir)
    return set(bundle_names)


def load_branch_deploy_state(branch_name):
    script_dir = os.path.dirname(os.path.realpath(__file__))
    filename = os.path.join(script_dir, 'scratch', branch_name + '.json')
    try:
        with open(filename, 'r') as file:
            return json.load(file)
    except (FileNotFoundError, json.decoder.JSONDecodeError):
        return None


def write_branch_deploy_state(branch_name, state):
    script_dir = os.path.dirname(os.path.realpath(__file__))
    scratch_dir = os.path.join(script_dir, 'scratch')
    filename = os.path.join(scratch_dir, branch_name + '.json')

    os.makedirs(os.path.dirname(filename), exist_ok=True)

    with open(filename, 'w') as file:
        return json.dump(state, file, indent=4)


def create_new_branch_state(apiproxies_root, apiproxies, sharedflows_root, sharedflows):
    return {
        'apiproxies': hashing.hash_directories(
            map(lambda name: os.path.join(apiproxies_root, name), apiproxies),
            subdir='apiproxy', list_function=git_utils.list_files
        ),
        'sharedflows': hashing.hash_directories(
            map(lambda name: os.path.join(sharedflows_root, name), sharedflows),
            subdir='sharedflowbundle', list_function=git_utils.list_files
        )
    }


def create_new_branch_state_zip(apiproxies, sharedflows):
    return {
        'apiproxies': hashing.hash_zips(apiproxies),
        'sharedflows': hashing.hash_zips(sharedflows)
    }


def run_master_deploy(apigee):
    this_repo = git_utils.find_git_root(os.getcwd())
    git_root_dir = this_repo.working_tree_dir

    apiproxy_source_root = 'apiproxies'
    apiproxy_sources = list(
        list_api_dirs(os.path.join(git_root_dir, apiproxy_source_root))
    )
    sharedflow_source_root = 'sharedflows'
    sharedflow_sources = list(
        list_shf_dirs(os.path.join(git_root_dir, sharedflow_source_root))
    )

    with TemporaryDirectory() as versions_repo_dir:
        ci_user = os.getenv('GITLAB_PUSH_USER')
        ci_token = os.getenv('GITLAB_PUSH_TOKEN')
        git_prj_ns = os.getenv('GIT_PROJECT_NAMESPACE')
        git_prj_name = os.getenv('GIT_PROJECT_NAME')
        versions_repo = git_utils.clone(
            'https://{}:{}@ecommgit.ybs.com/{}/{}-versions.git'.format(
                ci_user, ci_token, git_prj_ns, git_prj_name),
            versions_repo_dir
        )

        with open(os.path.join(versions_repo_dir, 'test.json'), 'r') as test_revisions:
            test_revisions = json.load(test_revisions)

        updated_bundles = {
            'apiproxies': compare_hashes.compare_with(test_revisions['apiproxies'], apiproxy_sources, subdir="apiproxy"),
            'sharedflows': compare_hashes.compare_with(test_revisions['sharedflows'], sharedflow_sources, subdir="sharedflowbundle"),
        }

        if not updated_bundles['apiproxies'].keys() and not updated_bundles['sharedflows'].keys():
            print('no changes detected')
            return

        print('detected changes for apiproxies:', list(
            updated_bundles['apiproxies'].keys()))
        print('detected changes for sharedflows:', list(
            updated_bundles['sharedflows'].keys()))

        all_revisions = apigee.get_revisions(
            updated_bundles['apiproxies'].keys(),
            updated_bundles['sharedflows'].keys()
        )

        apigee.reset_revisions(test_revisions, all_revisions)

        apiproxy_bundles = list(
            list_zips(os.path.join(git_root_dir, 'bundles/apiproxies')))
        sharedflow_bundles = list(
            list_zips(os.path.join(git_root_dir, 'bundles/sharedflows')))

        apiproxy_bundles = list(
            map(find_bundle(apiproxy_bundles), updated_bundles['apiproxies'].keys()))
        sharedflow_bundles = list(
            map(find_bundle(sharedflow_bundles), updated_bundles['sharedflows'].keys()))

        if None in apiproxy_bundles or None in sharedflow_bundles:
            print(
                'ERROR: missing bundles, please make sure you have built them before attempting to deploy')
            exit(1)

        print('Uploading SharedFlows')
        print(sharedflow_bundles)
        sharedflow_revisions = apigee.import_sharedflows(sharedflow_bundles)
        print('Uploading ApiProxies')
        print(apiproxy_bundles)
        apiproxy_revisions = apigee.import_apiproxies(apiproxy_bundles)

        apigee.deploy_sharedflows('test', sharedflow_revisions)
        apigee.deploy_apiproxies('test', apiproxy_revisions)

        # Reimport the bundle to get a new revision that we can deploy to dev.
        # This will mean that the default revision when the UI is loaded won't
        # be the one that is deployed to test.
        #
        # We need to do this because apparently you can add new policies to
        # deployed revisions at will without bumping the revision number.
        # This gives us a safety net where someone won't accidentally modify
        # the revision deployed to test because it was the default selected.
        sharedflow_revisions_dev = apigee.import_sharedflows(
            sharedflow_bundles)
        apiproxy_revisions_dev = apigee.import_apiproxies(apiproxy_bundles)

        apigee.deploy_sharedflows('dev', sharedflow_revisions_dev)
        apigee.deploy_apiproxies('dev', apiproxy_revisions_dev)

        tags = []
        for name, revision in apiproxy_revisions.items():
            tags.append(this_repo.create_tag(
                'apiproxy/{}/{}'.format(name, revision), force=True))
            test_revisions['apiproxies'].update({
                name: {
                    'hash': updated_bundles['apiproxies'].get(name),
                    'revision': revision
                }
            })

        for name, revision in sharedflow_revisions.items():
            tags.append(this_repo.create_tag(
                'sharedflow/{}/{}'.format(name, revision), force=True))
            test_revisions['sharedflows'].update({
                name: {
                    'hash': updated_bundles['sharedflows'].get(name),
                    'revision': revision
                }
            })

        tags_push_url = 'https://{}:{}@ecommgit.ybs.com/{}/{}.git'.format(
            ci_user, ci_token, git_prj_ns, git_prj_name)

        with open(os.path.join(versions_repo_dir, 'test.json'), 'w') as file:
            json.dump(test_revisions, file, indent=4, sort_keys=True)

        print('updating versions repository...')
        versions_repo.index.add(['test.json'])
        this_commit = this_repo.head.commit
        versions_repo.index.commit('update for commit: {}\n{}'.format(
            this_commit, this_commit.message))
        for push in versions_repo.remotes.origin.push():
            print('pushed new versions to versions repository:', push.summary)

        print('pushing tags:')
        try:
            ci_tag_remote = this_repo.remotes.ci_tags
            ci_tag_remote.set_url(tags_push_url)
        except:
            ci_tag_remote = this_repo.create_remote('ci_tags', tags_push_url)

        for push in ci_tag_remote.push(tags):
            print('\t', push.local_ref, '->', push.remote_ref)
        os_utils.chmod_dir(versions_repo_dir, 0o777)


def run_local_deploy(apigee):
    print("Local Deployment")
    repo = git_utils.find_git_root(os.getcwd())

    is_ci = os.getenv('CI')

    # TODO make this nicer
    base_branch = repo.remotes.origin.refs.master

    # Cannot use default argument here as it is resoved before calling getenv
    if is_ci:
        branch_from_env = os.getenv('CI_COMMIT_REF_NAME')
        this_branch = repo.remotes.origin.refs[branch_from_env]
    else:
        this_branch = repo.active_branch

    print(base_branch, this_branch)

    merge_base = repo.merge_base(
        base_branch,
        this_branch
    )[0]

    git_root_dir = repo.working_tree_dir

    apiproxy_source_root = 'apiproxies'
    apiproxy_sources = list(
        list_api_dirs(os.path.join(git_root_dir, apiproxy_source_root))
    )
    apiproxy_names = list(map(lambda path: path.name, apiproxy_sources))
    print("apiproxy_names : ", apiproxy_names)
    apiproxy_sources_relative = list(
        map(lambda path: path.path, apiproxy_sources))

    sharedflow_source_root = 'sharedflows'
    sharedflow_sources = list(
        list_shf_dirs(os.path.join(git_root_dir, sharedflow_source_root))
    )
    sharedflow_names = list(map(lambda path: path.name, sharedflow_sources))
    print("shredflow_names: ", sharedflow_names)
    sharedflow_sources_relative = list(
        map(lambda path: path.path, sharedflow_sources))

    apiproxy_bundles = list(
        list_zips(os.path.join(git_root_dir, 'bundles/apiproxies')))
    print("apiproxy_bundles: ", apiproxy_bundles)
    sharedflow_bundles = list(
        list_zips(os.path.join(git_root_dir, 'bundles/sharedflows')))
    print("sharedflow_bundles: ", sharedflow_bundles)

    # TODO cannot use active_branch here because it's note available in CI
    # Perhaps we need to put it in a conditional branch
    cached_branch_state = load_branch_deploy_state(this_branch.name)

    changed_sharedflows = None
    changed_apiproxies = None

    if cached_branch_state:
        print('using found cached state for this branch')
        changed_sharedflows = compare_hashes.compare_with(
            cached_branch_state['sharedflows'], sharedflow_sources, subdir="sharedflowbundle")
        changed_apiproxies = compare_hashes.compare_with(
            cached_branch_state['apiproxies'], apiproxy_sources, subdir="apiproxy")
    else:
        print('unable to find cached state, detecting changes using git')
        changed_files = git_utils.git_changed_files(
            repo, merge_base, [apiproxy_sources_relative, sharedflow_sources_relative])

        changed_sharedflows = extract_bundle_names(
            sharedflow_source_root, changed_files)
        changed_apiproxies = extract_bundle_names(
            apiproxy_source_root, changed_files)

    if not changed_sharedflows and not changed_apiproxies:
        print('all bundles up to date')
        return

    if not changed_sharedflows:
        print('all sharedflows up to date')
    else:
        print('detected changes to the following sharedflows:',
              list(changed_sharedflows))

    if not changed_apiproxies:
        print('all apiproxies up to date')
    else:
        print('detected changes to the following apiproxies:',
              list(changed_apiproxies))

    apiproxy_bundles = list(
        map(find_bundle(apiproxy_bundles), changed_apiproxies))
    print('apiproxy_bundles:', apiproxy_bundles)
    sharedflow_bundles = list(
        map(find_bundle(sharedflow_bundles), changed_sharedflows))
    print('sharedflow_bundles:', sharedflow_bundles)

    if None in apiproxy_bundles or None in sharedflow_bundles:
        print('ERROR: missing bundles, please make sure you have built them before attempting to deploy')
        exit(1)

    sharedflow_revisions = None
    if sharedflow_bundles:
        print('Uploading SharedFlows')
        print(sharedflow_bundles)
        sharedflow_revisions = apigee.import_sharedflows(sharedflow_bundles)
    apiproxy_revisions = None
    if apiproxy_bundles:
        print('Uploading ApiProxies')
        print(apiproxy_bundles)
        apiproxy_revisions = apigee.import_apiproxies(apiproxy_bundles)

    if sharedflow_revisions:
        apigee.deploy_sharedflows('dev', sharedflow_revisions)
    if apiproxy_revisions:
        apigee.deploy_apiproxies('dev', apiproxy_revisions)

    if sharedflow_revisions or apiproxy_revisions:
        new_branch_state = create_new_branch_state(
            apiproxy_source_root, apiproxy_sources,
            sharedflow_source_root, sharedflow_sources
        )

    write_branch_deploy_state(this_branch.name, new_branch_state)

    shutil.rmtree(os.path.join(git_root_dir, 'bundles'))


def print_items(bundle_type, items):

    print("\n" + bundle_type)
    print('-' * len(bundle_type))
    if None in items or len(items) == 0:
        print("\tNone")
    else:
        print(*list(map(lambda x: "\t" + x, items)), sep="\n")

    print("\n")


def run_local_feature_deploy(apigee):
    print("Local Feature Deployment")
    repo = git_utils.find_git_root(os.getcwd())

    this_branch = repo.active_branch

    print("Branch:" + str(this_branch))

    git_root_dir = repo.working_tree_dir

    apiproxy_bundles = list(
        list_zips(os.path.join(git_root_dir, 'bundles/apiproxies')))
    print_items("apiproxy_bundles found:", list(
        map(lambda x: x.name, apiproxy_bundles)))

    sharedflow_bundles = list(
        list_zips(os.path.join(git_root_dir, 'bundles/sharedflows')))
    print_items("sharedflow_bundles found:", list(
        map(lambda x: x.name, sharedflow_bundles)))

    changed_sharedflows = None
    changed_apiproxies = None

    cached_branch_state = load_branch_deploy_state(this_branch.name)

    if cached_branch_state:
        print('\nusing found cached state for this branch')
        changed_apiproxies = compare_hashes.compare_with_zip(
            cached_branch_state['apiproxies'], apiproxy_bundles)
        changed_sharedflows = compare_hashes.compare_with_zip(
            cached_branch_state['sharedflows'], sharedflow_bundles)
    else:
        print('\nunable to find cached state, detecting changes using git')
        changed_apiproxies = list(map(lambda x: x.name, apiproxy_bundles))
        changed_sharedflows = list(map(lambda x: x.name, sharedflow_bundles))

    if not changed_sharedflows and not changed_apiproxies:
        print('all bundles up to date')
        exit(0)

    if not changed_apiproxies:
        print('all apiproxies up to date')
    else:
        print_items("detected changes to the following apiproxies:",
                    changed_apiproxies)

    if not changed_sharedflows:
        print('all sharedflows up to date')
    else:
        print_items("detected changes to the following sharedflows:",
                    changed_sharedflows)

    changed_apiproxy_bundles = list(
        map(find_zip_bundle(apiproxy_bundles), changed_apiproxies))

    changed_sharedflow_bundles = list(
        map(find_zip_bundle(sharedflow_bundles), changed_sharedflows))

    if None in changed_apiproxy_bundles or None in changed_sharedflow_bundles:
        print('ERROR: missing bundles, please make sure you have built them before attempting to deploy')
        exit(1)

    apiproxy_revisions = None
    if apiproxy_bundles:
        print_items("Uploading ApiProxies", list(
            map(lambda x: x.name, changed_apiproxy_bundles)))
        apiproxy_revisions = apigee.import_apiproxies(changed_apiproxy_bundles)

    sharedflow_revisions = None
    if changed_sharedflow_bundles:
        print_items("Uploading SharedFlows", list(
            map(lambda x: x.name, changed_sharedflow_bundles)))
        sharedflow_revisions = apigee.import_sharedflows(
            changed_sharedflow_bundles)

    if apiproxy_revisions:
        apigee.deploy_apiproxies('dev', apiproxy_revisions)

    if sharedflow_revisions:
        apigee.deploy_sharedflows('dev', sharedflow_revisions)

    apigee.update_apiproducts(changed_apiproxy_bundles, this_branch.name)

    if apiproxy_revisions or sharedflow_revisions:
        new_branch_state = create_new_branch_state_zip(
            apiproxy_bundles,
            sharedflow_bundles
        )

    write_branch_deploy_state(this_branch.name, new_branch_state)

    shutil.rmtree(os.path.join(git_root_dir, 'bundles'))


def feature_deployment_required():
        this_repo = git_utils.find_git_root(os.getcwd())

        if this_repo.head.is_detached:
            return False

        git_root_dir = this_repo.working_tree_dir


        print('Git Active Branch:' + this_repo.active_branch.name)

        print('Git Root Dir:' + git_root_dir)

        apiproxy_bundles = list(
            list_zips(os.path.join(git_root_dir, 'bundles/apiproxies')))
        sharedflow_bundles = list(
            list_zips(os.path.join(git_root_dir, 'bundles/sharedflows')))

        bundles = apiproxy_bundles + sharedflow_bundles

        for item in list(map(lambda x: x.name, bundles)):
            if this_repo.active_branch.name in item:
                return True

        return False

def main():
    apg_password = os.getenv('APIGEE_DEPLOY_PASSWORD')
    if apg_password is None or apg_password == "":
        apg_password = b64decode(os.getenv('APIGEE_DEPLOY_PASSWORD_B64')).decode("ascii")
    apigee = Apigee(
        os.getenv('APIGEE_DEPLOY_ORG'),
        os.getenv('APIGEE_DEPLOY_USER'),
        apg_password
    )

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    if 'master' in sys.argv:
        if os.getenv('CI') or input("this script is meant to be run on CI, are you sure you want to run it locally? (y/N) ").lower() == 'y':
            run_master_deploy(apigee)
    else:
        os_utils.updateEnv("APIGEE_DEPLOY_STATUS","DEPLOYED")
        if feature_deployment_required():
            run_local_feature_deploy(apigee)
            os_utils.updateEnv("UNIT_TEST_FEATURE","True")
        else:
            run_local_deploy(apigee)
            os_utils.updateEnv("UNIT_TEST_FEATURE","False")


if __name__ == '__main__':
    main()
