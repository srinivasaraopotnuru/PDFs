"""
Wrapper around Apigee management API with uitilites for deployment scripts
"""

from enum import Enum

import json
import requests

import sys


class Apigee:

    def __init__(self, org, user, password):
        self.host = 'https://api.enterprise.apigee.com'
        self.org = org
        self.session = requests.Session()

        self.session.auth = user.strip(), password.strip()
        self.session.headers.update({
            'Accept': 'application/json'
        })

    def import_sharedflows(self, bundles):
        return self.import_bundles(BundleType.SHAREDFLOW, bundles)

    def import_apiproxies(self, bundles):
        return self.import_bundles(BundleType.APIPROXY, bundles)

    def import_bundles(self, bundle_type, bundles):
        new_revisions = {}
        for bundle in bundles:
            name = bundle.name[:-4]  # chop off .zip extension to get the name
            uri = (
                '/v1/organizations/{}/{}'
                '?action=import&name={}'
            ).format(self.org, self.path_from_type(bundle_type), name)
            headers = {'Content-Type': 'application/octet-stream'}
            print('importing', bundle_type.value, name, end='... ')
            with open(bundle, 'rb') as data:
                response = self.session.post(self.host + uri, data=data.read(), headers=headers, verify=False)
                self.check_response(response, 201)
                new_revision = int(json.loads(response.text)['revision'])
                new_revisions[name] = new_revision
                print('new revision:', new_revision)

        return new_revisions

    def deploy_apiproxies(self, env, bundle_revisions):
        for bundle, revision in bundle_revisions.items():
            self.deploy(BundleType.APIPROXY, env, bundle, revision)

    def deploy_sharedflows(self, env, bundle_revisions):
        for bundle, revision in bundle_revisions.items():
            self.deploy(BundleType.SHAREDFLOW, env, bundle, revision)

    def deploy(self, bundle_type, env, bundle, revision):
        uri = (
            '/v1/organizations/{}'
            '/environments/{}'
            '/{}/{}'
            '/revisions/{}'
            '/deployments'
        ).format(self.org, env, self.path_from_type(bundle_type), bundle, revision)

        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        data = 'override=true'

        msg = 'deploying {} {} (revision: {}) to {} environment'
        print(msg.format(bundle_type.value, bundle, revision, env), end='... ')

        response = self.session.post(self.host + uri, data=data, headers=headers, verify=False)
        self.check_response(response, 200)
        print('success')

    def get_apiproduct(self, prod_name):
        '''Gets an APIGee product.'''
        geturi = (
            '/v1/organizations/{}'
            '/apiproducts/{}').format(self.org, prod_name)

        response = self.session.get(self.host + geturi, verify=False)
        print("response.status_code: ", response.status_code)
        #print("Response: ", response.text)
        self.check_response(response, 200, 404)

        existingProduct = None
        if response.status_code == 200:
            existingProduct = response.json()
        return existingProduct

    def get_ref(self, ref_name, env=None):
        '''Gets an APIGee ref.'''
        if env != None:
            uri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/references'
            ).format(self.org, env)

        refuri = uri + ('/{}').format(ref_name)
        print("Getting reference with URI:", refuri)

        response = self.session.get(self.host + refuri, verify=False)
        print("response.status_code: ", response.status_code)
        print("Response: ", response.text)
        self.check_response(response, 200, 404)

        existingRef = None
        if response.status_code == 200:
            existingRef = response.json()
        return existingRef

    def get_targserv(self, targserv_name, env=None):
        '''Gets an APIGee target server.'''
        if env != None:
            uri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/targetservers'
            ).format(self.org, env)

        targservuri = uri + ('/{}').format(targserv_name)
        print("Getting target server with URI:", targservuri)

        response = self.session.get(self.host + targservuri, verify=False)
        print("response.status_code: ", response.status_code)
        print("Response: ", response.text)
        self.check_response(response, 200, 404)

        existingTargServ = None
        if response.status_code == 200:
            existingTargServ = response.json()
        return existingTargServ

    def get_virthost(self, virthost_name, env=None):
        '''Gets an APIGee virtual host.'''
        if env != None:
            uri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/virtualhosts'
            ).format(self.org, env)

        virthosturi = uri + ('/{}').format(virthost_name)
        print("Getting target server with URI:", virthosturi)

        response = self.session.get(self.host + virthosturi, verify=False)
        print("response.status_code: ", response.status_code)
        print("Response: ", response.text)
        self.check_response(response, 200, 404)

        existingVirtHost = None
        if response.status_code == 200:
            existingVirtHost = response.json()
        return existingVirtHost

    def upsert_ref(self, ref_name, env, new_ref, old_ref=None):
        '''Creates or updates an APIGee reference.'''
        headers = {'Content-Type': 'application/json'}
        # Check the existing ref first.
        if old_ref is None:
            ### Need to create it
            upduri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/references').format(self.org, env)
            workingMsg = 'Creating entry: ' + ref_name + ': with URI: ' + upduri
            successMsg = 'apiReference Create success'
            response = self.session.post(self.host + upduri, data=json.dumps(new_ref), headers=headers, verify=False)
            print(workingMsg, end='... ')
            self.check_response(response, 200, 201)
            print(response)
        else:
            ### Need to update it.
            upduri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/references/{}').format(self.org, env, ref_name)
            workingMsg = 'Updating entry: ' + ref_name + ': with URI: ' + upduri
            successMsg = 'apiReference Update success'
            response = self.session.put(self.host + upduri, data=json.dumps(new_ref), headers=headers, verify=False)
            print(workingMsg, end='... ')
            self.check_response(response, 200, 201)
            print(response)            

    def upsert_targserv(self, targserv_name, env, new_targserv, old_targserv=None):
        '''Creates or updates an APIGee target server.'''
        headers = {'Content-Type': 'application/json'}
        # Check the existing targserv first.
        if old_targserv is None:
            ### Need to create it
            upduri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/targetservers').format(self.org, env)
            workingMsg = 'Creating entry: ' + targserv_name + ': with URI: ' + upduri
            successMsg = 'apiTargetServer Create success'
            response = self.session.post(self.host + upduri, data=json.dumps(new_targserv), headers=headers, verify=False)
            print(workingMsg, end='... ')
            self.check_response(response, 200, 201)
            print(response)
        else:
            ### Need to update it.
            upduri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/targetservers/{}').format(self.org, env, targserv_name)
            workingMsg = 'Updating entry: ' + targserv_name + ': with URI: ' + upduri
            successMsg = 'apiTargetServer Update success'
            response = self.session.put(self.host + upduri, data=json.dumps(new_targserv), headers=headers, verify=False)
            print(workingMsg, end='... ')
            self.check_response(response, 200, 201)
            print(response)   

    def upsert_virthost(self, virthost_name, env, new_virthost, old_virthost=None):
        '''Creates or updates an APIGee virtual host.'''
        headers = {'Content-Type': 'application/json'}
        # Check the existing virthost first.
        if old_virthost is None:
            ### Need to create it
            upduri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/virtualhosts').format(self.org, env)
            workingMsg = 'Creating entry: ' + virthost_name + ': with URI: ' + upduri
            successMsg = 'apiVirtualHost Create success'
            response = self.session.post(self.host + upduri, data=json.dumps(new_virthost), headers=headers, verify=False)
            print(workingMsg, end='... ')
            self.check_response(response, 200, 201)
            print(response)
        else:
            ### Need to update it.
            upduri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/virtualhosts/{}').format(self.org, env, virthost_name)
            workingMsg = 'Updating entry: ' + virthost_name + ': with URI: ' + upduri
            successMsg = 'apiVirtualHost Update success'
            response = self.session.put(self.host + upduri, data=json.dumps(new_virthost), headers=headers, verify=False)
            print(workingMsg, end='... ')
            self.check_response(response, 200, 201)
            print(response)

    def upsert_apiproduct(self, prod_name, new_product, old_product=None):
        '''Creates or updates an APIGee product.'''
        # Check the existing product first.
        if old_product is None:
            ### Need to create it
            upduri = (
                '/v1/organizations/{}'
                '/apiproducts').format(self.org)
            workingMsg = 'Creating entry: ' + prod_name + ': with URI: ' + upduri
            successMsg = 'apiProduct Create success'
        else:
            ### Need to update it.
            upduri = (
                '/v1/organizations/{}'
                '/apiproducts/{}').format(self.org, prod_name)
            workingMsg = 'Updating entry: ' + prod_name + ': with URI: ' + upduri
            successMsg = 'apiProduct Update success'

        print(workingMsg, end='... ')
        ### Prepare and make API call
        headers = {'Content-Type': 'application/json'}
        response = self.session.post(self.host + upduri, data=json.dumps(new_product), headers=headers, verify=False)
        self.check_response(response, 200, 201)
        print(response)

    def get_developer(self, dev_email):
        '''Gets an APIGee developer.'''
        geturi = (
            '/v1/organizations/{}'
            '/developers/{}').format(self.org, dev_email)

        response = self.session.get(self.host + geturi, verify=False)
        print("response.status_code: ", response.status_code)
        #print("Response: ", response.text)
        self.check_response(response, 200, 404)

        existingDeveloper = None
        if response.status_code == 200:
            existingDeveloper = response.json()
        return existingDeveloper


    def upsert_developer(self, dev_email, new_dev, old_dev=None):
        '''Creates or updates an APIGee developer.'''
        # Check the existing product first.
        if old_dev is None:
            ### Need to create it
            upduri = (
                '/v1/organizations/{}'
                '/developers').format(self.org)
            workingMsg = 'Creating entry: ' + dev_email + ': with URI: ' + upduri
            successMsg = 'apiDeveloper Create success'
        else:
            ### Need to update it.
            upduri = (
                '/v1/organizations/{}'
                '/developers/{}').format(self.org, dev_email)
            workingMsg = 'Updating entry: ' + dev_email + ': with URI: ' + upduri
            successMsg = 'apiDeveloper Update success'

        print(workingMsg, end='... ')
        ### Prepare and make API call
        headers = {'Content-Type': 'application/json'}
        response = self.session.post(self.host + upduri, data=json.dumps(new_dev), headers=headers, verify=False)
        self.check_response(response, 200, 201)
        print(response)

    def get_app(self, dev_email, app_name):
        '''Gets an APIGee App.'''
        geturi = (
            '/v1/organizations/{}'
            '/developers/{}/apps/{}').format(self.org, dev_email, app_name)

        response = self.session.get(self.host + geturi, verify=False)
        print("response.status_code: ", response.status_code)
        #print("Response: ", response.text)
        self.check_response(response, 200, 404)

        existingApp = None
        if response.status_code == 200:
            existingApp = response.json()
        return existingApp


    def upsert_app(self, dev_email, app_name, new_app, old_app=None):
        '''Creates or updates an APIGee App.'''
        # Check the existing product first.
        if old_app is None:
            ### Need to create it
            upduri = (
                '/v1/organizations/{}'
                '/developers/{}/apps').format(self.org, dev_email)
            workingMsg = 'Creating entry: ' + app_name + ': with URI: ' + upduri
            successMsg = 'apiApp Create success'
        else:
            ### Need to update it.
            upduri = (
                '/v1/organizations/{}'
                '/developers/{}/apps/{}').format(self.org, dev_email, app_name)
            workingMsg = 'Updating entry: ' + app_name + ': with URI: ' + upduri
            successMsg = 'apiApp Update success'

        print(workingMsg, end='... ')
        ### Prepare and make API call
        headers = {'Content-Type': 'application/json'}
        response = self.session.post(self.host + upduri, data=json.dumps(new_app), headers=headers, verify=False)
        self.check_response(response, 200, 201)
        print(response)


    def get_kvm(self, kvm_name, env=None, proxy_name=None, proxy_version=None):
        ### Org scoped KVM
        uri = (
            '/v1/organizations/{}'
            '/keyvaluemaps'
        ).format(self.org)

        ### Env scoped KVM
        if env != None:
            uri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/keyvaluemaps'
            ).format(self.org, env)

        ### Proxy scoped KVM
        if proxy_name != None:
            uri = (
                '/v1/organizations/{}'
                '/apis/{}'
                '/keyvaluemaps'
            ).format(self.org, proxy_name)

        ### Proxy revision scoped KVM
        if proxy_version != None:
            uri = (
                '/v1/organizations/{}'
                '/apis/{}'
                'revisions/{}'
                '/keyvaluemaps'
            ).format(self.org, proxy_name, proxy_version)

        kvmuri = uri + ('/{}').format(kvm_name)
        print("Getting KVM with URI:", kvmuri)

        response = self.session.get(self.host + kvmuri, verify=False)
        print("response.status_code: ", response.status_code)
        print("Response: ", response.text)
        self.check_response(response, 200, 404)

        existingKvm = None
        if response.status_code == 200:
            existingKvm = response.json()
        return existingKvm


    def upsert_kvm(self, kvm_name, env, kvm_dict, proxy_name, proxy_version, old_kvm=None):
        ### Org scoped KVM
        uri = (
            '/v1/organizations/{}'
            '/keyvaluemaps'
        ).format(self.org)

        ### Env scoped KVM
        if env != None:
            uri = (
                '/v1/organizations/{}'
                '/environments/{}'
                '/keyvaluemaps'
            ).format(self.org, env)

        ### Proxy scoped KVM
        if proxy_name != None:
            uri = (
                '/v1/organizations/{}'
                '/apis/{}'
                '/keyvaluemaps'
            ).format(self.org, proxy_name)

        ### Proxy revision scoped KVM
        if proxy_version != None:
            uri = (
                '/v1/organizations/{}'
                '/apis/{}'
                'revisions/{}'
                '/keyvaluemaps'
            ).format(self.org, proxy_name, proxy_version)

        kvmuri = uri + ('/{}').format(kvm_name)
        headers = {'Content-Type': 'application/json'}

        encrypted = False
        if "encrypted" in kvm_dict and kvm_dict["encrypted"]:
            encrypted = True

        if old_kvm is None:
            ### Create New
            msg = 'Creating KVM with URI: ' + uri
            print(msg, end='... ')
            print(kvm_dict)
            response = self.session.post(self.host + uri, data=json.dumps(kvm_dict), headers=headers, verify=False)
            self.check_response(response, 200, 201)
            print('KVM Create success')

        else:
            ### Update it
            print('Updating KVM...')

            existingEntryKeys = {}
            if "entry" in old_kvm:
                print("Existing KVM entry: ", old_kvm["entry"])
                existingEntryKeys = set(map(lambda l: l['name'], old_kvm["entry"]))
            print("existingEntryKeys: ", existingEntryKeys)

            if "entry" in kvm_dict:
                for entry in kvm_dict["entry"]:
                    print("entry:", entry)
                    kvmupd_uri = kvmuri
                    kvm_key = entry["name"]
                    print("kvm_key:", kvm_key)
                    doUpsert = False
                    if kvm_key in existingEntryKeys:
                        if not encrypted:
                            kvmupd_uri = kvmuri + ('/entries/{}').format(kvm_key)
                            workingMsg = 'Updating entry: ' + kvm_key + ': with URI: ' + kvmupd_uri
                            successMsg = 'KVM Update success'
                            doUpsert = True
                        else:
                            workingMsg = "Not updating encrypted entry"
                    else:
                        kvmupd_uri = kvmuri + '/entries'
                        workingMsg = 'Creating entry: ' + kvm_key + ': with URI: ' + kvmupd_uri
                        successMsg = 'KVM Create success'
                        doUpsert = True
                    print(workingMsg, end='... ')
                    if doUpsert:
                        response = self.session.post(self.host + kvmupd_uri, data=json.dumps(entry), headers=headers, verify=False)
                        self.check_response(response, 200, 201)
                        print(successMsg)
            else:
                print("No entries found in the KVM")


    def get_revisions(self, apiproxies, sharedflows):
        def _get_revisions(bundle_type, name):
            uri = '/v1/organizations/{}/{}/{}/revisions'.format(self.org, bundle_type, name)
            response = self.session.get(self.host + uri, verify=False)
            self.check_response(response, 200, 404)
            if response.status_code == 200:
                return list(map(int, json.loads(response.text)))
            else:
                return None

        revisions = {
            'apiproxies': {name: _get_revisions('apis', name) for name in apiproxies},
            'sharedflows': {name: _get_revisions('sharedflows', name) for name in sharedflows}
        }
        print("got revisions")

        return revisions

    def reset_revisions(self, latest_revisions, all_revisions):
        for name, revisions in all_revisions['sharedflows'].items():
            revision = latest_revisions['sharedflows'].get(name, {}).get('revision', 0)
            revisions_to_remove = None if revisions is None else list(filter(lambda x: x > revision, revisions))
            if not revisions_to_remove:
                print('no revisions to remove for', name)
                continue

            print('removing revisions for', name, revisions_to_remove)
            for revision in revisions_to_remove:
                uri = '/v1/organizations/{}/environments/dev/sharedflows/{}/revisions/{}/deployments'.format(self.org, name, revision)
                response = self.session.delete('https://api.enterprise.apigee.com' + uri, verify=False)
                assert response.status_code == 200 or response.status_code == 400, (response.status_code, response.text)
                uri = '/v1/organizations/{}/environments/test/sharedflows/{}/revisions/{}/deployments'.format(self.org, name, revision)
                response = self.session.delete('https://api.enterprise.apigee.com' + uri, verify=False)
                assert response.status_code == 200 or response.status_code == 400, (response.status_code, response.text)
                uri = '/v1/organizations/{}/sharedflows/{}/revisions/{}'.format(self.org, name, revision)
                response = self.session.delete('https://api.enterprise.apigee.com' + uri, verify=False)
                assert response.status_code == 200, (response.status_code, response.text)
                print('.', end='', flush=True)

            print('\r', ' '*len(revisions_to_remove), end='\r')

        for name, revisions in all_revisions['apiproxies'].items():
            revision = latest_revisions['apiproxies'].get(name, {}).get('revision', 0)
            revisions_to_remove = list(filter(lambda x: x > revision, revisions))
            if not revisions_to_remove:
                print('no revisions to remove for', name)
                continue

            print('removing revisions for', name, revisions_to_remove)
            for revision in revisions_to_remove:
                uri = '/v1/organizations/{}/environments/dev/apis/{}/revisions/{}/deployments'.format(self.org, name, revision)
                response = self.session.delete('https://api.enterprise.apigee.com' + uri, verify=False)
                assert response.status_code == 200 or response.status_code == 400, (response.status_code, response.text)
                uri = '/v1/organizations/{}/environments/test/sharedflows/{}/revisions/{}/deployments'.format(self.org, name, revision)
                response = self.session.delete('https://api.enterprise.apigee.com' + uri, verify=False)
                assert response.status_code == 200 or response.status_code == 400, (response.status_code, response.text)
                uri = '/v1/organizations/{}/apis/{}/revisions/{}'.format(self.org, name, revision)
                response = self.session.delete('https://api.enterprise.apigee.com' + uri, verify=False)
                assert response.status_code == 200, (response.status_code, response.text)
                print('.', end='', flush=True)

            print('\r', ' '*len(revisions_to_remove), end='\r')

    def get_deployed_revisions(self, bundle_type, name):
        uri = '/v1/organizations/{}/{}/{}/deployments'.format(self.org, bundle_type, name)
        response = self.session.get(self.host + uri, verify=False)
        self.check_response(response, 200, 404)

        if response.status_code == 200:

            revisions = []

            jsonResponse = json.loads(response.text)

            for env in jsonResponse["environment"]:        

                for revision in env["revision"]:
                    rev = revision['name']
                    revisions.append(rev)
            
            return revisions
        else:
            return None
                    
    def remove_feature_item(self, branch, bundle_type):

        item_type = self.path_from_type(bundle_type)

        # get expanded list of proxies/shared flows
        uri = '/v1/organizations/{}/{}'.format(self.org,item_type)
        response = self.session.get(self.host + uri, verify=False)
        self.check_response(response, 200, 404)

        if response.status_code == 200:

            for item in json.loads(response.text): 

                if branch in item:

                    print("removing feature item {}".format(item))        
         
                    revisions = self.get_deployed_revisions(item_type, item)

                    for revision in revisions:
                        print("   undeploying feature item revision {}".format(revision))
                        uri = '/v1/organizations/{}/environments/dev/{}/{}/revisions/{}/deployments'.format(self.org,item_type,item,revision)
                        response = self.session.delete(self.host + uri, verify=False)
                        self.check_response(response, 200, 404)

                    uri = '/v1/organizations/{}/{}/{}'.format(self.org,item_type, item)
                    response = self.session.delete(self.host + uri, verify=False)
                    self.check_response(response, 200, 404)
                    print("   item removed")


    def update_apiproducts(self, apiproxies, branchName):
        print("Checking API Products")
        proxies = list(map(lambda x: x.name[:-4].replace(branchName + "-",""),apiproxies)) 
        featureProxies = list(map(lambda x: x.name[:-4],apiproxies)) 

        # get expanded list of products
        uri = '/v1/organizations/{}/apiproducts?expand=true'.format(self.org)
        response = self.session.get(self.host + uri, verify=False)
        self.check_response(response, 200, 404)

        if response.status_code == 200:

            apiProducts = json.loads(response.text)['apiProduct']
            
            for apiProduct in apiProducts: 
                updateApiProduct = False

                #are any of the proxies in this product
                anyProxiesMatched =  any(elem in proxies  for elem in apiProduct['proxies'])

                if anyProxiesMatched:
                    for proxy in proxies:
                        if proxy in apiProduct['proxies']:
                            featureProxy = featureProxies[proxies.index(proxy)]
                            if not featureProxy in apiProduct['proxies']:
                                    print("adding {} to product {}".format(featureProxy,  apiProduct['name']))
                                    apiProduct['proxies'].append(featureProxy)
                                    updateApiProduct = True

                    if updateApiProduct:
                        #call the update 
                        print("updating API Product " + apiProduct['name'])
                        uri = '/v1/organizations/{}/apiproducts/{}'.format(self.org,apiProduct['name'])
                        headers = {'Content-Type': 'application/json'}
                        data = json.dumps(apiProduct)
                        response = self.session.put(self.host + uri, data=data, headers=headers,   verify=False)
                        self.check_response(response, 200)
                        print('success')
            return None
        else:
            return None

    def remove_feature_from_apiproducts(self, branchName):
        print("Checking API Products")
    
        # get expanded list of products
        uri = '/v1/organizations/{}/apiproducts?expand=true'.format(self.org)
        response = self.session.get(self.host + uri, verify=False)
        self.check_response(response, 200, 404)

        if response.status_code == 200:

            apiProducts = json.loads(response.text)['apiProduct']
            
            for apiProduct in apiProducts: 
                updateApiProduct = False

                modifiedProxies = []
                for proxy in apiProduct['proxies']:

                    if branchName in proxy:
                        updateApiProduct = True
                        print("removing {} from API Product {}".format( proxy, apiProduct['name']))
                    else:
                         modifiedProxies.append(proxy)
                
                if updateApiProduct:
                    apiProduct['proxies'] = modifiedProxies

                    #call the update 
                    print("updating API Product " + apiProduct['name'])
                    uri = '/v1/organizations/{}/apiproducts/{}'.format(self.org,apiProduct['name'])
                    headers = {'Content-Type': 'application/json'}
                    data = json.dumps(apiProduct)
                    response = self.session.put(self.host + uri, data=data, headers=headers,   verify=False)
                    self.check_response(response, 200)
                    print('success')
            return None
        else:
            return None

    @staticmethod
    def path_from_type(type):
        return {
            BundleType.APIPROXY: 'apis',
            BundleType.SHAREDFLOW: 'sharedflows'
        }[type]

    @staticmethod
    def check_response(response, *status_codes):
        if response.status_code not in status_codes:
            msg = 'invalid response code [{}]'.format(response.status_code)

            raise RuntimeError(msg, ':', response.text)

    def __del__(self):
        pass
        # self.session.close()


class BundleType(Enum):
    APIPROXY = 'apiproxy'
    SHAREDFLOW = 'sharedflow'
