'''utilities for interacting with git repositories'''
import itertools
import os

import git


def clone(url, to='.'):
    '''clones a repository to the specified directory'''
    return git.Repo.clone_from(url, to)


def find_git_root(directory):
    '''determines whether the specified directory is in a git repository and
    returns a Repo object that wraps it. Otherwise returns None'''
    while directory != '':
        if '.git' in map(lambda entry: entry.name, os.scandir(directory)):
            break

        directory = os.path.dirname(directory)

    try:
        repo = git.Repo(directory)
    except git.InvalidGitRepositoryError:
        return None

    return repo


def list_files(directory):
    '''lists all files in the specified directory, honoring .gitignore'''
    return git.cmd.Git(directory).ls_files().splitlines()

def git_changed_files(git_repo, merge_base, dirs_list):
    changed_files = list(map(
            lambda diff: diff.b_path,  # get the _new_ of the modified file
            itertools.chain(
                # git diff base_branch...HEAD -- apiproxy_sources # sharedflow_sources
                git_repo.index.diff(merge_base, dirs_list),
                # git diff -- apiproxy_sources sharedflow_sources
                git_repo.index.diff(None, dirs_list),
                # git diff --staged -- apiproxy_sources # sharedflow_sources
                git_repo.index.diff(None, dirs_list, staged=True)
            )
        ))
    return changed_files
