##############################
#This should be called from the parent shell using source (.) e.g:
#'. set-env.sh'
#OR: '. set-env.sh' master if running deployments as master.
##############################

RESET="\033[0m"
BOLD_GREEN="\033[1;32m"
BOLD_RED="\033[1;31m"

##Get git working dir.
export gwd=`git rev-parse --show-toplevel`

#symlink custom client hooks
if [ -f custom_hooks/pre-commit ]; then
    ln -sf ../../custom_hooks/pre-commit .git/hooks/pre-commit
fi
if [ -f custom_hooks/pre-push ]; then
    ln -sf ../../custom_hooks/pre-push .git/hooks/pre-push
fi

if ls *.code-workspace 1> /dev/null 2>&1; then
  #Ignore updates to the VSCode workspace file
  git update-index --skip-worktree *.code-workspace
fi

#Set up GIT username and GIT email config.
#Hook failures complain if these values are not set, before the actual hook error.
gitUsername=`git config user.name`
if [ "$gitUsername" = "" ]; then
    read -p "Enter Your Git Username (Firstname Surname): " gitUsername
    git config --global user.name "$(echo -n $gitUsername)"
else
    echo "GIT username: $gitUsername"
fi

gitEmail=`git config user.email`
if [ "$gitEmail" = "" ]; then
    read -p "Enter Your Git Email: " gitEmail
    git config --global user.email "$(echo -n $gitEmail)"
else
    echo "GIT email: $gitEmail"
fi

APIGEE_DEPLOY_ORG=ybsg-digital-nonprod
SERVICE_DIR=
if [ -d "services" ]; then
  SERVICE_DIR=`find services/ -name "start-service.sh" -exec dirname {} \; -a -quit`
fi
ENVIRONMENT_NAME=os4/dev

### Get the GIT project namespace and name, we need this in the deploy script (for master deployments).
gitRemote=`git config --get remote.origin.url`
gitLocal=`git rev-parse --show-toplevel`
#echo $gitRemote
gitPrjName=`echo $gitRemote | awk -F/ '{print $NF}' | sed 's/\.git$//g'`
gitPrjNs=`echo $gitRemote | awk -F/ '{print $(NF-1)}'`
echo GIT_PROJECT_DIR=$gitLocal
echo GIT_PROJECT_NAMESPACE=$gitPrjNs
echo GIT_PROJECT_NAME=$gitPrjName

### Set up Openshift vars
OPENSHIFT_DEPLOY_NAMESPACE="ds-$gitPrjNs-dev"
OPENSHIFT_DEPLOY_NAMESPACE=${OPENSHIFT_DEPLOY_NAMESPACE/-enterprise/-reference}
OPENSHIFT_DEPLOY_NAMESPACE=${OPENSHIFT_DEPLOY_NAMESPACE/-calculators/-calculator}
echo OPENSHIFT_DEPLOY_NAMESPACE=$OPENSHIFT_DEPLOY_NAMESPACE
OPENSHIFT_DEPLOY_SUBDOMAIN=api
OPENSHIFT_DEPLOY_DOMAIN=ostest.ybs.com:6443
#Openshift Template PARAMS
OPENSHIFT_DOMAIN=apps.ostest.ybs.com
OPENSHIFT_PUBLIC_DOMAIN=nonprod.services.ybs.co.uk
REPLICAS=1
IDLE_ALLOWED='true'
PUBLIC_ROUTER=nonprod
ENV_TIER=nonprod

### Get the GIT password / token if running for master
if [[ "$1" = "master" && "$GITLAB_PUSH_TOKEN" = "" ]]; then
    read -s -p "Enter Your GIT password token: " GITLAB_PUSH_TOKEN
    echo
fi

### Get the Windows AD Username and password.
if [ "" != "$USERNAME" ]; then
    AD_USERNAME=$USERNAME
fi
if [ "" = "$AD_USERNAME" ]; then
    read -p "Enter Your Windows AD username: " AD_USERNAME
fi
if [ "" = "$AD_PASSWORD_B64" ]; then
    read -s -p "Enter Your Windows AD password: " AD_PASSWORD
    AD_PASSWORD_B64=`echo -n $AD_PASSWORD | base64`
    AD_PASSWORD=
    echo
fi
read -p "Enter the OpenShift instance (os4): " OS_INSTANCE
if [ "$OS_INSTANCE" == "" ]; then
  OS_INSTANCE=os4
elif [ "$OS_INSTANCE" != "os4" ]; then
  ENVIRONMENT_NAME=os3/dev
  OPENSHIFT_DEPLOY_SUBDOMAIN=master-test
  OPENSHIFT_DEPLOY_DOMAIN=os.ybs.com
  OPENSHIFT_DOMAIN=test.os.ybs.com
fi

VIA_API=
### Setup APIGEE credentials, we need this in the deploy script.
if [ -d "$gwd/apiproxies" ] && [[ ! $gitPrjName =~ .*-test$ ]]; then
  VIA_API=True
  if [[ "$APIGEE_DEPLOY_USER" = "" || "$APIGEE_DEPLOY_PASSWORD_B64" = "" ]]; then
      read -p "Enter Your Apigee username: " APIGEE_DEPLOY_USER
      read -s -p "Enter Your Apigee Password: " APIGEE_DEPLOY_PASSWORD
      APIGEE_DEPLOY_PASSWORD_B64=`echo -n $APIGEE_DEPLOY_PASSWORD | base64`
      APIGEE_DEPLOY_PASSWORD=
      echo
  else
      echo "APIGEE_DEPLOY_USER: $APIGEE_DEPLOY_USER"
      echo "APIGEE_DEPLOY_PASSWORD: ********"
      echo "To change the APIGEE user and password, reset the env vars: APIGEE_DEPLOY_USER and APIGEE_DEPLOY_PASSWORD_B64"
  fi
fi

#Load functions
. $gwd/sboot-tools/common/functions.sh

#Create the .env file if it does not already exist.
if [[ ! -f .env ]]; then
  if [[ -f .env.base ]]; then
    cp .env.base .env
  else
    touch .env
  fi
  if [[ -f settings.gradle ]]; then
    curRootProj=$(grep "rootProject.name *=" settings.gradle)
    lineRegex="rootProject.name *= *'$gitPrjName'"
    if [[ ! "$curRootProj" =~ $lineRegex ]]; then
      read -p "settings.gradle rootProject name: '$curRootProj' doesn't match the current GIT project name: $gitPrjName. Do you want to change it? " -n 1 -r
      echo #move to a new line
      if [[ $REPLY =~ ^[Yy]$ ]]
      then
        WritePropertyInFile settings.gradle "rootProject.name" "'$gitPrjName'" "true"
      fi
    fi
  fi
fi

### Artifactory:
ARTIFACTORY_HOST="artifactory.ybs.com"

echo Please wait.
# Write all values to the env file.
WritePropertyInFile .env "AD_USERNAME" "$AD_USERNAME" "true"
WritePropertyInFile .env "AD_PASSWORD_B64" "$AD_PASSWORD_B64" "true"
WritePropertyInFile .env "APIGEE_DEPLOY_ORG" "$APIGEE_DEPLOY_ORG"
WritePropertyInFile .env "APIGEE_DEPLOY_USER" "$APIGEE_DEPLOY_USER"
WritePropertyInFile .env "APIGEE_DEPLOY_PASSWORD_B64" "$APIGEE_DEPLOY_PASSWORD_B64"
WritePropertyInFile .env "APIGEE_USERNAME" "$APIGEE_DEPLOY_USER"
WritePropertyInFile .env "APIGEE_PASSWORD_B64" "$APIGEE_DEPLOY_PASSWORD_B64"
WritePropertyInFile .env "TARGET_ENV" "${ENVIRONMENT_NAME##*/}"
WritePropertyInFile .env "ENVIRONMENT_NAME" "$ENVIRONMENT_NAME" "true"
WritePropertyInFile .env "ENVIRONMENT_TIER" "development"
WritePropertyInFile .env "GIT_PROJECT_DIR" "$gitLocal" "true"
WritePropertyInFile .env "GIT_PROJECT_NAMESPACE" "$gitPrjNs" "true"
WritePropertyInFile .env "GIT_PROJECT_NAME" "$gitPrjName" "true"
WritePropertyInFile .env "GITLAB_PUSH_USER" "$AD_USERNAME" "true"
WritePropertyInFile .env "GITLAB_PUSH_TOKEN" "$GITLAB_PUSH_TOKEN" "true"
WritePropertyInFile .env "OPENSHIFT_DEPLOY_USER" "$AD_USERNAME" "true"
WritePropertyInFile .env "OPENSHIFT_DEPLOY_PASSWD_B64" "$AD_PASSWORD_B64" "true"
WritePropertyInFile .env "OPENSHIFT_DEPLOY_NAMESPACE" "$OPENSHIFT_DEPLOY_NAMESPACE" "false"
WritePropertyInFile .env "OPENSHIFT_DEPLOY_SUBDOMAIN" "$OPENSHIFT_DEPLOY_SUBDOMAIN" "true"
WritePropertyInFile .env "OPENSHIFT_DEPLOY_DOMAIN" "$OPENSHIFT_DEPLOY_DOMAIN" "true"
WritePropertyInFile .env "OPENSHIFT_DEPLOYER_TAG" "$AD_USERNAME" "true"
WritePropertyInFile .env "ARTIFACTORY_HOST" "$ARTIFACTORY_HOST" "false"
WritePropertyInFile .env "DOCKER_REGISTRY" "docker.$ARTIFACTORY_HOST" "false"
WritePropertyInFile .env "DOCKER_REGISTRY_PUSH" "digital-docker-nonprod-local.$ARTIFACTORY_HOST" "false"
WritePropertyInFile .env "DOCKER_NAME" "ybsg/$gitPrjNs/$gitPrjName" "false"
WritePropertyInFile .env "DOCKER_IMG_VERSION" "latest" "false"
WritePropertyInFile .env "SERVICE_DIR" "$SERVICE_DIR" "true"
WritePropertyInFile .env "SERVICE_PROTOCOL" "https" "true"
WritePropertyInFile .env "SERVICE_HOST" "$OPENSHIFT_DEPLOY_NAMESPACE.$OPENSHIFT_DOMAIN" "false"
WritePropertyInFile .env "OPENSHIFT_DOMAIN" "$OPENSHIFT_DOMAIN" "true"
WritePropertyInFile .env "OPENSHIFT_PUBLIC_DOMAIN" "$OPENSHIFT_PUBLIC_DOMAIN" "true"
WritePropertyInFile .env "OPENSHIFT_PUBLIC_FQDN" "$OPENSHIFT_DEPLOY_NAMESPACE.$OPENSHIFT_PUBLIC_DOMAIN" "true"
WritePropertyInFile .env "REPLICAS" "$REPLICAS" "true"
WritePropertyInFile .env "IDLE_ALLOWED" "$IDLE_ALLOWED" "true"
WritePropertyInFile .env "PUBLIC_ROUTER" "$PUBLIC_ROUTER" "true"
WritePropertyInFile .env "ENV_TIER" "$ENV_TIER" "true"
WritePropertyInFile .env "VIA_API" "$VIA_API" "true"
echo -e "${BOLD_RED}WARNING: Passwords are stored in the .env file, base64 encoded. \
It is your own responsibility to ensure the safety of this file.${RESET}"

APIPROXY_CFG="api-tools-cfg/apiproxyprefix.cfg"
if [ -f "api-tools-cfg/apiproxyprefix.cfg" ]; then
	echo "Loading config: $APIPROXY_CFG"
  set -a
	. $APIPROXY_CFG
  set +a
else
	echo "Config not found: $APIPROXY_CFG"
fi

export GRADLE_OPTS=-Djavax.net.ssl.trustStore=$gitLocal/sboot-tools/certs/cacerts.jks

#Run the env file to export all the vars.
set -a
. $gwd/.env
set +a

### Setup the virtual env (pipenv)
. $gwd/sboot-tools/local/check_virtenv.sh
if [ -f $gwd/services/dev.env ]; then
  echo "Loading dev.env environment variables..."
  set -a
  . $gwd/services/dev.env
  set +a
fi
