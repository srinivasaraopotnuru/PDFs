'Create the ECDSA key pair
ssh-keygen -t ecdsa -b 521 -m pem -f ./id_ecdsa
'Create a PEM version of the public key
openssl ec -in id_ecdsa -pubout -out id_ecdsa_pub.pem
