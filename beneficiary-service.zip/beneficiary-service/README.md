# Savings App Beneficiary Service
This service is for retrieving beneficiary (also known as transfer account) information for YBS customers.

## Overview
This repository contains a template for spring boot java service projects.
* Gradle version configured to 6.5
* Uses https://github.com/vivin/gradle-semantic-build-versioning to manage version numbers based on git tags
* Builds SNAPSHOT artifacts when building locally and when CI builds from 'feature/XXX' branch
* Builds release artifacts with minor version incremented when CI builds from 'master' branch
* Builds release artifacts with patch version incremented when CI builds from 'hotfix/XXX' branch
* Builds release artifacts CI builds from a version tag (e.g. '1.5.0')
* Version number added to the actuator build-info so that it is available on the /actuator/info endpoint

## CI Requirements
* The developer will need to create their own Artifatory API Key for local builds (see https://www.jfrog.com/confluence/display/JFROG/User+Profile#UserProfile-APIKey)
* The developer will need to set the following in the $HOME/.gradle/gradle.properties:
   * artifactory_username=[Your uXXXXXX username]
   * artifactory_password=[Your API Key]
   * artifactory_contextUrl=https://artifactory.ybs.com/artifactory
* The following are redundant and should bre removed from $HOME/.gradle/gradle.properties if they exist: ybsMavenRepositoryUrl, ybsMavenRepositoryPublishUrl, ybsMavenCredentialsHeaderName, ybsMavenCredentialsHeaderValue

* GitlabCI environment variables GITLAB_USERNAME,GITLAB_PASSWORD,GITLAB_EMAIL required to commit/push git tags
* GitlabCI environment variable SSH_PRIVATE_KEY required for commit/push to digital-infrastructure project

## Directory Structure

Below is an overview of the structure of the project:

```
.
├── README.md                           # This file
├── .gitignore                          # Ignores build output and some IDE specific files
│
├── gradlew                             # *nix Gradle wrapper
├── gradlew.bat                         # Windows Gradle wrapper
├── gradle
│   └── wrapper                         # gradle-wrapper.jar and configuration
│
├── build.gradle                        # Root build script
├── settings.gradle                     # Gradle project settings - applies the version number plugin
├── semantic-build-versioning.gradle    # Configuration for the version number plugin
│
├── .gitlab-ci                          # CI pipeline configuration
├── .gradle-ci                          # GRADLE_HOME for CI pipeline builds
│   └── gradle.properties               # gradle.properties used by CI.  Includes proxy and maven repository config
│
├── src
│   └── main                            
│       └── java                        # Placeholder java classes
├── Dockerfile                          # For building docker image
│
├── account-service.yml                 # Service definition to use in digital-infrastructure
│
├── Pipfile                             # For setting up pipenv to run smoke tests
├── Pipfile.lock                        # Lock file for reproducibility
├── smoke-tests                         # Directory for all smoke tests
│   └── README.md                       # Instructions for setting up / running smoke tests
│   └── test_example.py                 # Placeholder smoke test
     
```

## Building
Gradle is used to build all artifacts. There are Gradle wrapper scripts in the root of the
repository for convenience. `./gradlew` for \*nix systems and `gradlew.bat` for
windows systems.

In the follow examples replace `./gradlew` with `gradlew.bat` when running in
Windows CMD.

#### Building the service (includes running the unit / integration tests):
```
./gradlew build
```

#### Deployment

CI will:
* build and deploy the release versions of the service jar to the maven repository
* build and push the docker image tagged with the version number and 'latest'
* tag the git revision with the version number

#### Major release

Where a feature branch it to be merged to master and requires a major version bump, use the follwing process:
```
Pull the latest from git, checkout master then manually merge the feature branch
git checkout master
git pull
git merge --no-ff feature/XXX

Push the changes but instruct CI to skip the build
git push --push-option=ci.skip

Tag with the new major version, then push the tag
git tag 3.0.0
git push origin 3.0.0
```

## GitLab pipeline
The pipeline inherits from a shared pipeline.
See the [README](https://ecommgit.ybs.com/ybs/enterprise/digital/shared-pipeline-library#services-pipeline) for more information

## Setting up IntelliJ

Note that these instructions won't work properly until the service is changed to build using
Java 11. This is due to the latest version of the formatter not supporting Java 8, so the build
runs an older version, whilst the plugin runs the latest version in the IDE Java 11 runtime which 
results in slightly different output. For now the formatter must be invoked via Gradle:
`./gradlew spotlessJavaApply`

1. Install the [google-java-format](https://plugins.jetbrains.com/plugin/8527-google-java-format) plugin.
2. Add intellij format file for import order:
    1. Go to `Preferences/Settings > Editor > Code Style > Java`
    2. Click the cog next to the Scheme drop down
    3. Go to `Import Scheme > Intellij IDEA code style XML`
    4. Import `assurance/intellij-java-google-style.xml`


## Setting up Git

### Check for formatting before commit

create the file `.git/hooks/pre-commit` with the contents:

```
#!/bin/sh

# Stash instaged changes so they trigger a potential failure
git stash --keep-index > /dev/null

./gradlew spotlessJavaCheck > /dev/null
result=$?

if [ $result -ne 0 ]; then
	echo Commit failed: staged code is not formatted correctly. Please run ./gradlew spotlessJavaApply and stage the changes before commiting
fi

# Reapply stashed changes
git stash pop > /dev/null

exit $result
```

and make sure it's executable bit is set for your user:

```
chmod u+x .git/hooks/pre-commit
```

### Ignore large formatting changes in git blame
git config blame.ignoreRevsFile .git-blame-ignore-revs
