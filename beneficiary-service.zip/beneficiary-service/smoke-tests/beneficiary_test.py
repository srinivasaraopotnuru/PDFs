import json

import config
import ecdsa
import expected_json_schema
import hashlib
import jsonschema
import os
import uuid
from base64 import b64encode
from jwt import (
    JWT,
    jwk_from_pem,
)
from signer import Signer
from time import time

import requests

host = os.getenv('SERVICE_HOST', default='localhost:8080')
protocol = os.getenv('SERVICE_PROTOCOL', default='http://')
target_env = os.getenv('SMOKE_TARGET_ENV', default='test')

jwt_alg = 'RS256'
base_path = '/beneficiary'
accounts_path_public = '/accounts'
accounts_path_private = '/private/accounts'
host_presented = host
x_request_id = str(uuid.uuid4())
request_signing_key_id_public = 'apigee-nonprod-1'
request_signing_key_id_private = 'payment-service-nonprod-1'
sca_signing_key_id = 'sca_key'
jwt_scope_public = 'BENEFICIARY'
jwt_scope_public_beneficiary_limit = 'BENEFICIARY ACCOUNT_READ'
jwt_scope_private = 'ACCOUNT_READ BENEFICIARY'

if target_env == 'dev' or target_env == 'test':
    customer_number = '12462951'
    account_number = '2372146519'
    beneficiary_id = '16afcb7e247c0c22c3565fa54205585ae3d59ae8645646aa7d3b17657274edd4' # FRAZER beneficiary
    update_external_beneficiary_request = {
        'type': 'EXTERNAL',
        'beneficiaryId': '16afcb7e247c0c22c3565fa54205585ae3d59ae8645646aa7d3b17657274edd4',
        'accountSortCode': '300045',
        'name': 'FRAZER',
        'accountNumber': '12345678',
        'reference': '0',
        'memorableName': 'New Memorable Name'
    }
elif target_env == 'flex':
    customer_number = '12462951'
    account_number = '2372146519'
    beneficiary_id = 'b61069e2d3bfa4b9a3bd2b7df419be2d7dbc447382f5fdecd1fc8a64ed93c455' # HIRST beneficiary
    update_external_beneficiary_request = {
        'type': 'EXTERNAL',
        'beneficiaryId': '10380a22f8f4b97bc446589be0b373ceab6ff85b1978d87db0e9b445c5ece4d9',
        'accountSortCode': '300045',
        'name': 'FRAZER',
        'accountNumber': '12345678',
        'reference': '0',
        'memorableName': 'New Memorable Name'
    }
else:
    raise Exception('Unexpected SMOKE_TARGET_ENV: {}'.format(target_env))

signer = Signer({
    request_signing_key_id_public: ecdsa.SigningKey.from_pem(config.request_signature_private_key_public, hashlib.sha256),
    request_signing_key_id_private: ecdsa.SigningKey.from_pem(config.request_signature_private_key_private, hashlib.sha256),
    sca_signing_key_id: ecdsa.SigningKey.from_pem(config.sca_private_key, hashlib.sha256)
})


def test_get_account_beneficiaries_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt(jwt_scope_public))
    response = make_request('get', f'{accounts_path_public}/{account_number}/beneficiaries',
                            authorization=authorization, key_id=request_signing_key_id_public)
    assert response.status_code == 200
    response_body = response.json()
    jsonschema.validate(response_body, expected_json_schema.expected_account_beneficiaries_schema)

    assert len(list(filter(lambda item: item['beneficiaryId'] == beneficiary_id, response_body))) == 1


def test_private_get_account_beneficiary_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt(jwt_scope_private))
    response = make_request('get', f'{accounts_path_private}/{account_number}/beneficiaries/{beneficiary_id}',
                            authorization=authorization, key_id=request_signing_key_id_private)
    assert response.status_code == 200

    response_body = response.json()
    jsonschema.validate(response_body, expected_json_schema.expected_account_beneficiary_schema)


def test_get_account_beneficiaries_should_return_bad_request_if_account_number_is_invalid():
    authorization = create_authorization(create_jwt(jwt_scope_public))
    response = make_request('get', f'{accounts_path_public}/foobar/beneficiaries', authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert response.status_code == 400, f'unexpected http status: [{response.status_code}]: {response.text}'

    assert response.json() == {
        'id': x_request_id,
        'code': '400 Bad Request',
        'message': 'Invalid value',
        'errors': [
            {
                'errorCode': 'Field.Invalid',
                'message': 'foobar is not a valid account number; value must be of the form 1234567890'
            }
        ]
    }


def test_get_account_beneficiaries_should_fail_without_valid_scope():
    authorization = create_authorization(create_jwt('PAYMENT'))
    response = make_request('get', f'{accounts_path_public}/{account_number}/beneficiaries',
                            authorization=authorization, key_id=request_signing_key_id_public)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied',
                'message': 'Access Denied'
            }
        ]
    }


def test_get_account_beneficiaries_should_fail_without_signature():
    authorization = create_authorization(create_jwt(jwt_scope_public))
    response = make_request('get', f'{accounts_path_public}/{account_number}/beneficiaries',
                            authorization=authorization, key_id=request_signing_key_id_public, no_sign=True)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


def test_private_create_external_beneficiary_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt(jwt_scope_private))
    json = {
        'type': 'EXTERNAL',
        'accountNumber': '87654321',
        'accountSortCode': '300045',
        'name': 'Mr Smoke',
        'memorableName': 'Smoke Test'
    }

    # This test does not actually insert a record into the DB!
    # This is to avoid the processor picking up a test request and creating a beneficiary.
    # If we allowed this the test would fail with a duplicate exception after the first successful execution
    response = make_request('post', f'{accounts_path_private}/{account_number}/beneficiaries', json=json,
                            authorization=authorization, key_id=request_signing_key_id_private)
    assert response.status_code == 202, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_private_create_internal_beneficiary_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt(jwt_scope_private))
    json = {
        'type': 'INTERNAL',
        'accountNumber': '2266109419'
    }

    # This test does not actually insert a record into the DB!
    # This is to avoid the processor picking up a test request and creating a beneficiary.
    # If we allowed this the test would fail with a duplicate exception after the first successful execution
    response = make_request('post', f'{accounts_path_private}/{account_number}/beneficiaries', json=json,
                            authorization=authorization, key_id=request_signing_key_id_private)
    assert response.status_code == 202, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_update_beneficiary_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt(jwt_scope_public))
    response = make_request('put', f'{accounts_path_public}/{account_number}/beneficiaries',
                            json=update_external_beneficiary_request, authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert response.status_code == 403

    challenge = response.headers.get("x-ybs-sca-challenge")
    challenge_response = signer.create_ecdsa_signature(sca_signing_key_id, challenge)

    # This test does not actually insert a record into the DB!
    # This is to avoid the processor picking up a test request and updating a beneficiary.
    # As this test updates a beneficiary it could be processed, however doing this for consistency with the other
    # create/delete tests.
    response = make_request('put', f'{accounts_path_public}/{account_number}/beneficiaries',
                            json=update_external_beneficiary_request, authorization=authorization,
                            key_id=request_signing_key_id_public,
                            challenge=challenge, challenge_response=challenge_response)
    assert response.status_code == 202, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_private_update_beneficiary_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt(jwt_scope_private))
    response = make_request('put', f'{accounts_path_private}/{account_number}/beneficiaries',
                            json=update_external_beneficiary_request, authorization=authorization,
                            key_id=request_signing_key_id_private)

    # This test does not actually insert a record into the DB!
    # This is to avoid the processor picking up a test request and updating a beneficiary.
    # As this test updates a beneficiary it could be processed, however doing this for consistency with the other
    # create/delete tests.
    assert response.status_code == 202, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_delete_beneficiary_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt(jwt_scope_public))
    response = make_request('delete', f'{accounts_path_public}/{account_number}/beneficiaries/{beneficiary_id}',
                            authorization=authorization, key_id=request_signing_key_id_public)
    assert response.status_code == 403

    challenge = response.headers.get("x-ybs-sca-challenge")
    challenge_response = signer.create_ecdsa_signature(sca_signing_key_id, challenge)

    # This test does not actually insert a record into the DB!
    # This is to avoid the processor picking up a test request and deleting a beneficiary.
    # If we allowed this the test would fail with a duplicate exception after the first successful execution
    response = make_request('delete', f'{accounts_path_public}/{account_number}/beneficiaries/{beneficiary_id}',
                            json=update_external_beneficiary_request, authorization=authorization,
                            key_id=request_signing_key_id_public,
                            challenge=challenge, challenge_response=challenge_response)
    assert response.status_code == 202, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_challenge_failure_audit():
    authorization = create_authorization(create_jwt(jwt_scope_public))
    response = make_request('delete', f'{accounts_path_public}/{account_number}/beneficiaries/{beneficiary_id}',
                            authorization=authorization, key_id=request_signing_key_id_public)
    assert response.status_code == 403

    challenge = response.headers.get("x-ybs-sca-challenge")

    response = make_request('post', '/failure',
                            json={'challenge': challenge},
                            authorization=authorization,
                            key_id=request_signing_key_id_public)

    assert response.status_code == 204, f'unexpected http status: [{response.status_code}]: {response.text}'


def create_authorization(bearer_token):
    return 'Bearer ' + bearer_token


def make_request(method, path, json=None, authorization=None, challenge=None, challenge_response=None, key_id=None,
                 no_sign=False):
    url = protocol + host + base_path + path

    headers = {
        'x-ybs-request-id': x_request_id,
        'Host': host_presented,
    }

    def add_header_if_not_none(header, value):
        if value is not None:
            headers[header] = value

    add_header_if_not_none('Authorization', authorization)
    add_header_if_not_none('x-ybs-request-signature-key-id', key_id)
    add_header_if_not_none('x-ybs-sca-challenge', challenge)
    add_header_if_not_none('x-ybs-sca-challenge-response', challenge_response)
    if challenge_response or challenge:
        headers['x-ybs-sca-key'] = b64encode(config.sca_public_key.encode("utf-8")).decode()

    request = requests.Request(method, url, headers, json=json).prepare()

    if not no_sign:
        signer.sign_request(request)
    return requests.session().send(request, verify=False)


def create_jwt(scope):
    signing_key = jwk_from_pem(config.jwt_private_key.encode())
    jwt = JWT()

    headers = {
        'kid': 'OPAa9voYNByjE_lpbtHanOFKiV4',
        'alg': jwt_alg
    }

    message = {
        'jti': str(uuid.uuid4()),
        'sub': customer_number,
        'iat': time(),
        'sid': str(uuid.uuid4()),
        'aud': 'DIGITAL_API',
        'sub_type': 'customer',
        'brand_code': 'YBS',
        'scope': scope,
        'channel': 'SAPP',
        'registration_id': str(uuid.uuid4()),
        'verification_method': 'BIOMETRIC',
        'party_id': customer_number

    }
    return jwt.encode(message, signing_key, jwt_alg, headers)


def test_get_beneficiaries_limit_flag_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt(jwt_scope_public_beneficiary_limit))
    response = make_request('get', f'{accounts_path_public}/{account_number}/beneficiary-limits',
                            authorization=authorization, key_id=request_signing_key_id_public)
    assert response.status_code == 200
    response_body = response.json()
    jsonschema.validate(response_body, expected_json_schema.expected_account_beneficiary_limit_response_schema)


def test_get_account_beneficiaries_limit_flag_should_return_bad_request_if_account_number_is_invalid():
    authorization = create_authorization(create_jwt(jwt_scope_public_beneficiary_limit))
    response = make_request('get', f'{accounts_path_public}/foobar/beneficiary-limits', authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert response.status_code == 400, f'unexpected http status: [{response.status_code}]: {response.text}'

    assert response.json() == {
        'id': x_request_id,
        'code': '400 Bad Request',
        'message': 'Invalid value',
        'errors': [
            {
                'errorCode': 'Field.Invalid',
                'message': 'foobar is not a valid account number; value must be of the form 1234567890'
            }
        ]
    }


def test_get_account_beneficiaries_limit_flag_should_fail_without_valid_scope():
    authorization = create_authorization(create_jwt('PAYMENT'))
    response = make_request('get', f'{accounts_path_public}/{account_number}/beneficiary-limits',
                            authorization=authorization, key_id=request_signing_key_id_public)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied',
                'message': 'Access Denied'
            }
        ]
    }


def test_get_account_beneficiaries_limit_flag_should_fail_without_signature():
    authorization = create_authorization(create_jwt(jwt_scope_public_beneficiary_limit))
    response = make_request('get', f'{accounts_path_public}/{account_number}/beneficiary-limits',
                            authorization=authorization, key_id=request_signing_key_id_public, no_sign=True)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }
