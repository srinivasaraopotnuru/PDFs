expected_account_beneficiary_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "object",
    "required": ["accountNumber", "beneficiaryId", "type"],
    "properties": {
        "accountNumber": {"type": "string"},
        "accountSortCode": {"type": "string"},
        "beneficiaryId": {"type": "string"},
        "name": {"type": "string"},
        "reference": {"type": "string"},
        "type": {"type": "string"}
    }
}

expected_account_beneficiaries_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "array",
    "items": expected_account_beneficiary_schema
}

expected_account_beneficiaries_limit_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "object",
    "required": ["count", "maxPermitted","limitReached"],
    "properties": {
        "count": {"type": "integer"},
        "maxPermitted":{"type":"integer"},
        "limitReached": {"type": "boolean"}
    }
}

expected_account_beneficiary_limit_response_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "object",
    "required": ["internal", "external"],
    "properties": {
        "internal":expected_account_beneficiaries_limit_schema,
        "external":expected_account_beneficiaries_limit_schema
    }
}
