package uk.co.ybs.digital.beneficiary.service.product.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.Optional;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = ProductInfo.ProductInfoBuilder.class)
public class ProductInfo {

  private final String productIdentifier;
  private final String customerDescription;
  private final String productType;
  private final Balance balance;
  private final Deposits deposits;
  private final Withdrawals withdrawals;
  private final BigDecimal maximumMonthlyPayment;
  private final Isa isa;
  private final Beneficiaries beneficiaries;

  @JsonIgnore
  public Optional<Integer> getAnniversaryWithdrawalLimit() {
    return Optional.ofNullable(withdrawals)
        .map(Withdrawals::getLimits)
        .map(Withdrawals.Limits::getNumber)
        .map(NumberPeriodLimits::getAnniversaryYear);
  }

  public boolean hasAnniversaryWithdrawalLimit() {
    return getAnniversaryWithdrawalLimit().isPresent();
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Balance.BalanceBuilder.class)
  @Schema(name = "ProductBalance")
  public static class Balance {
    private BigDecimal min;
    private BigDecimal max;

    @JsonPOJOBuilder(withPrefix = "")
    public static class BalanceBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Withdrawals.WithdrawalsBuilder.class)
  public static class Withdrawals {
    private InterestPenalty interestPenalty;
    private boolean permittedOverWeb;
    private Limits limits;

    @Value
    @Builder
    @JsonDeserialize(builder = Limits.LimitsBuilder.class)
    public static class Limits {
      private NumberPeriodLimits number;

      @JsonPOJOBuilder(withPrefix = "")
      public static class LimitsBuilder {}
    }

    @Value
    @Builder
    @JsonDeserialize(builder = InterestPenalty.InterestPenaltyBuilder.class)
    public static class InterestPenalty {
      private Integer code;
      private Integer days;
      private BigDecimal balanceUpperBound;

      @JsonPOJOBuilder(withPrefix = "")
      public static class InterestPenaltyBuilder {}
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static class WithdrawalsBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Deposits.DepositsBuilder.class)
  public static class Deposits {
    private boolean permittedInternal;
    private Limits limits;

    @Value
    @Builder
    @JsonDeserialize(builder = Limits.LimitsBuilder.class)
    public static class Limits {
      private AmountPeriodLimits amount;

      @JsonPOJOBuilder(withPrefix = "")
      public static class LimitsBuilder {}
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static class DepositsBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = AmountPeriodLimits.AmountPeriodLimitsBuilder.class)
  public static class AmountPeriodLimits {
    private BigDecimal month;
    private BigDecimal year;
    private BigDecimal anniversaryYear;
    private BigDecimal taxYear;
    private BigDecimal productTerm;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AmountPeriodLimitsBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = NumberPeriodLimits.NumberPeriodLimitsBuilder.class)
  public static class NumberPeriodLimits {
    private Integer month;
    private Integer year;
    private Integer anniversaryYear;
    private Integer taxYear;
    private Integer productTerm;

    @JsonPOJOBuilder(withPrefix = "")
    public static class NumberPeriodLimitsBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Isa.IsaBuilder.class)
  public static class Isa {
    private Boolean flexible;
    private Boolean helpToBuy;
    private Integer isaYear;

    @JsonPOJOBuilder(withPrefix = "")
    public static class IsaBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Beneficiaries.BeneficiariesBuilder.class)
  public static class Beneficiaries {
    private Integer external;
    private Integer internal;

    @JsonPOJOBuilder(withPrefix = "")
    public static class BeneficiariesBuilder {}
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ProductInfoBuilder {}
}
