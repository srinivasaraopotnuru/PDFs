package uk.co.ybs.digital.beneficiary.service.utilities;

import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.PENDING;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.UnsupportedBeneficiaryFieldUpdateException;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.ExternalUpdateBeneficiaryInformationWrapper;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.product.dto.ProductInfo;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@Component
@RequiredArgsConstructor
@Slf4j
public class SoaBeneficiaryValidator {

  private static final List<String> SUPPORTED_EXTERNAL_BENEFICIARY_UPDATE_FIELDS =
      Arrays.asList("reference", "memorableName");

  private final ProductBeneficiaryLimitValidator productBeneficiaryLimitValidator;
  private final BeneficiaryInformationFactory beneficiaryInformationFactory;
  private final BeneficiaryUtils beneficiaryUtils;
  private final BeneficiaryAuditor beneficiaryAuditor;

  public int validateExternalCreate(
      final String accountNumber,
      final List<Beneficiary> beneficiaries,
      final ProductInfo productInfo,
      final ExternalBeneficiary request,
      final RequestMetadata metadata) {
    final List<ExternalBeneficiary> externalBeneficiaries =
        filterBeneficiaries(beneficiaries, ExternalBeneficiary.class);
    try {
      final int limit =
          productBeneficiaryLimitValidator.validateExternalBeneficiaryLimit(
              accountNumber, externalBeneficiaries.size(), productInfo);

      validateExternalForDuplicates(accountNumber, externalBeneficiaries, request);

      return limit;
    } catch (final BeneficiaryValidationException e) {
      final ExternalBeneficiaryInformation externalBeneficiaryInformation =
          beneficiaryInformationFactory.buildExternal(Long.parseLong(accountNumber), request);
      beneficiaryAuditor.auditBeneficiaryCreateFailure(
          externalBeneficiaryInformation, e.getReason().getDescription(), metadata);
      throw e;
    }
  }

  public ExternalBeneficiary validateExternalUpdate(
      final String accountNumber,
      final List<Beneficiary> beneficiaries,
      final ExternalBeneficiary request,
      final RequestMetadata metadata) {
    final List<ExternalBeneficiary> externalBeneficiaries =
        filterBeneficiaries(beneficiaries, ExternalBeneficiary.class);

    final String beneficiaryId = request.getBeneficiaryId();
    final List<ExternalBeneficiary> externalBeneficiariesExcludingRequested =
        externalBeneficiaries.stream()
            .filter(beneficiary -> !beneficiary.getBeneficiaryId().equals(beneficiaryId))
            .collect(Collectors.toList());

    final ExternalBeneficiary existingBeneficiary =
        findExistingBeneficiary(request, externalBeneficiaries);
    try {
      validateExternalUpdate(request, existingBeneficiary);
      validateExternalForDuplicates(
          accountNumber, externalBeneficiariesExcludingRequested, request);
      validatePending(accountNumber, existingBeneficiary);
    } catch (final UnsupportedBeneficiaryFieldUpdateException e) {
      final ExternalUpdateBeneficiaryInformationWrapper updateWrapper =
          beneficiaryInformationFactory.buildExternalUpdate(
              Long.parseLong(accountNumber), request, existingBeneficiary);
      beneficiaryAuditor.auditBeneficiaryUpdateFailure(
          updateWrapper, "Unsupported Field Update", metadata);
      throw e;
    } catch (final BeneficiaryValidationException e) {
      final ExternalUpdateBeneficiaryInformationWrapper updateWrapper =
          beneficiaryInformationFactory.buildExternalUpdate(
              Long.parseLong(accountNumber), request, existingBeneficiary);
      beneficiaryAuditor.auditBeneficiaryUpdateFailure(
          updateWrapper, e.getReason().getDescription(), metadata);
      throw e;
    }

    return existingBeneficiary;
  }

  public int validateInternalCreate(
      final String accountNumber,
      final List<Beneficiary> beneficiaries,
      final ProductInfo productInfo,
      final InternalBeneficiary request,
      final RequestMetadata metadata) {
    final List<InternalBeneficiary> internalBeneficiaries =
        filterBeneficiaries(beneficiaries, InternalBeneficiary.class);

    try {
      final int limit =
          productBeneficiaryLimitValidator.validateInternalBeneficiaryLimit(
              accountNumber, internalBeneficiaries.size(), productInfo);

      if (internalBeneficiaries.stream()
          .anyMatch(
              beneficiary -> beneficiary.getAccountNumber().equals(request.getAccountNumber()))) {
        log.info(
            "Requested internal beneficiary for account {} already exists: " + "accountNumber: {}",
            accountNumber,
            request.getAccountNumber());
        throw new BeneficiaryValidationException(
            String.format("Requested beneficiary already exists for account: %s", accountNumber),
            DUPLICATE);
      }

      return limit;
    } catch (final BeneficiaryValidationException e) {
      final InternalBeneficiaryInformation internalBeneficiaryInformation =
          beneficiaryInformationFactory.buildInternal(Long.parseLong(accountNumber), request);
      beneficiaryAuditor.auditBeneficiaryCreateFailure(
          internalBeneficiaryInformation, e.getReason().getDescription(), metadata);
      throw e;
    }
  }

  public Beneficiary validateDelete(
      final List<Beneficiary> beneficiaries,
      final String requestBeneficiaryId,
      final String accountNumber,
      final RequestMetadata metadata) {
    final Beneficiary beneficiary =
        beneficiaries.stream()
            .filter(candidate -> candidate.getBeneficiaryId().equals(requestBeneficiaryId))
            .findFirst()
            .orElseThrow(
                (Supplier<AccountResourceNotFoundException>)
                    () -> {
                      log.error(
                          "Beneficiary {} for account {} not found in list {}",
                          requestBeneficiaryId,
                          accountNumber,
                          beneficiaries);
                      throw new AccountResourceNotFoundException(
                          String.format("Beneficiary %s not found", requestBeneficiaryId));
                    });

    try {
      validatePending(accountNumber, beneficiary);
    } catch (final BeneficiaryValidationException e) {
      if (beneficiary instanceof ExternalBeneficiary) {
        final ExternalBeneficiaryInformation externalBeneficiaryInformation =
            beneficiaryInformationFactory.buildExternal(
                Long.parseLong(accountNumber), (ExternalBeneficiary) beneficiary);
        beneficiaryAuditor.auditBeneficiaryDeleteFailure(
            externalBeneficiaryInformation, e.getReason().getDescription(), metadata);
      } else {
        final InternalBeneficiaryInformation internalBeneficiaryInformation =
            beneficiaryInformationFactory.buildInternal(
                Long.parseLong(accountNumber), (InternalBeneficiary) beneficiary);
        beneficiaryAuditor.auditBeneficiaryDeleteFailure(
            internalBeneficiaryInformation, e.getReason().getDescription(), metadata);
      }
      throw e;
    }

    return beneficiary;
  }

  private ExternalBeneficiary findExistingBeneficiary(
      final ExternalBeneficiary request, final List<ExternalBeneficiary> beneficiaries) {
    final String requestBeneficiaryId = request.getBeneficiaryId();
    return beneficiaries.stream()
        .filter(candidate -> candidate.getBeneficiaryId().equals(requestBeneficiaryId))
        .findFirst()
        .orElseThrow(
            (Supplier<AccountResourceNotFoundException>)
                () -> {
                  log.error("Beneficiary {} not found in list {}", request, beneficiaries);
                  throw new AccountResourceNotFoundException(
                      String.format("Beneficiary %s not found", requestBeneficiaryId));
                });
  }

  private void validateExternalUpdate(
      final ExternalBeneficiary request, final ExternalBeneficiary existingBeneficiary) {
    final List<String> unsupportedFields = new ArrayList<>();
    if (!request.getAccountNumber().equals(existingBeneficiary.getAccountNumber())) {
      unsupportedFields.add("accountNumber");
    }
    if (!request.getAccountSortCode().equals(existingBeneficiary.getAccountSortCode())) {
      unsupportedFields.add("accountSortCode");
    }
    if (!request.getName().equals(existingBeneficiary.getName())) {
      unsupportedFields.add("name");
    }

    if (!unsupportedFields.isEmpty()) {
      throw new UnsupportedBeneficiaryFieldUpdateException(
          String.format("Unsupported fields: %s", unsupportedFields),
          unsupportedFields,
          SUPPORTED_EXTERNAL_BENEFICIARY_UPDATE_FIELDS);
    }
  }

  private void validateExternalForDuplicates(
      final String accountNumber,
      final List<ExternalBeneficiary> externalBeneficiaries,
      final ExternalBeneficiary request) {
    if (externalBeneficiaries.stream()
        .anyMatch(
            beneficiary ->
                beneficiary.getAccountNumber().equals(request.getAccountNumber())
                    && beneficiary.getAccountSortCode().equals(request.getAccountSortCode())
                    && beneficiaryUtils.compareReferences(
                        request.getReference(), beneficiary.getReference()))) {
      log.info(
          "Requested external beneficiary for account {} already exists: "
              + "accountNumber: {}, "
              + "accountSortCode: {}, "
              + "name: {}, "
              + "reference: {}, "
              + "memorableName: {}",
          accountNumber,
          request.getAccountNumber(),
          request.getAccountSortCode(),
          request.getName(),
          request.getReference(),
          request.getMemorableName());
      throw new BeneficiaryValidationException(
          String.format("Requested beneficiary already exists for account: %s", accountNumber),
          DUPLICATE);
    }
  }

  private void validatePending(final String accountNumber, final Beneficiary beneficiary) {
    if (beneficiary.isPending()) {
      final String beneficiaryId = beneficiary.getBeneficiaryId();
      log.info("Beneficiary {} for account {} is in a pending state", beneficiaryId, accountNumber);
      throw new BeneficiaryValidationException(
          String.format("Beneficiary %s is in a pending state", beneficiaryId), PENDING);
    }
  }

  @SuppressWarnings("unchecked")
  private <T extends Beneficiary> List<T> filterBeneficiaries(
      final List<Beneficiary> beneficiaries, final Class<? extends T> type) {
    return beneficiaries.stream()
        .filter(type::isInstance)
        .map(beneficiary -> (T) beneficiary)
        .collect(Collectors.toList());
  }
}
