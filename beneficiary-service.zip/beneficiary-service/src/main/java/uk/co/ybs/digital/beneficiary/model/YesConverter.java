package uk.co.ybs.digital.beneficiary.model;

import javax.persistence.AttributeConverter;

public class YesConverter implements AttributeConverter<Boolean, String> {
  @Override
  public String convertToDatabaseColumn(final Boolean bool) {
    return bool ? "Y" : "N";
  }

  @Override
  public Boolean convertToEntityAttribute(final String string) {
    return "Y".equalsIgnoreCase(string);
  }
}
