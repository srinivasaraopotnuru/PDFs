package uk.co.ybs.digital.beneficiary.service.processor;

import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.repository.core.BillPaymentInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.ExternalUpdateBeneficiaryInformationWrapper;
import uk.co.ybs.digital.beneficiary.service.mapper.ExternalBeneficiaryDatabaseEntityMapper;
import uk.co.ybs.digital.beneficiary.service.utilities.BeneficiaryUtils;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;

@Slf4j
@RequiredArgsConstructor
@Component
@Transactional("beneficiaryProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public class UpdateExternalBeneficiaryProcessor
    implements ExistingBeneficiaryProcessor<ExternalBeneficiary, BillPaymentInstruction> {

  private final BillPaymentInstructionCoreRepository billPaymentInstructionCoreRepository;
  private final ExternalBeneficiaryDatabaseEntityMapper externalBeneficiaryDatabaseEntityMapper;
  private final BeneficiaryInformationFactory beneficiaryInformationFactory;
  private final BeneficiaryAuditor beneficiaryAuditor;
  private final BeneficiaryUtils beneficiaryUtils;

  @Override
  public BillPaymentInstruction resolve(
      final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments) {
    final long sysId = arguments.getSysId();
    return billPaymentInstructionCoreRepository
        .findById(sysId)
        .orElseThrow(
            () ->
                new IllegalArgumentException(
                    String.format("BillPaymentInstruction %s not found", sysId)));
  }

  @Override
  public void execute(
      final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments,
      final BillPaymentInstruction instruction) {
    final long accountNumber = arguments.getAccountNumber();
    final ExternalBeneficiary beneficiary = arguments.getBeneficiary();
    final LocalDateTime processTime = arguments.getProcessTime();

    if (instruction.getEndDate() != null) {
      throw new BeneficiaryValidationException(
          "Beneficiary ended", BeneficiaryValidationExceptionReason.DELETED);
    }

    final String existingMemorableNameTrimmed = trim(instruction.getMemorableName());
    final String requestMemorableNameTrimmed = trim(beneficiary.getMemorableName());
    final String existingReferenceTrimmed = trim(instruction.getReference());
    final String requestReferenceTrimmed = trim(beneficiary.getReference());

    if (Objects.equals(existingMemorableNameTrimmed, requestMemorableNameTrimmed)
        && Objects.equals(existingReferenceTrimmed, requestReferenceTrimmed)) {
      throw new BeneficiaryValidationException(
          "Update already applied", BeneficiaryValidationExceptionReason.UPDATE_ALREADY_APPLIED);
    }

    ensureMatchingRecordDoesNotAlreadyExist(accountNumber, beneficiary, instruction, processTime);

    final BillPaymentInstruction newInstruction =
        instruction
            .toBuilder()
            .reference(requestReferenceTrimmed)
            .memorableName(requestMemorableNameTrimmed)
            .sysId(null)
            .status(BeneficiaryProcessorConstants.INSTRUCTION_STATUS_ACTIVE)
            .availableAtm(true)
            .fpTrustStatus(true)
            .fpChangeReason(BeneficiaryProcessorConstants.INSTRUCTION_FP_CHANGE_REASON)
            .createdAt(BeneficiaryProcessorConstants.AUDIT_AT)
            .createdBy(BeneficiaryProcessorConstants.AUDIT_BY)
            .createdDate(processTime)
            .build();

    final BillPaymentInstruction oldInstruction =
        instruction
            .toBuilder()
            .endDate(processTime)
            .endedAt(BeneficiaryProcessorConstants.AUDIT_AT)
            .endedBy(BeneficiaryProcessorConstants.AUDIT_BY)
            .endedDate(processTime)
            .status(BeneficiaryProcessorConstants.INSTRUCTION_STATUS_CANCELLED)
            .atmOrderNumber(null)
            .build();

    billPaymentInstructionCoreRepository.saveAll(Arrays.asList(newInstruction, oldInstruction));
    billPaymentInstructionCoreRepository.flush();
    billPaymentInstructionCoreRepository.updateExternalBeneficiaryAuthenticRecord(accountNumber);
  }

  @Override
  public void auditSuccess(
      final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments,
      final BillPaymentInstruction instruction) {
    final ExternalBeneficiary databaseBeneficiary =
        externalBeneficiaryDatabaseEntityMapper.map(instruction);
    final ExternalUpdateBeneficiaryInformationWrapper beneficiaryInformationWrapper =
        beneficiaryInformationFactory.buildExternalUpdate(
            arguments.getAccountNumber(), arguments.getBeneficiary(), databaseBeneficiary);
    beneficiaryAuditor.auditBeneficiaryUpdateSuccess(
        beneficiaryInformationWrapper, arguments.getRequestMetadata());
  }

  @Override
  public void auditFailure(
      final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments,
      final BillPaymentInstruction instruction,
      final BeneficiaryValidationExceptionReason reason) {
    final ExternalBeneficiary databaseBeneficiary =
        externalBeneficiaryDatabaseEntityMapper.map(instruction);
    final ExternalUpdateBeneficiaryInformationWrapper beneficiaryInformationWrapper =
        beneficiaryInformationFactory.buildExternalUpdate(
            arguments.getAccountNumber(), arguments.getBeneficiary(), databaseBeneficiary);
    beneficiaryAuditor.auditBeneficiaryUpdateFailure(
        beneficiaryInformationWrapper, reason.getDescription(), arguments.getRequestMetadata());
  }

  private String trim(final String value) {
    return Optional.ofNullable(value).map(String::trim).orElse(null);
  }

  private void ensureMatchingRecordDoesNotAlreadyExist(
      final long accountNumber,
      final ExternalBeneficiary request,
      final BillPaymentInstruction instruction,
      final LocalDateTime processTime) {
    final List<BillPaymentInstruction> returnedBeneficiaries =
        billPaymentInstructionCoreRepository.findExistingExternalBeneficiaries(
            accountNumber,
            Long.parseLong(request.getAccountSortCode()),
            Long.parseLong(request.getAccountNumber()),
            instruction.getSysId(),
            processTime);
    final long existingRecordsCount =
        returnedBeneficiaries.stream()
            .filter(
                beneficiary ->
                    beneficiaryUtils.compareReferences(
                        beneficiary.getReference(), request.getReference()))
            .count();

    if (existingRecordsCount > 0) {
      log.info(
          "Requested external beneficiary for account {} already exists: "
              + "accountNumber: {}, "
              + "accountSortCode: {}, "
              + "name: {}, "
              + "reference: {}, "
              + "memorableName: {}",
          accountNumber,
          request.getAccountNumber(),
          request.getAccountSortCode(),
          request.getName(),
          request.getReference(),
          request.getMemorableName());
      throw new BeneficiaryValidationException(
          String.format("Requested beneficiary already exists for account: %d", accountNumber),
          DUPLICATE);
    }
  }
}
