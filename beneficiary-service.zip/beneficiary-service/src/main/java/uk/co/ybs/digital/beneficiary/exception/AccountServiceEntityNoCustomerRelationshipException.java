package uk.co.ybs.digital.beneficiary.exception;

public class AccountServiceEntityNoCustomerRelationshipException
    extends AccountServiceEntityAccessDeniedException {

  private static final long serialVersionUID = 1L;

  public AccountServiceEntityNoCustomerRelationshipException(final String message) {
    super(message);
  }
}
