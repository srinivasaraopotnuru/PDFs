package uk.co.ybs.digital.beneficiary.exception;

public class AccountServiceEntityAccessDeniedException extends AccountServiceException {

  private static final long serialVersionUID = 1L;

  public AccountServiceEntityAccessDeniedException(final String message) {
    super(message);
  }
}
