package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(
    builder = AuditBeneficiaryFailureRequest.AuditBeneficiaryFailureRequestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditBeneficiaryFailureRequest {

  @NonNull String ipAddress;

  @NonNull String message;

  @NonNull BeneficiaryInformation beneficiaryInformation;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditBeneficiaryFailureRequestBuilder {}
}
