package uk.co.ybs.digital.beneficiary.repository.digitalbeneficiary;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;

public interface WorkLogRepository extends JpaRepository<WorkLog, Long> {

  @Query("SELECT wl FROM WorkLog wl WHERE wl.status = :status " + "ORDER BY wl.createdDate")
  List<WorkLog> findRequestsInState(@Param("status") WorkLog.Status status);

  @Query(
      "SELECT new org.apache.commons.lang3.tuple.ImmutablePair(wl.status, COUNT(wl.sysId)) "
          + "FROM WorkLog wl "
          + "GROUP BY wl.status")
  List<ImmutablePair<WorkLog.Status, Long>> findCountOfRequestsInState();

  @Query(
      "SELECT wl "
          + "FROM WorkLog wl "
          + "WHERE wl.createdDate >= :date "
          + "AND wl.status <> 'FAILED' "
          + "AND wl.accountNumber = :accountNumber")
  Collection<WorkLog> findRequestsAfterDate(
      @Param("date") LocalDateTime date, @Param("accountNumber") Long accountNumber);
}
