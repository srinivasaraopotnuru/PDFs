package uk.co.ybs.digital.beneficiary.service.account.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = DepositLimit.DepositLimitBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class DepositLimit {
  @Schema(required = true)
  BigDecimal available;

  @JsonPOJOBuilder(withPrefix = "")
  public static class DepositLimitBuilder {}
}
