package uk.co.ybs.digital.beneficiary.model.core;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "NON_YBS_BANK_ACCOUNTS")
public class NonYbsBankAccount {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NYBAC_SYSID_SEQ")
  @SequenceGenerator(sequenceName = "NYBAC_SYSID_SEQ", allocationSize = 1, name = "NYBAC_SYSID_SEQ")
  @EqualsAndHashCode.Include
  private Long sysId;

  @ManyToOne
  @JoinColumn(name = "FINST_PARTY_SYSID", nullable = false)
  private FinancialInstitution financialInstitution;

  @Column(name = "BANK_ACC_NUM", nullable = false)
  private Long accountNumber;

  @Column(name = "NAME", nullable = false)
  private String name;

  @Column(name = "SORT_CODE")
  private Long sortCode;

  @Column(name = "BANK_NAME", nullable = false)
  private String bankName;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "CREATED_AT", nullable = false)
  private String createdAt;

  @Column(name = "CREATED_BY", nullable = false)
  private String createdBy;

  @Column(name = "CREATED_DATE", nullable = false)
  private LocalDateTime createdDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "ENDED_AT")
  private String endedAt;

  @Column(name = "ENDED_BY")
  private String endedBy;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;
}
