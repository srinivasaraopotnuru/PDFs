package uk.co.ybs.digital.beneficiary.service.account.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Product.ProductBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Product {

  @Schema(required = true, example = "EGG302A")
  String identifier;

  @Schema(required = true, example = "SAVER")
  String type;

  @Schema(required = true, example = "Monthly Regular Saver: Issue 2")
  String description;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ProductBuilder {}
}
