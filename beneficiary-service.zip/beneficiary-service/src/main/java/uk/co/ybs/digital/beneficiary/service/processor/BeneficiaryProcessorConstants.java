package uk.co.ybs.digital.beneficiary.service.processor;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
final class BeneficiaryProcessorConstants {
  static final String AUDIT_AT = "0795";
  static final String AUDIT_BY = "SAPP";
  static final String INSTRUCTION_FP_CHANGE_REASON = "OOBAD";
  static final String INSTRUCTION_STATUS_ACTIVE = "ACTIVE";
  static final String INSTRUCTION_STATUS_CANCELLED = "CANC";
}
