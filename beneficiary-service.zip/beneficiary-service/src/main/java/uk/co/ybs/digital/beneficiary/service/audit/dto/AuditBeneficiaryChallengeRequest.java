package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(
    builder = AuditBeneficiaryChallengeRequest.AuditBeneficiaryChallengeRequestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditBeneficiaryChallengeRequest {
  String ipAddress;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditBeneficiaryChallengeRequestBuilder {}
}
