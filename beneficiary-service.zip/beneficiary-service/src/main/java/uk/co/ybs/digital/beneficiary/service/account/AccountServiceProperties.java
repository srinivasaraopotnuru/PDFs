package uk.co.ybs.digital.beneficiary.service.account;

import java.net.URL;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

@ConfigurationProperties(prefix = "uk.co.ybs.digital.account")
@ConstructorBinding
@AllArgsConstructor
@Getter
public class AccountServiceProperties {
  @NonNull private URL url;
}
