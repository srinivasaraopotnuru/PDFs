package uk.co.ybs.digital.beneficiary.exception;

import lombok.Getter;
import lombok.NonNull;

@Getter
public class BeneficiaryValidationException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  private final BeneficiaryValidationExceptionReason reason;

  public BeneficiaryValidationException(
      @NonNull final String message, @NonNull final BeneficiaryValidationExceptionReason reason) {
    this(message, reason, null);
  }

  public BeneficiaryValidationException(
      @NonNull final String message,
      @NonNull final BeneficiaryValidationExceptionReason reason,
      final Throwable cause) {
    super(message, cause);
    this.reason = reason;
  }
}
