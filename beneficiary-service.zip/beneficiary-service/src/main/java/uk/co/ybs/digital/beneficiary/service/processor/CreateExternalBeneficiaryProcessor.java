package uk.co.ybs.digital.beneficiary.service.processor;

import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.LIMIT_REACHED;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.repository.core.BillPaymentInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.repository.core.FinancialInstitutionCoreRepository;
import uk.co.ybs.digital.beneficiary.repository.core.NonYbsBankAccountCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.utilities.BeneficiaryUtils;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;

@Slf4j
@RequiredArgsConstructor
@Component
@Transactional("beneficiaryProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public class CreateExternalBeneficiaryProcessor
    implements CreateBeneficiaryProcessor<ExternalBeneficiary> {

  private static final LocalDateTime TIMESTAMP = LocalDateTime.parse("1900-01-01T00:00:00");

  private static final Locale LOCALE = Locale.ROOT;
  private final BeneficiaryInformationFactory beneficiaryInformationFactory;
  private final BeneficiaryAuditor beneficiaryAuditor;
  private final FinancialInstitutionCoreRepository financialInstitutionCoreRepository;
  private final NonYbsBankAccountCoreRepository nonYbsBankAccountCoreRepository;
  private final BillPaymentInstructionCoreRepository billPaymentInstructionCoreRepository;
  private final BeneficiaryUtils beneficiaryUtils;

  @Override
  public void execute(final BeneficiaryRequestArguments<ExternalBeneficiary> arguments) {
    final long accountNumber = arguments.getAccountNumber();
    final LocalDateTime processTime = arguments.getProcessTime();
    final ExternalBeneficiary beneficiary = arguments.getBeneficiary();
    ensureMatchingRecordDoesNotAlreadyExist(accountNumber, beneficiary, processTime);
    validateProductLimit(accountNumber, processTime, arguments.getBeneficiariesLimit());

    final long beneficiaryAccountNumberAsLong = Long.parseLong(beneficiary.getAccountNumber());
    final long beneficiarySortCodeAsLong = Long.parseLong(beneficiary.getAccountSortCode());

    final FinancialInstitution institution =
        financialInstitutionCoreRepository
            .findFinancialInstitution(beneficiarySortCodeAsLong, false).stream()
            .findFirst()
            .orElseThrow(
                () ->
                    (new RuntimeException(
                        String.format(
                            "Financial Institution for sortcode %d not found",
                            beneficiarySortCodeAsLong))));

    final NonYbsBankAccount nonYbsBankAccount =
        nonYbsBankAccountCoreRepository.saveAndFlush(
            createNonYbsBankAccount(
                beneficiaryAccountNumberAsLong,
                institution,
                beneficiary.getName(),
                beneficiarySortCodeAsLong));

    billPaymentInstructionCoreRepository.saveAndFlush(
        createBillPaymentInstruction(
            accountNumber,
            beneficiary.getMemorableName(),
            beneficiary.getReference(),
            nonYbsBankAccount,
            processTime));

    billPaymentInstructionCoreRepository.updateExternalBeneficiaryAuthenticRecord(accountNumber);
  }

  @Override
  public void auditSuccess(final BeneficiaryRequestArguments<ExternalBeneficiary> arguments) {
    final ExternalBeneficiaryInformation beneficiaryInformation =
        beneficiaryInformationFactory.buildExternal(
            arguments.getAccountNumber(), arguments.getBeneficiary());
    beneficiaryAuditor.auditBeneficiaryCreateSuccess(
        beneficiaryInformation, arguments.getRequestMetadata());
  }

  @Override
  public void auditFailure(
      final BeneficiaryRequestArguments<ExternalBeneficiary> arguments,
      final BeneficiaryValidationExceptionReason reason) {
    final ExternalBeneficiaryInformation beneficiaryInformation =
        beneficiaryInformationFactory.buildExternal(
            arguments.getAccountNumber(), arguments.getBeneficiary());
    beneficiaryAuditor.auditBeneficiaryCreateFailure(
        beneficiaryInformation, reason.getDescription(), arguments.getRequestMetadata());
  }

  private void validateProductLimit(
      final long accountNumber, final LocalDateTime processTime, final Integer beneficiariesLimit) {
    final int numberOfExistingBeneficiaries =
        billPaymentInstructionCoreRepository.findActiveExternalBeneficiaries(
            accountNumber, processTime);

    if (numberOfExistingBeneficiaries >= beneficiariesLimit) {
      log.info(
          "Adding a new external beneficiary would exceed permitted limit of: {} for account: {}",
          beneficiariesLimit,
          accountNumber);
      throw new BeneficiaryValidationException(
          String.format("External beneficiary limit exceeded for account: %s", accountNumber),
          LIMIT_REACHED);
    }
  }

  private void ensureMatchingRecordDoesNotAlreadyExist(
      final long accountNumber,
      final ExternalBeneficiary request,
      final LocalDateTime processTime) {
    final List<BillPaymentInstruction> returnedBeneficiaries =
        billPaymentInstructionCoreRepository.findExistingExternalBeneficiaries(
            accountNumber,
            Long.parseLong(request.getAccountSortCode()),
            Long.parseLong(request.getAccountNumber()),
            null,
            processTime);
    final long existingRecordsCount =
        returnedBeneficiaries.stream()
            .filter(
                beneficiary ->
                    beneficiaryUtils.compareReferences(
                        beneficiary.getReference(), request.getReference()))
            .count();

    if (existingRecordsCount > 0) {
      log.info(
          "Requested external beneficiary for account {} already exists: "
              + "accountNumber: {}, "
              + "accountSortCode: {}, "
              + "name: {}, "
              + "reference: {}, "
              + "memorableName: {}",
          accountNumber,
          request.getAccountNumber(),
          request.getAccountSortCode(),
          request.getName(),
          request.getReference(),
          request.getMemorableName());
      throw new BeneficiaryValidationException(
          String.format("Requested beneficiary already exists for account: %d", accountNumber),
          DUPLICATE);
    }
  }

  private static NonYbsBankAccount createNonYbsBankAccount(
      final long accountNumber,
      final FinancialInstitution financialInstitution,
      final String name,
      final long sortCode) {
    return NonYbsBankAccount.builder()
        .accountNumber(accountNumber)
        .bankName(financialInstitution.getBankName())
        .createdAt(BeneficiaryProcessorConstants.AUDIT_AT)
        .createdBy(BeneficiaryProcessorConstants.AUDIT_BY)
        .createdDate(TIMESTAMP)
        .financialInstitution(financialInstitution)
        .name(name.trim().toUpperCase(LOCALE))
        .sortCode(sortCode)
        .startDate(TIMESTAMP)
        .build();
  }

  private static BillPaymentInstruction createBillPaymentInstruction(
      final long accountNumber,
      final String memorableName,
      final String reference,
      final NonYbsBankAccount nonYbsBankAccount,
      final LocalDateTime processTime) {
    return BillPaymentInstruction.builder()
        .accountNumber(accountNumber)
        .availableAtm(true)
        .createdAt(BeneficiaryProcessorConstants.AUDIT_AT)
        .createdBy(BeneficiaryProcessorConstants.AUDIT_BY)
        .createdDate(processTime)
        .fpChangeReason(BeneficiaryProcessorConstants.INSTRUCTION_FP_CHANGE_REASON)
        .fpTrustStatus(true)
        .memorableName(Optional.ofNullable(memorableName).map(String::trim).orElse(null))
        .nonYbsBankAccount(nonYbsBankAccount)
        .reference(Optional.ofNullable(reference).map(String::trim).orElse(null))
        .startDate(processTime)
        .status(BeneficiaryProcessorConstants.INSTRUCTION_STATUS_ACTIVE)
        .build();
  }
}
