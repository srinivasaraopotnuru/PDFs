package uk.co.ybs.digital.beneficiary.exception;

public class InternalBeneficiaryUpdateNotSupportedException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public InternalBeneficiaryUpdateNotSupportedException(final String message) {
    super(message);
  }
}
