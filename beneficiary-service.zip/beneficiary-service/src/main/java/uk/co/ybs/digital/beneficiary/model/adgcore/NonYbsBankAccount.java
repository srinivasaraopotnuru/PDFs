package uk.co.ybs.digital.beneficiary.model.adgcore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "NON_YBS_BANK_ACCOUNTS")
public class NonYbsBankAccount {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "BANK_ACC_NUM", nullable = false)
  private Long accountNumber;

  @Column(name = "SORT_CODE")
  private Long sortCode;

  @Column(name = "NAME")
  private String name;
}
