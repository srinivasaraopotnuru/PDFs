package uk.co.ybs.digital.beneficiary.service;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.FailureRequest;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;

@Slf4j
@Service
@AllArgsConstructor
public class AuditingBeneficiaryService {
  private final BeneficiaryService beneficiariesService;
  private final BeneficiaryAuditor beneficiaryAuditor;
  private final ScaChallengeService challengeService;

  public List<Beneficiary> getBeneficiaries(
      final String accountNumber, final RequestMetadata requestMetadata) {
    final List<Beneficiary> response =
        beneficiariesService.getBeneficiaries(accountNumber, requestMetadata);
    beneficiaryAuditor.auditBeneficiariesView(accountNumber, requestMetadata);
    return response;
  }

  public void reportFailure(final FailureRequest request, final RequestMetadata requestMetadata) {
    try {
      challengeService.decodeChallenge(request.getChallenge(), Object.class);
      beneficiaryAuditor.auditBeneficiaryChallengeFailure(
          requestMetadata, "Client-side authentication error reported");
    } catch (InvalidScaException ex) {
      log.info("Unable to validate challenge is genuine: {}", ex.getMessage());
      throw new BadFailureRequestChallengeException();
    }
  }
}
