package uk.co.ybs.digital.beneficiary.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Value;
import lombok.experimental.NonFinal;
import lombok.experimental.SuperBuilder;

@Value
@NonFinal
@SuperBuilder(toBuilder = true)
@AllArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
  @JsonSubTypes.Type(name = "EXTERNAL", value = ExternalBeneficiary.class),
  @JsonSubTypes.Type(name = "INTERNAL", value = InternalBeneficiary.class)
})
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public abstract class Beneficiary {
  @NotNull(
      groups = {ExistingBeneficiaryValidationGroup.class},
      message = "You must specify a beneficiary identifier")
  @Schema(
      example = "2165f092096155c8a00a01f8ac1245435dbd4aaf44585a1a60335579dd001638",
      accessMode = Schema.AccessMode.READ_ONLY)
  String beneficiaryId;

  @JsonIgnore Long sysId;

  public boolean isPending() {
    return Objects.isNull(sysId);
  }

  public abstract <T> T accept(BeneficiaryVisitor<T> visitor);
}
