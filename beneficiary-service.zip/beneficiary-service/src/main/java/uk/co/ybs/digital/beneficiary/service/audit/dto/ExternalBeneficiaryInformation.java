package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;
import lombok.experimental.SuperBuilder;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(toBuilder = true)
@JsonDeserialize(
    builder = ExternalBeneficiaryInformation.ExternalBeneficiaryInformationBuilderImpl.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ExternalBeneficiaryInformation extends BeneficiaryInformation {

  @NonNull String payeeSortCode;

  @NonNull String payeeName;

  String reference;

  String memorableName;

  @JsonPOJOBuilder(withPrefix = "")
  static final class ExternalBeneficiaryInformationBuilderImpl
      extends ExternalBeneficiaryInformationBuilder<
          ExternalBeneficiaryInformation, ExternalBeneficiaryInformationBuilderImpl> {}
}
