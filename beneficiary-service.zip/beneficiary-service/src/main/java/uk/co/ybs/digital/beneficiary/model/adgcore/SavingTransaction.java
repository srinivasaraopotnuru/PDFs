package uk.co.ybs.digital.beneficiary.model.adgcore;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "SAVING_TRANSACTIONS")
public class SavingTransaction {

  public static final String GROSS_INTEREST_CAPITALISED = "0017";
  public static final String IT_CREDIT = "0025";
  public static final String TAX_CREDIT = "0034";
  public static final String POSITIVE_RATE_CHANGE = "0080";
  public static final String LP_CREDIT = "0081";
  public static final String NEGATIVE_RATE_CHANGE = "0084";
  public static final String LP_DEBIT = "0085";
  public static final String PRODUCT_MIGRATED_IN = "0094";
  public static final String PRODUCT_MIGRATED_OUT = "0095";
  public static final String DORMANCY = "0096";
  public static final String DORMANCY_REINSTATE = "0097";
  public static final String BONUS_INTEREST = "0144";
  public static final String BONUS_PROJECTED_INTEREST = "0153";
  public static final String BONUS_PROJECTED_INTEREST_DEBIT = "0154";
  public static final String PRODUCT_MIGRATED_IN_NEGATIVE_BALANCE = "0194";
  public static final String PRODUCT_MIGRATED_OUT_NEGATIVE_BALANCE = "0195";
  public static final String CANCELLED_LP_CREDIT = "9081";
  public static final String CANCELLED_LP_DEBIT = "9085";
  public static final String CANCELLED_PRODUCT_MIGRATED_IN = "9094";
  public static final String CANCELLED_PRODUCT_MIGRATED_OUT = "9095";

  public static final List<String> DEPOSIT_SUM_EXCLUDED_TRANSACTION_TYPES =
      Arrays.asList(
          GROSS_INTEREST_CAPITALISED,
          IT_CREDIT,
          TAX_CREDIT,
          POSITIVE_RATE_CHANGE,
          LP_CREDIT,
          NEGATIVE_RATE_CHANGE,
          LP_DEBIT,
          PRODUCT_MIGRATED_IN,
          PRODUCT_MIGRATED_OUT,
          DORMANCY,
          DORMANCY_REINSTATE,
          BONUS_INTEREST,
          BONUS_PROJECTED_INTEREST,
          BONUS_PROJECTED_INTEREST_DEBIT,
          PRODUCT_MIGRATED_IN_NEGATIVE_BALANCE,
          PRODUCT_MIGRATED_OUT_NEGATIVE_BALANCE,
          CANCELLED_LP_CREDIT,
          CANCELLED_LP_DEBIT,
          CANCELLED_PRODUCT_MIGRATED_IN,
          CANCELLED_PRODUCT_MIGRATED_OUT);

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private long sysid;

  @Column(name = "SAVACC_ACCOUNT_NUMBER")
  private long accountNumber;

  @Column(name = "CATEGORY")
  private String category;

  @Column(name = "FINTRM_FNTRTP_CODE")
  private String financialTransactionTypeCode;

  @Column(name = "PROCESS_DATE")
  private LocalDateTime processDate;

  @Column(name = "TRANSACTION_DATE")
  private LocalDateTime transactionDate;

  @Column(name = "TRANS_AMT")
  private BigDecimal transactionAmount;
}
