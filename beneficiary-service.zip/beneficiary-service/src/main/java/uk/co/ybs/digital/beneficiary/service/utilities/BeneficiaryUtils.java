package uk.co.ybs.digital.beneficiary.service.utilities;

import java.util.Collection;
import java.util.Comparator;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@Component
public class BeneficiaryUtils {

  private static final int REFERENCE_MAX_LENGTH = 18;

  private static final Locale LOCALE = Locale.ROOT;

  public Optional<WorkLog> findMatchingWorkLog(
      final BillPaymentInstruction instruction, final Collection<WorkLog> workLogs) {
    return workLogs.stream()
        .filter(workLog -> workLogMatches(workLog, instruction))
        .max(Comparator.comparing(WorkLog::getSysId));
  }

  public Optional<WorkLog> findMatchingWorkLog(
      final ItInstruction instruction, final Collection<WorkLog> workLogs) {
    return workLogs.stream()
        .filter(workLog -> workLogMatches(workLog, instruction))
        .max(Comparator.comparing(WorkLog::getSysId));
  }

  public boolean compareReferences(final String referenceA, final String referenceB) {
    return Objects.equals(transformReference(referenceA), transformReference(referenceB));
  }

  private boolean workLogMatches(final WorkLog workLog, final BillPaymentInstruction instruction) {
    final BeneficiaryRequest.Payload workLogPayload = workLog.getMessage().getPayload();
    return workLogPayload.getBeneficiary() instanceof ExternalBeneficiary
        && Objects.equals(workLogPayload.getSysId(), instruction.getSysId());
  }

  private boolean workLogMatches(final WorkLog workLog, final ItInstruction instruction) {
    final BeneficiaryRequest.Payload workLogPayload = workLog.getMessage().getPayload();
    return workLogPayload.getBeneficiary() instanceof InternalBeneficiary
        && Objects.equals(workLogPayload.getSysId(), instruction.getSysId());
  }

  private String transformReference(final String reference) {
    // This replicates ECOM logic
    //  - Trim white space
    //  - Truncated to 18 characters
    //  - Upper cased (resulting in a case insensitive comparison)
    return reference != null
        ? StringUtils.left(reference.trim(), REFERENCE_MAX_LENGTH).toUpperCase(LOCALE)
        : null;
  }
}
