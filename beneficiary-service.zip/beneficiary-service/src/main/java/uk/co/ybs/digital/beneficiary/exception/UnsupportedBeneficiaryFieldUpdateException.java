package uk.co.ybs.digital.beneficiary.exception;

import java.util.List;
import lombok.Getter;

@Getter
public class UnsupportedBeneficiaryFieldUpdateException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private final List<String> unsupportedFields;
  private final List<String> supportedFields;

  public UnsupportedBeneficiaryFieldUpdateException(
      final String message,
      final List<String> unsupportedFields,
      final List<String> supportedFields) {
    super(message);
    this.unsupportedFields = unsupportedFields;
    this.supportedFields = supportedFields;
  }
}
