package uk.co.ybs.digital.beneficiary.model.digitalbeneficiary;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.temporal.TemporalAccessor;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.data.auditing.DateTimeProvider;

@AllArgsConstructor
public class ClockDateTimeProvider implements DateTimeProvider {

  @NonNull private final Clock clock;

  @Override
  public Optional<TemporalAccessor> getNow() {
    return Optional.of(LocalDateTime.now(clock));
  }
}
