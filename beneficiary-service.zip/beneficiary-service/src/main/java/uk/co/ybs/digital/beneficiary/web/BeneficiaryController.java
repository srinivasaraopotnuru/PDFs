package uk.co.ybs.digital.beneficiary.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import uk.co.ybs.digital.beneficiary.config.SwaggerConfig;
import uk.co.ybs.digital.beneficiary.service.AuditingBeneficiaryService;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryService;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryLimitResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ExistingBeneficiaryValidationGroup;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.FailureRequest;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.beneficiary.web.validators.InternalAccountNumber;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.logging.filters.session.SessionIdFilter;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@RestController
@AllArgsConstructor
@Validated
@Slf4j
public class BeneficiaryController {

  public static final String REQUIRE_SCOPE_BENEFICIARY_AND_SCOPE_ACCOUNT_READ =
      "hasAuthority('SCOPE_BENEFICIARY') and hasAuthority('SCOPE_ACCOUNT_READ')";
  private final AuditingBeneficiaryService auditingBeneficiaryService;
  private final BeneficiaryService beneficiariesService;
  private final ScaCredentialsExtractor scaCredentialsExtractor;
  private static final String CHANNEL_CLAIM = "channel";
  private static final String REQUIRE_SCOPE_BENEFICIARY = "hasAuthority('SCOPE_BENEFICIARY')";
  private static final String ACCOUNT_NUMBER = "accountNumber";
  public static final String TEN_DIGIT_ACCOUNT_NUMBER = "10 digit account number";
  private static final String WEB_CHANNEL = "WEB";
  private static final String OK = "OK";
  private static final String CODE_200 = "200";
  private static final String ACCEPTED = "Accepted";
  private static final String CODE_202 = "202";
  private static final String BAD_REQUEST = "Bad Request";
  private static final String CODE_400 = "400";
  private static final String UNAUTHORISED = "Unauthorised";
  private static final String CODE_401 = "401";
  private static final String FORBIDDEN = "Forbidden";
  private static final String CODE_403 = "403";
  private static final String NOT_FOUND = "Not Found";
  private static final String CODE_404 = "404";
  private static final String NOT_ACCEPTABLE = "Not Acceptable";
  private static final String CODE_406 = "406";
  private static final String CONFLICT = "Conflict";
  private static final String CODE_409 = "409";
  private static final String UNSUPPORTED_MEDIA_TYPE = "Unsupported Media Type";
  private static final String CODE_415 = "415";
  private static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
  private static final String CODE_500 = "500";

  @GetMapping(
      value = {"/accounts/{accountNumber}/beneficiaries"},
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(REQUIRE_SCOPE_BENEFICIARY)
  @Operation(
      description = "Get beneficiaries for an account number",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(
            responseCode = CODE_200,
            description = OK,
            content =
                @Content(
                    schema =
                        @Schema(oneOf = {ExternalBeneficiary.class, InternalBeneficiary.class}))),
        @ApiResponse(
            responseCode = CODE_400,
            description = BAD_REQUEST,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_401,
            description = UNAUTHORISED,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_403,
            description = FORBIDDEN,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_406,
            description = NOT_ACCEPTABLE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_415,
            description = UNSUPPORTED_MEDIA_TYPE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_500,
            description = INTERNAL_SERVER_ERROR,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  public List<Beneficiary> getBeneficiaries(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = TEN_DIGIT_ACCOUNT_NUMBER)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, sessionId, request, headers);
    return auditingBeneficiaryService.getBeneficiaries(accountNumber, metadata);
  }

  @PutMapping(
      value = "/accounts/{accountNumber}/beneficiaries",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(REQUIRE_SCOPE_BENEFICIARY)
  @Operation(
      description = "Update an existing beneficiary for an account",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = CODE_202, description = ACCEPTED),
        @ApiResponse(responseCode = CODE_400, description = BAD_REQUEST),
        @ApiResponse(responseCode = CODE_401, description = UNAUTHORISED),
        @ApiResponse(responseCode = CODE_404, description = NOT_FOUND),
        @ApiResponse(responseCode = CODE_406, description = NOT_ACCEPTABLE),
        @ApiResponse(responseCode = CODE_409, description = CONFLICT),
        @ApiResponse(responseCode = CODE_415, description = UNSUPPORTED_MEDIA_TYPE),
        @ApiResponse(responseCode = CODE_500, description = INTERNAL_SERVER_ERROR)
      })
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  @SuppressWarnings("PMD.ExcessiveParameterList")
  public Beneficiary updateBeneficiary(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = TEN_DIGIT_ACCOUNT_NUMBER)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @RequestBody @Validated({Default.class, ExistingBeneficiaryValidationGroup.class})
          final Beneficiary requestBody,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, sessionId, request, headers);
    final Optional<ScaCredentials> scaCredentials = scaCredentialsExtractor.extract(headers);
    return beneficiariesService.updateBeneficiary(
        accountNumber, requestBody, metadata, scaCredentials.orElse(null));
  }

  @DeleteMapping(value = "/accounts/{accountNumber}/beneficiaries/{beneficiaryId}")
  @PreAuthorize(REQUIRE_SCOPE_BENEFICIARY)
  @Operation(
      description = "Delete an existing beneficiary for an account",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = CODE_202, description = ACCEPTED),
        @ApiResponse(responseCode = CODE_400, description = BAD_REQUEST),
        @ApiResponse(responseCode = CODE_401, description = UNAUTHORISED),
        @ApiResponse(responseCode = CODE_404, description = NOT_FOUND),
        @ApiResponse(responseCode = CODE_406, description = NOT_ACCEPTABLE),
        @ApiResponse(responseCode = CODE_409, description = CONFLICT),
        @ApiResponse(responseCode = CODE_500, description = INTERNAL_SERVER_ERROR)
      })
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  @SuppressWarnings("PMD.ExcessiveParameterList")
  public void deleteBeneficiary(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = TEN_DIGIT_ACCOUNT_NUMBER)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @PathVariable final String beneficiaryId,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, sessionId, request, headers);
    if (WEB_CHANNEL.equalsIgnoreCase(user.getClaimAsString(CHANNEL_CLAIM))) {
      beneficiariesService.deleteBeneficiaryWithoutSca(accountNumber, beneficiaryId, metadata);
    } else {
      final Optional<ScaCredentials> scaCredentials = scaCredentialsExtractor.extract(headers);
      beneficiariesService.deleteBeneficiary(
          accountNumber, beneficiaryId, metadata, scaCredentials.orElse(null));
    }
  }

  @PostMapping(value = "/failure", consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(REQUIRE_SCOPE_BENEFICIARY)
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void reportFailure(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers,
      @RequestBody final FailureRequest request,
      final HttpServletRequest servletRequest) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(
            user, requestId, sessionId, servletRequest, headers);
    auditingBeneficiaryService.reportFailure(request, metadata);
  }

  @GetMapping(
      value = {"/accounts/{accountNumber}/beneficiary-limits"},
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(REQUIRE_SCOPE_BENEFICIARY_AND_SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get beneficiary limit",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(
            responseCode = CODE_200,
            description = OK,
            content = @Content(schema = @Schema(implementation = BeneficiaryLimitResponse.class))),
        @ApiResponse(
            responseCode = CODE_400,
            description = BAD_REQUEST,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_401,
            description = UNAUTHORISED,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_403,
            description = FORBIDDEN,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_406,
            description = NOT_ACCEPTABLE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_415,
            description = UNSUPPORTED_MEDIA_TYPE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CODE_500,
            description = INTERNAL_SERVER_ERROR,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  public BeneficiaryLimitResponse getBeneficiaryLimits(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = TEN_DIGIT_ACCOUNT_NUMBER)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, sessionId, request, headers);
    return beneficiariesService.getBeneficiariesLimits(accountNumber, metadata);
  }
}
