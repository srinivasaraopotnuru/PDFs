package uk.co.ybs.digital.beneficiary.service;

import java.util.List;
import lombok.Value;
import lombok.experimental.NonFinal;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.validation.annotation.Validated;

@Value
@NonFinal
@ConstructorBinding
@ConfigurationProperties(prefix = "uk.co.ybs.digital.beneficiary")
@Validated
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class BeneficiaryServiceProperties {

  // Represents a list of account numbers to not create beneficiary requests for.
  // Used by smoke/e2e tests
  List<String> accountNumberBlacklist;
}
