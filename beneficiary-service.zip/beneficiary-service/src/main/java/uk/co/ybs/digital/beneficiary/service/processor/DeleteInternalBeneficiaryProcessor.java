package uk.co.ybs.digital.beneficiary.service.processor;

import com.google.common.base.Strings;
import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;
import uk.co.ybs.digital.beneficiary.repository.core.ItInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@Slf4j
@RequiredArgsConstructor
@Component
@Transactional("beneficiaryProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public class DeleteInternalBeneficiaryProcessor
    implements ExistingBeneficiaryProcessor<InternalBeneficiary, ItInstruction> {

  private final ItInstructionCoreRepository itInstructionCoreRepository;
  private final BeneficiaryInformationFactory beneficiaryInformationFactory;
  private final BeneficiaryAuditor beneficiaryAuditor;

  @Override
  public ItInstruction resolve(
      final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments) {
    final long sysId = arguments.getSysId();
    return itInstructionCoreRepository
        .findById(sysId)
        .orElseThrow(
            () -> new IllegalArgumentException(String.format("ItInstruction %s not found", sysId)));
  }

  @Override
  public void execute(
      final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments,
      final ItInstruction instruction) {
    final LocalDateTime processTime = arguments.getProcessTime();
    if (instruction.getEndDate() != null) {
      throw new BeneficiaryValidationException(
          "Beneficiary already ended", BeneficiaryValidationExceptionReason.DELETED);
    }

    final ItInstruction endedInstruction =
        instruction
            .toBuilder()
            .endDate(processTime)
            .endedAt(BeneficiaryProcessorConstants.AUDIT_AT)
            .endedBy(BeneficiaryProcessorConstants.AUDIT_BY)
            .endedDate(processTime)
            .status(BeneficiaryProcessorConstants.INSTRUCTION_STATUS_CANCELLED)
            .build();

    itInstructionCoreRepository.saveAndFlush(endedInstruction);
    itInstructionCoreRepository.updateInternalBeneficiaryAuthenticRecord(
        arguments.getAccountNumber());
  }

  @Override
  public void auditSuccess(
      final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments,
      final ItInstruction instruction) {
    final InternalBeneficiary databaseBeneficiary = mapItInstruction(instruction);
    final InternalBeneficiaryInformation beneficiaryInformation =
        beneficiaryInformationFactory.buildInternal(
            arguments.getAccountNumber(), databaseBeneficiary);
    beneficiaryAuditor.auditBeneficiaryDeleteSuccess(
        beneficiaryInformation, arguments.getRequestMetadata());
  }

  @Override
  public void auditFailure(
      final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments,
      final ItInstruction instruction,
      final BeneficiaryValidationExceptionReason reason) {
    final InternalBeneficiary databaseBeneficiary = mapItInstruction(instruction);
    final InternalBeneficiaryInformation beneficiaryInformation =
        beneficiaryInformationFactory.buildInternal(
            arguments.getAccountNumber(), databaseBeneficiary);
    beneficiaryAuditor.auditBeneficiaryDeleteFailure(
        beneficiaryInformation, reason.getDescription(), arguments.getRequestMetadata());
  }

  private InternalBeneficiary mapItInstruction(final ItInstruction instruction) {
    return InternalBeneficiary.builder()
        .accountNumber(padInternalAccountNumber(instruction.getCreditorAccountNumber()))
        .build();
  }

  private String padInternalAccountNumber(final long accountNumber) {
    return Strings.padStart(String.valueOf(accountNumber), 10, '0');
  }
}
