package uk.co.ybs.digital.beneficiary.model.digitalbeneficiary;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties("pending")
public abstract class IgnorePendingMixin {}
