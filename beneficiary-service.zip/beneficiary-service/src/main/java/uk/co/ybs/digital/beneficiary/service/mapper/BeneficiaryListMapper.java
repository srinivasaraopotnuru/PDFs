package uk.co.ybs.digital.beneficiary.service.mapper;

import static java.util.Comparator.comparing;
import static java.util.Comparator.naturalOrder;
import static java.util.Comparator.nullsFirst;
import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.toList;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Stream;
import javax.validation.groups.Default;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.SmartValidator;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExistingBeneficiaryValidationGroup;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@AllArgsConstructor
@Component
@Slf4j
public class BeneficiaryListMapper {

  @NonNull private final ExternalBeneficiaryMapper externalBeneficiaryMapper;
  @NonNull private final InternalBeneficiaryMapper internalBeneficiaryMapper;

  @NonNull
  @Qualifier("defaultValidator")
  private final SmartValidator validator;

  public List<Beneficiary> map(
      final Collection<BillPaymentInstruction> externalInstructions,
      final Collection<ItInstruction> internalInstructions,
      final Collection<WorkLog> pendingWorkLogs) {
    final Stream<ExternalBeneficiary> externalBeneficiaries =
        externalInstructions.stream()
            .map(instruction -> externalBeneficiaryMapper.map(instruction, pendingWorkLogs))
            .sorted(
                comparing(
                        ExternalBeneficiary::getMemorableName,
                        nullsFirst(String.CASE_INSENSITIVE_ORDER))
                    .thenComparing(
                        ExternalBeneficiary::getName, nullsFirst(String.CASE_INSENSITIVE_ORDER))
                    .thenComparing(
                        ExternalBeneficiary::getReference,
                        nullsFirst(String.CASE_INSENSITIVE_ORDER))
                    .thenComparing(
                        ExternalBeneficiary::getAccountSortCode, nullsFirst(naturalOrder()))
                    .thenComparing(
                        ExternalBeneficiary::getAccountNumber, nullsFirst(naturalOrder()))
                    .thenComparing(ExternalBeneficiary::getBeneficiaryId));

    final Stream<InternalBeneficiary> internalBeneficiaries =
        internalInstructions.stream()
            .map(instruction -> internalBeneficiaryMapper.map(instruction, pendingWorkLogs))
            .sorted(
                comparing(InternalBeneficiary::getAccountNumber, nullsFirst(naturalOrder()))
                    .thenComparing(InternalBeneficiary::getBeneficiaryId));

    return Stream.concat(internalBeneficiaries, externalBeneficiaries).filter(this::checkValid)
        .collect(groupingBy(Beneficiary::getBeneficiaryId, LinkedHashMap::new, toList())).values()
        .stream()
        .filter(this::checkIdUnique)
        .flatMap(Collection::stream)
        .collect(toList());
  }

  private boolean checkValid(final Beneficiary beneficiary) {
    final BindingResult bindingResult = new MapBindingResult(new HashMap<>(), "beneficiary");
    validator.validate(
        beneficiary, bindingResult, Default.class, ExistingBeneficiaryValidationGroup.class);
    final boolean hasErrors = bindingResult.hasErrors();
    if (hasErrors) {
      log.warn("Filtering invalid beneficiary {}: {}", beneficiary, bindingResult);
    }
    return !hasErrors;
  }

  private boolean checkIdUnique(final List<Beneficiary> beneficiariesWithId) {
    final boolean unique = beneficiariesWithId.size() == 1;
    if (!unique) {
      log.warn("Filtering beneficiaries with matching ids: {}", beneficiariesWithId);
    }
    return unique;
  }
}
