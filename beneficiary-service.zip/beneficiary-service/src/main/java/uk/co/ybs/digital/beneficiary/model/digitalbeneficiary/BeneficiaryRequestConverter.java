package uk.co.ybs.digital.beneficiary.model.digitalbeneficiary;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;

@Converter(autoApply = true)
public class BeneficiaryRequestConverter implements AttributeConverter<BeneficiaryRequest, String> {

  private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  @Override
  public String convertToDatabaseColumn(final BeneficiaryRequest entityValue) {
    try {
      return OBJECT_MAPPER
          .addMixIn(Beneficiary.class, IgnorePendingMixin.class)
          .writeValueAsString(entityValue);
    } catch (JsonProcessingException e) {
      throw new DataConversionException("Unable to serialise Beneficiary request", e);
    }
  }

  @Override
  public BeneficiaryRequest convertToEntityAttribute(final String databaseValue) {
    try {
      return OBJECT_MAPPER.readValue(databaseValue, BeneficiaryRequest.class);
    } catch (JsonProcessingException e) {
      throw new DataConversionException("Unable to deserialise Beneficiary request", e);
    }
  }

  public static class DataConversionException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public DataConversionException(final String message, final Throwable cause) {
      super(message, cause);
    }
  }
}
