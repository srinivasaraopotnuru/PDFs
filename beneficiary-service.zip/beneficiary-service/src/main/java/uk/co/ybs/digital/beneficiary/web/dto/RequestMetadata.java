package uk.co.ybs.digital.beneficiary.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.net.InetSocketAddress;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = RequestMetadata.RequestMetadataBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class RequestMetadata {
  @NonNull UUID requestId;
  @NonNull UUID sessionId;
  @NonNull InetSocketAddress host;
  @NonNull String partyId;
  @NonNull String brandCode;
  @ToString.Exclude @NonNull String forwardingAuth;
  @NonNull String ipAddress;

  @JsonPOJOBuilder(withPrefix = "")
  public static class RequestMetadataBuilder {}
}
