package uk.co.ybs.digital.beneficiary.service.processor;

import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.repository.core.BillPaymentInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.mapper.ExternalBeneficiaryDatabaseEntityMapper;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;

@Slf4j
@RequiredArgsConstructor
@Component
@Transactional("beneficiaryProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public class DeleteExternalBeneficiaryProcessor
    implements ExistingBeneficiaryProcessor<ExternalBeneficiary, BillPaymentInstruction> {

  private final BillPaymentInstructionCoreRepository billPaymentInstructionCoreRepository;
  private final ExternalBeneficiaryDatabaseEntityMapper externalBeneficiaryDatabaseEntityMapper;
  private final BeneficiaryInformationFactory beneficiaryInformationFactory;
  private final BeneficiaryAuditor beneficiaryAuditor;

  @Override
  public BillPaymentInstruction resolve(
      final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments) {
    final long sysId = arguments.getSysId();
    return billPaymentInstructionCoreRepository
        .findById(sysId)
        .orElseThrow(
            () ->
                new IllegalArgumentException(
                    String.format("BillPaymentInstruction %s not found", sysId)));
  }

  @Override
  public void execute(
      final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments,
      final BillPaymentInstruction instruction) {
    final LocalDateTime processTime = arguments.getProcessTime();
    if (instruction.getEndDate() != null) {
      throw new BeneficiaryValidationException(
          "Beneficiary already ended", BeneficiaryValidationExceptionReason.DELETED);
    }

    final BillPaymentInstruction endedInstruction =
        instruction
            .toBuilder()
            .endDate(processTime)
            .endedAt(BeneficiaryProcessorConstants.AUDIT_AT)
            .endedBy(BeneficiaryProcessorConstants.AUDIT_BY)
            .endedDate(processTime)
            .status(BeneficiaryProcessorConstants.INSTRUCTION_STATUS_CANCELLED)
            .atmOrderNumber(null)
            .build();

    billPaymentInstructionCoreRepository.saveAndFlush(endedInstruction);
    billPaymentInstructionCoreRepository.updateExternalBeneficiaryAuthenticRecord(
        arguments.getAccountNumber());
  }

  @Override
  public void auditSuccess(
      final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments,
      final BillPaymentInstruction instruction) {
    final ExternalBeneficiary databaseBeneficiary =
        externalBeneficiaryDatabaseEntityMapper.map(instruction);
    final ExternalBeneficiaryInformation beneficiaryInformation =
        beneficiaryInformationFactory.buildExternal(
            arguments.getAccountNumber(), databaseBeneficiary);
    beneficiaryAuditor.auditBeneficiaryDeleteSuccess(
        beneficiaryInformation, arguments.getRequestMetadata());
  }

  @Override
  public void auditFailure(
      final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments,
      final BillPaymentInstruction instruction,
      final BeneficiaryValidationExceptionReason reason) {
    final ExternalBeneficiary databaseBeneficiary =
        externalBeneficiaryDatabaseEntityMapper.map(instruction);
    final ExternalBeneficiaryInformation beneficiaryInformation =
        beneficiaryInformationFactory.buildExternal(
            arguments.getAccountNumber(), databaseBeneficiary);
    beneficiaryAuditor.auditBeneficiaryDeleteFailure(
        beneficiaryInformation, reason.getDescription(), arguments.getRequestMetadata());
  }
}
