package uk.co.ybs.digital.beneficiary.service.sca;

import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;

@Value
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class BeneficiaryChallengePayloadBody {
  @NonNull WorkLog.Operation operation;

  @NonNull Beneficiary beneficiary;
}
