package uk.co.ybs.digital.beneficiary.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class BeneficiaryLimit {

  @Schema(example = "1", description = "Number of existing payees", required = true)
  int count;

  @Schema(example = "12", description = " Maximum number of payees permitted", required = true)
  int maxPermitted;

  @Schema(
      example = "false",
      type = "boolean",
      description =
          " Flag to indicate if customer has reached their limit for the number of payees",
      required = true)
  boolean limitReached;
}
