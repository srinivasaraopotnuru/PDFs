package uk.co.ybs.digital.beneficiary.config.persistence;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@Import({
  AdgCoreConfiguration.class,
  DigitalBeneficiaryConfiguration.class,
  CoreConfiguration.class
})
public class PersistenceConfiguration {
  public static final String DATASOURCE_PROPERTY_PREFIX = "spring.datasource.";
  public static final String JPA_PROPERTIES_PREFIX = "spring.jpa.";

  public static final String MODEL_PACKAGE_PREFIX = "uk.co.ybs.digital.beneficiary.model.";
  public static final String REPOSITORY_PACKAGE_PREFIX =
      "uk.co.ybs.digital.beneficiary.repository.";

  @Bean
  public PlatformTransactionManager transactionManager(
      final PlatformTransactionManager adgCoreTransactionManager,
      final PlatformTransactionManager digitalBeneficiaryTransactionManager) {
    return new ChainedTransactionManager(
        adgCoreTransactionManager, digitalBeneficiaryTransactionManager);
  }

  @Bean
  @ConditionalOnProperty(
      prefix = "uk.co.ybs.digital.beneficiary.processor",
      name = "enabled",
      havingValue = "true")
  public PlatformTransactionManager beneficiaryProcessorTransactionManager(
      final PlatformTransactionManager coreTransactionManager,
      final PlatformTransactionManager digitalBeneficiaryTransactionManager) {
    return new ChainedTransactionManager(
        digitalBeneficiaryTransactionManager, coreTransactionManager);
  }
}
