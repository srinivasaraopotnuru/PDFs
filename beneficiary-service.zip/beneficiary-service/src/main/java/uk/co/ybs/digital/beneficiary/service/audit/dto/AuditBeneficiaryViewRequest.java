package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = AuditBeneficiaryViewRequest.AuditBeneficiaryViewRequestBuilder.class)
public class AuditBeneficiaryViewRequest {
  @NonNull private final String ipAddress;
  @NonNull private final BeneficiaryInformation beneficiaryInformation;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditBeneficiaryViewRequestBuilder {}

  @Value
  @Builder
  @JsonDeserialize(builder = BeneficiaryInformation.BeneficiaryInformationBuilder.class)
  public static class BeneficiaryInformation {
    @NonNull private final String accountNumber;

    @JsonPOJOBuilder(withPrefix = "")
    public static class BeneficiaryInformationBuilder {}
  }
}
