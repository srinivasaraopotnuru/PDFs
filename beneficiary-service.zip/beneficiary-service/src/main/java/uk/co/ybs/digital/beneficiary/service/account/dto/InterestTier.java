package uk.co.ybs.digital.beneficiary.service.account.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = InterestTier.InterestTierBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class InterestTier {
  @Schema(required = true, example = "0.700")
  String interestRate;

  @Schema(required = true, example = "0.700")
  String annualEquivalentRate;

  @JsonPOJOBuilder(withPrefix = "")
  public static class InterestTierBuilder {}
}
