package uk.co.ybs.digital.beneficiary.service.processor;

import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;

public interface CreateBeneficiaryProcessor<B extends Beneficiary> {
  void execute(BeneficiaryRequestArguments<B> arguments);

  void auditSuccess(BeneficiaryRequestArguments<B> arguments);

  void auditFailure(
      BeneficiaryRequestArguments<B> arguments, BeneficiaryValidationExceptionReason reason);
}
