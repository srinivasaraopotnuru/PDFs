package uk.co.ybs.digital.beneficiary.service.processor;

import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;

public interface ExistingBeneficiaryProcessor<B extends Beneficiary, DatabaseEntity> {
  DatabaseEntity resolve(ExistingBeneficiaryRequestArguments<B> arguments);

  void execute(ExistingBeneficiaryRequestArguments<B> arguments, DatabaseEntity databaseEntity);

  void auditSuccess(
      ExistingBeneficiaryRequestArguments<B> arguments, DatabaseEntity databaseEntity);

  void auditFailure(
      ExistingBeneficiaryRequestArguments<B> arguments,
      DatabaseEntity databaseEntity,
      BeneficiaryValidationExceptionReason reason);
}
