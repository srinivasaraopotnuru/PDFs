package uk.co.ybs.digital.beneficiary.service.account.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Isa.IsaBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Isa {
  Boolean flexible;
  Boolean helpToBuy;
  Boolean subscribed;

  @JsonPOJOBuilder(withPrefix = "")
  public static class IsaBuilder {}
}
