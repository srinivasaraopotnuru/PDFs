package uk.co.ybs.digital.beneficiary.service.mapper;

import com.google.common.base.Strings;
import org.springframework.stereotype.Component;

@Component
public class CommonAccountMapper {

  public String convertAndPadSortCode(final Integer sortCode) {
    return Strings.padStart(String.valueOf(sortCode), 6, '0');
  }

  public String internalToExternalAccountNumber(final String internalAccountNumber) {
    return internalAccountNumber.substring(0, 8);
  }
}
