package uk.co.ybs.digital.beneficiary.model.digitalbeneficiary;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class BeneficiaryRequest {
  @NonNull Payload payload;
  @NonNull RequestMetadata metadata;

  @Value
  @Builder
  @Jacksonized
  public static class Payload {
    Long sysId;
    Integer beneficiariesLimit;
    @NonNull Beneficiary beneficiary;
  }
}
