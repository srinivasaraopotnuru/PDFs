package uk.co.ybs.digital.beneficiary.service.processor;

import java.time.LocalDateTime;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@Value
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ExistingBeneficiaryRequestArguments<B extends Beneficiary> {
  long accountNumber;
  @NonNull RequestMetadata requestMetadata;
  @NonNull LocalDateTime processTime;
  @NonNull B beneficiary;
  long sysId;
}
