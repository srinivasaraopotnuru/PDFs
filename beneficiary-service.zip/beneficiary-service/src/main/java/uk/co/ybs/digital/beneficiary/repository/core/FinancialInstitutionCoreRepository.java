package uk.co.ybs.digital.beneficiary.repository.core;

import java.util.List;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public interface FinancialInstitutionCoreRepository
    extends JpaRepository<FinancialInstitution, Long> {

  @Query(
      "SELECT fi "
          + "FROM FinancialInstitution fi "
          + "WHERE fi.sortCode = :sortCode AND fi.subBranch = :subBranch and fi.closedDate IS NULL "
          + "ORDER BY fi.sysId")
  List<FinancialInstitution> findFinancialInstitution(
      @Param("sortCode") Long sortCode, @Param("subBranch") Boolean subBranch);
}
