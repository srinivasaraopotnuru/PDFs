package uk.co.ybs.digital.beneficiary.repository.adgcore;

import java.time.LocalDateTime;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;

public interface BillPaymentInstructionRepository
    extends JpaRepository<BillPaymentInstruction, Long> {

  @Query(
      "FROM BillPaymentInstruction bpi "
          + "JOIN FETCH bpi.nonYbsBankAccount "
          + "WHERE bpi.accountNumber = :accountNumber "
          + "AND (bpi.endDate > :now OR bpi.endDate IS NULL) "
          + "AND bpi.status = 'ACTIVE' "
          + "AND bpi.availableAtm = 'Y' "
          + "AND function('PACK_FASTER_PAY.FN_TRUST_STATUS', "
          + "bpi.accountNumber, bpi.nonYbsBankAccount.sortCode, "
          + "bpi.nonYbsBankAccount.accountNumber, 'B') = 'Y'")
  Collection<BillPaymentInstruction> findActiveExternalBeneficiaries(
      @Param("accountNumber") Long accountNumber, @Param("now") LocalDateTime now);
}
