package uk.co.ybs.digital.beneficiary.service.account.dto;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum RestrictionCategory {
  DEPOSIT_ISA_DECLARATION("deposit.isa.declaration"),
  DEPOSIT_ISA_TRANSFERRED("deposit.isa.transfer"),
  DEPOSIT_DEFAULT("deposit.account.restriction"),
  WITHDRAWAL_NEW_ACCOUNT("withdrawal.account.newacnt14day"),
  WITHDRAWAL_INTEREST_PENALTY("withdrawal.account.interest-penalty"),
  WITHDRAWAL_DEFAULT("withdrawal.account.restriction");

  @JsonValue private final String description;
}
