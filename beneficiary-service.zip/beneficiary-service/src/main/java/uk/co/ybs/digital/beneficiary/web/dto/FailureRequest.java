package uk.co.ybs.digital.beneficiary.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = FailureRequest.FailureRequestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class FailureRequest {
  @NotNull(message = "You must specify the original challenge")
  @Schema(required = true)
  String challenge;

  @JsonPOJOBuilder(withPrefix = "")
  public static class FailureRequestBuilder {}
}
