package uk.co.ybs.digital.beneficiary.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class BeneficiaryLimitResponse {

  @Schema(type = "object", description = "Account with internal beneficiary limit", required = true)
  BeneficiaryLimit internal;

  @Schema(type = "object", description = "Account with external beneficiary limit", required = true)
  BeneficiaryLimit external;
}
