package uk.co.ybs.digital.beneficiary.model.adgcore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ACCOUNT_NUMBERS")
public class AccountNumber {
  public static final String TABLE_ID_SAVACC = "SAVACC";

  @Id
  @Column(name = "ACCOUNT_NUMBER", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  @SuppressWarnings("PMD.AvoidFieldNameMatchingTypeName")
  private Long accountNumber;

  @Column(name = "TABLE_ID", nullable = false)
  private String tableId;

  @Column(name = "SPRD_SYSID", nullable = false)
  private Long savingProductSysId;
}
