package uk.co.ybs.digital.beneficiary.repository.core;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public interface BillPaymentInstructionCoreRepository
    extends JpaRepository<BillPaymentInstruction, Long> {

  @Procedure(procedureName = "PACK_ATM.PR_BILL_PAYMENT_DETAILS")
  void updateExternalBeneficiaryAuthenticRecord(@Param("PN_SAVACC_ACCOUNT") Long pnSavaccAccount);

  @Query(
      "SELECT bpi "
          + "FROM BillPaymentInstruction bpi "
          + "JOIN bpi.nonYbsBankAccount nyba "
          + "WHERE bpi.accountNumber = :debtorAccountNumber "
          + "AND (:updatingSysId IS NULL OR (bpi.sysId <> :updatingSysId)) "
          + "AND bpi.status = 'ACTIVE' "
          + "AND bpi.availableAtm = 'Y' "
          + "AND (bpi.endDate > :now OR bpi.endDate IS NULL) "
          + "AND nyba.accountNumber = :accountNumber "
          + "AND nyba.sortCode = :sortCode "
          + "AND (nyba.endDate > :now OR nyba.endDate IS NULL)")
  List<BillPaymentInstruction> findExistingExternalBeneficiaries(
      @Param("debtorAccountNumber") Long debtorAccountNumber,
      @Param("sortCode") Long sortCode,
      @Param("accountNumber") Long accountNumber,
      @Param("updatingSysId") Long updatingSysId,
      @Param("now") LocalDateTime now);

  @Query(
      "SELECT COUNT(bpi) "
          + "FROM BillPaymentInstruction bpi "
          + "WHERE bpi.accountNumber = :debtorAccountNumber "
          + "AND bpi.status = 'ACTIVE' "
          + "AND bpi.availableAtm = 'Y' "
          + "AND (bpi.endDate > :now OR bpi.endDate IS NULL)")
  int findActiveExternalBeneficiaries(
      @Param("debtorAccountNumber") Long debtorAccountNumber, @Param("now") LocalDateTime now);
}
