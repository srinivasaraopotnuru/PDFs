package uk.co.ybs.digital.beneficiary.web;

import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.LIMIT_REACHED;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.PENDING;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.TECHNICAL;

import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.beneficiary.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.exception.InternalBeneficiaryUpdateNotSupportedException;
import uk.co.ybs.digital.beneficiary.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.beneficiary.exception.ScaRequiredException;
import uk.co.ybs.digital.beneficiary.exception.UnsupportedBeneficiaryFieldUpdateException;
import uk.co.ybs.digital.beneficiary.service.BadFailureRequestChallengeException;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.sca.exception.InvalidPemKeyException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;

@Slf4j
@ControllerAdvice
public class BeneficiaryServiceExceptionHandler {
  private static final ImmutableMap<BeneficiaryValidationExceptionReason, ErrorItem>
      INVALID_BENEFICIARY_REASON_TO_ERROR_ITEM_MAPPER =
          ImmutableMap.<BeneficiaryValidationExceptionReason, ErrorResponse.ErrorItem>builder()
              .put(
                  LIMIT_REACHED,
                  ErrorItem.builder()
                      .errorCode(ErrorItem.BENEFICIARY_REJECTED_LIMIT_EXCEEDED)
                      .message("Unable to add beneficiary as allowed limit would be exceeded")
                      .build())
              .put(
                  DUPLICATE,
                  ErrorItem.builder()
                      .errorCode(ErrorResponse.ErrorItem.BENEFICIARY_REJECTED_ALREADY_EXISTS)
                      .message("Unable to add beneficiary as it already exists for this account")
                      .build())
              .put(
                  PENDING,
                  ErrorItem.builder()
                      .errorCode(ErrorItem.BENEFICIARY_REJECTED_PENDING)
                      .message("Currently unable to support modifications to this beneficiary")
                      .build())
              .put(
                  TECHNICAL,
                  ErrorItem.builder()
                      .errorCode(ErrorItem.BENEFICIARY_REJECTED_TECHNICAL_FAULT)
                      .message("Something went wrong")
                      .build())
              .build();

  @ExceptionHandler(RuntimeException.class)
  public ResponseEntity<ErrorResponse> handleUnknownErrors(
      final RuntimeException exception, final WebRequest request) {
    log.error(
        "Unhandled exception thrown. Returning 500 Internal Error. {}",
        exception.getMessage(),
        exception);
    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    ErrorResponse response =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Internal Server Error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorItem.UNEXPECTED_ERROR)
                    .message("Internal Server Error")
                    .build())
            .build();

    return ResponseEntity.status(status).body(response);
  }

  @ExceptionHandler(AccessDeniedException.class)
  public void handleInvalidJwtScope(final AccessDeniedException exception) {
    // Let spring security handle it.
    throw exception;
  }

  @ExceptionHandler(ConstraintViolationException.class)
  public ResponseEntity<ErrorResponse> constraintViolated(
      final ConstraintViolationException exception, final WebRequest webrequest) {
    log.info(
        "Handling ConstraintViolationException, returning 400 Bad Request: {}",
        exception.toString());
    final HttpStatus status = HttpStatus.BAD_REQUEST;

    final List<ErrorItem> errorItems =
        exception.getConstraintViolations().stream()
            .map(
                constraintViolation ->
                    ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_INVALID)
                        .message(
                            String.format(
                                "%s %s",
                                constraintViolation.getInvalidValue(),
                                constraintViolation.getMessage()))
                        .build())
            .collect(Collectors.toList());

    final UUID requestId = RequestIdHelper.getRequestId(webrequest);
    final ErrorResponse response =
        ErrorResponse.builder(status)
            .id(requestId)
            .message("Invalid value")
            .errors(errorItems)
            .build();
    return ResponseEntity.status(status).body(response);
  }

  @ExceptionHandler(AccountResourceNotFoundException.class)
  public ResponseEntity<ErrorResponse> resourceNotFound(
      final RuntimeException exception, final WebRequest request) {
    log.info(
        "Handling AccountResourceNotFoundException, returning 404 Not Found: {}",
        exception.toString());
    HttpStatus status = HttpStatus.NOT_FOUND;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Resource not found")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.RESOURCE_NOT_FOUND)
                    .message("Resource not found")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(BeneficiaryValidationException.class)
  public ResponseEntity<ErrorResponse> handleBeneficiaryValidationException(
      final BeneficiaryValidationException exception, final WebRequest request) {
    log.info(
        "Handling BeneficiaryValidationException, returning 409 Conflict: {}",
        exception.toString());
    final HttpStatus status = HttpStatus.CONFLICT;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Beneficiary validation error")
            .error(
                Optional.ofNullable(
                        INVALID_BENEFICIARY_REASON_TO_ERROR_ITEM_MAPPER.get(exception.getReason()))
                    .orElseThrow(
                        () ->
                            new IllegalArgumentException(
                                "Don't know how to map reason to ErrorItem: "
                                    + exception.getReason())))
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(AccountAccessDeniedException.class)
  public ResponseEntity<ErrorResponse> accountAccessDenied(
      final AccountAccessDeniedException exception, final WebRequest request) {
    log.info(
        "Handling AccountAccessDeniedException, returning 403 Forbidden: {}", exception.toString());
    final HttpStatus status = HttpStatus.FORBIDDEN;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.ACCESS_DENIED)
                    .message("Access Denied")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(InvalidScaHeadersException.class)
  public ResponseEntity<ErrorResponse> handleInvalidScaHeadersException(
      final InvalidScaHeadersException exception, final WebRequest request) {
    log.info(
        "Handling InvalidScaHeadersException, returning 400 Bad Request: {}", exception.toString());

    final List<ErrorItem> errors =
        exception.getMissingHeaders().stream()
            .map(
                header ->
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.HEADER_MISSING)
                        .message(String.format("Required SCA header missing: %s", header))
                        .path(header)
                        .build())
            .collect(Collectors.toList());

    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(RequestIdHelper.getRequestId(request))
            .message(
                String.format(
                    "Required SCA header missing - Required SCA headers: %s",
                    exception.getRequiredHeaders()))
            .errors(errors)
            .build();

    return ResponseEntity.badRequest().body(response);
  }

  @ExceptionHandler(InvalidPemKeyException.class)
  public ResponseEntity<ErrorResponse> handleInvalidPemKeyException(
      final InvalidPemKeyException exception, final WebRequest request) {
    log.info(
        "Handling InvalidPemKeyException, returning 400 Bad Request: {}", exception.toString());

    final HttpStatus badRequestStatusCode = HttpStatus.BAD_REQUEST;
    return ResponseEntity.status(badRequestStatusCode)
        .body(
            ErrorResponse.builder(badRequestStatusCode)
                .id(RequestIdHelper.getRequestId(request))
                .message("SCA key could not be read")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.HEADER_INVALID)
                        .message("SCA key must be in PEM format and Base64 encoded")
                        .path("x-ybs-sca-key")
                        .build())
                .build());
  }

  @ExceptionHandler(ScaRequiredException.class)
  public ResponseEntity<ErrorResponse> handleScaRequiredException(
      final ScaRequiredException exception, final WebRequest request) {
    log.info("Handling ScaRequiredException, returning 403 Forbidden: {}", exception.toString());

    final String challenge = exception.getChallenge();
    final HttpStatus status = HttpStatus.FORBIDDEN;
    return ResponseEntity.status(status)
        .header("x-ybs-sca-challenge", challenge)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .message("Strong customer authentication required")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.SCA_REQUIRED)
                        .message(
                            "Please sign the value in x-ybs-sca-challenge header with the request")
                        .build())
                .build());
  }

  @ExceptionHandler(InvalidScaException.class)
  public ResponseEntity<ErrorResponse> handleInvalidScaException(
      final InvalidScaException exception, final WebRequest request) {
    log.info("Handling InvalidScaException, returning 403 Forbidden: {}", exception.toString());

    final HttpStatus status = HttpStatus.FORBIDDEN;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.ACCESS_DENIED)
                        .message("Access Denied")
                        .build())
                .build());
  }

  @ExceptionHandler(InternalBeneficiaryUpdateNotSupportedException.class)
  public ResponseEntity<ErrorResponse> handleInternalBeneficiaryUpdateNotSupportedException(
      final InternalBeneficiaryUpdateNotSupportedException exception, final WebRequest request) {
    log.info(
        "Handling InternalBeneficiaryUpdateNotSupportedException, returning 400 Bad Request: {}",
        exception.toString());

    final HttpStatus badRequestStatusCode = HttpStatus.BAD_REQUEST;
    return ResponseEntity.status(badRequestStatusCode)
        .body(
            ErrorResponse.builder(badRequestStatusCode)
                .id(RequestIdHelper.getRequestId(request))
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_INVALID)
                        .message("Internal beneficiary updates are not supported")
                        .path("type")
                        .build())
                .build());
  }

  @ExceptionHandler(UnsupportedBeneficiaryFieldUpdateException.class)
  public ResponseEntity<ErrorResponse> handleUnsupportedBeneficiaryFieldUpdateException(
      final UnsupportedBeneficiaryFieldUpdateException exception, final WebRequest request) {
    log.info(
        "Handling UnsupportedBeneficiaryFieldUpdateException, returning 400 Bad Request: {}",
        exception.toString());

    final List<ErrorItem> errors =
        exception.getUnsupportedFields().stream()
            .map(
                field ->
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_INVALID)
                        .message(String.format("Update of field not supported: %s", field))
                        .path(field)
                        .build())
            .collect(Collectors.toList());

    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(RequestIdHelper.getRequestId(request))
            .message(
                String.format(
                    "Update of unsupported field requested - Supported fields: %s",
                    exception.getSupportedFields()))
            .errors(errors)
            .build();

    return ResponseEntity.badRequest().body(response);
  }

  @ExceptionHandler(BadFailureRequestChallengeException.class)
  public ResponseEntity<ErrorResponse> handleBadFailureRequestChallenge(
      final BadFailureRequestChallengeException exception, final WebRequest request) {
    log.info("Handling BadFailureRequestChallenge, returning 403 Forbidden");
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.FIELD_INVALID)
                    .message("Authenticity of the challenge could not validated")
                    .build())
            .build();

    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
  }
}
