package uk.co.ybs.digital.beneficiary.service.mapper;

import java.util.Collection;
import java.util.Optional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.service.utilities.BeneficiaryUtils;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@Component
@RequiredArgsConstructor
public class InternalBeneficiaryMapper {

  @NonNull private final BeneficiaryIdGenerator beneficiaryIdGenerator;
  @NonNull private final BeneficiaryUtils beneficiaryUtils;

  public InternalBeneficiary map(
      final ItInstruction instruction, final Collection<WorkLog> workLogs) {
    final Long sysId = instruction.getSysId();
    final String beneficiaryId =
        beneficiaryIdGenerator.generateId(InternalBeneficiary.class, sysId);
    final boolean pending = beneficiaryUtils.findMatchingWorkLog(instruction, workLogs).isPresent();
    final Long stableSysId = pending ? null : sysId;

    return InternalBeneficiary.builder()
        .sysId(stableSysId)
        .beneficiaryId(beneficiaryId)
        .accountNumber(
            Optional.ofNullable(instruction.getCreditorAccountNumber())
                .map(String::valueOf)
                .orElse(null))
        .build();
  }
}
