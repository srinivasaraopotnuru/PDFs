package uk.co.ybs.digital.beneficiary.service.processor;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryVisitor;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@Component
@RequiredArgsConstructor
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public class BeneficiaryRequestFactory {

  private final CreateExternalBeneficiaryProcessor createExternalBeneficiaryProcessor;
  private final CreateInternalBeneficiaryProcessor createInternalBeneficiaryProcessor;
  private final UpdateExternalBeneficiaryProcessor updateExternalBeneficiaryProcessor;
  private final DeleteExternalBeneficiaryProcessor deleteExternalBeneficiaryProcessor;
  private final DeleteInternalBeneficiaryProcessor deleteInternalBeneficiaryProcessor;

  public BeneficiaryRequest build(final WorkLog workLog, final LocalDateTime processTime) {
    final Beneficiary beneficiary = workLog.getMessage().getPayload().getBeneficiary();
    return beneficiary.accept(new BuildBeneficiaryRequestVisitor(workLog, processTime));
  }

  @AllArgsConstructor
  private class BuildBeneficiaryRequestVisitor implements BeneficiaryVisitor<BeneficiaryRequest> {

    private final WorkLog workLog;
    private final LocalDateTime processTime;

    @Override
    public BeneficiaryRequest visit(final ExternalBeneficiary beneficiary) {
      return build(
          beneficiary,
          createExternalBeneficiaryProcessor,
          updateExternalBeneficiaryProcessor,
          deleteExternalBeneficiaryProcessor);
    }

    @Override
    public BeneficiaryRequest visit(final InternalBeneficiary beneficiary) {
      return build(
          beneficiary,
          createInternalBeneficiaryProcessor,
          null,
          deleteInternalBeneficiaryProcessor);
    }

    private <B extends Beneficiary, DatabaseEntity> BeneficiaryRequest build(
        final B beneficiary,
        final CreateBeneficiaryProcessor<B> createProcessor,
        final ExistingBeneficiaryProcessor<B, DatabaseEntity> updateProcessor,
        final ExistingBeneficiaryProcessor<B, DatabaseEntity> deleteProcessor) {
      final WorkLog.Operation operation = workLog.getOperation();
      final Long accountNumber = workLog.getAccountNumber();
      final RequestMetadata requestMetadata = workLog.getMessage().getMetadata();
      final Long sysId = workLog.getMessage().getPayload().getSysId();
      final Integer beneficiariesLimit = workLog.getMessage().getPayload().getBeneficiariesLimit();

      switch (operation) {
        case CREATE:
          return new CreateBeneficiaryRequest<>(
              new BeneficiaryRequestArguments<>(
                  accountNumber, requestMetadata, processTime, beneficiary, beneficiariesLimit),
              createProcessor);
        case UPDATE:
          if (updateProcessor != null) {
            return new ExistingBeneficiaryRequest<>(
                new ExistingBeneficiaryRequestArguments<>(
                    accountNumber, requestMetadata, processTime, beneficiary, sysId),
                updateProcessor);
          } else {
            return new NotImplementedBeneficiaryRequest(operation, beneficiary);
          }
        case DELETE:
          return new ExistingBeneficiaryRequest<>(
              new ExistingBeneficiaryRequestArguments<>(
                  accountNumber, requestMetadata, processTime, beneficiary, sysId),
              deleteProcessor);
        default:
          throw new UnsupportedOperationException(
              String.format("Operation %s unsupported", operation));
      }
    }
  }

  private static final class NotImplementedBeneficiaryRequest implements BeneficiaryRequest {

    private final transient String message;

    public NotImplementedBeneficiaryRequest(
        final WorkLog.Operation operation, final Beneficiary beneficiary) {
      message =
          String.format("Not implemented %s %s", operation, beneficiary.getClass().getSimpleName());
    }

    @Override
    public ResolvedBeneficiaryRequest resolve() {
      throw new UnsupportedOperationException(message);
    }
  }
}
