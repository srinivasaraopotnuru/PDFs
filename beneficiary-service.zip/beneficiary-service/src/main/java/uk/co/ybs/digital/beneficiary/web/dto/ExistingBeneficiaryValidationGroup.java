package uk.co.ybs.digital.beneficiary.web.dto;

/**
 * For use with the {@link org.springframework.validation.annotation.Validated} annotation, allowing
 * certain validation to be skipped when creating a beneficiary.
 */
public interface ExistingBeneficiaryValidationGroup {}
