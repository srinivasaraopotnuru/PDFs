package uk.co.ybs.digital.beneficiary.service;

import java.time.Duration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.exception.ScaRequiredException;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.service.sca.BeneficiaryChallengePayloadBody;
import uk.co.ybs.digital.beneficiary.service.sca.BeneficiaryIdChallengePayloadBody;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@Component
@RequiredArgsConstructor
@Slf4j
public class ScaManager {

  private static final Duration SCA_CHALLENGE_TIMEOUT = Duration.ofMinutes(1);

  private final ScaChallengeService scaChallengeService;
  private final BeneficiaryAuditor beneficiaryAuditor;

  public void validateDeleteSca(
      final WorkLog.Operation operation,
      final String beneficiaryId,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    final BeneficiaryIdChallengePayloadBody challengePayloadBody =
        new BeneficiaryIdChallengePayloadBody(operation, beneficiaryId);
    validateSca(
        operation,
        challengePayloadBody,
        BeneficiaryIdChallengePayloadBody.class,
        metadata,
        scaCredentials);
  }

  public void validateSca(
      final WorkLog.Operation operation,
      final Beneficiary beneficiary,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    final BeneficiaryChallengePayloadBody challengePayloadBody =
        new BeneficiaryChallengePayloadBody(operation, beneficiary);
    validateSca(
        operation,
        challengePayloadBody,
        BeneficiaryChallengePayloadBody.class,
        metadata,
        scaCredentials);
  }

  private <T> void validateSca(
      final WorkLog.Operation operation,
      final T challengePayloadBody,
      final Class<T> payloadBodyClass,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    if (scaCredentials == null) {
      log.info("SCA required for beneficiary {}", operation);
      final String generatedChallenge =
          scaChallengeService.generateChallenge(
              challengePayloadBody, metadata.getSessionId(), SCA_CHALLENGE_TIMEOUT);
      beneficiaryAuditor.auditBeneficiaryChallenge(metadata);
      throw new ScaRequiredException(generatedChallenge);
    }

    log.info("Validating SCA for beneficiary {}", operation);
    try {
      scaChallengeService.validateChallenge(
          scaCredentials, challengePayloadBody, payloadBodyClass, metadata.getSessionId());
      beneficiaryAuditor.auditBeneficiaryChallengeSuccess(metadata);
    } catch (final InvalidScaException exception) {
      beneficiaryAuditor.auditBeneficiaryChallengeFailure(metadata, "Invalid Challenge Response");
      throw exception;
    }
  }
}
