package uk.co.ybs.digital.beneficiary.service;

public class BadFailureRequestChallengeException extends RuntimeException {
  private static final long serialVersionUID = 1L;
}
