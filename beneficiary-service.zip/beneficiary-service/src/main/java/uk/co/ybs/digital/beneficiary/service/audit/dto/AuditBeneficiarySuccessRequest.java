package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(
    builder = AuditBeneficiarySuccessRequest.AuditBeneficiarySuccessRequestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditBeneficiarySuccessRequest {

  @NonNull String ipAddress;

  @NonNull BeneficiaryInformation beneficiaryInformation;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditBeneficiarySuccessRequestBuilder {}
}
