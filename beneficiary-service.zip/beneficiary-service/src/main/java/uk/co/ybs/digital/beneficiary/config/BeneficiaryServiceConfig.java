package uk.co.ybs.digital.beneficiary.config;

import java.time.Clock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryServiceProperties;

@Configuration
@EnableConfigurationProperties(BeneficiaryServiceProperties.class)
@Slf4j
public class BeneficiaryServiceConfig {
  @Bean
  public Clock clock() {
    // The application should be run in UK timezone for consistency with other
    // YBS timezone handling.
    final Clock systemClock = Clock.systemDefaultZone();
    log.info("System clock is: {}", systemClock);

    return systemClock;
  }
}
