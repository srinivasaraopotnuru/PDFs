package uk.co.ybs.digital.beneficiary.service.processor;

import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;

public interface ResolvedBeneficiaryRequest {
  void execute();

  void auditSuccess();

  void auditFailure(BeneficiaryValidationExceptionReason reason);
}
