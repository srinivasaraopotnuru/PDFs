package uk.co.ybs.digital.beneficiary.repository.core;

import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.beneficiary.model.core.Metadata;

public interface MetadataRepository extends JpaRepository<Metadata, Long> {}
