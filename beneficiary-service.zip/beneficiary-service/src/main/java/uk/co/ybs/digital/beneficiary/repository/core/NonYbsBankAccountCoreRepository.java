package uk.co.ybs.digital.beneficiary.repository.core;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public interface NonYbsBankAccountCoreRepository extends JpaRepository<NonYbsBankAccount, Long> {}
