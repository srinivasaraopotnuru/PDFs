package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder(toBuilder = true)
@AllArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({
  @JsonSubTypes.Type(name = "EXTERNAL", value = ExternalBeneficiaryInformation.class),
  @JsonSubTypes.Type(name = "INTERNAL", value = InternalBeneficiaryInformation.class)
})
public abstract class BeneficiaryInformation {
  @NonNull private final String accountNumber;

  @NonNull private final String payeeAccountNumber;
}
