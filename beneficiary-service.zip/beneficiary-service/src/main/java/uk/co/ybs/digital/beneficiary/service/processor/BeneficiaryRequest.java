package uk.co.ybs.digital.beneficiary.service.processor;

public interface BeneficiaryRequest {
  ResolvedBeneficiaryRequest resolve();
}
