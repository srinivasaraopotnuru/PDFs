package uk.co.ybs.digital.beneficiary.service.processor;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;

@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ResolvedExistingBeneficiaryRequest<B extends Beneficiary, DatabaseEntity>
    implements ResolvedBeneficiaryRequest {

  @NonNull private final ExistingBeneficiaryRequestArguments<B> arguments;
  @NonNull private final DatabaseEntity databaseEntity;
  @NonNull private final ExistingBeneficiaryProcessor<B, DatabaseEntity> processor;

  @Override
  public void execute() {
    processor.execute(arguments, databaseEntity);
  }

  @Override
  public void auditSuccess() {
    processor.auditSuccess(arguments, databaseEntity);
  }

  @Override
  public void auditFailure(final BeneficiaryValidationExceptionReason reason) {
    processor.auditFailure(arguments, databaseEntity, reason);
  }
}
