package uk.co.ybs.digital.beneficiary.model.core;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "V$Database")
public class Metadata {

  @Id
  @Column(name = "DBID", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "CREATED", nullable = false)
  private LocalDateTime created;
}
