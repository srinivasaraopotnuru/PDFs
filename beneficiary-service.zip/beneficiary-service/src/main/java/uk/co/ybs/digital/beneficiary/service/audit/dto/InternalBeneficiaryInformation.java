package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.Value;
import lombok.experimental.SuperBuilder;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(toBuilder = true)
@JsonDeserialize(
    builder = InternalBeneficiaryInformation.InternalBeneficiaryInformationBuilderImpl.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class InternalBeneficiaryInformation extends BeneficiaryInformation {

  @JsonPOJOBuilder(withPrefix = "")
  static final class InternalBeneficiaryInformationBuilderImpl
      extends InternalBeneficiaryInformationBuilder<
          InternalBeneficiaryInformation, InternalBeneficiaryInformationBuilderImpl> {}
}
