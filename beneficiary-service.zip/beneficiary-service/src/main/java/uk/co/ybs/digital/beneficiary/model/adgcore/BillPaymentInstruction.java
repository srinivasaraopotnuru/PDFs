package uk.co.ybs.digital.beneficiary.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import uk.co.ybs.digital.beneficiary.model.YesConverter;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "BILL_PAYM_INSTRUCTIONS")
public class BillPaymentInstruction {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private Long sysId;

  @ManyToOne
  @JoinColumn(name = "NYBAC_SYSID", nullable = false)
  private NonYbsBankAccount nonYbsBankAccount;

  @Column(name = "ACCNUM_ACCOUNT_NUMBER", nullable = false)
  private Long accountNumber;

  @Column(name = "STATUS", nullable = false)
  private String status;

  @Column(name = "AVAILABLE_ATM", nullable = false)
  @Convert(converter = YesConverter.class)
  private boolean availableAtm;

  @Column(name = "BILL_REFERENCE")
  private String reference;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "INSTRUCTION_NAME")
  private String memorableName;
}
