package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(
    builder =
        AuditBeneficiaryChallengeSuccessRequest.AuditBeneficiaryChallengeSuccessRequestBuilder
            .class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditBeneficiaryChallengeSuccessRequest {
  String ipAddress;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditBeneficiaryChallengeSuccessRequestBuilder {}
}
