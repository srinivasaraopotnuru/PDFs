package uk.co.ybs.digital.beneficiary.web.dto;

public interface BeneficiaryVisitor<T> {
  T visit(ExternalBeneficiary beneficiary);

  T visit(InternalBeneficiary beneficiary);
}
