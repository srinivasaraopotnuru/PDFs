package uk.co.ybs.digital.beneficiary.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import java.util.UUID;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Singular;
import lombok.Value;
import org.springframework.http.HttpStatus;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonDeserialize(builder = ErrorResponse.ErrorResponseBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public final class ErrorResponse {
  @NonNull UUID id;

  @NonNull String code;

  @NonNull String message;

  @Singular List<? extends ErrorItem> errors;

  public static ErrorResponseBuilder builder() {
    return new ErrorResponseBuilder();
  }

  public static ErrorResponseBuilder builder(final HttpStatus status) {
    return builder()
        .code(String.format("%s %s", status.value(), status.getReasonPhrase()))
        .message(status.getReasonPhrase());
  }

  public boolean containsOnlyErrorCode(final String errorCode) {
    if (errors.size() == 1) {
      return errors.get(0).getErrorCode().equals(errorCode);
    }
    return false;
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ErrorResponseBuilder {}

  @Value
  @Builder
  @AllArgsConstructor(access = AccessLevel.PRIVATE)
  @JsonDeserialize(builder = ErrorItem.ErrorItemBuilder.class)
  public static class ErrorItem {
    public static final String ACCESS_DENIED = "AccessDenied";
    public static final String INVALID_REQUEST_SIGNATURE = "AccessDenied.InvalidRequestSignature";
    public static final String FIELD_INVALID = "Field.Invalid";
    public static final String FIELD_MISSING = "Field.Missing";
    public static final String HEADER_INVALID = "Header.Invalid";
    public static final String HEADER_MISSING = "Header.Missing";
    public static final String RESOURCE_INVALID_FORMAT = "Resource.InvalidFormat";
    public static final String RESOURCE_NOT_FOUND = "Resource.NotFound";
    public static final String UNAUTHORIZED = "Unauthorized";
    public static final String UNEXPECTED_ERROR = "UnexpectedError";
    public static final String UNSUPPORTED_METHOD = "Unsupported.Method";
    public static final String BENEFICIARY_REJECTED_LIMIT_EXCEEDED = "Beneficiary.Limit";
    public static final String BENEFICIARY_REJECTED_ALREADY_EXISTS = "Beneficiary.Exists";
    public static final String BENEFICIARY_REJECTED_PENDING = "Beneficiary.Pending";
    public static final String BENEFICIARY_REJECTED_TECHNICAL_FAULT = "Beneficiary.Technical";
    public static final String SCA_REQUIRED = "SCA.Required";
    public static final String NO_CUSTOMER_RELATIONSHIP = "AccessDenied.NoCustomerRelationship";
    public static final String CONFLICT = "Resource.Conflict";

    @NonNull String errorCode;

    @NonNull String message;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String path;

    @JsonPOJOBuilder(withPrefix = "")
    public static class ErrorItemBuilder {}
  }
}
