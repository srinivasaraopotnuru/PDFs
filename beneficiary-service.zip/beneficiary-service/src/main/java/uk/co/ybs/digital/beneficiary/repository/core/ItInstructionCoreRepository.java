package uk.co.ybs.digital.beneficiary.repository.core;

import java.time.LocalDateTime;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public interface ItInstructionCoreRepository extends JpaRepository<ItInstruction, Long> {

  @Procedure(procedureName = "PACK_ATM.PR_INTERNAL_TRANSFERS")
  void updateInternalBeneficiaryAuthenticRecord(@Param("PN_SAVACC_ACCOUNT") Long pnSavaccAccount);

  @Query(
      "SELECT COUNT(iti) "
          + "FROM ItInstruction iti "
          + "WHERE iti.debtorAccountNumber = :debtorAccountNumber "
          + "AND iti.creditorAccountNumber = :creditorAccountNumber "
          + "AND iti.status = 'ACTIVE' "
          + "AND iti.availableAtm = 'Y' "
          + "AND (iti.endDate > :now OR iti.endDate IS NULL) ")
  int findExistingInternalBeneficiaries(
      @Param("debtorAccountNumber") Long debtorAccountNumber,
      @Param("creditorAccountNumber") Long creditorAccountNumber,
      @Param("now") LocalDateTime now);

  @Query(
      "SELECT COUNT(iti) "
          + "FROM ItInstruction iti "
          + "WHERE iti.debtorAccountNumber = :debtorAccountNumber "
          + "AND iti.status = 'ACTIVE' "
          + "AND iti.availableAtm = 'Y' "
          + "AND (iti.endDate > :now OR iti.endDate IS NULL) ")
  int findActiveInternalBeneficiaries(
      @Param("debtorAccountNumber") Long debtorAccountNumber, @Param("now") LocalDateTime now);
}
