package uk.co.ybs.digital.beneficiary.service;

import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;

@Value
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ExternalUpdateBeneficiaryInformationWrapper {
  @NonNull ExternalBeneficiaryInformation beneficiaryInformation;
  @NonNull ExternalUpdateBeneficiaryInformation updateBeneficiaryInformation;
}
