package uk.co.ybs.digital.beneficiary.model.adgcore;

import lombok.Value;

@Value
public class AccountActivityGroup {
  private final Long accountNumber;
  private final String activityGroupCode;
}
