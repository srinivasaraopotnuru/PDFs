package uk.co.ybs.digital.beneficiary.model.core;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import uk.co.ybs.digital.beneficiary.model.YesConverter;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "IT_INSTRUCTIONS")
public class ItInstruction {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ITINST_SYSID_SEQ")
  @SequenceGenerator(
      sequenceName = "ITINST_SYSID_SEQ",
      allocationSize = 1,
      name = "ITINST_SYSID_SEQ")
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "ACCNUM_ACCOUNT_NUMBER", nullable = false)
  private Long debtorAccountNumber;

  @Column(name = "TRFREQ_CODE", nullable = false)
  private String code;

  @Column(name = "AVAILABLE_ATM", nullable = false)
  @Convert(converter = YesConverter.class)
  private boolean availableAtm;

  @Column(name = "NEXT_PAYMENT_DATE")
  private LocalDateTime nextPaymentDate;

  @Column(name = "LOANAC_ACCGRP_NUM")
  private Long loanAccountGroupNumber;

  @Column(name = "LOANAC_LATYPE_CODE")
  private Integer loanAccountTypeCode;

  @Column(name = "ACCNUM_ACCOUNT_NUMBER_THE_PAYM", nullable = false)
  private Long creditorAccountNumber;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "LAST_PAYMENT_DATE")
  private LocalDateTime lastPaymentDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "STATUS", nullable = false)
  private String status;

  @Column(name = "ATM_ORDER_NUMBER")
  private int atmOrderNumber;

  @Column(name = "CREATED_AT", nullable = false)
  private String createdAt;

  @Column(name = "CREATED_BY", nullable = false)
  private String createdBy;

  @Column(name = "CREATED_DATE", nullable = false)
  private LocalDateTime createdDate;

  @Column(name = "ENDED_AT")
  private String endedAt;

  @Column(name = "ENDED_BY")
  private String endedBy;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Column(name = "PAYMTH_SYSID")
  private Long paymentSysId;

  @Column(name = "SOURCE_PAY_UTR")
  private String sourcePaymentUtr;
}
