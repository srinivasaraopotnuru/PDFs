package uk.co.ybs.digital.beneficiary.service.processor;

import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.LIMIT_REACHED;

import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;
import uk.co.ybs.digital.beneficiary.repository.core.ItInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@Slf4j
@RequiredArgsConstructor
@Component
@Transactional("beneficiaryProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.beneficiary.processor",
    name = "enabled",
    havingValue = "true")
public class CreateInternalBeneficiaryProcessor
    implements CreateBeneficiaryProcessor<InternalBeneficiary> {

  private static final String STATUS = "ACTIVE";
  private static final String CODE = "ATM";

  private final BeneficiaryInformationFactory beneficiaryInformationFactory;
  private final BeneficiaryAuditor beneficiaryAuditor;
  private final ItInstructionCoreRepository itInstructionCoreRepository;

  @Override
  public void execute(final BeneficiaryRequestArguments<InternalBeneficiary> arguments) {
    final long accountNumber = arguments.getAccountNumber();
    final LocalDateTime processTime = arguments.getProcessTime();
    final InternalBeneficiary beneficiary = arguments.getBeneficiary();
    validateDuplicateRecords(accountNumber, beneficiary, processTime);
    validateProductLimit(accountNumber, processTime, arguments.getBeneficiariesLimit());

    final long beneficiaryAccountNumberAsLong = Long.parseLong(beneficiary.getAccountNumber());

    itInstructionCoreRepository.saveAndFlush(
        createItInstruction(accountNumber, beneficiaryAccountNumberAsLong, processTime));
    itInstructionCoreRepository.updateInternalBeneficiaryAuthenticRecord(accountNumber);
  }

  @Override
  public void auditSuccess(final BeneficiaryRequestArguments<InternalBeneficiary> arguments) {
    final InternalBeneficiaryInformation beneficiaryInformation =
        beneficiaryInformationFactory.buildInternal(
            arguments.getAccountNumber(), arguments.getBeneficiary());
    beneficiaryAuditor.auditBeneficiaryCreateSuccess(
        beneficiaryInformation, arguments.getRequestMetadata());
  }

  @Override
  public void auditFailure(
      final BeneficiaryRequestArguments<InternalBeneficiary> arguments,
      final BeneficiaryValidationExceptionReason reason) {
    final InternalBeneficiaryInformation beneficiaryInformation =
        beneficiaryInformationFactory.buildInternal(
            arguments.getAccountNumber(), arguments.getBeneficiary());
    beneficiaryAuditor.auditBeneficiaryCreateFailure(
        beneficiaryInformation, reason.getDescription(), arguments.getRequestMetadata());
  }

  private void validateProductLimit(
      final long accountNumber, final LocalDateTime processTime, final Integer beneficiariesLimit) {
    final int numberOfExistingBeneficiaries =
        itInstructionCoreRepository.findActiveInternalBeneficiaries(accountNumber, processTime);

    if (numberOfExistingBeneficiaries >= beneficiariesLimit) {
      log.info(
          "Adding a new internal beneficiary would exceed permitted limit of: {} for account: {}",
          beneficiariesLimit,
          accountNumber);
      throw new BeneficiaryValidationException(
          String.format("Internal beneficiary limit exceeded for account: %s", accountNumber),
          LIMIT_REACHED);
    }
  }

  public void validateDuplicateRecords(
      final long accountNumber,
      final InternalBeneficiary request,
      final LocalDateTime processTime) {
    final int existingRecordsCount =
        itInstructionCoreRepository.findExistingInternalBeneficiaries(
            accountNumber, Long.parseLong(request.getAccountNumber()), processTime);

    if (existingRecordsCount > 0) {
      log.info(
          "Requested internal beneficiary for account {} already exists: accountNumber: {}",
          accountNumber,
          request.getAccountNumber());
      throw new BeneficiaryValidationException(
          String.format("Requested beneficiary already exists for account: %d", accountNumber),
          DUPLICATE);
    }
  }

  private static ItInstruction createItInstruction(
      final long debtorAccountNumber, final long creditorAccountNumber, final LocalDateTime now) {
    return ItInstruction.builder()
        .debtorAccountNumber(debtorAccountNumber)
        .code(CODE)
        .availableAtm(true)
        .creditorAccountNumber(creditorAccountNumber)
        .startDate(now)
        .status(STATUS)
        .createdAt(BeneficiaryProcessorConstants.AUDIT_AT)
        .createdBy(BeneficiaryProcessorConstants.AUDIT_BY)
        .createdDate(now)
        .build();
  }
}
