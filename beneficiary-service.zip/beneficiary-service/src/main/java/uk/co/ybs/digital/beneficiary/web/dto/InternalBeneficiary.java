package uk.co.ybs.digital.beneficiary.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.Value;
import lombok.experimental.SuperBuilder;
import uk.co.ybs.digital.beneficiary.web.validators.InternalAccountNumber;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(toBuilder = true)
@JsonDeserialize(builder = InternalBeneficiary.InternalBeneficiaryBuilderImpl.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class InternalBeneficiary extends Beneficiary {

  @NotNull(message = "You must specify an account number")
  @InternalAccountNumber(message = "Account number must be 10 digits")
  @Schema(required = true, example = "1234567890")
  String accountNumber;

  @Override
  public <T> T accept(final BeneficiaryVisitor<T> visitor) {
    return visitor.visit(this);
  }

  @JsonPOJOBuilder(withPrefix = "")
  static final class InternalBeneficiaryBuilderImpl
      extends InternalBeneficiaryBuilder<InternalBeneficiary, InternalBeneficiaryBuilderImpl> {}
}
