package uk.co.ybs.digital.beneficiary.model.core;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import uk.co.ybs.digital.beneficiary.model.YesConverter;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "BILL_PAYM_INSTRUCTIONS")
public class BillPaymentInstruction {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "BPINST_SYSID_SEQ")
  @SequenceGenerator(
      sequenceName = "BPINST_SYSID_SEQ",
      allocationSize = 1,
      name = "BPINST_SYSID_SEQ")
  @EqualsAndHashCode.Include
  private Long sysId;

  @ManyToOne
  @JoinColumn(name = "NYBAC_SYSID", nullable = false)
  private NonYbsBankAccount nonYbsBankAccount;

  @Column(name = "ACCNUM_ACCOUNT_NUMBER", nullable = false)
  private Long accountNumber;

  @Column(name = "STATUS", nullable = false)
  private String status;

  @Column(name = "AVAILABLE_ATM", nullable = false)
  @Convert(converter = YesConverter.class)
  private boolean availableAtm;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "BILL_REFERENCE")
  private String reference;

  @Column(name = "ATM_ORDER_NUMBER")
  private Integer atmOrderNumber;

  @Column(name = "CREATED_AT", nullable = false)
  private String createdAt;

  @Column(name = "CREATED_BY", nullable = false)
  private String createdBy;

  @Column(name = "CREATED_DATE", nullable = false)
  private LocalDateTime createdDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "ENDED_AT")
  private String endedAt;

  @Column(name = "ENDED_BY")
  private String endedBy;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Column(name = "FP_TRUST_STATUS", nullable = false)
  @Convert(converter = YesConverter.class)
  private boolean fpTrustStatus;

  @Column(name = "FP_CHANGE_REASON", nullable = false)
  private String fpChangeReason;

  @Column(name = "INSTRUCTION_NAME")
  private String memorableName;
}
