package uk.co.ybs.digital.beneficiary.service.utilities;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.model.adgcore.AccountActivityGroup;
import uk.co.ybs.digital.beneficiary.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.beneficiary.model.adgcore.SavingProduct;
import uk.co.ybs.digital.beneficiary.repository.adgcore.ActivityPlayerRepository;
import uk.co.ybs.digital.beneficiary.repository.adgcore.SavingProductRepository;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@Component
@AllArgsConstructor
public class AccountAccessValidator {

  private static final String REQUIRED_ACTIVITY_GROUP_CODE =
      ActivityTypeGroup.ACTIVITY_GROUP_CODE_AISP;

  private final SavingProductRepository savingProductRepository;
  private final ActivityPlayerRepository activityPlayerRepository;

  public Set<String> validateAccountAccess(
      final String accountNumber,
      final RequestMetadata metadata,
      final Collection<String> activityTypeGroupCodesToRetrieve,
      final LocalDateTime now) {
    validateAccountExistenceAndBrand(accountNumber, metadata);
    return validateActivityGroup(accountNumber, metadata, activityTypeGroupCodesToRetrieve, now);
  }

  private void validateAccountExistenceAndBrand(
      final String accountNumber, final RequestMetadata metadata) {
    final SavingProduct savingProduct =
        savingProductRepository
            .findBySavingAccountNumber(Long.parseLong(accountNumber))
            .orElseThrow(
                () ->
                    new AccountResourceNotFoundException(
                        String.format("Account %s not found", accountNumber)));

    if (!metadata.getBrandCode().equals(savingProduct.getBrandCode())) {
      throw new AccountAccessDeniedException(
          String.format(
              "Account %s is for brand %s, but request is for brand %s",
              accountNumber, savingProduct.getBrandCode(), metadata.getBrandCode()));
    }
  }

  private Set<String> validateActivityGroup(
      final String accountNumber,
      final RequestMetadata metadata,
      final Collection<String> activityTypeGroupCodesToRetrieve,
      final LocalDateTime now) {
    final Collection<String> allActivityTypeGroupCodesToRetrieve =
        new HashSet<>(activityTypeGroupCodesToRetrieve);
    allActivityTypeGroupCodesToRetrieve.add(REQUIRED_ACTIVITY_GROUP_CODE);

    final Collection<AccountActivityGroup> accountActivityGroups =
        activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            Long.parseLong(metadata.getPartyId()),
            allActivityTypeGroupCodesToRetrieve,
            Collections.singleton(Long.parseLong(accountNumber)),
            now);

    final Set<String> activityTypeGroupCodes =
        accountActivityGroups.stream()
            .map(AccountActivityGroup::getActivityGroupCode)
            .collect(Collectors.toSet());

    if (!activityTypeGroupCodes.contains(REQUIRED_ACTIVITY_GROUP_CODE)) {
      throw new AccountAccessDeniedException(
          String.format(
              "Customer %s does not have a %s relationship with account %s",
              metadata.getPartyId(), REQUIRED_ACTIVITY_GROUP_CODE, accountNumber));
    }

    activityTypeGroupCodes.retainAll(activityTypeGroupCodesToRetrieve);

    return activityTypeGroupCodes;
  }
}
