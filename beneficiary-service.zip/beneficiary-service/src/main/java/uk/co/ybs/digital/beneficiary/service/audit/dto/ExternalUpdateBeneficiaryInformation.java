package uk.co.ybs.digital.beneficiary.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(
    builder =
        ExternalUpdateBeneficiaryInformation.ExternalUpdateBeneficiaryInformationBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ExternalUpdateBeneficiaryInformation {
  String reference;
  String memorableName;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ExternalUpdateBeneficiaryInformationBuilder {}
}
