package uk.co.ybs.digital.beneficiary.service.audit;

import io.micrometer.core.annotation.Timed;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiarySuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryViewRequest;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class AuditService {

  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling audit service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Audit service returned error status: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private final WebClient auditServiceWebClient;

  public void auditBeneficiariesView(
      final AuditBeneficiaryViewRequest request, final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/view", request, requestMetadata);
  }

  public void auditBeneficiaryCreateSuccess(
      final AuditBeneficiarySuccessRequest request, final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/create/success", request, requestMetadata);
  }

  public void auditBeneficiaryCreateFailure(
      final AuditBeneficiaryFailureRequest request, final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/create/failure", request, requestMetadata);
  }

  public void auditBeneficiaryUpdateSuccess(
      final AuditBeneficiaryUpdateSuccessRequest request, final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/update/success", request, requestMetadata);
  }

  public void auditBeneficiaryUpdateFailure(
      final AuditBeneficiaryUpdateFailureRequest request, final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/update/failure", request, requestMetadata);
  }

  public void auditBeneficiaryDeleteSuccess(
      final AuditBeneficiarySuccessRequest request, final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/delete/success", request, requestMetadata);
  }

  public void auditBeneficiaryDeleteFailure(
      final AuditBeneficiaryFailureRequest request, final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/delete/failure", request, requestMetadata);
  }

  public void auditBeneficiaryChallenge(
      final AuditBeneficiaryChallengeRequest request, final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/authentication/challenge", request, requestMetadata);
  }

  public void auditBeneficiaryChallengeSuccess(
      final AuditBeneficiaryChallengeSuccessRequest request,
      final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/authentication/success", request, requestMetadata);
  }

  public void auditBeneficiaryChallengeFailure(
      final AuditBeneficiaryChallengeFailureRequest request,
      final RequestMetadata requestMetadata) {
    postAudit("/beneficiary/authentication/failure", request, requestMetadata);
  }

  private void postAudit(
      final String uri, final Object requestPayload, final RequestMetadata requestMetadata) {
    auditServiceWebClient
        .post()
        .uri(uri)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + requestMetadata.getForwardingAuth())
        .header(REQUEST_ID_HEADER, requestMetadata.getRequestId().toString())
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(requestPayload)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .toBodilessEntity()
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AuditServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .block();
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AuditServiceException);
  }

  private Mono<AuditServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new AuditServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
