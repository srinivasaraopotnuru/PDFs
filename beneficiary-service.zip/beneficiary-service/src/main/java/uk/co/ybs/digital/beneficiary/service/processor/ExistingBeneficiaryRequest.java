package uk.co.ybs.digital.beneficiary.service.processor;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;

@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ExistingBeneficiaryRequest<B extends Beneficiary, DatabaseEntity>
    implements BeneficiaryRequest {

  @NonNull private final ExistingBeneficiaryRequestArguments<B> arguments;
  @NonNull private final ExistingBeneficiaryProcessor<B, DatabaseEntity> processor;

  @Override
  public ResolvedBeneficiaryRequest resolve() {
    final DatabaseEntity databaseEntity = processor.resolve(arguments);
    return new ResolvedExistingBeneficiaryRequest<>(arguments, databaseEntity, processor);
  }
}
