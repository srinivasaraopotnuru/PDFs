package uk.co.ybs.digital.beneficiary.model.core;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import uk.co.ybs.digital.beneficiary.model.YesConverter;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "FINANCIAL_INSTITUTIONS")
public class FinancialInstitution {
  @Id
  @Column(name = "PARTY_SYSID", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "SORT_CODE")
  private Long sortCode;

  @Column(name = "SUB_BRANCH")
  @Convert(converter = YesConverter.class)
  private boolean subBranch;

  @Column(name = "BANK_NAME")
  private String bankName;

  @Column(name = "CLOSED_DATE")
  private LocalDateTime closedDate;
}
