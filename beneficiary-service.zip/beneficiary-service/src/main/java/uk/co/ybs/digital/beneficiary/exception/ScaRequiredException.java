package uk.co.ybs.digital.beneficiary.exception;

import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public class ScaRequiredException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  @NonNull private final String challenge;
}
