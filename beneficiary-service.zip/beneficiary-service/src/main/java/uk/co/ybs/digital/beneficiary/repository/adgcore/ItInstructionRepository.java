package uk.co.ybs.digital.beneficiary.repository.adgcore;

import java.time.LocalDateTime;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;

public interface ItInstructionRepository extends JpaRepository<ItInstruction, Long> {

  @Query(
      "SELECT iti "
          + "FROM ItInstruction iti "
          + "WHERE iti.debtorAccountNumber = :debtorAccountNumber "
          + "AND iti.status = 'ACTIVE' "
          + "AND iti.availableAtm = 'Y' "
          + "AND (iti.endDate > :now OR iti.endDate IS NULL)")
  Collection<ItInstruction> findActiveInternalBeneficiaries(
      @Param("debtorAccountNumber") Long debtorAccountNumber, @Param("now") LocalDateTime now);
}
