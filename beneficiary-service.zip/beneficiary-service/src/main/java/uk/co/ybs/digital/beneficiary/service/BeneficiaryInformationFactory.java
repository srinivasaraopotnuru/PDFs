package uk.co.ybs.digital.beneficiary.service;

import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@Component
@Slf4j
public class BeneficiaryInformationFactory {

  public ExternalBeneficiaryInformation buildExternal(
      final long accountNumber, final ExternalBeneficiary beneficiary) {
    return ExternalBeneficiaryInformation.builder()
        .payeeName(beneficiary.getName())
        .payeeSortCode(beneficiary.getAccountSortCode())
        .reference(beneficiary.getReference())
        .memorableName(beneficiary.getMemorableName())
        .payeeAccountNumber(beneficiary.getAccountNumber())
        .accountNumber(padAccountNumber(accountNumber))
        .build();
  }

  public InternalBeneficiaryInformation buildInternal(
      final long accountNumber, final InternalBeneficiary beneficiary) {
    return InternalBeneficiaryInformation.builder()
        .payeeAccountNumber(beneficiary.getAccountNumber())
        .accountNumber(padAccountNumber(accountNumber))
        .build();
  }

  public ExternalUpdateBeneficiaryInformationWrapper buildExternalUpdate(
      final long accountNumber,
      final ExternalBeneficiary request,
      final ExternalBeneficiary originalBeneficiary) {
    final ExternalBeneficiaryInformation beneficiaryInformation =
        buildExternal(accountNumber, originalBeneficiary);
    final ExternalUpdateBeneficiaryInformation updateBeneficiaryInformation =
        buildExternalUpdate(request);
    return new ExternalUpdateBeneficiaryInformationWrapper(
        beneficiaryInformation, updateBeneficiaryInformation);
  }

  private ExternalUpdateBeneficiaryInformation buildExternalUpdate(
      final ExternalBeneficiary request) {
    return ExternalUpdateBeneficiaryInformation.builder()
        .reference(request.getReference())
        .memorableName(request.getMemorableName())
        .build();
  }

  private String padAccountNumber(final long accountNumber) {
    return Strings.padStart(String.valueOf(accountNumber), 10, '0');
  }
}
