package uk.co.ybs.digital.beneficiary.service.mapper;

import com.google.common.base.Strings;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;

@Component
public class ExternalBeneficiaryDatabaseEntityMapper {

  public ExternalBeneficiary map(final BillPaymentInstruction instruction) {
    final NonYbsBankAccount nonYbsBankAccount = instruction.getNonYbsBankAccount();
    return ExternalBeneficiary.builder()
        .accountSortCode(padNumber(nonYbsBankAccount.getSortCode(), 6))
        .accountNumber(padNumber(nonYbsBankAccount.getAccountNumber(), 8))
        .name(nonYbsBankAccount.getName())
        .reference(instruction.getReference())
        .memorableName(instruction.getMemorableName())
        .build();
  }

  private String padNumber(final Number number, final int minimumLength) {
    return Strings.padStart(String.valueOf(number), minimumLength, '0');
  }
}
