package uk.co.ybs.digital.beneficiary.service;

import java.time.Clock;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.InternalBeneficiaryUpdateNotSupportedException;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation;
import uk.co.ybs.digital.beneficiary.repository.adgcore.BillPaymentInstructionRepository;
import uk.co.ybs.digital.beneficiary.repository.adgcore.ItInstructionRepository;
import uk.co.ybs.digital.beneficiary.repository.digitalbeneficiary.WorkLogRepository;
import uk.co.ybs.digital.beneficiary.service.account.AccountService;
import uk.co.ybs.digital.beneficiary.service.account.dto.AccountDetails;
import uk.co.ybs.digital.beneficiary.service.mapper.BeneficiaryListMapper;
import uk.co.ybs.digital.beneficiary.service.product.ProductService;
import uk.co.ybs.digital.beneficiary.service.product.dto.ProductInfo;
import uk.co.ybs.digital.beneficiary.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.beneficiary.service.utilities.ProductBeneficiaryLimitValidator;
import uk.co.ybs.digital.beneficiary.service.utilities.SoaBeneficiaryValidator;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryLimit;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryLimitResponse;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryVisitor;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@Service
@RequiredArgsConstructor
@Slf4j
public class BeneficiaryService {

  private static final Duration WORK_LOG_RETRIEVE_CUT_OFF = Duration.ofDays(1);

  private final AccountAccessValidator accountAccessValidator;
  private final SoaBeneficiaryValidator soaBeneficiaryValidator;
  private final ProductService productService;
  private final BillPaymentInstructionRepository billPaymentInstructionRepository;
  private final ItInstructionRepository itInstructionRepository;
  private final WorkLogRepository workLogRepository;
  private final BeneficiaryListMapper beneficiaryListMapper;
  private final BeneficiaryServiceProperties beneficiaryServiceProperties;
  private final AccountService accountService;
  private final ScaManager scaManager;
  private final Clock clock;
  private final ProductBeneficiaryLimitValidator productBeneficiaryLimitValidator;

  public List<Beneficiary> getBeneficiaries(
      final String accountNumber, final RequestMetadata metadata) {
    final LocalDateTime now = LocalDateTime.now(clock);

    accountAccessValidator.validateAccountAccess(
        accountNumber, metadata, Collections.emptySet(), now);

    final long debtorAccountNumber = Long.parseLong(accountNumber);
    final Collection<BillPaymentInstruction> externalInstructions =
        billPaymentInstructionRepository.findActiveExternalBeneficiaries(debtorAccountNumber, now);
    final Collection<ItInstruction> internalInstructions =
        itInstructionRepository.findActiveInternalBeneficiaries(debtorAccountNumber, now);

    final LocalDateTime workLogRetrieveCutOff = now.minus(WORK_LOG_RETRIEVE_CUT_OFF);
    final Collection<WorkLog> pendingWorkLogs =
        workLogRepository.findRequestsAfterDate(workLogRetrieveCutOff, debtorAccountNumber);

    return beneficiaryListMapper.map(externalInstructions, internalInstructions, pendingWorkLogs);
  }

  public Beneficiary getBeneficiary(
      final String accountNumber, final String beneficiaryId, final RequestMetadata metadata) {
    return getBeneficiaries(accountNumber, metadata).stream()
        .filter(beneficiary -> beneficiary.getBeneficiaryId().equals(beneficiaryId))
        .findFirst()
        .orElseThrow(
            () ->
                new AccountResourceNotFoundException(
                    String.format(
                        "Failed to find beneficiary for id [%s] and account number [%s]",
                        beneficiaryId, accountNumber)));
  }

  public void createBeneficiaryWithoutSca(
      final String accountNumber, final Beneficiary request, final RequestMetadata metadata) {
    request.accept(new HandleCreateBeneficiaryWithoutScaVisitor(accountNumber, metadata));
  }

  public Beneficiary updateBeneficiary(
      final String accountNumber,
      final Beneficiary request,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    return request.accept(
        new HandleUpdateBeneficiaryVisitor(accountNumber, metadata, scaCredentials));
  }

  public void updateBeneficiaryWithoutSca(
      final String accountNumber, final Beneficiary request, final RequestMetadata metadata) {
    request.accept(new HandleUpdateBeneficiaryWithoutScaVisitor(accountNumber, metadata));
  }

  public void deleteBeneficiary(
      final String accountNumber,
      final String requestBeneficiaryId,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    log.info("Attempting to delete beneficiary with SCA credentials");
    final Beneficiary currentBeneficiary =
        soaBeneficiaryValidator.validateDelete(
            getBeneficiaries(accountNumber, metadata),
            requestBeneficiaryId,
            accountNumber,
            metadata);

    scaManager.validateDeleteSca(
        Operation.DELETE, currentBeneficiary.getBeneficiaryId(), metadata, scaCredentials);

    insertWorkLogRecord(
        accountNumber,
        Operation.DELETE,
        currentBeneficiary,
        currentBeneficiary.getSysId(),
        null,
        metadata);
  }

  public void deleteBeneficiaryWithoutSca(
      final String accountNumber,
      final String requestBeneficiaryId,
      final RequestMetadata metadata) {
    log.info("Attempting to delete beneficiary without SCA credentials");
    final Beneficiary currentBeneficiary =
        soaBeneficiaryValidator.validateDelete(
            getBeneficiaries(accountNumber, metadata),
            requestBeneficiaryId,
            accountNumber,
            metadata);

    insertWorkLogRecord(
        accountNumber,
        Operation.DELETE,
        currentBeneficiary,
        currentBeneficiary.getSysId(),
        null,
        metadata);
  }

  @AllArgsConstructor
  @FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
  @SuppressWarnings("PMD.CommentDefaultAccessModifier")
  private class HandleCreateBeneficiaryWithoutScaVisitor implements BeneficiaryVisitor<Void> {
    String accountNumber;
    RequestMetadata metadata;

    @Override
    public Void visit(final ExternalBeneficiary beneficiary) {
      final int limit =
          soaBeneficiaryValidator.validateExternalCreate(
              accountNumber,
              getBeneficiaries(accountNumber, metadata),
              getProductInfo(accountNumber, metadata),
              beneficiary,
              metadata);

      insertWorkLogRecord(accountNumber, Operation.CREATE, beneficiary, null, limit, metadata);

      return null;
    }

    @Override
    public Void visit(final InternalBeneficiary beneficiary) {
      final int limit =
          soaBeneficiaryValidator.validateInternalCreate(
              accountNumber,
              getBeneficiaries(accountNumber, metadata),
              getProductInfo(accountNumber, metadata),
              beneficiary,
              metadata);

      insertWorkLogRecord(accountNumber, Operation.CREATE, beneficiary, null, limit, metadata);

      return null;
    }
  }

  @AllArgsConstructor
  @FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
  @SuppressWarnings("PMD.CommentDefaultAccessModifier")
  private class HandleUpdateBeneficiaryWithoutScaVisitor implements BeneficiaryVisitor<Void> {
    String accountNumber;
    RequestMetadata metadata;

    @Override
    public Void visit(final ExternalBeneficiary beneficiary) {
      final ExternalBeneficiary currentBeneficiary =
          soaBeneficiaryValidator.validateExternalUpdate(
              accountNumber, getBeneficiaries(accountNumber, metadata), beneficiary, metadata);

      insertWorkLogRecord(
          accountNumber,
          Operation.UPDATE,
          beneficiary,
          currentBeneficiary.getSysId(),
          null,
          metadata);

      return null;
    }

    @Override
    public Void visit(final InternalBeneficiary beneficiary) {
      throw new InternalBeneficiaryUpdateNotSupportedException(
          String.format("Internal beneficiary updates are not supported: %s", beneficiary));
    }
  }

  @AllArgsConstructor
  @FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
  @SuppressWarnings("PMD.CommentDefaultAccessModifier")
  private class HandleUpdateBeneficiaryVisitor implements BeneficiaryVisitor<Beneficiary> {
    String accountNumber;
    RequestMetadata metadata;
    ScaCredentials scaCredentials;

    @Override
    public Beneficiary visit(final ExternalBeneficiary beneficiary) {
      final ExternalBeneficiary currentBeneficiary =
          soaBeneficiaryValidator.validateExternalUpdate(
              accountNumber, getBeneficiaries(accountNumber, metadata), beneficiary, metadata);

      scaManager.validateSca(Operation.UPDATE, beneficiary, metadata, scaCredentials);

      insertWorkLogRecord(
          accountNumber,
          Operation.UPDATE,
          beneficiary,
          currentBeneficiary.getSysId(),
          null,
          metadata);

      // Return the beneficiary in its new current state, which is the current beneficiary but now
      // in a pending state because an update is queued
      return currentBeneficiary.toBuilder().sysId(null).build();
    }

    @Override
    public Beneficiary visit(final InternalBeneficiary beneficiary) {
      throw new InternalBeneficiaryUpdateNotSupportedException(
          String.format("Internal beneficiary updates are not supported: %s", beneficiary));
    }
  }

  private void insertWorkLogRecord(
      final String accountNumber,
      final WorkLog.Operation operation,
      final Beneficiary request,
      final Long currentBeneficiarySysId,
      final Integer beneficiariesLimit,
      final RequestMetadata metadata) {
    log.info("Creating beneficiary work log for account {}: {}", accountNumber, request);

    if (!shouldInsertWorkLogRecord(accountNumber)) {
      log.info(
          "Not creating beneficiary work log because account {} is in the black list",
          accountNumber);
      return;
    }

    workLogRepository.save(
        WorkLog.builder()
            .accountNumber(Long.valueOf(accountNumber))
            .message(
                BeneficiaryRequest.builder()
                    .payload(
                        BeneficiaryRequest.Payload.builder()
                            .sysId(currentBeneficiarySysId)
                            .beneficiariesLimit(beneficiariesLimit)
                            .beneficiary(request)
                            .build())
                    .metadata(metadata)
                    .build())
            .status(WorkLog.Status.PENDING)
            .operation(operation)
            .build());
  }

  private Boolean shouldInsertWorkLogRecord(final String accountNumber) {
    return Optional.ofNullable(beneficiaryServiceProperties.getAccountNumberBlacklist())
        .map(
            blacklist ->
                blacklist.stream()
                    .noneMatch(blacklisted -> blacklisted.equalsIgnoreCase(accountNumber)))
        .orElse(true);
  }

  public BeneficiaryLimitResponse getBeneficiariesLimits(
      final String accountNumber, final RequestMetadata metadata) {
    final LocalDateTime now = LocalDateTime.now(clock);

    accountAccessValidator.validateAccountAccess(
        accountNumber, metadata, Collections.emptySet(), now);

    final long debtorAccountNumber = Long.parseLong(accountNumber);
    final ProductInfo productInfo = getProductInfo(accountNumber, metadata);
    final int externalLimitCount = externalLimitCount(now, debtorAccountNumber);
    final int internalLimitCount = internalLimitCount(now, debtorAccountNumber);

    final boolean externalLimitReached =
        isExternalLimitReached(accountNumber, externalLimitCount, productInfo);
    final boolean internalLimitReached =
        isInternalLimitReached(accountNumber, internalLimitCount, productInfo);

    return BeneficiaryLimitResponse.builder()
        .internal(
            BeneficiaryLimit.builder()
                .limitReached(internalLimitReached)
                .count(internalLimitCount)
                .maxPermitted(productInfo.getBeneficiaries().getInternal())
                .build())
        .external(
            BeneficiaryLimit.builder()
                .limitReached(externalLimitReached)
                .count(externalLimitCount)
                .maxPermitted(productInfo.getBeneficiaries().getExternal())
                .build())
        .build();
  }

  private int internalLimitCount(final LocalDateTime now, final long debtorAccountNumber) {
    return itInstructionRepository.findActiveInternalBeneficiaries(debtorAccountNumber, now).size();
  }

  private int externalLimitCount(final LocalDateTime now, final long debtorAccountNumber) {
    final Collection<BillPaymentInstruction> externalBeneficiaries =
        billPaymentInstructionRepository.findActiveExternalBeneficiaries(debtorAccountNumber, now);
    final Collection<WorkLog> pendingWorkLogs =
        workLogRepository.findRequestsAfterDate(
            now.minus(WORK_LOG_RETRIEVE_CUT_OFF), debtorAccountNumber);
    return beneficiaryListMapper
        .map(externalBeneficiaries, Collections.emptyList(), pendingWorkLogs)
        .size();
  }

  private boolean isExternalLimitReached(
      final String accountNumber,
      final int activeExternalBeneficiariesCount,
      final ProductInfo productInfo) {
    try {
      productBeneficiaryLimitValidator.validateExternalBeneficiaryLimit(
          accountNumber, activeExternalBeneficiariesCount, productInfo);
    } catch (BeneficiaryValidationException e) {
      return true;
    }
    return false;
  }

  private boolean isInternalLimitReached(
      final String accountNumber,
      final int activeInternalBeneficiariesCount,
      final ProductInfo productInfo) {
    try {
      productBeneficiaryLimitValidator.validateInternalBeneficiaryLimit(
          accountNumber, activeInternalBeneficiariesCount, productInfo);
    } catch (BeneficiaryValidationException e) {
      return true;
    }
    return false;
  }

  private ProductInfo getProductInfo(final String accountNumber, final RequestMetadata metadata) {
    final AccountDetails accountDetails = accountService.getAccount(accountNumber, metadata);
    return productService.getProductInfo(accountDetails.getProduct().getIdentifier(), metadata);
  }
}
