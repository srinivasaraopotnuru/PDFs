package uk.co.ybs.digital.beneficiary.exception;

public class AccountServiceEntityNotFoundException extends AccountServiceException {

  private static final long serialVersionUID = 1L;

  public AccountServiceEntityNotFoundException(final String message) {
    super(message);
  }
}
