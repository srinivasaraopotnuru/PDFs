package uk.co.ybs.digital.beneficiary.service.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;

@Component
@AllArgsConstructor
public class BeneficiaryIdGenerator {

  private final ObjectMapper mapper;

  public String generateId(final Class<? extends Beneficiary> type, final Long sysId) {
    try {
      final String json =
          mapper.writeValueAsString(
              BeneficiaryIdPayload.builder().type(type.getSimpleName()).sysId(sysId).build());
      return DigestUtils.sha256Hex(json);
    } catch (JsonProcessingException e) {
      // Should never happen
      throw new IllegalStateException("Unexpected exception generating json", e);
    }
  }

  @Value
  @Builder
  @SuppressWarnings("PMD.CommentDefaultAccessModifier")
  protected static class BeneficiaryIdPayload {
    @NonNull String type;
    @NonNull Long sysId;
  }
}
