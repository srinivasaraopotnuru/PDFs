package uk.co.ybs.digital.beneficiary.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum BeneficiaryValidationExceptionReason {
  LIMIT_REACHED("Limit Exceeded"),
  DUPLICATE("Duplicate Beneficiary"),
  PENDING("Pending Beneficiary"),
  DELETED("Beneficiary Deleted"),
  UPDATE_ALREADY_APPLIED("Update Already Applied"),
  TECHNICAL("Technical Failure");

  private final String description;
}
