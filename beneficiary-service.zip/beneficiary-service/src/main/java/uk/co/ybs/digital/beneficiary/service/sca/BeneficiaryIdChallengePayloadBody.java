package uk.co.ybs.digital.beneficiary.service.sca;

import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;

@Value
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class BeneficiaryIdChallengePayloadBody {
  @NonNull WorkLog.Operation operation;

  @NonNull String beneficiaryId;
}
