package uk.co.ybs.digital.beneficiary.model.digitalbeneficiary;

import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;

@AllArgsConstructor
public class EntityAuditor implements AuditorAware<String> {

  @NonNull private final String defaultAuditor;

  @Override
  public Optional<String> getCurrentAuditor() {
    String auditorName =
        Optional.ofNullable(SecurityContextHolder.getContext())
            .map(SecurityContext::getAuthentication)
            .filter(Authentication::isAuthenticated)
            .map(Authentication::getPrincipal)
            .map(Jwt.class::cast)
            .map(jwt -> jwt.getClaimAsString("sub"))
            .orElse(defaultAuditor);
    return Optional.of(auditorName);
  }
}
