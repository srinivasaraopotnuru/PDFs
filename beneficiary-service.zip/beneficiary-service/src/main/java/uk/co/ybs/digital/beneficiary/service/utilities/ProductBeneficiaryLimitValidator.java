package uk.co.ybs.digital.beneficiary.service.utilities;

import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.LIMIT_REACHED;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.service.product.dto.ProductInfo;

@Component
@RequiredArgsConstructor
@Slf4j
public class ProductBeneficiaryLimitValidator {

  public int validateExternalBeneficiaryLimit(
      final String accountNumber,
      final int numberOfExistingBeneficiaries,
      final ProductInfo productInfo) {
    final int limit = productInfo.getBeneficiaries().getExternal();
    if (numberOfExistingBeneficiaries >= limit) {
      log.info(
          "Adding a new external beneficiary would exceed permitted limit for product: {}, with limit: {}",
          productInfo.getProductIdentifier(),
          limit);

      throw new BeneficiaryValidationException(
          String.format("External beneficiary limit exceeded for account: %s", accountNumber),
          LIMIT_REACHED);
    }
    return limit;
  }

  public int validateInternalBeneficiaryLimit(
      final String accountNumber,
      final int numberOfExistingBeneficiaries,
      final ProductInfo productInfo) {
    final int limit = productInfo.getBeneficiaries().getInternal();
    if (numberOfExistingBeneficiaries >= limit) {
      log.info(
          "Adding a new internal beneficiary would exceed permitted limit for product: {}, with limit: {}",
          productInfo.getProductIdentifier(),
          limit);

      throw new BeneficiaryValidationException(
          String.format("Internal beneficiary limit exceeded for account: %s", accountNumber),
          LIMIT_REACHED);
    }
    return limit;
  }
}
