package uk.co.ybs.digital.beneficiary.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.beneficiary.service.audit.AuditService;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiarySuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryViewRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.BeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@Service
@AllArgsConstructor
public class BeneficiaryAuditor {

  private final AuditService auditService;

  public void auditBeneficiariesView(
      final String accountNumber, final RequestMetadata requestMetadata) {
    final AuditBeneficiaryViewRequest auditRequest =
        AuditBeneficiaryViewRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .beneficiaryInformation(
                AuditBeneficiaryViewRequest.BeneficiaryInformation.builder()
                    .accountNumber(accountNumber)
                    .build())
            .build();

    auditService.auditBeneficiariesView(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryCreateSuccess(
      final BeneficiaryInformation beneficiaryInformation, final RequestMetadata requestMetadata) {
    final AuditBeneficiarySuccessRequest auditRequest =
        AuditBeneficiarySuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .beneficiaryInformation(beneficiaryInformation)
            .build();

    auditService.auditBeneficiaryCreateSuccess(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryCreateFailure(
      final BeneficiaryInformation beneficiaryInformation,
      final String failureReason,
      final RequestMetadata requestMetadata) {
    final AuditBeneficiaryFailureRequest auditRequest =
        AuditBeneficiaryFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(failureReason)
            .beneficiaryInformation(beneficiaryInformation)
            .build();

    auditService.auditBeneficiaryCreateFailure(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryUpdateSuccess(
      final ExternalUpdateBeneficiaryInformationWrapper updateInformationWrapper,
      final RequestMetadata requestMetadata) {
    final AuditBeneficiaryUpdateSuccessRequest auditRequest =
        AuditBeneficiaryUpdateSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .beneficiaryInformation(updateInformationWrapper.getBeneficiaryInformation())
            .updateBeneficiaryInformation(
                updateInformationWrapper.getUpdateBeneficiaryInformation())
            .build();

    auditService.auditBeneficiaryUpdateSuccess(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryUpdateFailure(
      final ExternalUpdateBeneficiaryInformationWrapper updateInformationWrapper,
      final String failureReason,
      final RequestMetadata requestMetadata) {
    final AuditBeneficiaryUpdateFailureRequest auditRequest =
        AuditBeneficiaryUpdateFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(failureReason)
            .beneficiaryInformation(updateInformationWrapper.getBeneficiaryInformation())
            .updateBeneficiaryInformation(
                updateInformationWrapper.getUpdateBeneficiaryInformation())
            .build();

    auditService.auditBeneficiaryUpdateFailure(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryDeleteSuccess(
      final BeneficiaryInformation beneficiaryInformation, final RequestMetadata requestMetadata) {
    final AuditBeneficiarySuccessRequest auditRequest =
        AuditBeneficiarySuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .beneficiaryInformation(beneficiaryInformation)
            .build();

    auditService.auditBeneficiaryDeleteSuccess(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryDeleteFailure(
      final BeneficiaryInformation beneficiaryInformation,
      final String failureReason,
      final RequestMetadata requestMetadata) {
    final AuditBeneficiaryFailureRequest auditRequest =
        AuditBeneficiaryFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(failureReason)
            .beneficiaryInformation(beneficiaryInformation)
            .build();

    auditService.auditBeneficiaryDeleteFailure(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryChallenge(final RequestMetadata requestMetadata) {
    final AuditBeneficiaryChallengeRequest auditRequest =
        AuditBeneficiaryChallengeRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .build();

    auditService.auditBeneficiaryChallenge(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryChallengeSuccess(final RequestMetadata requestMetadata) {
    final AuditBeneficiaryChallengeSuccessRequest auditRequest =
        AuditBeneficiaryChallengeSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .build();

    auditService.auditBeneficiaryChallengeSuccess(auditRequest, requestMetadata);
  }

  public void auditBeneficiaryChallengeFailure(
      final RequestMetadata requestMetadata, final String message) {
    final AuditBeneficiaryChallengeFailureRequest auditRequest =
        AuditBeneficiaryChallengeFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(message)
            .build();

    auditService.auditBeneficiaryChallengeFailure(auditRequest, requestMetadata);
  }
}
