package uk.co.ybs.digital.beneficiary.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.Value;
import lombok.experimental.SuperBuilder;
import uk.co.ybs.digital.beneficiary.web.validators.AlphaNumeric;
import uk.co.ybs.digital.beneficiary.web.validators.ExternalAccountNumber;
import uk.co.ybs.digital.beneficiary.web.validators.NotAllWhitespace;
import uk.co.ybs.digital.beneficiary.web.validators.SortCode;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder(toBuilder = true)
@JsonDeserialize(builder = ExternalBeneficiary.ExternalBeneficiaryBuilderImpl.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ExternalBeneficiary extends Beneficiary {
  @NotNull(message = "You must specify an account sort code")
  @SortCode
  @Schema(required = true, example = "123456")
  String accountSortCode;

  @NotNull(message = "You must specify a name")
  @NotAllWhitespace(message = "Name must contain at least one non-whitespace character")
  @AlphaNumeric
  @Size(max = 30, message = "Name must be at most 30 characters long")
  @Schema(required = true, example = "NAME", maxLength = 30)
  String name;

  @NotNull(message = "You must specify an account number")
  @ExternalAccountNumber(message = "Account number must be 8 digits")
  @Schema(required = true, example = "12345678")
  String accountNumber;

  @NotAllWhitespace(message = "Reference must contain at least one non-whitespace character")
  @AlphaNumeric
  @Size(max = 18, message = "Reference must be at most 18 characters long")
  @Schema(example = "REF", maxLength = 18)
  String reference;

  @NotAllWhitespace(message = "Memorable name must contain at least one non-whitespace character")
  @AlphaNumeric
  @Size(max = 20, message = "Memorable name must be at most 20 characters long")
  @Schema(example = "Joint Account", maxLength = 20)
  String memorableName;

  @Override
  public <T> T accept(final BeneficiaryVisitor<T> visitor) {
    return visitor.visit(this);
  }

  @JsonPOJOBuilder(withPrefix = "")
  static final class ExternalBeneficiaryBuilderImpl
      extends ExternalBeneficiaryBuilder<ExternalBeneficiary, ExternalBeneficiaryBuilderImpl> {}
}
