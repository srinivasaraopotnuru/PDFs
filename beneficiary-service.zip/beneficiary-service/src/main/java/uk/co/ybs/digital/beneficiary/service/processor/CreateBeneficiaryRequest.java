package uk.co.ybs.digital.beneficiary.service.processor;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;

@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class CreateBeneficiaryRequest<B extends Beneficiary>
    implements BeneficiaryRequest, ResolvedBeneficiaryRequest {

  @NonNull private final BeneficiaryRequestArguments<B> arguments;
  @NonNull private final CreateBeneficiaryProcessor<B> processor;

  @Override
  public ResolvedBeneficiaryRequest resolve() {
    return this; // No resolution required
  }

  @Override
  public void execute() {
    processor.execute(arguments);
  }

  @Override
  public void auditSuccess() {
    processor.auditSuccess(arguments);
  }

  @Override
  public void auditFailure(final BeneficiaryValidationExceptionReason reason) {
    processor.auditFailure(arguments, reason);
  }
}
