package uk.co.ybs.digital.beneficiary.config;

import java.time.Clock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.auditing.DateTimeProvider;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.ClockDateTimeProvider;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.EntityAuditor;

@Configuration
@EnableJpaAuditing(dateTimeProviderRef = "auditorDateTimeProvider")
public class JpaAuditingConfig {

  @Value("${spring.datasource.digitalbeneficiary.username:DIGITAL_BENEFICIARY}")
  private String databaseUser;

  @Bean
  public AuditorAware<String> auditorAware() {
    return new EntityAuditor(databaseUser);
  }

  @Bean
  public DateTimeProvider auditorDateTimeProvider(final Clock clock) {
    return new ClockDateTimeProvider(clock);
  }
}
