package uk.co.ybs.digital.beneficiary.service.mapper;

import java.util.Collection;
import java.util.Optional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.service.utilities.BeneficiaryUtils;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;

@Component
@RequiredArgsConstructor
public class ExternalBeneficiaryMapper {

  private static final int EXTERNAL_ACCOUNT_NUMBER_LENGTH = 8;
  private static final int EXTERNAL_SORT_CODE_LENGTH = 6;

  @NonNull private final BeneficiaryIdGenerator beneficiaryIdGenerator;
  @NonNull private final BeneficiaryUtils beneficiaryUtils;

  public ExternalBeneficiary map(
      final BillPaymentInstruction instruction, final Collection<WorkLog> workLogs) {
    final Long sysId = instruction.getSysId();
    final NonYbsBankAccount account = instruction.getNonYbsBankAccount();
    final String beneficiaryId =
        beneficiaryIdGenerator.generateId(ExternalBeneficiary.class, sysId);
    final boolean pending = beneficiaryUtils.findMatchingWorkLog(instruction, workLogs).isPresent();
    final Long stableSysId = pending ? null : sysId;

    return ExternalBeneficiary.builder()
        .sysId(stableSysId)
        .beneficiaryId(beneficiaryId)
        .accountSortCode(formatNumber(account.getSortCode(), EXTERNAL_SORT_CODE_LENGTH))
        .accountNumber(formatNumber(account.getAccountNumber(), EXTERNAL_ACCOUNT_NUMBER_LENGTH))
        .reference(formatString(instruction.getReference()))
        .name(formatString(account.getName()))
        .memorableName(formatString(instruction.getMemorableName()))
        .build();
  }

  private String formatNumber(final Long number, final int length) {
    if (number == null) {
      return null;
    }
    final String string = String.valueOf(number);
    if (string.length() > length) {
      return StringUtils.left(string, length);
    } else {
      return StringUtils.leftPad(string, length, '0');
    }
  }

  private String formatString(final String string) {
    return Optional.ofNullable(string).map(String::trim).orElse(null);
  }
}
