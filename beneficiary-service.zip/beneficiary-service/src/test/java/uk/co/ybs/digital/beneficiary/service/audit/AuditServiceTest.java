package uk.co.ybs.digital.beneficiary.service.audit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.TECHNICAL;
import static uk.co.ybs.digital.beneficiary.utils.TestHelper.readClassPathResource;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.apache.commons.lang3.ArrayUtils;
import org.hamcrest.Matcher;
import org.json.JSONException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.reactive.function.client.ClientHttpConnectorAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.beneficiary.config.ServiceToServiceConfig;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiarySuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryViewRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.BeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.security.requestsigning.RequestSigningAutoConfiguration;

@SpringBootTest(
    classes = {
      AuditService.class,
      ServiceToServiceConfig.class,
      RequestSigningAutoConfiguration.class,
      ClientHttpConnectorAutoConfiguration.class
    },
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AuditServiceTest {

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Audit service returned error status: ";

  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String ACCOUNT_NUMBER = "2372146519";
  private static final String IP_ADDRESS = "12.66.53.145";
  public static final String CODE_400 = "400";

  @Autowired private AuditService auditService;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  private MockWebServer mockWebServer;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start(auditTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void shouldAuditBeneficiariesView() throws Exception {
    final AuditBeneficiaryViewRequest request = buildAuditBeneficiaryViewRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiariesView(request, requestMetadata);

    verifyRequest(
        "/audit/beneficiary/view", "api/auditService/request/auditBeneficiary/View/request.json");
  }

  @Test
  void shouldAuditBeneficiaryCreateSuccess() throws Exception {
    final AuditBeneficiarySuccessRequest request = buildAuditBeneficiarySuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryCreateSuccess(request, requestMetadata);

    verifyRequest(
        "/audit/beneficiary/create/success",
        "api/auditService/request/auditBeneficiary/CreateDelete/successRequest.json");
  }

  @ParameterizedTest
  @MethodSource("failedBeneficiaryRequests")
  void shouldAuditBeneficiaryCreateFailure(
      final BeneficiaryInformation beneficiaryInformation,
      final BeneficiaryValidationExceptionReason validationException,
      final String expectedResponseBodyResource)
      throws Exception {
    final AuditBeneficiaryFailureRequest request =
        buildAuditBeneficiaryFailureRequest(beneficiaryInformation, validationException);
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryCreateFailure(request, requestMetadata);

    verifyRequest("/audit/beneficiary/create/failure", expectedResponseBodyResource);
  }

  @Test
  void shouldAuditBeneficiaryUpdateSuccess() throws Exception {
    final AuditBeneficiaryUpdateSuccessRequest request =
        buildAuditBeneficiaryUpdateSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryUpdateSuccess(request, requestMetadata);

    verifyRequest(
        "/audit/beneficiary/update/success",
        "api/auditService/request/auditBeneficiary/Update/externalSuccessAllFields.json");
  }

  @Test
  void shouldAuditBeneficiaryUpdateFailure() throws Exception {
    final AuditBeneficiaryUpdateFailureRequest request =
        buildAuditBeneficiaryUpdateFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryUpdateFailure(request, requestMetadata);

    verifyRequest(
        "/audit/beneficiary/update/failure",
        "api/auditService/request/auditBeneficiary/Update/externalFailureAllFields.json");
  }

  @Test
  void shouldAuditBeneficiaryChallenge() throws Exception {
    final AuditBeneficiaryChallengeRequest request = buildAuditBeneficiaryChallengeRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryChallenge(request, requestMetadata);

    verifyRequest(
        "/audit/beneficiary/authentication/challenge",
        "api/auditService/request/auditBeneficiary/Challenge/challenge.json");
  }

  @Test
  void shouldAuditBeneficiaryChallengeSuccess() throws Exception {
    final AuditBeneficiaryChallengeSuccessRequest request =
        buildAuditBeneficiaryChallengeSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryChallengeSuccess(request, requestMetadata);

    verifyRequest(
        "/audit/beneficiary/authentication/success",
        "api/auditService/request/auditBeneficiary/Challenge/challengeSuccess.json");
  }

  @Test
  void shouldAuditBeneficiaryChallengeFailure() throws Exception {
    final AuditBeneficiaryChallengeFailureRequest request =
        buildAuditBeneficiaryChallengeFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryChallengeFailure(request, requestMetadata);

    verifyRequest(
        "/audit/beneficiary/authentication/failure",
        "api/auditService/request/auditBeneficiary/Challenge/challengeFailure.json");
  }

  @Test
  void shouldAuditBeneficiaryDeleteSuccess() throws Exception {
    final AuditBeneficiarySuccessRequest request = buildAuditBeneficiarySuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryDeleteSuccess(request, requestMetadata);

    verifyRequest(
        "/audit/beneficiary/delete/success",
        "api/auditService/request/auditBeneficiary/CreateDelete/successRequest.json");
  }

  @ParameterizedTest
  @MethodSource("failedBeneficiaryRequests")
  void shouldAuditBeneficiaryDeleteFailure(
      final BeneficiaryInformation beneficiaryInformation,
      final BeneficiaryValidationExceptionReason validationException,
      final String expectedResponseBodyResource)
      throws Exception {
    final AuditBeneficiaryFailureRequest request =
        buildAuditBeneficiaryFailureRequest(beneficiaryInformation, validationException);
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditBeneficiaryDeleteFailure(request, requestMetadata);

    verifyRequest("/audit/beneficiary/delete/failure", expectedResponseBodyResource);
  }

  @ParameterizedTest
  @MethodSource("auditMethods")
  void shouldThrowAuditServiceExceptionForConnectionError(
      @SuppressWarnings("unused") final String auditMethodLabel,
      final Function<AuditService, Executable> auditMethod)
      throws IOException {
    mockWebServer.shutdown();

    final AuditServiceException exception =
        assertThrows(AuditServiceException.class, auditMethod.apply(auditService));
    assertThat(exception.getMessage(), is(equalTo("Error calling audit service")));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditMethodsAndServiceErrorResponses")
  void auditBeneficiariesViewShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      @SuppressWarnings("unused") final String auditMethodLabel,
      final Function<AuditService, Executable> auditMethod,
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuditServiceException exception =
        assertThrows(AuditServiceException.class, auditMethod.apply(auditService));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  private static Stream<Arguments> failedBeneficiaryRequests() {
    return Stream.of(
        Arguments.of(
            buildInternalBeneficiaryInformation(),
            TECHNICAL,
            "api/auditService/request/auditBeneficiary/CreateDelete/internalFailureRequest.json"),
        Arguments.of(
            buildExternalBeneficiaryInformation(),
            DUPLICATE,
            "api/auditService/request/auditBeneficiary/CreateDelete/externalFailureRequest.json"));
  }

  private void verifyRequest(final String expectedPath, final String expectedResponseBodyResource)
      throws InterruptedException, JSONException {
    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is(expectedPath));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody = readClassPathResource(expectedResponseBodyResource);
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  private static Stream<Arguments> auditMethods() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Function<AuditService, Executable> view =
        service ->
            () ->
                service.auditBeneficiariesView(buildAuditBeneficiaryViewRequest(), requestMetadata);
    final Function<AuditService, Executable> createSuccess =
        service ->
            () ->
                service.auditBeneficiaryCreateSuccess(
                    buildAuditBeneficiarySuccessRequest(), requestMetadata);
    final Function<AuditService, Executable> createFailure =
        service ->
            () ->
                service.auditBeneficiaryCreateFailure(
                    buildAuditBeneficiaryFailureRequest(
                        buildExternalBeneficiaryInformation(), DUPLICATE),
                    requestMetadata);
    final Function<AuditService, Executable> updateSuccess =
        service ->
            () ->
                service.auditBeneficiaryUpdateSuccess(
                    buildAuditBeneficiaryUpdateSuccessRequest(), requestMetadata);
    final Function<AuditService, Executable> updateFailure =
        service ->
            () ->
                service.auditBeneficiaryUpdateFailure(
                    buildAuditBeneficiaryUpdateFailureRequest(), requestMetadata);
    final Function<AuditService, Executable> deleteSuccess =
        service ->
            () ->
                service.auditBeneficiaryDeleteSuccess(
                    buildAuditBeneficiarySuccessRequest(), requestMetadata);
    final Function<AuditService, Executable> deleteFailure =
        service ->
            () ->
                service.auditBeneficiaryDeleteFailure(
                    buildAuditBeneficiaryFailureRequest(
                        buildExternalBeneficiaryInformation(), DUPLICATE),
                    requestMetadata);
    final Function<AuditService, Executable> challenge =
        service ->
            () ->
                service.auditBeneficiaryChallenge(
                    buildAuditBeneficiaryChallengeRequest(), requestMetadata);
    final Function<AuditService, Executable> challengeSuccess =
        service ->
            () ->
                service.auditBeneficiaryChallengeSuccess(
                    buildAuditBeneficiaryChallengeSuccessRequest(), requestMetadata);
    final Function<AuditService, Executable> challengeFailure =
        service ->
            () ->
                service.auditBeneficiaryChallengeFailure(
                    buildAuditBeneficiaryChallengeFailureRequest(), requestMetadata);
    return Stream.of(
        Arguments.of("View", view),
        Arguments.of("Create Success", createSuccess),
        Arguments.of("Create Failure", createFailure),
        Arguments.of("Update Success", updateSuccess),
        Arguments.of("Update Failure", updateFailure),
        Arguments.of("Delete Success", deleteSuccess),
        Arguments.of("Delete Failure", deleteFailure),
        Arguments.of("Challenge", challenge),
        Arguments.of("Challenge Success", challengeSuccess),
        Arguments.of("Challenge Failure", challengeFailure));
  }

  private static Stream<Arguments> auditServiceErrorResponses() {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/errorResponseInvalidSignature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/errorResponseBadRequest.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/unexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/emptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)));
  }

  private static Stream<Arguments> auditMethodsAndServiceErrorResponses() {
    return auditMethods()
        .flatMap(
            auditMethodArguments ->
                auditServiceErrorResponses()
                    .map(
                        errorResponseArguments ->
                            combine(auditMethodArguments, errorResponseArguments)));
  }

  private static Arguments combine(final Arguments argumentsA, final Arguments argumentsB) {
    return Arguments.of(ArrayUtils.addAll(argumentsA.get(), argumentsB.get()));
  }

  private static AuditBeneficiaryViewRequest buildAuditBeneficiaryViewRequest() {
    return AuditBeneficiaryViewRequest.builder()
        .ipAddress(IP_ADDRESS)
        .beneficiaryInformation(
            AuditBeneficiaryViewRequest.BeneficiaryInformation.builder()
                .accountNumber(ACCOUNT_NUMBER)
                .build())
        .build();
  }

  private static AuditBeneficiarySuccessRequest buildAuditBeneficiarySuccessRequest() {
    return AuditBeneficiarySuccessRequest.builder()
        .ipAddress(IP_ADDRESS)
        .beneficiaryInformation(buildExternalBeneficiaryInformation())
        .build();
  }

  private static AuditBeneficiaryFailureRequest buildAuditBeneficiaryFailureRequest(
      final BeneficiaryInformation beneficiaryInformation,
      final BeneficiaryValidationExceptionReason validationException) {
    return AuditBeneficiaryFailureRequest.builder()
        .ipAddress(IP_ADDRESS)
        .message(validationException.getDescription())
        .beneficiaryInformation(beneficiaryInformation)
        .build();
  }

  private static AuditBeneficiaryUpdateSuccessRequest buildAuditBeneficiaryUpdateSuccessRequest() {
    return AuditBeneficiaryUpdateSuccessRequest.builder()
        .ipAddress(IP_ADDRESS)
        .beneficiaryInformation(buildExternalBeneficiaryInformation())
        .updateBeneficiaryInformation(buildExternalUpdateBeneficiaryInformation())
        .build();
  }

  private static AuditBeneficiaryUpdateFailureRequest buildAuditBeneficiaryUpdateFailureRequest() {
    return AuditBeneficiaryUpdateFailureRequest.builder()
        .ipAddress(IP_ADDRESS)
        .message("Duplicate Beneficiary")
        .beneficiaryInformation(buildExternalBeneficiaryInformation())
        .updateBeneficiaryInformation(buildExternalUpdateBeneficiaryInformation())
        .build();
  }

  private static AuditBeneficiaryChallengeRequest buildAuditBeneficiaryChallengeRequest() {
    return AuditBeneficiaryChallengeRequest.builder().ipAddress(IP_ADDRESS).build();
  }

  private static AuditBeneficiaryChallengeSuccessRequest
      buildAuditBeneficiaryChallengeSuccessRequest() {
    return AuditBeneficiaryChallengeSuccessRequest.builder().ipAddress(IP_ADDRESS).build();
  }

  private static AuditBeneficiaryChallengeFailureRequest
      buildAuditBeneficiaryChallengeFailureRequest() {
    return AuditBeneficiaryChallengeFailureRequest.builder()
        .ipAddress(IP_ADDRESS)
        .message("Invalid Credentials")
        .build();
  }

  private static ExternalBeneficiaryInformation buildExternalBeneficiaryInformation() {
    return ExternalBeneficiaryInformation.builder()
        .payeeName("Mr Test")
        .payeeSortCode("112233")
        .reference("Ref")
        .memorableName("Memorable")
        .payeeAccountNumber("12345678")
        .accountNumber(ACCOUNT_NUMBER)
        .build();
  }

  private static InternalBeneficiaryInformation buildInternalBeneficiaryInformation() {
    return InternalBeneficiaryInformation.builder()
        .payeeAccountNumber("1234567890")
        .accountNumber(ACCOUNT_NUMBER)
        .build();
  }

  private static ExternalUpdateBeneficiaryInformation buildExternalUpdateBeneficiaryInformation() {
    return ExternalUpdateBeneficiaryInformation.builder()
        .reference("New Ref")
        .memorableName("New Memorable")
        .build();
  }

  private static RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .sessionId(SESSION_ID)
        .host(InetSocketAddress.createUnresolved("localhost", 80))
        .partyId("1234567891")
        .brandCode("YBS")
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .build();
  }
}
