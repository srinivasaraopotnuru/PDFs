package uk.co.ybs.digital.beneficiary.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.beneficiary.model.adgcore.AccountActivityGroup;
import uk.co.ybs.digital.beneficiary.model.adgcore.ActivityPlayer;
import uk.co.ybs.digital.beneficiary.model.adgcore.ActivityType;
import uk.co.ybs.digital.beneficiary.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;

@YbsDataJpaTest
class ActivityPlayerRepositoryTest {

  private static final String ACTIVITY_TYPE_CODE_1 = "ACTTYP";
  private static final String ACTIVITY_GROUP_CODE_PISP = "PISP";
  private static final String ACTIVITY_GROUP_CODE_AHLDRS = "AHLDRS";
  private static final Set<String> ACTIVITY_GROUP_PISP_ONLY =
      new HashSet<>(Collections.singletonList(ACTIVITY_GROUP_CODE_PISP));
  private static final Set<String> ACTIVITY_GROUP_ALL_CODES =
      new HashSet<>(Arrays.asList(ACTIVITY_GROUP_CODE_PISP, ACTIVITY_GROUP_CODE_AHLDRS));

  private static final LocalDateTime DATETIME = LocalDateTime.parse("2020-05-25T04:20:00");

  private static final Long ACCOUNT_NUMBER_1 = 2001L;
  private static final Long ACCOUNT_NUMBER_2 = 2002L;

  private static final Long PARTY_ID_1 = 3001L;

  @Autowired ActivityPlayerRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @Test
  void shouldFindById() {
    // Proves that the repo has been setup with the correct entity and pk types
    final Long activityPlayerSysId = 123L;

    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    final ActivityPlayer persisted =
        persistActivityPlayerForAccountNumber(
            activityPlayerSysId, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, null);
    adgCoreTestEntityManager.clear();

    final Optional<ActivityPlayer> found = testSubject.findById(activityPlayerSysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldFindAllAccountsWherePartyHasActivityTypeGroup() {

    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(ACTIVITY_GROUP_CODE_PISP, activityType, DATETIME, null);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, null);
    persistActivityPlayerForAccountNumber(
        2L, ACCOUNT_NUMBER_2, PARTY_ID_1, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1,
            ACTIVITY_GROUP_PISP_ONLY,
            Arrays.asList(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2),
            DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers, containsInAnyOrder(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2));
  }

  @ParameterizedTest
  @CsvSource({"2020-05-25T04:19:59,true", "2020-05-25T04:20:00,true", "2020-05-25T04:20:01,false"})
  void shouldOnlyFindAccountsWhereActivityTypeHasStarted(
      final LocalDateTime activityTypeStartDate, final boolean expectedFind) {
    final ActivityType activityType =
        persistActivityType(ACTIVITY_TYPE_CODE_1, activityTypeStartDate, null);
    persistActivityTypeGroup(ACTIVITY_GROUP_CODE_PISP, activityType, DATETIME, null);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1, ACTIVITY_GROUP_PISP_ONLY, Arrays.asList(ACCOUNT_NUMBER_1), DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({
    "2020-05-25T04:19:59,false",
    "2020-05-25T04:20:00,false",
    "2020-05-25T04:20:01,true",
    ",true"
  })
  void shouldOnlyFindAccountsWhereActivityTypeHasNotEnded(
      final LocalDateTime activityTypeEndDate, final boolean expectedFind) {
    final ActivityType activityType =
        persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, activityTypeEndDate);
    persistActivityTypeGroup(ACTIVITY_GROUP_CODE_PISP, activityType, DATETIME, null);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1, ACTIVITY_GROUP_PISP_ONLY, Arrays.asList(ACCOUNT_NUMBER_1), DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"2020-05-25T04:19:59,true", "2020-05-25T04:20:00,true", "2020-05-25T04:20:01,false"})
  void shouldOnlyFindAccountsWhereActivityTypeGroupHasStarted(
      final LocalDateTime activityTypeGroupStartDate, final boolean expectedFind) {
    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(
        ACTIVITY_GROUP_CODE_PISP, activityType, activityTypeGroupStartDate, null);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1, ACTIVITY_GROUP_PISP_ONLY, Arrays.asList(ACCOUNT_NUMBER_1), DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({
    "2020-05-25T04:19:59,false",
    "2020-05-25T04:20:00,false",
    "2020-05-25T04:20:01,true",
    ",true"
  })
  void shouldOnlyFindAccountsWhereActivityTypeGroupHasNotEnded(
      final LocalDateTime activityTypeGroupEndDate, final boolean expectedFind) {
    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(
        ACTIVITY_GROUP_CODE_PISP, activityType, DATETIME, activityTypeGroupEndDate);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1, ACTIVITY_GROUP_PISP_ONLY, Arrays.asList(ACCOUNT_NUMBER_1), DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"PISP,true", "AISP,false"})
  void shouldOnlyFindAccountsWhereActivityTypeGroupIsPISP(
      final String activityGroupCode, final boolean expectedFind) {

    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(activityGroupCode, activityType, DATETIME, null);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1,
            ACTIVITY_GROUP_PISP_ONLY,
            Arrays.asList(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2),
            DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"2020-05-25T04:19:59,true", "2020-05-25T04:20:00,true", "2020-05-25T04:20:01,false"})
  void shouldOnlyFindAccountsWhereActivityPlayerHasStarted(
      final LocalDateTime activityPlayerStartDate, final boolean expectedFind) {
    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(ACTIVITY_GROUP_CODE_PISP, activityType, DATETIME, null);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, activityPlayerStartDate, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1, ACTIVITY_GROUP_PISP_ONLY, Arrays.asList(ACCOUNT_NUMBER_1), DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({
    "2020-05-25T04:19:59,false",
    "2020-05-25T04:20:00,false",
    "2020-05-25T04:20:01,true",
    ",true"
  })
  void shouldOnlyFindAccountsWhereActivityPlayerHasNotEnded(
      final LocalDateTime activityPlayerEndDate, final boolean expectedFind) {
    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(ACTIVITY_GROUP_CODE_PISP, activityType, DATETIME, null);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, activityPlayerEndDate);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1, ACTIVITY_GROUP_PISP_ONLY, Arrays.asList(ACCOUNT_NUMBER_1), DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"ACCNUM,2001,true", "ACCNUM,2002,false", "OTHER,2001,false"})
  void shouldOnlyFindAccountsWhereActivityPlayerExistsForAccountNumber(
      final String tableId, final Long tableSysId, final boolean expectedFind) {

    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(ACTIVITY_GROUP_CODE_PISP, activityType, DATETIME, null);
    persistActivityPlayer(1L, tableId, tableSysId, PARTY_ID_1, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1, ACTIVITY_GROUP_PISP_ONLY, Arrays.asList(ACCOUNT_NUMBER_1), DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"3001,true", "3002,false"})
  void shouldOnlyFindAccountsWhereActivityPlayerExistsForParty(
      final Long partyId, final boolean expectedFind) {

    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(ACTIVITY_GROUP_CODE_PISP, activityType, DATETIME, null);
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, partyId, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1, ACTIVITY_GROUP_PISP_ONLY, Arrays.asList(ACCOUNT_NUMBER_1), DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"AHLDRS,PISP,true", "AHLDRS,,true", "PISP,,true", "AISP,,false"})
  void shouldOnlyFindAccountsWhereRequiredActivityTypeCodeIsPresent(
      final String activityGroupCode,
      final String otherActivityGroupCode,
      final boolean expectedFind) {

    final ActivityType activityType = persistActivityType(ACTIVITY_TYPE_CODE_1, DATETIME, null);
    persistActivityTypeGroup(activityGroupCode, activityType, DATETIME, null);
    if (otherActivityGroupCode != null) {
      persistActivityTypeGroup(otherActivityGroupCode, activityType, DATETIME, null);
    }
    persistActivityPlayerForAccountNumber(
        1L, ACCOUNT_NUMBER_1, PARTY_ID_1, activityType, DATETIME, null);

    final Collection<AccountActivityGroup> accountsAndGroups =
        testSubject.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_1,
            ACTIVITY_GROUP_ALL_CODES,
            Arrays.asList(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2),
            DATETIME);
    final Set<Long> accountNumbers = getAccountNumbersOnly(accountsAndGroups);

    assertThat(accountNumbers.isEmpty(), not(expectedFind));

    final List<String> groupsOnly =
        accountsAndGroups.stream()
            .map(AccountActivityGroup::getActivityGroupCode)
            .collect(Collectors.toList());
    if (otherActivityGroupCode != null) {
      assertThat(
          groupsOnly.containsAll(Arrays.asList(activityGroupCode, otherActivityGroupCode)),
          is(expectedFind));
    } else {
      assertThat(groupsOnly.contains(activityGroupCode), is(expectedFind));
    }
  }

  private ActivityType persistActivityType(
      final String code, final LocalDateTime startDate, final LocalDateTime endDate) {
    final ActivityType activityType = new ActivityType(code, startDate, endDate);
    return adgCoreTestEntityManager.persistAndFlush(activityType);
  }

  private ActivityTypeGroup persistActivityTypeGroup(
      final String activityGroupCode,
      final ActivityType activityType,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    final ActivityTypeGroup activityTypeGroup =
        new ActivityTypeGroup(activityGroupCode, activityType, startDate, endDate);
    return adgCoreTestEntityManager.persistAndFlush(activityTypeGroup);
  }

  private ActivityPlayer persistActivityPlayerForAccountNumber(
      final Long sysId,
      final Long accountNumber,
      final Long customerId,
      final ActivityType activityType,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    return persistActivityPlayer(
        sysId, "ACCNUM", accountNumber, customerId, activityType, startDate, endDate);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private ActivityPlayer persistActivityPlayer(
      final Long sysId,
      final String tableId,
      final Long tableSysId,
      final Long partySysId,
      final ActivityType activityType,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    final ActivityPlayer activityPlayer =
        new ActivityPlayer(
            sysId, tableId, tableSysId, partySysId, activityType, startDate, endDate);
    return adgCoreTestEntityManager.persistAndFlush(activityPlayer);
  }

  private Set<Long> getAccountNumbersOnly(
      final Collection<AccountActivityGroup> accountActivityGroups) {
    return accountActivityGroups.stream()
        .map(AccountActivityGroup::getAccountNumber)
        .collect(Collectors.toSet());
  }
}
