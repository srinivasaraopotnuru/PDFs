package uk.co.ybs.digital.beneficiary.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DELETED;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.TECHNICAL;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;
import uk.co.ybs.digital.beneficiary.repository.core.ItInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class DeleteInternalBeneficiaryProcessorTest {

  private static final long ACCOUNT_NUMBER = 1234567890L;
  private static final long PAYEE_ACCOUNT_NUMBER = 2234567890L;
  private static final long BENEFICIARY_SYS_ID = 1L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  @InjectMocks private DeleteInternalBeneficiaryProcessor testSubject;

  @Mock private ItInstructionCoreRepository itInstructionCoreRepository;

  @Mock private BeneficiaryInformationFactory beneficiaryInformationFactory;

  @Mock private BeneficiaryAuditor beneficiaryAuditor;

  @Test
  void resolveShouldReturnDatabaseEntity() {
    final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments =
        buildArguments(TestHelper.createRequestMetadata());
    final ItInstruction itInstruction = ItInstruction.builder().sysId(2L).build();

    when(itInstructionCoreRepository.findById(BENEFICIARY_SYS_ID))
        .thenReturn(Optional.of(itInstruction));

    final ItInstruction instruction = testSubject.resolve(arguments);

    assertThat(instruction, is(instruction));
    verifyNoMoreInteractions(itInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void resolveShouldThrowIllegalArgumentExceptionWhenRepositoryReturnsEmpty() {
    final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments =
        buildArguments(TestHelper.createRequestMetadata());

    when(itInstructionCoreRepository.findById(BENEFICIARY_SYS_ID)).thenReturn(Optional.empty());

    final IllegalArgumentException exception =
        assertThrows(IllegalArgumentException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("ItInstruction 1 not found"));
    verifyNoMoreInteractions(itInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void executeShouldEndBeneficiary() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments =
        buildArguments(requestMetadata);

    final ItInstruction itInstruction = buildItInstruction();

    final ItInstruction expectedItInstruction =
        itInstruction
            .toBuilder()
            .endDate(PROCESS_TIME)
            .endedAt("0795")
            .endedBy("SAPP")
            .endedDate(PROCESS_TIME)
            .status("CANC")
            .build();

    testSubject.execute(arguments, itInstruction);

    verify(itInstructionCoreRepository)
        .saveAndFlush(argThat(samePropertyValuesAs(expectedItInstruction)));
    verify(itInstructionCoreRepository).updateInternalBeneficiaryAuthenticRecord(ACCOUNT_NUMBER);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfAlreadyEnded() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments =
        buildArguments(requestMetadata);

    final ItInstruction itInstruction =
        buildItInstruction().toBuilder().endDate(PROCESS_TIME).build();

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () -> testSubject.execute(arguments, itInstruction));

    assertThat(exception.getMessage(), is("Beneficiary already ended"));
    assertThat(exception.getReason(), is(DELETED));

    verifyNoInteractions(itInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void auditSuccessShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments =
        buildArguments(requestMetadata);

    final InternalBeneficiary databaseBeneficiary = buildDatabaseBeneficiary();
    final ItInstruction itInstruction = buildItInstruction();

    final InternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createInternalBeneficiaryInformation(
            String.valueOf(ACCOUNT_NUMBER), String.valueOf(PAYEE_ACCOUNT_NUMBER));
    when(beneficiaryInformationFactory.buildInternal(ACCOUNT_NUMBER, databaseBeneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditSuccess(arguments, itInstruction);

    verify(beneficiaryAuditor).auditBeneficiaryDeleteSuccess(expectedAuditBody, requestMetadata);
    verifyNoInteractions(itInstructionCoreRepository);
  }

  @Test
  void auditFailureShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExistingBeneficiaryRequestArguments<InternalBeneficiary> arguments =
        buildArguments(requestMetadata);

    final InternalBeneficiary databaseBeneficiary = buildDatabaseBeneficiary();
    final ItInstruction itInstruction = buildItInstruction();

    final InternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createInternalBeneficiaryInformation(
            String.valueOf(ACCOUNT_NUMBER), String.valueOf(PAYEE_ACCOUNT_NUMBER));
    when(beneficiaryInformationFactory.buildInternal(ACCOUNT_NUMBER, databaseBeneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditFailure(arguments, itInstruction, TECHNICAL);

    verify(beneficiaryAuditor)
        .auditBeneficiaryDeleteFailure(expectedAuditBody, "Technical Failure", requestMetadata);
    verifyNoInteractions(itInstructionCoreRepository);
  }

  private ExistingBeneficiaryRequestArguments<InternalBeneficiary> buildArguments(
      final RequestMetadata requestMetadata) {
    return new ExistingBeneficiaryRequestArguments<>(
        ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, buildBeneficiary(), BENEFICIARY_SYS_ID);
  }

  private InternalBeneficiary buildBeneficiary() {
    return InternalBeneficiary.builder()
        .beneficiaryId("abc123")
        .accountNumber(String.valueOf(PAYEE_ACCOUNT_NUMBER))
        .build();
  }

  private InternalBeneficiary buildDatabaseBeneficiary() {
    return InternalBeneficiary.builder()
        .accountNumber(String.valueOf(PAYEE_ACCOUNT_NUMBER))
        .build();
  }

  private ItInstruction buildItInstruction() {
    return ItInstruction.builder().creditorAccountNumber(PAYEE_ACCOUNT_NUMBER).build();
  }
}
