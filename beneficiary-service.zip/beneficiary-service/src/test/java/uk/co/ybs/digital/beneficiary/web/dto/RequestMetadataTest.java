package uk.co.ybs.digital.beneficiary.web.dto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;

import java.net.InetSocketAddress;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class RequestMetadataTest {

  @Test
  void toStringShouldNotIncludeForwardingAuth() {
    final RequestMetadata metadata =
        RequestMetadata.builder()
            .requestId(UUID.randomUUID())
            .sessionId(UUID.randomUUID())
            .host(InetSocketAddress.createUnresolved("host", 443))
            .partyId("1234567890")
            .brandCode("YBS")
            .forwardingAuth("<jwt>")
            .ipAddress("12.66.53.145")
            .build();

    final String toString = metadata.toString();

    assertThat(
        toString, allOf(not(containsString("forwardingAuth")), not(containsString("<jwt>"))));
  }
}
