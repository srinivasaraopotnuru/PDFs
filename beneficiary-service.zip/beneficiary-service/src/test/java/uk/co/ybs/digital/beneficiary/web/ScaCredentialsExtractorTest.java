package uk.co.ybs.digital.beneficiary.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.HttpHeaders;
import uk.co.ybs.digital.beneficiary.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.sca.service.ScaCredentials;

class ScaCredentialsExtractorTest {

  public static final String X_YBS_SCA_KEY = "x-ybs-sca-key";
  public static final String SCA_KEY = "sca-key";
  public static final String X_YBS_SCA_CHALLENGE = "x-ybs-sca-challenge";
  public static final String X_YBS_SCA_CHALLENGE_RESPONSE = "x-ybs-sca-challenge-response";
  private final ScaCredentialsExtractor testSubject = new ScaCredentialsExtractor();

  @Test
  void extractShouldReturnEmptyOptionalWhenScaCredentialsNotProvided() {
    final HttpHeaders headers = new HttpHeaders();
    headers.add(X_YBS_SCA_KEY, SCA_KEY);

    final Optional<ScaCredentials> scaCredentials = testSubject.extract(headers);

    assertThat(scaCredentials.isPresent(), is(false));
  }

  @Test
  void extractShouldReturnEmptyOptionalWhenScaCredentialsNotProvidedWithNoScaKey() {
    final HttpHeaders headers = new HttpHeaders();

    final Optional<ScaCredentials> scaCredentials = testSubject.extract(headers);

    assertThat(scaCredentials.isPresent(), is(false));
  }

  @Test
  void extractShouldReturnScaCredentialsWhenProvided() {
    final String challenge = "challenge";
    final String challengeResponse = "challenge-response";
    final String scaKey = SCA_KEY;

    final HttpHeaders headers = new HttpHeaders();
    headers.add(X_YBS_SCA_CHALLENGE, challenge);
    headers.add(X_YBS_SCA_CHALLENGE_RESPONSE, challengeResponse);
    headers.add(X_YBS_SCA_KEY, scaKey);

    final Optional<ScaCredentials> scaCredentials = testSubject.extract(headers);

    assertThat(scaCredentials.isPresent(), is(true));
    assertThat(scaCredentials.get(), is(new ScaCredentials(challenge, challengeResponse, scaKey)));
  }

  @ParameterizedTest
  @MethodSource("partialScaCredentials")
  void extractShouldThrowInvalidScaHeadersExceptionWhenPartialScaCredentialsProvided(
      final String challenge,
      final String challengeResponse,
      final String scaKey,
      final String expectedMessage,
      final List<String> expectedMissingHeaders) {
    final HttpHeaders headers = new HttpHeaders();
    if (challenge != null) {
      headers.add(X_YBS_SCA_CHALLENGE, challenge);
    }
    if (challengeResponse != null) {
      headers.add(X_YBS_SCA_CHALLENGE_RESPONSE, challengeResponse);
    }
    if (scaKey != null) {
      headers.add(X_YBS_SCA_KEY, scaKey);
    }

    final InvalidScaHeadersException exception =
        assertThrows(InvalidScaHeadersException.class, () -> testSubject.extract(headers));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getMissingHeaders(), is(expectedMissingHeaders));
    assertThat(
        exception.getRequiredHeaders(),
        is(Arrays.asList(X_YBS_SCA_CHALLENGE, X_YBS_SCA_CHALLENGE_RESPONSE, X_YBS_SCA_KEY)));
  }

  private static Stream<Arguments> partialScaCredentials() {
    return Stream.of(
        Arguments.of(
            "challenge",
            null,
            null,
            "Missing headers: [x-ybs-sca-challenge-response, x-ybs-sca-key]",
            Arrays.asList(X_YBS_SCA_CHALLENGE_RESPONSE, X_YBS_SCA_KEY)),
        Arguments.of(
            null,
            "challenge-response",
            null,
            "Missing headers: [x-ybs-sca-challenge, x-ybs-sca-key]",
            Arrays.asList(X_YBS_SCA_CHALLENGE, X_YBS_SCA_KEY)),
        Arguments.of(
            "challenge",
            null,
            SCA_KEY,
            "Missing headers: [x-ybs-sca-challenge-response]",
            Collections.singletonList(X_YBS_SCA_CHALLENGE_RESPONSE)),
        Arguments.of(
            null,
            "challenge-response",
            SCA_KEY,
            "Missing headers: [x-ybs-sca-challenge]",
            Collections.singletonList(X_YBS_SCA_CHALLENGE)));
  }
}
