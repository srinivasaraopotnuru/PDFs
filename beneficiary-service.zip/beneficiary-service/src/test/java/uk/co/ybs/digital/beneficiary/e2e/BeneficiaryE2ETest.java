package uk.co.ybs.digital.beneficiary.e2e;

import static org.exparity.hamcrest.date.LocalDateTimeMatchers.within;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.emptyString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static uk.co.ybs.digital.beneficiary.e2e.TestData.CANONICAL_PARTY_ID;
import static uk.co.ybs.digital.beneficiary.e2e.TestData.DEBTOR_ACCOUNT_NUMBER;
import static uk.co.ybs.digital.beneficiary.e2e.TestData.PARTY_ID;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.LIMIT_REACHED;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.PENDING;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.UPDATE_ALREADY_APPLIED;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation.CREATE;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation.DELETE;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation.UPDATE;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Status.COMPLETE;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Status.FAILED;
import static uk.co.ybs.digital.beneficiary.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.SignatureException;
import java.time.Clock;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Stream;
import javax.persistence.Query;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.exparity.hamcrest.date.core.TemporalMatcher;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.beneficiary.IntegrationTestConfig;
import uk.co.ybs.digital.beneficiary.IntegrationTestJwtFactory;
import uk.co.ybs.digital.beneficiary.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Status;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryProcessorService;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiarySuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryViewRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.beneficiary.utils.SigningUtils;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
public class BeneficiaryE2ETest {

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";

  private static final String BENEFICIARY_SCOPE = "BENEFICIARY";
  private static final String ACCOUNT_READ_BENEFICIARY = "ACCOUNT_READ BENEFICIARY";
  private static final String BRAND_CODE_YBS = "YBS";

  private static final String BASE_PATH = "/beneficiary";
  private static final String BASE_PATH_PUBLIC = "";
  private static final String BASE_PATH_PRIVATE = "/private";
  private static final String ACCOUNT_BENEFICIARIES_PATH =
      "/accounts/" + TestData.DEBTOR_ACCOUNT_NUMBER_STRING + "/beneficiaries";

  private static final String IP_ADDRESS = "127.0.0.1";
  private static final UUID REQUEST_ID = UUID.fromString("3cfa397f-ff5d-4252-b8f0-69daac23fba4");
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  public static final String EXISTING_BENEFICIARIES = "existingBeneficiaries";
  public static final String MEMORABLE_NAME = "MEM";
  public static final String BENEFICIARY_VALIDATION_ERROR = "Beneficiary validation error";
  public static final String CURRENTLY_UNABLE_TO_SUPPORT_MODIFICATIONS_TO_THIS_BENEFICIARY =
      "Currently unable to support modifications to this beneficiary";
  public static final String RESOURCE_NOT_FOUND = "Resource not found";
  public static final String UNCHECKED_WARNING = "unchecked";
  public static final String SYS_ID = "sysId";
  public static final String CREATED_DATE = "createdDate";
  public static final String START_DATE = "startDate";
  public static final String NON_YBS_BANK_ACCOUNT = "nonYbsBankAccount";
  public static final String X_YBS_SCA_CHALLENGE = "x-ybs-sca-challenge";

  @LocalServerPort private int port;

  @Autowired private BeneficiaryProcessorService beneficiaryProcessorService;

  @Value("${uk.co.ybs.digital.product-test-port}")
  private int productTestPort;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  @Value("${uk.co.ybs.digital.account-test-port}")
  private int accountTestPort;

  @Autowired private WebTestClient signingWebClientPublic;
  @Autowired private WebTestClient signingWebClientPrivate;
  @Autowired private PrivateKey jwtSigningPrivateKey;

  private MockWebServer mockProductService;
  private MockWebServer mockAuditService;
  private MockWebServer mockAccountService;

  @Autowired private TransactionTemplate transactionTemplate;
  @Autowired private TestEntityManager coreTestEntityManager;
  @Autowired private TestEntityManager adgCoreTestEntityManager;
  @Autowired private TestEntityManager digitalBeneficiaryTestEntityManager;
  @Autowired private ObjectMapper objectMapper;
  @Autowired private Clock clock;

  private CoreHelper coreHelper;
  private AdgCoreHelper adgCoreHelper;
  private WorkLogHelper workLogHelper;
  private CoreToAdgCoreEntityConverter coreToAdgCoreEntityConverter;
  private static final String WEB_CHANNEL = "WEB";

  @BeforeEach
  void setup() throws Exception {

    mockProductService = new MockWebServer();
    mockProductService.start(productTestPort);

    mockAuditService = new MockWebServer();
    mockAuditService.start(auditTestPort);

    mockAccountService = new MockWebServer();
    mockAccountService.start(accountTestPort);

    coreHelper = new CoreHelper(transactionTemplate, coreTestEntityManager);
    adgCoreHelper = new AdgCoreHelper(transactionTemplate, adgCoreTestEntityManager, clock);
    workLogHelper =
        new WorkLogHelper(transactionTemplate, digitalBeneficiaryTestEntityManager, clock);
    coreToAdgCoreEntityConverter =
        new CoreToAdgCoreEntityConverter(transactionTemplate, adgCoreTestEntityManager);
  }

  @AfterEach
  void cleanup() throws IOException {
    mockProductService.shutdown();
    mockAuditService.shutdown();
    mockAccountService.shutdown();
    tearDownDb();
  }

  @ParameterizedTest
  @MethodSource("beneficiariesToCreate")
  <BeneficiaryT extends Beneficiary, InstructionT> void shouldCreateBeneficiary(
      final Function<CoreHelper, InstructionT> createInstruction,
      final BeneficiaryT beneficiary,
      final Class<InstructionT> instructionType)
      throws Exception {
    final InstructionT instruction = createInstruction.apply(coreHelper);
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    // Request stubs
    stubFindAccountSuccess(TestData.OTHER_INTERNAL_ACCOUNT_NUMBER);
    stubProductServiceResponse("/it/productInfoManyBeneficiaries.json");

    // Processor stubs
    mockAuditServiceResponse();

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(createValidYbsJwt(ACCOUNT_READ_BENEFICIARY)))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isAccepted();

    beneficiaryProcessorService.process();

    assertInstructions(instructionType, created(instructionType, instruction));
    assertAuditBeneficiaryCreateSuccess(beneficiary);
    assertUpdateLog(operationStatus(CREATE, COMPLETE));
  }

  @ParameterizedTest
  @MethodSource(EXISTING_BENEFICIARIES)
  <BeneficiaryT extends Beneficiary, InstructionT>
      void beneficiaryProcessorShouldRecordFailureWhenBeneficiaryAlreadyExistsInCoreButNotAdgCore(
          final Function<CoreHelper, InstructionT> setupInstruction,
          final Class<InstructionT> instructionType,
          final Class<BeneficiaryT> beneficiaryType)
          throws Exception {
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);
    final BeneficiaryT beneficiary = createBeneficiary(beneficiaryType);
    final InstructionT instruction = setupInstruction.apply(coreHelper);

    stubFindAccountSuccess(TestData.OTHER_INTERNAL_ACCOUNT_NUMBER);
    stubProductServiceResponse("/it/productInfoManyBeneficiaries.json");

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(createValidYbsJwt(ACCOUNT_READ_BENEFICIARY)))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isAccepted();

    mockAuditServiceResponse();

    beneficiaryProcessorService.process();

    assertInstructions(instructionType, samePropertyValuesAs(instruction));
    assertAuditBeneficiaryCreateFailure(beneficiary, DUPLICATE);
    assertUpdateLog(operationStatus(CREATE, FAILED));
  }

  @ParameterizedTest
  @MethodSource("existingBeneficiariesWithOtherAccountNumber")
  <BeneficiaryT extends Beneficiary, InstructionT>
      void beneficiaryProcessorShouldRecordFailureWhenBeneficiaryInCoreExceedsTheLimit(
          final Function<CoreHelper, InstructionT> setupInstruction,
          final Class<InstructionT> instructionType,
          final Class<BeneficiaryT> beneficiaryType)
          throws Exception {
    final BeneficiaryT beneficiary = createBeneficiary(beneficiaryType);

    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    // Request stubs
    stubFindAccountSuccess(TestData.OTHER_INTERNAL_ACCOUNT_NUMBER);
    stubProductServiceResponse("/it/productInfoOneOfEachBeneficiary.json");

    // Processor stubs
    mockAuditServiceResponse();

    final String jwt = createValidYbsJwt(ACCOUNT_READ_BENEFICIARY);

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(jwt))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isAccepted();

    final InstructionT instruction = setupInstruction.apply(coreHelper);

    beneficiaryProcessorService.process();

    assertInstructions(instructionType, samePropertyValuesAs(instruction));
    assertAuditBeneficiaryCreateFailure(beneficiary, LIMIT_REACHED);
    assertUpdateLog(operationStatus(CREATE, FAILED));
  }

  @ParameterizedTest
  @MethodSource("existingBeneficiariesForFailedWorkLogs")
  <BeneficiaryT extends Beneficiary, InstructionT> void shouldDeleteBeneficiary(
      final Function<CoreHelper, InstructionT> setupInstruction,
      final Class<InstructionT> instructionType,
      final Class<BeneficiaryT> beneficiaryType,
      final boolean hasPreviousFailedWorkLog)
      throws Exception {
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);
    final KeyPair keyPair = SigningUtils.generateKeyPair();

    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);
    final InstructionT instruction = setupInstruction.apply(coreHelper);

    syncCoreBeneficiariesToAdgCore();

    stubForRequest(); // Get request
    stubForRequest(); // Initial request stubs
    stubForRequest(); // SCA'd request stubs
    mockAuditServiceResponse(); // processor stubs

    final BeneficiaryT beneficiary = getBeneficiary(jwt, beneficiaryType);

    if (hasPreviousFailedWorkLog) {
      final RequestMetadata metadata =
          TestHelper.buildValidRequestMetadata(UUID.randomUUID(), port, jwt);
      final long sysId =
          instruction instanceof BillPaymentInstruction
              ? ((BillPaymentInstruction) instruction).getSysId()
              : ((ItInstruction) instruction).getSysId();
      workLogHelper.setupWorkLog(sysId, DELETE, beneficiary, metadata);
    }

    sendDeleteRequest(jwt, keyPair, beneficiary);

    beneficiaryProcessorService.process();

    assertInstructions(instructionType, deleted(instructionType, instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertAuditBeneficiaryDeleteSuccess(beneficiary);
    if (hasPreviousFailedWorkLog) {
      assertUpdateLog(operationStatus(DELETE, FAILED), operationStatus(DELETE, COMPLETE));
    } else {
      assertUpdateLog(operationStatus(DELETE, COMPLETE));
    }
  }

  @ParameterizedTest
  @MethodSource("existingBeneficiariesForFailedWorkLogs")
  <BeneficiaryT extends Beneficiary, InstructionT> void shouldDeleteBeneficiaryWithoutScaForWeb(
      final Function<CoreHelper, InstructionT> setupInstruction,
      final Class<InstructionT> instructionType,
      final Class<BeneficiaryT> beneficiaryType,
      final boolean hasPreviousFailedWorkLog)
      throws Exception {
    final String jwt = createValidYbsJwtWithChannel(BENEFICIARY_SCOPE, WEB_CHANNEL);

    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);
    final InstructionT instruction = setupInstruction.apply(coreHelper);

    syncCoreBeneficiariesToAdgCore();

    stubForRequest(); // Get request
    stubForRequest(); // Initial request stubs
    stubForRequest(); // SCA'd request stubs
    mockAuditServiceResponse(); // processor stubs

    final BeneficiaryT beneficiary = getBeneficiary(jwt, beneficiaryType);

    if (hasPreviousFailedWorkLog) {
      final RequestMetadata metadata =
          TestHelper.buildValidRequestMetadata(UUID.randomUUID(), port, jwt);
      final long sysId =
          instruction instanceof BillPaymentInstruction
              ? ((BillPaymentInstruction) instruction).getSysId()
              : ((ItInstruction) instruction).getSysId();
      workLogHelper.setupWorkLog(sysId, DELETE, beneficiary, metadata);
    }

    sendDeleteRequestForWebWithoutSca(jwt, beneficiary);

    beneficiaryProcessorService.process();

    assertInstructions(instructionType, deleted(instructionType, instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryDeleteSuccess(beneficiary);
    if (hasPreviousFailedWorkLog) {
      assertUpdateLog(operationStatus(DELETE, FAILED), operationStatus(DELETE, COMPLETE));
    } else {
      assertUpdateLog(operationStatus(DELETE, COMPLETE));
    }
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void shouldUpdateExternalBeneficiary(final boolean hasPreviousFailedWorkLog) throws Exception {
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);
    final KeyPair keyPair = SigningUtils.generateKeyPair();

    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            Long.parseLong(TestData.SORT_CODE),
            coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE)),
            false);
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    stubForRequest(); // Get beneficiaries request
    stubForRequest(); // Initial update beneficiary request
    stubForRequest(); // SCAd update beneficiary request
    mockAuditServiceResponse(); // processor stubs

    syncCoreBeneficiariesToAdgCore();

    final ExternalBeneficiary beneficiary = getBeneficiary(jwt, ExternalBeneficiary.class);
    final ExternalBeneficiary updatedBeneficiary =
        beneficiary.toBuilder().memorableName(MEMORABLE_NAME).build();

    if (hasPreviousFailedWorkLog) {
      final RequestMetadata metadata =
          TestHelper.buildValidRequestMetadata(UUID.randomUUID(), port, jwt);
      workLogHelper.setupWorkLog(instruction.getSysId(), UPDATE, beneficiary, metadata);
    }

    sendUpdateRequest(jwt, keyPair, updatedBeneficiary);

    beneficiaryProcessorService.process();

    final BillPaymentInstruction newInstruction =
        coreHelper
            .createBillPaymentInstruction(
                DEBTOR_ACCOUNT_NUMBER, instruction.getNonYbsBankAccount(), false)
            .toBuilder()
            .memorableName(MEMORABLE_NAME)
            .build();

    assertInstructions(BillPaymentInstruction.class, deleted(instruction), updated(newInstruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertAuditBeneficiaryUpdateSuccess(updatedBeneficiary, instruction);

    if (hasPreviousFailedWorkLog) {
      assertUpdateLog(operationStatus(UPDATE, FAILED), operationStatus(UPDATE, COMPLETE));
    } else {
      assertUpdateLog(operationStatus(UPDATE, COMPLETE));
    }
  }

  @Test
  void beneficiariesPendingUpdateShouldBeMarkedPendingInGetResponse() throws Exception {
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);
    final KeyPair keyPair = SigningUtils.generateKeyPair();

    final FinancialInstitution institution =
        coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE));
    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            Long.parseLong(TestData.SORT_CODE),
            institution,
            false);
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    stubForRequest(); // Get request

    stubForRequest(); // Initial update request
    stubForRequest(); // SCAd update request
    mockAuditServiceResponse(); // Process update request

    stubForRequest(); // Second get request

    syncCoreBeneficiariesToAdgCore();

    // First update should succeed
    final ExternalBeneficiary beneficiary = getBeneficiary(jwt, ExternalBeneficiary.class);
    final ExternalBeneficiary updatedBeneficiary =
        beneficiary.toBuilder().memorableName(MEMORABLE_NAME).build();
    sendUpdateRequest(jwt, keyPair, updatedBeneficiary);

    final ExternalBeneficiary updatedBeneficiary2 = getBeneficiary(jwt, ExternalBeneficiary.class);
    assertThat(updatedBeneficiary2, hasProperty("pending", is(true)));

    assertInstructions(BillPaymentInstruction.class, equalTo(instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);

    assertAuditBeneficiariesView(jwt);
    assertUpdateLog(operationStatus(UPDATE, Status.PENDING));
  }

  @Test
  void shouldNotApplyMultipleUpdatesWithinTheSameDay() throws Exception {
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);
    final KeyPair keyPair = SigningUtils.generateKeyPair();

    final FinancialInstitution institution =
        coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE));
    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            Long.parseLong(TestData.SORT_CODE),
            institution,
            false);
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    stubForRequest(); // Get request

    stubForRequest(); // Initial update request
    stubForRequest(); // SCAd update request
    mockAuditServiceResponse(); // Process update request

    stubForRequest(); // Second get request

    stubForRequest(); // Rejected update request

    syncCoreBeneficiariesToAdgCore();

    // First update should succeed
    final ExternalBeneficiary beneficiary = getBeneficiary(jwt, ExternalBeneficiary.class);
    final ExternalBeneficiary updatedBeneficiary =
        beneficiary.toBuilder().memorableName(MEMORABLE_NAME).build();
    sendUpdateRequest(jwt, keyPair, updatedBeneficiary);
    beneficiaryProcessorService.process();

    // Second update should be rejected as there has been an update since the last time core was
    // synced
    final ExternalBeneficiary beneficiary2 = getBeneficiary(jwt, ExternalBeneficiary.class);
    final ExternalBeneficiary updatedBeneficiary2 =
        beneficiary2.toBuilder().memorableName("MEM2").build();

    signingWebClientPublic
        .put()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(jwt))
        .bodyValue(updatedBeneficiary2)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(
            ErrorResponse.builder(HttpStatus.CONFLICT)
                .id(REQUEST_ID)
                .message(BENEFICIARY_VALIDATION_ERROR)
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorResponse.ErrorItem.BENEFICIARY_REJECTED_PENDING)
                        .message(CURRENTLY_UNABLE_TO_SUPPORT_MODIFICATIONS_TO_THIS_BENEFICIARY)
                        .build())
                .build());

    final BillPaymentInstruction newInstruction =
        coreHelper
            .createBillPaymentInstruction(
                DEBTOR_ACCOUNT_NUMBER, instruction.getNonYbsBankAccount(), false)
            .toBuilder()
            .memorableName(MEMORABLE_NAME)
            .build();

    assertInstructions(BillPaymentInstruction.class, deleted(instruction), updated(newInstruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertAuditBeneficiaryUpdateSuccess(updatedBeneficiary, instruction);

    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryUpdateFailure(updatedBeneficiary2, instruction, PENDING);
    assertUpdateLog(operationStatus(UPDATE, COMPLETE));
  }

  @Test
  void secondUpdateShouldSucceedAfterUpdateIsSyncedWithAdgCore() throws Exception {
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);
    final KeyPair keyPair = SigningUtils.generateKeyPair();

    final FinancialInstitution institution =
        coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE));
    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            Long.parseLong(TestData.SORT_CODE),
            institution,
            false);
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    stubForRequest(); // Get request

    stubForRequest(); // Initial update request
    stubForRequest(); // SCAd update request
    mockAuditServiceResponse(); // Process update request

    stubForRequest(); // Second get request

    stubForRequest(); // Initial second update request
    stubForRequest(); // SCAd second update request

    syncCoreBeneficiariesToAdgCore();

    // First update should succeed
    final ExternalBeneficiary beneficiary = getBeneficiary(jwt, ExternalBeneficiary.class);
    final ExternalBeneficiary updatedBeneficiary =
        beneficiary.toBuilder().memorableName(MEMORABLE_NAME).build();
    sendUpdateRequest(jwt, keyPair, updatedBeneficiary);
    beneficiaryProcessorService.process();

    syncCoreBeneficiariesToAdgCore();

    final ExternalBeneficiary beneficiary2 = getBeneficiary(jwt, ExternalBeneficiary.class);
    final ExternalBeneficiary updatedBeneficiary2 =
        beneficiary2.toBuilder().memorableName("MEM2").build();
    sendUpdateRequest(jwt, keyPair, updatedBeneficiary2);

    final BillPaymentInstruction firstUpdateInstruction =
        coreHelper
            .createBillPaymentInstruction(
                DEBTOR_ACCOUNT_NUMBER, instruction.getNonYbsBankAccount(), false)
            .toBuilder()
            .memorableName(MEMORABLE_NAME)
            .build();

    assertInstructions(
        BillPaymentInstruction.class, deleted(instruction), updated(firstUpdateInstruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertAuditBeneficiaryUpdateSuccess(updatedBeneficiary, instruction);

    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertUpdateLog(operationStatus(UPDATE, COMPLETE), operationStatus(UPDATE, Status.PENDING));
  }

  @Test
  void shouldNotUpdateIfUpdateDetailsAreTheSame() throws Exception {
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);
    final KeyPair keyPair = SigningUtils.generateKeyPair();

    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            Long.parseLong(TestData.SORT_CODE),
            coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE)),
            false);
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    stubForRequest(); // Get beneficiaries request
    stubForRequest(); // Initial update request
    stubForRequest(); // SCAd update request

    mockAuditServiceResponse(); // process update request

    syncCoreBeneficiariesToAdgCore();

    // Update with the exactly same data we received
    final ExternalBeneficiary beneficiary = getBeneficiary(jwt, ExternalBeneficiary.class);
    sendUpdateRequest(jwt, keyPair, beneficiary);
    beneficiaryProcessorService.process();

    assertInstructions(BillPaymentInstruction.class, equalTo(instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertAuditBeneficiaryUpdateFailure(beneficiary, instruction, UPDATE_ALREADY_APPLIED);
    assertUpdateLog(operationStatus(UPDATE, FAILED));
  }

  @Test
  void shouldNotUpdateBeneficiariesPendingDeletion() throws Exception {
    final KeyPair keyPair = SigningUtils.generateKeyPair();
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);

    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            Long.parseLong(TestData.SORT_CODE),
            coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE)),
            false);
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    stubForRequest(); // Get request stubs
    stubForRequest(); // Initial delete request stubs
    stubForRequest(); // SCA'd delete request stubs
    stubForRequest(); // Initial update request stubs

    syncCoreBeneficiariesToAdgCore();

    // Delete request
    final ExternalBeneficiary beneficiary = getBeneficiary(jwt, ExternalBeneficiary.class);
    sendDeleteRequest(jwt, keyPair, beneficiary);

    // Update request
    final ExternalBeneficiary updatedBeneficiary =
        beneficiary.toBuilder().memorableName(MEMORABLE_NAME).build();
    signingWebClientPublic
        .put()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(jwt))
        .bodyValue(updatedBeneficiary)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(
            ErrorResponse.builder(HttpStatus.CONFLICT)
                .id(REQUEST_ID)
                .message(BENEFICIARY_VALIDATION_ERROR)
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorResponse.ErrorItem.BENEFICIARY_REJECTED_PENDING)
                        .message(CURRENTLY_UNABLE_TO_SUPPORT_MODIFICATIONS_TO_THIS_BENEFICIARY)
                        .build())
                .build());

    assertInstructions(BillPaymentInstruction.class, equalTo(instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);

    assertAuditBeneficiaryUpdateFailure(updatedBeneficiary, instruction, PENDING);
    assertUpdateLog(operationStatus(DELETE, Status.PENDING));
  }

  @ParameterizedTest
  @MethodSource(EXISTING_BENEFICIARIES)
  <BeneficiaryT extends Beneficiary, InstructionT>
      void beneficiariesPendingDeletionShouldBeMarkedPendingInGetResponse(
          final Function<CoreHelper, InstructionT> setupInstruction,
          final Class<InstructionT> instructionType,
          final Class<BeneficiaryT> beneficiaryType)
          throws Exception {
    final KeyPair keyPair = SigningUtils.generateKeyPair();
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);

    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    final InstructionT instruction = setupInstruction.apply(coreHelper);

    stubForRequest(); // Get request stubs

    stubForRequest(); // Initial delete request stubs
    stubForRequest(); // SCA'd delete request stubs

    stubForRequest(); // Second delete request stubs

    syncCoreBeneficiariesToAdgCore();

    final BeneficiaryT beneficiary = getBeneficiary(jwt, beneficiaryType);

    // Send first delete request
    sendDeleteRequest(jwt, keyPair, beneficiary);

    final BeneficiaryT deletedBeneficiary = getBeneficiary(jwt, beneficiaryType);
    assertThat(deletedBeneficiary, hasProperty("pending", is(true)));

    assertInstructions(instructionType, equalTo(instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);

    assertAuditBeneficiariesView(jwt);
    assertUpdateLog(operationStatus(DELETE, Status.PENDING));
  }

  @Test
  void shouldNotUpdateBeneficiariesAfterDeletionJobHasRunAndRemovedFromAdgCore() throws Exception {
    final KeyPair keyPair = SigningUtils.generateKeyPair();
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);

    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            Long.parseLong(TestData.SORT_CODE),
            coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE)),
            false);
    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    stubForRequest(); // Get request stubs
    stubForRequest(); // Initial delete request stubs
    stubForRequest(); // SCA'd delete request stubs

    mockAuditServiceResponse(); // Processor stubs

    syncCoreBeneficiariesToAdgCore();

    // Delete request
    final ExternalBeneficiary beneficiary = getBeneficiary(jwt, ExternalBeneficiary.class);
    sendDeleteRequest(jwt, keyPair, beneficiary);

    beneficiaryProcessorService.process();

    syncCoreBeneficiariesToAdgCore();

    // Update request
    final ExternalBeneficiary updatedBeneficiary =
        beneficiary.toBuilder().memorableName(MEMORABLE_NAME).build();
    signingWebClientPublic
        .put()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(jwt))
        .bodyValue(updatedBeneficiary)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.NOT_FOUND)
        .expectBody(ErrorResponse.class)
        .isEqualTo(
            ErrorResponse.builder(HttpStatus.NOT_FOUND)
                .id(REQUEST_ID)
                .message(RESOURCE_NOT_FOUND)
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.RESOURCE_NOT_FOUND)
                        .message(RESOURCE_NOT_FOUND)
                        .build())
                .build());

    assertInstructions(BillPaymentInstruction.class, deleted(instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertAuditBeneficiaryDeleteSuccess(beneficiary);

    assertUpdateLog(operationStatus(DELETE, COMPLETE));
  }

  @ParameterizedTest
  @MethodSource(EXISTING_BENEFICIARIES)
  <BeneficiaryT extends Beneficiary, InstructionT>
      void shouldHandleDeletingABeneficiaryPendingDeletion(
          final Function<CoreHelper, InstructionT> setupInstruction,
          final Class<InstructionT> instructionType,
          final Class<BeneficiaryT> beneficiaryType)
          throws Exception {
    final KeyPair keyPair = SigningUtils.generateKeyPair();
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);

    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    final InstructionT instruction = setupInstruction.apply(coreHelper);

    stubForRequest(); // Get request stubs

    stubForRequest(); // Initial delete request stubs
    stubForRequest(); // SCA'd delete request stubs

    stubForRequest(); // Second delete request stubs

    syncCoreBeneficiariesToAdgCore();

    final BeneficiaryT beneficiary = getBeneficiary(jwt, beneficiaryType);

    // Send first delete request
    sendDeleteRequest(jwt, keyPair, beneficiary);

    // Send second delete request
    signingWebClientPublic
        .delete()
        .uri(
            getURI(
                BASE_PATH_PUBLIC,
                ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiary.getBeneficiaryId()))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(
            ErrorResponse.builder(HttpStatus.CONFLICT)
                .id(REQUEST_ID)
                .message(BENEFICIARY_VALIDATION_ERROR)
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorResponse.ErrorItem.BENEFICIARY_REJECTED_PENDING)
                        .message(CURRENTLY_UNABLE_TO_SUPPORT_MODIFICATIONS_TO_THIS_BENEFICIARY)
                        .build())
                .build());

    assertInstructions(instructionType, equalTo(instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);

    assertAuditBeneficiaryDeleteFailure(beneficiary);
    assertUpdateLog(operationStatus(DELETE, Status.PENDING));
  }

  @ParameterizedTest
  @MethodSource(EXISTING_BENEFICIARIES)
  <BeneficiaryT extends Beneficiary, InstructionT>
      void shouldHandleDeletingBeneficiaryThatIsDeletedButNotRemovedFromAdgCore(
          final Function<CoreHelper, InstructionT> setupInstruction,
          final Class<InstructionT> instructionType,
          final Class<BeneficiaryT> beneficiaryType)
          throws Exception {
    final KeyPair keyPair = SigningUtils.generateKeyPair();
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);

    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    final InstructionT instruction = setupInstruction.apply(coreHelper);

    stubForRequest(); // Get request stubs

    stubForRequest(); // Initial delete request stubs
    stubForRequest(); // SCA'd delete request stubs
    mockAuditServiceResponse(); // processor delete stubs

    stubForRequest(); // Second delete request stubs

    syncCoreBeneficiariesToAdgCore();

    final BeneficiaryT beneficiary = getBeneficiary(jwt, beneficiaryType);

    // Send first request
    sendDeleteRequest(jwt, keyPair, beneficiary);
    beneficiaryProcessorService.process();

    // Send second delete request
    signingWebClientPublic
        .delete()
        .uri(
            getURI(
                BASE_PATH_PUBLIC,
                ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiary.getBeneficiaryId()))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(
            ErrorResponse.builder(HttpStatus.CONFLICT)
                .id(REQUEST_ID)
                .message(BENEFICIARY_VALIDATION_ERROR)
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorResponse.ErrorItem.BENEFICIARY_REJECTED_PENDING)
                        .message(CURRENTLY_UNABLE_TO_SUPPORT_MODIFICATIONS_TO_THIS_BENEFICIARY)
                        .build())
                .build());

    assertInstructions(instructionType, equalTo(instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertAuditBeneficiaryDeleteSuccess(beneficiary);

    assertAuditBeneficiaryDeleteFailure(beneficiary);
    assertUpdateLog(operationStatus(DELETE, COMPLETE));
  }

  @ParameterizedTest
  @MethodSource(EXISTING_BENEFICIARIES)
  <BeneficiaryT extends Beneficiary, InstructionT>
      void shouldHandleDeletingBeneficiaryThatIsDeletedAndRemovedFromAdgCore(
          final Function<CoreHelper, InstructionT> setupInstruction,
          final Class<InstructionT> instructionType,
          final Class<BeneficiaryT> beneficiaryType)
          throws Exception {
    final KeyPair keyPair = SigningUtils.generateKeyPair();
    final String jwt = createValidYbsJwt(BENEFICIARY_SCOPE);

    adgCoreHelper.setUpAccountAccessRequiredEntities(DEBTOR_ACCOUNT_NUMBER);

    final InstructionT instruction = setupInstruction.apply(coreHelper);

    stubForRequest(); // Get request stubs

    stubForRequest(); // Initial delete request stubs
    stubForRequest(); // SCA'd delete request stubs
    mockAuditServiceResponse(); // processor delete stubs

    syncCoreBeneficiariesToAdgCore();

    final BeneficiaryT beneficiary = getBeneficiary(jwt, beneficiaryType);

    // Send first request
    sendDeleteRequest(jwt, keyPair, beneficiary);
    beneficiaryProcessorService.process();

    syncCoreBeneficiariesToAdgCore();

    // Send second delete request
    signingWebClientPublic
        .delete()
        .uri(
            getURI(
                BASE_PATH_PUBLIC,
                ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiary.getBeneficiaryId()))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectBody(ErrorResponse.class)
        .isEqualTo(
            ErrorResponse.builder(HttpStatus.NOT_FOUND)
                .id(REQUEST_ID)
                .message(RESOURCE_NOT_FOUND)
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.RESOURCE_NOT_FOUND)
                        .message(RESOURCE_NOT_FOUND)
                        .build())
                .build());

    assertInstructions(instructionType, equalTo(instruction));
    assertAuditBeneficiariesView(jwt);
    assertAuditBeneficiaryChallenge(jwt);
    assertAuditBeneficiaryChallengeSuccess(jwt);
    assertAuditBeneficiaryDeleteSuccess(beneficiary);

    assertUpdateLog(operationStatus(DELETE, COMPLETE));
  }

  @SuppressWarnings("ConstantConditions")
  private void syncCoreBeneficiariesToAdgCore() {
    final List<BillPaymentInstruction> externalInstructions =
        transactionTemplate.execute(
            status ->
                coreTestEntityManager
                    .getEntityManager()
                    .createQuery(
                        "select i from BillPaymentInstruction i", BillPaymentInstruction.class)
                    .getResultList());
    externalInstructions.forEach(coreToAdgCoreEntityConverter::syncToAdgCore);

    final List<ItInstruction> internalInstructions =
        transactionTemplate.execute(
            status ->
                coreTestEntityManager
                    .getEntityManager()
                    .createQuery("select i from ItInstruction i", ItInstruction.class)
                    .getResultList());
    internalInstructions.forEach(coreToAdgCoreEntityConverter::syncToAdgCore);
  }

  private static ExternalBeneficiary createExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .accountNumber(TestData.EXTERNAL_ACCOUNT_NUMBER)
        .accountSortCode(TestData.SORT_CODE)
        .memorableName(TestData.MEMORABLE_NAME)
        .name(TestData.NAME)
        .reference(TestData.REFERENCE)
        .build();
  }

  private TemporalMatcher<LocalDateTime> withinTenSecondsOf(final LocalDateTime time) {
    return within(10, ChronoUnit.SECONDS, time);
  }

  private void mockAuditServiceResponse() {
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  private void assertAuditBeneficiaryCreateFailure(
      final Beneficiary beneficiary, final BeneficiaryValidationExceptionReason reason)
      throws InterruptedException, JsonProcessingException {
    assertAuditBeneficiaryFailure(beneficiary, reason, "/audit/beneficiary/create/failure");
  }

  private void assertAuditBeneficiaryDeleteFailure(final Beneficiary beneficiary)
      throws InterruptedException, JsonProcessingException {
    assertAuditBeneficiaryFailure(beneficiary, PENDING, "/audit/beneficiary/delete/failure");
  }

  private void assertAuditBeneficiaryFailure(
      final Beneficiary beneficiary,
      final BeneficiaryValidationExceptionReason reason,
      final String path)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest(path);

    if (beneficiary instanceof ExternalBeneficiary) {
      assertExternalBeneficiaryAuditFailure(request, (ExternalBeneficiary) beneficiary, reason);
    } else {
      assertInternalBeneficiaryAuditFailure(request, (InternalBeneficiary) beneficiary, reason);
    }
  }

  private void assertExternalBeneficiaryAuditFailure(
      final RecordedRequest request,
      final ExternalBeneficiary beneficiary,
      final BeneficiaryValidationExceptionReason reason)
      throws JsonProcessingException {
    final AuditBeneficiaryFailureRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiaryFailureRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiaryFailureRequest.builder()
                .ipAddress(IP_ADDRESS)
                .message(reason.getDescription())
                .beneficiaryInformation(
                    ExternalBeneficiaryInformation.builder()
                        .memorableName(beneficiary.getMemorableName())
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .reference(beneficiary.getReference())
                        .payeeSortCode(beneficiary.getAccountSortCode())
                        .payeeName(beneficiary.getName())
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .build())
                .build()));
  }

  private void assertInternalBeneficiaryAuditFailure(
      final RecordedRequest request,
      final InternalBeneficiary beneficiary,
      final BeneficiaryValidationExceptionReason reason)
      throws JsonProcessingException {
    final AuditBeneficiaryFailureRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiaryFailureRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiaryFailureRequest.builder()
                .ipAddress(IP_ADDRESS)
                .message(reason.getDescription())
                .beneficiaryInformation(
                    InternalBeneficiaryInformation.builder()
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .build())
                .build()));
  }

  private void assertAuditBeneficiaryCreateSuccess(final Beneficiary beneficiary)
      throws InterruptedException, JsonProcessingException {
    assertAuditBeneficiarySuccess(beneficiary, "/audit/beneficiary/create/success");
  }

  private void assertAuditBeneficiaryDeleteSuccess(final Beneficiary beneficiary)
      throws InterruptedException, JsonProcessingException {
    assertAuditBeneficiarySuccess(beneficiary, "/audit/beneficiary/delete/success");
  }

  private void assertAuditBeneficiarySuccess(final Beneficiary beneficiary, final String path)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest(path);

    if (beneficiary instanceof ExternalBeneficiary) {
      assertExternalBeneficiaryAuditSuccess(request, (ExternalBeneficiary) beneficiary);
    } else {
      assertInternalBeneficiaryAuditSuccess(request, (InternalBeneficiary) beneficiary);
    }
  }

  private void assertExternalBeneficiaryAuditSuccess(
      final RecordedRequest request, final ExternalBeneficiary beneficiary)
      throws JsonProcessingException {
    final AuditBeneficiarySuccessRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiarySuccessRequest.class);

    final AuditBeneficiarySuccessRequest expected =
        AuditBeneficiarySuccessRequest.builder()
            .ipAddress(IP_ADDRESS)
            .beneficiaryInformation(
                ExternalBeneficiaryInformation.builder()
                    .memorableName(beneficiary.getMemorableName())
                    .payeeAccountNumber(beneficiary.getAccountNumber())
                    .reference(beneficiary.getReference())
                    .payeeSortCode(beneficiary.getAccountSortCode())
                    .payeeName(beneficiary.getName())
                    .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                    .build())
            .build();

    assertThat(actual, is(expected));
  }

  private void assertInternalBeneficiaryAuditSuccess(
      final RecordedRequest request, final InternalBeneficiary beneficiary)
      throws JsonProcessingException {
    final AuditBeneficiarySuccessRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiarySuccessRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiarySuccessRequest.builder()
                .ipAddress(IP_ADDRESS)
                .beneficiaryInformation(
                    InternalBeneficiaryInformation.builder()
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .build())
                .build()));
  }

  private void assertAuditBeneficiaryUpdateSuccess(
      final ExternalBeneficiary beneficiary, final BillPaymentInstruction originalInstruction)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest("/audit/beneficiary/update/success");
    final AuditBeneficiaryUpdateSuccessRequest actual =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditBeneficiaryUpdateSuccessRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiaryUpdateSuccessRequest.builder()
                .ipAddress(IP_ADDRESS)
                .beneficiaryInformation(
                    ExternalBeneficiaryInformation.builder()
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .payeeSortCode(beneficiary.getAccountSortCode())
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .payeeName(beneficiary.getName())
                        .reference(originalInstruction.getReference())
                        .memorableName(originalInstruction.getMemorableName())
                        .build())
                .updateBeneficiaryInformation(
                    ExternalUpdateBeneficiaryInformation.builder()
                        .reference(beneficiary.getReference())
                        .memorableName(beneficiary.getMemorableName())
                        .build())
                .build()));
  }

  private void assertAuditBeneficiaryUpdateFailure(
      final ExternalBeneficiary beneficiary,
      final BillPaymentInstruction originalInstruction,
      final BeneficiaryValidationExceptionReason reason)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest("/audit/beneficiary/update/failure");
    final AuditBeneficiaryUpdateFailureRequest actual =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditBeneficiaryUpdateFailureRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiaryUpdateFailureRequest.builder()
                .ipAddress(IP_ADDRESS)
                .message(reason.getDescription())
                .beneficiaryInformation(
                    ExternalBeneficiaryInformation.builder()
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .payeeSortCode(beneficiary.getAccountSortCode())
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .payeeName(beneficiary.getName())
                        .reference(originalInstruction.getReference())
                        .memorableName(originalInstruction.getMemorableName())
                        .build())
                .updateBeneficiaryInformation(
                    ExternalUpdateBeneficiaryInformation.builder()
                        .reference(beneficiary.getReference())
                        .memorableName(beneficiary.getMemorableName())
                        .build())
                .build()));
  }

  private RecordedRequest assertAuditRequest(final String path) throws InterruptedException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());
    return request;
  }

  @SafeVarargs
  private final void assertUpdateLog(final Matcher<WorkLog>... matchers) {
    final List<WorkLog> workLog =
        transactionTemplate.execute(
            status ->
                digitalBeneficiaryTestEntityManager
                    .getEntityManager()
                    .createQuery("select w from WorkLog w", WorkLog.class)
                    .getResultList());
    assertThat(workLog, containsInAnyOrder(matchers));
  }

  private void assertInstructions(final Class<?> instructionType, final Matcher<?>... expected) {
    assertEntities(instructionType.getSimpleName(), expected);
  }

  @SuppressWarnings(UNCHECKED_WARNING)
  private void assertEntities(final String table, final Matcher<?>[] expected) {
    final List<?> actual =
        transactionTemplate.execute(
            transactionStatus -> {
              final Query query =
                  coreTestEntityManager
                      .getEntityManager()
                      .createQuery("select e from " + table + " e");
              return query.getResultList();
            });
    assertThat(actual, containsInAnyOrder((Matcher<Object>[]) expected));
  }

  private void tearDownDb() {
    workLogHelper.clearDb();
    adgCoreHelper.clearDb();
    coreHelper.clearDb();
  }

  private String createValidYbsJwt(final String requiredScope) {
    return IntegrationTestJwtFactory.createJwt(
        IntegrationTestJwtFactory.claimsMap(
            PARTY_ID, CANONICAL_PARTY_ID, SESSION_ID, requiredScope, BRAND_CODE_YBS),
        jwtSigningPrivateKey);
  }

  private String createValidYbsJwtWithChannel(final String requiredScope, final String channel) {
    return IntegrationTestJwtFactory.createJwt(
        IntegrationTestJwtFactory.claimsMapWithChannel(
            PARTY_ID,
            CANONICAL_PARTY_ID,
            SESSION_ID.toString(),
            requiredScope,
            BRAND_CODE_YBS,
            channel),
        jwtSigningPrivateKey);
  }

  private void stubAccountServiceResponse(final HttpStatus httpStatus, final String response) {
    mockAccountService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(response));
  }

  private void stubFindAccountSuccess(final String accountNumber) {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource(
            String.format("api/account/account/ResponseAccountNumber%s.json", accountNumber)));
  }

  private void stubProductServiceResponse(final String resourcePath) {
    ClassPathResource resource = new ClassPathResource(resourcePath);
    mockProductService.enqueue(
        new MockResponse()
            .setHeader("Content-Type", "application/json")
            .setBody(readClassPathResource(resource)));
  }

  private URI getURI(final String basePath, final String path) {
    return URI.create("http://localhost:" + port + BASE_PATH + basePath + path);
  }

  private Consumer<HttpHeaders> standardHeaders(final String jwt) {
    return headers -> {
      standardHeaders().accept(headers);
      headers.setBearerAuth(jwt);
    };
  }

  private Consumer<HttpHeaders> standardHeaders() {
    return headers -> {
      headers.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON));
      headers.setHost(new InetSocketAddress("localhost", 0));
      headers.add(HEADER_REQUEST_ID, REQUEST_ID.toString());
    };
  }

  private void assertAuditBeneficiaryChallenge(final String jwt)
      throws JsonProcessingException, InterruptedException {
    final AuditBeneficiaryChallengeRequest request =
        AuditBeneficiaryChallengeRequest.builder().ipAddress("127.0.0.1").build();
    assertAuditBeneficiaryRequest(
        jwt,
        "/audit/beneficiary/authentication/challenge",
        request,
        AuditBeneficiaryChallengeRequest.class);
  }

  private void assertAuditBeneficiaryChallengeSuccess(final String jwt)
      throws JsonProcessingException, InterruptedException {
    final AuditBeneficiaryChallengeSuccessRequest request =
        AuditBeneficiaryChallengeSuccessRequest.builder().ipAddress("127.0.0.1").build();
    assertAuditBeneficiaryRequest(
        jwt,
        "/audit/beneficiary/authentication/success",
        request,
        AuditBeneficiaryChallengeSuccessRequest.class);
  }

  private <T> void assertAuditBeneficiaryRequest(
      final String jwt, final String path, final T payload, final Class<T> payloadClass)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final T actual = objectMapper.readValue(request.getBody().readUtf8(), payloadClass);
    assertThat(actual, is(payload));
  }

  private void assertAuditBeneficiariesView(final String jwt)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is("/audit/beneficiary/view"));
    assertThat(request.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditBeneficiaryViewRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiaryViewRequest.class);
    assertThat(
        actual,
        is(
            AuditBeneficiaryViewRequest.builder()
                .beneficiaryInformation(
                    AuditBeneficiaryViewRequest.BeneficiaryInformation.builder()
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .build())
                .ipAddress(IP_ADDRESS)
                .build()));
  }

  @SuppressWarnings(UNCHECKED_WARNING)
  private <T> Matcher<T> created(final Class<T> instructionType, final T instruction) {
    if (instructionType == BillPaymentInstruction.class) {
      return (Matcher<T>) created((BillPaymentInstruction) instruction);
    } else if (instructionType == ItInstruction.class) {
      return (Matcher<T>) created((ItInstruction) instruction);
    }

    throw new IllegalArgumentException("argument is not a valid instruction type");
  }

  private Matcher<ItInstruction> created(final ItInstruction instruction) {
    LocalDateTime now = LocalDateTime.now(clock);
    return allOf(
        samePropertyValuesAs(instruction, SYS_ID, CREATED_DATE, START_DATE),
        hasProperty(SYS_ID, notNullValue(Long.class)),
        hasProperty(CREATED_DATE, withinTenSecondsOf(now)),
        hasProperty(START_DATE, withinTenSecondsOf(now)));
  }

  private Matcher<BillPaymentInstruction> created(final BillPaymentInstruction instruction) {
    final LocalDateTime now = LocalDateTime.now(clock);
    return allOf(
        samePropertyValuesAs(instruction, SYS_ID, CREATED_DATE, START_DATE, NON_YBS_BANK_ACCOUNT),
        hasProperty(SYS_ID, notNullValue(Long.class)),
        hasProperty(CREATED_DATE, withinTenSecondsOf(now)),
        hasProperty(START_DATE, withinTenSecondsOf(now)),
        hasProperty(
            NON_YBS_BANK_ACCOUNT,
            samePropertyValuesAs(instruction.getNonYbsBankAccount(), SYS_ID)));
  }

  private Matcher<BillPaymentInstruction> updated(final BillPaymentInstruction instruction) {
    final LocalDateTime now = LocalDateTime.now(clock);
    return allOf(
        samePropertyValuesAs(instruction, SYS_ID, CREATED_DATE, NON_YBS_BANK_ACCOUNT),
        hasProperty(SYS_ID, notNullValue(Long.class)),
        hasProperty(CREATED_DATE, withinTenSecondsOf(now)),
        hasProperty(
            NON_YBS_BANK_ACCOUNT,
            samePropertyValuesAs(instruction.getNonYbsBankAccount(), SYS_ID)));
  }

  private Matcher<WorkLog> operationStatus(
      final WorkLog.Operation operation, final WorkLog.Status status) {
    return allOf(
        hasProperty("operation", equalTo(operation)), hasProperty("status", equalTo(status)));
  }

  @SuppressWarnings({UNCHECKED_WARNING, "OptionalGetWithoutIsPresent"})
  private <T extends Beneficiary> T getBeneficiary(final String jwt, final Class<T> type) {
    return getBeneficiaries(jwt).stream()
        .filter(type::isInstance)
        .map(b -> (T) b)
        .findFirst()
        .get();
  }

  private <T extends Beneficiary> void sendDeleteRequest(
      final String jwt, final KeyPair keyPair, final T beneficiary) throws Exception {
    final String challenge =
        signingWebClientPublic
            .delete()
            .uri(
                getURI(
                    BASE_PATH_PUBLIC,
                    ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiary.getBeneficiaryId()))
            .headers(standardHeaders(jwt))
            .exchange()
            .expectStatus()
            .isForbidden()
            .expectHeader()
            .value(X_YBS_SCA_CHALLENGE, not(emptyString()))
            .returnResult(Object.class)
            .getResponseHeaders()
            .getFirst(X_YBS_SCA_CHALLENGE);

    signingWebClientPublic
        .delete()
        .uri(
            getURI(
                BASE_PATH_PUBLIC,
                ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiary.getBeneficiaryId()))
        .headers(standardHeaders(jwt))
        .header(X_YBS_SCA_CHALLENGE, challenge)
        .header(
            "x-ybs-sca-challenge-response",
            SigningUtils.signWithPrivateKey(challenge, keyPair.getPrivate()))
        .header("x-ybs-sca-key", SigningUtils.encodePublicKey(keyPair.getPublic()))
        .exchange()
        .expectStatus()
        .isAccepted();
  }

  private <T extends Beneficiary> void sendDeleteRequestForWebWithoutSca(
      final String jwt, final T beneficiary) throws Exception {

    signingWebClientPublic
        .delete()
        .uri(
            getURI(
                BASE_PATH_PUBLIC,
                ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiary.getBeneficiaryId()))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isAccepted()
        .expectHeader()
        .value(X_YBS_SCA_CHALLENGE, is(emptyOrNullString()))
        .expectBody()
        .isEmpty();
  }

  private void stubForRequest() {
    stubProductServiceResponse("/it/productInfoManyBeneficiaries.json");
    mockAuditServiceResponse();
  }

  private Matcher<ItInstruction> deleted(final ItInstruction instruction) {
    return equalTo(instruction);
  }

  @SuppressWarnings(UNCHECKED_WARNING)
  private <T> Matcher<T> deleted(final Class<T> instructionType, final T instruction) {
    if (instructionType == BillPaymentInstruction.class) {
      return (Matcher<T>) deleted((BillPaymentInstruction) instruction);
    } else if (instructionType == ItInstruction.class) {
      return (Matcher<T>) deleted((ItInstruction) instruction);
    }

    throw new IllegalArgumentException("argument is not a valid instruction type");
  }

  private Matcher<BillPaymentInstruction> deleted(final BillPaymentInstruction instruction) {
    final LocalDateTime now = LocalDateTime.now(clock);
    return allOf(
        samePropertyValuesAs(instruction, "status", "endDate", "endedDate", "endedAt", "endedBy"),
        hasProperty("status", equalTo("CANC")),
        hasProperty("endedDate", withinTenSecondsOf(now)),
        hasProperty("endDate", withinTenSecondsOf(now)),
        hasProperty("endedAt", equalTo(TestData.CREATED_AT)),
        hasProperty("endedBy", equalTo(TestData.CREATED_BY)));
  }

  private void sendUpdateRequest(
      final String jwt, final KeyPair keyPair, final ExternalBeneficiary updatedBeneficiary)
      throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException,
          SignatureException, IOException {
    final String challenge =
        signingWebClientPublic
            .put()
            .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
            .headers(standardHeaders(jwt))
            .bodyValue(updatedBeneficiary)
            .exchange()
            .expectStatus()
            .isForbidden()
            .expectHeader()
            .value(X_YBS_SCA_CHALLENGE, not(emptyString()))
            .returnResult(Object.class)
            .getResponseHeaders()
            .getFirst(X_YBS_SCA_CHALLENGE);

    signingWebClientPublic
        .put()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(jwt))
        .header(X_YBS_SCA_CHALLENGE, challenge)
        .header(
            "x-ybs-sca-challenge-response",
            SigningUtils.signWithPrivateKey(challenge, keyPair.getPrivate()))
        .header("x-ybs-sca-key", SigningUtils.encodePublicKey(keyPair.getPublic()))
        .bodyValue(updatedBeneficiary)
        .exchange()
        .expectStatus()
        .isAccepted();
  }

  private List<Beneficiary> getBeneficiaries(final String jwt) {
    return signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBodyList(Beneficiary.class)
        .returnResult()
        .getResponseBody();
  }

  private static InternalBeneficiary createInternalBeneficiary() {
    return InternalBeneficiary.builder().accountNumber(TestData.INTERNAL_ACCOUNT_NUMBER).build();
  }

  @SuppressWarnings("PMD.UnusedPrivateMethod")
  private static Stream<Arguments> existingBeneficiaries() {
    return existingBeneficiariesFor(
        TestData.EXTERNAL_ACCOUNT_NUMBER, TestData.INTERNAL_ACCOUNT_NUMBER);
  }

  private static Stream<Arguments> existingBeneficiariesWithOtherAccountNumber() {
    return existingBeneficiariesFor(
        TestData.OTHER_EXTERNAL_ACCOUNT_NUMBER, TestData.OTHER_INTERNAL_ACCOUNT_NUMBER);
  }

  private static Stream<Arguments> existingBeneficiariesFor(
      final String externalAccountNumber, final String internalAccountNumber) {
    return Stream.of(
        Arguments.of(
            setupBillPaymentInstructionFunction(externalAccountNumber),
            BillPaymentInstruction.class,
            ExternalBeneficiary.class),
        Arguments.of(
            setupItInstructionFunction(internalAccountNumber),
            ItInstruction.class,
            InternalBeneficiary.class));
  }

  private static Stream<Arguments> existingBeneficiariesForFailedWorkLogs() {
    return Stream.of(
        Arguments.of(
            setupBillPaymentInstructionFunction(TestData.EXTERNAL_ACCOUNT_NUMBER),
            BillPaymentInstruction.class,
            ExternalBeneficiary.class,
            true),
        Arguments.of(
            setupBillPaymentInstructionFunction(TestData.EXTERNAL_ACCOUNT_NUMBER),
            BillPaymentInstruction.class,
            ExternalBeneficiary.class,
            false),
        Arguments.of(
            setupItInstructionFunction(TestData.INTERNAL_ACCOUNT_NUMBER),
            ItInstruction.class,
            InternalBeneficiary.class,
            true),
        Arguments.of(
            setupItInstructionFunction(TestData.INTERNAL_ACCOUNT_NUMBER),
            ItInstruction.class,
            InternalBeneficiary.class,
            false));
  }

  private static Function<CoreHelper, ItInstruction> setupItInstructionFunction(
      final String internalAccountNumber) {
    return (CoreHelper core) ->
        core.setupExistingInternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER, Long.parseLong(internalAccountNumber), false);
  }

  private static Function<CoreHelper, BillPaymentInstruction> setupBillPaymentInstructionFunction(
      final String externalAccountNumber) {
    return (CoreHelper core) ->
        core.setupExistingExternalBeneficiary(
            DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(externalAccountNumber),
            Long.parseLong(TestData.SORT_CODE),
            core.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE)),
            false);
  }

  private static Stream<Arguments> beneficiariesToCreate() {
    final Function<CoreHelper, BillPaymentInstruction> createBillPaymentInstruction =
        (CoreHelper core) -> {
          final FinancialInstitution institution =
              core.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE));
          final NonYbsBankAccount bankAccount =
              core.createNonYbsBankAccount(
                  Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER), institution);
          return core.createBillPaymentInstruction(DEBTOR_ACCOUNT_NUMBER, bankAccount, false);
        };

    final Function<CoreHelper, ItInstruction> createItInstruction =
        (CoreHelper core) ->
            core.createItInstruction(
                DEBTOR_ACCOUNT_NUMBER, Long.parseLong(TestData.INTERNAL_ACCOUNT_NUMBER), false);

    return Stream.of(
        Arguments.of(
            createBillPaymentInstruction,
            createExternalBeneficiary(),
            BillPaymentInstruction.class),
        Arguments.of(createItInstruction, createInternalBeneficiary(), ItInstruction.class));
  }

  @SuppressWarnings(UNCHECKED_WARNING)
  private <BeneficiaryT extends Beneficiary> BeneficiaryT createBeneficiary(
      final Class<BeneficiaryT> beneficiaryType) {
    if (beneficiaryType == ExternalBeneficiary.class) {
      return (BeneficiaryT) createExternalBeneficiary();
    }

    return (BeneficiaryT) createInternalBeneficiary();
  }
}
