package uk.co.ybs.digital.beneficiary;

import java.net.URI;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class})
@ActiveProfiles("test")
class SwaggerIT {
  @LocalServerPort private int port;

  @Autowired private WebTestClient nonSigningWebClient;

  @CsvSource({
    "/beneficiary/swagger-ui.html,302",
    "/beneficiary/swagger-ui/index.html,200",
    "/beneficiary/swagger-ui/swagger-ui-bundle.js,200",
    "/beneficiary/swagger-ui/swagger-ui-standalone-preset.js,200",
    "/beneficiary/v3/api-docs/swagger-config,200",
    "/beneficiary/v3/api-docs,200"
  })
  @ParameterizedTest
  void shouldGetExpectedResponseStatusForSwaggerEndpointsWithNoSignature(
      final String path, final int expectedStatus) {
    nonSigningWebClient
        .get()
        .uri(getInfoURI(path))
        .exchange()
        .expectStatus()
        .isEqualTo(expectedStatus);
  }

  private URI getInfoURI(final String path) {
    return URI.create("http://localhost:" + port + path);
  }
}
