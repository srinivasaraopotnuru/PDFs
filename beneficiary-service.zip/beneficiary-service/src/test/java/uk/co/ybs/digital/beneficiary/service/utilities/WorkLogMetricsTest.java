package uk.co.ybs.digital.beneficiary.service.utilities;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableMap;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;

@ExtendWith(MockitoExtension.class)
public class WorkLogMetricsTest {

  private static final Long DEFAULT_VALUE = 0L;

  @Mock private MeterRegistry meterRegistry;

  @Mock private AtomicLong pendingGauge;

  @Mock private AtomicLong failedGauge;

  @Mock private AtomicLong completedGauge;

  private WorkLogMetrics testSubject;

  @BeforeEach
  void setUp() {
    when(meterRegistry.gauge(
            eq("uk.co.ybs.digital.beneficiary.processor.pending"), any(AtomicLong.class)))
        .thenReturn(pendingGauge);

    when(meterRegistry.gauge(
            eq("uk.co.ybs.digital.beneficiary.processor.failed"), any(AtomicLong.class)))
        .thenReturn(failedGauge);

    when(meterRegistry.gauge(
            eq("uk.co.ybs.digital.beneficiary.processor.completed"), any(AtomicLong.class)))
        .thenReturn(completedGauge);

    testSubject = new WorkLogMetrics(meterRegistry);
  }

  @Test
  void shouldReturnDefaultValues() {
    assertThat(pendingGauge.get(), equalTo(DEFAULT_VALUE));
    assertThat(failedGauge.get(), equalTo(DEFAULT_VALUE));
    assertThat(completedGauge.get(), equalTo(DEFAULT_VALUE));
  }

  @ParameterizedTest
  @MethodSource("statusValues")
  void shouldUpdateValues(
      final Map<WorkLog.Status, Long> statuses,
      final long pending,
      final long failed,
      final long complete) {
    testSubject.setValues(statuses);

    assertThat(pendingGauge.get(), equalTo(pending));
    assertThat(failedGauge.get(), equalTo(failed));
    assertThat(completedGauge.get(), equalTo(complete));
  }

  private static Stream<Arguments> statusValues() {
    return Stream.of(
        Arguments.of(Collections.emptyMap(), DEFAULT_VALUE, DEFAULT_VALUE, DEFAULT_VALUE),
        Arguments.of(
            Collections.singletonMap(WorkLog.Status.PENDING, 2L), 2L, DEFAULT_VALUE, DEFAULT_VALUE),
        Arguments.of(
            Collections.singletonMap(WorkLog.Status.FAILED, 3L), DEFAULT_VALUE, 3L, DEFAULT_VALUE),
        Arguments.of(
            Collections.singletonMap(WorkLog.Status.COMPLETE, 1L),
            DEFAULT_VALUE,
            DEFAULT_VALUE,
            1L),
        Arguments.of(
            ImmutableMap.of(
                WorkLog.Status.PENDING, 2L, WorkLog.Status.FAILED, 3L, WorkLog.Status.COMPLETE, 1L),
            2L,
            3L,
            1L));
  }
}
