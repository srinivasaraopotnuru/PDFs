package uk.co.ybs.digital.beneficiary.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("beneficiaryProcessorTransactionManager")
class ItInstructionCoreRepositoryTest {
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-07-13T14:56:30");
  private static final String CREATED_AT = "0795";
  private static final String CREATED_BY = "SAPP";
  private static final long CREDITOR_ACCOUNT_NUMBER = 1001L;
  private static final long DEBTOR_ACCOUNT_NUMBER = 2001L;
  private static final String STATUS = "ACTIVE";

  @Autowired ItInstructionCoreRepository testSubject;

  @Autowired TestEntityManager coreTestEntityManager;

  @Test
  void shouldFindById() {
    final ItInstruction itInstruction = createItInstruction();
    Long sysId = coreTestEntityManager.persistAndFlush(itInstruction).getSysId();
    coreTestEntityManager.clear();

    final Optional<ItInstruction> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(itInstruction));
  }

  @ParameterizedTest
  @CsvSource({"2002,0", "2001,1"})
  void findExistingInternalBeneficiariesShouldFindBeneficiariesWithMatchingDebtorAccount(
      final Long accountNumberLong, final int expectedCount) {
    final ItInstruction itInstruction = createItInstruction();
    coreTestEntityManager.persistAndFlush(itInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject.findExistingInternalBeneficiaries(
            accountNumberLong, CREDITOR_ACCOUNT_NUMBER, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"1002,0", "1001,1"})
  void findExistingInternalBeneficiariesShouldFindBeneficiariesWithMatchingCreditorAccount(
      final Long accountNumberLong, final int expectedCount) {
    final ItInstruction itInstruction = createItInstruction();
    coreTestEntityManager.persistAndFlush(itInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject.findExistingInternalBeneficiaries(
            DEBTOR_ACCOUNT_NUMBER, accountNumberLong, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"ONEOFF,0", "CANC,0", "ACTIVE,1"})
  void findExistingInternalBeneficiariesShouldOnlyFindActiveRecords(
      final String status, final int expectedCount) {
    final ItInstruction itInstruction = createItInstruction().toBuilder().status(status).build();
    coreTestEntityManager.persistAndFlush(itInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject.findExistingInternalBeneficiaries(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_ACCOUNT_NUMBER, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"false,0", "true,1"})
  void findExistingInternalBeneficiariesShouldOnlyFindAvailableAtmRecords(
      final boolean availableAtm, final int expectedCount) {
    final ItInstruction itInstruction =
        createItInstruction().toBuilder().availableAtm(availableAtm).build();
    coreTestEntityManager.persistAndFlush(itInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject.findExistingInternalBeneficiaries(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_ACCOUNT_NUMBER, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"2020-07-13T14:56:29,0", "2020-07-13T14:56:30,0", "2020-07-13T14:56:31,1", ",1"})
  void findExistingInternalBeneficiariesShouldOnlyFindRecordsWhereInstructionIsNotEnded(
      final LocalDateTime instructionEndDate, final int expectedCount) {
    final ItInstruction itInstruction =
        createItInstruction().toBuilder().endDate(instructionEndDate).build();
    coreTestEntityManager.persistAndFlush(itInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject.findExistingInternalBeneficiaries(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_ACCOUNT_NUMBER, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"2002,0", "2001,1"})
  void findActiveInternalBeneficiariesShouldFindBeneficiariesWithMatchingDebtorAccount(
      final Long accountNumberLong, final int expectedCount) {
    final ItInstruction itInstruction = createItInstruction();
    coreTestEntityManager.persistAndFlush(itInstruction);
    coreTestEntityManager.clear();

    final int count = testSubject.findActiveInternalBeneficiaries(accountNumberLong, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"ONEOFF,0", "CANC,0", "ACTIVE,1"})
  void findActiveInternalBeneficiariesShouldOnlyFindActiveRecords(
      final String status, final int expectedCount) {
    final ItInstruction itInstruction = createItInstruction().toBuilder().status(status).build();
    coreTestEntityManager.persistAndFlush(itInstruction);
    coreTestEntityManager.clear();

    final int count = testSubject.findActiveInternalBeneficiaries(DEBTOR_ACCOUNT_NUMBER, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"2020-07-13T14:56:29,0", "2020-07-13T14:56:30,0", "2020-07-13T14:56:31,1", ",1"})
  void findActiveInternalBeneficiariesShouldOnlyFindRecordsWhereInstructionIsNotEnded(
      final LocalDateTime instructionEndDate, final int expectedCount) {
    final ItInstruction itInstruction =
        createItInstruction().toBuilder().endDate(instructionEndDate).build();
    coreTestEntityManager.persistAndFlush(itInstruction);
    coreTestEntityManager.clear();

    final int count = testSubject.findActiveInternalBeneficiaries(DEBTOR_ACCOUNT_NUMBER, NOW);
    assertThat(count, is(expectedCount));
  }

  private static ItInstruction createItInstruction() {
    return ItInstruction.builder()
        .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
        .code("ATM")
        .availableAtm(true)
        .creditorAccountNumber(CREDITOR_ACCOUNT_NUMBER)
        .startDate(NOW)
        .status(STATUS)
        .createdAt(CREATED_AT)
        .createdBy(CREATED_BY)
        .createdDate(NOW)
        .build();
  }
}
