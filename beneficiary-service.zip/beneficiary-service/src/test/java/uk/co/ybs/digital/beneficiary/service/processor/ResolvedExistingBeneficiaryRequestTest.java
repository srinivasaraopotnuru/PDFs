package uk.co.ybs.digital.beneficiary.service.processor;

import static org.mockito.Mockito.verify;

import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.beneficiary.web.dto.TestBeneficiary;

@ExtendWith(MockitoExtension.class)
class ResolvedExistingBeneficiaryRequestTest {

  private ResolvedExistingBeneficiaryRequest<TestBeneficiary, TestDatabaseEntity> testSubject;
  private TestDatabaseEntity databaseEntity;
  private ExistingBeneficiaryRequestArguments<TestBeneficiary> arguments;

  @Mock
  private ExistingBeneficiaryProcessor<TestBeneficiary, TestDatabaseEntity>
      existingBeneficiaryProcessor;

  @BeforeEach
  void setUp() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    arguments =
        new ExistingBeneficiaryRequestArguments<>(
            1234567890,
            requestMetadata,
            LocalDateTime.parse("2020-05-26T14:45:01"),
            new TestBeneficiary("abc123", 1L),
            123L);
    databaseEntity = new TestDatabaseEntity();
    testSubject =
        new ResolvedExistingBeneficiaryRequest<>(
            arguments, databaseEntity, existingBeneficiaryProcessor);
  }

  @Test
  void executeShouldCallProcessor() {
    testSubject.execute();
    verify(existingBeneficiaryProcessor).execute(arguments, databaseEntity);
  }

  @Test
  void auditSuccessShouldCallProcessor() {
    testSubject.auditSuccess();
    verify(existingBeneficiaryProcessor).auditSuccess(arguments, databaseEntity);
  }

  @ParameterizedTest
  @EnumSource(BeneficiaryValidationExceptionReason.class)
  void auditFailureShouldCallProcessor(final BeneficiaryValidationExceptionReason reason) {
    testSubject.auditFailure(reason);
    verify(existingBeneficiaryProcessor).auditFailure(arguments, databaseEntity, reason);
  }

  private static class TestDatabaseEntity {}
}
