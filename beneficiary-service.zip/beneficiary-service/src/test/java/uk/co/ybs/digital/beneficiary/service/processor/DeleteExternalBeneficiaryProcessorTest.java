package uk.co.ybs.digital.beneficiary.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DELETED;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.TECHNICAL;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.repository.core.BillPaymentInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.mapper.ExternalBeneficiaryDatabaseEntityMapper;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class DeleteExternalBeneficiaryProcessorTest {

  private static final long ACCOUNT_NUMBER = 1234567890L;
  private static final long PAYEE_ACCOUNT_NUMBER = 12345678L;
  private static final long BENEFICIARY_SYS_ID = 1L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  @InjectMocks private DeleteExternalBeneficiaryProcessor testSubject;

  @Mock private BillPaymentInstructionCoreRepository billPaymentInstructionCoreRepository;

  @Mock private ExternalBeneficiaryDatabaseEntityMapper externalBeneficiaryDatabaseEntityMapper;

  @Mock private BeneficiaryInformationFactory beneficiaryInformationFactory;

  @Mock private BeneficiaryAuditor beneficiaryAuditor;

  @Test
  void resolveShouldReturnDatabaseEntity() {
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(TestHelper.createRequestMetadata());
    final BillPaymentInstruction billPaymentInstruction =
        BillPaymentInstruction.builder().sysId(2L).build();

    when(billPaymentInstructionCoreRepository.findById(BENEFICIARY_SYS_ID))
        .thenReturn(Optional.of(billPaymentInstruction));

    final BillPaymentInstruction instruction = testSubject.resolve(arguments);

    assertThat(instruction, is(billPaymentInstruction));
    verifyNoMoreInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void resolveShouldThrowIllegalArgumentExceptionWhenRepositoryReturnsEmpty() {
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(TestHelper.createRequestMetadata());

    when(billPaymentInstructionCoreRepository.findById(any())).thenReturn(Optional.empty());

    final IllegalArgumentException exception =
        assertThrows(IllegalArgumentException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("BillPaymentInstruction 1 not found"));
    verifyNoMoreInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void executeShouldEndBeneficiary() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata);

    final NonYbsBankAccount nonYbsBankAccount = buildNonYbsBankAccount();
    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(nonYbsBankAccount);

    final BillPaymentInstruction expectedBillPaymentInstruction =
        billPaymentInstruction
            .toBuilder()
            .status("CANC")
            .atmOrderNumber(null)
            .endDate(PROCESS_TIME)
            .endedAt("0795")
            .endedBy("SAPP")
            .endedDate(PROCESS_TIME)
            .build();

    testSubject.execute(arguments, billPaymentInstruction);

    verify(billPaymentInstructionCoreRepository)
        .saveAndFlush(argThat(samePropertyValuesAs(expectedBillPaymentInstruction)));
    verify(billPaymentInstructionCoreRepository)
        .updateExternalBeneficiaryAuthenticRecord(ACCOUNT_NUMBER);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfAlreadyEnded() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata);

    final NonYbsBankAccount nonYbsBankAccount = buildNonYbsBankAccount();
    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(nonYbsBankAccount).toBuilder().endDate(PROCESS_TIME).build();

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () -> testSubject.execute(arguments, billPaymentInstruction));

    assertThat(exception.getMessage(), is("Beneficiary already ended"));
    assertThat(exception.getReason(), is(DELETED));

    verifyNoInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void auditSuccessShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata);

    final ExternalBeneficiary databaseBeneficiary = buildDatabaseBeneficiary();
    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(buildNonYbsBankAccount());

    final ExternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createExternalBeneficiaryInformation(
            String.valueOf(ACCOUNT_NUMBER), String.valueOf(PAYEE_ACCOUNT_NUMBER));

    when(externalBeneficiaryDatabaseEntityMapper.map(billPaymentInstruction))
        .thenReturn(databaseBeneficiary);
    when(beneficiaryInformationFactory.buildExternal(ACCOUNT_NUMBER, databaseBeneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditSuccess(arguments, billPaymentInstruction);

    verify(beneficiaryAuditor).auditBeneficiaryDeleteSuccess(expectedAuditBody, requestMetadata);
    verifyNoInteractions(billPaymentInstructionCoreRepository);
  }

  @Test
  void auditFailureShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata);

    final ExternalBeneficiary databaseBeneficiary = buildDatabaseBeneficiary();
    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(buildNonYbsBankAccount());

    final ExternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createExternalBeneficiaryInformation(
            String.valueOf(ACCOUNT_NUMBER), String.valueOf(PAYEE_ACCOUNT_NUMBER));

    when(externalBeneficiaryDatabaseEntityMapper.map(billPaymentInstruction))
        .thenReturn(databaseBeneficiary);
    when(beneficiaryInformationFactory.buildExternal(ACCOUNT_NUMBER, databaseBeneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditFailure(arguments, billPaymentInstruction, TECHNICAL);

    verify(beneficiaryAuditor)
        .auditBeneficiaryDeleteFailure(expectedAuditBody, "Technical Failure", requestMetadata);
    verifyNoInteractions(billPaymentInstructionCoreRepository);
  }

  private ExistingBeneficiaryRequestArguments<ExternalBeneficiary> buildArguments(
      final RequestMetadata requestMetadata) {
    return new ExistingBeneficiaryRequestArguments<>(
        ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, buildBeneficiary(), BENEFICIARY_SYS_ID);
  }

  private ExternalBeneficiary buildBeneficiary() {
    return ExternalBeneficiary.builder()
        .beneficiaryId("abc123")
        .accountSortCode("112233")
        .accountNumber(String.valueOf(PAYEE_ACCOUNT_NUMBER))
        .name("the-payee-name")
        .reference("Reference")
        .memorableName("Memorable Name")
        .build();
  }

  private ExternalBeneficiary buildDatabaseBeneficiary() {
    return ExternalBeneficiary.builder()
        .beneficiaryId("abc123")
        .accountSortCode("112233")
        .accountNumber(String.valueOf(PAYEE_ACCOUNT_NUMBER))
        .name("the-payee-name")
        .reference("Current Reference")
        .memorableName("Current Memorable Name")
        .build();
  }

  private BillPaymentInstruction buildBillPaymentInstruction(
      final NonYbsBankAccount nonYbsBankAccount) {
    return BillPaymentInstruction.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .status("ACTIVE")
        .atmOrderNumber(1)
        .nonYbsBankAccount(nonYbsBankAccount)
        .reference("the-reference")
        .memorableName("the-memorable-name")
        .build();
  }

  private NonYbsBankAccount buildNonYbsBankAccount() {
    return NonYbsBankAccount.builder()
        .sortCode(112233L)
        .accountNumber(PAYEE_ACCOUNT_NUMBER)
        .name("the-payee-name")
        .build();
  }
}
