package uk.co.ybs.digital.beneficiary.utils;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.IOException;
import java.io.StringWriter;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.Signature;
import java.security.SignatureException;
import java.util.Base64;
import lombok.experimental.UtilityClass;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemWriter;

@UtilityClass
public class SigningUtils {

  public static KeyPair generateKeyPair() throws NoSuchProviderException, NoSuchAlgorithmException {
    Security.addProvider(new BouncyCastleProvider());
    final KeyPairGenerator generator = KeyPairGenerator.getInstance("ECDSA", "BC");
    return generator.generateKeyPair();
  }

  public static String encodePublicKey(final PublicKey publicKey) throws IOException {
    final String publicKeyPem = convertPublicKeyToPem(publicKey);
    return new String(Base64.getEncoder().encode(publicKeyPem.getBytes(UTF_8)), UTF_8);
  }

  public static String signWithPrivateKey(final String toSign, final PrivateKey privateKey)
      throws NoSuchProviderException, NoSuchAlgorithmException, InvalidKeyException,
          SignatureException {
    final Signature signature = Signature.getInstance("SHA256WithECDSA", "BC");
    signature.initSign(privateKey);
    signature.update(toSign.getBytes(UTF_8));
    return new String(Base64.getEncoder().encode(signature.sign()), UTF_8);
  }

  private static String convertPublicKeyToPem(final PublicKey publicKey) throws IOException {
    final StringWriter sw = new StringWriter();
    try (PemWriter pemWriter = new PemWriter(sw)) {
      pemWriter.writeObject(new PemObject("PUBLIC KEY", publicKey.getEncoded()));
    }
    return sw.toString();
  }
}
