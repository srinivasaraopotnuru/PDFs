package uk.co.ybs.digital.beneficiary.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;

import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentConversionNotSupportedException;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;

// This class is created to test the exceptions we can't trigger with WebMVC test
class GlobalMvcResponseEntityExceptionHandlerTest {

  GlobalMvcResponseEntityExceptionHandler exceptionHandler =
      new GlobalMvcResponseEntityExceptionHandler();

  @Test
  void methodArgumentConversionNotSupportedExceptionConvertedToStandardErrorStructure() {
    final MethodArgumentConversionNotSupportedException mockException =
        Mockito.mock(MethodArgumentConversionNotSupportedException.class);
    final HttpHeaders mockHeaders = HttpHeaders.EMPTY;
    final HttpStatus badRequest = HttpStatus.BAD_REQUEST;
    final WebRequest mockRequest = Mockito.mock(WebRequest.class);

    when(mockException.getName()).thenReturn("MockName");
    when(mockException.getValue()).thenReturn("MockValue");
    final UUID requestId = UUID.randomUUID();
    when(mockRequest.getAttribute(
            RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME, WebRequest.SCOPE_REQUEST))
        .thenReturn(requestId);

    final ResponseEntity<Object> response =
        exceptionHandler.handleTypeMismatch(mockException, mockHeaders, badRequest, mockRequest);
    final ErrorResponse errorResponse = (ErrorResponse) response.getBody();

    ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid value")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("Invalid MockName: 'MockValue'")
                    .build())
            .build();

    assertThat(errorResponse, is(expectedErrorResponse));
  }

  @Test
  void genericConversionNotSupportedExceptionConvertedToStandardErrorStructure() {
    final ConversionNotSupportedException mockException =
        Mockito.mock(ConversionNotSupportedException.class);
    final HttpHeaders mockHeaders = HttpHeaders.EMPTY;
    final HttpStatus badRequest = HttpStatus.BAD_REQUEST;
    final WebRequest mockRequest = Mockito.mock(WebRequest.class);

    when(mockException.getValue()).thenReturn("MockValue");
    final UUID requestId = UUID.randomUUID();
    when(mockRequest.getAttribute(
            RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME, WebRequest.SCOPE_REQUEST))
        .thenReturn(requestId);

    final ResponseEntity<Object> response =
        exceptionHandler.handleTypeMismatch(mockException, mockHeaders, badRequest, mockRequest);
    final ErrorResponse errorResponse = (ErrorResponse) response.getBody();

    ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid value")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("Invalid value: 'MockValue'")
                    .build())
            .build();

    assertThat(errorResponse, is(expectedErrorResponse));
  }
}
