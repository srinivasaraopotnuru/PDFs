package uk.co.ybs.digital.beneficiary.e2e;

import java.time.LocalDateTime;
import javax.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;

@RequiredArgsConstructor
public class CoreHelper {
  private final TransactionTemplate transactionTemplate;
  private final TestEntityManager testEntityManager;

  public FinancialInstitution createFinancialInstitution(final long sortCode) {
    return FinancialInstitution.builder()
        .sysId(1L)
        .bankName("Bank 1")
        .sortCode(sortCode)
        .subBranch(false)
        .build();
  }

  public NonYbsBankAccount createNonYbsBankAccount(
      final long creditorAccountNumber, final FinancialInstitution institution) {
    return NonYbsBankAccount.builder()
        .accountNumber(creditorAccountNumber)
        .bankName(TestData.BANK_NAME)
        .createdAt(TestData.CREATED_AT)
        .createdBy(TestData.CREATED_BY)
        .createdDate(LocalDateTime.parse("1900-01-01T00:00:00"))
        .financialInstitution(institution)
        .name(TestData.NAME)
        .sortCode(Long.parseLong(TestData.SORT_CODE))
        .startDate(LocalDateTime.parse("1900-01-01T00:00:00"))
        .build();
  }

  public BillPaymentInstruction createBillPaymentInstruction(
      final long debtorAccountNumber,
      final NonYbsBankAccount nonYbsBankAccount,
      final boolean ended) {
    final BillPaymentInstruction.BillPaymentInstructionBuilder builder =
        BillPaymentInstruction.builder()
            .accountNumber(debtorAccountNumber)
            .availableAtm(true)
            .createdAt(TestData.CREATED_AT)
            .createdBy(TestData.CREATED_BY)
            .createdDate(TestData.EXISTING_BENEFICIARY_START_DATE)
            .fpChangeReason("OOBAD")
            .fpTrustStatus(true)
            .memorableName(TestData.MEMORABLE_NAME)
            .nonYbsBankAccount(nonYbsBankAccount)
            .reference(TestData.REFERENCE)
            .startDate(TestData.EXISTING_BENEFICIARY_START_DATE)
            .status("ACTIVE");

    if (ended) {
      builder.endDate(TestData.EXISTING_BENEFICIARY_START_DATE);
    }

    return builder.build();
  }

  public ItInstruction createItInstruction(
      final long debtorAccountNumber, final long creditorAccountNumber, final boolean ended) {
    final ItInstruction.ItInstructionBuilder builder =
        ItInstruction.builder()
            .debtorAccountNumber(debtorAccountNumber)
            .code("ATM")
            .availableAtm(true)
            .creditorAccountNumber(creditorAccountNumber)
            .startDate(TestData.EXISTING_BENEFICIARY_START_DATE)
            .status("ACTIVE")
            .createdAt(TestData.CREATED_AT)
            .createdBy(TestData.CREATED_BY)
            .createdDate(TestData.EXISTING_BENEFICIARY_START_DATE);

    if (ended) {
      builder.endDate(TestData.EXISTING_BENEFICIARY_START_DATE);
    }

    return builder.build();
  }

  public BillPaymentInstruction setupExistingExternalBeneficiary(
      final long debtorAccountNumber,
      final long creditorAccountNumber,
      final long sortCode,
      final FinancialInstitution institution,
      final boolean ended) {
    return transactionTemplate.execute(
        status ->
            testEntityManager.persist(
                createBillPaymentInstruction(
                    debtorAccountNumber,
                    testEntityManager.persistAndFlush(
                        createNonYbsBankAccount(creditorAccountNumber, institution)),
                    ended)));
  }

  public FinancialInstitution setupFinancialInstitution(final long sortCode) {
    return transactionTemplate.execute(
        status -> testEntityManager.persistAndFlush(createFinancialInstitution(sortCode)));
  }

  public ItInstruction setupExistingInternalBeneficiary(
      final long debtorAccountNumber, final long creditorAccountNumber, final boolean ended) {
    return transactionTemplate.execute(
        status ->
            testEntityManager.persistAndFlush(
                createItInstruction(debtorAccountNumber, creditorAccountNumber, ended)));
  }

  public void clearDb() {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager entityManager = testEntityManager.getEntityManager();
          entityManager.createQuery("delete from BillPaymentInstruction").executeUpdate();
          entityManager.createQuery("delete from NonYbsBankAccount").executeUpdate();
          entityManager.createQuery("delete from FinancialInstitution").executeUpdate();
          entityManager.createQuery("delete from ItInstruction").executeUpdate();
        });
  }
}
