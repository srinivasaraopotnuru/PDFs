package uk.co.ybs.digital.beneficiary.service.product.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
public class ProductInfoJsonTest {

  public static final String ONE_POINT_ZERO = "1.00";
  @Autowired private JacksonTester<ProductInfo> json;

  @Value("classpath:api/productService/response/getProductInfoSuccess.json")
  private Resource expectedJson;

  private final ProductInfo productInfo = createFullProductInfo();

  @Test
  void serializes() throws IOException {
    assertThat(json.write(productInfo)).isEqualToJson(expectedJson, JSONCompareMode.STRICT);
  }

  @Test
  void deserialize() throws IOException {
    assertThat(json.read(expectedJson)).isEqualTo(productInfo);
  }

  private static ProductInfo createFullProductInfo() {
    return ProductInfo.builder()
        .productIdentifier("EGG302A")
        .customerDescription("Customer Description")
        .productType("Product Type")
        .maximumMonthlyPayment(new BigDecimal(ONE_POINT_ZERO))
        .balance(
            ProductInfo.Balance.builder()
                .min(new BigDecimal("0.00"))
                .max(new BigDecimal(ONE_POINT_ZERO))
                .build())
        .deposits(
            ProductInfo.Deposits.builder()
                .permittedInternal(true)
                .limits(
                    ProductInfo.Deposits.Limits.builder()
                        .amount(
                            ProductInfo.AmountPeriodLimits.builder()
                                .anniversaryYear(new BigDecimal(ONE_POINT_ZERO))
                                .month(new BigDecimal(ONE_POINT_ZERO))
                                .productTerm(new BigDecimal(ONE_POINT_ZERO))
                                .taxYear(new BigDecimal(ONE_POINT_ZERO))
                                .year(new BigDecimal(ONE_POINT_ZERO))
                                .build())
                        .build())
                .build())
        .withdrawals(
            ProductInfo.Withdrawals.builder()
                .interestPenalty(
                    ProductInfo.Withdrawals.InterestPenalty.builder()
                        .code(2)
                        .days(30)
                        .balanceUpperBound(new BigDecimal("999999999.99"))
                        .build())
                .permittedOverWeb(true)
                .limits(
                    ProductInfo.Withdrawals.Limits.builder()
                        .number(
                            ProductInfo.NumberPeriodLimits.builder()
                                .anniversaryYear(1)
                                .month(1)
                                .productTerm(1)
                                .taxYear(1)
                                .year(1)
                                .build())
                        .build())
                .build())
        .isa(ProductInfo.Isa.builder().flexible(false).isaYear(1).build())
        .beneficiaries(ProductInfo.Beneficiaries.builder().external(1).internal(1).build())
        .build();
  }
}
