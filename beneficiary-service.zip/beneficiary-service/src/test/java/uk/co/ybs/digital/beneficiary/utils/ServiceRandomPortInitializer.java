package uk.co.ybs.digital.beneficiary.utils;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

/*
 * For testing we want to create a mock services on a random port and connect to it.
 * Find a port during startup and store it to the corresponding system property, meaning that the application can
 * continue to initialise in the normal way from the properties.
 */
public class ServiceRandomPortInitializer
    implements ApplicationContextInitializer<ConfigurableApplicationContext> {

  @Override
  public void initialize(final ConfigurableApplicationContext applicationContext) {
    initializePort(applicationContext, "uk.co.ybs.digital.product-test-port");
    initializePort(applicationContext, "uk.co.ybs.digital.audit-test-port");
    initializePort(applicationContext, "uk.co.ybs.digital.account-test-port");
  }

  private void initializePort(
      final ConfigurableApplicationContext applicationContext, final String property) {
    TestPropertySourceUtils.addInlinedPropertiesToEnvironment(
        applicationContext, String.format("%s=%s", property, SocketUtils.findAvailableTcpPort()));
  }
}
