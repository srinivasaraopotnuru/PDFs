package uk.co.ybs.digital.beneficiary.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThrows;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation.CREATE;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation.DELETE;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation.UPDATE;

import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class BeneficiaryRequestFactoryTest {

  private static final long ACCOUNT_NUMBER = 9876543210L;
  private static final String INTERNAL_ACCOUNT_NUMBER = "1234567890";
  private static final String EXTERNAL_ACCOUNT_NUMBER = "12345678";
  private static final long SYS_ID = 1L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final int BENEFICIARIES_LIMIT = 4;

  @InjectMocks private BeneficiaryRequestFactory testSubject;
  @Mock private CreateInternalBeneficiaryProcessor createInternalBeneficiaryProcessor;
  @Mock private CreateExternalBeneficiaryProcessor createExternalBeneficiaryProcessor;
  @Mock private UpdateExternalBeneficiaryProcessor updateExternalBeneficiaryProcessor;
  @Mock private DeleteExternalBeneficiaryProcessor deleteExternalBeneficiaryProcessor;
  @Mock private DeleteInternalBeneficiaryProcessor deleteInternalBeneficiaryProcessor;

  @ParameterizedTest
  @NullSource
  @ValueSource(ints = {BENEFICIARIES_LIMIT})
  void buildShouldReturnCreateInternalBeneficiaryRequest(final Integer beneficiariesLimit) {
    final InternalBeneficiary beneficiary =
        TestHelper.createInternalBeneficiary(INTERNAL_ACCOUNT_NUMBER);
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog =
        buildWorkLog(CREATE, requestMetadata, null, beneficiariesLimit, beneficiary);

    final BeneficiaryRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new CreateBeneficiaryRequest<>(
                new BeneficiaryRequestArguments<>(
                    ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, beneficiariesLimit),
                createInternalBeneficiaryProcessor)));
  }

  @ParameterizedTest
  @NullSource
  @ValueSource(ints = {BENEFICIARIES_LIMIT})
  void buildShouldReturnCreateExternalBeneficiaryRequest(final Integer beneficiariesLimit) {
    final ExternalBeneficiary beneficiary =
        TestHelper.createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER);
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog =
        buildWorkLog(CREATE, requestMetadata, null, beneficiariesLimit, beneficiary);

    final BeneficiaryRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new CreateBeneficiaryRequest<>(
                new BeneficiaryRequestArguments<>(
                    ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, beneficiariesLimit),
                createExternalBeneficiaryProcessor)));
  }

  @Test
  void buildShouldReturnUpdateExternalBeneficiaryRequest() {
    final ExternalBeneficiary beneficiary =
        TestHelper.createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER);
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = buildWorkLog(UPDATE, requestMetadata, SYS_ID, null, beneficiary);

    final BeneficiaryRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new ExistingBeneficiaryRequest<>(
                new ExistingBeneficiaryRequestArguments<>(
                    ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, SYS_ID),
                updateExternalBeneficiaryProcessor)));
  }

  @Test
  void buildShouldReturnDeleteExternalBeneficiaryRequest() {
    final ExternalBeneficiary beneficiary =
        TestHelper.createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER);
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = buildWorkLog(DELETE, requestMetadata, SYS_ID, null, beneficiary);

    final BeneficiaryRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new ExistingBeneficiaryRequest<>(
                new ExistingBeneficiaryRequestArguments<>(
                    ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, SYS_ID),
                deleteExternalBeneficiaryProcessor)));
  }

  @Test
  void buildShouldReturnDeleteInternalBeneficiaryRequest() {
    final InternalBeneficiary beneficiary =
        TestHelper.createInternalBeneficiary(INTERNAL_ACCOUNT_NUMBER);
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = buildWorkLog(DELETE, requestMetadata, SYS_ID, null, beneficiary);

    final BeneficiaryRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new ExistingBeneficiaryRequest<>(
                new ExistingBeneficiaryRequestArguments<>(
                    ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, SYS_ID),
                deleteInternalBeneficiaryProcessor)));
  }

  @Test
  void buildShouldReturnNotImplementedBeneficiaryRequestForUpdateInternalBeneficiary() {
    final InternalBeneficiary beneficiary =
        TestHelper.createInternalBeneficiary(INTERNAL_ACCOUNT_NUMBER);
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = buildWorkLog(UPDATE, requestMetadata, SYS_ID, null, beneficiary);

    final BeneficiaryRequest request = testSubject.build(workLog, PROCESS_TIME);

    final UnsupportedOperationException exception =
        assertThrows(UnsupportedOperationException.class, request::resolve);
    assertThat(exception.getMessage(), is("Not implemented UPDATE InternalBeneficiary"));
  }

  private WorkLog buildWorkLog(
      final Operation operation,
      final RequestMetadata requestMetadata,
      final Long currentBeneficiarySysId,
      final Integer beneficiariesLimit,
      final Beneficiary beneficiary) {
    return WorkLog.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .operation(operation)
        .message(
            uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest.builder()
                .payload(
                    uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest
                        .Payload.builder()
                        .sysId(currentBeneficiarySysId)
                        .beneficiariesLimit(beneficiariesLimit)
                        .beneficiary(beneficiary)
                        .build())
                .metadata(requestMetadata)
                .build())
        .build();
  }
}
