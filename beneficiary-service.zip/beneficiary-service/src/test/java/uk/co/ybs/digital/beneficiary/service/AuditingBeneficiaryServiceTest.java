package uk.co.ybs.digital.beneficiary.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.FailureRequest;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;

@ExtendWith(MockitoExtension.class)
class AuditingBeneficiaryServiceTest {

  private static final String ACCOUNT_NUMBER = "1234567891";
  public static final String CHALLENGE = "the-challenge";

  @InjectMocks private AuditingBeneficiaryService testSubject;

  @Mock private BeneficiaryService beneficiaryService;

  @Mock private BeneficiaryAuditor beneficiaryAuditor;

  @Mock private ScaChallengeService challengeService;

  @Test
  void getBeneficiariesShouldAuditBeneficiariesView() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final List<Beneficiary> expectedBeneficiaries = new ArrayList<>();
    when(beneficiaryService.getBeneficiaries(ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(expectedBeneficiaries);

    final List<Beneficiary> actual = testSubject.getBeneficiaries(ACCOUNT_NUMBER, requestMetadata);
    assertThat(actual, sameInstance(expectedBeneficiaries));

    verify(beneficiaryAuditor).auditBeneficiariesView(same(ACCOUNT_NUMBER), same(requestMetadata));
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @Test
  void reportFailureShouldCheckChallengeAndReportChallengeFailure() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final FailureRequest request = FailureRequest.builder().challenge(CHALLENGE).build();

    testSubject.reportFailure(request, requestMetadata);

    verify(challengeService).decodeChallenge(CHALLENGE, Object.class);
    verify(beneficiaryAuditor)
        .auditBeneficiaryChallengeFailure(
            requestMetadata, "Client-side authentication error reported");
  }

  @Test
  void
      reportFailureShouldThrowBadFailureRequestChallengeExceptionAndNotAuditIfChallengeIsInvalid() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final FailureRequest request = FailureRequest.builder().challenge(CHALLENGE).build();

    doThrow(InvalidScaException.class)
        .when(challengeService)
        .decodeChallenge(CHALLENGE, Object.class);

    assertThrows(
        BadFailureRequestChallengeException.class,
        () -> testSubject.reportFailure(request, requestMetadata));

    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  private RequestMetadata buildRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 80);
  }
}
