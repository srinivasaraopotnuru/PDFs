package uk.co.ybs.digital.beneficiary.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
public class BeneficiaryLimitResponseJsonTest {
  @Autowired private JacksonTester<BeneficiaryLimitResponse> json;

  @Value("classpath:api/accountBeneficiaries/beneficiaryLimitResponse.json")
  private Resource responseFile;

  @Test
  void serializes() throws IOException {
    final BeneficiaryLimitResponse response = buildBeneficiaryLimitResponse();
    assertThat(json.write(response)).isEqualToJson(responseFile, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    final BeneficiaryLimitResponse response = buildBeneficiaryLimitResponse();
    assertThat(json.read(responseFile)).isEqualTo(response);
  }

  private static BeneficiaryLimitResponse buildBeneficiaryLimitResponse() {
    return BeneficiaryLimitResponse.builder()
        .external(BeneficiaryLimit.builder().count(3).maxPermitted(4).limitReached(false).build())
        .internal(BeneficiaryLimit.builder().count(1).maxPermitted(5).limitReached(false).build())
        .build();
  }
}
