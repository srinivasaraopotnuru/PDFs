package uk.co.ybs.digital.beneficiary.service.audit.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class AuditBeneficiaryUpdateFailureRequestJsonTest {

  @Autowired private JacksonTester<AuditBeneficiaryUpdateFailureRequest> tester;

  @Value("classpath:api/auditService/request/auditBeneficiary/Update/externalFailureAllFields.json")
  private Resource requestAllFields;

  @Value(
      "classpath:api/auditService/request/auditBeneficiary/Update/externalFailureMandatoryFields.json")
  private Resource requestMandatoryFields;

  @Test
  void shouldSerializeAllFields() throws IOException {
    assertThat(tester.write(buildAllFields()))
        .isEqualToJson(requestAllFields, JSONCompareMode.STRICT);
  }

  @Test
  void shouldDeserializeAllFields() throws IOException {
    assertThat(tester.read(requestAllFields)).isEqualTo(buildAllFields());
  }

  @Test
  void shouldSerializeMandatoryFields() throws IOException {
    assertThat(tester.write(buildMandatoryFields()))
        .isEqualToJson(requestMandatoryFields, JSONCompareMode.STRICT);
  }

  @Test
  void shouldDeserializeMandatoryFields() throws IOException {
    assertThat(tester.read(requestMandatoryFields)).isEqualTo(buildMandatoryFields());
  }

  private AuditBeneficiaryUpdateFailureRequest buildAllFields() {
    return AuditBeneficiaryUpdateFailureRequest.builder()
        .ipAddress("12.66.53.145")
        .message("Duplicate Beneficiary")
        .beneficiaryInformation(
            ExternalBeneficiaryInformation.builder()
                .accountNumber("2372146519")
                .payeeAccountNumber("12345678")
                .payeeSortCode("112233")
                .payeeName("Mr Test")
                .reference("Ref")
                .memorableName("Memorable")
                .build())
        .updateBeneficiaryInformation(
            ExternalUpdateBeneficiaryInformation.builder()
                .reference("New Ref")
                .memorableName("New Memorable")
                .build())
        .build();
  }

  private AuditBeneficiaryUpdateFailureRequest buildMandatoryFields() {
    final AuditBeneficiaryUpdateFailureRequest allFields = buildAllFields();
    return allFields
        .toBuilder()
        .beneficiaryInformation(
            allFields
                .getBeneficiaryInformation()
                .toBuilder()
                .reference(null)
                .memorableName(null)
                .build())
        .updateBeneficiaryInformation(ExternalUpdateBeneficiaryInformation.builder().build())
        .build();
  }
}
