package uk.co.ybs.digital.beneficiary.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.beneficiary.web.dto.TestBeneficiary;

@ExtendWith(MockitoExtension.class)
class ExistingBeneficiaryRequestTest {

  private ExistingBeneficiaryRequest<TestBeneficiary, TestDatabaseEntity> testSubject;
  private ExistingBeneficiaryRequestArguments<TestBeneficiary> arguments;

  @Mock
  private ExistingBeneficiaryProcessor<TestBeneficiary, TestDatabaseEntity>
      existingBeneficiaryProcessor;

  @BeforeEach
  void setUp() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final TestBeneficiary beneficiary = new TestBeneficiary("abc123", 1L);
    arguments =
        new ExistingBeneficiaryRequestArguments<>(
            1234567890,
            requestMetadata,
            LocalDateTime.parse("2020-05-26T14:45:01"),
            beneficiary,
            123L);
    testSubject = new ExistingBeneficiaryRequest<>(arguments, existingBeneficiaryProcessor);
  }

  @Test
  void resolveShouldReturnResolvedRequest() {
    final TestDatabaseEntity databaseEntity = new TestDatabaseEntity();
    when(existingBeneficiaryProcessor.resolve(arguments)).thenReturn(databaseEntity);

    final ResolvedBeneficiaryRequest resolved = testSubject.resolve();

    assertThat(
        resolved,
        is(
            new ResolvedExistingBeneficiaryRequest<>(
                arguments, databaseEntity, existingBeneficiaryProcessor)));
  }

  private static class TestDatabaseEntity {}
}
