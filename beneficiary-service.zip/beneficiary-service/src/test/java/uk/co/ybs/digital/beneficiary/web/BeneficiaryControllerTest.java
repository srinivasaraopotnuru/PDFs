package uk.co.ybs.digital.beneficiary.web;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.lang3.ArrayUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import uk.co.ybs.digital.beneficiary.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.exception.AccountServiceException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.exception.InternalBeneficiaryUpdateNotSupportedException;
import uk.co.ybs.digital.beneficiary.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.beneficiary.exception.ScaRequiredException;
import uk.co.ybs.digital.beneficiary.exception.UnsupportedBeneficiaryFieldUpdateException;
import uk.co.ybs.digital.beneficiary.service.AuditingBeneficiaryService;
import uk.co.ybs.digital.beneficiary.service.BadFailureRequestChallengeException;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryService;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryLimitResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.FailureRequest;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.sca.exception.InvalidPemKeyException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaCredentials;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(controllers = BeneficiaryController.class)
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter
  RequestVerificationSecurityAutoConfiguration.class, // Signature and JWT validation
  FilterErrorResponseFactory.class,
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class // Metrics
})
@ActiveProfiles({"test", "text-logging"})
class BeneficiaryControllerTest {

  public static final String ACCOUNT_NUMBER1 = "accountNumber";
  private static final String HOST_HEADER_VALUE = "beneficiaryservice.ybs.co.uk:443";
  private static final String BENEFICIARIES_ENDPOINT = "/accounts/%s/beneficiaries";
  private static final String BENEFICIARIES_BENEFICIARY_ENDPOINT = "/accounts/%s/beneficiaries/%s";
  private static final String CHALLENGE_FAILURE_ENDPOINT = "/failure";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String VALID_SCOPE = "BENEFICIARY ACCOUNT_READ";
  private static final String VALID_SCOPE_BENEFICIARY_LIMITS = "BENEFICIARY ACCOUNT_READ";
  private static final String OTHER_SCOPE = "ACCOUNT_READ";

  private static final String ACCOUNT_NUMBER = "1234567890";

  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final String SESSION_ID_ATTRIBUTE_NAME =
      "uk.co.ybs.digital.logging.session.SessionIdFilter.sessionId";
  private static final String BENEFICIARIY_LIMIT_ENDPOINT = "/accounts/%s/beneficiary-limits";
  public static final String INVALID_FIELD = "Field.Invalid";
  public static final String UPDATE_BENEFICIARY = "UPDATE_BENEFICIARY";
  public static final String DELETE_BENEFICIARY = "DELETE_BENEFICIARY";
  public static final String X_YBS_SCA_CHALLENGE = "x-ybs-sca-challenge";
  public static final String X_YBS_SCA_KEY = "x-ybs-sca-key";

  @Autowired private MockMvc mvc;

  @Autowired private ObjectMapper objectMapper;

  @MockBean private RequestSigningVerificationService requestSigningVerificationService;

  @MockBean private AuditingBeneficiaryService auditingBeneficiaryService;

  @MockBean private BeneficiaryService beneficiaryService;

  @MockBean private ScaCredentialsExtractor scaCredentialsExtractor;

  @BeforeEach
  void beforeEach() {
    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
  }

  @Test
  void getBeneficiariesShouldGetBeneficiariesList() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata expectedMetadata = buildRequestMetadata(requestId);

    final Beneficiary beneficiary = buildExternalBeneficiaryRequest();
    final List<Beneficiary> expectedResponse = Collections.singletonList(beneficiary);

    when(auditingBeneficiaryService.getBeneficiaries(ACCOUNT_NUMBER, expectedMetadata))
        .thenReturn(expectedResponse);

    mvc.perform(
            get(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));

    verifyNoInteractions(beneficiaryService);
  }

  @Test
  void updateBeneficiaryShouldInvokeBeneficiaryService() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata expectedMetadata = buildRequestMetadata(requestId);
    final Beneficiary beneficiary = buildExternalBeneficiaryRequest();
    final ScaCredentials scaCredentials =
        new ScaCredentials("challenge", "challenge-response", "sca-key");

    final HttpHeaders headers = standardHeaders(requestId);
    headers.setContentType(MediaType.APPLICATION_JSON);

    when(beneficiaryService.updateBeneficiary(
            ACCOUNT_NUMBER, beneficiary, expectedMetadata, scaCredentials))
        .thenReturn(beneficiary);

    // Other headers get added automatically such as Content-Length, just check that at least the
    // headers we asked for are present
    // MockMvc behaviour has changed to not not honor the produces content type; ends up using
    // Tomcat value of
    // application/json;charset=UTF-8, so skip the Content-Type header.
    final Set<Map.Entry<String, List<String>>> headersToCheck =
        headers.entrySet().stream()
            .filter(entry -> !"Content-Type".equals(entry.getKey()))
            .collect(Collectors.toSet());
    final ArgumentMatcher<HttpHeaders> headersMatcher =
        headersArgument -> headersArgument.entrySet().containsAll(headersToCheck);
    when(scaCredentialsExtractor.extract(argThat(headersMatcher)))
        .thenReturn(Optional.of(scaCredentials));

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(headers)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isAccepted())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(beneficiary)));

    verifyNoInteractions(auditingBeneficiaryService);
  }

  @Test
  void deleteBeneficiaryShouldInvokeBeneficiaryService() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata expectedMetadata = buildRequestMetadata(requestId);
    final String requestBeneficiaryId = "beneficiaryId";
    final ScaCredentials scaCredentials =
        new ScaCredentials("challenge", "challenge-response", "sca-key");
    final HttpHeaders headers = standardHeaders(requestId);

    // Other headers get added automatically such as Content-Length, just check that at least the
    // headers we asked for are present
    final ArgumentMatcher<HttpHeaders> headersMatcher =
        headersArgument -> headersArgument.entrySet().containsAll(headers.entrySet());
    when(scaCredentialsExtractor.extract(argThat(headersMatcher)))
        .thenReturn(Optional.of(scaCredentials));

    mvc.perform(
            delete(
                    String.format(
                        BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, requestBeneficiaryId))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(headers))
        .andExpect(status().isAccepted());

    verify(beneficiaryService)
        .deleteBeneficiary(ACCOUNT_NUMBER, requestBeneficiaryId, expectedMetadata, scaCredentials);
    verifyNoInteractions(auditingBeneficiaryService);
  }

  @Test
  void updateBeneficiaryShouldReturnBadRequestForMissingRequestField() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary beneficiary =
        buildExternalBeneficiaryRequest().toBuilder().accountNumber(null).build();
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify an account number")
                    .path(ACCOUNT_NUMBER1)
                    .build())
            .build();

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateBeneficiaryShouldReturnBadRequestForInvalidRequestField() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary beneficiary =
        buildExternalBeneficiaryRequest().toBuilder().accountNumber("123").build();
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(INVALID_FIELD)
                    .message("Account number must be 8 digits")
                    .path(ACCOUNT_NUMBER1)
                    .build())
            .build();

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void
      updateBeneficiaryShouldReturnBadRequestForMissingRequestFieldInExistingBeneficiaryValidationGroup()
          throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary beneficiary =
        buildExternalBeneficiaryRequest().toBuilder().beneficiaryId(null).build();
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify a beneficiary identifier")
                    .path("beneficiaryId")
                    .build())
            .build();

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      names = {UPDATE_BENEFICIARY, DELETE_BENEFICIARY})
  void endpointShouldReturnBadRequestWhenInvalidScaHeadersExceptionThrown(final Endpoint endpoint)
      throws Exception {
    final UUID requestId = UUID.randomUUID();

    final InvalidScaHeadersException exception =
        new InvalidScaHeadersException(
            "",
            Arrays.asList(X_YBS_SCA_CHALLENGE, X_YBS_SCA_KEY),
            Arrays.asList(X_YBS_SCA_CHALLENGE, "x-ybs-sca-challenge-response", X_YBS_SCA_KEY));

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message(
                "Required SCA header missing - Required SCA headers: [x-ybs-sca-challenge, x-ybs-sca-challenge-response, x-ybs-sca-key]")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Missing")
                    .message("Required SCA header missing: x-ybs-sca-challenge")
                    .path(X_YBS_SCA_CHALLENGE)
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Missing")
                    .message("Required SCA header missing: x-ybs-sca-key")
                    .path(X_YBS_SCA_KEY)
                    .build())
            .build();

    stubServiceMethodExceptionForEndpoint(endpoint, exception);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      names = {UPDATE_BENEFICIARY, DELETE_BENEFICIARY})
  void endpointShouldReturnBadRequestWhenInvalidPemKeyExceptionThrown(final Endpoint endpoint)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("SCA key could not be read")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("SCA key must be in PEM format and Base64 encoded")
                    .path(X_YBS_SCA_KEY)
                    .build())
            .build();

    stubServiceMethodExceptionForEndpoint(endpoint, InvalidPemKeyException.class);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      names = {UPDATE_BENEFICIARY, DELETE_BENEFICIARY})
  void endpointShouldReturnBadRequestWhenScaRequiredExceptionThrown(final Endpoint endpoint)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String challenge = "the-challenge";
    final ScaRequiredException exception = new ScaRequiredException(challenge);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    stubServiceMethodExceptionForEndpoint(endpoint, exception);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(header().string(X_YBS_SCA_CHALLENGE, challenge))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      names = {UPDATE_BENEFICIARY, DELETE_BENEFICIARY})
  void endpointShouldReturnBadRequestWhenInvalidScaExceptionThrown(final Endpoint endpoint)
      throws Exception {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    stubServiceMethodExceptionForEndpoint(endpoint, InvalidScaException.class);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @MethodSource("endpointsAndBeneficiaryValidationExceptionReason")
  void endpointShouldReturnBadRequestWhenBeneficiaryValidationExceptionThrown(
      final Endpoint endpoint,
      final BeneficiaryValidationExceptionReason reason,
      final String expectedErrorCode,
      final String expectedErrorMessage)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final BeneficiaryValidationException exception = new BeneficiaryValidationException("", reason);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.CONFLICT)
            .id(requestId)
            .message("Beneficiary validation error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(expectedErrorCode)
                    .message(expectedErrorMessage)
                    .build())
            .build();

    stubServiceMethodExceptionForEndpoint(endpoint, exception);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isConflict())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateBeneficiaryShouldReturnBadRequestWhenInternalBeneficiaryUpdateNotSupportedException()
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary beneficiary = buildExternalBeneficiaryRequest();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Bad Request")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(INVALID_FIELD)
                    .message("Internal beneficiary updates are not supported")
                    .path("type")
                    .build())
            .build();

    doThrow(InternalBeneficiaryUpdateNotSupportedException.class)
        .when(beneficiaryService)
        .updateBeneficiary(any(), any(), any(), any());

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateBeneficiaryShouldReturnBadRequestWhenUnsupportedBeneficiaryFieldUpdateExceptionThrown()
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary beneficiary = buildExternalBeneficiaryRequest();

    final UnsupportedBeneficiaryFieldUpdateException exception =
        new UnsupportedBeneficiaryFieldUpdateException(
            "",
            Arrays.asList(ACCOUNT_NUMBER1, "accountSortCode"),
            Arrays.asList("reference", "memorableName"));

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message(
                "Update of unsupported field requested - Supported fields: [reference, memorableName]")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(INVALID_FIELD)
                    .message("Update of field not supported: accountNumber")
                    .path(ACCOUNT_NUMBER1)
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(INVALID_FIELD)
                    .message("Update of field not supported: accountSortCode")
                    .path("accountSortCode")
                    .build())
            .build();

    doThrow(exception).when(beneficiaryService).updateBeneficiary(any(), any(), any(), any());

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @MethodSource("endpointsAndInvalidAccountNumberStrings")
  void endpointShouldReturnBadRequestIfAccountNumberIsInvalid(
      final Endpoint endpoint, final String accountNumber) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid value")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(INVALID_FIELD)
                    .message(
                        String.format(
                            "%s is not a valid account number; value must be of the form 1234567890",
                            accountNumber))
                    .build())
            .build();

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, accountNumber)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @EnumSource(Endpoint.class)
  void endpointShouldReturnNotFoundIfAccountResourceIsNotFound(final Endpoint endpoint)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedErrorResponse = TestHelper.notFound(requestId);

    stubServiceMethodExceptionForEndpoint(endpoint, AccountResourceNotFoundException.class);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @EnumSource(Endpoint.class)
  void endpointShouldReturnBadRequestWhenScopeIsNotValid(final Endpoint endpoint) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getJwtWithInvalidScope()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @ParameterizedTest
  @EnumSource(Endpoint.class)
  void endpointShouldReturnBadRequestWhenRequestIdIsNotAUUID(final Endpoint endpoint)
      throws Exception {
    final String requestId = "not-a-uuid";

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.id", notNullValue()))
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(REQUEST_ID_HEADER)));
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      mode = EnumSource.Mode.EXCLUDE,
      names = {"REPORT_FAILURE"})
  void endpointShouldReturnInternalServerErrorIfAccountServiceExceptionIsThrown(
      final Endpoint endpoint) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedErrorResponse = TestHelper.internalServerError(requestId);

    stubServiceMethodExceptionForEndpoint(endpoint, AccountServiceException.class);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @EnumSource(
      value = Endpoint.class,
      mode = EnumSource.Mode.EXCLUDE,
      names = {"REPORT_FAILURE"})
  void endpointShouldReturnForbiddenForAccountAccessDeniedException(final Endpoint endpoint)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedErrorResponse = TestHelper.accessDeniedErrorResponse(requestId);

    stubServiceMethodExceptionForEndpoint(endpoint, AccountAccessDeniedException.class);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @EnumSource(Endpoint.class)
  void endpointShouldIncludeResponseBodyWhenUnexpectedSpringInternalExceptionThrown(
      final Endpoint endpoint) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    stubServiceMethodExceptionForEndpoint(endpoint, AsyncRequestTimeoutException.class);

    mvc.perform(
            getRequestBuilderForEndpoint(endpoint, ACCOUNT_NUMBER)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void shouldReturnMethodNotSupportedWhenMethodNotSupported() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("405 Method Not Allowed")
            .id(requestId)
            .message("Method Not Allowed")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method")
                    .build())
            .build();

    mvc.perform(
            post(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .contentType(MediaType.TEXT_PLAIN)
                .headers(standardHeaders(requestId))
                .content(""))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, "GET,PUT"));
  }

  @Test
  void reportFailureShouldReturnNoContentOnSuccess() throws Exception {
    final RequestMetadata metadata = buildRequestMetadata(UUID.randomUUID());
    final FailureRequest request = buildFailureRequest();

    mvc.perform(
            post(CHALLENGE_FAILURE_ENDPOINT)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .contentType(MediaType.APPLICATION_JSON)
                .headers(standardHeaders(metadata.getRequestId().toString()))
                .content(objectMapper.writeValueAsBytes(request)))
        .andExpect(status().isNoContent());

    verify(auditingBeneficiaryService).reportFailure(request, metadata);
  }

  @Test
  void reportFailureShouldReturnForbiddenWhenBadFailureRequestChallengeExceptionIsThrown()
      throws Exception {
    final RequestMetadata metadata = buildRequestMetadata(UUID.randomUUID());
    final FailureRequest request = buildFailureRequest();
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(metadata.getRequestId())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message("Authenticity of the challenge could not validated")
                    .build())
            .build();

    doThrow(BadFailureRequestChallengeException.class)
        .when(auditingBeneficiaryService)
        .reportFailure(request, metadata);

    mvc.perform(
            post(CHALLENGE_FAILURE_ENDPOINT)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .contentType(MediaType.APPLICATION_JSON)
                .headers(standardHeaders(metadata.getRequestId().toString()))
                .content(objectMapper.writeValueAsBytes(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
        .andExpect(content().json(objectMapper.writeValueAsString(response)));
  }

  private FailureRequest buildFailureRequest() {
    final FailureRequest request = FailureRequest.builder().challenge("the-challenge").build();
    return request;
  }

  private enum Endpoint {
    GET_BENEFICIARIES,
    GET_BENEFICIARY_LIMITS,
    UPDATE_BENEFICIARY,
    DELETE_BENEFICIARY,
    REPORT_FAILURE,
  }

  private static Stream<Arguments> endpointsAndInvalidAccountNumberStrings() {
    final List<Endpoint> endpoints =
        new ArrayList<>(EnumSet.complementOf(EnumSet.of(Endpoint.REPORT_FAILURE)));
    final List<String> invalidAccountNumbers =
        Arrays.asList("123a", "foobar", "123456789011", "A234567890");

    return endpoints.stream()
        .flatMap(
            endpoint ->
                invalidAccountNumbers.stream()
                    .map(invalidAccountNumber -> Arguments.of(endpoint, invalidAccountNumber)));
  }

  private static Stream<Arguments> endpointsAndBeneficiaryValidationExceptionReason() {
    final List<Endpoint> endpoints =
        Arrays.asList(Endpoint.UPDATE_BENEFICIARY, Endpoint.DELETE_BENEFICIARY);
    final List<Arguments> argumentsList =
        Arrays.asList(
            Arguments.of(
                BeneficiaryValidationExceptionReason.LIMIT_REACHED,
                "Beneficiary.Limit",
                "Unable to add beneficiary as allowed limit would be exceeded"),
            Arguments.of(
                BeneficiaryValidationExceptionReason.DUPLICATE,
                "Beneficiary.Exists",
                "Unable to add beneficiary as it already exists for this account"),
            Arguments.of(
                BeneficiaryValidationExceptionReason.PENDING,
                "Beneficiary.Pending",
                "Currently unable to support modifications to this beneficiary"),
            Arguments.of(
                BeneficiaryValidationExceptionReason.TECHNICAL,
                "Beneficiary.Technical",
                "Something went wrong"));

    return endpoints.stream()
        .flatMap(
            endpoint ->
                argumentsList.stream()
                    .map(
                        arguments ->
                            Arguments.of(ArrayUtils.insert(0, arguments.get(), endpoint))));
  }

  private MockHttpServletRequestBuilder getRequestBuilderForEndpoint(
      final Endpoint endpoint, final String accountNumber) throws JsonProcessingException {
    switch (endpoint) {
      case GET_BENEFICIARIES:
        return get(String.format(BENEFICIARIES_ENDPOINT, accountNumber));
      case GET_BENEFICIARY_LIMITS:
        return get(String.format(BENEFICIARIY_LIMIT_ENDPOINT, accountNumber));
      case UPDATE_BENEFICIARY:
        return put(String.format(BENEFICIARIES_ENDPOINT, accountNumber))
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(buildExternalBeneficiaryRequest()));
      case DELETE_BENEFICIARY:
        return delete(String.format(BENEFICIARIES_BENEFICIARY_ENDPOINT, accountNumber, "abc123"));
      case REPORT_FAILURE:
        return post(CHALLENGE_FAILURE_ENDPOINT)
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsBytes(buildFailureRequest()));
      default:
        throw new IllegalArgumentException(String.format("Unexpected endpoint %s", endpoint));
    }
  }

  private void stubServiceMethodExceptionForEndpoint(
      final Endpoint endpoint, final Class<? extends Exception> exception) {
    switch (endpoint) {
      case GET_BENEFICIARIES:
        doThrow(exception).when(auditingBeneficiaryService).getBeneficiaries(any(), any());
        break;
      case GET_BENEFICIARY_LIMITS:
        doThrow(exception).when(beneficiaryService).getBeneficiariesLimits(any(), any());
        break;
      case UPDATE_BENEFICIARY:
        doThrow(exception).when(beneficiaryService).updateBeneficiary(any(), any(), any(), any());
        break;
      case DELETE_BENEFICIARY:
        doThrow(exception).when(beneficiaryService).deleteBeneficiary(any(), any(), any(), any());
        break;
      case REPORT_FAILURE:
        doThrow(exception).when(auditingBeneficiaryService).reportFailure(any(), any());
        break;
      default:
        throw new IllegalArgumentException(String.format("Unexpected endpoint %s", endpoint));
    }
  }

  private void stubServiceMethodExceptionForEndpoint(
      final Endpoint endpoint, final Exception exception) {
    switch (endpoint) {
      case GET_BENEFICIARIES:
        doThrow(exception).when(auditingBeneficiaryService).getBeneficiaries(any(), any());
        return;
      case UPDATE_BENEFICIARY:
        doThrow(exception).when(beneficiaryService).updateBeneficiary(any(), any(), any(), any());
        return;
      case DELETE_BENEFICIARY:
        doThrow(exception).when(beneficiaryService).deleteBeneficiary(any(), any(), any(), any());
        return;
      default:
        throw new IllegalArgumentException(String.format("Unexpected endpoint %s", endpoint));
    }
  }

  private Jwt getValidJwt() {
    return getJwtWithScope(VALID_SCOPE);
  }

  private Jwt getValidJwtForBeneficiaryLimit() {
    return getJwtWithScope(VALID_SCOPE_BENEFICIARY_LIMITS);
  }

  private Jwt getJwtWithInvalidScope() {
    return getJwtWithScope(OTHER_SCOPE);
  }

  private Jwt getJwtWithScope(final String scope) {
    return Jwt.withTokenValue("<jwt>")
        .header("kid", "key-id")
        .subject("987654321")
        .claim("scope", scope)
        .claim("brand_code", "YBS")
        .claim("party_id", "12462951")
        .claim("sid", SESSION_ID.toString())
        .build();
  }

  private Jwt getJwtWithScopeAndChannel(final String scope, final String channel) {
    return Jwt.withTokenValue("<jwt>")
        .header("kid", "key-id")
        .subject("987654321")
        .claim("scope", scope)
        .claim("brand_code", "YBS")
        .claim("party_id", "12462951")
        .claim("sid", SESSION_ID.toString())
        .claim("channel", channel)
        .build();
  }

  private HttpHeaders standardHeaders(final UUID requestId) {
    return standardHeaders(requestId.toString());
  }

  private HttpHeaders standardHeaders(final String requestId) {
    final HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    httpHeaders.add(HttpHeaders.HOST, HOST_HEADER_VALUE);
    httpHeaders.add(REQUEST_ID_HEADER, requestId);
    return httpHeaders;
  }

  private RequestMetadata buildRequestMetadata(final UUID requestId) {
    return TestHelper.buildValidRequestMetadata(requestId, 443);
  }

  private ExternalBeneficiary buildExternalBeneficiaryRequest() {
    return TestHelper.createExternalBeneficiary("12345678", "abc123");
  }

  private BeneficiaryLimitResponse buildBeneficieriesLimitResponse() {
    return TestHelper.buildBeneficiaryLimit();
  }

  @Test
  void testGetBeneficiariesFlag() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata expectedMetadata = buildRequestMetadata(requestId);

    final BeneficiaryLimitResponse beneficiaryLimits = buildBeneficieriesLimitResponse();

    when(beneficiaryService.getBeneficiariesLimits(ACCOUNT_NUMBER, expectedMetadata))
        .thenReturn(beneficiaryLimits);

    mvc.perform(
            get(String.format(BENEFICIARIY_LIMIT_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwtForBeneficiaryLimit()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(beneficiaryLimits)));

    verifyNoInteractions(auditingBeneficiaryService);
  }

  @Test
  void deleteBeneficiaryForWebShouldInvokeBeneficiaryServiceWithoutSca() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata expectedMetadata = buildRequestMetadata(requestId);
    final String requestBeneficiaryId = "beneficiaryId";

    final HttpHeaders headers = standardHeaders(requestId);

    mvc.perform(
            delete(
                    String.format(
                        BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, requestBeneficiaryId))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getJwtWithScopeAndChannel(VALID_SCOPE, "WEB")))
                .headers(headers))
        .andExpect(status().isAccepted());

    verify(beneficiaryService)
        .deleteBeneficiaryWithoutSca(ACCOUNT_NUMBER, requestBeneficiaryId, expectedMetadata);
    verifyNoInteractions(auditingBeneficiaryService);
    verifyNoInteractions(scaCredentialsExtractor);
  }
}
