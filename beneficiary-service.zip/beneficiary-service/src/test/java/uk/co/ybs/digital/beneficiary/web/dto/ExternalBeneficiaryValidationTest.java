package uk.co.ybs.digital.beneficiary.web.dto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.beneficiary.utils.TestHelper.validateRequest;
import static uk.co.ybs.digital.beneficiary.web.dto.FieldErrorMatcher.fieldError;

import com.google.common.base.Splitter;
import com.google.common.base.Strings;
import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import javax.validation.groups.Default;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.validation.BindingResult;
import org.springframework.validation.SmartValidator;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ValidationAutoConfiguration.class)
class ExternalBeneficiaryValidationTest {

  public static final String NAME_FIELD = "name";

  @Autowired
  @Qualifier("defaultValidator")
  private SmartValidator validator;

  @Test
  void shouldValidateValidRequestAllFields() {
    final ExternalBeneficiary beneficiary = buildAllFields();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @Test
  void shouldValidateValidRequestAllFieldsExistingBeneficiary() {
    final ExternalBeneficiary beneficiary = buildAllFields();

    final BindingResult bindingResult =
        validateRequest(
            beneficiary, validator, Default.class, ExistingBeneficiaryValidationGroup.class);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @Test
  void shouldValidateValidRequestOptionalFields() {
    final ExternalBeneficiary beneficiary =
        buildAllFields()
            .toBuilder()
            .beneficiaryId(null)
            .reference(null)
            .memorableName(null)
            .build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @Test
  void shouldDetectMissingFields() {
    final ExternalBeneficiary beneficiary = ExternalBeneficiary.builder().build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("accountSortCode", "You must specify an account sort code"),
                fieldError(NAME_FIELD, "You must specify a name"),
                fieldError("accountNumber", "You must specify an account number"))));
  }

  @Test
  void shouldDetectMissingFieldsExistingBeneficiary() {
    final ExternalBeneficiary beneficiary = ExternalBeneficiary.builder().build();

    final BindingResult bindingResult =
        validateRequest(
            beneficiary, validator, Default.class, ExistingBeneficiaryValidationGroup.class);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("beneficiaryId", "You must specify a beneficiary identifier"),
                fieldError("accountSortCode", "You must specify an account sort code"),
                fieldError(NAME_FIELD, "You must specify a name"),
                fieldError("accountNumber", "You must specify an account number"))));
  }

  @ParameterizedTest
  @ValueSource(strings = {"", "11223", "1122334", "11223a"})
  void shouldDetectInvalidSortCode(final String sortCode) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().accountSortCode(sortCode).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError(
                    "accountSortCode",
                    String.format(
                        "%s is not a valid sort code; value must be of the form 112233",
                        sortCode)))));
  }

  @ParameterizedTest
  @ValueSource(strings = {"", "  "})
  void shouldDetectWhitespaceName(final String name) {
    final ExternalBeneficiary beneficiary = buildAllFields().toBuilder().name(name).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError(
                    NAME_FIELD, "Name must contain at least one non-whitespace character"))));
  }

  @ParameterizedTest
  @MethodSource("validCharactersSource")
  void shouldAllowAllValidCharactersInName(final String characters) {
    final ExternalBeneficiary beneficiary = buildAllFields().toBuilder().name(characters).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @ParameterizedTest
  @MethodSource("invalidCharactersSource")
  void shouldDetectInvalidCharactersInName(final char character) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().name(String.valueOf(character)).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError(NAME_FIELD, "Value must match pattern [A-Za-z0-9 ]*"))));
  }

  @ParameterizedTest
  @CsvSource({"30,true", "31,false"})
  void shouldDetectOverMaximumLengthName(final int length, final boolean valid) {
    final String name = Strings.repeat("0", length);
    final ExternalBeneficiary beneficiary = buildAllFields().toBuilder().name(name).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    if (valid) {
      assertThat(bindingResult.hasErrors(), is(false));
    } else {
      assertThat(bindingResult.hasErrors(), is(true));
      assertThat(
          bindingResult.getFieldErrors(),
          containsInAnyOrder(
              Collections.singletonList(
                  fieldError(NAME_FIELD, "Name must be at most 30 characters long"))));
    }
  }

  @ParameterizedTest
  @ValueSource(strings = {"0000000", "000000000", "0000000X"})
  void shouldDetectInvalidAccountNumber(final String accountNumber) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().accountNumber(accountNumber).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError("accountNumber", "Account number must be 8 digits"))));
  }

  @ParameterizedTest
  @ValueSource(strings = {"", "  "})
  void shouldDetectWhitespaceReference(final String reference) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().reference(reference).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError(
                    "reference", "Reference must contain at least one non-whitespace character"))));
  }

  @ParameterizedTest
  @MethodSource("validCharactersSource")
  void shouldAllowAllValidCharactersInReference(final String characters) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().reference(characters).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @ParameterizedTest
  @MethodSource("invalidCharactersSource")
  void shouldDetectInvalidCharactersInReference(final char character) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().reference(String.valueOf(character)).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError("reference", "Value must match pattern [A-Za-z0-9 ]*"))));
  }

  @ParameterizedTest
  @CsvSource({"18,true", "19,false"})
  void shouldDetectOverMaximumLengthReference(final int length, final boolean valid) {
    final String reference = Strings.repeat("0", length);
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().reference(reference).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    if (valid) {
      assertThat(bindingResult.hasErrors(), is(false));
    } else {
      assertThat(bindingResult.hasErrors(), is(true));
      assertThat(
          bindingResult.getFieldErrors(),
          containsInAnyOrder(
              Collections.singletonList(
                  fieldError("reference", "Reference must be at most 18 characters long"))));
    }
  }

  @ParameterizedTest
  @ValueSource(strings = {"", "  "})
  void shouldDetectWhitespaceMemorableName(final String memorableName) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().memorableName(memorableName).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError(
                    "memorableName",
                    "Memorable name must contain at least one non-whitespace character"))));
  }

  @ParameterizedTest
  @MethodSource("validCharactersSource")
  void shouldAllowAllValidCharactersInMemorableName(final String characters) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().memorableName(characters).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @ParameterizedTest
  @MethodSource("invalidCharactersSource")
  void shouldDetectInvalidCharactersInMemorableName(final char character) {
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().memorableName(String.valueOf(character)).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError("memorableName", "Value must match pattern [A-Za-z0-9 ]*"))));
  }

  @ParameterizedTest
  @CsvSource({"20,true", "21,false"})
  void shouldDetectOverMaximumLengthMemorableName(final int length, final boolean valid) {
    final String memorableName = Strings.repeat("0", length);
    final ExternalBeneficiary beneficiary =
        buildAllFields().toBuilder().memorableName(memorableName).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    if (valid) {
      assertThat(bindingResult.hasErrors(), is(false));
    } else {
      assertThat(bindingResult.hasErrors(), is(true));
      assertThat(
          bindingResult.getFieldErrors(),
          containsInAnyOrder(
              Collections.singletonList(
                  fieldError(
                      "memorableName", "Memorable name must be at most 20 characters long"))));
    }
  }

  private ExternalBeneficiary buildAllFields() {
    return ExternalBeneficiary.builder()
        .beneficiaryId("abc123")
        .accountNumber("12345678")
        .accountSortCode("112244")
        .name("MR B TEST")
        .reference("B REF")
        .memorableName("Joint Account")
        .build();
  }

  private static Stream<String> validCharactersSource() {
    final String all = " 01234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    // Split in to chunks so they will fit in to the smallest text field
    final Iterable<String> split = Splitter.fixedLength(18).split(all);
    return StreamSupport.stream(split.spliterator(), false);
  }

  private static Stream<Character> invalidCharactersSource() {
    return Stream.of(
        '!', '@', '£', '$', '%', '^', '&', '*', '(', ')', '-', '_', '=', '+', '#', '[', ']', '{',
        '}', ';', '\'', '\\', ':', '"', '|', ',', '.', '/', '<', '>', '?', '`', '~', '§', '±');
  }
}
