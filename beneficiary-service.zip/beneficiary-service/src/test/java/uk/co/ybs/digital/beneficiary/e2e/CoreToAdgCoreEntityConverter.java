package uk.co.ybs.digital.beneficiary.e2e;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.NonYbsBankAccount;

@RequiredArgsConstructor
public class CoreToAdgCoreEntityConverter {
  private final TransactionTemplate transactionTemplate;
  private final TestEntityManager adgCoreTestEntityManager;

  public BillPaymentInstruction syncToAdgCore(
      final uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction coreInstruction) {
    final BillPaymentInstruction adgCoreInstruction = convert(coreInstruction);
    return transactionTemplate.execute(
        status -> {
          adgCoreTestEntityManager.merge(adgCoreInstruction.getNonYbsBankAccount());
          adgCoreTestEntityManager.merge(adgCoreInstruction);
          adgCoreTestEntityManager.flush();
          return adgCoreInstruction;
        });
  }

  public void syncToAdgCore(
      final uk.co.ybs.digital.beneficiary.model.core.ItInstruction coreInstruction) {
    final ItInstruction adgCoreInstruction = convert(coreInstruction);
    transactionTemplate.execute(
        status -> {
          adgCoreTestEntityManager.merge(adgCoreInstruction);
          adgCoreTestEntityManager.flush();
          return adgCoreInstruction;
        });
  }

  public static BillPaymentInstruction convert(
      final uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction instruction) {
    return BillPaymentInstruction.builder()
        .sysId(instruction.getSysId())
        .memorableName(instruction.getMemorableName())
        .accountNumber(instruction.getAccountNumber())
        .availableAtm(true)
        .endDate(instruction.getEndDate())
        .reference(instruction.getReference())
        .status(instruction.getStatus())
        .nonYbsBankAccount(convert(instruction.getNonYbsBankAccount()))
        .build();
  }

  public static NonYbsBankAccount convert(
      final uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount nonYbsBankAccount) {
    return NonYbsBankAccount.builder()
        .sysId(nonYbsBankAccount.getSysId())
        .accountNumber(nonYbsBankAccount.getAccountNumber())
        .sortCode(nonYbsBankAccount.getSortCode())
        .name(nonYbsBankAccount.getName())
        .build();
  }

  private static ItInstruction convert(
      final uk.co.ybs.digital.beneficiary.model.core.ItInstruction coreInstruction) {
    return ItInstruction.builder()
        .sysId(coreInstruction.getSysId())
        .debtorAccountNumber(coreInstruction.getDebtorAccountNumber())
        .availableAtm(coreInstruction.isAvailableAtm())
        .creditorAccountNumber(coreInstruction.getCreditorAccountNumber())
        .status(coreInstruction.getStatus())
        .endDate(coreInstruction.getEndDate())
        .build();
  }
}
