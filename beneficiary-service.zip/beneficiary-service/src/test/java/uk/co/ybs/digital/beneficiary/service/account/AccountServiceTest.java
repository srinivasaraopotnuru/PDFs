package uk.co.ybs.digital.beneficiary.service.account;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.reactive.function.client.ClientHttpConnectorAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.codec.DecodingException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.beneficiary.config.ServiceToServiceConfig;
import uk.co.ybs.digital.beneficiary.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.beneficiary.exception.AccountServiceEntityNoCustomerRelationshipException;
import uk.co.ybs.digital.beneficiary.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.beneficiary.exception.AccountServiceException;
import uk.co.ybs.digital.beneficiary.service.account.dto.AccountDetails;
import uk.co.ybs.digital.beneficiary.service.account.dto.Deposits;
import uk.co.ybs.digital.beneficiary.service.account.dto.Isa;
import uk.co.ybs.digital.beneficiary.service.account.dto.Product;
import uk.co.ybs.digital.beneficiary.service.account.dto.WithdrawalLimit;
import uk.co.ybs.digital.beneficiary.service.account.dto.Withdrawals;
import uk.co.ybs.digital.beneficiary.service.account.dto.Withdrawals.InterestPenalty;
import uk.co.ybs.digital.beneficiary.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.security.requestsigning.RequestSigningAutoConfiguration;

@SpringBootTest(
    classes = {
      AccountService.class,
      ServiceToServiceConfig.class,
      RequestSigningAutoConfiguration.class,
      ClientHttpConnectorAutoConfiguration
          .class // Required by the WebClient bean defined in AccountServiceConfig
    },
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AccountServiceTest {

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Account service returned error status: ";

  private static final String PARTY_ID = "12462951";
  private static final String ACCOUNT_NUMBER = "0123456789";
  public static final String CONTENT_TYPE = "Content-Type";
  public static final String APPLICATION_JSON = "application/json";
  public static final String CODE_400 = "400";

  @Autowired private AccountService accountService;

  @Autowired ObjectMapper objectMapper;

  @Value("${uk.co.ybs.digital.account-test-port}")
  private int accountTestPort;

  private MockWebServer mockWebServer;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start(accountTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void getAccountShouldReturnAccount() throws IOException, InterruptedException {
    final String body =
        readClassPathResource("api/account/account/ResponseAccountNumber0123456789.json");
    mockWebServer.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, 80);
    final AccountDetails account = accountService.getAccount(ACCOUNT_NUMBER, metadata);
    assertThat(account, is(equalTo(buildValidAccount())));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(equalTo(("GET"))));
    assertThat(
        recordedRequest.getPath(), is(equalTo("/account/private/accounts/" + ACCOUNT_NUMBER)));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(equalTo("Bearer <jwt>")));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST), is(equalTo("localhost:" + accountTestPort)));
    assertThat(recordedRequest.getHeader("x-ybs-request-id"), is(equalTo(requestId.toString())));
    assertThat(recordedRequest.getHeader("x-ybs-request-signature"), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader("x-ybs-request-signature-key-id"),
        is(equalTo("beneficiary-service-nonprod-1")));
  }

  @Test
  void methodShouldThrowAccountServiceExceptionForInvalidJson() {
    final String body = "abc";

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, 80);

    mockWebServer.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final AccountServiceException thrown =
        assertThrows(
            AccountServiceException.class,
            () -> accountService.getAccount(ACCOUNT_NUMBER, metadata));

    assertThat(thrown.getMessage(), is("Error calling account service"));
    assertThat(thrown.getCause(), instanceOf(DecodingException.class));
  }

  @Test
  void methodShouldThrowAccountServiceExceptionForEmptyResponse() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, 80);

    final String body = "";
    mockWebServer.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final AccountServiceException exception =
        assertThrows(
            AccountServiceException.class,
            () -> accountService.getAccount(ACCOUNT_NUMBER, metadata));
    assertThat(exception.getMessage(), equalTo("Empty response calling account service"));
  }

  @Test
  void methodShouldThrowAccountServiceExceptionForConnectionError() throws IOException {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, 80);

    mockWebServer.shutdown();

    final AccountServiceException exception =
        assertThrows(
            AccountServiceException.class,
            () -> accountService.getAccount(ACCOUNT_NUMBER, metadata));
    assertThat(exception.getMessage(), is(equalTo("Error calling account service")));
  }

  @Test
  void methodShouldThrowAccountAccessDeniedExceptionForHttpStatus403AndErrorCodeAccessDenied()
      throws IOException {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, 80);

    final String body = readClassPathResource("api/account/ResponseErrorAccessDenied.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.FORBIDDEN.value())
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(body));

    final AccountServiceEntityAccessDeniedException exception =
        assertThrows(
            AccountServiceEntityAccessDeniedException.class,
            () -> accountService.getAccount(ACCOUNT_NUMBER, metadata));
    assertThat(
        exception.getMessage(),
        is(equalTo("Party " + PARTY_ID + " is not allowed access account " + ACCOUNT_NUMBER)));
  }

  @Test
  void
      methodShouldThrowAccountServiceEntityNoCustomerRelationshipExceptionForHttpStatus403AndErrorCodeNoCustomerRelationship()
          throws IOException {
    final String body =
        readClassPathResource("api/account/ResponseErrorAccessDeniedNoCustomerRelationship.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.FORBIDDEN.value())
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, 80);

    final AccountServiceEntityNoCustomerRelationshipException exception =
        assertThrows(
            AccountServiceEntityNoCustomerRelationshipException.class,
            () -> accountService.getAccount(ACCOUNT_NUMBER, metadata));
    assertThat(
        exception.getMessage(),
        is(
            equalTo(
                "Party "
                    + PARTY_ID
                    + " doesn't have customer relationship to access account "
                    + ACCOUNT_NUMBER)));
  }

  @Test
  void methodShouldThrowAccountNotFoundExceptionForHttpStatus404AndErrorCodeResourceNotFound()
      throws IOException {
    final String body = readClassPathResource("api/account/ResponseErrorResourceNotFound.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.NOT_FOUND.value())
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, 80);

    final AccountServiceEntityNotFoundException exception =
        assertThrows(
            AccountServiceEntityNotFoundException.class,
            () -> accountService.getAccount(ACCOUNT_NUMBER, metadata));
    assertThat(exception.getMessage(), is(equalTo("Failed to find account " + ACCOUNT_NUMBER)));
  }

  @ParameterizedTest
  @MethodSource("unexpectedHttpStatusesAndBodies")
  void getAccountShouldThrowAccountServiceExceptionForUnexpectedHttpStatusAndBody(
      final HttpStatus httpStatus,
      final MediaType mediaType,
      final ClassPathResource bodyResource,
      final Matcher<String> expectedMessage)
      throws IOException {
    final String body = readClassPathResource(bodyResource);
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, mediaType)
            .setBody(body));

    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 80);
    final AccountServiceException exception =
        assertThrows(
            AccountServiceException.class,
            () -> accountService.getAccount(ACCOUNT_NUMBER, metadata));
    assertThat(
        exception.getClass(),
        is(equalTo(AccountServiceException.class))); // Expect not a sub-class here
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AccountServiceException.class)));
  }

  private static Stream<Arguments> unexpectedHttpStatusesAndBodies() {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDeniedWithAdditional.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied"),
                containsString("ErrorCodeOther"))),
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorResourceNotFound.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("Resource.NotFound"))),
        Arguments.of(
            HttpStatus.NOT_FOUND,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorResourceNotFoundWithAdditional.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "404"),
                containsString("Resource.NotFound"),
                containsString("ErrorCodeOther"))),
        Arguments.of(
            HttpStatus.NOT_FOUND,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDenied.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "404"),
                containsString("AccessDenied"))),
        Arguments.of(
            HttpStatus.INTERNAL_SERVER_ERROR,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDenied.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "500"),
                containsString("AccessDenied"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/UnexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/EmptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/TextResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            new ClassPathResource("api/audit/response/TextResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)));
  }

  private String readClassPathResource(final ClassPathResource classPathResource)
      throws IOException {
    return new String(
        Files.readAllBytes(classPathResource.getFile().toPath()), StandardCharsets.UTF_8);
  }

  private String readClassPathResource(final String classPathResource) throws IOException {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  private static AccountDetails buildValidAccount() {
    return AccountDetails.builder()
        .accountNumber("0123456789")
        .accountSortCode("123456")
        .product(
            Product.builder()
                .description("Monthly Regular Saver: Issue 2")
                .identifier("EGG302A")
                .type("SAVER")
                .build())
        .withdrawals(
            Withdrawals.builder()
                .permittedOverApi(true)
                .limit(
                    WithdrawalLimit.builder()
                        .permitted(4)
                        .available(3)
                        .periodEnd(LocalDate.of(2020, 12, 31))
                        .build())
                .interestPenalty(InterestPenalty.builder().days(30).build())
                .build())
        .deposits(Deposits.builder().permittedOverApi(true).build())
        .isa(Isa.builder().flexible(false).build())
        .build();
  }
}
