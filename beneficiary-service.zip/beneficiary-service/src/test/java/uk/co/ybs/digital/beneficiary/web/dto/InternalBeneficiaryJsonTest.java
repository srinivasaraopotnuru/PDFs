package uk.co.ybs.digital.beneficiary.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
public class InternalBeneficiaryJsonTest {
  @Autowired private JacksonTester<InternalBeneficiary> json;

  @Value("classpath:api/accountBeneficiaries/internal.json")
  private Resource responseFile;

  @Value("classpath:api/accountBeneficiaries/internalWithSysId.json")
  private Resource responseFileWithSysId;

  @Test
  void serializes() throws IOException {
    final InternalBeneficiary response = buildInternalBeneficiary();
    assertThat(json.write(response)).isEqualToJson(responseFile, JSONCompareMode.STRICT);
  }

  @Test
  void serializesWithSysId() throws IOException {
    final InternalBeneficiary response = buildInternalBeneficiary().toBuilder().sysId(1L).build();
    assertThat(json.write(response)).isEqualToJson(responseFileWithSysId, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    final InternalBeneficiary response = buildInternalBeneficiary();
    assertThat(json.read(responseFile)).isEqualTo(response);
  }

  private static InternalBeneficiary buildInternalBeneficiary() {
    return InternalBeneficiary.builder().accountNumber("1234567890").build();
  }
}
