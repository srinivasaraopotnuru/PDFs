package uk.co.ybs.digital.beneficiary.service;

import static org.mockito.Mockito.verify;

import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.service.audit.AuditService;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiarySuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryViewRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.BeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class BeneficiaryAuditorTest {

  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String INTERNAL_ACCOUNT_NUMBER = "1234567891";
  private static final String INTERNAL_ACCOUNT_NUMBER_OTHER = "1234567892";
  private static final String EXTERNAL_ACCOUNT_NUMBER = "12345678";
  private static final String EXTERNAL_ACCOUNT_NUMBER_OTHER = "12345679";
  public static final String BENEFICIARY_INFORMATION_ARGS = "beneficiaryInformationArgs";

  @InjectMocks private BeneficiaryAuditor testSubject;

  @Mock private AuditService auditService;

  @Test
  void shouldAuditBeneficiariesView() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    testSubject.auditBeneficiariesView(INTERNAL_ACCOUNT_NUMBER, requestMetadata);

    final AuditBeneficiaryViewRequest expectedAuditRequest =
        AuditBeneficiaryViewRequest.builder()
            .ipAddress(IP_ADDRESS)
            .beneficiaryInformation(
                AuditBeneficiaryViewRequest.BeneficiaryInformation.builder()
                    .accountNumber(INTERNAL_ACCOUNT_NUMBER)
                    .build())
            .build();

    verify(auditService).auditBeneficiariesView(expectedAuditRequest, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource(BENEFICIARY_INFORMATION_ARGS)
  void shouldAuditBeneficiaryCreateSuccess(final BeneficiaryInformation beneficiaryInformation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    testSubject.auditBeneficiaryCreateSuccess(beneficiaryInformation, requestMetadata);

    final AuditBeneficiarySuccessRequest expectedAuditRequest =
        AuditBeneficiarySuccessRequest.builder()
            .ipAddress(IP_ADDRESS)
            .beneficiaryInformation(beneficiaryInformation)
            .build();

    verify(auditService).auditBeneficiaryCreateSuccess(expectedAuditRequest, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource(BENEFICIARY_INFORMATION_ARGS)
  void shouldAuditBeneficiaryCreateFailure(final BeneficiaryInformation beneficiaryInformation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final String failureReason = "Technical Failure";

    testSubject.auditBeneficiaryCreateFailure(
        beneficiaryInformation, failureReason, requestMetadata);

    final AuditBeneficiaryFailureRequest expectedAuditRequest =
        AuditBeneficiaryFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .message(failureReason)
            .beneficiaryInformation(beneficiaryInformation)
            .build();

    verify(auditService).auditBeneficiaryCreateFailure(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditBeneficiaryUpdateSuccess() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final ExternalBeneficiaryInformation beneficiaryInformation =
        TestHelper.createExternalBeneficiaryInformation(
            EXTERNAL_ACCOUNT_NUMBER, EXTERNAL_ACCOUNT_NUMBER_OTHER);
    final ExternalUpdateBeneficiaryInformation updateBeneficiaryInformation =
        TestHelper.createExternalUpdateBeneficiaryInformation();
    final ExternalUpdateBeneficiaryInformationWrapper updateWrapper =
        new ExternalUpdateBeneficiaryInformationWrapper(
            beneficiaryInformation, updateBeneficiaryInformation);

    testSubject.auditBeneficiaryUpdateSuccess(updateWrapper, requestMetadata);

    final AuditBeneficiaryUpdateSuccessRequest expectedAuditRequest =
        AuditBeneficiaryUpdateSuccessRequest.builder()
            .ipAddress(IP_ADDRESS)
            .beneficiaryInformation(beneficiaryInformation)
            .updateBeneficiaryInformation(updateBeneficiaryInformation)
            .build();

    verify(auditService).auditBeneficiaryUpdateSuccess(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditBeneficiaryUpdateFailure() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final ExternalBeneficiaryInformation beneficiaryInformation =
        TestHelper.createExternalBeneficiaryInformation(
            EXTERNAL_ACCOUNT_NUMBER, EXTERNAL_ACCOUNT_NUMBER_OTHER);
    final ExternalUpdateBeneficiaryInformation updateBeneficiaryInformation =
        TestHelper.createExternalUpdateBeneficiaryInformation();
    final ExternalUpdateBeneficiaryInformationWrapper updateWrapper =
        new ExternalUpdateBeneficiaryInformationWrapper(
            beneficiaryInformation, updateBeneficiaryInformation);
    final String failureReason = "Technical Failure";

    testSubject.auditBeneficiaryUpdateFailure(updateWrapper, failureReason, requestMetadata);

    final AuditBeneficiaryUpdateFailureRequest expectedAuditRequest =
        AuditBeneficiaryUpdateFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .message(failureReason)
            .beneficiaryInformation(beneficiaryInformation)
            .updateBeneficiaryInformation(updateBeneficiaryInformation)
            .build();

    verify(auditService).auditBeneficiaryUpdateFailure(expectedAuditRequest, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource(BENEFICIARY_INFORMATION_ARGS)
  void shouldAuditBeneficiaryDeleteSuccess(final BeneficiaryInformation beneficiaryInformation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    testSubject.auditBeneficiaryDeleteSuccess(beneficiaryInformation, requestMetadata);

    final AuditBeneficiarySuccessRequest expectedAuditRequest =
        AuditBeneficiarySuccessRequest.builder()
            .ipAddress(IP_ADDRESS)
            .beneficiaryInformation(beneficiaryInformation)
            .build();

    verify(auditService).auditBeneficiaryDeleteSuccess(expectedAuditRequest, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource(BENEFICIARY_INFORMATION_ARGS)
  void shouldAuditBeneficiaryDeleteFailure(final BeneficiaryInformation beneficiaryInformation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final String failureReason = "Technical Failure";

    testSubject.auditBeneficiaryDeleteFailure(
        beneficiaryInformation, failureReason, requestMetadata);

    final AuditBeneficiaryFailureRequest expectedAuditRequest =
        AuditBeneficiaryFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .message(failureReason)
            .beneficiaryInformation(beneficiaryInformation)
            .build();

    verify(auditService).auditBeneficiaryDeleteFailure(expectedAuditRequest, requestMetadata);
  }

  @SuppressWarnings("PMD.UnusedPrivateMethod")
  private static Stream<BeneficiaryInformation> beneficiaryInformationArgs() {
    return Stream.of(
        TestHelper.createExternalBeneficiaryInformation(
            EXTERNAL_ACCOUNT_NUMBER, EXTERNAL_ACCOUNT_NUMBER_OTHER),
        TestHelper.createInternalBeneficiaryInformation(
            INTERNAL_ACCOUNT_NUMBER, INTERNAL_ACCOUNT_NUMBER_OTHER));
  }

  @Test
  void shouldAuditBeneficiaryChallenge() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    testSubject.auditBeneficiaryChallenge(requestMetadata);

    final AuditBeneficiaryChallengeRequest expectedAuditRequest =
        AuditBeneficiaryChallengeRequest.builder().ipAddress(IP_ADDRESS).build();

    verify(auditService).auditBeneficiaryChallenge(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditBeneficiaryChallengeSuccess() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    testSubject.auditBeneficiaryChallengeSuccess(requestMetadata);

    final AuditBeneficiaryChallengeSuccessRequest expectedAuditRequest =
        AuditBeneficiaryChallengeSuccessRequest.builder().ipAddress(IP_ADDRESS).build();

    verify(auditService).auditBeneficiaryChallengeSuccess(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditBeneficiaryChallengeFailure() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final String message = "Invalid Credentials";

    testSubject.auditBeneficiaryChallengeFailure(requestMetadata, message);

    final AuditBeneficiaryChallengeFailureRequest expectedAuditRequest =
        AuditBeneficiaryChallengeFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .message(message)
            .build();

    verify(auditService).auditBeneficiaryChallengeFailure(expectedAuditRequest, requestMetadata);
  }
}
