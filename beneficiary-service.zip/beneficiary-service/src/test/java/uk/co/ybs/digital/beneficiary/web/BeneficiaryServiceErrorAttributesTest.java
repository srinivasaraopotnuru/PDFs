package uk.co.ybs.digital.beneficiary.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.servlet.error.BasicErrorController;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;

@WebMvcTest(BasicErrorController.class)
class BeneficiaryServiceErrorAttributesTest {
  @Autowired private BeneficiaryServiceErrorAttributes testSubject;

  @Test
  void shouldBuildInternalServerErrorAttributes() {
    final UUID requestId = UUID.randomUUID();

    final MockHttpServletRequest request = new MockHttpServletRequest();
    request.setAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME, requestId);

    final WebRequest webRequest = new ServletWebRequest(request);

    final Map<String, Object> attributes =
        testSubject.getErrorAttributes(webRequest, ErrorAttributeOptions.defaults());
    assertThat(attributes.get("id"), is(requestId.toString()));
    assertThat(attributes.get("code"), is("500 Internal Server Error"));
    assertThat(attributes.get("message"), is("Internal Server Error"));

    @SuppressWarnings("unchecked")
    final List<Map<String, Object>> errors = (List<Map<String, Object>>) attributes.get("errors");

    assertThat(errors.size(), is(1));
    assertThat(errors.get(0).get("errorCode"), is("UnexpectedError"));
    assertThat(errors.get(0).get("message"), is("Unexpected error"));
  }
}
