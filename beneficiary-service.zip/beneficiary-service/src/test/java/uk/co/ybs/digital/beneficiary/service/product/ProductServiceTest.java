package uk.co.ybs.digital.beneficiary.service.product;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.beneficiary.utils.TestHelper.readClassPathResource;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.reactive.function.client.ClientHttpConnectorAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.beneficiary.config.ServiceToServiceConfig;
import uk.co.ybs.digital.beneficiary.service.product.dto.ProductInfo;
import uk.co.ybs.digital.beneficiary.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.security.requestsigning.RequestSigningAutoConfiguration;

@SpringBootTest(
    classes = {
      ProductService.class,
      ServiceToServiceConfig.class,
      RequestSigningAutoConfiguration.class,
      ClientHttpConnectorAutoConfiguration
          .class // Required by the WebClient bean defined in ProductServiceConfig
    },
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class ProductServiceTest {

  private static final String REQUEST_SIGNATURE_KEY_ID_HEADER = "x-ybs-request-signature-key-id";
  private static final String REQUEST_SIGNATURE_HEADER = "x-ybs-request-signature";
  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String EMPTY_RESPONSE_ERROR_MESSAGE =
      "Empty response calling product service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX = "Error calling product service: ";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling product service";

  private static final String PRODUCT_IDENTIFIER_INTSAV = "INTSAV";
  public static final String TEXT_RESPONSE_TXT = "api/productService/response/TextResponse.txt";
  public static final String CODE_400 = "400";

  @Autowired private ProductService productService;

  @Value("${uk.co.ybs.digital.product-test-port}")
  private int productTestPort;

  @Value("${spring.security.ybs.request-signature.signing.key-id}")
  private String requestSignatureSigningKeyId;

  private MockWebServer mockWebServer;

  private RequestMetadata requestMetadata;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start(productTestPort);

    requestMetadata = TestHelper.buildValidRequestMetadata(UUID.randomUUID(), productTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void getProductInfoShouldReturnProductInfo() throws IOException, InterruptedException {
    final String body =
        readClassPathResource("api/productService/response/getProductInfoSuccess.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(body));

    final ProductInfo productInfo =
        productService.getProductInfo(PRODUCT_IDENTIFIER_INTSAV, requestMetadata);
    assertThat(productInfo, equalTo(createProductInfoPrivate()));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(
        recordedRequest.getPath(), endsWith("/private/product/" + PRODUCT_IDENTIFIER_INTSAV));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer <jwt>"));
    assertThat(recordedRequest.getHeader(HttpHeaders.HOST), is("localhost:" + productTestPort));
    assertThat(
        recordedRequest.getHeader(REQUEST_ID_HEADER),
        is(requestMetadata.getRequestId().toString()));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE_HEADER), notNullValue());
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID_HEADER),
        is(requestSignatureSigningKeyId));
  }

  @Test
  void getProductInfoShouldThrowProductInfoExceptionWhenConnectionErrorConnectingToProductService()
      throws IOException {
    mockWebServer.shutdown();
    final ProductServiceException exception =
        assertThrows(
            ProductServiceException.class,
            () -> productService.getProductInfo(PRODUCT_IDENTIFIER_INTSAV, requestMetadata));
    assertThat(exception.getMessage(), equalTo(UNEXPECTED_ERROR_MESSAGE));
  }

  @ParameterizedTest
  @MethodSource("productServiceErrorResponses")
  void getProductInfoShouldThrowProductServiceExceptionWhenProductServiceReturnsErrorResponse(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final ProductServiceException exception =
        assertThrows(
            ProductServiceException.class,
            () -> productService.getProductInfo(PRODUCT_IDENTIFIER_INTSAV, requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(ProductServiceException.class)));
  }

  private static Stream<Arguments> productServiceErrorResponses() throws IOException {
    return Stream.of(
        // ok response with body not matching content-type
        Arguments.of(
            HttpStatus.OK,
            MediaType.APPLICATION_JSON,
            readClassPathResource(TEXT_RESPONSE_TXT),
            is(UNEXPECTED_ERROR_MESSAGE)),
        // ok response with text body
        Arguments.of(
            HttpStatus.OK,
            MediaType.TEXT_PLAIN,
            readClassPathResource(TEXT_RESPONSE_TXT),
            is(UNEXPECTED_ERROR_MESSAGE)),
        // ok response with empty body
        Arguments.of(
            HttpStatus.OK,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/response/EmptyResponse.json"),
            is(EMPTY_RESPONSE_ERROR_MESSAGE)),

        // standard error response
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/response/ErrorResponseBadRequest.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400),
                containsString("Field.Invalid"))),
        // error response with unexpected json in response body
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/response/UnexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        // error response with body not matching content-type
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource(TEXT_RESPONSE_TXT),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        // error response with text body
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource(TEXT_RESPONSE_TXT),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)),
        // error response with empty body
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/response/EmptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + CODE_400)));
  }

  private static ProductInfo createProductInfoPrivate() {
    return createProductInfo(buildWithdrawalInterestPenalty())
        .toBuilder()
        .isa(ProductInfo.Isa.builder().flexible(false).isaYear(1).build())
        .beneficiaries(ProductInfo.Beneficiaries.builder().external(1).internal(1).build())
        .build();
  }

  private static ProductInfo createProductInfo(
      final ProductInfo.Withdrawals.InterestPenalty interestPenalty) {
    return ProductInfo.builder()
        .productIdentifier("EGG302A")
        .customerDescription("Customer Description")
        .productType("Product Type")
        .maximumMonthlyPayment(BigDecimal.valueOf(100, 2))
        .balance(
            ProductInfo.Balance.builder()
                .min(BigDecimal.valueOf(0, 2))
                .max(BigDecimal.valueOf(100, 2))
                .build())
        .deposits(
            ProductInfo.Deposits.builder()
                .permittedInternal(true)
                .limits(
                    ProductInfo.Deposits.Limits.builder()
                        .amount(
                            ProductInfo.AmountPeriodLimits.builder()
                                .anniversaryYear(BigDecimal.valueOf(100, 2))
                                .month(BigDecimal.valueOf(100, 2))
                                .productTerm(BigDecimal.valueOf(100, 2))
                                .taxYear(BigDecimal.valueOf(100, 2))
                                .year(BigDecimal.valueOf(100, 2))
                                .build())
                        .build())
                .build())
        .withdrawals(
            ProductInfo.Withdrawals.builder()
                .interestPenalty(interestPenalty)
                .permittedOverWeb(true)
                .limits(
                    ProductInfo.Withdrawals.Limits.builder()
                        .number(
                            ProductInfo.NumberPeriodLimits.builder()
                                .anniversaryYear(1)
                                .month(1)
                                .productTerm(1)
                                .taxYear(1)
                                .year(1)
                                .build())
                        .build())
                .build())
        .build();
  }

  private static ProductInfo.Withdrawals.InterestPenalty buildWithdrawalInterestPenalty() {
    return ProductInfo.Withdrawals.InterestPenalty.builder()
        .code(2)
        .days(30)
        .balanceUpperBound(new BigDecimal("999999999.99"))
        .build();
  }
}
