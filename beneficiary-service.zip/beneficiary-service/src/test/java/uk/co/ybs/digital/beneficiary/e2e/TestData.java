package uk.co.ybs.digital.beneficiary.e2e;

import java.time.LocalDateTime;

public class TestData {
  public static final String PARTY_ID = "92462951";
  public static final String CANONICAL_PARTY_ID = "12462951";
  public static final Long DEBTOR_ACCOUNT_NUMBER = 2001L;
  public static final String DEBTOR_ACCOUNT_NUMBER_STRING = "0000002001";
  public static final String EXTERNAL_ACCOUNT_NUMBER = "12345678";
  public static final String OTHER_EXTERNAL_ACCOUNT_NUMBER = "12345679";
  public static final String INTERNAL_ACCOUNT_NUMBER = "1234567899";
  public static final String OTHER_INTERNAL_ACCOUNT_NUMBER = "1234567890";
  public static final String SORT_CODE = "123456";
  public static final String MEMORABLE_NAME = null;
  public static final String NAME = "MR TEST";
  public static final String REFERENCE = "Ref";
  public static final String CREATED_AT = "0795";
  public static final String CREATED_BY = "SAPP";
  public static final LocalDateTime EXISTING_BENEFICIARY_START_DATE =
      LocalDateTime.parse("2020-05-26T14:45:01");
  public static final Long PRODUCT_SYS_ID = 2000L;
  public static final String ACTIVITY_PLAYER_TABLE_ID = "ACCNUM";
  public static final String ACTIVITY_TYPE_CODE_MHLDRS = "MHLDRS";
  public static final String ACTIVITY_GROUP_CODE_AISP = "AISP";
  public static final String BANK_NAME = "Bank 1";
}
