package uk.co.ybs.digital.beneficiary.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
public class ExternalBeneficiaryJsonTest {
  @Autowired private JacksonTester<ExternalBeneficiary> json;

  @Value("classpath:api/accountBeneficiaries/external.json")
  private Resource responseFile;

  @Value("classpath:api/accountBeneficiaries/externalWithSysId.json")
  private Resource responseFileWithSysId;

  @Test
  void serializes() throws IOException {
    final ExternalBeneficiary response = buildExternalBeneficiary();
    assertThat(json.write(response)).isEqualToJson(responseFile, JSONCompareMode.STRICT);
  }

  @Test
  void serializesWithSysId() throws IOException {
    final ExternalBeneficiary response = buildExternalBeneficiary().toBuilder().sysId(1L).build();
    assertThat(json.write(response)).isEqualToJson(responseFileWithSysId, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    final ExternalBeneficiary response = buildExternalBeneficiary();
    assertThat(json.read(responseFile)).isEqualTo(response);
  }

  private static ExternalBeneficiary buildExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .name("MR B TEST")
        .accountNumber("12345679")
        .accountSortCode("112244")
        .reference("B REF")
        .memorableName("Joint Account")
        .build();
  }
}
