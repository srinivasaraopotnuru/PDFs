package uk.co.ybs.digital.beneficiary.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.beneficiary.model.adgcore.AccountNumber;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.model.adgcore.SavingProduct;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;

@YbsDataJpaTest
class BillPaymentInstructionRepositoryTest {

  private static final Long PRODUCT_ID = 1001L;
  private static final Long OWNING_ACCOUNT_NUMBER = 1000000001L;
  private static final Long OTHER_OWNING_ACCOUNT_NUMBER = 1000000002L;

  @Autowired private BillPaymentInstructionRepository testSubject;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  @Test
  void shouldFindActiveExternalBeneficiaries() {
    adgCoreTestEntityManager.persistAndFlush(buildProduct());
    adgCoreTestEntityManager.persistAndFlush(buildAccountNumber(OWNING_ACCOUNT_NUMBER));
    adgCoreTestEntityManager.persistAndFlush(buildAccountNumber(OTHER_OWNING_ACCOUNT_NUMBER));

    // Valid account 1
    final NonYbsBankAccount account =
        NonYbsBankAccount.builder().sysId(1L).accountNumber(12345678L).sortCode(123456L).build();
    adgCoreTestEntityManager.persistAndFlush(account);

    final BillPaymentInstruction instruction =
        BillPaymentInstruction.builder()
            .sysId(1L)
            .nonYbsBankAccount(account)
            .accountNumber(OWNING_ACCOUNT_NUMBER)
            .status("ACTIVE")
            .availableAtm(true)
            .reference("Reference")
            .endDate(null)
            .memorableName("Memorable Name")
            .build();
    adgCoreTestEntityManager.persistAndFlush(instruction);

    // Valid account 2
    final NonYbsBankAccount account2 =
        account.toBuilder().sysId(2L).accountNumber(22345678L).build();
    adgCoreTestEntityManager.persistAndFlush(account2);

    final BillPaymentInstruction instruction2 =
        instruction.toBuilder().sysId(2L).nonYbsBankAccount(account2).build();
    adgCoreTestEntityManager.persistAndFlush(instruction2);

    // Invalid/wrong account
    adgCoreTestEntityManager.persistAndFlush(
        instruction.toBuilder().sysId(3L).endDate(LocalDateTime.now().minusDays(1)).build());
    adgCoreTestEntityManager.persistAndFlush(
        instruction.toBuilder().sysId(4L).status("ONEOFF").build());
    adgCoreTestEntityManager.persistAndFlush(
        instruction.toBuilder().sysId(5L).availableAtm(false).build());
    adgCoreTestEntityManager.persistAndFlush(
        instruction.toBuilder().sysId(6L).accountNumber(OTHER_OWNING_ACCOUNT_NUMBER).build());

    adgCoreTestEntityManager.clear();

    final Collection<BillPaymentInstruction> instructions =
        testSubject.findActiveExternalBeneficiaries(OWNING_ACCOUNT_NUMBER, LocalDateTime.now());
    assertThat(instructions, containsInAnyOrder(instruction, instruction2));
  }

  @Test
  void shouldFindById() {
    adgCoreTestEntityManager.persistAndFlush(buildProduct());
    adgCoreTestEntityManager.persistAndFlush(buildAccountNumber(OWNING_ACCOUNT_NUMBER));

    final NonYbsBankAccount account =
        NonYbsBankAccount.builder().sysId(1L).accountNumber(12345678L).sortCode(123456L).build();
    adgCoreTestEntityManager.persistAndFlush(account);

    final BillPaymentInstruction instruction =
        BillPaymentInstruction.builder()
            .sysId(1L)
            .nonYbsBankAccount(account)
            .accountNumber(OWNING_ACCOUNT_NUMBER)
            .status("ACTIVE")
            .availableAtm(true)
            .reference("Reference")
            .endDate(null)
            .memorableName("Memorable Name")
            .build();
    adgCoreTestEntityManager.persistAndFlush(instruction);

    adgCoreTestEntityManager.clear();

    final Optional<BillPaymentInstruction> retrievedInstruction = testSubject.findById(1L);
    assertThat(retrievedInstruction.isPresent(), is(true));
    assertThat(retrievedInstruction.get(), is(instruction));
  }

  private AccountNumber buildAccountNumber(final Long accountNumber) {
    return AccountNumber.builder()
        .accountNumber(accountNumber)
        .savingProductSysId(PRODUCT_ID)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .build();
  }

  private SavingProduct buildProduct() {
    return SavingProduct.builder().sysid(PRODUCT_ID).brandCode("YBS").build();
  }

  @Test
  void findActiveExternalBeneficiariesCount() {
    adgCoreTestEntityManager.persistAndFlush(buildProduct());
    adgCoreTestEntityManager.persistAndFlush(buildAccountNumber(OWNING_ACCOUNT_NUMBER));

    final NonYbsBankAccount account =
        NonYbsBankAccount.builder().sysId(1L).accountNumber(12345678L).sortCode(123456L).build();
    adgCoreTestEntityManager.persistAndFlush(account);

    final BillPaymentInstruction instruction =
        BillPaymentInstruction.builder()
            .sysId(1L)
            .nonYbsBankAccount(account)
            .accountNumber(OWNING_ACCOUNT_NUMBER)
            .status("ACTIVE")
            .availableAtm(true)
            .reference("Reference")
            .endDate(null)
            .memorableName("Memorable Name")
            .build();

    adgCoreTestEntityManager.persistAndFlush(instruction);
    adgCoreTestEntityManager.clear();

    final int count =
        testSubject.findActiveExternalBeneficiaries(instruction.getAccountNumber(), null).size();
    assertThat(count, is(1));
  }
}
