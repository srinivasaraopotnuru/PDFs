package uk.co.ybs.digital.beneficiary.model;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class YesConverterTest {

  @InjectMocks private YesConverter testSubject;

  @ParameterizedTest
  @MethodSource("booleanValues")
  void shouldReturnExpectedDatabaseColumnValue(final boolean input, final String expectedValue) {
    String result = testSubject.convertToDatabaseColumn(input);
    assertThat(result, is(expectedValue));
  }

  private static Stream<Arguments> booleanValues() {
    return Stream.of(Arguments.of(true, "Y"), Arguments.of(false, "N"));
  }

  @ParameterizedTest
  @MethodSource("dbValues")
  void shouldReturnExpectedBooleanValue(final String input, final boolean expectedValue) {
    boolean result = testSubject.convertToEntityAttribute(input);
    assertThat(result, is(expectedValue));
  }

  private static Stream<Arguments> dbValues() {
    return Stream.of(Arguments.of("Y", true), Arguments.of("N", false));
  }
}
