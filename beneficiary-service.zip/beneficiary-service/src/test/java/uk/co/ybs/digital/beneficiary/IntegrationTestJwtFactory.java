package uk.co.ybs.digital.beneficiary;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.security.Key;
import java.time.Duration;
import java.time.Instant;
import java.time.Period;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import lombok.experimental.UtilityClass;

@UtilityClass
public class IntegrationTestJwtFactory {
  public static final String CLAIM_SCOPE = "scope";
  public static final String CLAIM_BRAND_CODE = "brand_code";
  public static final String CLAIM_CANONICAL_PARTY_ID = "party_id";
  public static final String CLAIM_AUD = "aud";
  public static final String CLAIM_SUB = "sub";
  public static final String CLAIM_SESSION_ID = "sid";
  public static final String CLAIM_SUB_TYPE = "sub_type";
  public static final String SUB_TYPE = "customer";
  public static final String AUDIENCE = "DIGITAL_API";
  public static final String CHANNEL = "channel";

  public static String createJwt(
      final String partyId,
      final String canonicalPartyId,
      final UUID sessionId,
      final String scope,
      final String brandCode,
      final Key signingKey) {
    return createJwt(claimsMap(partyId, canonicalPartyId, sessionId, scope, brandCode), signingKey);
  }

  public static Map<String, Object> claimsMap(
      final String partyId,
      final String canonicalPartyId,
      final UUID sessionId,
      final String scope,
      final String brandCode) {
    return claimsMap(partyId, canonicalPartyId, sessionId.toString(), scope, brandCode);
  }

  public static Map<String, Object> claimsMap(
      final String partyId,
      final String canonicalPartyId,
      final String sessionId,
      final String scope,
      final String brandCode) {
    final Map<String, Object> map = new HashMap<>();
    map.put(CLAIM_SUB, partyId);
    map.put(CLAIM_CANONICAL_PARTY_ID, canonicalPartyId);
    map.put(CLAIM_SESSION_ID, sessionId);
    map.put(CLAIM_SCOPE, scope);
    map.put(CLAIM_BRAND_CODE, brandCode);
    map.put(CLAIM_AUD, AUDIENCE);
    map.put(CLAIM_SUB_TYPE, SUB_TYPE);

    return map;
  }

  public static Map<String, Object> claimsMapWithChannel(
      final String partyId,
      final String canonicalPartyId,
      final String sessionId,
      final String scope,
      final String brandCode,
      final String channel) {
    final Map<String, Object> map = new HashMap<>();
    map.put(CLAIM_SUB, partyId);
    map.put(CLAIM_CANONICAL_PARTY_ID, canonicalPartyId);
    map.put(CLAIM_SESSION_ID, sessionId);
    map.put(CLAIM_SCOPE, scope);
    map.put(CLAIM_BRAND_CODE, brandCode);
    map.put(CLAIM_AUD, AUDIENCE);
    map.put(CLAIM_SUB_TYPE, SUB_TYPE);
    map.put(CHANNEL, channel);

    return map;
  }

  public static String createJwt(final Map<String, Object> claims, final Key signingKey) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .addClaims(claims)
        .signWith(SignatureAlgorithm.RS256, signingKey)
        .compact();
  }
}
