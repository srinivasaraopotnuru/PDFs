package uk.co.ybs.digital.beneficiary.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;

import java.time.LocalDateTime;
import java.util.Collection;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;

@YbsDataJpaTest
class ItInstructionRepositoryTest {
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-07-13T14:56:30");
  private static final long CREDITOR_ACCOUNT_NUMBER = 1001L;
  private static final long DEBTOR_ACCOUNT_NUMBER = 2001L;
  private static final String STATUS = "ACTIVE";

  @Autowired ItInstructionRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @ParameterizedTest
  @CsvSource({"2002,false", "2001,true"})
  void findActiveInternalBeneficiariesShouldFindBeneficiariesWithMatchingDebtorAccount(
      final Long accountNumberLong, final boolean found) {
    final ItInstruction itInstruction = createItInstruction();
    adgCoreTestEntityManager.persistAndFlush(itInstruction);
    adgCoreTestEntityManager.clear();

    final Collection<ItInstruction> instructions =
        testSubject.findActiveInternalBeneficiaries(accountNumberLong, NOW);
    assertThat(instructions, found ? contains(itInstruction) : empty());
  }

  @ParameterizedTest
  @CsvSource({"ONEOFF,false", "CANC,false", "ACTIVE,true"})
  void findActiveInternalBeneficiariesShouldOnlyFindActiveRecords(
      final String status, final boolean found) {
    final ItInstruction itInstruction = createItInstruction().toBuilder().status(status).build();
    adgCoreTestEntityManager.persistAndFlush(itInstruction);
    adgCoreTestEntityManager.clear();

    final Collection<ItInstruction> instructions =
        testSubject.findActiveInternalBeneficiaries(DEBTOR_ACCOUNT_NUMBER, NOW);
    assertThat(instructions, found ? contains(itInstruction) : empty());
  }

  @ParameterizedTest
  @CsvSource({"2020-07-13T14:56:29,false", ",true"})
  void findActiveInternalBeneficiariesShouldOnlyFindRecordsWhereInstructionIsNotEnded(
      final LocalDateTime instructionEndDate, final boolean found) {
    final ItInstruction itInstruction =
        createItInstruction().toBuilder().endDate(instructionEndDate).build();
    adgCoreTestEntityManager.persistAndFlush(itInstruction);
    adgCoreTestEntityManager.clear();

    final Collection<ItInstruction> instructions =
        testSubject.findActiveInternalBeneficiaries(DEBTOR_ACCOUNT_NUMBER, NOW);
    assertThat(instructions, found ? contains(itInstruction) : empty());
  }

  @ParameterizedTest
  @CsvSource({"false,false", "true,true"})
  void findExistingInternalBeneficiariesShouldOnlyFindAvailableAtmRecords(
      final boolean availableAtm, final boolean found) {
    final ItInstruction itInstruction =
        createItInstruction().toBuilder().availableAtm(availableAtm).build();
    adgCoreTestEntityManager.persistAndFlush(itInstruction);
    adgCoreTestEntityManager.clear();

    final Collection<ItInstruction> instructions =
        testSubject.findActiveInternalBeneficiaries(DEBTOR_ACCOUNT_NUMBER, NOW);
    assertThat(instructions, found ? contains(itInstruction) : empty());
  }

  private static ItInstruction createItInstruction() {
    return ItInstruction.builder()
        .sysId(1L)
        .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
        .availableAtm(true)
        .creditorAccountNumber(CREDITOR_ACCOUNT_NUMBER)
        .status(STATUS)
        .build();
  }
}
