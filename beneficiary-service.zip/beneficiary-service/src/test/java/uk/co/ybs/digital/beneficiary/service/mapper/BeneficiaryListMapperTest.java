package uk.co.ybs.digital.beneficiary.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.validation.groups.Default;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.SmartValidator;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExistingBeneficiaryValidationGroup;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@ExtendWith(MockitoExtension.class)
class BeneficiaryListMapperTest {

  public static final String MEMORABLE_NAME = "MemC";
  public static final String NAME_C = "NameC";
  public static final String REFERENCE = "RefC";
  public static final String SORT_CODE_123457 = "123457";
  @InjectMocks private BeneficiaryListMapper testSubject;
  @Mock private ExternalBeneficiaryMapper externalBeneficiaryMapper;
  @Mock private InternalBeneficiaryMapper internalBeneficiaryMapper;
  @Mock private SmartValidator validator;

  @Test
  void mapShouldReturnResult() {
    final BillPaymentInstruction externalInstruction1 = BillPaymentInstruction.builder().build();
    final BillPaymentInstruction externalInstruction2 = BillPaymentInstruction.builder().build();

    final ItInstruction internalInstruction1 = ItInstruction.builder().build();
    final ItInstruction internalInstruction2 = ItInstruction.builder().build();

    final List<BillPaymentInstruction> externalInstructions =
        Arrays.asList(externalInstruction1, externalInstruction2);
    final List<ItInstruction> internalInstructions =
        Arrays.asList(internalInstruction1, internalInstruction2);
    final List<WorkLog> workLogs = new ArrayList<>();

    final ExternalBeneficiary externalBeneficiary1 =
        ExternalBeneficiary.builder().beneficiaryId("beneficiaryIdExternal1").build();
    final ExternalBeneficiary externalBeneficiary2 =
        ExternalBeneficiary.builder().beneficiaryId("beneficiaryIdExternal2").build();

    final InternalBeneficiary internalBeneficiary1 =
        InternalBeneficiary.builder().beneficiaryId("beneficiaryIdInternal1").build();
    final InternalBeneficiary internalBeneficiary2 =
        InternalBeneficiary.builder().beneficiaryId("beneficiaryIdInternal2").build();

    when(externalBeneficiaryMapper.map(same(externalInstruction1), same(workLogs)))
        .thenReturn(externalBeneficiary1);
    when(externalBeneficiaryMapper.map(same(externalInstruction2), same(workLogs)))
        .thenReturn(externalBeneficiary2);

    when(internalBeneficiaryMapper.map(same(internalInstruction1), same(workLogs)))
        .thenReturn(internalBeneficiary1);
    when(internalBeneficiaryMapper.map(same(internalInstruction2), same(workLogs)))
        .thenReturn(internalBeneficiary2);

    final List<Beneficiary> beneficiaries =
        testSubject.map(externalInstructions, internalInstructions, workLogs);

    verify(validator)
        .validate(
            eq(externalBeneficiary1),
            any(),
            eq(Default.class),
            eq(ExistingBeneficiaryValidationGroup.class));
    verify(validator)
        .validate(
            eq(externalBeneficiary2),
            any(),
            eq(Default.class),
            eq(ExistingBeneficiaryValidationGroup.class));
    verify(validator)
        .validate(
            eq(internalBeneficiary1),
            any(),
            eq(Default.class),
            eq(ExistingBeneficiaryValidationGroup.class));
    verify(validator)
        .validate(
            eq(internalBeneficiary2),
            any(),
            eq(Default.class),
            eq(ExistingBeneficiaryValidationGroup.class));

    assertThat(
        beneficiaries,
        is(
            Arrays.asList(
                internalBeneficiary1,
                internalBeneficiary2,
                externalBeneficiary1,
                externalBeneficiary2)));
  }

  @Test
  void mapShouldFilterInvalidBeneficiaries() {
    final BillPaymentInstruction externalInstructionValid =
        BillPaymentInstruction.builder().build();
    final BillPaymentInstruction externalInstructionInvalid =
        BillPaymentInstruction.builder().build();

    final ItInstruction internalInstructionValid = ItInstruction.builder().build();
    final ItInstruction internalInstructionInvalid = ItInstruction.builder().build();

    final List<BillPaymentInstruction> externalInstructions =
        Arrays.asList(externalInstructionValid, externalInstructionInvalid);
    final List<ItInstruction> internalInstructions =
        Arrays.asList(internalInstructionValid, internalInstructionInvalid);
    final List<WorkLog> workLogs = new ArrayList<>();

    final ExternalBeneficiary externalBeneficiaryValid =
        ExternalBeneficiary.builder().beneficiaryId("beneficiaryIdExternalValid").build();
    final ExternalBeneficiary externalBeneficiaryInvalid =
        ExternalBeneficiary.builder().beneficiaryId("beneficiaryIdExternalInvalid").build();

    final InternalBeneficiary internalBeneficiaryValid =
        InternalBeneficiary.builder().beneficiaryId("beneficiaryIdInternalValid").build();
    final InternalBeneficiary internalBeneficiaryInvalid =
        InternalBeneficiary.builder().beneficiaryId("beneficiaryIdInternalInvalid").build();

    when(externalBeneficiaryMapper.map(same(externalInstructionValid), same(workLogs)))
        .thenReturn(externalBeneficiaryValid);
    when(externalBeneficiaryMapper.map(same(externalInstructionInvalid), same(workLogs)))
        .thenReturn(externalBeneficiaryInvalid);

    when(internalBeneficiaryMapper.map(same(internalInstructionValid), same(workLogs)))
        .thenReturn(internalBeneficiaryValid);
    when(internalBeneficiaryMapper.map(same(internalInstructionInvalid), same(workLogs)))
        .thenReturn(internalBeneficiaryInvalid);

    doNothing()
        .when(validator)
        .validate(
            eq(externalBeneficiaryValid),
            any(),
            eq(Default.class),
            eq(ExistingBeneficiaryValidationGroup.class));

    doNothing()
        .when(validator)
        .validate(
            eq(internalBeneficiaryValid),
            any(),
            eq(Default.class),
            eq(ExistingBeneficiaryValidationGroup.class));

    doAnswer(
            invocation -> {
              final BindingResult bindingResult = invocation.getArgument(1);
              bindingResult.addError(new FieldError("beneficiary", "field", "invalid"));
              return null;
            })
        .when(validator)
        .validate(
            eq(externalBeneficiaryInvalid),
            any(),
            eq(Default.class),
            eq(ExistingBeneficiaryValidationGroup.class));

    doAnswer(
            invocation -> {
              final BindingResult bindingResult = invocation.getArgument(1);
              bindingResult.addError(new FieldError("beneficiary", "field", "invalid"));
              return null;
            })
        .when(validator)
        .validate(
            eq(internalBeneficiaryInvalid),
            any(),
            eq(Default.class),
            eq(ExistingBeneficiaryValidationGroup.class));

    final List<Beneficiary> beneficiaries =
        testSubject.map(externalInstructions, internalInstructions, workLogs);

    assertThat(
        beneficiaries, is(Arrays.asList(internalBeneficiaryValid, externalBeneficiaryValid)));
  }

  @Test
  void mapShouldFilterBeneficiariesWithDuplicateIds() {
    final BillPaymentInstruction externalInstruction = BillPaymentInstruction.builder().build();
    final BillPaymentInstruction externalInstructionDuplicate1 =
        BillPaymentInstruction.builder().build();
    final BillPaymentInstruction externalInstructionDuplicate2 =
        BillPaymentInstruction.builder().build();

    final ItInstruction internalInstruction = ItInstruction.builder().build();
    final ItInstruction internalInstructionDuplicate1 = ItInstruction.builder().build();
    final ItInstruction internalInstructionDuplicate2 = ItInstruction.builder().build();

    final List<BillPaymentInstruction> externalInstructions =
        Arrays.asList(
            externalInstruction, externalInstructionDuplicate1, externalInstructionDuplicate2);
    final List<ItInstruction> internalInstructions =
        Arrays.asList(
            internalInstruction, internalInstructionDuplicate1, internalInstructionDuplicate2);
    final List<WorkLog> workLogs = new ArrayList<>();

    final ExternalBeneficiary externalBeneficiary =
        ExternalBeneficiary.builder().beneficiaryId("beneficiaryIdExternal").build();
    final ExternalBeneficiary externalBeneficiaryDuplicate1 =
        ExternalBeneficiary.builder().beneficiaryId("beneficiaryIdExternalDuplicate").build();
    final ExternalBeneficiary externalBeneficiaryDuplicate2 =
        ExternalBeneficiary.builder().beneficiaryId("beneficiaryIdExternalDuplicate").build();

    final InternalBeneficiary internalBeneficiary =
        InternalBeneficiary.builder().beneficiaryId("beneficiaryIdInternal").build();
    final InternalBeneficiary internalBeneficiaryDuplicate1 =
        InternalBeneficiary.builder().beneficiaryId("beneficiaryIdInternalDuplicate").build();
    final InternalBeneficiary internalBeneficiaryDuplicate2 =
        InternalBeneficiary.builder().beneficiaryId("beneficiaryIdInternalDuplicate").build();

    when(externalBeneficiaryMapper.map(same(externalInstruction), same(workLogs)))
        .thenReturn(externalBeneficiary);
    when(externalBeneficiaryMapper.map(same(externalInstructionDuplicate1), same(workLogs)))
        .thenReturn(externalBeneficiaryDuplicate1);
    when(externalBeneficiaryMapper.map(same(externalInstructionDuplicate2), same(workLogs)))
        .thenReturn(externalBeneficiaryDuplicate2);

    when(internalBeneficiaryMapper.map(same(internalInstruction), same(workLogs)))
        .thenReturn(internalBeneficiary);
    when(internalBeneficiaryMapper.map(same(internalInstructionDuplicate1), same(workLogs)))
        .thenReturn(internalBeneficiaryDuplicate1);
    when(internalBeneficiaryMapper.map(same(internalInstructionDuplicate2), same(workLogs)))
        .thenReturn(internalBeneficiaryDuplicate2);

    final List<Beneficiary> beneficiaries =
        testSubject.map(externalInstructions, internalInstructions, workLogs);

    assertThat(beneficiaries, is(Arrays.asList(internalBeneficiary, externalBeneficiary)));
  }

  @Test
  void mapShouldSortResult() {
    class TestContext {
      final List<BillPaymentInstruction> externalBillPaymentInstructions = new ArrayList<>();
      final List<ItInstruction> internalBillPaymentInstructions = new ArrayList<>();
      final List<ExternalBeneficiary> externalBeneficiaries = new ArrayList<>();
      final List<InternalBeneficiary> internalBeneficiaries = new ArrayList<>();

      void stubExternal(
          final String memorableName,
          final String name,
          final String reference,
          final String sortCode,
          final String accountNumber,
          final String beneficiaryId) {
        final BillPaymentInstruction instruction = BillPaymentInstruction.builder().build();
        final ExternalBeneficiary beneficiary =
            ExternalBeneficiary.builder()
                .beneficiaryId(beneficiaryId)
                .accountSortCode(sortCode)
                .accountNumber(accountNumber)
                .reference(reference)
                .name(name)
                .memorableName(memorableName)
                .build();

        when(externalBeneficiaryMapper.map(same(instruction), any())).thenReturn(beneficiary);
        externalBillPaymentInstructions.add(instruction);
        externalBeneficiaries.add(beneficiary);
      }

      void stubInternal(final String accountNumber, final String beneficiaryId) {
        final ItInstruction instruction = ItInstruction.builder().build();
        final InternalBeneficiary beneficiary =
            InternalBeneficiary.builder()
                .beneficiaryId(beneficiaryId)
                .accountNumber(accountNumber)
                .build();

        when(internalBeneficiaryMapper.map(same(instruction), any())).thenReturn(beneficiary);
        internalBillPaymentInstructions.add(instruction);
        internalBeneficiaries.add(beneficiary);
      }
    }

    final TestContext context = new TestContext();
    context.stubInternal(null, "a");
    context.stubInternal("1234567890", "b");
    context.stubInternal("1234567891", "c");
    context.stubExternal(null, null, null, null, null, "d");
    context.stubExternal("MemA", null, null, null, null, "e");
    context.stubExternal("Memb", null, null, null, null, "f");
    context.stubExternal(MEMORABLE_NAME, null, null, null, null, "g");
    context.stubExternal(MEMORABLE_NAME, "NameA", null, null, null, "h");
    context.stubExternal(MEMORABLE_NAME, "Nameb", null, null, null, "i");
    context.stubExternal(MEMORABLE_NAME, NAME_C, null, null, null, "j");
    context.stubExternal(MEMORABLE_NAME, NAME_C, "RefA", null, null, "k");
    context.stubExternal(MEMORABLE_NAME, NAME_C, "Refb", null, null, "l");
    context.stubExternal(MEMORABLE_NAME, NAME_C, REFERENCE, null, null, "m");
    context.stubExternal(MEMORABLE_NAME, NAME_C, REFERENCE, "123456", null, "n");
    context.stubExternal(MEMORABLE_NAME, NAME_C, REFERENCE, SORT_CODE_123457, null, "o");
    context.stubExternal(MEMORABLE_NAME, NAME_C, REFERENCE, SORT_CODE_123457, "12345678", "p");
    context.stubExternal(MEMORABLE_NAME, NAME_C, REFERENCE, SORT_CODE_123457, "12345679", "q");
    context.stubExternal(MEMORABLE_NAME, NAME_C, REFERENCE, SORT_CODE_123457, "12345679", "r");

    final List<BillPaymentInstruction> externalInstructions =
        context.externalBillPaymentInstructions;
    final List<ItInstruction> internalInstructions = context.internalBillPaymentInstructions;
    Collections.shuffle(externalInstructions);
    Collections.shuffle(internalInstructions);

    final List<Beneficiary> beneficiaries =
        testSubject.map(externalInstructions, internalInstructions, Collections.emptyList());

    final List<Beneficiary> expectedBeneficiaries =
        Stream.concat(
                context.internalBeneficiaries.stream(), context.externalBeneficiaries.stream())
            .collect(Collectors.toList());

    assertThat(beneficiaries, is(expectedBeneficiaries));
  }
}
