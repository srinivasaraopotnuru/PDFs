package uk.co.ybs.digital.beneficiary.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;

class ExternalBeneficiaryDatabaseEntityMapperTest {

  private static final String REFERENCE = "the-reference";
  private static final String MEMORABLE_NAME = "the-memorable-name";
  private static final long PAYEE_SORT_CODE = 112233L;
  private static final long PAYEE_ACCOUNT_NUMBER = 12345678L;
  private static final String PAYEE_NAME = "the-payee-name";

  private final ExternalBeneficiaryDatabaseEntityMapper testSubject =
      new ExternalBeneficiaryDatabaseEntityMapper();

  @Test
  void mapShouldReturnExternalBeneficiary() {
    final BillPaymentInstruction instruction =
        buildBillPaymentInstruction(buildNonYbsBankAccount());

    final ExternalBeneficiary beneficiary = testSubject.map(instruction);

    assertThat(
        beneficiary,
        is(
            ExternalBeneficiary.builder()
                .accountSortCode(String.valueOf(PAYEE_SORT_CODE))
                .accountNumber(String.valueOf(PAYEE_ACCOUNT_NUMBER))
                .name(PAYEE_NAME)
                .reference(REFERENCE)
                .memorableName(MEMORABLE_NAME)
                .build()));
  }

  @ParameterizedTest
  @CsvSource({
    "1,000001",
    "11,000011",
    "111,000111",
    "1111,001111",
    "11111,011111",
    "111111,111111"
  })
  void mapShouldLeftPadPayeeSortCode(final long sortCode, final String expectedSortCode) {
    final BillPaymentInstruction instruction =
        buildBillPaymentInstruction(
            buildNonYbsBankAccount().toBuilder().sortCode(sortCode).build());

    final ExternalBeneficiary beneficiary = testSubject.map(instruction);

    assertThat(beneficiary.getAccountSortCode(), is(expectedSortCode));
  }

  @ParameterizedTest
  @CsvSource({
    "1,00000001",
    "11,00000011",
    "111,00000111",
    "1111,00001111",
    "11111,00011111",
    "111111,00111111",
    "1111111,01111111",
    "11111111,11111111"
  })
  void mapShouldLeftPadPayeeAccountNumber(
      final long accountNumber, final String expectedAccountNumber) {
    final BillPaymentInstruction instruction =
        buildBillPaymentInstruction(
            buildNonYbsBankAccount().toBuilder().accountNumber(accountNumber).build());

    final ExternalBeneficiary beneficiary = testSubject.map(instruction);

    assertThat(beneficiary.getAccountNumber(), is(expectedAccountNumber));
  }

  private BillPaymentInstruction buildBillPaymentInstruction(
      final NonYbsBankAccount nonYbsBankAccount) {
    return BillPaymentInstruction.builder()
        .accountNumber(1234567890L)
        .reference(REFERENCE)
        .memorableName(MEMORABLE_NAME)
        .nonYbsBankAccount(nonYbsBankAccount)
        .build();
  }

  private NonYbsBankAccount buildNonYbsBankAccount() {
    return NonYbsBankAccount.builder()
        .sortCode(PAYEE_SORT_CODE)
        .accountNumber(PAYEE_ACCOUNT_NUMBER)
        .name(PAYEE_NAME)
        .build();
  }
}
