package uk.co.ybs.digital.beneficiary.service.audit.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class AuditBeneficiaryViewRequestJsonTest {
  @Autowired private JacksonTester<AuditBeneficiaryViewRequest> tester;

  private AuditBeneficiaryViewRequest request;

  @Value("classpath:api/auditService/request/auditBeneficiary/View/request.json")
  private Resource requestFile;

  @BeforeEach
  void setUp() {
    request =
        AuditBeneficiaryViewRequest.builder()
            .ipAddress("12.66.53.145")
            .beneficiaryInformation(
                AuditBeneficiaryViewRequest.BeneficiaryInformation.builder()
                    .accountNumber("2372146519")
                    .build())
            .build();
  }

  @Test
  void serializes() throws IOException {
    assertThat(tester.write(request)).isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    assertThat(tester.read(requestFile)).isEqualTo(request);
  }
}
