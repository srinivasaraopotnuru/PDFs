package uk.co.ybs.digital.beneficiary;

import static org.exparity.hamcrest.date.LocalDateTimeMatchers.within;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertAll;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DELETED;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.LIMIT_REACHED;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.TECHNICAL;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Status.COMPLETE;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Status.FAILED;
import static uk.co.ybs.digital.beneficiary.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.time.Clock;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.exparity.hamcrest.date.core.TemporalMatcher;
import org.hamcrest.Matcher;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.beneficiary.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.beneficiary.e2e.CoreHelper;
import uk.co.ybs.digital.beneficiary.e2e.TestData;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryProcessorService;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiarySuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@SpringBootTest(classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
@SuppressWarnings("Convert2MethodRef")
public class BeneficiaryProcessorServiceIT {

  private static final String NEW_MEMORABLE_NAME = "NEW MEM";

  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String PARTY_ID = "1234567890";
  private static final String BRAND_CODE = "YBS";
  private static final InetSocketAddress HOST = InetSocketAddress.createUnresolved("host", 443);
  private static final UUID REQUEST_ID = UUID.fromString("3cfa397f-ff5d-4252-b8f0-69daac23fba4");
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final int BENEFICIARIES_EXTERNAL_LIMIT = 10;
  private static final int BENEFICIARIES_INTERNAL_LIMIT = 4;

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  public static final String CREATED_DATE = "createdDate";
  public static final String START_DATE = "startDate";
  public static final String SYS_ID = "sysId";
  public static final String ENDED_AT_0795 = "0795";
  public static final String SAPP = "SAPP";
  public static final String END_DATE = "endDate";
  public static final String ENDED_DATE = "endedDate";

  @Autowired private BeneficiaryProcessorService beneficiaryProcessorService;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  private MockWebServer mockAuditService;

  @Autowired private TransactionTemplate transactionTemplate;
  @Autowired private TestEntityManager coreTestEntityManager;
  @Autowired private TestEntityManager digitalBeneficiaryTestEntityManager;
  @Autowired private ObjectMapper objectMapper;
  @Autowired private Clock clock;

  private CoreHelper coreHelper;

  @BeforeEach
  void setup() throws Exception {
    mockAuditService = new MockWebServer();
    mockAuditService.start(auditTestPort);
    coreHelper = new CoreHelper(transactionTemplate, coreTestEntityManager);
  }

  @AfterEach
  void cleanup() throws IOException {
    mockAuditService.shutdown();
    tearDownDb();
  }

  @Test
  void beneficiaryProcessorShouldDoNothingWhenNoRequestsPending() {
    beneficiaryProcessorService.process();
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldRecordFailureWhenExternalBeneficiaryAlreadyExists(
      final boolean auditFailed) {
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.CREATE, beneficiary, null, BENEFICIARIES_EXTERNAL_LIMIT);

    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            123456L,
            coreHelper.setupFinancialInstitution(123456L),
            false);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () -> assertBillPaymentInstructions(samePropertyValuesAs(instruction)),
        () -> assertItInstructions(),
        () -> assertAuditBeneficiaryCreateFailure(beneficiary, DUPLICATE, true));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldRecordFailureWhenInternalBeneficiaryAlreadyExists(
      final boolean auditFailed) {
    final InternalBeneficiary beneficiary = createInternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.CREATE, beneficiary, null, BENEFICIARIES_INTERNAL_LIMIT);

    final ItInstruction instruction =
        coreHelper.setupExistingInternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.INTERNAL_ACCOUNT_NUMBER),
            false);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () -> assertBillPaymentInstructions(),
        () -> assertItInstructions(samePropertyValuesAs(instruction)),
        () -> assertAuditBeneficiaryCreateFailure(beneficiary, DUPLICATE, false));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldFailWhenExternalBeneficiaryLimitExceeded(
      final boolean auditFailed) {
    beneficiaryProcessorShouldFailWhenExternalBeneficiaryLimitExceeded(
        BENEFICIARIES_EXTERNAL_LIMIT, BENEFICIARIES_EXTERNAL_LIMIT, auditFailed);
  }

  private void beneficiaryProcessorShouldFailWhenExternalBeneficiaryLimitExceeded(
      final Integer beneficiariesLimit,
      final int existingBeneficiaries,
      final boolean auditFailed) {
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(WorkLog.Operation.CREATE, beneficiary, null, beneficiariesLimit);

    final FinancialInstitution financialInstitution =
        coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE));
    final long firstCreditorAccountNumber = Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER) + 1;
    final List<BillPaymentInstruction> instructions =
        setupExistingExternalBeneficiaries(
            existingBeneficiaries, firstCreditorAccountNumber, financialInstitution);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    final Matcher<?>[] matchers =
        toSamePropertyValuesAsStream(instructions).toArray(Matcher[]::new);

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () -> assertBillPaymentInstructions(matchers),
        () -> assertItInstructions(),
        () -> assertAuditBeneficiaryCreateFailure(beneficiary, LIMIT_REACHED, true));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldFailWhenInternalBeneficiaryLimitExceeded(
      final boolean auditFailed) {
    beneficiaryProcessorShouldFailWhenInternalBeneficiaryLimitExceeded(
        BENEFICIARIES_INTERNAL_LIMIT, BENEFICIARIES_INTERNAL_LIMIT, auditFailed);
  }

  private void beneficiaryProcessorShouldFailWhenInternalBeneficiaryLimitExceeded(
      final Integer beneficiariesLimit,
      final int existingBeneficiaries,
      final boolean auditFailed) {
    final InternalBeneficiary beneficiary = createInternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(WorkLog.Operation.CREATE, beneficiary, null, beneficiariesLimit);

    final long firstCreditorAccountNumber = Long.parseLong(TestData.INTERNAL_ACCOUNT_NUMBER) + 1;
    final List<ItInstruction> instructions =
        setupExistingInternalBeneficiaries(existingBeneficiaries, firstCreditorAccountNumber);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    final Matcher<?>[] matchers =
        toSamePropertyValuesAsStream(instructions).toArray(Matcher[]::new);

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () -> assertBillPaymentInstructions(),
        () -> assertItInstructions(matchers),
        () -> assertAuditBeneficiaryCreateFailure(beneficiary, LIMIT_REACHED, false));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldRecordFailureWhenFinancialInstitutionDoesNotExist(
      final boolean auditFailed) {
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.CREATE, beneficiary, null, BENEFICIARIES_EXTERNAL_LIMIT);
    coreHelper.setupFinancialInstitution(112233L);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () -> assertBillPaymentInstructions(),
        () -> assertItInstructions(),
        () -> assertAuditBeneficiaryCreateFailure(beneficiary, TECHNICAL, true));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldSuccessfullyProcessCreateExternalPendingRequest(
      final boolean auditFailed) {
    beneficiaryProcessorShouldSuccessfullyProcessCreateExternalPendingRequest(
        BENEFICIARIES_EXTERNAL_LIMIT, BENEFICIARIES_EXTERNAL_LIMIT - 1, auditFailed);
  }

  private void beneficiaryProcessorShouldSuccessfullyProcessCreateExternalPendingRequest(
      final Integer beneficiariesLimit,
      final int existingBeneficiaries,
      final boolean auditFailed) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(WorkLog.Operation.CREATE, beneficiary, null, beneficiariesLimit);

    final FinancialInstitution financialInstitution =
        coreHelper.setupFinancialInstitution(Long.parseLong(TestData.SORT_CODE));
    final long firstCreditorAccountNumber = Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER) + 1;
    final List<BillPaymentInstruction> instructions =
        setupExistingExternalBeneficiaries(
            existingBeneficiaries, firstCreditorAccountNumber, financialInstitution);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    final NonYbsBankAccount bankAccount =
        coreHelper.createNonYbsBankAccount(
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER), financialInstitution);
    final BillPaymentInstruction instruction =
        coreHelper.createBillPaymentInstruction(TestData.DEBTOR_ACCOUNT_NUMBER, bankAccount, false);

    beneficiaryProcessorService.process();

    final Matcher<?>[] matchers =
        Stream.concat(
                toSamePropertyValuesAsStream(instructions),
                Stream.of(
                    allOf(
                        samePropertyValuesAs(
                            instruction, SYS_ID, "nonYbsBankAccount", START_DATE, CREATED_DATE),
                        hasProperty(SYS_ID, notNullValue()),
                        hasProperty("nonYbsBankAccount", samePropertyValuesAs(bankAccount, SYS_ID)),
                        hasProperty(START_DATE, withinTenSecondsOf(now)),
                        hasProperty(CREATED_DATE, withinTenSecondsOf(now)))))
            .toArray(Matcher[]::new);

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, COMPLETE),
        () -> assertBillPaymentInstructions(matchers),
        () -> assertItInstructions(),
        () -> assertAuditBeneficiaryCreateSuccess(beneficiary, true));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldSuccessfullyProcessCreateInternalPendingRequest(
      final boolean auditFailed) {
    beneficiaryProcessorShouldSuccessfullyProcessCreateInternalPendingRequest(
        BENEFICIARIES_INTERNAL_LIMIT, BENEFICIARIES_INTERNAL_LIMIT - 1, auditFailed);
  }

  private void beneficiaryProcessorShouldSuccessfullyProcessCreateInternalPendingRequest(
      final Integer beneficiariesLimit,
      final int existingBeneficiaries,
      final boolean auditFailed) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final InternalBeneficiary beneficiary = createInternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(WorkLog.Operation.CREATE, beneficiary, null, beneficiariesLimit);

    final long firstCreditorAccountNumber = Long.parseLong(TestData.INTERNAL_ACCOUNT_NUMBER) + 1;
    final List<ItInstruction> instructions =
        setupExistingInternalBeneficiaries(existingBeneficiaries, firstCreditorAccountNumber);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    final ItInstruction instruction =
        coreHelper.createItInstruction(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.INTERNAL_ACCOUNT_NUMBER),
            false);

    beneficiaryProcessorService.process();

    final Matcher<?>[] matchers =
        Stream.concat(
                toSamePropertyValuesAsStream(instructions),
                Stream.of(
                    allOf(
                        samePropertyValuesAs(instruction, SYS_ID, START_DATE, CREATED_DATE),
                        hasProperty(SYS_ID, notNullValue()),
                        hasProperty(START_DATE, withinTenSecondsOf(now)),
                        hasProperty(CREATED_DATE, withinTenSecondsOf(now)))))
            .toArray(Matcher[]::new);

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, COMPLETE),
        () -> assertBillPaymentInstructions(),
        () -> assertItInstructions(matchers),
        () -> assertAuditBeneficiaryCreateSuccess(beneficiary, false));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldRecordFailureWhenUpdateExternalBeneficiaryIsDeleted(
      final boolean auditFailed) {
    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            123456L,
            coreHelper.setupFinancialInstitution(123456L),
            true);
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.UPDATE, beneficiary, instruction.getSysId(), null);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () -> assertBillPaymentInstructions(samePropertyValuesAs(instruction)),
        () -> assertItInstructions(),
        () -> assertAuditBeneficiaryUpdateFailure(beneficiary, instruction, "Beneficiary Deleted"));
  }

  /*
   * FIXME - This test doesn't currently make a huge amount of sense, as it sets up a beneficiary which is already a
   *  duplicate. We've disabled updates of reference until Active Data Guard is available. When reference updates
   *  are possible this test can be changed to setup two beneficiaries which are the same but have different
   *  references, and then attempt to process a request to update one of the references to create a duplicate.
   */
  @Test
  void beneficiaryProcessorShouldRecordFailureWhenUpdateExternalBeneficiaryIsDuplicate() {
    final FinancialInstitution financialInstitution = coreHelper.setupFinancialInstitution(123456L);
    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            123456L,
            financialInstitution,
            false);
    final BillPaymentInstruction existingDuplicateInstruction =
        coreHelper.setupExistingExternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            123456L,
            financialInstitution,
            false);
    final ExternalBeneficiary beneficiary =
        createExternalBeneficiary().toBuilder().memorableName(NEW_MEMORABLE_NAME).build();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.UPDATE, beneficiary, instruction.getSysId(), null);

    mockAuditServiceResponse();

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () ->
            assertBillPaymentInstructions(
                samePropertyValuesAs(instruction),
                samePropertyValuesAs(existingDuplicateInstruction)),
        () -> assertItInstructions(),
        () ->
            assertAuditBeneficiaryUpdateFailure(beneficiary, instruction, "Duplicate Beneficiary"));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldSuccessfullyProcessUpdateExternalPendingRequest(
      final boolean auditFailed) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final BillPaymentInstruction originalInstruction =
        coreHelper.setupExistingExternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            123456L,
            coreHelper.setupFinancialInstitution(123456L),
            false);
    final ExternalBeneficiary beneficiary =
        createExternalBeneficiary().toBuilder().memorableName(NEW_MEMORABLE_NAME).build();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.UPDATE, beneficiary, originalInstruction.getSysId(), null);

    final BillPaymentInstruction expectedEndedInstruction =
        originalInstruction
            .toBuilder()
            .endedAt(ENDED_AT_0795)
            .endedBy(SAPP)
            .status("CANC")
            .atmOrderNumber(null)
            .build();

    final BillPaymentInstruction expectedNewInstruction =
        originalInstruction
            .toBuilder()
            .memorableName(NEW_MEMORABLE_NAME)
            .status("ACTIVE")
            .availableAtm(true)
            .fpTrustStatus(true)
            .fpChangeReason("OOBAD")
            .createdAt(ENDED_AT_0795)
            .createdBy(SAPP)
            .build();

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, COMPLETE),
        () ->
            assertBillPaymentInstructions(
                allOf(
                    samePropertyValuesAs(expectedEndedInstruction, END_DATE, ENDED_DATE),
                    hasProperty(END_DATE, withinTenSecondsOf(now)),
                    hasProperty(ENDED_DATE, withinTenSecondsOf(now))),
                allOf(
                    samePropertyValuesAs(expectedNewInstruction, SYS_ID, CREATED_DATE),
                    hasProperty(SYS_ID, notNullValue()),
                    hasProperty(CREATED_DATE, withinTenSecondsOf(now)))),
        () -> assertItInstructions(),
        () -> assertAuditBeneficiaryUpdateSuccess(beneficiary, originalInstruction));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldRecordFailureWhenDeleteExternalBeneficiaryIsDeleted(
      final boolean auditFailed) {
    final BillPaymentInstruction instruction =
        coreHelper.setupExistingExternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            123456L,
            coreHelper.setupFinancialInstitution(123456L),
            true);
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.DELETE, beneficiary, instruction.getSysId(), null);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () -> assertBillPaymentInstructions(samePropertyValuesAs(instruction)),
        () -> assertItInstructions(),
        () -> assertAuditBeneficiaryDeleteFailure(beneficiary, DELETED, true));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldRecordFailureWhenDeleteInternalBeneficiaryIsDeleted(
      final boolean auditFailed) {
    final ItInstruction instruction =
        coreHelper.setupExistingInternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER, Long.parseLong(TestData.INTERNAL_ACCOUNT_NUMBER), true);
    final InternalBeneficiary beneficiary = createInternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.DELETE, beneficiary, instruction.getSysId(), null);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, FAILED),
        () -> assertBillPaymentInstructions(),
        () -> assertItInstructions(samePropertyValuesAs(instruction)),
        () -> assertAuditBeneficiaryDeleteFailure(beneficiary, DELETED, false));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldSuccessfullyProcessExternalDeletePendingRequest(
      final boolean auditFailed) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final BillPaymentInstruction originalInstruction =
        coreHelper.setupExistingExternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.EXTERNAL_ACCOUNT_NUMBER),
            123456L,
            coreHelper.setupFinancialInstitution(123456L),
            false);
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.DELETE, beneficiary, originalInstruction.getSysId(), null);

    final BillPaymentInstruction expectedInstruction =
        originalInstruction
            .toBuilder()
            .endedAt(ENDED_AT_0795)
            .endedBy(SAPP)
            .status("CANC")
            .atmOrderNumber(null)
            .build();

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, COMPLETE),
        () ->
            assertBillPaymentInstructions(
                allOf(
                    samePropertyValuesAs(expectedInstruction, END_DATE, ENDED_DATE),
                    hasProperty(END_DATE, withinTenSecondsOf(now)),
                    hasProperty(ENDED_DATE, withinTenSecondsOf(now)))),
        () -> assertItInstructions(),
        () -> assertAuditBeneficiaryDeleteSuccess(beneficiary, true));
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void beneficiaryProcessorShouldSuccessfullyProcessInternalDeletePendingRequest(
      final boolean auditFailed) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final ItInstruction originalInstruction =
        coreHelper.setupExistingInternalBeneficiary(
            TestData.DEBTOR_ACCOUNT_NUMBER,
            Long.parseLong(TestData.INTERNAL_ACCOUNT_NUMBER),
            false);
    final InternalBeneficiary beneficiary = createInternalBeneficiary();
    final Long beneficiaryRequestId =
        setupBeneficiaryRequest(
            WorkLog.Operation.DELETE, beneficiary, originalInstruction.getSysId(), null);

    final ItInstruction expectedInstruction =
        originalInstruction.toBuilder().endedAt(ENDED_AT_0795).endedBy(SAPP).status("CANC").build();

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    beneficiaryProcessorService.process();

    assertAll(
        () -> assertUpdateLog(beneficiaryRequestId, COMPLETE),
        () -> assertBillPaymentInstructions(),
        () ->
            assertItInstructions(
                allOf(
                    samePropertyValuesAs(expectedInstruction, END_DATE, ENDED_DATE),
                    hasProperty(END_DATE, withinTenSecondsOf(now)),
                    hasProperty(ENDED_DATE, withinTenSecondsOf(now)))),
        () -> assertAuditBeneficiaryDeleteSuccess(beneficiary, false));
  }

  private TemporalMatcher<LocalDateTime> withinTenSecondsOf(final LocalDateTime time) {
    return within(10, ChronoUnit.SECONDS, time);
  }

  private void mockAuditServiceResponse() {
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  private void mockAuditServiceFailureResponse() {
    mockAuditService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.UNAUTHORIZED.value())
            .setBody(
                readClassPathResource("api/auditService/response/errorResponseUnauthorized.json")));
  }

  private void assertAuditBeneficiaryCreateFailure(
      final Beneficiary beneficiary,
      final BeneficiaryValidationExceptionReason reason,
      final boolean isExternal)
      throws InterruptedException, JsonProcessingException {
    assertAuditBeneficiaryFailure(
        beneficiary, reason, isExternal, "/audit/beneficiary/create/failure");
  }

  private void assertAuditBeneficiaryDeleteFailure(
      final Beneficiary beneficiary,
      final BeneficiaryValidationExceptionReason reason,
      final boolean isExternal)
      throws InterruptedException, JsonProcessingException {
    assertAuditBeneficiaryFailure(
        beneficiary, reason, isExternal, "/audit/beneficiary/delete/failure");
  }

  private void assertAuditBeneficiaryFailure(
      final Beneficiary beneficiary,
      final BeneficiaryValidationExceptionReason reason,
      final boolean isExternal,
      final String path)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest(path);

    if (isExternal) {
      assertExternalBeneficiaryAuditFailure(request, (ExternalBeneficiary) beneficiary, reason);
    } else {
      assertInternalBeneficiaryAuditFailure(request, (InternalBeneficiary) beneficiary, reason);
    }
  }

  private void assertExternalBeneficiaryAuditFailure(
      final RecordedRequest request,
      final ExternalBeneficiary beneficiary,
      final BeneficiaryValidationExceptionReason reason)
      throws JsonProcessingException {
    final AuditBeneficiaryFailureRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiaryFailureRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiaryFailureRequest.builder()
                .ipAddress(IP_ADDRESS)
                .message(reason.getDescription())
                .beneficiaryInformation(
                    ExternalBeneficiaryInformation.builder()
                        .memorableName(beneficiary.getMemorableName())
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .reference(beneficiary.getReference())
                        .payeeSortCode(beneficiary.getAccountSortCode())
                        .payeeName(beneficiary.getName())
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .build())
                .build()));
  }

  private void assertInternalBeneficiaryAuditFailure(
      final RecordedRequest request,
      final InternalBeneficiary beneficiary,
      final BeneficiaryValidationExceptionReason reason)
      throws JsonProcessingException {
    final AuditBeneficiaryFailureRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiaryFailureRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiaryFailureRequest.builder()
                .ipAddress(IP_ADDRESS)
                .message(reason.getDescription())
                .beneficiaryInformation(
                    InternalBeneficiaryInformation.builder()
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .build())
                .build()));
  }

  private void assertAuditBeneficiaryCreateSuccess(
      final Beneficiary beneficiary, final boolean isExternal)
      throws InterruptedException, JsonProcessingException {
    assertAuditBeneficiarySuccess(beneficiary, isExternal, "/audit/beneficiary/create/success");
  }

  private void assertAuditBeneficiaryDeleteSuccess(
      final Beneficiary beneficiary, final boolean isExternal)
      throws InterruptedException, JsonProcessingException {
    assertAuditBeneficiarySuccess(beneficiary, isExternal, "/audit/beneficiary/delete/success");
  }

  private void assertAuditBeneficiarySuccess(
      final Beneficiary beneficiary, final boolean isExternal, final String path)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest(path);

    if (isExternal) {
      assertExternalBeneficiaryAuditSuccess(request, (ExternalBeneficiary) beneficiary);
    } else {
      assertInternalBeneficiaryAuditSuccess(request, (InternalBeneficiary) beneficiary);
    }
  }

  private void assertExternalBeneficiaryAuditSuccess(
      final RecordedRequest request, final ExternalBeneficiary beneficiary)
      throws JsonProcessingException {
    final AuditBeneficiarySuccessRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiarySuccessRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiarySuccessRequest.builder()
                .ipAddress(IP_ADDRESS)
                .beneficiaryInformation(
                    ExternalBeneficiaryInformation.builder()
                        .memorableName(beneficiary.getMemorableName())
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .reference(beneficiary.getReference())
                        .payeeSortCode(beneficiary.getAccountSortCode())
                        .payeeName(beneficiary.getName())
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .build())
                .build()));
  }

  private void assertInternalBeneficiaryAuditSuccess(
      final RecordedRequest request, final InternalBeneficiary beneficiary)
      throws JsonProcessingException {
    final AuditBeneficiarySuccessRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiarySuccessRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiarySuccessRequest.builder()
                .ipAddress(IP_ADDRESS)
                .beneficiaryInformation(
                    InternalBeneficiaryInformation.builder()
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .build())
                .build()));
  }

  private void assertAuditBeneficiaryUpdateSuccess(
      final ExternalBeneficiary beneficiary, final BillPaymentInstruction originalInstruction)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest("/audit/beneficiary/update/success");
    final AuditBeneficiaryUpdateSuccessRequest actual =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditBeneficiaryUpdateSuccessRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiaryUpdateSuccessRequest.builder()
                .ipAddress(IP_ADDRESS)
                .beneficiaryInformation(
                    ExternalBeneficiaryInformation.builder()
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .payeeSortCode(beneficiary.getAccountSortCode())
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .payeeName(beneficiary.getName())
                        .reference(originalInstruction.getReference())
                        .memorableName(originalInstruction.getMemorableName())
                        .build())
                .updateBeneficiaryInformation(
                    ExternalUpdateBeneficiaryInformation.builder()
                        .reference(beneficiary.getReference())
                        .memorableName(beneficiary.getMemorableName())
                        .build())
                .build()));
  }

  private void assertAuditBeneficiaryUpdateFailure(
      final ExternalBeneficiary beneficiary,
      final BillPaymentInstruction originalInstruction,
      final String errorMessage)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest("/audit/beneficiary/update/failure");
    final AuditBeneficiaryUpdateFailureRequest actual =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditBeneficiaryUpdateFailureRequest.class);

    assertThat(
        actual,
        is(
            AuditBeneficiaryUpdateFailureRequest.builder()
                .ipAddress(IP_ADDRESS)
                .message(errorMessage)
                .beneficiaryInformation(
                    ExternalBeneficiaryInformation.builder()
                        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER_STRING)
                        .payeeSortCode(beneficiary.getAccountSortCode())
                        .payeeAccountNumber(beneficiary.getAccountNumber())
                        .payeeName(beneficiary.getName())
                        .reference(originalInstruction.getReference())
                        .memorableName(originalInstruction.getMemorableName())
                        .build())
                .updateBeneficiaryInformation(
                    ExternalUpdateBeneficiaryInformation.builder()
                        .reference(beneficiary.getReference())
                        .memorableName(beneficiary.getMemorableName())
                        .build())
                .build()));
  }

  private RecordedRequest assertAuditRequest(final String path) throws InterruptedException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());
    return request;
  }

  private void assertUpdateLog(
      final long beneficiaryRequestId, final WorkLog.Status updateLogStatus) {
    final WorkLog workLog =
        transactionTemplate.execute(
            status ->
                digitalBeneficiaryTestEntityManager.find(WorkLog.class, beneficiaryRequestId));
    assertThat(workLog, is(notNullValue()));
    assertThat(workLog.getStatus(), is(updateLogStatus));
  }

  private void assertBillPaymentInstructions(final Matcher<?>... expected) {
    assertEntities("BillPaymentInstruction", expected);
  }

  private void assertItInstructions(final Matcher<?>... expected) {
    assertEntities("ItInstruction", expected);
  }

  @SuppressWarnings("unchecked")
  private void assertEntities(final String table, final Matcher<?>[] expected) {
    final List<?> actual =
        transactionTemplate.execute(
            transactionStatus -> {
              final Query query =
                  coreTestEntityManager
                      .getEntityManager()
                      .createQuery("select e from " + table + " e");
              return query.getResultList();
            });
    assertThat(actual, containsInAnyOrder((Matcher<Object>[]) expected));
  }

  private Long setupBeneficiaryRequest(
      final Operation operation,
      final Beneficiary beneficiary,
      final Long sysId,
      final Integer beneficiariesLimit) {
    return transactionTemplate.execute(
        status ->
            digitalBeneficiaryTestEntityManager.persistAndGetId(
                createWorkLog(operation, beneficiary, sysId, beneficiariesLimit), Long.class));
  }

  private List<BillPaymentInstruction> setupExistingExternalBeneficiaries(
      final int number,
      final long firstCreditorAccountNumber,
      final FinancialInstitution financialInstitution) {
    return IntStream.range(0, number)
        .mapToObj(
            i ->
                coreHelper.setupExistingExternalBeneficiary(
                    TestData.DEBTOR_ACCOUNT_NUMBER,
                    firstCreditorAccountNumber + i,
                    Long.parseLong(TestData.SORT_CODE),
                    financialInstitution,
                    false))
        .collect(Collectors.toList());
  }

  private List<ItInstruction> setupExistingInternalBeneficiaries(
      final int number, final long firstCreditorAccountNumber) {
    return IntStream.range(0, number)
        .mapToObj(
            i ->
                coreHelper.setupExistingInternalBeneficiary(
                    TestData.DEBTOR_ACCOUNT_NUMBER, firstCreditorAccountNumber + i, false))
        .collect(Collectors.toList());
  }

  private Stream<Matcher<?>> toSamePropertyValuesAsStream(final List<?> objects) {
    return objects.stream().map(Matchers::samePropertyValuesAs);
  }

  private static ExternalBeneficiary createExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .accountNumber(TestData.EXTERNAL_ACCOUNT_NUMBER)
        .accountSortCode(TestData.SORT_CODE)
        .memorableName(TestData.MEMORABLE_NAME)
        .name(TestData.NAME)
        .reference(TestData.REFERENCE)
        .build();
  }

  private static InternalBeneficiary createInternalBeneficiary() {
    return InternalBeneficiary.builder().accountNumber(TestData.INTERNAL_ACCOUNT_NUMBER).build();
  }

  private static WorkLog createWorkLog(
      final Operation operation,
      final Beneficiary beneficiary,
      final Long sysId,
      final Integer beneficiariesLimit) {
    return WorkLog.builder()
        .accountNumber(TestData.DEBTOR_ACCOUNT_NUMBER)
        .status(WorkLog.Status.PENDING)
        .operation(operation)
        .message(
            BeneficiaryRequest.builder()
                .payload(
                    BeneficiaryRequest.Payload.builder()
                        .sysId(sysId)
                        .beneficiary(beneficiary)
                        .beneficiariesLimit(beneficiariesLimit)
                        .build())
                .metadata(
                    RequestMetadata.builder()
                        .requestId(REQUEST_ID)
                        .sessionId(SESSION_ID)
                        .ipAddress(IP_ADDRESS)
                        .forwardingAuth(FORWARDING_AUTH)
                        .partyId(PARTY_ID)
                        .brandCode(BRAND_CODE)
                        .host(HOST)
                        .build())
                .build())
        .build();
  }

  private void tearDownDb() {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager digitalAccountEntityManager =
              digitalBeneficiaryTestEntityManager.getEntityManager();
          digitalAccountEntityManager.createQuery("delete from WorkLog").executeUpdate();
        });

    coreHelper.clearDb();
  }
}
