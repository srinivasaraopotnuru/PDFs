package uk.co.ybs.digital.beneficiary.service.audit.dto;

import static org.assertj.core.api.Assertions.assertThat;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.TECHNICAL;

import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class AuditBeneficiaryFailureRequestJsonTest {
  @Autowired private JacksonTester<AuditBeneficiaryFailureRequest> tester;

  private AuditBeneficiaryFailureRequest externalRequest;
  private AuditBeneficiaryFailureRequest internalRequest;

  @Value(
      "classpath:api/auditService/request/auditBeneficiary/CreateDelete/externalFailureRequest.json")
  private Resource externalRequestFile;

  @Value(
      "classpath:api/auditService/request/auditBeneficiary/CreateDelete/internalFailureRequest.json")
  private Resource internalRequestFile;

  @BeforeEach
  void setUp() {
    externalRequest =
        AuditBeneficiaryFailureRequest.builder()
            .ipAddress("12.66.53.145")
            .message(DUPLICATE.getDescription())
            .beneficiaryInformation(
                ExternalBeneficiaryInformation.builder()
                    .payeeName("Mr Test")
                    .payeeSortCode("112233")
                    .reference("Ref")
                    .memorableName("Memorable")
                    .payeeAccountNumber("12345678")
                    .accountNumber("2372146519")
                    .build())
            .build();

    internalRequest =
        AuditBeneficiaryFailureRequest.builder()
            .ipAddress("12.66.53.145")
            .message(TECHNICAL.getDescription())
            .beneficiaryInformation(
                InternalBeneficiaryInformation.builder()
                    .payeeAccountNumber("1234567890")
                    .accountNumber("2372146519")
                    .build())
            .build();
  }

  @Test
  void canSerializeExternalCreateBeneficiaryFailureRequest() throws IOException {
    assertThat(tester.write(externalRequest))
        .isEqualToJson(externalRequestFile, JSONCompareMode.STRICT);
  }

  @Test
  void canDeserializeExternalCreateBeneficiaryFailureRequest() throws IOException {
    assertThat(tester.read(externalRequestFile)).isEqualTo(externalRequest);
  }

  @Test
  void canSerializeInternalCreateBeneficiaryFailureRequest() throws IOException {
    assertThat(tester.write(internalRequest))
        .isEqualToJson(internalRequestFile, JSONCompareMode.STRICT);
  }

  @Test
  void canDeserializeInternalCreateBeneficiaryFailureRequest() throws IOException {
    assertThat(tester.read(internalRequestFile)).isEqualTo(internalRequest);
  }
}
