package uk.co.ybs.digital.beneficiary.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@ExtendWith(MockitoExtension.class)
class BeneficiaryIdGeneratorTest {

  @InjectMocks private BeneficiaryIdGenerator testSubject;
  @Mock private ObjectMapper objectMapper;

  @ParameterizedTest
  @MethodSource("beneficiaryTypes")
  void shouldGenerateId(final Class<? extends Beneficiary> type, final String typeName)
      throws JsonProcessingException {
    final BeneficiaryIdGenerator.BeneficiaryIdPayload expectedPayload =
        BeneficiaryIdGenerator.BeneficiaryIdPayload.builder().type(typeName).sysId(1L).build();

    when(objectMapper.writeValueAsString(expectedPayload)).thenReturn("beneficiaryId");

    final String beneficiaryId = testSubject.generateId(type, 1L);
    assertThat(
        beneficiaryId, is("fd40049946d56183b770f45dec148d3c78014457b4b23113fa8d92eedc9f6e04"));
  }

  private static Stream<Arguments> beneficiaryTypes() {
    return Stream.of(
        arguments(ExternalBeneficiary.class, "ExternalBeneficiary"),
        arguments(InternalBeneficiary.class, "InternalBeneficiary"));
  }

  @Test
  void shouldWrapJsonProcessingExceptionInRuntimeException() throws JsonProcessingException {
    final JsonProcessingException expectedException = new JsonProcessingException("") {};
    when(objectMapper.writeValueAsString(any())).thenThrow(expectedException);

    final RuntimeException exception =
        assertThrows(
            RuntimeException.class, () -> testSubject.generateId(ExternalBeneficiary.class, 1L));

    assertThat(exception.getMessage(), is("Unexpected exception generating json"));
    assertThat(exception.getCause(), sameInstance(expectedException));
  }
}
