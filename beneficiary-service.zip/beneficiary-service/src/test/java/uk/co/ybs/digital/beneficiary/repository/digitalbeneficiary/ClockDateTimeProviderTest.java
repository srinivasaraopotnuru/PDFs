package uk.co.ybs.digital.beneficiary.repository.digitalbeneficiary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.TemporalAccessor;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.ClockDateTimeProvider;

class ClockDateTimeProviderTest {
  private ClockDateTimeProvider testSubject;

  @BeforeEach
  void beforeEach() {
    Clock clock = Clock.fixed(Instant.parse("2020-04-27T12:00:00Z"), ZoneId.of("Europe/London"));
    testSubject = new ClockDateTimeProvider(clock);
  }

  @Test
  void getNowShouldReturnCurrentLocalDateTime() {
    final Optional<TemporalAccessor> actual = testSubject.getNow();

    // Should be in UK time
    assertThat(actual.isPresent(), is(true));
    assertThat(actual.get(), is(LocalDateTime.parse("2020-04-27T13:00:00")));
  }
}
