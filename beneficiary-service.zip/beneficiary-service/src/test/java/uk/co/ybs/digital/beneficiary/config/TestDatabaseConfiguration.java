package uk.co.ybs.digital.beneficiary.config;

import javax.persistence.EntityManagerFactory;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

@TestConfiguration
public class TestDatabaseConfiguration {
  @Bean
  public TransactionTemplate transactionTemplate(
      final PlatformTransactionManager adgCoreTransactionManager,
      final PlatformTransactionManager coreTransactionManager,
      final PlatformTransactionManager digitalBeneficiaryTransactionManager) {
    final ChainedTransactionManager chainedTransactionManager =
        new ChainedTransactionManager(
            adgCoreTransactionManager,
            coreTransactionManager,
            digitalBeneficiaryTransactionManager);
    return new TransactionTemplate(chainedTransactionManager);
  }

  @Bean
  public TestEntityManager adgCoreTestEntityManager(
      final EntityManagerFactory adgCoreEntityManagerFactory) {
    return new TestEntityManager(adgCoreEntityManagerFactory);
  }

  @Bean
  public TestEntityManager digitalBeneficiaryTestEntityManager(
      final EntityManagerFactory digitalBeneficiaryEntityManagerFactory) {
    return new TestEntityManager(digitalBeneficiaryEntityManagerFactory);
  }

  @Bean
  public TestEntityManager coreTestEntityManager(
      final EntityManagerFactory coreEntityManagerFactory) {
    return new TestEntityManager(coreEntityManagerFactory);
  }
}
