package uk.co.ybs.digital.beneficiary.service.utilities;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.google.common.collect.Sets;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.model.adgcore.AccountActivityGroup;
import uk.co.ybs.digital.beneficiary.model.adgcore.SavingProduct;
import uk.co.ybs.digital.beneficiary.repository.adgcore.ActivityPlayerRepository;
import uk.co.ybs.digital.beneficiary.repository.adgcore.SavingProductRepository;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class AccountAccessValidatorTest {

  private static final Long PARTY_ID = 123456L;
  private static final Long ACCOUNT_NUMBER = 12345678L;
  private static final String BRAND_CODE_YBS = "YBS";
  private static final String REQUIRED_ACTIVITY_GROUP_CODE = "AISP";
  private static final LocalDateTime DATETIME = LocalDateTime.parse("2020-05-26T04:20:00");
  public static final String ACTIVITY_GROUP_CODE_PISP = "PISP";
  public static final String ACTIVITY_GROUP_CODE_AHLDRS = "AHLDRS";

  @InjectMocks private AccountAccessValidator testSubject;

  @Mock private SavingProductRepository accountNumberRepository;

  @Mock private ActivityPlayerRepository activityPlayerRepository;

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void shouldValidateAccountAccess(final boolean includeRequired) {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final Set<String> activityGroupCodesToRetrieve =
        includeRequired
            ? Sets.newHashSet(
                ACTIVITY_GROUP_CODE_PISP, ACTIVITY_GROUP_CODE_AHLDRS, REQUIRED_ACTIVITY_GROUP_CODE)
            : Sets.newHashSet(ACTIVITY_GROUP_CODE_PISP, ACTIVITY_GROUP_CODE_AHLDRS);

    final Collection<String> allActivityGroupCodesToRetrieve =
        new HashSet<>(activityGroupCodesToRetrieve);
    allActivityGroupCodesToRetrieve.add("AISP");
    final Collection<AccountActivityGroup> activityTypeGroups =
        Arrays.asList(
            new AccountActivityGroup(ACCOUNT_NUMBER, ACTIVITY_GROUP_CODE_PISP),
            new AccountActivityGroup(ACCOUNT_NUMBER, ACTIVITY_GROUP_CODE_AHLDRS),
            new AccountActivityGroup(ACCOUNT_NUMBER, REQUIRED_ACTIVITY_GROUP_CODE));

    when(accountNumberRepository.findBySavingAccountNumber(ACCOUNT_NUMBER))
        .thenReturn(Optional.of(new SavingProduct(1L, BRAND_CODE_YBS)));
    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID,
            allActivityGroupCodesToRetrieve,
            Collections.singleton(ACCOUNT_NUMBER),
            DATETIME))
        .thenReturn(activityTypeGroups);

    final Set<String> activityGroupCodes =
        testSubject.validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), metadata, activityGroupCodesToRetrieve, DATETIME);
    assertThat(activityGroupCodes, is(activityGroupCodesToRetrieve));
  }

  @Test
  void shouldRejectAccessWhenAccountDoesntExist() {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final Collection<String> activityGroupCodesToRetrieve = Collections.emptySet();

    when(accountNumberRepository.findBySavingAccountNumber(ACCOUNT_NUMBER))
        .thenReturn(Optional.empty());

    final AccountResourceNotFoundException exception =
        assertThrows(
            AccountResourceNotFoundException.class,
            () ->
                testSubject.validateAccountAccess(
                    String.valueOf(ACCOUNT_NUMBER),
                    metadata,
                    activityGroupCodesToRetrieve,
                    DATETIME));

    assertThat(exception.getMessage(), is("Account " + ACCOUNT_NUMBER + " not found"));
  }

  @Test
  void shouldRejectAccessWhenAccountBrandCodeDoesNotMatchTheRequestBrandCode() {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final Collection<String> activityGroupCodesToRetrieve = Collections.emptySet();

    when(accountNumberRepository.findBySavingAccountNumber(ACCOUNT_NUMBER))
        .thenReturn(Optional.of(new SavingProduct(1L, "CHE")));

    final AccountAccessDeniedException exception =
        assertThrows(
            AccountAccessDeniedException.class,
            () ->
                testSubject.validateAccountAccess(
                    String.valueOf(ACCOUNT_NUMBER),
                    metadata,
                    activityGroupCodesToRetrieve,
                    DATETIME));

    assertThat(
        exception.getMessage(),
        is(
            "Account "
                + ACCOUNT_NUMBER
                + " is for brand CHE, but request is for brand "
                + BRAND_CODE_YBS));
  }

  @Test
  void shouldRejectAccessWhenRequestPartyIdDoesntHaveRequiredActivityGroupRelationship() {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final Collection<String> activityGroupCodesToRetrieve =
        Arrays.asList(ACTIVITY_GROUP_CODE_PISP, ACTIVITY_GROUP_CODE_AHLDRS);

    final Collection<String> allActivityGroupCodesToRetrieve =
        new HashSet<>(activityGroupCodesToRetrieve);
    allActivityGroupCodesToRetrieve.add("AISP");
    final Collection<AccountActivityGroup> activityTypeGroups =
        Arrays.asList(
            new AccountActivityGroup(ACCOUNT_NUMBER, ACTIVITY_GROUP_CODE_PISP),
            new AccountActivityGroup(ACCOUNT_NUMBER, ACTIVITY_GROUP_CODE_AHLDRS));

    when(accountNumberRepository.findBySavingAccountNumber(ACCOUNT_NUMBER))
        .thenReturn(Optional.of(new SavingProduct(1L, BRAND_CODE_YBS)));
    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID,
            allActivityGroupCodesToRetrieve,
            Collections.singleton(ACCOUNT_NUMBER),
            DATETIME))
        .thenReturn(activityTypeGroups);

    final AccountAccessDeniedException exception =
        assertThrows(
            AccountAccessDeniedException.class,
            () ->
                testSubject.validateAccountAccess(
                    String.valueOf(ACCOUNT_NUMBER),
                    metadata,
                    activityGroupCodesToRetrieve,
                    DATETIME));

    assertThat(
        exception.getMessage(),
        is(
            "Customer "
                + PARTY_ID
                + " does not have a "
                + REQUIRED_ACTIVITY_GROUP_CODE
                + " relationship with account "
                + ACCOUNT_NUMBER));
  }
}
