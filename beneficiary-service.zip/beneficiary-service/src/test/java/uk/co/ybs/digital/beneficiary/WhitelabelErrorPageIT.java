package uk.co.ybs.digital.beneficiary;

import java.io.IOException;
import java.net.URI;
import java.security.PrivateKey;
import java.util.UUID;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.filter.OncePerRequestFilter;
import uk.co.ybs.digital.beneficiary.WhitelabelErrorPageIT.WhitelabelErrorPageTestConfig;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, WhitelabelErrorPageTestConfig.class})
@ActiveProfiles("test")
class WhitelabelErrorPageIT {
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";

  private static final String PARTY_ID = "12462951";
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final String SCOPE = "BENEFICIARY";
  private static final String BRAND_CODE = "YBS";

  @LocalServerPort private int port;

  @Autowired private WebTestClient signingWebClientPublic;

  @Autowired private PrivateKey jwtSigningPrivateKey;

  @Test
  void
      whitelabelErrorPageShouldReturnInternalServerErrorWhenRequestFilterThrowsUnexpectedException() {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwt(
            PARTY_ID, PARTY_ID, SESSION_ID, SCOPE, BRAND_CODE, jwtSigningPrivateKey);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("500 Internal Server Error")
            .message("Internal Server Error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected error")
                    .build())
            .build();

    signingWebClientPublic
        .get()
        .uri(getAccountURI())
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  private URI getAccountURI() {
    return URI.create("http://localhost:" + port + "/beneficiary/accounts/123/beneficiaries");
  }

  @TestConfiguration
  static class WhitelabelErrorPageTestConfig {
    @Bean
    FilterRegistrationBean<Filter> filterRegistrationBean() {
      return new FilterRegistrationBean<>(
          new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(
                final HttpServletRequest request,
                final HttpServletResponse response,
                final FilterChain filterChain)
                throws IOException {
              throw new IOException("Unexpected exception");
            }
          });
    }
  }
}
