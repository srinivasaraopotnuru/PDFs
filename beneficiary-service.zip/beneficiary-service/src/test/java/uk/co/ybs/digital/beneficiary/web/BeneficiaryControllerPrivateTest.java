package uk.co.ybs.digital.beneficiary.web;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import uk.co.ybs.digital.beneficiary.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.exception.AccountServiceException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryService;
import uk.co.ybs.digital.beneficiary.service.account.AccountService;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(controllers = BeneficiaryControllerPrivate.class)
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter
  RequestVerificationSecurityAutoConfiguration.class, // Signature and JWT validation
  FilterErrorResponseFactory.class,
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class // Metrics
})
@ActiveProfiles({"test", "text-logging"})
class BeneficiaryControllerPrivateTest {

  private static final String HOST_HEADER_VALUE = "beneficiaryservice.ybs.co.uk:443";

  private static final String BASE_PATH = "/private";
  private static final String BENEFICIARIES_ENDPOINT = BASE_PATH + "/accounts/%s/beneficiaries";
  private static final String BENEFICIARIES_BENEFICIARY_ENDPOINT =
      BASE_PATH + "/accounts/%s/beneficiaries/%s";

  private static final String ACCOUNT_NUMBER = "1234567890";
  private static final String STR_ACCOUNT_NUMBER = "accountNumber";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String OTHER_SCOPE = "PAYMENT";
  private static final String VALID_SCOPE = "ACCOUNT_READ BENEFICIARY";

  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final String SESSION_ID_ATTRIBUTE_NAME =
      "uk.co.ybs.digital.logging.session.SessionIdFilter.sessionId";
  private static final String BENEFICIARY_ID_XYZ_1 = "xyz1";
  private static final int PORT_SSL = 443;
  private static final String INVALID_REQUEST_BODY = "Invalid request body";
  private static final String BENEFICIARY_ID = "beneficiaryId";

  @Autowired private MockMvc mvc;

  @Autowired private ObjectMapper objectMapper;

  @MockBean private RequestSigningVerificationService requestSigningVerificationService;

  @MockBean private BeneficiaryService beneficiaryService;

  @MockBean private AccountService accountService;

  @BeforeEach
  void beforeEach() {
    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
  }

  @Test
  void getBeneficiaryShouldGetBeneficiary() throws Exception {
    UUID requestId = UUID.randomUUID();

    mvc.perform(
            get(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isOk());

    RequestMetadata expectedMetadata = TestHelper.buildValidRequestMetadata(requestId, PORT_SSL);
    verify(beneficiaryService)
        .getBeneficiary(ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1, expectedMetadata);
  }

  @ParameterizedTest
  @MethodSource("beneficiaryRequest")
  void createBeneficiaryShouldCreateBeneficiary(final Beneficiary request) throws Exception {
    final UUID requestId = UUID.randomUUID();

    postBeneficiary(ACCOUNT_NUMBER, requestId, request).andExpect(status().isAccepted());

    RequestMetadata expectedMetadata = TestHelper.buildValidRequestMetadata(requestId, PORT_SSL);
    verify(beneficiaryService)
        .createBeneficiaryWithoutSca(ACCOUNT_NUMBER, request, expectedMetadata);
  }

  private static Stream<Beneficiary> beneficiaryRequest() {
    return Stream.of(
        validCreateExternalBeneficiaryRequest(), validCreateInternalBeneficiaryRequest());
  }

  @Test
  void getBeneficiaryShouldReturnNotFoundIfAccountIsNotFound() throws Exception {
    UUID requestId = UUID.randomUUID();
    when(beneficiaryService.getBeneficiary(
            eq(ACCOUNT_NUMBER), eq(BENEFICIARY_ID_XYZ_1), any(RequestMetadata.class)))
        .thenThrow(AccountResourceNotFoundException.class);

    ErrorResponse expectedErrorResponse = TestHelper.notFound(requestId);

    mvc.perform(
            get(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void getBeneficiaryShouldReturnNotFoundIfBeneficiaryIsNotFound() throws Exception {
    UUID requestId = UUID.randomUUID();
    when(beneficiaryService.getBeneficiary(
            eq(ACCOUNT_NUMBER), eq(BENEFICIARY_ID_XYZ_1), any(RequestMetadata.class)))
        .thenThrow(AccountResourceNotFoundException.class);

    ErrorResponse expectedErrorResponse = TestHelper.notFound(requestId);

    mvc.perform(
            get(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void getBeneficiaryShouldReturnBadRequestWhenRequestIdIsNotAUUID() throws Exception {
    String requestId = "not-a-uuid";

    mvc.perform(
            get(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.id", notNullValue()))
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(REQUEST_ID_HEADER)));
  }

  @Test
  void getBeneficiaryShouldReturnMethodNotSupportedWhenMethodNotSupported() throws Exception {
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("405 Method Not Allowed")
            .id(requestId)
            .message("Method Not Allowed")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method")
                    .build())
            .build();

    mvc.perform(
            post(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .contentType(MediaType.TEXT_PLAIN)
                .headers(standardHeaders(requestId))
                .content(""))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.GET.name())));
  }

  @Test
  void getBeneficiaryShouldIncludeResponseBodyWhenUnexpectedSpringInternalExceptionThrown()
      throws Exception {
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException())
        .when(beneficiaryService)
        .getBeneficiary(any(), any(), any());

    mvc.perform(
            get(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void getBeneficiaryShouldReturnBadRequestWhenScopeIsNotValid() throws Exception {
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    mvc.perform(
            get(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getJwtWithInvalidScope()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void getBeneficiaryShouldReturnForbiddenForAccountAccessDeniedException() throws Exception {
    UUID requestId = UUID.randomUUID();

    when(beneficiaryService.getBeneficiary(
            eq(ACCOUNT_NUMBER), eq(BENEFICIARY_ID_XYZ_1), any(RequestMetadata.class)))
        .thenThrow(AccountAccessDeniedException.class);

    ErrorResponse expectedErrorResponse = TestHelper.accessDeniedErrorResponse(requestId);

    mvc.perform(
            get(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void getBeneficiaryShouldReturnInternalServerErrorIfAccountServiceExceptionIsThrown()
      throws Exception {
    UUID requestId = UUID.randomUUID();

    when(beneficiaryService.getBeneficiary(
            eq(ACCOUNT_NUMBER), eq(BENEFICIARY_ID_XYZ_1), any(RequestMetadata.class)))
        .thenThrow(AccountServiceException.class);

    ErrorResponse expectedErrorResponse = TestHelper.internalServerError(requestId);

    mvc.perform(
            get(String.format(
                    BENEFICIARIES_BENEFICIARY_ENDPOINT, ACCOUNT_NUMBER, BENEFICIARY_ID_XYZ_1))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId)))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {"123456789", "12345678901", "abcdefgh"})
  void createBeneficiaryShouldReturnBadRequestAccountNumberInvalid(final String accountNumber)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary request = validCreateInternalBeneficiaryRequest();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("400 Bad Request")
            .id(requestId)
            .message("Invalid value")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message(
                        String.format(
                            "%s is not a valid account number; value must be of the form 1234567890",
                            accountNumber))
                    .build())
            .build();

    postBeneficiary(accountNumber, requestId, request)
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));

    verify(beneficiaryService, never()).createBeneficiaryWithoutSca(any(), any(), any());
  }

  @Test
  void createBeneficiaryShouldBadRequestForMissingRequestField() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary request = TestHelper.createExternalBeneficiary(null);
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify an account number")
                    .path(STR_ACCOUNT_NUMBER)
                    .build())
            .build();

    postBeneficiary(ACCOUNT_NUMBER, requestId, request)
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void createBeneficiaryShouldBadRequestForInvalidRequestField() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary request = TestHelper.createExternalBeneficiary("123");
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("Account number must be 8 digits")
                    .path(STR_ACCOUNT_NUMBER)
                    .build())
            .build();

    postBeneficiary(ACCOUNT_NUMBER, requestId, request)
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @MethodSource("beneficiaryValidationExceptionReason")
  void updateBeneficiaryShouldReturnBadRequestWhenBeneficiaryValidationExceptionThrown(
      final BeneficiaryValidationExceptionReason reason,
      final String expectedErrorCode,
      final String expectedErrorMessage)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary beneficiary = validCreateExternalBeneficiaryRequest();
    final BeneficiaryValidationException exception = new BeneficiaryValidationException("", reason);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.CONFLICT)
            .id(requestId)
            .message("Beneficiary validation error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(expectedErrorCode)
                    .message(expectedErrorMessage)
                    .build())
            .build();

    doThrow(exception).when(beneficiaryService).createBeneficiaryWithoutSca(any(), any(), any());

    postBeneficiary(ACCOUNT_NUMBER, requestId, beneficiary)
        .andExpect(status().isConflict())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  private static Stream<Arguments> beneficiaryValidationExceptionReason() {
    return Stream.of(
        Arguments.of(
            BeneficiaryValidationExceptionReason.LIMIT_REACHED,
            "Beneficiary.Limit",
            "Unable to add beneficiary as allowed limit would be exceeded"),
        Arguments.of(
            BeneficiaryValidationExceptionReason.DUPLICATE,
            "Beneficiary.Exists",
            "Unable to add beneficiary as it already exists for this account"));
  }

  @Test
  void createBeneficiaryShouldReturnBadRequestWhenRequestIdIsNotAUUID() throws Exception {
    final String requestId = "not-a-uuid";
    final Beneficiary request = validCreateExternalBeneficiaryRequest();

    mvc.perform(
            post(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getJwtWithInvalidScope()))
                .headers(standardHeaders(requestId))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.id", notNullValue()))
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(REQUEST_ID_HEADER)));

    verify(beneficiaryService, never()).createBeneficiaryWithoutSca(any(), any(), any());
  }

  @Test
  void createBeneficiaryShouldReturnMethodNotSupportedWhenMethodNotSupported() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary request = validCreateExternalBeneficiaryRequest();
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("405 Method Not Allowed")
            .id(requestId)
            .message("Method Not Allowed")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method")
                    .build())
            .build();

    mvc.perform(
            get(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, "POST,PUT"));

    verify(beneficiaryService, never()).createBeneficiaryWithoutSca(any(), any(), any());
  }

  @Test
  void createBeneficiaryShouldReturnErrorWhenUnexpectedSpringInternalExceptionThrown()
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary request = validCreateExternalBeneficiaryRequest();
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException())
        .when(beneficiaryService)
        .createBeneficiaryWithoutSca(any(), any(), any());

    postBeneficiary(ACCOUNT_NUMBER, requestId, request)
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void createBeneficiaryShouldReturnBadRequestWhenScopeIsNotValid() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary request = validCreateExternalBeneficiaryRequest();
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    mvc.perform(
            post(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getJwtWithInvalidScope()))
                .headers(standardHeaders(requestId))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));

    verify(beneficiaryService, never()).createBeneficiaryWithoutSca(any(), any(), any());
  }

  @Test
  void updateBeneficiaryShouldInvokeBeneficiaryService() throws Exception {
    final UUID requestId = UUID.randomUUID();
    RequestMetadata expectedMetadata = TestHelper.buildValidRequestMetadata(requestId, PORT_SSL);

    final Beneficiary beneficiary =
        validCreateExternalBeneficiaryRequest().toBuilder().beneficiaryId(BENEFICIARY_ID).build();

    final HttpHeaders headers = standardHeaders(requestId);
    headers.setContentType(MediaType.APPLICATION_JSON);

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(headers)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isAccepted());

    verify(beneficiaryService)
        .updateBeneficiaryWithoutSca(ACCOUNT_NUMBER, beneficiary, expectedMetadata);
  }

  @Test
  void updateBeneficiaryShouldReturnBadRequestForMissingRequestField() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary beneficiary =
        validCreateExternalBeneficiaryRequest()
            .toBuilder()
            .beneficiaryId(BENEFICIARY_ID)
            .accountNumber(null)
            .build();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify an account number")
                    .path(STR_ACCOUNT_NUMBER)
                    .build())
            .build();

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateBeneficiaryShouldReturnBadRequestForInvalidRequestField() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalBeneficiary beneficiary =
        validCreateExternalBeneficiaryRequest()
            .toBuilder()
            .beneficiaryId(BENEFICIARY_ID)
            .accountNumber("123")
            .build();
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("Account number must be 8 digits")
                    .path(STR_ACCOUNT_NUMBER)
                    .build())
            .build();

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void
      updateBeneficiaryShouldReturnBadRequestForMissingRequestFieldInExistingBeneficiaryValidationGroup()
          throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary beneficiary =
        validCreateExternalBeneficiaryRequest().toBuilder().beneficiaryId(null).build();
    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify a beneficiary identifier")
                    .path(BENEFICIARY_ID)
                    .build())
            .build();

    mvc.perform(
            put(String.format(BENEFICIARIES_ENDPOINT, ACCOUNT_NUMBER))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(getValidJwt()))
                .headers(standardHeaders(requestId))
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(beneficiary)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  private Jwt getValidJwt() {
    return getJwtWithScope(VALID_SCOPE);
  }

  private Jwt getJwtWithInvalidScope() {
    return getJwtWithScope(OTHER_SCOPE);
  }

  private Jwt getJwtWithScope(final String scope) {
    return Jwt.withTokenValue("<jwt>")
        .header("kid", "key-id")
        .subject("987654321")
        .claim("scope", scope)
        .claim("brand_code", "YBS")
        .claim("party_id", "12462951")
        .claim("sid", SESSION_ID.toString())
        .build();
  }

  private HttpHeaders standardHeaders(final UUID requestId) {
    return standardHeaders(requestId.toString());
  }

  private HttpHeaders standardHeaders(final String requestId) {
    final HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    httpHeaders.add(HttpHeaders.HOST, HOST_HEADER_VALUE);
    httpHeaders.add(REQUEST_ID_HEADER, requestId);
    return httpHeaders;
  }

  private ResultActions postBeneficiary(
      final String accountNumber, final UUID requestId, final Beneficiary request)
      throws Exception {
    return postRequest(String.format(BENEFICIARIES_ENDPOINT, accountNumber), requestId, request);
  }

  private ResultActions postRequest(final String path, final UUID requestId, final Object request)
      throws Exception {
    return mvc.perform(
        post(path)
            .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
            .with(jwt().jwt(getValidJwt()))
            .headers(standardHeaders(requestId))
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .content(objectMapper.writeValueAsString(request)));
  }

  private static ExternalBeneficiary validCreateExternalBeneficiaryRequest() {
    return ExternalBeneficiary.builder()
        .accountSortCode("112233")
        .accountNumber("12345678")
        .memorableName("memorable")
        .name("name")
        .reference("reference")
        .build();
  }

  private static InternalBeneficiary validCreateInternalBeneficiaryRequest() {
    return InternalBeneficiary.builder().accountNumber("1234567890").build();
  }
}
