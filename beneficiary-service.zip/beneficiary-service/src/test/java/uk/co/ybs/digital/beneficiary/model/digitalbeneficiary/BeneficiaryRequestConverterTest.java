package uk.co.ybs.digital.beneficiary.model.digitalbeneficiary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class BeneficiaryRequestConverterTest {

  private static final String PARTY_ID = "123456";
  private static final String BRAND_YBS = "YBS";
  private static final UUID REQUEST_ID = UUID.fromString("8e112ed4-0374-47d0-aa82-427049d2dab4");
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final long SYS_ID = 1L;

  @InjectMocks private BeneficiaryRequestConverter testSubject;

  @ParameterizedTest
  @MethodSource("requestValues")
  void shouldCreateJsonString(
      final Beneficiary beneficiary,
      final Long sysId,
      final Integer beneficiariesLimit,
      final String expectedValue) {
    final BeneficiaryRequest input =
        BeneficiaryRequest.builder()
            .payload(
                BeneficiaryRequest.Payload.builder()
                    .sysId(sysId)
                    .beneficiariesLimit(beneficiariesLimit)
                    .beneficiary(beneficiary)
                    .build())
            .metadata(createRequestMetadata())
            .build();

    String result = testSubject.convertToDatabaseColumn(input);

    assertThat(result, is(expectedValue));
  }

  private static Stream<Arguments> requestValues() {
    return Stream.of(
        Arguments.of(
            createExternalBeneficiary(),
            null,
            null,
            "{\"payload\":{\"sysId\":null,\"beneficiariesLimit\":null,\"beneficiary\":{\"type\":\"EXTERNAL\",\"beneficiaryId\":null,\"accountSortCode\":\"112233\",\"name\":\"NAME\",\"accountNumber\":\"12345678\",\"reference\":\"REF\",\"memorableName\":\"MEM\"}},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"862ddff4-2b6d-4dda-b4d2-98cfcf83ab60\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}"),
        Arguments.of(
            createExternalBeneficiary(),
            SYS_ID,
            98,
            "{\"payload\":{\"sysId\":1,\"beneficiariesLimit\":98,\"beneficiary\":{\"type\":\"EXTERNAL\",\"beneficiaryId\":null,\"accountSortCode\":\"112233\",\"name\":\"NAME\",\"accountNumber\":\"12345678\",\"reference\":\"REF\",\"memorableName\":\"MEM\"}},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"862ddff4-2b6d-4dda-b4d2-98cfcf83ab60\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}"),
        Arguments.of(
            createInternalBeneficiary(),
            null,
            null,
            "{\"payload\":{\"sysId\":null,\"beneficiariesLimit\":null,\"beneficiary\":{\"type\":\"INTERNAL\",\"beneficiaryId\":null,\"accountNumber\":\"1234567890\"}},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"862ddff4-2b6d-4dda-b4d2-98cfcf83ab60\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}"),
        Arguments.of(
            createInternalBeneficiary(),
            SYS_ID,
            6,
            "{\"payload\":{\"sysId\":1,\"beneficiariesLimit\":6,\"beneficiary\":{\"type\":\"INTERNAL\",\"beneficiaryId\":null,\"accountNumber\":\"1234567890\"}},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"862ddff4-2b6d-4dda-b4d2-98cfcf83ab60\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}"));
  }

  @ParameterizedTest
  @MethodSource("dbValues")
  void shouldReturnValidBeneficiaryRequest(
      final String input,
      final Beneficiary expectedBeneficiary,
      final Long expectedSysId,
      final Integer expectedBeneficiariesLimit) {
    BeneficiaryRequest result = testSubject.convertToEntityAttribute(input);

    final BeneficiaryRequest expected =
        BeneficiaryRequest.builder()
            .payload(
                BeneficiaryRequest.Payload.builder()
                    .sysId(expectedSysId)
                    .beneficiariesLimit(expectedBeneficiariesLimit)
                    .beneficiary(expectedBeneficiary)
                    .build())
            .metadata(createRequestMetadata())
            .build();

    assertThat(result, samePropertyValuesAs(expected));
  }

  private static Stream<Arguments> dbValues() {
    return Stream.of(
        Arguments.of(
            "{\"payload\":{\"sysId\":null,\"beneficiariesLimit\":null,\"beneficiary\":{\"type\":\"EXTERNAL\",\"beneficiaryId\":null,\"accountSortCode\":\"112233\",\"name\":\"NAME\",\"accountNumber\":\"12345678\",\"reference\":\"REF\",\"memorableName\":\"MEM\"}},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"862ddff4-2b6d-4dda-b4d2-98cfcf83ab60\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}",
            createExternalBeneficiary(),
            null,
            null),
        Arguments.of(
            "{\"payload\":{\"sysId\":1,\"beneficiariesLimit\":98,\"beneficiary\":{\"type\":\"EXTERNAL\",\"beneficiaryId\":null,\"accountSortCode\":\"112233\",\"name\":\"NAME\",\"accountNumber\":\"12345678\",\"reference\":\"REF\",\"memorableName\":\"MEM\"}},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"862ddff4-2b6d-4dda-b4d2-98cfcf83ab60\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}",
            createExternalBeneficiary(),
            SYS_ID,
            98),
        Arguments.of(
            "{\"payload\":{\"sysId\":null,\"beneficiariesLimit\":null,\"beneficiary\":{\"type\":\"INTERNAL\",\"beneficiaryId\":null,\"accountNumber\":\"1234567890\"}},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"862ddff4-2b6d-4dda-b4d2-98cfcf83ab60\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}",
            createInternalBeneficiary(),
            null,
            null),
        Arguments.of(
            "{\"payload\":{\"sysId\":1,\"beneficiariesLimit\":6,\"beneficiary\":{\"type\":\"INTERNAL\",\"beneficiaryId\":null,\"accountNumber\":\"1234567890\"}},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"862ddff4-2b6d-4dda-b4d2-98cfcf83ab60\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}",
            createInternalBeneficiary(),
            SYS_ID,
            6));
  }

  @Test
  void shouldThrowErrorIfDBValueNotValidBeneficiaryRequest() {
    assertThrows(
        BeneficiaryRequestConverter.DataConversionException.class,
        () -> testSubject.convertToEntityAttribute("{\"invalid\":\"entity\"}"));
  }

  private static RequestMetadata createRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .sessionId(SESSION_ID)
        .host(InetSocketAddress.createUnresolved("accountservice.ybs.co.uk", 443))
        .brandCode(BRAND_YBS)
        .partyId(PARTY_ID)
        .forwardingAuth("<jwt>")
        .ipAddress("12.66.53.145")
        .build();
  }

  private static InternalBeneficiary createInternalBeneficiary() {
    return InternalBeneficiary.builder().accountNumber("1234567890").build();
  }

  private static ExternalBeneficiary createExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .accountNumber("12345678")
        .accountSortCode("112233")
        .memorableName("MEM")
        .name("NAME")
        .reference("REF")
        .build();
  }
}
