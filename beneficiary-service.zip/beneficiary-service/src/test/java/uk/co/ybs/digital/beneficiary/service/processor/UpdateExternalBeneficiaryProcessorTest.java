package uk.co.ybs.digital.beneficiary.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DELETED;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.TECHNICAL;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.UPDATE_ALREADY_APPLIED;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.repository.core.BillPaymentInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.ExternalUpdateBeneficiaryInformationWrapper;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.mapper.ExternalBeneficiaryDatabaseEntityMapper;
import uk.co.ybs.digital.beneficiary.service.utilities.BeneficiaryUtils;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class UpdateExternalBeneficiaryProcessorTest {

  private static final long ACCOUNT_NUMBER = 1234567890L;
  private static final long PAYEE_SORT_CODE = 112233L;
  private static final long PAYEE_ACCOUNT_NUMBER = 12345678L;
  private static final String PAYEE_NAME = "payee-name";
  private static final long BENEFICIARY_SYS_ID = 1L;
  private static final String REFERENCE = "reference";
  private static final String NEW_REFERENCE = "new reference";
  private static final String CURRENT_MEMORABLE_NAME = "current-memorable-name";
  private static final String NEW_MEMORABLE_NAME = "new-memorable-name";
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  @InjectMocks private UpdateExternalBeneficiaryProcessor testSubject;
  @Mock private BillPaymentInstructionCoreRepository billPaymentInstructionCoreRepository;
  @Mock private ExternalBeneficiaryDatabaseEntityMapper externalBeneficiaryDatabaseEntityMapper;
  @Mock private BeneficiaryInformationFactory beneficiaryInformationFactory;
  @Mock private BeneficiaryAuditor beneficiaryAuditor;
  @Mock private BeneficiaryUtils beneficiaryUtils;

  @Test
  void resolveShouldReturnDatabaseEntity() {
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(TestHelper.createRequestMetadata(), buildBeneficiary());
    final BillPaymentInstruction billPaymentInstruction =
        BillPaymentInstruction.builder().sysId(2L).build();

    when(billPaymentInstructionCoreRepository.findById(BENEFICIARY_SYS_ID))
        .thenReturn(Optional.of(billPaymentInstruction));

    final BillPaymentInstruction instruction = testSubject.resolve(arguments);

    assertThat(instruction, is(billPaymentInstruction));
    verifyNoMoreInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void resolveShouldThrowIllegalArgumentExceptionWhenRepositoryReturnsEmpty() {
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(TestHelper.createRequestMetadata(), buildBeneficiary());

    when(billPaymentInstructionCoreRepository.findById(any())).thenReturn(Optional.empty());

    final IllegalArgumentException exception =
        assertThrows(IllegalArgumentException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("BillPaymentInstruction 1 not found"));
    verifyNoMoreInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void executeShouldUpdateBeneficiary() {
    executeShouldCreateBeneficiary(NEW_MEMORABLE_NAME, NEW_MEMORABLE_NAME, NEW_REFERENCE);
  }

  @ParameterizedTest
  @MethodSource("memorableNameAndReferenceForTrimming")
  void executeShouldCreateBeneficiaryTrimmingWhitespaceFromMemorableNameAndReference(
      @SuppressWarnings("unused") final String label,
      final String memorableName,
      final String reference) {
    executeShouldCreateBeneficiary(memorableName, NEW_MEMORABLE_NAME, reference);
  }

  private void executeShouldCreateBeneficiary(
      final String memorableName, final String expectedMemorableName, final String reference) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary =
        buildBeneficiary().toBuilder().memorableName(memorableName).reference(reference).build();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata, beneficiary);

    final NonYbsBankAccount nonYbsBankAccount = buildNonYbsBankAccount();
    final BillPaymentInstruction instruction = buildBillPaymentInstruction(nonYbsBankAccount);

    final BillPaymentInstruction newInstruction =
        instruction
            .toBuilder()
            .reference(NEW_REFERENCE)
            .memorableName(expectedMemorableName)
            .sysId(null)
            .status("ACTIVE")
            .availableAtm(true)
            .fpTrustStatus(true)
            .fpChangeReason("OOBAD")
            .createdAt("0795")
            .createdBy("SAPP")
            .createdDate(PROCESS_TIME)
            .build();

    final BillPaymentInstruction oldInstruction =
        instruction
            .toBuilder()
            .endDate(PROCESS_TIME)
            .endedAt("0795")
            .endedBy("SAPP")
            .endedDate(PROCESS_TIME)
            .status("CANC")
            .atmOrderNumber(null)
            .build();

    testSubject.execute(arguments, instruction);

    verify(billPaymentInstructionCoreRepository)
        .saveAll(
            (Iterable<? extends BillPaymentInstruction>)
                argThat(
                    contains(
                        samePropertyValuesAs(newInstruction),
                        samePropertyValuesAs(oldInstruction))));
    verify(billPaymentInstructionCoreRepository).flush();
    verify(billPaymentInstructionCoreRepository)
        .updateExternalBeneficiaryAuthenticRecord(ACCOUNT_NUMBER);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfEnded() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = buildBeneficiary();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata, beneficiary);

    final NonYbsBankAccount nonYbsBankAccount = buildNonYbsBankAccount();
    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(nonYbsBankAccount).toBuilder().endDate(PROCESS_TIME).build();

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () -> testSubject.execute(arguments, billPaymentInstruction));

    assertThat(exception.getMessage(), is("Beneficiary ended"));
    assertThat(exception.getReason(), is(DELETED));

    verifyNoInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfEndedAndRemainingValidationWouldFail() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = buildBeneficiary();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata, beneficiary);

    final NonYbsBankAccount nonYbsBankAccount = buildNonYbsBankAccount();
    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(nonYbsBankAccount)
            .toBuilder()
            .memorableName(NEW_MEMORABLE_NAME)
            .endDate(PROCESS_TIME)
            .build();

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () -> testSubject.execute(arguments, billPaymentInstruction));

    assertThat(exception.getMessage(), is("Beneficiary ended"));
    assertThat(exception.getReason(), is(DELETED));

    verifyNoMoreInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @ParameterizedTest
  @CsvSource(
      value = {
        NEW_MEMORABLE_NAME + "," + NEW_MEMORABLE_NAME + "," + NEW_REFERENCE + "," + NEW_REFERENCE,
        "null,null,null,null"
      },
      nullValues = "null")
  void executeShouldThrowBeneficiaryValidationExceptionIfUpdateAlreadyApplied(
      final String currentMemorableName,
      final String newMemorableName,
      final String currentReference,
      final String newReference) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary =
        buildBeneficiary()
            .toBuilder()
            .reference(newReference)
            .memorableName(newMemorableName)
            .build();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata, beneficiary);

    final NonYbsBankAccount nonYbsBankAccount = buildNonYbsBankAccount();
    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(nonYbsBankAccount)
            .toBuilder()
            .reference(currentReference)
            .memorableName(currentMemorableName)
            .build();

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () -> testSubject.execute(arguments, billPaymentInstruction));

    assertThat(exception.getMessage(), is("Update already applied"));
    assertThat(exception.getReason(), is(UPDATE_ALREADY_APPLIED));

    verifyNoInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfBeneficiaryAlreadyExists() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = buildBeneficiary();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata, beneficiary);

    final NonYbsBankAccount nonYbsBankAccount = buildNonYbsBankAccount();
    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(nonYbsBankAccount);

    when(billPaymentInstructionCoreRepository.findExistingExternalBeneficiaries(
            ACCOUNT_NUMBER,
            PAYEE_SORT_CODE,
            PAYEE_ACCOUNT_NUMBER,
            BENEFICIARY_SYS_ID,
            PROCESS_TIME))
        .thenReturn(Collections.singletonList(billPaymentInstruction));

    when(beneficiaryUtils.compareReferences(
            billPaymentInstruction.getReference(), beneficiary.getReference()))
        .thenReturn(true);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () -> testSubject.execute(arguments, billPaymentInstruction));

    assertThat(
        exception.getMessage(),
        is("Requested beneficiary already exists for account: " + ACCOUNT_NUMBER));
    assertThat(exception.getReason(), is(DUPLICATE));

    verifyNoMoreInteractions(billPaymentInstructionCoreRepository);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @Test
  void auditSuccessShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = buildBeneficiary();
    final ExternalBeneficiary databaseBeneficiary = buildDatabaseBeneficiary();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata, beneficiary);

    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(buildNonYbsBankAccount());

    final ExternalBeneficiaryInformation information =
        TestHelper.createExternalBeneficiaryInformation(
            String.valueOf(ACCOUNT_NUMBER), String.valueOf(PAYEE_ACCOUNT_NUMBER));
    final ExternalUpdateBeneficiaryInformation updateInformation =
        TestHelper.createExternalUpdateBeneficiaryInformation();
    final ExternalUpdateBeneficiaryInformationWrapper expectedAuditBody =
        new ExternalUpdateBeneficiaryInformationWrapper(information, updateInformation);

    when(externalBeneficiaryDatabaseEntityMapper.map(billPaymentInstruction))
        .thenReturn(databaseBeneficiary);
    when(beneficiaryInformationFactory.buildExternalUpdate(
            ACCOUNT_NUMBER, beneficiary, databaseBeneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditSuccess(arguments, billPaymentInstruction);

    verify(beneficiaryAuditor).auditBeneficiaryUpdateSuccess(expectedAuditBody, requestMetadata);
    verifyNoInteractions(billPaymentInstructionCoreRepository);
  }

  @Test
  void auditFailureShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = buildBeneficiary();
    final ExternalBeneficiary databaseBeneficiary = buildDatabaseBeneficiary();
    final ExistingBeneficiaryRequestArguments<ExternalBeneficiary> arguments =
        buildArguments(requestMetadata, beneficiary);

    final BillPaymentInstruction billPaymentInstruction =
        buildBillPaymentInstruction(buildNonYbsBankAccount());

    final ExternalBeneficiaryInformation information =
        TestHelper.createExternalBeneficiaryInformation(
            String.valueOf(ACCOUNT_NUMBER), String.valueOf(PAYEE_ACCOUNT_NUMBER));
    final ExternalUpdateBeneficiaryInformation updateInformation =
        TestHelper.createExternalUpdateBeneficiaryInformation();
    final ExternalUpdateBeneficiaryInformationWrapper expectedAuditBody =
        new ExternalUpdateBeneficiaryInformationWrapper(information, updateInformation);

    when(externalBeneficiaryDatabaseEntityMapper.map(billPaymentInstruction))
        .thenReturn(databaseBeneficiary);
    when(beneficiaryInformationFactory.buildExternalUpdate(
            ACCOUNT_NUMBER, beneficiary, databaseBeneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditFailure(arguments, billPaymentInstruction, TECHNICAL);

    verify(beneficiaryAuditor)
        .auditBeneficiaryUpdateFailure(expectedAuditBody, "Technical Failure", requestMetadata);
    verifyNoInteractions(billPaymentInstructionCoreRepository);
  }

  private ExistingBeneficiaryRequestArguments<ExternalBeneficiary> buildArguments(
      final RequestMetadata requestMetadata, final ExternalBeneficiary beneficiary) {
    return new ExistingBeneficiaryRequestArguments<>(
        ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, BENEFICIARY_SYS_ID);
  }

  private ExternalBeneficiary buildBeneficiary() {
    return ExternalBeneficiary.builder()
        .beneficiaryId("abc123")
        .accountSortCode(String.valueOf(PAYEE_SORT_CODE))
        .accountNumber(String.valueOf(PAYEE_ACCOUNT_NUMBER))
        .name(PAYEE_NAME)
        .reference(NEW_REFERENCE)
        .memorableName(NEW_MEMORABLE_NAME)
        .build();
  }

  private ExternalBeneficiary buildDatabaseBeneficiary() {
    return ExternalBeneficiary.builder()
        .beneficiaryId("abc123")
        .accountSortCode(String.valueOf(PAYEE_SORT_CODE))
        .accountNumber(String.valueOf(PAYEE_ACCOUNT_NUMBER))
        .name(PAYEE_NAME)
        .reference(REFERENCE)
        .memorableName(CURRENT_MEMORABLE_NAME)
        .build();
  }

  private BillPaymentInstruction buildBillPaymentInstruction(
      final NonYbsBankAccount nonYbsBankAccount) {
    return BillPaymentInstruction.builder()
        .sysId(BENEFICIARY_SYS_ID)
        .accountNumber(ACCOUNT_NUMBER)
        .nonYbsBankAccount(nonYbsBankAccount)
        .reference(REFERENCE)
        .memorableName(CURRENT_MEMORABLE_NAME)
        .build();
  }

  private NonYbsBankAccount buildNonYbsBankAccount() {
    return NonYbsBankAccount.builder()
        .sortCode(PAYEE_SORT_CODE)
        .accountNumber(PAYEE_ACCOUNT_NUMBER)
        .name(PAYEE_NAME)
        .build();
  }

  private static Stream<Arguments> memorableNameAndReferenceForTrimming() {
    return Stream.of(
        Arguments.of(
            "Memorable name: Leading white space", " " + NEW_MEMORABLE_NAME, NEW_REFERENCE),
        Arguments.of(
            "Memorable name: Trailing white space", NEW_MEMORABLE_NAME + " ", NEW_REFERENCE),
        Arguments.of(
            "Memorable name: Leading and trailing white space",
            " " + NEW_MEMORABLE_NAME + " ",
            NEW_REFERENCE),
        Arguments.of("Reference: Leading white space", NEW_MEMORABLE_NAME, " " + NEW_REFERENCE),
        Arguments.of("Reference: Trailing white space", NEW_MEMORABLE_NAME, NEW_REFERENCE + " "),
        Arguments.of(
            "Reference: Leading and trailing white space",
            NEW_MEMORABLE_NAME,
            " " + NEW_REFERENCE + " "));
  }
}
