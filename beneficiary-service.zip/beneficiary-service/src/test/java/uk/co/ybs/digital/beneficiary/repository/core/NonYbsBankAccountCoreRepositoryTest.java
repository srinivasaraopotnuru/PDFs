package uk.co.ybs.digital.beneficiary.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("beneficiaryProcessorTransactionManager")
public class NonYbsBankAccountCoreRepositoryTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-07-13T14:56:15");

  @Autowired private NonYbsBankAccountCoreRepository testSubject;

  @Autowired private TestEntityManager coreTestEntityManager;

  @Test
  void shouldFindById() {
    final FinancialInstitution institution =
        FinancialInstitution.builder()
            .sysId(1L)
            .subBranch(false)
            .sortCode(112233L)
            .bankName("Bank 1")
            .build();
    coreTestEntityManager.persistAndFlush(institution);
    coreTestEntityManager.clear();

    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccountAllFields(institution);
    final Long sysId = coreTestEntityManager.persistAndFlush(nonYbsBankAccount).getSysId();
    coreTestEntityManager.clear();

    final Optional<NonYbsBankAccount> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(nonYbsBankAccount));
    assertThat(found.get(), samePropertyValuesAs(nonYbsBankAccount));
  }

  private static NonYbsBankAccount createNonYbsBankAccountAllFields(
      final FinancialInstitution institution) {
    return NonYbsBankAccount.builder()
        .financialInstitution(institution)
        .accountNumber(1L)
        .name("TEST")
        .sortCode(112233L)
        .bankName("Bank 1")
        .startDate(NOW)
        .createdAt("0795")
        .createdBy("SAPP")
        .createdDate(NOW)
        .endDate(NOW)
        .endedAt("0795")
        .endedBy("SAPP")
        .endedDate(NOW)
        .build();
  }
}
