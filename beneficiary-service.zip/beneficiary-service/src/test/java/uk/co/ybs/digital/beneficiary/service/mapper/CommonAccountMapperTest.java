package uk.co.ybs.digital.beneficiary.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CommonAccountMapperTest {
  private CommonAccountMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new CommonAccountMapper();
  }

  @Test
  void shouldMapSortCode() {
    final String mapped = testSubject.convertAndPadSortCode(1);

    assertThat(mapped, is("000001"));
  }

  @Test
  void shouldMapInternalAccountNumberToExternalAccountNumber() {
    final String mapped = testSubject.internalToExternalAccountNumber("1234567890");

    assertThat(mapped, is("12345678"));
  }
}
