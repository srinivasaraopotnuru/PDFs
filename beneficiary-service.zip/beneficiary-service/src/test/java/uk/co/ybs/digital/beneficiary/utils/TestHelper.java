package uk.co.ybs.digital.beneficiary.utils;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.UUID;
import lombok.experimental.UtilityClass;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.SmartValidator;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.product.dto.ProductInfo;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryLimit;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryLimitResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@UtilityClass
public class TestHelper {

  public static ErrorResponse accessDeniedErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied")
                .message("Access Denied")
                .build())
        .build();
  }

  public static ErrorResponse invalidSignature(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied.InvalidRequestSignature")
                .message("Access Denied")
                .build())
        .build();
  }

  public static ErrorResponse unauthorizedErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("401 Unauthorized")
        .message("Unauthorized")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Unauthorized")
                .message("Unauthorized")
                .build())
        .build();
  }

  public static ErrorResponse internalServerError(final UUID requestId) {
    return ErrorResponse.builder(HttpStatus.INTERNAL_SERVER_ERROR)
        .id(requestId)
        .message("Internal Server Error")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode(ErrorResponse.ErrorItem.UNEXPECTED_ERROR)
                .message("Internal Server Error")
                .build())
        .build();
  }

  public static ErrorResponse notFound(final UUID requestId) {
    return ErrorResponse.builder(HttpStatus.NOT_FOUND)
        .id(requestId)
        .message("Resource not found")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Resource.NotFound")
                .message("Resource not found")
                .build())
        .build();
  }

  public static RequestMetadata buildValidRequestMetadata(final UUID requestId, final int port) {
    return buildValidRequestMetadata(requestId, port, "<jwt>");
  }

  public static RequestMetadata buildValidRequestMetadata(
      final UUID requestId, final int port, final String jwt) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .sessionId(UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60"))
        .host(InetSocketAddress.createUnresolved("beneficiaryservice.ybs.co.uk", port))
        .brandCode("YBS")
        .partyId("12462951")
        .forwardingAuth(jwt)
        .ipAddress("127.0.0.1")
        .build();
  }

  public static String readClassPathResource(final String classPathResource) {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  public static String readClassPathResource(final Resource resource) {
    try {
      return new String(Files.readAllBytes(resource.getFile().toPath()), StandardCharsets.UTF_8);
    } catch (IOException e) {
      throw new RuntimeException("Error reading " + resource, e);
    }
  }

  public static ProductInfo createProductInfo() {
    return ProductInfo.builder()
        .beneficiaries(ProductInfo.Beneficiaries.builder().external(2).internal(2).build())
        .build();
  }

  public static RequestMetadata createRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(UUID.fromString("8e112ed4-0374-47d0-aa82-427049d2dab4"))
        .sessionId(UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60"))
        .host(InetSocketAddress.createUnresolved("accountservice.ybs.co.uk", 443))
        .brandCode("YBS")
        .partyId("123456")
        .forwardingAuth("<jwt>")
        .ipAddress("12.66.53.145")
        .build();
  }

  public static ExternalBeneficiary createExternalBeneficiary(final String accountNumber) {
    return createExternalBeneficiary(accountNumber, null);
  }

  public static ExternalBeneficiary createExternalBeneficiary(
      final String accountNumber, final String beneficiaryId) {
    return ExternalBeneficiary.builder()
        .beneficiaryId(beneficiaryId)
        .accountNumber(accountNumber)
        .accountSortCode("112233")
        .memorableName("MEM")
        .name("NAME")
        .reference("REF")
        .build();
  }

  public static InternalBeneficiary createInternalBeneficiary(final String accountNumber) {
    return InternalBeneficiary.builder().accountNumber(accountNumber).build();
  }

  public static ExternalBeneficiaryInformation createExternalBeneficiaryInformation(
      final String accountNumber, final String payeeAccountNumber) {
    return ExternalBeneficiaryInformation.builder()
        .payeeName("NAME")
        .payeeSortCode("112233")
        .reference("REF")
        .memorableName("MEM")
        .payeeAccountNumber(payeeAccountNumber)
        .accountNumber(accountNumber)
        .build();
  }

  public static InternalBeneficiaryInformation createInternalBeneficiaryInformation(
      final String accountNumber, final String payeeAccountNumber) {
    return InternalBeneficiaryInformation.builder()
        .payeeAccountNumber(payeeAccountNumber)
        .accountNumber(accountNumber)
        .build();
  }

  public static ExternalUpdateBeneficiaryInformation createExternalUpdateBeneficiaryInformation() {
    return ExternalUpdateBeneficiaryInformation.builder()
        .reference("NEW REF")
        .memorableName("NEW MEM")
        .build();
  }

  public static BindingResult validateRequest(
      final Object request, final SmartValidator validator, final Object... validationHints) {
    final BindingResult bindingResult = new MapBindingResult(new HashMap<>(), "request");
    validator.validate(request, bindingResult, validationHints);
    return bindingResult;
  }

  public static BeneficiaryLimitResponse buildBeneficiaryLimit() {
    return BeneficiaryLimitResponse.builder()
        .external(BeneficiaryLimit.builder().limitReached(false).count(5).maxPermitted(6).build())
        .internal(BeneficiaryLimit.builder().limitReached(false).count(5).maxPermitted(6).build())
        .build();
  }
}
