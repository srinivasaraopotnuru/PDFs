package uk.co.ybs.digital.beneficiary.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;

import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.model.core.ItInstruction;
import uk.co.ybs.digital.beneficiary.repository.core.ItInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class CreateInternalBeneficiaryProcessorTest {

  private static final long ACCOUNT_NUMBER = 1L;
  private static final String ACCOUNT_NUMBER_STRING = String.valueOf(ACCOUNT_NUMBER);
  private static final long PAYEE_ACCOUNT_NUMBER = 1234567890L;
  private static final String PAYEE_ACCOUNT_NUMBER_STRING = "1234567890";
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final int BENEFICIARIES_LIMIT = 4;

  @Mock private BeneficiaryInformationFactory beneficiaryInformationFactory;
  @Mock private BeneficiaryAuditor beneficiaryAuditor;
  @Mock private ItInstructionCoreRepository itInstructionCoreRepository;
  @InjectMocks private CreateInternalBeneficiaryProcessor testSubject;

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfLimitIsExceeded() {
    executeShouldThrowBeneficiaryValidationExceptionIfLimitIsExceeded(
        BENEFICIARIES_LIMIT, BENEFICIARIES_LIMIT);
  }

  private void executeShouldThrowBeneficiaryValidationExceptionIfLimitIsExceeded(
      final Integer savedLimit, final int expectedLimit) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final InternalBeneficiary beneficiary =
        TestHelper.createInternalBeneficiary(PAYEE_ACCOUNT_NUMBER_STRING);

    when(itInstructionCoreRepository.findActiveInternalBeneficiaries(ACCOUNT_NUMBER, PROCESS_TIME))
        .thenReturn(expectedLimit);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.execute(
                    new BeneficiaryRequestArguments<>(
                        ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, savedLimit)));

    assertThat(
        exception.getMessage(),
        is("Internal beneficiary limit exceeded for account: " + ACCOUNT_NUMBER_STRING));
    verify(itInstructionCoreRepository, never()).saveAndFlush(any());
    verify(itInstructionCoreRepository, never())
        .updateInternalBeneficiaryAuthenticRecord(anyLong());
  }

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfBeneficiaryAlreadyExists() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final InternalBeneficiary beneficiary =
        TestHelper.createInternalBeneficiary(PAYEE_ACCOUNT_NUMBER_STRING);

    when(itInstructionCoreRepository.findExistingInternalBeneficiaries(
            ACCOUNT_NUMBER, PAYEE_ACCOUNT_NUMBER, PROCESS_TIME))
        .thenReturn(1);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.execute(
                    new BeneficiaryRequestArguments<>(
                        ACCOUNT_NUMBER,
                        requestMetadata,
                        PROCESS_TIME,
                        beneficiary,
                        BENEFICIARIES_LIMIT)));

    assertThat(
        exception.getMessage(),
        is("Requested beneficiary already exists for account: " + ACCOUNT_NUMBER_STRING));
    verify(itInstructionCoreRepository, never()).saveAndFlush(any());
    verify(itInstructionCoreRepository, never())
        .updateInternalBeneficiaryAuthenticRecord(anyLong());
  }

  @ParameterizedTest
  @ValueSource(ints = {0, 1, BENEFICIARIES_LIMIT - 1})
  void executeShouldCreateBeneficiary(final int numberOfExistingBeneficiaries) {
    executeShouldCreateBeneficiary(BENEFICIARIES_LIMIT, numberOfExistingBeneficiaries);
  }

  private void executeShouldCreateBeneficiary(
      final Integer savedLimit, final int numberOfExistingBeneficiaries) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final InternalBeneficiary beneficiary =
        TestHelper.createInternalBeneficiary(PAYEE_ACCOUNT_NUMBER_STRING);

    when(itInstructionCoreRepository.findActiveInternalBeneficiaries(ACCOUNT_NUMBER, PROCESS_TIME))
        .thenReturn(numberOfExistingBeneficiaries);

    final ItInstruction expectedInstruction =
        ItInstruction.builder()
            .debtorAccountNumber(ACCOUNT_NUMBER)
            .code("ATM")
            .availableAtm(true)
            .creditorAccountNumber(PAYEE_ACCOUNT_NUMBER)
            .startDate(PROCESS_TIME)
            .status("ACTIVE")
            .createdAt("0795")
            .createdBy("SAPP")
            .createdDate(PROCESS_TIME)
            .build();

    testSubject.execute(
        new BeneficiaryRequestArguments<>(
            ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, savedLimit));

    verify(itInstructionCoreRepository)
        .saveAndFlush(argThat(samePropertyValuesAs(expectedInstruction)));
    verify(itInstructionCoreRepository).updateInternalBeneficiaryAuthenticRecord(ACCOUNT_NUMBER);
  }

  @Test
  void auditSuccessShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final InternalBeneficiary beneficiary =
        TestHelper.createInternalBeneficiary(PAYEE_ACCOUNT_NUMBER_STRING);

    final InternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createInternalBeneficiaryInformation(
            ACCOUNT_NUMBER_STRING, PAYEE_ACCOUNT_NUMBER_STRING);
    when(beneficiaryInformationFactory.buildInternal(ACCOUNT_NUMBER, beneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditSuccess(
        new BeneficiaryRequestArguments<>(
            ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, BENEFICIARIES_LIMIT));

    verify(beneficiaryAuditor).auditBeneficiaryCreateSuccess(expectedAuditBody, requestMetadata);
  }

  @Test
  void auditFailureShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final InternalBeneficiary beneficiary =
        TestHelper.createInternalBeneficiary(PAYEE_ACCOUNT_NUMBER_STRING);

    final InternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createInternalBeneficiaryInformation(
            ACCOUNT_NUMBER_STRING, PAYEE_ACCOUNT_NUMBER_STRING);
    when(beneficiaryInformationFactory.buildInternal(ACCOUNT_NUMBER, beneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditFailure(
        new BeneficiaryRequestArguments<>(
            ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, BENEFICIARIES_LIMIT),
        DUPLICATE);

    verify(beneficiaryAuditor)
        .auditBeneficiaryCreateFailure(expectedAuditBody, "Duplicate Beneficiary", requestMetadata);
  }
}
