package uk.co.ybs.digital.beneficiary.e2e;

import static uk.co.ybs.digital.beneficiary.e2e.TestData.DEBTOR_ACCOUNT_NUMBER;
import static uk.co.ybs.digital.beneficiary.e2e.TestData.PARTY_ID;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Status.FAILED;

import java.time.Clock;
import java.time.LocalDateTime;
import javax.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@RequiredArgsConstructor
public class WorkLogHelper {
  private static final int BENEFICIARY_LIMIT = 99;

  private final TransactionTemplate transactionTemplate;
  private final TestEntityManager testEntityManager;
  private final Clock clock;

  private WorkLog createWorkLogEntry(
      final long sysId,
      final WorkLog.Operation operation,
      final Beneficiary beneficiary,
      final RequestMetadata metadata) {
    return WorkLog.builder()
        .accountNumber(DEBTOR_ACCOUNT_NUMBER)
        .createdBy(PARTY_ID)
        .createdDate(LocalDateTime.now(clock))
        .message(
            BeneficiaryRequest.builder()
                .payload(
                    BeneficiaryRequest.Payload.builder()
                        .sysId(sysId)
                        .beneficiariesLimit(BENEFICIARY_LIMIT)
                        .beneficiary(beneficiary)
                        .build())
                .metadata(metadata)
                .build())
        .operation(operation)
        .status(FAILED)
        .build();
  }

  public void setupWorkLog(
      final long sysId,
      final WorkLog.Operation operation,
      final Beneficiary beneficiary,
      final RequestMetadata metadata) {
    transactionTemplate.executeWithoutResult(
        status -> {
          testEntityManager.persistAndFlush(
              createWorkLogEntry(sysId, operation, beneficiary, metadata));
        });
  }

  public void clearDb() {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager digitalAccountEntityManager = testEntityManager.getEntityManager();
          digitalAccountEntityManager.createQuery("delete from WorkLog").executeUpdate();
        });
  }
}
