package uk.co.ybs.digital.beneficiary.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.model.core.Metadata;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("beneficiaryProcessorTransactionManager")
class MetadataRepositoryTest {

  private static final long SYS_ID = 1L;
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-12-07T13:31:30");

  @Autowired MetadataRepository testSubject;

  @Autowired TestEntityManager coreTestEntityManager;

  @Test
  void shouldFindById() {
    final Metadata metadata = Metadata.builder().sysId(SYS_ID).created(NOW).build();

    coreTestEntityManager.persistAndFlush(metadata);
    coreTestEntityManager.clear();

    final Optional<Metadata> found = testSubject.findById(SYS_ID);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(metadata));
  }
}
