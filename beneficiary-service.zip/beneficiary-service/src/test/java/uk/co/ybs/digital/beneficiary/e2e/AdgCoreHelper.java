package uk.co.ybs.digital.beneficiary.e2e;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.beneficiary.model.adgcore.AccountNumber;
import uk.co.ybs.digital.beneficiary.model.adgcore.ActivityPlayer;
import uk.co.ybs.digital.beneficiary.model.adgcore.ActivityType;
import uk.co.ybs.digital.beneficiary.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.model.adgcore.SavingProduct;

@RequiredArgsConstructor
public class AdgCoreHelper {
  private final TransactionTemplate transactionTemplate;
  private final TestEntityManager testEntityManager;
  private final Clock clock;

  public static ItInstruction createItInstruction(
      final long sysId,
      final long debtorAccountNumber,
      final long creditorAccountNumber,
      final boolean ended) {
    final ItInstruction.ItInstructionBuilder builder =
        ItInstruction.builder()
            .sysId(sysId)
            .debtorAccountNumber(debtorAccountNumber)
            .creditorAccountNumber(creditorAccountNumber)
            .availableAtm(true)
            .status("ACTIVE");

    if (ended) {
      builder.endDate(TestData.EXISTING_BENEFICIARY_START_DATE);
    }

    return builder.build();
  }

  public void setUpInternalBeneficiary(
      final long sysId,
      final long debtorAccountNumber,
      final long creditorAccountNumber,
      final boolean ended) {
    transactionTemplate.executeWithoutResult(
        status ->
            testEntityManager.persistAndFlush(
                createItInstruction(sysId, debtorAccountNumber, creditorAccountNumber, ended)));
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public void setUpExternalBeneficiary(
      final Long sysId,
      final String debtorAccountNumber,
      final String sortCode,
      final String creditorBeneficiaryAccountNumber,
      final String reference,
      final String name,
      final String memorableName,
      final boolean ended) {
    transactionTemplate.executeWithoutResult(
        status -> {
          final NonYbsBankAccount account =
              testEntityManager.persist(
                  new NonYbsBankAccount(
                      sysId,
                      Long.parseLong(creditorBeneficiaryAccountNumber),
                      Long.parseLong(sortCode),
                      name));
          final LocalDateTime endDate = ended ? TestData.EXISTING_BENEFICIARY_START_DATE : null;
          testEntityManager.persistAndFlush(
              new BillPaymentInstruction(
                  sysId,
                  account,
                  Long.parseLong(debtorAccountNumber),
                  "ACTIVE",
                  true,
                  reference,
                  endDate,
                  memorableName));
        });
  }

  public AccountAccessRequiredEntities setUpAccountAccessRequiredEntities(
      final Long accountNumberRequired, final String... activityTypeGroupCodes) {
    final SavingProduct savingProductRequiredEntity = setUpSavingProduct();
    final AccountNumber accountNumberRequiredEntity =
        setUpAccountNumber(accountNumberRequired, savingProductRequiredEntity);

    final Set<String> allActivityTypeGroupCodes =
        new HashSet<>(Arrays.asList(activityTypeGroupCodes));
    allActivityTypeGroupCodes.add(TestData.ACTIVITY_GROUP_CODE_AISP);

    final ActivityType activityType =
        setUpActivityType(allActivityTypeGroupCodes.toArray(new String[] {}));
    setUpActivityPlayer(activityType, 1L, accountNumberRequired);

    return new AccountAccessRequiredEntities(
        savingProductRequiredEntity, accountNumberRequiredEntity);
  }

  public AccountNumber setUpAccountNumber(
      final Long accountNumber, final SavingProduct savingProduct) {
    return transactionTemplate.execute(
        status ->
            testEntityManager.persistAndFlush(
                new AccountNumber(
                    accountNumber, AccountNumber.TABLE_ID_SAVACC, savingProduct.getSysid())));
  }

  private SavingProduct setUpSavingProduct() {
    return setUpSavingProduct(TestData.PRODUCT_SYS_ID);
  }

  private SavingProduct setUpSavingProduct(final Long productSysId) {
    return transactionTemplate.execute(
        status -> testEntityManager.persistAndFlush(new SavingProduct(productSysId, "YBS")));
  }

  @SuppressWarnings("PMD.AvoidInstantiatingObjectsInLoops")
  private ActivityType setUpActivityType(final String... activityTypeGroupCodes) {
    return transactionTemplate.execute(
        status -> {
          final ActivityType type =
              testEntityManager.persist(
                  new ActivityType(
                      TestData.ACTIVITY_TYPE_CODE_MHLDRS,
                      LocalDateTime.now(clock).minusDays(1L),
                      null));
          for (String code : activityTypeGroupCodes) {
            testEntityManager.persist(
                new ActivityTypeGroup(code, type, LocalDateTime.now(clock).minusDays(1L), null));
          }
          testEntityManager.flush();
          return type;
        });
  }

  private void setUpActivityPlayer(
      final ActivityType activityType, final Long sysId, final Long accountNumber) {
    transactionTemplate.execute(
        status ->
            testEntityManager.persistAndFlush(
                new ActivityPlayer(
                    sysId,
                    TestData.ACTIVITY_PLAYER_TABLE_ID,
                    accountNumber,
                    Long.valueOf(TestData.CANONICAL_PARTY_ID),
                    activityType,
                    LocalDateTime.now(clock).minusSeconds(1L),
                    null)));
  }

  @lombok.Value
  public static class AccountAccessRequiredEntities {
    SavingProduct savingProduct;
    AccountNumber accountNumber;
  }

  public void clearDb() {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager entityManager = testEntityManager.getEntityManager();
          entityManager.createQuery("delete from ActivityPlayer").executeUpdate();
          entityManager.createQuery("delete from ActivityTypeGroup").executeUpdate();
          entityManager.createQuery("delete from ActivityType").executeUpdate();
          entityManager.createQuery("delete from BillPaymentInstruction").executeUpdate();
          entityManager.createQuery("delete from ItInstruction").executeUpdate();
          entityManager.createQuery("delete from NonYbsBankAccount").executeUpdate();
          entityManager.createQuery("delete from SavingTransaction").executeUpdate();
          entityManager.createQuery("delete from AccountNumber").executeUpdate();
          entityManager.createQuery("delete from SavingProduct").executeUpdate();
        });
  }
}
