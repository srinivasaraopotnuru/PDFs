package uk.co.ybs.digital.beneficiary.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;

import java.net.InetSocketAddress;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.exception.AccountServiceException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.exception.InternalBeneficiaryUpdateNotSupportedException;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation;
import uk.co.ybs.digital.beneficiary.repository.adgcore.BillPaymentInstructionRepository;
import uk.co.ybs.digital.beneficiary.repository.adgcore.ItInstructionRepository;
import uk.co.ybs.digital.beneficiary.repository.digitalbeneficiary.WorkLogRepository;
import uk.co.ybs.digital.beneficiary.service.account.AccountService;
import uk.co.ybs.digital.beneficiary.service.account.dto.AccountDetails;
import uk.co.ybs.digital.beneficiary.service.account.dto.Product;
import uk.co.ybs.digital.beneficiary.service.mapper.BeneficiaryListMapper;
import uk.co.ybs.digital.beneficiary.service.product.ProductService;
import uk.co.ybs.digital.beneficiary.service.product.dto.ProductInfo;
import uk.co.ybs.digital.beneficiary.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.beneficiary.service.utilities.ProductBeneficiaryLimitValidator;
import uk.co.ybs.digital.beneficiary.service.utilities.SoaBeneficiaryValidator;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.BeneficiaryLimitResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.beneficiary.web.dto.TestBeneficiary;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@ExtendWith(MockitoExtension.class)
class BeneficiaryServiceTest {

  private static final Long ACCOUNT_NUMBER = 123L;
  private static final String PARTY_ID = "123456";
  private static final String BRAND_YBS = "YBS";
  private static final String PRODUCT_ID = "INTSAV";
  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-05-26T13:45:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);
  private static final LocalDateTime ONE_DAY_AGO = NOW.minusDays(1L);
  private static final int BENEFICIARIES_LIMIT = 2;
  public static final String BENEFICIARY_ID_123ABC = "123abc";
  public static final String BENEFICIARY_ID = "beneficiaryId";

  private BeneficiaryService beneficiaryService;

  @Mock private AccountAccessValidator accountAccessValidator;
  @Mock private SoaBeneficiaryValidator soaBeneficiaryValidator;
  @Mock private ProductService productService;
  @Mock private BillPaymentInstructionRepository billPaymentInstructionRepository;
  @Mock private ItInstructionRepository itInstructionRepository;
  @Mock private WorkLogRepository workLogRepository;
  @Mock private BeneficiaryListMapper beneficiaryListMapper;
  @Mock private BeneficiaryServiceProperties beneficiaryServiceProperties;
  @Mock private ScaManager scaManager;
  @Mock private AccountService accountService;
  @Mock private ProductBeneficiaryLimitValidator productBeneficiaryLimitValidator;

  @BeforeEach
  void setUp() {
    beneficiaryService =
        new BeneficiaryService(
            accountAccessValidator,
            soaBeneficiaryValidator,
            productService,
            billPaymentInstructionRepository,
            itInstructionRepository,
            workLogRepository,
            beneficiaryListMapper,
            beneficiaryServiceProperties,
            accountService,
            scaManager,
            CLOCK,
            productBeneficiaryLimitValidator);
  }

  @Test
  void getBeneficiariesShouldRetrieveAccountBeneficiariesAndMapResponse() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();

    final Collection<BillPaymentInstruction> externalInstructions = new ArrayList<>();
    when(billPaymentInstructionRepository.findActiveExternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(externalInstructions);

    final Collection<ItInstruction> internalInstructions = new ArrayList<>();
    when(itInstructionRepository.findActiveInternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(internalInstructions);

    final Collection<WorkLog> workLogs = new ArrayList<>();
    when(workLogRepository.findRequestsAfterDate(ONE_DAY_AGO, ACCOUNT_NUMBER)).thenReturn(workLogs);

    final List<Beneficiary> expectedBeneficiaries =
        Arrays.asList(
            createInternalBeneficiary(BENEFICIARY_ID_123ABC), createInternalBeneficiary("223abc"));
    when(beneficiaryListMapper.map(
            same(externalInstructions), same(internalInstructions), same(workLogs)))
        .thenReturn(expectedBeneficiaries);

    final List<Beneficiary> actualBeneficiaries =
        beneficiaryService.getBeneficiaries(String.valueOf(ACCOUNT_NUMBER), requestMetadata);
    assertThat(actualBeneficiaries, sameInstance(expectedBeneficiaries));
    verify(accountAccessValidator)
        .validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW);
  }

  @Test
  void getBeneficiaryShouldRetrieveAccountBeneficiariesAndMapResponse() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();

    final Collection<BillPaymentInstruction> externalInstructions = new ArrayList<>();
    when(billPaymentInstructionRepository.findActiveExternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(externalInstructions);

    final Collection<ItInstruction> internalInstructions = new ArrayList<>();
    when(itInstructionRepository.findActiveInternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(internalInstructions);

    final Collection<WorkLog> workLogs = new ArrayList<>();
    when(workLogRepository.findRequestsAfterDate(ONE_DAY_AGO, ACCOUNT_NUMBER)).thenReturn(workLogs);

    final Beneficiary expectedBeneficiary = createInternalBeneficiary(BENEFICIARY_ID_123ABC);
    final List<Beneficiary> expectedBeneficiaries =
        Arrays.asList(createInternalBeneficiary("223abc"), expectedBeneficiary);
    when(beneficiaryListMapper.map(
            same(externalInstructions), same(internalInstructions), same(workLogs)))
        .thenReturn(expectedBeneficiaries);

    final Beneficiary beneficiary =
        beneficiaryService.getBeneficiary(
            String.valueOf(ACCOUNT_NUMBER), BENEFICIARY_ID_123ABC, requestMetadata);
    assertThat(beneficiary, sameInstance(expectedBeneficiary));
    verify(accountAccessValidator)
        .validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW);
  }

  @Test
  void getBeneficiaryShouldHandleBeneficiaryNotFound() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();

    final List<Beneficiary> expectedBeneficiaries =
        Collections.singletonList(createInternalBeneficiary(BENEFICIARY_ID_123ABC));
    when(beneficiaryListMapper.map(any(), any(), any())).thenReturn(expectedBeneficiaries);

    final AccountResourceNotFoundException exception =
        assertThrows(
            AccountResourceNotFoundException.class,
            () ->
                beneficiaryService.getBeneficiary(
                    String.valueOf(ACCOUNT_NUMBER), "223abc", requestMetadata));
    assertThat(
        exception.getMessage(),
        is(
            "Failed to find beneficiary for id [223abc] and account number ["
                + ACCOUNT_NUMBER
                + "]"));
  }

  @Test
  void createExternalBeneficiaryShouldCreateRequest() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    final ProductInfo productInfo = createProductInfo();
    final AccountDetails accountDetails = createAccountServiceResponse();

    when(accountService.getAccount(String.valueOf(ACCOUNT_NUMBER), requestMetadata))
        .thenReturn(accountDetails);

    when(productService.getProductInfo(PRODUCT_ID, requestMetadata)).thenReturn(productInfo);

    when(soaBeneficiaryValidator.validateExternalCreate(
            String.valueOf(ACCOUNT_NUMBER),
            mappedBeneficiaries,
            productInfo,
            beneficiary,
            requestMetadata))
        .thenReturn(BENEFICIARIES_LIMIT);

    beneficiaryService.createBeneficiaryWithoutSca(
        String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata);

    verify(accountAccessValidator)
        .validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW);

    verifyNoInteractions(scaManager);
    verifyNoMoreInteractions(soaBeneficiaryValidator);

    final BeneficiaryRequest expectedMessage =
        BeneficiaryRequest.builder()
            .payload(
                BeneficiaryRequest.Payload.builder()
                    .beneficiariesLimit(BENEFICIARIES_LIMIT)
                    .beneficiary(beneficiary)
                    .build())
            .metadata(requestMetadata)
            .build();

    verifyWorkLogSaved(expectedMessage, Operation.CREATE);
  }

  @Test
  void createBeneficiaryShouldThrowAccountServiceException() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();

    doThrow(new AccountServiceException("Error calling account service"))
        .when(accountService)
        .getAccount(any(), any());

    final AccountServiceException exception =
        assertThrows(
            AccountServiceException.class,
            () ->
                beneficiaryService.createBeneficiaryWithoutSca(
                    String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata));
    assertThat(exception.getMessage(), is("Error calling account service"));
    assertThat(exception.getCause(), not(instanceOf(AccountServiceException.class)));
  }

  @Test
  void updateExternalBeneficiaryShouldCreateRequest() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final ScaCredentials scaCredentials = buildScaCredentials();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);
    final long currentBeneficiarySysId = 1L;

    stubGetBeneficiaries(mappedBeneficiaries);

    final ExternalBeneficiary dbRecord =
        beneficiary.toBuilder().sysId(currentBeneficiarySysId).build();
    when(soaBeneficiaryValidator.validateExternalUpdate(
            String.valueOf(ACCOUNT_NUMBER), mappedBeneficiaries, beneficiary, requestMetadata))
        .thenReturn(dbRecord);

    beneficiaryService.updateBeneficiary(
        String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata, scaCredentials);

    verify(accountAccessValidator)
        .validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW);

    verify(soaBeneficiaryValidator)
        .validateExternalUpdate(
            String.valueOf(ACCOUNT_NUMBER), mappedBeneficiaries, beneficiary, requestMetadata);

    verify(scaManager).validateSca(Operation.UPDATE, beneficiary, requestMetadata, scaCredentials);

    verifyNoMoreInteractions(accountService);
    verifyNoInteractions(productService);
    verifyNoMoreInteractions(soaBeneficiaryValidator);

    final BeneficiaryRequest expectedMessage =
        BeneficiaryRequest.builder()
            .payload(
                BeneficiaryRequest.Payload.builder()
                    .sysId(currentBeneficiarySysId)
                    .beneficiary(beneficiary)
                    .build())
            .metadata(requestMetadata)
            .build();

    verifyWorkLogSaved(expectedMessage, Operation.UPDATE);
  }

  @Test
  void updateExternalBeneficiaryWithoutScaShouldCreateRequest() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);
    final long currentBeneficiarySysId = 1L;

    stubGetBeneficiaries(mappedBeneficiaries);

    final ExternalBeneficiary dbRecord =
        beneficiary.toBuilder().sysId(currentBeneficiarySysId).build();
    when(soaBeneficiaryValidator.validateExternalUpdate(
            String.valueOf(ACCOUNT_NUMBER), mappedBeneficiaries, beneficiary, requestMetadata))
        .thenReturn(dbRecord);

    beneficiaryService.updateBeneficiaryWithoutSca(
        String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata);

    verify(accountAccessValidator)
        .validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW);

    verify(soaBeneficiaryValidator)
        .validateExternalUpdate(
            String.valueOf(ACCOUNT_NUMBER), mappedBeneficiaries, beneficiary, requestMetadata);

    verifyNoMoreInteractions(accountService);
    verifyNoMoreInteractions(soaBeneficiaryValidator);
    verifyNoInteractions(productService);
    verifyNoInteractions(scaManager);

    final BeneficiaryRequest expectedMessage =
        BeneficiaryRequest.builder()
            .payload(
                BeneficiaryRequest.Payload.builder()
                    .sysId(currentBeneficiarySysId)
                    .beneficiary(beneficiary)
                    .build())
            .metadata(requestMetadata)
            .build();

    verifyWorkLogSaved(expectedMessage, Operation.UPDATE);
  }

  @Test
  void createExternalBeneficiaryShouldNotInsertRecordIfBlacklisted() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    final ProductInfo productInfo = createProductInfo();
    final AccountDetails accountDetails = createAccountServiceResponse();

    when(accountService.getAccount(String.valueOf(ACCOUNT_NUMBER), requestMetadata))
        .thenReturn(accountDetails);

    when(productService.getProductInfo(PRODUCT_ID, requestMetadata)).thenReturn(productInfo);

    when(soaBeneficiaryValidator.validateExternalCreate(
            String.valueOf(ACCOUNT_NUMBER),
            mappedBeneficiaries,
            productInfo,
            beneficiary,
            requestMetadata))
        .thenReturn(BENEFICIARIES_LIMIT);

    final List<String> blacklisted = Collections.singletonList(String.valueOf(ACCOUNT_NUMBER));
    when(beneficiaryServiceProperties.getAccountNumberBlacklist()).thenReturn(blacklisted);

    beneficiaryService.createBeneficiaryWithoutSca(
        String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata);

    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void updateExternalBeneficiaryShouldNotInsertRecordIfBlacklisted() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    final ExternalBeneficiary dbRecord = beneficiary.toBuilder().sysId(1L).build();
    when(soaBeneficiaryValidator.validateExternalUpdate(
            String.valueOf(ACCOUNT_NUMBER), mappedBeneficiaries, beneficiary, requestMetadata))
        .thenReturn(dbRecord);

    final List<String> blacklisted = Collections.singletonList(String.valueOf(ACCOUNT_NUMBER));
    when(beneficiaryServiceProperties.getAccountNumberBlacklist()).thenReturn(blacklisted);

    beneficiaryService.updateBeneficiary(
        String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata, buildScaCredentials());

    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void updateExternalBeneficiaryWithoutScaShouldNotInsertRecordIfBlacklisted() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    final ExternalBeneficiary dbRecord = beneficiary.toBuilder().sysId(1L).build();
    when(soaBeneficiaryValidator.validateExternalUpdate(
            String.valueOf(ACCOUNT_NUMBER), mappedBeneficiaries, beneficiary, requestMetadata))
        .thenReturn(dbRecord);

    final List<String> blacklisted = Collections.singletonList(String.valueOf(ACCOUNT_NUMBER));
    when(beneficiaryServiceProperties.getAccountNumberBlacklist()).thenReturn(blacklisted);

    beneficiaryService.updateBeneficiaryWithoutSca(
        String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata);

    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void createExternalBeneficiaryShouldThrowValidationExceptionIfValidationFails() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    final AccountDetails accountDetails = createAccountServiceResponse();

    when(accountService.getAccount(String.valueOf(ACCOUNT_NUMBER), requestMetadata))
        .thenReturn(accountDetails);

    final ProductInfo productInfo = createProductInfo();
    when(productService.getProductInfo(PRODUCT_ID, requestMetadata)).thenReturn(productInfo);

    doThrow(BeneficiaryValidationException.class)
        .when(soaBeneficiaryValidator)
        .validateExternalCreate(any(), any(), any(), any(), any());

    assertThrows(
        BeneficiaryValidationException.class,
        () ->
            beneficiaryService.createBeneficiaryWithoutSca(
                String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata));

    verifyNoInteractions(scaManager);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void updateExternalBeneficiaryShouldThrowValidationExceptionIfValidationFails() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    doThrow(BeneficiaryValidationException.class)
        .when(soaBeneficiaryValidator)
        .validateExternalUpdate(any(), any(), any(), any());

    assertThrows(
        BeneficiaryValidationException.class,
        () ->
            beneficiaryService.updateBeneficiary(
                String.valueOf(ACCOUNT_NUMBER),
                beneficiary,
                requestMetadata,
                buildScaCredentials()));

    verifyNoInteractions(scaManager);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void updateExternalBeneficiaryWithoutScaShouldThrowValidationExceptionIfValidationFails() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    doThrow(BeneficiaryValidationException.class)
        .when(soaBeneficiaryValidator)
        .validateExternalUpdate(any(), any(), any(), any());

    assertThrows(
        BeneficiaryValidationException.class,
        () ->
            beneficiaryService.updateBeneficiaryWithoutSca(
                String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata));

    verifyNoInteractions(scaManager);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void createInternalBeneficiaryShouldCreateRequest() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final InternalBeneficiary beneficiary = createInternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    final AccountDetails accountDetails = createAccountServiceResponse();

    when(accountService.getAccount(String.valueOf(ACCOUNT_NUMBER), requestMetadata))
        .thenReturn(accountDetails);

    final ProductInfo productInfo = createProductInfo();
    when(productService.getProductInfo(PRODUCT_ID, requestMetadata)).thenReturn(productInfo);

    when(soaBeneficiaryValidator.validateInternalCreate(
            String.valueOf(ACCOUNT_NUMBER),
            mappedBeneficiaries,
            productInfo,
            beneficiary,
            requestMetadata))
        .thenReturn(BENEFICIARIES_LIMIT);

    beneficiaryService.createBeneficiaryWithoutSca(
        String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata);

    verify(accountAccessValidator)
        .validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW);
    verifyNoInteractions(scaManager);
    verify(soaBeneficiaryValidator)
        .validateInternalCreate(
            String.valueOf(ACCOUNT_NUMBER),
            mappedBeneficiaries,
            productInfo,
            beneficiary,
            requestMetadata);
    verifyNoMoreInteractions(soaBeneficiaryValidator);

    final BeneficiaryRequest expectedMessage =
        BeneficiaryRequest.builder()
            .payload(
                BeneficiaryRequest.Payload.builder()
                    .beneficiariesLimit(BENEFICIARIES_LIMIT)
                    .beneficiary(beneficiary)
                    .build())
            .metadata(requestMetadata)
            .build();

    verifyWorkLogSaved(expectedMessage, Operation.CREATE);
  }

  @Test
  void createInternalBeneficiaryShouldNotInsertRecordIfBlacklisted() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final InternalBeneficiary beneficiary = createInternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    final AccountDetails accountDetails = createAccountServiceResponse();

    when(accountService.getAccount(String.valueOf(ACCOUNT_NUMBER), requestMetadata))
        .thenReturn(accountDetails);

    final ProductInfo productInfo = createProductInfo();
    when(productService.getProductInfo(PRODUCT_ID, requestMetadata)).thenReturn(productInfo);

    final List<String> blacklisted = Collections.singletonList(String.valueOf(ACCOUNT_NUMBER));
    when(beneficiaryServiceProperties.getAccountNumberBlacklist()).thenReturn(blacklisted);

    beneficiaryService.createBeneficiaryWithoutSca(
        String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata);

    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void createInternalBeneficiaryShouldThrowValidationExceptionIfValidationFails() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final InternalBeneficiary beneficiary = createInternalBeneficiary();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    final AccountDetails accountDetails = createAccountServiceResponse();

    when(accountService.getAccount(String.valueOf(ACCOUNT_NUMBER), requestMetadata))
        .thenReturn(accountDetails);

    final ProductInfo productInfo = createProductInfo();
    when(productService.getProductInfo(PRODUCT_ID, requestMetadata)).thenReturn(productInfo);

    doThrow(BeneficiaryValidationException.class)
        .when(soaBeneficiaryValidator)
        .validateInternalCreate(
            String.valueOf(ACCOUNT_NUMBER),
            mappedBeneficiaries,
            productInfo,
            beneficiary,
            requestMetadata);

    assertThrows(
        BeneficiaryValidationException.class,
        () ->
            beneficiaryService.createBeneficiaryWithoutSca(
                String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata));

    verifyNoInteractions(scaManager);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void updateInternalBeneficiaryShouldThrowInternalBeneficiaryUpdateNotSupportedException() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final InternalBeneficiary beneficiary = createInternalBeneficiary();

    final InternalBeneficiaryUpdateNotSupportedException exception =
        assertThrows(
            InternalBeneficiaryUpdateNotSupportedException.class,
            () ->
                beneficiaryService.updateBeneficiary(
                    String.valueOf(ACCOUNT_NUMBER),
                    beneficiary,
                    requestMetadata,
                    buildScaCredentials()));

    assertThat(
        exception.getMessage(),
        is(
            "Internal beneficiary updates are not supported: InternalBeneficiary(super=Beneficiary(beneficiaryId=null, sysId=null), accountNumber=1234567890)"));

    verifyNoInteractions(soaBeneficiaryValidator);
    verifyNoInteractions(scaManager);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void
      updateInternalBeneficiaryWithoutScaShouldThrowInternalBeneficiaryUpdateNotSupportedException() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final InternalBeneficiary beneficiary = createInternalBeneficiary();

    final InternalBeneficiaryUpdateNotSupportedException exception =
        assertThrows(
            InternalBeneficiaryUpdateNotSupportedException.class,
            () ->
                beneficiaryService.updateBeneficiaryWithoutSca(
                    String.valueOf(ACCOUNT_NUMBER), beneficiary, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(
            "Internal beneficiary updates are not supported: InternalBeneficiary(super=Beneficiary(beneficiaryId=null, sysId=null), accountNumber=1234567890)"));

    verifyNoInteractions(soaBeneficiaryValidator);
    verifyNoInteractions(scaManager);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void deleteBeneficiaryShouldCreateRequest() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final String requestBeneficiaryId = BENEFICIARY_ID;
    final long currentBeneficiarySysId = 1L;
    final Beneficiary beneficiary =
        new TestBeneficiary(requestBeneficiaryId, currentBeneficiarySysId);
    final ScaCredentials scaCredentials = buildScaCredentials();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);
    when(soaBeneficiaryValidator.validateDelete(
            mappedBeneficiaries,
            requestBeneficiaryId,
            String.valueOf(ACCOUNT_NUMBER),
            requestMetadata))
        .thenReturn(beneficiary);

    beneficiaryService.deleteBeneficiary(
        String.valueOf(ACCOUNT_NUMBER), requestBeneficiaryId, requestMetadata, scaCredentials);

    verify(accountAccessValidator)
        .validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW);
    verify(scaManager)
        .validateDeleteSca(
            WorkLog.Operation.DELETE,
            beneficiary.getBeneficiaryId(),
            requestMetadata,
            scaCredentials);
    verifyNoMoreInteractions(soaBeneficiaryValidator);

    final BeneficiaryRequest expectedMessage =
        BeneficiaryRequest.builder()
            .payload(
                BeneficiaryRequest.Payload.builder()
                    .beneficiary(beneficiary)
                    .sysId(currentBeneficiarySysId)
                    .build())
            .metadata(requestMetadata)
            .build();

    verifyWorkLogSaved(expectedMessage, Operation.DELETE);
  }

  @Test
  void deleteBeneficiaryWithoutScaShouldCreateRequestWithoutSca() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final String requestBeneficiaryId = BENEFICIARY_ID;
    final long currentBeneficiarySysId = 1L;
    final Beneficiary beneficiary =
        new TestBeneficiary(requestBeneficiaryId, currentBeneficiarySysId);

    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);
    when(soaBeneficiaryValidator.validateDelete(
            mappedBeneficiaries,
            requestBeneficiaryId,
            String.valueOf(ACCOUNT_NUMBER),
            requestMetadata))
        .thenReturn(beneficiary);

    beneficiaryService.deleteBeneficiaryWithoutSca(
        String.valueOf(ACCOUNT_NUMBER), requestBeneficiaryId, requestMetadata);

    verify(accountAccessValidator)
        .validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW);

    verifyNoMoreInteractions(soaBeneficiaryValidator);
    verifyNoInteractions(scaManager);

    final BeneficiaryRequest expectedMessage =
        BeneficiaryRequest.builder()
            .payload(
                BeneficiaryRequest.Payload.builder()
                    .beneficiary(beneficiary)
                    .sysId(currentBeneficiarySysId)
                    .build())
            .metadata(requestMetadata)
            .build();

    verifyWorkLogSaved(expectedMessage, Operation.DELETE);
  }

  @Test
  void deleteBeneficiaryShouldNotInsertRecordIfBlackListed() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final String requestBeneficiaryId = BENEFICIARY_ID;
    final Beneficiary beneficiary = new TestBeneficiary(requestBeneficiaryId, 1L);
    final ScaCredentials scaCredentials = buildScaCredentials();
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    stubGetBeneficiaries(mappedBeneficiaries);

    when(soaBeneficiaryValidator.validateDelete(
            mappedBeneficiaries,
            requestBeneficiaryId,
            String.valueOf(ACCOUNT_NUMBER),
            requestMetadata))
        .thenReturn(beneficiary);

    final List<String> blacklisted = Collections.singletonList(String.valueOf(ACCOUNT_NUMBER));
    when(beneficiaryServiceProperties.getAccountNumberBlacklist()).thenReturn(blacklisted);

    beneficiaryService.deleteBeneficiary(
        String.valueOf(ACCOUNT_NUMBER), requestBeneficiaryId, requestMetadata, scaCredentials);

    verify(workLogRepository).findRequestsAfterDate(ONE_DAY_AGO, ACCOUNT_NUMBER);
    verifyNoMoreInteractions(workLogRepository);
  }

  private void stubGetBeneficiaries(final List<Beneficiary> mappedBeneficiaries) {
    final Collection<BillPaymentInstruction> externalInstructions = new ArrayList<>();
    when(billPaymentInstructionRepository.findActiveExternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(externalInstructions);

    final Collection<ItInstruction> internalInstructions = new ArrayList<>();
    when(itInstructionRepository.findActiveInternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(internalInstructions);

    final Collection<WorkLog> workLogs = new ArrayList<>();
    when(workLogRepository.findRequestsAfterDate(ONE_DAY_AGO, ACCOUNT_NUMBER)).thenReturn(workLogs);

    when(beneficiaryListMapper.map(
            same(externalInstructions), same(internalInstructions), same(workLogs)))
        .thenReturn(mappedBeneficiaries);
  }

  private void verifyWorkLogSaved(
      final BeneficiaryRequest expectedMessage, final Operation create) {
    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("accountNumber", is(ACCOUNT_NUMBER)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty("operation", is(create)),
                    hasProperty("message", is(expectedMessage)),
                    hasProperty("createdBy", is(nullValue())),
                    hasProperty("createdDate", is(nullValue())),
                    hasProperty("updatedBy", is(nullValue())),
                    hasProperty("updatedDate", is(nullValue())))));
  }

  private static RequestMetadata buildValidRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(UUID.randomUUID())
        .sessionId(UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60"))
        .host(InetSocketAddress.createUnresolved("accountservice.ybs.co.uk", 443))
        .brandCode(BRAND_YBS)
        .partyId(BeneficiaryServiceTest.PARTY_ID)
        .forwardingAuth("<jwt>")
        .ipAddress("12.66.53.145")
        .build();
  }

  private static InternalBeneficiary createInternalBeneficiary() {
    return InternalBeneficiary.builder().accountNumber("1234567890").build();
  }

  private static Beneficiary createInternalBeneficiary(final String id) {
    return InternalBeneficiary.builder().beneficiaryId(id).accountNumber("1234567890").build();
  }

  private static ExternalBeneficiary createExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .accountNumber("12345678")
        .accountSortCode("112233")
        .memorableName("MEM")
        .name("NAME")
        .reference("REF")
        .build();
  }

  private AccountDetails createAccountServiceResponse() {
    return (AccountDetails.builder()
        .accountNumber(PARTY_ID)
        .accountNumber(String.valueOf(ACCOUNT_NUMBER))
        .product(
            Product.builder()
                .identifier(BeneficiaryServiceTest.PRODUCT_ID)
                .type(String.format("TYPE_%s", BeneficiaryServiceTest.PRODUCT_ID))
                .build())
        .build());
  }

  private static ProductInfo createProductInfo() {
    return ProductInfo.builder()
        .beneficiaries(ProductInfo.Beneficiaries.builder().external(1).internal(1).build())
        .build();
  }

  private static ProductInfo createProductInfoBeneficiaryLimit() {
    return ProductInfo.builder()
        .beneficiaries(ProductInfo.Beneficiaries.builder().external(2).internal(1).build())
        .build();
  }

  private ScaCredentials buildScaCredentials() {
    return new ScaCredentials("mockChallenge", "mockResponse", "mockBase64EncodedPublicKey");
  }

  @Test
  void getBeneficiariesLimitShouldReturnFlagsFalseWhenLimitsNotReached() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    AccountDetails accountDetails = createAccountServiceResponse();

    when(accountAccessValidator.validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW))
        .thenReturn(Collections.emptySet());
    when(billPaymentInstructionRepository.findActiveExternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(
            Stream.of(
                    BillPaymentInstruction.builder().build(),
                    BillPaymentInstruction.builder().build())
                .collect(Collectors.toList()));
    when(beneficiaryListMapper.map(any(), any(), any()))
        .thenReturn(
            Stream.of(ExternalBeneficiary.builder().build(), ExternalBeneficiary.builder().build())
                .collect(Collectors.toList()));
    final Collection<ItInstruction> internalInstructions = new ArrayList<>();
    when(itInstructionRepository.findActiveInternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(internalInstructions);

    when(accountService.getAccount(String.valueOf(ACCOUNT_NUMBER), requestMetadata))
        .thenReturn(accountDetails);
    when(productService.getProductInfo(
            accountDetails.getProduct().getIdentifier(), requestMetadata))
        .thenReturn(createProductInfoBeneficiaryLimit());

    BeneficiaryLimitResponse beneficiaryLimitResponse =
        beneficiaryService.getBeneficiariesLimits(String.valueOf(ACCOUNT_NUMBER), requestMetadata);
    assertThat(false, is(beneficiaryLimitResponse.getExternal().isLimitReached()));
    assertThat(false, is(beneficiaryLimitResponse.getInternal().isLimitReached()));
    assertEquals(
        billPaymentInstructionRepository
            .findActiveExternalBeneficiaries(ACCOUNT_NUMBER, NOW)
            .size(),
        beneficiaryLimitResponse.getExternal().getCount());

    ProductInfo productInfo =
        productService.getProductInfo(accountDetails.getProduct().getIdentifier(), requestMetadata);
    assertEquals(
        productInfo.getBeneficiaries().getExternal().intValue(),
        beneficiaryLimitResponse.getExternal().getMaxPermitted());
  }

  @Test
  void getBeneficiariesLimitShouldReturnFlagsTrueWhenLimitsReached() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    AccountDetails accountDetails = createAccountServiceResponse();
    ProductInfo productInfo = createProductInfo();

    final String requestBeneficiaryId = BENEFICIARY_ID;
    final Beneficiary beneficiary = new TestBeneficiary(requestBeneficiaryId, 1L);
    final List<Beneficiary> mappedBeneficiaries = Collections.singletonList(beneficiary);

    when(accountAccessValidator.validateAccountAccess(
            String.valueOf(ACCOUNT_NUMBER), requestMetadata, Collections.emptySet(), NOW))
        .thenReturn(Collections.emptySet());
    when(billPaymentInstructionRepository.findActiveExternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(
            Stream.of(BillPaymentInstruction.builder().build()).collect(Collectors.toList()));
    final Collection<ItInstruction> internalInstructions = new ArrayList<>();
    internalInstructions.add(
        ItInstruction.builder()
            .sysId(1L)
            .debtorAccountNumber(2001L)
            .availableAtm(true)
            .creditorAccountNumber(1001L)
            .status("ACTIVE")
            .build());
    when(beneficiaryListMapper.map(any(), any(), any()))
        .thenReturn(Stream.of(ExternalBeneficiary.builder().build()).collect(Collectors.toList()));
    when(itInstructionRepository.findActiveInternalBeneficiaries(ACCOUNT_NUMBER, NOW))
        .thenReturn(internalInstructions);
    when(accountService.getAccount(String.valueOf(ACCOUNT_NUMBER), requestMetadata))
        .thenReturn(accountDetails);
    when(productService.getProductInfo(
            accountDetails.getProduct().getIdentifier(), requestMetadata))
        .thenReturn(productInfo);

    when(productBeneficiaryLimitValidator.validateExternalBeneficiaryLimit(
            String.valueOf(ACCOUNT_NUMBER), mappedBeneficiaries.size(), productInfo))
        .thenThrow(
            new BeneficiaryValidationException(
                "Dummy Reason", BeneficiaryValidationExceptionReason.LIMIT_REACHED));
    when(productBeneficiaryLimitValidator.validateInternalBeneficiaryLimit(
            String.valueOf(ACCOUNT_NUMBER), mappedBeneficiaries.size(), productInfo))
        .thenThrow(
            new BeneficiaryValidationException(
                "Dummy Reason", BeneficiaryValidationExceptionReason.LIMIT_REACHED));

    BeneficiaryLimitResponse beneficiaryLimitResponse =
        beneficiaryService.getBeneficiariesLimits(String.valueOf(ACCOUNT_NUMBER), requestMetadata);
    assertThat(true, is(beneficiaryLimitResponse.getExternal().isLimitReached()));
    assertThat(true, is(beneficiaryLimitResponse.getInternal().isLimitReached()));
    assertEquals(
        billPaymentInstructionRepository
            .findActiveExternalBeneficiaries(ACCOUNT_NUMBER, NOW)
            .size(),
        beneficiaryLimitResponse.getExternal().getCount());
  }
}
