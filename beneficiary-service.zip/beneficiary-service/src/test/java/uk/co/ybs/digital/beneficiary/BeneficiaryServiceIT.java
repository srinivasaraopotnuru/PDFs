package uk.co.ybs.digital.beneficiary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.hamcrest.beans.HasPropertyWithValue.hasPropertyAtPath;
import static uk.co.ybs.digital.beneficiary.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.MACSigner;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.time.Clock;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Stream;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.CustomTypeSafeMatcher;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.beneficiary.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.beneficiary.e2e.AdgCoreHelper;
import uk.co.ybs.digital.beneficiary.e2e.AdgCoreHelper.AccountAccessRequiredEntities;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryChallengeSuccessRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryUpdateFailureRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.AuditBeneficiaryViewRequest;
import uk.co.ybs.digital.beneficiary.service.audit.dto.BeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.beneficiary.utils.SigningUtils;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ErrorResponse;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.FailureRequest;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.filters.session.SessionIdSourceType;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class BeneficiaryServiceIT {

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";

  private static final String PUBLIC_REQUIRED_SCOPE = "BENEFICIARY";
  private static final String PRIVATE_REQUIRED_SCOPE = "ACCOUNT_READ BENEFICIARY";
  private static final String ACCOUNT_READ_SCOPE = "ACCOUNT_READ";
  private static final String PUBLIC_REQUIRED_SCOPE_BENEFICIARY_LIMIT = "BENEFICIARY ACCOUNT_READ";

  private static final String BRAND_CODE_YBS = "YBS";

  private static final String PARTY_ID = "92462951";
  private static final String CANONICAL_PARTY_ID = "12462951";
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final UUID SESSION_ID_OTHER =
      UUID.fromString("e5c3c4bf-8b48-44e2-b120-eea2dd84bf46");

  private static final String BASE_PATH = "/beneficiary";
  private static final String BASE_PATH_PUBLIC = "";
  private static final String BASE_PATH_PRIVATE = "/private";
  private static final String ACCOUNT_NUMBER = "1234567890";
  private static final String ACCOUNT_NUMBER_OTHER = "2234567890";
  private static final String BENEFICIARY_ID_EXTERNAL =
      "05616510c2ce1901fb1a1ad811894bc526ab0d3e97196d09d8555d4f1be07214";
  private static final String BENEFICIARY_ID_INTERNAL =
      "4ed3b368a1722d041cf33b78fd0218db6b73a4c60db61c59b09b032cef3349a1";
  private static final String ACCOUNT_BENEFICIARIES_PATH =
      "/accounts/" + ACCOUNT_NUMBER + "/beneficiaries";
  private static final String ACCOUNT_BENEFICIARIES_BENEFICIARY_PATH =
      ACCOUNT_BENEFICIARIES_PATH + "/" + BENEFICIARY_ID_EXTERNAL;
  private static final String REPORT_FAILURE_PATH = "/failure";

  private static final long EXISTING_BENEFICIARY_SYS_ID = 1L;
  private static final String ACCOUNT_BENEFICIARY_LIMIT_PATH =
      "/accounts/" + ACCOUNT_NUMBER + "/beneficiary-limits";
  private static final String WEB_CHANNEL = "WEB";

  private static final String NEW_REFERENCE = "New Reference";
  private static final String NEW_MEMORABLE_NAME = "New Memorable Name";

  public static final String STR_123456 = "123456";
  public static final String ACCT_NO_32345679 = "32345679";
  public static final String REF = "Ref";
  public static final String MR_TEST = "Mr Test";
  public static final String JOINT_ACCOUNT = "Joint Account";
  public static final String ACCT_NO_32345678 = "32345678";
  public static final String REF_PENDING = "Ref Pending";
  public static final String MR_TEST_PENDING = "Mr Test Pending";
  public static final String MEM_PENDING = "Mem Pending";
  public static final String BENEFICIARY_VALIDATION_ERROR = "Beneficiary validation error";
  public static final String X_YBS_SCA_CHALLENGE = "x-ybs-sca-challenge";
  public static final String LOCALHOST = "127.0.0.1";
  @LocalServerPort private int port;

  @Value("${uk.co.ybs.digital.product-test-port}")
  private int productTestPort;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  @Value("${uk.co.ybs.digital.account-test-port}")
  private int accountTestPort;

  @Autowired private WebTestClient signingWebClientPublic;

  @Autowired private WebTestClient signingWebClientPrivate;

  @Autowired private WebTestClient nonSigningWebClient;

  @Autowired private PrivateKey jwtSigningPrivateKey;

  private MockWebServer mockProductService;
  private MockWebServer mockAuditService;
  private MockWebServer mockAccountService;

  @Autowired private Clock clock;

  @Autowired private ObjectMapper objectMapper;

  @Autowired private TransactionTemplate transactionTemplate;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  @Autowired private TestEntityManager digitalBeneficiaryTestEntityManager;

  private AdgCoreHelper adgCoreHelper;

  @BeforeEach
  void setUp() throws IOException {
    mockProductService = new MockWebServer();
    mockProductService.start(productTestPort);
    mockAuditService = new MockWebServer();
    mockAuditService.start(auditTestPort);
    mockAccountService = new MockWebServer();
    mockAccountService.start(accountTestPort);
    adgCoreHelper = new AdgCoreHelper(transactionTemplate, adgCoreTestEntityManager, clock);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockProductService.shutdown();
    mockAuditService.shutdown();
    mockAccountService.shutdown();
    tearDownDb();
  }

  @Test
  void getBeneficiariesShouldReturnBeneficiariesResponseWhenRequestIsValid()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    final AccountAccessRequiredEntities accessEntities =
        adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    adgCoreHelper.setUpAccountNumber(
        Long.parseLong(ACCOUNT_NUMBER_OTHER), accessEntities.getSavingProduct());

    final String expectedResponse =
        readClassPathResource("it/getBeneficiariesExpectedResponse.json");

    // External
    adgCoreHelper.setUpExternalBeneficiary(
        EXISTING_BENEFICIARY_SYS_ID,
        ACCOUNT_NUMBER,
        STR_123456,
        ACCT_NO_32345678,
        REF,
        MR_TEST,
        JOINT_ACCOUNT,
        false);
    // External - Pending
    adgCoreHelper.setUpExternalBeneficiary(
        2L,
        ACCOUNT_NUMBER,
        STR_123456,
        ACCT_NO_32345679,
        REF_PENDING,
        MR_TEST_PENDING,
        MEM_PENDING,
        false);
    setUpWorkLog(
        2L,
        ExternalBeneficiary.builder()
            .accountSortCode(STR_123456)
            .accountNumber(ACCT_NO_32345679)
            .reference(REF_PENDING)
            .name(MR_TEST_PENDING)
            .memorableName(MEM_PENDING)
            .build());
    // External - Other debtor account
    adgCoreHelper.setUpExternalBeneficiary(
        3L, ACCOUNT_NUMBER_OTHER, STR_123456, "32345680", REF, MR_TEST, JOINT_ACCOUNT, false);
    // External - Ended
    adgCoreHelper.setUpExternalBeneficiary(
        4L, ACCOUNT_NUMBER, STR_123456, "12345681", REF, "Mr Test 2", JOINT_ACCOUNT, true);
    // External - Invalid
    adgCoreHelper.setUpExternalBeneficiary(
        5L, ACCOUNT_NUMBER, STR_123456, "12345682", REF, MR_TEST, "Joint & Account", false);
    // Internal
    adgCoreHelper.setUpInternalBeneficiary(1L, Long.parseLong(ACCOUNT_NUMBER), 2234567891L, false);
    // Internal - Pending
    adgCoreHelper.setUpInternalBeneficiary(2L, Long.parseLong(ACCOUNT_NUMBER), 2234567892L, false);
    setUpWorkLog(2L, InternalBeneficiary.builder().accountNumber("2234567892").build());
    // Internal - Other debtor account
    adgCoreHelper.setUpInternalBeneficiary(
        3L, Long.parseLong(ACCOUNT_NUMBER_OTHER), 2234567893L, false);
    // Internal - Ended
    adgCoreHelper.setUpInternalBeneficiary(4L, Long.parseLong(ACCOUNT_NUMBER), 2234567894L, true);
    // Internal - Invalid
    adgCoreHelper.setUpInternalBeneficiary(5L, Long.parseLong(ACCOUNT_NUMBER), 1L, false);

    stubMockAuditServiceResponse();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody()
        .json(expectedResponse);

    assertAuditBeneficiariesView(requestId, jwt);
  }

  @Test
  void getBeneficiariesShouldReturnEmptyListWhenRequestIsValidButNoBeneficiariesExist()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    final List<Beneficiary> expectedResponse = Collections.emptyList();

    stubMockAuditServiceResponse();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(Beneficiary.class)
        .isEqualTo(expectedResponse);

    assertAuditBeneficiariesView(requestId, jwt);
  }

  @Test
  void privateGetBeneficiaryShouldReturnBeneficiaryResponseWhenRequestIsValid() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPrivate();
    final Beneficiary expectedResponse =
        ExternalBeneficiary.builder()
            .beneficiaryId(BENEFICIARY_ID_EXTERNAL)
            .accountNumber(ACCT_NO_32345678)
            .reference(REF)
            .accountSortCode(STR_123456)
            .name(MR_TEST)
            .memorableName(JOINT_ACCOUNT)
            .build();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_BENEFICIARY_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(Beneficiary.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @MethodSource("newCreateBeneficiaryRequests")
  void privateCreateBeneficiaryShouldReturnAcceptedWhenRequestIsValid(
      final Beneficiary beneficiary, final int beneficiariesLimit) throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPrivate();
    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);
    final LocalDateTime now = LocalDateTime.now(clock);

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();
    stubFindAccountSuccess(ACCOUNT_NUMBER);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoManyBeneficiaries.json"));

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isAccepted();

    assertWorkLogs(
        workLogMatching(
            workLog(
                WorkLog.Operation.CREATE, beneficiary, null, beneficiariesLimit, requestMetadata),
            now));
  }

  @ParameterizedTest
  @MethodSource("existingCreateBeneficiaryRequests")
  void privateCreateBeneficiaryShouldReturnConflictWhenBeneficiaryAlreadyExists(
      final Beneficiary beneficiary, final BeneficiaryInformation beneficiaryInformation)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPrivate();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    if (beneficiary instanceof ExternalBeneficiary) {
      setUpExternalBeneficiary();
    } else {
      setUpInternalBeneficiary();
    }
    stubFindAccountSuccess(ACCOUNT_NUMBER);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoManyBeneficiaries.json"));
    // Required as a failure is audited event though this is a private endpoint.
    stubMockAuditServiceResponse();

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("409 Conflict")
            .message(BENEFICIARY_VALIDATION_ERROR)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Beneficiary.Exists")
                    .message("Unable to add beneficiary as it already exists for this account")
                    .build())
            .build();

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    assertAuditBeneficiaryFailure(
        requestId,
        jwt,
        "/audit/beneficiary/create/failure",
        BeneficiaryValidationExceptionReason.DUPLICATE,
        beneficiaryInformation);
    assertWorkLogs();
  }

  @ParameterizedTest
  @MethodSource("existingCreateBeneficiaryRequests")
  void privateCreateBeneficiaryShouldReturnConflictWhenBeneficiaryLimitExceeded(
      final Beneficiary beneficiary, final BeneficiaryInformation beneficiaryInformation)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPrivate();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    stubFindAccountSuccess(ACCOUNT_NUMBER);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoNoBeneficiaries.json"));

    // Required as a failure is audited event though this is a private endpoint.
    stubMockAuditServiceResponse();

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("409 Conflict")
            .message(BENEFICIARY_VALIDATION_ERROR)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Beneficiary.Limit")
                    .message("Unable to add beneficiary as allowed limit would be exceeded")
                    .build())
            .build();

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    assertAuditBeneficiaryFailure(
        requestId,
        jwt,
        "/audit/beneficiary/create/failure",
        BeneficiaryValidationExceptionReason.LIMIT_REACHED,
        beneficiaryInformation);
    assertWorkLogs();
  }

  @Test
  void updateBeneficiaryShouldReturnAcceptedWhenRequestIsValid() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();
    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();
    final LocalDateTime now = LocalDateTime.now(clock);
    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    final ExternalBeneficiary expectedBeneficiary =
        existingExternalBeneficiary().toBuilder().beneficiaryId(BENEFICIARY_ID_EXTERNAL).build();

    final Beneficiary updatedBeneficiary =
        expectedBeneficiary
            .toBuilder()
            .reference(NEW_REFERENCE)
            .memorableName(NEW_MEMORABLE_NAME)
            .build();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();
    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    final String challenge = putBeneficiaryRequestWithoutSca(requestId, updatedBeneficiary, jwt);
    putBeneficiaryRequestWithSca(requestId, updatedBeneficiary, jwt, scaKeyPair, challenge)
        .expectStatus()
        .isAccepted()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ExternalBeneficiary.class)
        .isEqualTo(expectedBeneficiary);

    assertAuditBeneficiaryChallengeSuccess(requestId, jwt);
    assertWorkLogs(
        workLogMatching(
            workLog(
                WorkLog.Operation.UPDATE,
                updatedBeneficiary,
                EXISTING_BENEFICIARY_SYS_ID,
                null,
                requestMetadata),
            now));
  }

  @Test
  void privateUpdateBeneficiaryShouldReturnAcceptedWhenRequestIsValid() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();
    final LocalDateTime now = LocalDateTime.now(clock);
    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    final ExternalBeneficiary expectedBeneficiary =
        existingExternalBeneficiary().toBuilder().beneficiaryId(BENEFICIARY_ID_EXTERNAL).build();

    final Beneficiary updatedBeneficiary =
        expectedBeneficiary
            .toBuilder()
            .reference(NEW_REFERENCE)
            .memorableName(NEW_MEMORABLE_NAME)
            .build();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();

    signingWebClientPrivate
        .put()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(updatedBeneficiary)
        .exchange()
        .expectStatus()
        .isAccepted();

    assertWorkLogs(
        workLogMatching(
            workLog(
                WorkLog.Operation.UPDATE,
                updatedBeneficiary,
                EXISTING_BENEFICIARY_SYS_ID,
                null,
                requestMetadata),
            now));
  }

  private String putBeneficiaryRequestWithoutSca(
      final UUID requestId, final Beneficiary beneficiary, final String jwt)
      throws JsonProcessingException, InterruptedException {
    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    final String challenge =
        signingWebClientPublic
            .put()
            .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
            .headers(standardHeaders(requestId, jwt))
            .bodyValue(beneficiary)
            .exchange()
            .expectStatus()
            .isForbidden()
            .expectHeader()
            .value(X_YBS_SCA_CHALLENGE, is(not(emptyOrNullString())))
            .expectBody(ErrorResponse.class)
            .isEqualTo(expectedResponse)
            .returnResult()
            .getResponseHeaders()
            .getFirst(X_YBS_SCA_CHALLENGE);

    assertAuditBeneficiaryChallenge(requestId, jwt);

    return challenge;
  }

  private WebTestClient.ResponseSpec putBeneficiaryRequestWithSca(
      final UUID requestId,
      final Beneficiary beneficiary,
      final String jwt,
      final KeyPair scaKeyPair,
      final String challenge)
      throws Exception {
    final String challengeResponse =
        SigningUtils.signWithPrivateKey(challenge, scaKeyPair.getPrivate());
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair.getPublic());

    return signingWebClientPublic
        .put()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .header(X_YBS_SCA_CHALLENGE, challenge)
        .header("x-ybs-sca-challenge-response", challengeResponse)
        .header("x-ybs-sca-key", encodedPublicKey)
        .bodyValue(beneficiary)
        .exchange();
  }

  @Test
  void updateBeneficiaryShouldReturnForbiddenWhenSessionIdDoesntMatchChallengeSessionId()
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary beneficiary =
        existingExternalBeneficiary().toBuilder().beneficiaryId(BENEFICIARY_ID_EXTERNAL).build();
    final String jwt = createValidYbsJwtPublic();
    final String jwtWithOtherSession =
        createJwt(
            IntegrationTestJwtFactory.claimsMap(
                PARTY_ID,
                CANONICAL_PARTY_ID,
                SESSION_ID_OTHER,
                PUBLIC_REQUIRED_SCOPE,
                BRAND_CODE_YBS));

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final ErrorResponse expectedResponseWithSca =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();
    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge Failure

    final String challenge = putBeneficiaryRequestWithoutSca(requestId, beneficiary, jwt);
    putBeneficiaryRequestWithSca(requestId, beneficiary, jwtWithOtherSession, scaKeyPair, challenge)
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponseWithSca);

    assertAuditBeneficiaryChallengeFailure(
        requestId, jwtWithOtherSession, "Invalid Challenge Response");

    assertWorkLogs();
  }

  @Test
  void updateBeneficiaryShouldReturnConflictWhenBeneficiaryPending() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary beneficiary =
        existingExternalBeneficiary().toBuilder().beneficiaryId(BENEFICIARY_ID_EXTERNAL).build();
    final String jwt = createValidYbsJwtPublic();
    final LocalDateTime now = LocalDateTime.now(clock);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.CONFLICT)
            .id(requestId)
            .message(BENEFICIARY_VALIDATION_ERROR)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Beneficiary.Pending")
                    .message("Currently unable to support modifications to this beneficiary")
                    .build())
            .build();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();
    final WorkLog workLog = setUpWorkLog(EXISTING_BENEFICIARY_SYS_ID, beneficiary);
    stubMockAuditServiceResponse();

    signingWebClientPublic
        .put()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    assertAuditBeneficiaryUpdateFailure(
        requestId,
        jwt,
        BeneficiaryValidationExceptionReason.PENDING,
        externalBeneficiaryInformation()
            .toBuilder()
            .memorableName(JOINT_ACCOUNT)
            .reference(REF)
            .build(),
        ExternalUpdateBeneficiaryInformation.builder()
            .memorableName(JOINT_ACCOUNT)
            .reference(REF)
            .build());

    assertWorkLogs(workLogMatching(workLog, now));
  }

  @Test
  void privateUpdateBeneficiaryShouldReturnConflictWhenBeneficiaryPending() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final Beneficiary beneficiary =
        existingExternalBeneficiary().toBuilder().beneficiaryId(BENEFICIARY_ID_EXTERNAL).build();
    final String jwt = createValidYbsJwtPublic();
    final LocalDateTime now = LocalDateTime.now(clock);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.CONFLICT)
            .id(requestId)
            .message(BENEFICIARY_VALIDATION_ERROR)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Beneficiary.Pending")
                    .message("Currently unable to support modifications to this beneficiary")
                    .build())
            .build();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();
    final WorkLog workLog = setUpWorkLog(EXISTING_BENEFICIARY_SYS_ID, beneficiary);
    stubMockAuditServiceResponse();

    signingWebClientPrivate
        .put()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    assertAuditBeneficiaryUpdateFailure(
        requestId,
        jwt,
        BeneficiaryValidationExceptionReason.PENDING,
        externalBeneficiaryInformation()
            .toBuilder()
            .memorableName(JOINT_ACCOUNT)
            .reference(REF)
            .build(),
        ExternalUpdateBeneficiaryInformation.builder()
            .memorableName(JOINT_ACCOUNT)
            .reference(REF)
            .build());

    assertWorkLogs(workLogMatching(workLog, now));
  }

  @ParameterizedTest
  @MethodSource("existingBeneficiaries")
  void deleteBeneficiaryShouldReturnAcceptedWhenRequestIsValid(final Beneficiary beneficiary)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();
    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();
    final LocalDateTime now = LocalDateTime.now(clock);

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    if (beneficiary instanceof ExternalBeneficiary) {
      setUpExternalBeneficiary();
    } else {
      setUpInternalBeneficiary();
    }
    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    final String challenge =
        deleteBeneficiaryRequestWithoutScaReturnsForbidden(
            requestId, beneficiary.getBeneficiaryId(), jwt);
    deleteBeneficiaryRequestWithSca(
            requestId, beneficiary.getBeneficiaryId(), jwt, scaKeyPair, challenge)
        .expectStatus()
        .isAccepted();

    assertAuditBeneficiaryChallengeSuccess(requestId, jwt);
    assertWorkLogs(
        workLogMatching(
            workLog(
                WorkLog.Operation.DELETE,
                beneficiary,
                EXISTING_BENEFICIARY_SYS_ID,
                null,
                requestMetadata),
            now));
  }

  @ParameterizedTest
  @MethodSource("existingBeneficiaries")
  void deleteBeneficiaryShouldReturnAcceptedForWebWhenRequestIsValid(final Beneficiary beneficiary)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScopeAndChannel();
    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);
    final LocalDateTime now = LocalDateTime.now(clock);

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    if (beneficiary instanceof ExternalBeneficiary) {
      setUpExternalBeneficiary();
    } else {
      setUpInternalBeneficiary();
    }

    deleteBeneficiaryRequestWithoutSca(requestId, beneficiary.getBeneficiaryId(), jwt)
        .expectHeader()
        .value(X_YBS_SCA_CHALLENGE, is(emptyOrNullString()))
        .expectStatus()
        .isAccepted()
        .expectBody()
        .isEmpty();

    assertWorkLogs(
        workLogMatching(
            workLog(
                WorkLog.Operation.DELETE,
                beneficiary,
                EXISTING_BENEFICIARY_SYS_ID,
                null,
                requestMetadata),
            now));
  }

  private String deleteBeneficiaryRequestWithoutScaReturnsForbidden(
      final UUID requestId, final String beneficiaryId, final String jwt)
      throws JsonProcessingException, InterruptedException {
    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    final String challenge =
        signingWebClientPublic
            .delete()
            .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiaryId))
            .headers(standardHeaders(requestId, jwt))
            .exchange()
            .expectStatus()
            .isForbidden()
            .expectHeader()
            .value(X_YBS_SCA_CHALLENGE, is(not(emptyOrNullString())))
            .expectBody(ErrorResponse.class)
            .isEqualTo(expectedResponse)
            .returnResult()
            .getResponseHeaders()
            .getFirst(X_YBS_SCA_CHALLENGE);

    assertAuditBeneficiaryChallenge(requestId, jwt);

    return challenge;
  }

  private WebTestClient.ResponseSpec deleteBeneficiaryRequestWithoutSca(
      final UUID requestId, final String beneficiaryId, final String jwt) {

    return signingWebClientPublic
        .delete()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiaryId))
        .headers(standardHeaders(requestId, jwt))
        .exchange();
  }

  private WebTestClient.ResponseSpec deleteBeneficiaryRequestWithSca(
      final UUID requestId,
      final String beneficiaryId,
      final String jwt,
      final KeyPair scaKeyPair,
      final String challenge)
      throws Exception {
    final String challengeResponse =
        SigningUtils.signWithPrivateKey(challenge, scaKeyPair.getPrivate());
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair.getPublic());

    return signingWebClientPublic
        .delete()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH + "/" + beneficiaryId))
        .headers(standardHeaders(requestId, jwt))
        .header(X_YBS_SCA_CHALLENGE, challenge)
        .header("x-ybs-sca-challenge-response", challengeResponse)
        .header("x-ybs-sca-key", encodedPublicKey)
        .exchange();
  }

  @Test
  void deleteBeneficiaryShouldReturnForbiddenWhenSessionIdDoesntMatchChallengeSessionId()
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();
    final String jwtWithOtherSession =
        createJwt(
            IntegrationTestJwtFactory.claimsMap(
                PARTY_ID,
                CANONICAL_PARTY_ID,
                SESSION_ID_OTHER,
                PUBLIC_REQUIRED_SCOPE,
                BRAND_CODE_YBS));
    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final ErrorResponse expectedResponseWithSca =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();
    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge failure

    final String challenge =
        deleteBeneficiaryRequestWithoutScaReturnsForbidden(requestId, BENEFICIARY_ID_EXTERNAL, jwt);
    deleteBeneficiaryRequestWithSca(
            requestId, BENEFICIARY_ID_EXTERNAL, jwtWithOtherSession, scaKeyPair, challenge)
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponseWithSca);

    assertAuditBeneficiaryChallengeFailure(
        requestId, jwtWithOtherSession, "Invalid Challenge Response");
    assertWorkLogs();
  }

  @Test
  void deleteBeneficiaryShouldReturnConflictWhenBeneficiaryPending() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();
    final LocalDateTime now = LocalDateTime.now(clock);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.CONFLICT)
            .id(requestId)
            .message(BENEFICIARY_VALIDATION_ERROR)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Beneficiary.Pending")
                    .message("Currently unable to support modifications to this beneficiary")
                    .build())
            .build();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();
    final WorkLog workLog =
        setUpWorkLog(EXISTING_BENEFICIARY_SYS_ID, existingExternalBeneficiary());
    stubMockAuditServiceResponse();

    signingWebClientPublic
        .delete()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH + "/" + BENEFICIARY_ID_EXTERNAL))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    assertAuditBeneficiaryFailure(
        requestId,
        jwt,
        "/audit/beneficiary/delete/failure",
        BeneficiaryValidationExceptionReason.PENDING,
        externalBeneficiaryInformation()
            .toBuilder()
            .memorableName(JOINT_ACCOUNT)
            .reference(REF)
            .build());

    assertWorkLogs(workLogMatching(workLog, now));
  }

  @Test
  void reportFailureReturnsCallsAuditService() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setUpExternalBeneficiary();
    stubMockAuditServiceResponse(); // Challenge created
    stubMockAuditServiceResponse(); // Challenge failure

    final String challenge =
        deleteBeneficiaryRequestWithoutScaReturnsForbidden(requestId, BENEFICIARY_ID_EXTERNAL, jwt);

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, REPORT_FAILURE_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(FailureRequest.builder().challenge(challenge).build())
        .exchange()
        .expectStatus()
        .isNoContent();

    assertAuditBeneficiaryChallengeFailure(
        requestId, jwt, "Client-side authentication error reported");
  }

  @Test
  void reportFailureReturnsForbiddenIfChallengeIsNotAuthentic() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();
    final JWSSigner signer = new MACSigner("bad-key-that-is-long-enough-to-be-valid");
    final JWSObject badChallenge =
        new JWSObject(new JWSHeader(JWSAlgorithm.HS256), new Payload("some-payload"));
    badChallenge.sign(signer);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("Authenticity of the challenge could not validated")
                    .build())
            .build();

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, REPORT_FAILURE_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(FailureRequest.builder().challenge(badChallenge.serialize()).build())
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void getBeneficiariesShouldReturnForbiddenForPrivateRequestSigningKey() {
    endpointShouldReturnForbiddenForInvalidRequestSigningKey(
        BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH, signingWebClientPrivate);
  }

  @Test
  void privateGetBeneficiaryShouldReturnForbiddenForPublicRequestSigningKey() {
    endpointShouldReturnForbiddenForInvalidRequestSigningKey(
        BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_BENEFICIARY_PATH, signingWebClientPublic);
  }

  @Test
  void privateCreateBeneficiaryShouldReturnForbiddenForPublicRequestSigningKey() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSignature(requestId));
  }

  @Test
  void updateBeneficiaryShouldReturnForbiddenForPrivateRequestSigningKey() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    signingWebClientPrivate
        .put()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSignature(requestId));

    assertWorkLogs();
  }

  @Test
  void privateUpdateBeneficiaryShouldReturnForbiddenForPublicRequestSigningKey() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    signingWebClientPublic
        .put()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSignature(requestId));

    assertWorkLogs();
  }

  @Test
  void deleteBeneficiaryShouldReturnForbiddenForPrivateRequestSigningKey() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    signingWebClientPrivate
        .delete()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_BENEFICIARY_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSignature(requestId));

    assertWorkLogs();
  }

  private void endpointShouldReturnForbiddenForInvalidRequestSigningKey(
      final String basePath, final String endpoint, final WebTestClient webTestClient) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    webTestClient
        .get()
        .uri(getURI(basePath, endpoint))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSignature(requestId));
  }

  @Test
  void privateGetBeneficiaryShouldReturnNotFoundWhenBeneficiaryDoesNotExit() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPrivate();

    adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH + "/xyz1"))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));
  }

  @Test
  void getBeneficiariesShouldReturnNotFoundWhenAccountDoesNotExist() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));
  }

  @Test
  void privateGetBeneficiaryShouldReturnNotFoundWhenAccountDoesNotExist() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPrivate();

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_BENEFICIARY_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));
  }

  @Test
  void privateCreateBeneficiaryShouldReturnNotFoundWhenAccountDoesNotExist() {
    final Beneficiary beneficiary = existingExternalBeneficiary();
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPrivate();

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(beneficiary)
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));

    assertWorkLogs();
  }

  @Test
  void shouldReturnUnauthorisedWhenBearerTokenIsNotValidJwt() {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, "invalid.bearer.token"))
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturnUnauthorisedWhenBearerTokenIsMissing() {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId))
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturnForbiddenWhenJwtLacksRequiredScopePublic() {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithoutRequiredScope = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);

    final ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwtWithoutRequiredScope))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturnForbiddenWhenJwtLacksRequiredScopePrivate() {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithoutRequiredScope = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);

    final ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_BENEFICIARIES_BENEFICIARY_PATH))
        .headers(standardHeaders(requestId, jwtWithoutRequiredScope))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        IntegrationTestJwtFactory.CLAIM_AUD,
        IntegrationTestJwtFactory.CLAIM_SUB,
        IntegrationTestJwtFactory.CLAIM_BRAND_CODE
      })
  void shouldReturnUnauthorisedWhenRequiredClaimMissing(final String missingClaim) {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    final Map<String, Object> claims =
        IntegrationTestJwtFactory.claimsMap(
            PARTY_ID, CANONICAL_PARTY_ID, SESSION_ID, PUBLIC_REQUIRED_SCOPE, BRAND_CODE_YBS);
    claims.remove(missingClaim);

    final String jwt = createJwt(claims);

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturnForbiddenWhenSignatureIsInvalid() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublic();

    nonSigningWebClient
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, "request-signature-key-id-public")
        .header(HEADER_REQUEST_SIGNATURE, "invalid-signature")
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSignature(requestId));
  }

  @Test
  void shouldReturnBadRequestWhenJwtSessionIdClaimIsNotAUUID() {
    final UUID requestId = UUID.randomUUID();
    final Map<String, Object> claims =
        IntegrationTestJwtFactory.claimsMap(
            PARTY_ID,
            CANONICAL_PARTY_ID,
            "invalid_session_id",
            PUBLIC_REQUIRED_SCOPE,
            BRAND_CODE_YBS);
    final String jwt = createJwt(claims);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("400 Bad Request")
            .message("Bad Request")
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("Field.Invalid")
                        .message("SessionId is not a valid UUID")
                        .path(SessionIdSourceType.JWT.toString())
                        .build()))
            .build();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARIES_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  private static Stream<Arguments> newCreateBeneficiaryRequests() {
    return Stream.of(
        Arguments.of(existingExternalBeneficiary().toBuilder().reference("NewRef").build(), 10),
        Arguments.of(
            existingInternalBeneficiary().toBuilder().accountNumber("9876543210").build(), 8));
  }

  private static Stream<Arguments> existingCreateBeneficiaryRequests() {
    return Stream.of(
        Arguments.of(existingExternalBeneficiary(), externalBeneficiaryInformation()),
        Arguments.of(
            existingInternalBeneficiary(),
            InternalBeneficiaryInformation.builder()
                .accountNumber(ACCOUNT_NUMBER)
                .payeeAccountNumber(ACCOUNT_NUMBER_OTHER)
                .build()));
  }

  private static Stream<Beneficiary> existingBeneficiaries() {
    return Stream.of(
        existingExternalBeneficiary().toBuilder().beneficiaryId(BENEFICIARY_ID_EXTERNAL).build(),
        existingInternalBeneficiary().toBuilder().beneficiaryId(BENEFICIARY_ID_INTERNAL).build());
  }

  private URI getURI(final String basePath, final String path) {
    return URI.create("http://localhost:" + port + BASE_PATH + basePath + path);
  }

  private static ExternalBeneficiary existingExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .accountNumber(ACCT_NO_32345678)
        .reference(REF)
        .accountSortCode(STR_123456)
        .name(MR_TEST)
        .memorableName(JOINT_ACCOUNT)
        .build();
  }

  private static InternalBeneficiary existingInternalBeneficiary() {
    return InternalBeneficiary.builder().accountNumber(ACCOUNT_NUMBER_OTHER).build();
  }

  private static ExternalBeneficiaryInformation externalBeneficiaryInformation() {
    return ExternalBeneficiaryInformation.builder()
        .memorableName(JOINT_ACCOUNT)
        .payeeAccountNumber(ACCT_NO_32345678)
        .reference(REF)
        .payeeSortCode(STR_123456)
        .payeeName(MR_TEST)
        .accountNumber(ACCOUNT_NUMBER)
        .build();
  }

  private static RequestMetadata buildExpectedRequestMetadata(
      final UUID requestId, final String jwt) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .sessionId(SESSION_ID)
        .host(InetSocketAddress.createUnresolved("localhost/127.0.0.1", 0))
        .brandCode("YBS")
        .partyId(CANONICAL_PARTY_ID)
        .forwardingAuth(jwt)
        .ipAddress(LOCALHOST)
        .build();
  }

  private WorkLog workLog(
      final Operation operation,
      final Beneficiary request,
      final Long sysId,
      final Integer beneficiariesLimit,
      final RequestMetadata metadata) {
    return WorkLog.builder()
        .accountNumber(Long.parseLong(ACCOUNT_NUMBER))
        .status(WorkLog.Status.PENDING)
        .operation(operation)
        .message(
            BeneficiaryRequest.builder()
                .payload(
                    BeneficiaryRequest.Payload.builder()
                        .sysId(sysId)
                        .beneficiariesLimit(beneficiariesLimit)
                        .beneficiary(request)
                        .build())
                .metadata(metadata)
                .build())
        .createdBy(PARTY_ID)
        .updatedBy(PARTY_ID)
        .build();
  }

  private String createValidYbsJwtPublic() {
    return createYbsJwtWithScope(PUBLIC_REQUIRED_SCOPE);
  }

  private String createValidYbsJwtPublicForBeneficiaryLimit() {
    return createYbsJwtWithScope(PUBLIC_REQUIRED_SCOPE_BENEFICIARY_LIMIT);
  }

  private String createValidYbsJwtPrivate() {
    return createYbsJwtWithScope(PRIVATE_REQUIRED_SCOPE);
  }

  private String createYbsJwtWithScope(final String scope) {
    return createJwt(
        IntegrationTestJwtFactory.claimsMap(
            PARTY_ID, CANONICAL_PARTY_ID, SESSION_ID, scope, BRAND_CODE_YBS));
  }

  private String createJwt(final Map<String, Object> claims) {
    return IntegrationTestJwtFactory.createJwt(claims, jwtSigningPrivateKey);
  }

  private String createYbsJwtWithScopeAndChannel() {
    return createJwt(
        IntegrationTestJwtFactory.claimsMapWithChannel(
            PARTY_ID,
            CANONICAL_PARTY_ID,
            SESSION_ID.toString(),
            PUBLIC_REQUIRED_SCOPE,
            BRAND_CODE_YBS,
            WEB_CHANNEL));
  }

  private Consumer<HttpHeaders> standardHeaders(final UUID requestId, final String jwt) {
    return headers -> {
      standardHeaders(requestId).accept(headers);
      headers.setBearerAuth(jwt);
    };
  }

  private Consumer<HttpHeaders> standardHeaders(final UUID requestId) {
    return headers -> {
      headers.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON));
      headers.setHost(new InetSocketAddress("localhost", 0));
      headers.add(HEADER_REQUEST_ID, requestId.toString());
    };
  }

  private void setUpExternalBeneficiary() {
    adgCoreHelper.setUpExternalBeneficiary(
        EXISTING_BENEFICIARY_SYS_ID,
        ACCOUNT_NUMBER,
        STR_123456,
        ACCT_NO_32345678,
        REF,
        MR_TEST,
        JOINT_ACCOUNT,
        false);
  }

  private void setUpInternalBeneficiary() {
    adgCoreHelper.setUpInternalBeneficiary(
        1L, Long.parseLong(ACCOUNT_NUMBER), Long.parseLong(ACCOUNT_NUMBER_OTHER), false);
  }

  private WorkLog setUpWorkLog(final long sysId, final Beneficiary beneficiary) {
    return transactionTemplate.execute(
        status ->
            digitalBeneficiaryTestEntityManager.persistAndFlush(
                workLog(
                    Operation.DELETE,
                    beneficiary,
                    sysId,
                    100,
                    TestHelper.createRequestMetadata())));
  }

  private void stubMockProductServiceResponse(final Resource resource) {
    mockProductService.enqueue(
        new MockResponse()
            .setHeader("Content-Type", "application/json")
            .setBody(readClassPathResource(resource)));
  }

  private void stubMockAuditServiceResponse() {
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  private void stubAccountServiceResponse(final HttpStatus httpStatus, final String response) {
    mockAccountService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(response));
  }

  private void stubFindAccountSuccess(final String accountNumber) {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource(
            String.format("api/account/account/ResponseAccountNumber%s.json", accountNumber)));
  }

  private void assertAuditBeneficiariesView(final UUID requestId, final String jwt)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is("/audit/beneficiary/view"));
    assertThat(request.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditBeneficiaryViewRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditBeneficiaryViewRequest.class);
    assertThat(
        actual,
        is(
            AuditBeneficiaryViewRequest.builder()
                .beneficiaryInformation(
                    AuditBeneficiaryViewRequest.BeneficiaryInformation.builder()
                        .accountNumber("1234567890")
                        .build())
                .ipAddress(LOCALHOST)
                .build()));
  }

  private void assertAuditBeneficiaryFailure(
      final UUID requestId,
      final String jwt,
      final String path,
      final BeneficiaryValidationExceptionReason reason,
      final BeneficiaryInformation beneficiaryInformation)
      throws InterruptedException, JsonProcessingException {
    final AuditBeneficiaryFailureRequest request =
        AuditBeneficiaryFailureRequest.builder()
            .ipAddress(LOCALHOST)
            .message(reason.getDescription())
            .beneficiaryInformation(beneficiaryInformation)
            .build();
    assertAuditBeneficiaryRequest(
        requestId, jwt, path, request, AuditBeneficiaryFailureRequest.class);
  }

  private void assertAuditBeneficiaryUpdateFailure(
      final UUID requestId,
      final String jwt,
      final BeneficiaryValidationExceptionReason reason,
      final ExternalBeneficiaryInformation beneficiaryInformation,
      final ExternalUpdateBeneficiaryInformation updateBeneficiaryInformation)
      throws InterruptedException, JsonProcessingException {
    final AuditBeneficiaryUpdateFailureRequest request =
        AuditBeneficiaryUpdateFailureRequest.builder()
            .ipAddress(LOCALHOST)
            .message(reason.getDescription())
            .beneficiaryInformation(beneficiaryInformation)
            .updateBeneficiaryInformation(updateBeneficiaryInformation)
            .build();
    assertAuditBeneficiaryRequest(
        requestId,
        jwt,
        "/audit/beneficiary/update/failure",
        request,
        AuditBeneficiaryUpdateFailureRequest.class);
  }

  private void assertAuditBeneficiaryChallenge(final UUID requestId, final String jwt)
      throws JsonProcessingException, InterruptedException {
    final AuditBeneficiaryChallengeRequest request =
        AuditBeneficiaryChallengeRequest.builder().ipAddress(LOCALHOST).build();
    assertAuditBeneficiaryRequest(
        requestId,
        jwt,
        "/audit/beneficiary/authentication/challenge",
        request,
        AuditBeneficiaryChallengeRequest.class);
  }

  private void assertAuditBeneficiaryChallengeSuccess(final UUID requestId, final String jwt)
      throws JsonProcessingException, InterruptedException {
    final AuditBeneficiaryChallengeSuccessRequest request =
        AuditBeneficiaryChallengeSuccessRequest.builder().ipAddress(LOCALHOST).build();
    assertAuditBeneficiaryRequest(
        requestId,
        jwt,
        "/audit/beneficiary/authentication/success",
        request,
        AuditBeneficiaryChallengeSuccessRequest.class);
  }

  private void assertAuditBeneficiaryChallengeFailure(
      final UUID requestId, final String jwt, final String message)
      throws JsonProcessingException, InterruptedException {
    final AuditBeneficiaryChallengeFailureRequest request =
        AuditBeneficiaryChallengeFailureRequest.builder()
            .ipAddress(LOCALHOST)
            .message(message)
            .build();
    assertAuditBeneficiaryRequest(
        requestId,
        jwt,
        "/audit/beneficiary/authentication/failure",
        request,
        AuditBeneficiaryChallengeFailureRequest.class);
  }

  private <T> void assertAuditBeneficiaryRequest(
      final UUID requestId,
      final String jwt,
      final String path,
      final T payload,
      final Class<T> payloadClass)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final T actual = objectMapper.readValue(request.getBody().readUtf8(), payloadClass);
    assertThat(actual, is(payload));
  }

  private Matcher<WorkLog> workLogMatching(final WorkLog expected, final LocalDateTime now) {
    return allOf(
        samePropertyValuesAs(expected, "sysId", "message", "createdDate", "updatedDate"),
        hasProperty("sysId", notNullValue()),
        hasProperty("createdDate", equalsOrWithinTenSeconds(now)),
        hasProperty("updatedDate", equalsOrWithinTenSeconds(now)),
        hasPropertyAtPath(
            "message.payload", samePropertyValuesAs((Object) expected.getMessage().getPayload())),
        hasPropertyAtPath(
            "message.metadata",
            samePropertyValuesAs((Object) expected.getMessage().getMetadata(), "host")));
  }

  private Matcher<LocalDateTime> equalsOrWithinTenSeconds(final LocalDateTime time) {
    final LocalDateTime timeTruncated = time.truncatedTo(ChronoUnit.SECONDS);
    final LocalDateTime maximumTime = timeTruncated.plusSeconds(10);
    return new CustomTypeSafeMatcher<LocalDateTime>("equal or within 10 seconds of time") {
      @Override
      protected boolean matchesSafely(final LocalDateTime argument) {
        return !argument.isBefore(timeTruncated) && !argument.isAfter(maximumTime);
      }
    };
  }

  @SafeVarargs
  private final void assertWorkLogs(final Matcher<WorkLog>... expected) {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              digitalBeneficiaryTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from WorkLog e");
          @SuppressWarnings("unchecked")
          final List<WorkLog> actual = query.getResultList();
          assertThat(actual, containsInAnyOrder(expected));
        });
  }

  private void tearDownDb() {
    adgCoreHelper.clearDb();
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager digitalAccountEntityManager =
              digitalBeneficiaryTestEntityManager.getEntityManager();
          digitalAccountEntityManager.createQuery("delete from WorkLog").executeUpdate();
        });
  }

  @Test
  void getBeneficiaryLimitShouldReturnBeneficiariesLimitFlagResponseWhenRequestIsValid() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublicForBeneficiaryLimit();

    final AccountAccessRequiredEntities accessEntities =
        adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    adgCoreHelper.setUpAccountNumber(
        Long.parseLong(ACCOUNT_NUMBER_OTHER), accessEntities.getSavingProduct());

    final String expectedResponse =
        readClassPathResource("it/getBeneficiariesLimitNotReachedExpectedResponse.json");

    // External
    adgCoreHelper.setUpExternalBeneficiary(
        EXISTING_BENEFICIARY_SYS_ID,
        ACCOUNT_NUMBER,
        STR_123456,
        ACCT_NO_32345678,
        REF,
        MR_TEST,
        JOINT_ACCOUNT,
        false);
    // External - Pending
    adgCoreHelper.setUpExternalBeneficiary(
        2L,
        ACCOUNT_NUMBER,
        STR_123456,
        ACCT_NO_32345679,
        REF_PENDING,
        MR_TEST_PENDING,
        MEM_PENDING,
        false);

    // External - Other debtor account
    adgCoreHelper.setUpExternalBeneficiary(
        3L, ACCOUNT_NUMBER_OTHER, STR_123456, "32345680", REF, MR_TEST, JOINT_ACCOUNT, false);
    // External - Ended
    adgCoreHelper.setUpExternalBeneficiary(
        4L, ACCOUNT_NUMBER, STR_123456, "12345681", REF, "Mr Test 2", JOINT_ACCOUNT, true);
    // External - Invalid
    adgCoreHelper.setUpExternalBeneficiary(
        5L, ACCOUNT_NUMBER, STR_123456, "12345682", REF, MR_TEST, "Joint & Account", false);
    // Internal
    adgCoreHelper.setUpInternalBeneficiary(1L, Long.parseLong(ACCOUNT_NUMBER), 2234567891L, false);
    // Internal - Pending
    adgCoreHelper.setUpInternalBeneficiary(2L, Long.parseLong(ACCOUNT_NUMBER), 2234567892L, false);
    setUpWorkLog(2L, InternalBeneficiary.builder().accountNumber("2234567892").build());
    // Internal - Other debtor account
    adgCoreHelper.setUpInternalBeneficiary(
        3L, Long.parseLong(ACCOUNT_NUMBER_OTHER), 2234567893L, false);
    // Internal - Ended
    adgCoreHelper.setUpInternalBeneficiary(4L, Long.parseLong(ACCOUNT_NUMBER), 2234567894L, true);
    // Internal - Invalid
    adgCoreHelper.setUpInternalBeneficiary(5L, Long.parseLong(ACCOUNT_NUMBER), 1L, false);

    stubFindAccountSuccess(ACCOUNT_NUMBER);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoManyBeneficiaries.json"));
    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARY_LIMIT_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody()
        .json(expectedResponse);
  }

  @Test
  void getBeneficiaryLimitReachedShouldReturnBeneficiariesLimitFlagResponseWhenRequestIsValid()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublicForBeneficiaryLimit();

    final AccountAccessRequiredEntities accessEntities =
        adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    adgCoreHelper.setUpAccountNumber(
        Long.parseLong(ACCOUNT_NUMBER_OTHER), accessEntities.getSavingProduct());

    final String expectedResponse =
        readClassPathResource("it/getBeneficiariesLimitReachedExpectedResponse.json");

    // External
    adgCoreHelper.setUpExternalBeneficiary(
        EXISTING_BENEFICIARY_SYS_ID,
        ACCOUNT_NUMBER,
        STR_123456,
        ACCT_NO_32345678,
        REF,
        MR_TEST,
        JOINT_ACCOUNT,
        false);

    // Internal
    adgCoreHelper.setUpInternalBeneficiary(1L, Long.parseLong(ACCOUNT_NUMBER), 2234567891L, false);

    stubFindAccountSuccess(ACCOUNT_NUMBER);
    stubMockProductServiceResponse(
        new ClassPathResource("/it/productInfoOneOfEachBeneficiary.json"));
    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARY_LIMIT_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody()
        .json(expectedResponse);
  }

  @Test
  void
      getBeneficiaryLimitReachedForExternalShouldReturnBeneficiaryLimitsResponseWhenRequestIsValid()
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwtPublicForBeneficiaryLimit();

    final AccountAccessRequiredEntities accessEntities =
        adgCoreHelper.setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    adgCoreHelper.setUpAccountNumber(
        Long.parseLong(ACCOUNT_NUMBER_OTHER), accessEntities.getSavingProduct());

    final String expectedResponse =
        readClassPathResource("it/getBeneficiariesLimitReachedForExternalExpectedResponse.json");

    // External
    adgCoreHelper.setUpExternalBeneficiary(
        EXISTING_BENEFICIARY_SYS_ID,
        ACCOUNT_NUMBER,
        STR_123456,
        ACCT_NO_32345678,
        REF,
        MR_TEST,
        JOINT_ACCOUNT,
        false);
    // External - Pending
    adgCoreHelper.setUpExternalBeneficiary(
        2L,
        ACCOUNT_NUMBER,
        STR_123456,
        ACCT_NO_32345679,
        REF_PENDING,
        MR_TEST_PENDING,
        MEM_PENDING,
        false);

    // Internal
    adgCoreHelper.setUpInternalBeneficiary(1L, Long.parseLong(ACCOUNT_NUMBER), 2234567891L, false);
    // Internal - Pending
    adgCoreHelper.setUpInternalBeneficiary(2L, Long.parseLong(ACCOUNT_NUMBER), 2234567892L, false);
    setUpWorkLog(2L, InternalBeneficiary.builder().accountNumber("2234567892").build());
    // Internal - Other debtor account
    adgCoreHelper.setUpInternalBeneficiary(
        3L, Long.parseLong(ACCOUNT_NUMBER_OTHER), 2234567893L, false);
    // Internal - Ended
    adgCoreHelper.setUpInternalBeneficiary(4L, Long.parseLong(ACCOUNT_NUMBER), 2234567894L, true);
    // Internal - Invalid
    adgCoreHelper.setUpInternalBeneficiary(5L, Long.parseLong(ACCOUNT_NUMBER), 1L, false);

    stubFindAccountSuccess(ACCOUNT_NUMBER);
    stubMockProductServiceResponse(
        new ClassPathResource("/it/productInfoMultiInternalAndTwoExternalBeneficiary.json"));
    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_BENEFICIARY_LIMIT_PATH))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody()
        .json(expectedResponse);
  }
}
