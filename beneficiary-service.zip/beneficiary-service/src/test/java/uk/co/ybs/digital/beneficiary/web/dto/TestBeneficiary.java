package uk.co.ybs.digital.beneficiary.web.dto;

public class TestBeneficiary extends Beneficiary {
  public TestBeneficiary(final String beneficiaryId, final Long sysId) {
    super(beneficiaryId, sysId);
  }

  @Override
  public <T> T accept(final BeneficiaryVisitor<T> visitor) {
    throw new UnsupportedOperationException();
  }
}
