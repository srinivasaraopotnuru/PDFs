package uk.co.ybs.digital.beneficiary.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;
import lombok.Builder;
import lombok.Value;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.service.utilities.BeneficiaryUtils;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@ExtendWith(MockitoExtension.class)
class InternalBeneficiaryMapperTest {

  private static final Long SYS_ID = 1L;
  private static final String BENEFICIARY_ID = "beneficiaryId";
  private static final Long ACCOUNT_NUMBER = 1234567890L;

  @InjectMocks private InternalBeneficiaryMapper testSubject;
  @Mock private BeneficiaryIdGenerator beneficiaryIdGenerator;
  @Mock private BeneficiaryUtils beneficiaryUtils;

  @Test
  void mapShouldReturnResult() {
    mapShouldReturnResult(TestParameters.builder().build());
  }

  @Test
  void mapShouldHandleNullAccountNumber() {
    mapShouldReturnResult(
        TestParameters.builder().accountNumber(null).expectedAccountNumber(null).build());
  }

  @Test
  void mapShouldHandlePendingBeneficiary() {
    final ItInstruction instruction =
        ItInstruction.builder().sysId(SYS_ID).creditorAccountNumber(ACCOUNT_NUMBER).build();

    final Collection<WorkLog> workLogs = new ArrayList<>();

    when(beneficiaryIdGenerator.generateId(InternalBeneficiary.class, SYS_ID))
        .thenReturn(BENEFICIARY_ID);
    when(beneficiaryUtils.findMatchingWorkLog(same(instruction), same(workLogs)))
        .thenReturn(Optional.of(WorkLog.builder().build()));

    final InternalBeneficiary beneficiary = testSubject.map(instruction, workLogs);

    assertThat(
        beneficiary,
        is(
            InternalBeneficiary.builder()
                .sysId(null)
                .beneficiaryId(BENEFICIARY_ID)
                .accountNumber(String.valueOf(ACCOUNT_NUMBER))
                .build()));
  }

  void mapShouldReturnResult(final TestParameters testParameters) {
    final ItInstruction instruction =
        ItInstruction.builder()
            .sysId(SYS_ID)
            .creditorAccountNumber(testParameters.getAccountNumber())
            .build();

    final Collection<WorkLog> workLogs = new ArrayList<>();

    when(beneficiaryIdGenerator.generateId(InternalBeneficiary.class, SYS_ID))
        .thenReturn(BENEFICIARY_ID);
    when(beneficiaryUtils.findMatchingWorkLog(same(instruction), same(workLogs)))
        .thenReturn(Optional.empty());

    final InternalBeneficiary beneficiary = testSubject.map(instruction, workLogs);

    assertThat(
        beneficiary,
        is(
            InternalBeneficiary.builder()
                .sysId(SYS_ID)
                .beneficiaryId(BENEFICIARY_ID)
                .accountNumber(testParameters.getExpectedAccountNumber())
                .build()));
  }

  @Value
  @Builder
  private static class TestParameters {
    Long accountNumber;
    String expectedAccountNumber;

    @SuppressWarnings({"unused", "FieldMayBeFinal"})
    private static class TestParametersBuilder {
      private Long accountNumber = ACCOUNT_NUMBER;
      private String expectedAccountNumber = String.valueOf(ACCOUNT_NUMBER);
    }
  }
}
