package uk.co.ybs.digital.beneficiary.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.when;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;
import lombok.Builder;
import lombok.Value;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.service.utilities.BeneficiaryUtils;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;

@ExtendWith(MockitoExtension.class)
class ExternalBeneficiaryMapperTest {

  private static final Long SYS_ID = 1L;
  private static final String BENEFICIARY_ID = "beneficiaryId";
  private static final Long SORT_CODE = 123456L;
  private static final Long ACCOUNT_NUMBER = 12345678L;
  private static final String REFERENCE = "reference";
  private static final String NAME = "name";
  private static final String MEMORABLE_NAME = "memorableName";

  @InjectMocks private ExternalBeneficiaryMapper testSubject;
  @Mock private BeneficiaryIdGenerator beneficiaryIdGenerator;
  @Mock private BeneficiaryUtils beneficiaryUtils;

  @Test
  void mapShouldReturnResult() {
    mapShouldReturnResult(TestParameters.builder().build());
  }

  @Test
  void mapShouldHandleNullFields() {
    mapShouldReturnResult(
        TestParameters.builder()
            .sortCode(null)
            .accountNumber(null)
            .reference(null)
            .name(null)
            .memorableName(null)
            .expectedSortCode(null)
            .expectedAccountNumber(null)
            .expectedReference(null)
            .expectedName(null)
            .expectedMemorableName(null)
            .build());
  }

  @ParameterizedTest
  @ValueSource(longs = {1234567, 12345678})
  void mapShouldTruncateSortCode(final long sortCode) {
    mapShouldReturnResult(
        TestParameters.builder().sortCode(sortCode).expectedSortCode("123456").build());
  }

  @ParameterizedTest
  @ValueSource(longs = {123456789, 1234567890})
  void mapShouldTruncateAccountNumber(final long accountNumber) {
    mapShouldReturnResult(
        TestParameters.builder()
            .accountNumber(accountNumber)
            .expectedAccountNumber("12345678")
            .build());
  }

  @ParameterizedTest
  @CsvSource({
    "1,000001",
    "11,000011",
    "111,000111",
    "1111,001111",
    "11111,011111",
    "111111,111111"
  })
  void mapShouldPadSortCode(final long sortCode, final String expectedSortCode) {
    mapShouldReturnResult(
        TestParameters.builder().sortCode(sortCode).expectedSortCode(expectedSortCode).build());
  }

  @ParameterizedTest
  @CsvSource({
    "1,00000001",
    "11,00000011",
    "111,00000111",
    "1111,00001111",
    "11111,00011111",
    "111111,00111111",
    "1111111,01111111",
    "11111111,11111111"
  })
  void mapShouldPadAccountNumber(final long accountNumber, final String expectedAccountNumber) {
    mapShouldReturnResult(
        TestParameters.builder()
            .accountNumber(accountNumber)
            .expectedAccountNumber(expectedAccountNumber)
            .build());
  }

  @ParameterizedTest
  @WhitespaceSource
  void mapShouldTrimReference(final String value, final String expectedValue) {
    mapShouldReturnResult(
        TestParameters.builder().reference(value).expectedReference(expectedValue).build());
  }

  @ParameterizedTest
  @WhitespaceSource
  void mapShouldTrimName(final String value, final String expectedValue) {
    mapShouldReturnResult(TestParameters.builder().name(value).expectedName(expectedValue).build());
  }

  @ParameterizedTest
  @WhitespaceSource
  void mapShouldTrimMemorableName(final String value, final String expectedValue) {
    mapShouldReturnResult(
        TestParameters.builder().memorableName(value).expectedMemorableName(expectedValue).build());
  }

  @Test
  void mapShouldHandlePendingBeneficiary() {
    final BillPaymentInstruction instruction =
        BillPaymentInstruction.builder()
            .sysId(SYS_ID)
            .nonYbsBankAccount(
                NonYbsBankAccount.builder()
                    .sortCode(SORT_CODE)
                    .accountNumber(ACCOUNT_NUMBER)
                    .name(NAME)
                    .build())
            .reference(REFERENCE)
            .memorableName(MEMORABLE_NAME)
            .build();

    final Collection<WorkLog> workLogs = new ArrayList<>();

    when(beneficiaryIdGenerator.generateId(ExternalBeneficiary.class, SYS_ID))
        .thenReturn(BENEFICIARY_ID);
    when(beneficiaryUtils.findMatchingWorkLog(same(instruction), same(workLogs)))
        .thenReturn(Optional.of(WorkLog.builder().build()));

    final ExternalBeneficiary beneficiary = testSubject.map(instruction, workLogs);

    assertThat(
        beneficiary,
        is(
            ExternalBeneficiary.builder()
                .sysId(null)
                .beneficiaryId(BENEFICIARY_ID)
                .accountSortCode(String.valueOf(SORT_CODE))
                .accountNumber(String.valueOf(ACCOUNT_NUMBER))
                .reference(REFERENCE)
                .name(NAME)
                .memorableName(MEMORABLE_NAME)
                .build()));
  }

  private void mapShouldReturnResult(final TestParameters testParameters) {
    final BillPaymentInstruction instruction =
        BillPaymentInstruction.builder()
            .sysId(SYS_ID)
            .nonYbsBankAccount(
                NonYbsBankAccount.builder()
                    .sortCode(testParameters.getSortCode())
                    .accountNumber(testParameters.getAccountNumber())
                    .name(testParameters.getName())
                    .build())
            .reference(testParameters.getReference())
            .memorableName(testParameters.getMemorableName())
            .build();

    final Collection<WorkLog> workLogs = new ArrayList<>();

    when(beneficiaryIdGenerator.generateId(ExternalBeneficiary.class, SYS_ID))
        .thenReturn(BENEFICIARY_ID);
    when(beneficiaryUtils.findMatchingWorkLog(same(instruction), same(workLogs)))
        .thenReturn(Optional.empty());

    final ExternalBeneficiary beneficiary = testSubject.map(instruction, workLogs);

    assertThat(
        beneficiary,
        is(
            ExternalBeneficiary.builder()
                .sysId(SYS_ID)
                .beneficiaryId(BENEFICIARY_ID)
                .accountSortCode(testParameters.getExpectedSortCode())
                .accountNumber(testParameters.getExpectedAccountNumber())
                .reference(testParameters.getExpectedReference())
                .name(testParameters.getExpectedName())
                .memorableName(testParameters.getExpectedMemorableName())
                .build()));
  }

  @Value
  @Builder
  private static class TestParameters {
    Long sortCode;
    Long accountNumber;
    String reference;
    String name;
    String memorableName;

    String expectedSortCode;
    String expectedAccountNumber;
    String expectedReference;
    String expectedName;
    String expectedMemorableName;

    @SuppressWarnings({"unused", "FieldMayBeFinal"})
    private static class TestParametersBuilder {
      private Long sortCode = SORT_CODE;
      private Long accountNumber = ACCOUNT_NUMBER;
      private String reference = REFERENCE;
      private String name = NAME;
      private String memorableName = MEMORABLE_NAME;

      private String expectedSortCode = String.valueOf(SORT_CODE);
      private String expectedAccountNumber = String.valueOf(ACCOUNT_NUMBER);
      private String expectedReference = REFERENCE;
      private String expectedName = NAME;
      private String expectedMemorableName = MEMORABLE_NAME;
    }
  }

  @Target(ElementType.METHOD)
  @Retention(RetentionPolicy.RUNTIME)
  @CsvSource({"'',''", "' ',''", "' a','a'", "'a ','a'", "' a ', 'a'"})
  @interface WhitespaceSource {}
}
