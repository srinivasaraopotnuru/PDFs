package uk.co.ybs.digital.beneficiary.repository.digitalbeneficiary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.net.InetSocketAddress;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import uk.co.ybs.digital.beneficiary.config.JpaAuditingConfig;
import uk.co.ybs.digital.beneficiary.config.TestClockConfig;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@YbsDataJpaTest
@Import({JpaAuditingConfig.class, TestClockConfig.class})
public class WorkLogRepositoryTest {

  private static final Long ACCOUNT_NUMBER = 2001L;

  private static final String IP_ADDRESS = "1.2.3.4";
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String PARTY_ID = "1234567890";
  private static final String BRAND_CODE = "YBS";
  private static final InetSocketAddress HOST = InetSocketAddress.createUnresolved("host", 443);
  private static final UUID REQUEST_ID = UUID.fromString("3cfa397f-ff5d-4252-b8f0-69daac23fba4");
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final LocalDateTime ONE_DAY_AGO = LocalDateTime.parse("2020-04-22T14:56:15");

  @Autowired WorkLogRepository testSubject;

  @Autowired TestEntityManager digitalBeneficiaryTestEntityManager;

  @Test
  void shouldFindById() {
    final InternalBeneficiary beneficiary =
        InternalBeneficiary.builder().accountNumber("1234567890").build();

    final WorkLog workLog = buildWorkLog(beneficiary);
    Long sysId = digitalBeneficiaryTestEntityManager.persistAndFlush(workLog).getSysId();
    digitalBeneficiaryTestEntityManager.clear();

    final Optional<WorkLog> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(workLog));
  }

  @Test
  void shouldPersistUpdateLogEntryForExternalBeneficiary() {
    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();

    final WorkLog workLog = buildWorkLog(beneficiary);
    Long sysId = digitalBeneficiaryTestEntityManager.persistAndFlush(workLog).getSysId();
    digitalBeneficiaryTestEntityManager.clear();

    final Optional<WorkLog> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(workLog));
  }

  @Test
  void findRequestsInStateShouldReturnEmptyListIfNoRequestsInDesiredState() {
    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();
    final WorkLog workLog =
        buildWorkLog(beneficiary).toBuilder().status(WorkLog.Status.COMPLETE).build();
    digitalBeneficiaryTestEntityManager.persistAndFlush(workLog);
    digitalBeneficiaryTestEntityManager.clear();

    final ExternalBeneficiary anotherBeneficiary = buildExternalBeneficiary();
    final WorkLog anotherWorkLog =
        buildWorkLog(anotherBeneficiary).toBuilder().status(WorkLog.Status.FAILED).build();
    digitalBeneficiaryTestEntityManager.persistAndFlush(anotherWorkLog);
    digitalBeneficiaryTestEntityManager.clear();

    final List<WorkLog> found = testSubject.findRequestsInState(WorkLog.Status.PENDING);

    assertThat(found.isEmpty(), is(true));
  }

  @Test
  void findRequestsInStateShouldReturnPendingRequestsOrderedByDate() {
    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();
    final WorkLog workLog = buildWorkLog(beneficiary);
    digitalBeneficiaryTestEntityManager.persistAndFlush(workLog);
    digitalBeneficiaryTestEntityManager.clear();

    final ExternalBeneficiary otherBeneficiary = buildExternalBeneficiary();
    final WorkLog otherWorkLog = buildWorkLog(otherBeneficiary);
    digitalBeneficiaryTestEntityManager.persistAndFlush(otherWorkLog);
    digitalBeneficiaryTestEntityManager.clear();

    final List<WorkLog> found = testSubject.findRequestsInState(WorkLog.Status.PENDING);

    assertThat(found.isEmpty(), is(not(true)));
    assertThat(found, contains(samePropertyValuesAs(workLog), samePropertyValuesAs(otherWorkLog)));
  }

  @ParameterizedTest
  @CsvSource({"2020-04-22T13:56:15,1", "2020-04-23T13:56:15,1", "2020-04-24T13:56:15,0", ",0"})
  void findRequestsSinceLastDbSyncShouldReturnAllRequestsMadeSinceDateTime(
      final LocalDateTime latestUpdate, final int expectedReturns) {

    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();
    final WorkLog workLog = buildWorkLog(beneficiary);
    digitalBeneficiaryTestEntityManager.persistAndFlush(workLog);
    digitalBeneficiaryTestEntityManager.clear();

    final int count = testSubject.findRequestsAfterDate(latestUpdate, ACCOUNT_NUMBER).size();

    assertThat(count, is(expectedReturns));
  }

  @Test
  void findCountOfRequestsInStateShouldReturnCountsForState() {
    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();
    final WorkLog pendingWorkLog = buildWorkLog(beneficiary);
    final WorkLog otherPendingWorkLog = buildWorkLog(beneficiary);
    final WorkLog failedWorkLog =
        buildWorkLog(beneficiary).toBuilder().status(WorkLog.Status.FAILED).build();
    final WorkLog completedWorkLog =
        buildWorkLog(beneficiary).toBuilder().status(WorkLog.Status.COMPLETE).build();
    final WorkLog otherCompletedWorkLog =
        buildWorkLog(beneficiary).toBuilder().status(WorkLog.Status.COMPLETE).build();
    final WorkLog anotherCompletedWorkLog =
        buildWorkLog(beneficiary).toBuilder().status(WorkLog.Status.COMPLETE).build();

    digitalBeneficiaryTestEntityManager.persist(pendingWorkLog);
    digitalBeneficiaryTestEntityManager.persist(otherPendingWorkLog);
    digitalBeneficiaryTestEntityManager.persist(failedWorkLog);
    digitalBeneficiaryTestEntityManager.persist(completedWorkLog);
    digitalBeneficiaryTestEntityManager.persist(otherCompletedWorkLog);
    digitalBeneficiaryTestEntityManager.persist(anotherCompletedWorkLog);
    digitalBeneficiaryTestEntityManager.flush();
    digitalBeneficiaryTestEntityManager.clear();

    final List<ImmutablePair<WorkLog.Status, Long>> statuses =
        testSubject.findCountOfRequestsInState();

    assertThat(
        statuses,
        containsInAnyOrder(
            new ImmutablePair<>(WorkLog.Status.PENDING, 2L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 1L),
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 3L)));
  }

  @Test
  void findCountOfRequestsShouldReturnEmptyIfNoRecords() {
    final List<ImmutablePair<WorkLog.Status, Long>> statuses =
        testSubject.findCountOfRequestsInState();

    assertThat(statuses, is(empty()));
  }

  @Test
  void findRequestsAfterDateShouldFindRequests() {
    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();
    final WorkLog workLog = buildWorkLog(beneficiary);
    digitalBeneficiaryTestEntityManager.persistAndFlush(workLog);
    digitalBeneficiaryTestEntityManager.clear();

    final Collection<WorkLog> found =
        testSubject.findRequestsAfterDate(ONE_DAY_AGO, ACCOUNT_NUMBER);

    assertThat(found, not(empty()));
    assertThat(found, contains(samePropertyValuesAs(workLog)));
  }

  @ParameterizedTest
  @CsvSource({"2020-04-23T14:56:14,false", "2020-04-23T14:56:15,false", "2020-04-23T14:56:16,true"})
  void findRequestsAfterDateShouldNotFindRequestsBeforeDate(
      final LocalDateTime cutOff, final boolean expectedFind) {
    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();
    final WorkLog workLog = buildWorkLog(beneficiary);
    digitalBeneficiaryTestEntityManager.persistAndFlush(workLog);
    digitalBeneficiaryTestEntityManager.clear();

    final Collection<WorkLog> found = testSubject.findRequestsAfterDate(cutOff, ACCOUNT_NUMBER);

    assertThat(found.isEmpty(), is(expectedFind));
  }

  @Test
  void findRequestsAfterDateShouldNotFindRequestsInFailedState() {
    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();
    final WorkLog workLog =
        buildWorkLog(beneficiary).toBuilder().status(WorkLog.Status.FAILED).build();
    digitalBeneficiaryTestEntityManager.persistAndFlush(workLog);
    digitalBeneficiaryTestEntityManager.clear();

    final Collection<WorkLog> found =
        testSubject.findRequestsAfterDate(ONE_DAY_AGO, ACCOUNT_NUMBER);

    assertThat(found, empty());
  }

  @Test
  void findRequestsAfterDateShouldNotFindRequestsForDifferentAccount() {
    final ExternalBeneficiary beneficiary = buildExternalBeneficiary();
    final WorkLog workLog = buildWorkLog(beneficiary);
    digitalBeneficiaryTestEntityManager.persistAndFlush(workLog);
    digitalBeneficiaryTestEntityManager.clear();

    final Collection<WorkLog> found = testSubject.findRequestsAfterDate(ONE_DAY_AGO, 1001L);

    assertThat(found, empty());
  }

  private static ExternalBeneficiary buildExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .accountNumber("12345678")
        .accountSortCode("112233")
        .memorableName("MEM")
        .name("NAME")
        .reference("REF")
        .build();
  }

  private static WorkLog buildWorkLog(final Beneficiary beneficiary) {
    return WorkLog.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .status(WorkLog.Status.PENDING)
        .operation(WorkLog.Operation.CREATE)
        .message(
            BeneficiaryRequest.builder()
                .payload(BeneficiaryRequest.Payload.builder().beneficiary(beneficiary).build())
                .metadata(
                    RequestMetadata.builder()
                        .requestId(REQUEST_ID)
                        .sessionId(SESSION_ID)
                        .ipAddress(IP_ADDRESS)
                        .forwardingAuth(FORWARDING_AUTH)
                        .partyId(PARTY_ID)
                        .brandCode(BRAND_CODE)
                        .host(HOST)
                        .build())
                .build())
        .build();
  }
}
