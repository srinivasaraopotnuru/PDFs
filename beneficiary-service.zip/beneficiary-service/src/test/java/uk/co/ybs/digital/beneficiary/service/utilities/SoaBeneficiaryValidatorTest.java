package uk.co.ybs.digital.beneficiary.service.utilities;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.same;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.LIMIT_REACHED;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.PENDING;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.exception.UnsupportedBeneficiaryFieldUpdateException;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.ExternalUpdateBeneficiaryInformationWrapper;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.product.dto.ProductInfo;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.beneficiary.web.dto.TestBeneficiary;

@ExtendWith(MockitoExtension.class)
public class SoaBeneficiaryValidatorTest {

  private static final long EXTERNAL_ACCOUNT_NUMBER = 12345678L;
  private static final long INTERNAL_ACCOUNT_NUMBER = 1234567890L;
  private static final String EXTERNAL_ACCOUNT_NUMBER_STRING =
      String.valueOf(EXTERNAL_ACCOUNT_NUMBER);
  private static final String INTERNAL_ACCOUNT_NUMBER_STRING =
      String.valueOf(INTERNAL_ACCOUNT_NUMBER);
  private static final String EXTERNAL_ACCOUNT_NUMBER_OTHER = "87654321";
  private static final String INTERNAL_ACCOUNT_NUMBER_OTHER = "9996663331";
  private static final String EXTERNAL_BENEFICIARY_ID_UPDATE = "beneficiaryIdUpdate";
  private static final int BENEFICIARIES_LIMIT = 2;
  public static final String BENEFICIARY_ID_A = "beneficiaryIdA";
  public static final String BENEFICIARY_ID_B = "beneficiaryIdB";

  @InjectMocks private SoaBeneficiaryValidator testSubject;
  @Mock private ProductBeneficiaryLimitValidator productBeneficiaryLimitValidator;
  @Mock private BeneficiaryInformationFactory beneficiaryInformationFactory;
  @Mock private BeneficiaryUtils beneficiaryUtils;
  @Mock private BeneficiaryAuditor beneficiaryAuditor;

  @ParameterizedTest
  @MethodSource("validateExternalCreateArguments")
  void validateExternalCreateShouldValidateValidBeneficiary(
      final List<Beneficiary> beneficiaries, final int expectedCurrentBeneficiaries) {
    final ProductInfo productInfo = TestHelper.createProductInfo();
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary request =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER)
            .toBuilder()
            .reference("NEWREF")
            .build();

    when(productBeneficiaryLimitValidator.validateExternalBeneficiaryLimit(
            eq(EXTERNAL_ACCOUNT_NUMBER_STRING),
            eq(expectedCurrentBeneficiaries),
            same(productInfo)))
        .thenReturn(BENEFICIARIES_LIMIT);

    final int limit =
        testSubject.validateExternalCreate(
            EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, productInfo, request, metadata);

    assertThat(limit, is(BENEFICIARIES_LIMIT));

    verifyNoInteractions(beneficiaryInformationFactory);
    verifyNoInteractions(beneficiaryAuditor);
  }

  private static Stream<Arguments> validateExternalCreateArguments() {
    return Stream.of(
        Arguments.of(Collections.emptyList(), 0),
        Arguments.of(
            Collections.singletonList(
                createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, BENEFICIARY_ID_A)),
            1),
        Arguments.of(
            Collections.singletonList(
                createInternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, BENEFICIARY_ID_B)),
            0));
  }

  @Test
  void validateExternalCreateShouldThrowExceptionWhenBeneficiariesLimitWouldBeExceeded() {
    final ExternalBeneficiary request = createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER);
    final List<Beneficiary> beneficiaries = Collections.singletonList(request);
    final ProductInfo productInfo = TestHelper.createProductInfo();
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    final ExternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createExternalBeneficiaryInformation(
            EXTERNAL_ACCOUNT_NUMBER_STRING, EXTERNAL_ACCOUNT_NUMBER_OTHER);
    when(beneficiaryInformationFactory.buildExternal(EXTERNAL_ACCOUNT_NUMBER, request))
        .thenReturn(expectedAuditBody);

    doThrow(
            new BeneficiaryValidationException(
                String.format(
                    "External beneficiary limit exceeded for account: %s",
                    EXTERNAL_ACCOUNT_NUMBER_STRING),
                LIMIT_REACHED))
        .when(productBeneficiaryLimitValidator)
        .validateExternalBeneficiaryLimit(anyString(), anyInt(), any());

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateExternalCreate(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, productInfo, request, metadata));

    assertThat(
        exception.getMessage(),
        is("External beneficiary limit exceeded for account: " + EXTERNAL_ACCOUNT_NUMBER_STRING));
    assertThat(exception.getReason(), is(LIMIT_REACHED));
    verify(beneficiaryAuditor)
        .auditBeneficiaryCreateFailure(expectedAuditBody, "Limit Exceeded", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @ParameterizedTest
  @MethodSource("duplicateExistingExternalBeneficiaries")
  void validateExternalCreateShouldThrowExceptionWhenBeneficiaryAlreadyExists(
      final ExternalBeneficiary existingBeneficiary) {
    final ExternalBeneficiary request = createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER);
    final List<Beneficiary> beneficiaries = Collections.singletonList(existingBeneficiary);
    final ProductInfo productInfo = TestHelper.createProductInfo();
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    when(beneficiaryUtils.compareReferences(
            request.getReference(), existingBeneficiary.getReference()))
        .thenReturn(true);

    final ExternalBeneficiaryInformation expectedAuditBody = createExternalBeneficiaryInformation();
    when(beneficiaryInformationFactory.buildExternal(EXTERNAL_ACCOUNT_NUMBER, request))
        .thenReturn(expectedAuditBody);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateExternalCreate(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, productInfo, request, metadata));

    assertThat(
        exception.getMessage(),
        is("Requested beneficiary already exists for account: " + EXTERNAL_ACCOUNT_NUMBER_STRING));
    assertThat(exception.getReason(), is(DUPLICATE));
    verify(beneficiaryAuditor)
        .auditBeneficiaryCreateFailure(expectedAuditBody, "Duplicate Beneficiary", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @Test
  void validateExternalUpdateShouldValidateValidBeneficiary() {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary request =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, EXTERNAL_BENEFICIARY_ID_UPDATE)
            .toBuilder()
            .sysId(1L)
            .build();
    final ExternalBeneficiary otherBeneficiary =
        createExternalBeneficiary("12345678", "beneficiaryIdOther").toBuilder().sysId(2L).build();
    final List<Beneficiary> beneficiaries = Arrays.asList(request, otherBeneficiary);

    assertDoesNotThrow(
        () ->
            testSubject.validateExternalUpdate(
                EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, request, metadata));
    verifyNoInteractions(beneficiaryUtils);
    verifyNoInteractions(productBeneficiaryLimitValidator);
    verifyNoInteractions(beneficiaryInformationFactory);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @ParameterizedTest
  @CsvSource(
      value = {"New reference,Existing reference", "Reference,null", "null,Reference"},
      nullValues = "null")
  void validateExternalUpdateShouldValidateNewBeneficiaryReference(
      final String requestReference, final String existingReference) {
    final ExternalBeneficiary request =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_STRING, EXTERNAL_BENEFICIARY_ID_UPDATE)
            .toBuilder()
            .sysId(1L)
            .reference(requestReference)
            .build();

    final ExternalBeneficiary existingBeneficiary =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_STRING, EXTERNAL_BENEFICIARY_ID_UPDATE)
            .toBuilder()
            .sysId(1L)
            .reference(existingReference)
            .build();

    final List<Beneficiary> beneficiaries = Collections.singletonList(existingBeneficiary);
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    assertDoesNotThrow(
        () ->
            testSubject.validateExternalUpdate(
                EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, request, metadata));
    verifyNoInteractions(beneficiaryUtils);
    verifyNoInteractions(productBeneficiaryLimitValidator);
    verifyNoInteractions(beneficiaryInformationFactory);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @ParameterizedTest
  @MethodSource("validateExternalUpdateBeneficiaries")
  void validateExternalUpdateShouldIgnoreRequestedBeneficiary(
      @SuppressWarnings("unused") final String label, final ExternalBeneficiary request) {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final List<Beneficiary> beneficiaries = Collections.singletonList(request);

    assertDoesNotThrow(
        () ->
            testSubject.validateExternalUpdate(
                EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, request, metadata));
    verifyNoInteractions(productBeneficiaryLimitValidator);
    verifyNoInteractions(beneficiaryInformationFactory);
    verifyNoInteractions(beneficiaryAuditor);
  }

  private static Stream<Arguments> validateExternalUpdateBeneficiaries() {
    return Stream.of(
        Arguments.of(
            "All fields",
            createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, EXTERNAL_BENEFICIARY_ID_UPDATE)
                .toBuilder()
                .sysId(1L)
                .build()),
        Arguments.of(
            "Mandatory fields",
            createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, EXTERNAL_BENEFICIARY_ID_UPDATE)
                .toBuilder()
                .sysId(1L)
                .reference(null)
                .memorableName(null)
                .build()));
  }

  @Test
  void validateExternalUpdateShouldIgnoreInternalBeneficiaries() {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary request =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, EXTERNAL_BENEFICIARY_ID_UPDATE)
            .toBuilder()
            .sysId(1L)
            .build();
    final InternalBeneficiary internalBeneficiary =
        createInternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, "beneficiaryIdOther")
            .toBuilder()
            .sysId(2L)
            .build();
    final List<Beneficiary> beneficiaries = Arrays.asList(request, internalBeneficiary);

    assertDoesNotThrow(
        () ->
            testSubject.validateExternalUpdate(
                EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, request, metadata));
    verifyNoInteractions(productBeneficiaryLimitValidator);
    verifyNoInteractions(beneficiaryInformationFactory);
    verifyNoInteractions(beneficiaryAuditor);
  }

  @ParameterizedTest
  @MethodSource("duplicateExistingExternalBeneficiaries")
  void validateExternalUpdateShouldThrowExceptionWhenBeneficiaryAlreadyExists(
      final ExternalBeneficiary existingBeneficiary) {
    final ExternalBeneficiary request =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, EXTERNAL_BENEFICIARY_ID_UPDATE);
    final List<Beneficiary> beneficiaries = Collections.singletonList(existingBeneficiary);
    final ProductInfo productInfo = TestHelper.createProductInfo();
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    when(beneficiaryUtils.compareReferences(
            request.getReference(), existingBeneficiary.getReference()))
        .thenReturn(true);

    final ExternalBeneficiaryInformation expectedAuditBody = createExternalBeneficiaryInformation();
    when(beneficiaryInformationFactory.buildExternal(EXTERNAL_ACCOUNT_NUMBER, request))
        .thenReturn(expectedAuditBody);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateExternalCreate(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, productInfo, request, metadata));

    assertThat(
        exception.getMessage(),
        is("Requested beneficiary already exists for account: " + EXTERNAL_ACCOUNT_NUMBER_STRING));
    assertThat(exception.getReason(), is(DUPLICATE));
    verify(beneficiaryAuditor)
        .auditBeneficiaryCreateFailure(expectedAuditBody, "Duplicate Beneficiary", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @Test
  void validateExternalUpdateShouldThrowExceptionWhenBeneficiaryDoesNotExist() {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary request =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, EXTERNAL_BENEFICIARY_ID_UPDATE);
    final List<Beneficiary> beneficiaries =
        Collections.singletonList(
            createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, "beneficiaryIdExternalOther"));

    final AccountResourceNotFoundException exception =
        assertThrows(
            AccountResourceNotFoundException.class,
            () ->
                testSubject.validateExternalUpdate(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, request, metadata));

    assertThat(exception.getMessage(), is("Beneficiary beneficiaryIdUpdate not found"));
    verifyNoInteractions(productBeneficiaryLimitValidator);
    verifyNoInteractions(beneficiaryAuditor);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @Test
  void validateExternalUpdateShouldThrowExceptionWhenBeneficiaryIsPending() {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary request =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, EXTERNAL_BENEFICIARY_ID_UPDATE);
    final ExternalBeneficiary existingBeneficiary =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, EXTERNAL_BENEFICIARY_ID_UPDATE);
    final List<Beneficiary> existingBeneficiaries = Collections.singletonList(existingBeneficiary);

    final ExternalUpdateBeneficiaryInformationWrapper expectedAuditBody =
        new ExternalUpdateBeneficiaryInformationWrapper(
            createExternalBeneficiaryInformation(), createExternalUpdateBeneficiaryInformation());
    when(beneficiaryInformationFactory.buildExternalUpdate(
            EXTERNAL_ACCOUNT_NUMBER, request, existingBeneficiary))
        .thenReturn(expectedAuditBody);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateExternalUpdate(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, existingBeneficiaries, request, metadata));

    assertThat(exception.getMessage(), is("Beneficiary beneficiaryIdUpdate is in a pending state"));
    verifyNoInteractions(productBeneficiaryLimitValidator);
    verify(beneficiaryAuditor)
        .auditBeneficiaryUpdateFailure(expectedAuditBody, "Pending Beneficiary", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @ParameterizedTest
  @MethodSource("unsupportedFieldUpdateBeneficiaries")
  void
      validateExternalUpdateShouldThrowExceptionWhenUpdatingAndBeneficiaryHasUnsupportedFieldChanged(
          final ExternalBeneficiary request,
          final String expectedExceptionMessage,
          final List<String> expectedUnsupportedFields) {
    final ExternalBeneficiary existingBeneficiary =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_STRING, EXTERNAL_BENEFICIARY_ID_UPDATE);
    validateExternalUpdateShouldThrowExceptionWhenUpdatingAndBeneficiaryHasUnsupportedFieldChanged(
        request, existingBeneficiary, expectedExceptionMessage, expectedUnsupportedFields);
  }

  private static Stream<Arguments> unsupportedFieldUpdateBeneficiaries() {
    return Stream.of(
        Arguments.of(
            createExternalBeneficiary(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, EXTERNAL_BENEFICIARY_ID_UPDATE)
                .toBuilder()
                .accountNumber("")
                .build(),
            "Unsupported fields: [accountNumber]",
            Collections.singletonList("accountNumber")),
        Arguments.of(
            createExternalBeneficiary(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, EXTERNAL_BENEFICIARY_ID_UPDATE)
                .toBuilder()
                .accountSortCode("")
                .build(),
            "Unsupported fields: [accountSortCode]",
            Collections.singletonList("accountSortCode")),
        Arguments.of(
            createExternalBeneficiary(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, EXTERNAL_BENEFICIARY_ID_UPDATE)
                .toBuilder()
                .name("")
                .build(),
            "Unsupported fields: [name]",
            Collections.singletonList("name")),
        Arguments.of(
            createExternalBeneficiary(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, EXTERNAL_BENEFICIARY_ID_UPDATE)
                .toBuilder()
                .accountNumber("")
                .accountSortCode("")
                .name("")
                .reference("")
                .build(),
            "Unsupported fields: [accountNumber, accountSortCode, name]",
            Arrays.asList("accountNumber", "accountSortCode", "name")));
  }

  private void
      validateExternalUpdateShouldThrowExceptionWhenUpdatingAndBeneficiaryHasUnsupportedFieldChanged(
          final ExternalBeneficiary request,
          final ExternalBeneficiary existingBeneficiary,
          final String expectedExceptionMessage,
          final List<String> expectedUnsupportedFields) {
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final List<Beneficiary> beneficiaries = Collections.singletonList(existingBeneficiary);

    final ExternalUpdateBeneficiaryInformationWrapper expectedAuditBody =
        new ExternalUpdateBeneficiaryInformationWrapper(
            createExternalBeneficiaryInformation(), createExternalUpdateBeneficiaryInformation());
    when(beneficiaryInformationFactory.buildExternalUpdate(
            EXTERNAL_ACCOUNT_NUMBER, request, existingBeneficiary))
        .thenReturn(expectedAuditBody);

    final UnsupportedBeneficiaryFieldUpdateException exception =
        assertThrows(
            UnsupportedBeneficiaryFieldUpdateException.class,
            () ->
                testSubject.validateExternalUpdate(
                    EXTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, request, metadata));

    assertThat(exception.getMessage(), is(expectedExceptionMessage));
    assertThat(exception.getUnsupportedFields(), is(expectedUnsupportedFields));
    assertThat(exception.getSupportedFields(), is(Arrays.asList("reference", "memorableName")));
    verifyNoInteractions(productBeneficiaryLimitValidator);
    verify(beneficiaryAuditor)
        .auditBeneficiaryUpdateFailure(expectedAuditBody, "Unsupported Field Update", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @ParameterizedTest
  @MethodSource("newInternalBeneficiaryValidationArguments")
  void validateInternalCreateShouldValidateValidBeneficiary(
      final List<Beneficiary> beneficiaries, final int expectedCurrentBeneficiaries) {
    final ProductInfo productInfo = TestHelper.createProductInfo();
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final InternalBeneficiary request = createInternalBeneficiary("9876543210");

    when(productBeneficiaryLimitValidator.validateInternalBeneficiaryLimit(
            eq(INTERNAL_ACCOUNT_NUMBER_STRING),
            eq(expectedCurrentBeneficiaries),
            same(productInfo)))
        .thenReturn(BENEFICIARIES_LIMIT);

    final int limit =
        testSubject.validateInternalCreate(
            INTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, productInfo, request, metadata);

    assertThat(limit, is(BENEFICIARIES_LIMIT));

    verifyNoInteractions(beneficiaryInformationFactory);
    verifyNoInteractions(beneficiaryAuditor);
  }

  private static Stream<Arguments> newInternalBeneficiaryValidationArguments() {
    return Stream.of(
        Arguments.of(Collections.emptyList(), 0),
        Arguments.of(
            Collections.singletonList(
                createInternalBeneficiary(INTERNAL_ACCOUNT_NUMBER_OTHER, BENEFICIARY_ID_A)),
            1),
        Arguments.of(
            Collections.singletonList(createExternalBeneficiary("9876543210", BENEFICIARY_ID_B)),
            0));
  }

  @Test
  void validateInternalShouldThrowExceptionWhenBeneficiariesLimitWouldBeExceeded() {
    final InternalBeneficiary request = createInternalBeneficiary(INTERNAL_ACCOUNT_NUMBER_OTHER);
    final List<Beneficiary> beneficiaries = Collections.singletonList(request);
    final ProductInfo productInfo = TestHelper.createProductInfo();
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    final InternalBeneficiaryInformation expectedAuditBody = createInternalBeneficiaryInformation();
    when(beneficiaryInformationFactory.buildInternal(INTERNAL_ACCOUNT_NUMBER, request))
        .thenReturn(expectedAuditBody);

    doThrow(
            new BeneficiaryValidationException(
                String.format(
                    "Internal beneficiary limit exceeded for account: %s",
                    INTERNAL_ACCOUNT_NUMBER_STRING),
                LIMIT_REACHED))
        .when(productBeneficiaryLimitValidator)
        .validateInternalBeneficiaryLimit(anyString(), anyInt(), any());

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateInternalCreate(
                    INTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, productInfo, request, metadata));

    assertThat(
        exception.getMessage(),
        is("Internal beneficiary limit exceeded for account: " + INTERNAL_ACCOUNT_NUMBER_STRING));
    assertThat(exception.getReason(), is(LIMIT_REACHED));
    verify(beneficiaryAuditor)
        .auditBeneficiaryCreateFailure(expectedAuditBody, "Limit Exceeded", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @Test
  void validateInternalShouldThrowExceptionWhenBeneficiaryAlreadyExists() {
    final InternalBeneficiary request = createInternalBeneficiary(INTERNAL_ACCOUNT_NUMBER_OTHER);
    final List<Beneficiary> beneficiaries = Collections.singletonList(request);
    final ProductInfo productInfo = TestHelper.createProductInfo();
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    final InternalBeneficiaryInformation expectedAuditBody = createInternalBeneficiaryInformation();
    when(beneficiaryInformationFactory.buildInternal(INTERNAL_ACCOUNT_NUMBER, request))
        .thenReturn(expectedAuditBody);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateInternalCreate(
                    INTERNAL_ACCOUNT_NUMBER_STRING, beneficiaries, productInfo, request, metadata));

    assertThat(
        exception.getMessage(),
        is("Requested beneficiary already exists for account: " + INTERNAL_ACCOUNT_NUMBER_STRING));
    assertThat(exception.getReason(), is(DUPLICATE));
    verify(beneficiaryAuditor)
        .auditBeneficiaryCreateFailure(expectedAuditBody, "Duplicate Beneficiary", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @Test
  void validateDeleteShouldValidateValidBeneficiaryAndReturnIt() {
    final String requestBeneficiaryId = BENEFICIARY_ID_A;
    final TestBeneficiary otherBeneficiary = new TestBeneficiary(BENEFICIARY_ID_B, 1L);
    final TestBeneficiary requestedBeneficiary = new TestBeneficiary(BENEFICIARY_ID_A, 2L);
    final List<Beneficiary> beneficiaries = Arrays.asList(otherBeneficiary, requestedBeneficiary);
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    final Beneficiary beneficiary =
        testSubject.validateDelete(
            beneficiaries, requestBeneficiaryId, INTERNAL_ACCOUNT_NUMBER_STRING, metadata);

    assertThat(beneficiary, is(requestedBeneficiary));
  }

  @Test
  void validateDeleteShouldShouldThrowExceptionWhenBeneficiaryDoesNotExist() {
    final String requestBeneficiaryId = "beneficiaryA";
    final RequestMetadata metadata = TestHelper.createRequestMetadata();
    final List<Beneficiary> beneficiaries =
        Collections.singletonList(new TestBeneficiary(BENEFICIARY_ID_B, 1L));

    final AccountResourceNotFoundException exception =
        assertThrows(
            AccountResourceNotFoundException.class,
            () ->
                testSubject.validateDelete(
                    beneficiaries, requestBeneficiaryId, INTERNAL_ACCOUNT_NUMBER_STRING, metadata));

    assertThat(exception.getMessage(), is("Beneficiary beneficiaryA not found"));
  }

  @Test
  void validateDeleteShouldThrowExceptionWhenInternalBeneficiaryIsPending() {
    final String requestBeneficiaryId = "beneficiaryA";
    final InternalBeneficiary request =
        createInternalBeneficiary(INTERNAL_ACCOUNT_NUMBER_OTHER, requestBeneficiaryId);
    final List<Beneficiary> beneficiaries = Collections.singletonList(request);
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    final InternalBeneficiaryInformation expectedAuditBody = createInternalBeneficiaryInformation();
    when(beneficiaryInformationFactory.buildInternal(INTERNAL_ACCOUNT_NUMBER, request))
        .thenReturn(expectedAuditBody);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateDelete(
                    beneficiaries, requestBeneficiaryId, INTERNAL_ACCOUNT_NUMBER_STRING, metadata));

    assertThat(exception.getMessage(), is("Beneficiary beneficiaryA is in a pending state"));
    assertThat(exception.getReason(), is(PENDING));
    verify(beneficiaryAuditor)
        .auditBeneficiaryDeleteFailure(expectedAuditBody, "Pending Beneficiary", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  @Test
  void validateDeleteShouldThrowExceptionWhenExternalBeneficiaryIsPending() {
    final String requestBeneficiaryId = "beneficiaryA";
    final ExternalBeneficiary request =
        createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_STRING, requestBeneficiaryId);
    final List<Beneficiary> beneficiaries = Collections.singletonList(request);
    final RequestMetadata metadata = TestHelper.createRequestMetadata();

    final ExternalBeneficiaryInformation expectedAuditBody = createExternalBeneficiaryInformation();
    when(beneficiaryInformationFactory.buildExternal(EXTERNAL_ACCOUNT_NUMBER, request))
        .thenReturn(expectedAuditBody);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateDelete(
                    beneficiaries, requestBeneficiaryId, EXTERNAL_ACCOUNT_NUMBER_STRING, metadata));

    assertThat(exception.getMessage(), is("Beneficiary beneficiaryA is in a pending state"));
    assertThat(exception.getReason(), is(PENDING));
    verify(beneficiaryAuditor)
        .auditBeneficiaryDeleteFailure(expectedAuditBody, "Pending Beneficiary", metadata);
    verifyNoMoreInteractions(beneficiaryInformationFactory);
    verifyNoMoreInteractions(beneficiaryAuditor);
  }

  private static Stream<Arguments> duplicateExistingExternalBeneficiaries() {
    return Stream.of(
        // Exact match
        Arguments.of(createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, BENEFICIARY_ID_A)),
        // Exact match with different casing
        Arguments.of(
            createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, BENEFICIARY_ID_B)
                .toBuilder()
                .reference("rEf")
                .build()),
        // Field not compared changed
        Arguments.of(
            createExternalBeneficiary(EXTERNAL_ACCOUNT_NUMBER_OTHER, "beneficiaryIdC")
                .toBuilder()
                .name("X")
                .memorableName("Y")
                .build()));
  }

  private static ExternalBeneficiary createExternalBeneficiary(final String accountNumber) {
    return createExternalBeneficiary(accountNumber, null);
  }

  private static ExternalBeneficiary createExternalBeneficiary(
      final String accountNumber, final String beneficiaryId) {
    return ExternalBeneficiary.builder()
        .beneficiaryId(beneficiaryId)
        .accountNumber(accountNumber)
        .accountSortCode("112233")
        .memorableName("MEM")
        .name("NAME")
        .reference("REF")
        .build();
  }

  public static InternalBeneficiary createInternalBeneficiary(final String accountNumber) {
    return createInternalBeneficiary(accountNumber, null);
  }

  public static InternalBeneficiary createInternalBeneficiary(
      final String accountNumber, final String beneficiaryId) {
    return InternalBeneficiary.builder()
        .beneficiaryId(beneficiaryId)
        .accountNumber(accountNumber)
        .build();
  }

  private static ExternalBeneficiaryInformation createExternalBeneficiaryInformation() {
    return ExternalBeneficiaryInformation.builder()
        .accountNumber(SoaBeneficiaryValidatorTest.EXTERNAL_ACCOUNT_NUMBER_STRING)
        .payeeAccountNumber(SoaBeneficiaryValidatorTest.EXTERNAL_ACCOUNT_NUMBER_OTHER)
        .payeeSortCode("112233")
        .payeeName("NAME")
        .reference("REF")
        .memorableName("MEM")
        .build();
  }

  private static InternalBeneficiaryInformation createInternalBeneficiaryInformation() {
    return InternalBeneficiaryInformation.builder()
        .payeeAccountNumber(SoaBeneficiaryValidatorTest.INTERNAL_ACCOUNT_NUMBER_OTHER)
        .accountNumber(SoaBeneficiaryValidatorTest.INTERNAL_ACCOUNT_NUMBER_STRING)
        .build();
  }

  private static ExternalUpdateBeneficiaryInformation createExternalUpdateBeneficiaryInformation() {
    return ExternalUpdateBeneficiaryInformation.builder()
        .reference("NEW REF")
        .memorableName("NEW MEM")
        .build();
  }
}
