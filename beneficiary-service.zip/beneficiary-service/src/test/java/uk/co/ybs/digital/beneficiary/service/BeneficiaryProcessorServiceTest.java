package uk.co.ybs.digital.beneficiary.service;

import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.TECHNICAL;
import static uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog.Operation.CREATE;

import com.google.common.collect.ImmutableMap;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.transaction.CannotCreateTransactionException;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest.Payload;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.repository.core.MetadataRepository;
import uk.co.ybs.digital.beneficiary.repository.digitalbeneficiary.WorkLogRepository;
import uk.co.ybs.digital.beneficiary.service.audit.AuditServiceException;
import uk.co.ybs.digital.beneficiary.service.processor.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.service.processor.BeneficiaryRequestFactory;
import uk.co.ybs.digital.beneficiary.service.processor.ResolvedBeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.service.utilities.WorkLogMetrics;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.beneficiary.web.dto.TestBeneficiary;

@ExtendWith(MockitoExtension.class)
public class BeneficiaryProcessorServiceTest {

  private static final long ACCOUNT_NUMBER = 1L;
  private static final String BENEFICIARY_IDENTIFIER = "abc123";
  private static final long BENEFICIARY_SYS_ID = 2L;

  private BeneficiaryProcessorService testSubject;

  @Mock private WorkLogRepository workLogRepository;

  @Mock private MetadataRepository metadataRepository;

  @Mock private BeneficiaryRequestFactory beneficiaryRequestFactory;

  @Mock private BeneficiaryRequest beneficiaryRequest;

  @Mock private ResolvedBeneficiaryRequest resolvedBeneficiaryRequest;

  @Mock private WorkLogMetrics workLogMetrics;

  private LocalDateTime now;

  @BeforeEach
  void setUp() {
    final Clock clock =
        Clock.fixed(Instant.parse("2020-05-26T13:45:01Z"), ZoneId.of("Europe/London"));

    now = LocalDateTime.now(clock);

    testSubject =
        new BeneficiaryProcessorService(
            workLogRepository,
            metadataRepository,
            beneficiaryRequestFactory,
            workLogMetrics,
            clock);
  }

  @Test
  void processShouldDoNothingWhenThereAreNoPendingRequests() {
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(Collections.emptyList());

    final List<WorkLog> pendingRequests = Collections.emptyList();
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    testSubject.process();

    verify(workLogMetrics).setValues(Collections.emptyMap());
    verifyNoInteractions(beneficiaryRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void processShouldUpdateMetricsWhenNoPendingRequests() {
    final List<ImmutablePair<WorkLog.Status, Long>> requestStates =
        Arrays.asList(
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 3L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 2L));
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(requestStates);

    final List<WorkLog> pendingRequests = Collections.emptyList();
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    final Map<WorkLog.Status, Long> expectedStatusCounts =
        ImmutableMap.of(WorkLog.Status.COMPLETE, 3L, WorkLog.Status.FAILED, 2L);

    testSubject.process();

    verify(workLogMetrics).setValues(expectedStatusCounts);
    verifyNoInteractions(beneficiaryRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void processShouldHandleUnexpectedExceptions() {
    doThrow(RuntimeException.class).when(workLogRepository).findCountOfRequestsInState();

    testSubject.process();

    verifyNoInteractions(beneficiaryRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @ParameterizedTest
  @ValueSource(
      classes = {DataAccessResourceFailureException.class, CannotCreateTransactionException.class})
  void processShouldHandleFailedLivenessCheckWhenDBUnavailable(final Class<Exception> exception) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final Beneficiary beneficiary = new TestBeneficiary(BENEFICIARY_IDENTIFIER, BENEFICIARY_SYS_ID);
    final WorkLog workLog = createWorkLog(beneficiary, CREATE, requestMetadata);

    final List<ImmutablePair<WorkLog.Status, Long>> requestStates =
        Arrays.asList(
            new ImmutablePair<>(WorkLog.Status.PENDING, 1L),
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 3L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 2L));
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(requestStates);

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    doThrow(exception).when(metadataRepository).count();

    final Map<WorkLog.Status, Long> expectedMap =
        ImmutableMap.of(
            WorkLog.Status.PENDING, 1L, WorkLog.Status.COMPLETE, 3L, WorkLog.Status.FAILED, 2L);

    testSubject.process();

    verify(workLogMetrics).setValues(expectedMap);
    verifyNoInteractions(beneficiaryRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void processWorkLogShouldExecuteRequest() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final Beneficiary beneficiary = new TestBeneficiary(BENEFICIARY_IDENTIFIER, BENEFICIARY_SYS_ID);
    final WorkLog workLog = createWorkLog(beneficiary, CREATE, requestMetadata);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.COMPLETE).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(beneficiaryRequestFactory.build(workLog, now)).thenReturn(beneficiaryRequest);
    when(beneficiaryRequest.resolve()).thenReturn(resolvedBeneficiaryRequest);

    testSubject.process();

    verify(resolvedBeneficiaryRequest).execute();
    verify(resolvedBeneficiaryRequest).auditSuccess();
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @Test
  void processWorkLogShouldHandleSuccessAuditErrorWhenExecutingRequest() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final Beneficiary beneficiary = new TestBeneficiary(BENEFICIARY_IDENTIFIER, BENEFICIARY_SYS_ID);
    final WorkLog workLog = createWorkLog(beneficiary, CREATE, requestMetadata);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.COMPLETE).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(beneficiaryRequestFactory.build(workLog, now)).thenReturn(beneficiaryRequest);
    when(beneficiaryRequest.resolve()).thenReturn(resolvedBeneficiaryRequest);

    doThrow(new AuditServiceException("Audit Failure"))
        .when(resolvedBeneficiaryRequest)
        .auditSuccess();

    testSubject.process();

    verify(resolvedBeneficiaryRequest).execute();
    verify(resolvedBeneficiaryRequest).auditSuccess();
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @Test
  void processWorkLogShouldHandleErrorsResolvingBeneficiaryRequests() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final Beneficiary beneficiary = new TestBeneficiary(BENEFICIARY_IDENTIFIER, BENEFICIARY_SYS_ID);
    final WorkLog workLog = createWorkLog(beneficiary, CREATE, requestMetadata);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(beneficiaryRequestFactory.build(workLog, now)).thenReturn(beneficiaryRequest);
    when(beneficiaryRequest.resolve()).thenThrow(RuntimeException.class);

    testSubject.process();

    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @Test
  void processWorkLogShouldHandleBeneficiaryValidationExceptions() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final Beneficiary beneficiary = new TestBeneficiary(BENEFICIARY_IDENTIFIER, BENEFICIARY_SYS_ID);
    final WorkLog workLog = createWorkLog(beneficiary, CREATE, requestMetadata);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(beneficiaryRequestFactory.build(workLog, now)).thenReturn(beneficiaryRequest);
    when(beneficiaryRequest.resolve()).thenReturn(resolvedBeneficiaryRequest);
    doThrow(new BeneficiaryValidationException("", DUPLICATE))
        .when(resolvedBeneficiaryRequest)
        .execute();

    testSubject.process();

    verify(resolvedBeneficiaryRequest).auditFailure(DUPLICATE);
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @Test
  void processWorkLogShouldHandleUnexpectedExceptions() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final Beneficiary beneficiary = new TestBeneficiary(BENEFICIARY_IDENTIFIER, BENEFICIARY_SYS_ID);
    final WorkLog workLog = createWorkLog(beneficiary, CREATE, requestMetadata);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(beneficiaryRequestFactory.build(workLog, now)).thenReturn(beneficiaryRequest);
    when(beneficiaryRequest.resolve()).thenReturn(resolvedBeneficiaryRequest);
    doThrow(RuntimeException.class).when(resolvedBeneficiaryRequest).execute();

    testSubject.process();

    verify(resolvedBeneficiaryRequest).auditFailure(TECHNICAL);
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  private static WorkLog createWorkLog(
      final Beneficiary beneficiary,
      final WorkLog.Operation operation,
      final RequestMetadata metadata) {
    return WorkLog.builder()
        .status(WorkLog.Status.PENDING)
        .accountNumber(ACCOUNT_NUMBER)
        .operation(operation)
        .message(
            uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest.builder()
                .payload(Payload.builder().beneficiary(beneficiary).build())
                .metadata(metadata)
                .build())
        .build();
  }
}
