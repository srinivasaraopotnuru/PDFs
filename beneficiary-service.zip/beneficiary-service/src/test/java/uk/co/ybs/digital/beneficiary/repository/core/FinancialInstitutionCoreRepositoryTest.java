package uk.co.ybs.digital.beneficiary.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("beneficiaryProcessorTransactionManager")
public class FinancialInstitutionCoreRepositoryTest {

  private static final long SYS_ID = 1L;
  private static final boolean SUB_BRANCH = false;
  private static final long SORT_CODE = 112233L;
  private static final String BANK_NAME = "Bank 1";

  private static final long OTHER_SYS_ID = 2L;
  private static final long OTHER_SORT_CODE = 112244L;
  private static final String OTHER_BANK_NAME = "Bank 2";

  @Autowired FinancialInstitutionCoreRepository testSubject;

  @Autowired TestEntityManager coreTestEntityManager;

  @Test
  void shouldFindById() {
    final FinancialInstitution financialInstitution =
        createFinancialInstitution(SYS_ID, SUB_BRANCH, SORT_CODE, BANK_NAME);

    Long sysId = coreTestEntityManager.persistAndFlush(financialInstitution).getSysId();
    coreTestEntityManager.clear();

    final Optional<FinancialInstitution> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(financialInstitution));
  }

  @Test
  void shouldFindFinancialInstitutions() {
    final FinancialInstitution financialInstitution =
        createFinancialInstitution(SYS_ID, SUB_BRANCH, SORT_CODE, BANK_NAME);
    persistFinancialInstitution(financialInstitution);

    final List<FinancialInstitution> found =
        testSubject.findFinancialInstitution(SORT_CODE, SUB_BRANCH);

    assertThat(found.size(), is(1));
    assertThat(found, contains(samePropertyValuesAs(financialInstitution)));
  }

  @Test
  void shouldFindFinancialInstitutionsOrderedBySysId() {
    final FinancialInstitution financialInstitution =
        createFinancialInstitution(SYS_ID, SUB_BRANCH, SORT_CODE, BANK_NAME);
    persistFinancialInstitution(financialInstitution);

    final FinancialInstitution otherFinancialInstitution =
        createFinancialInstitution(OTHER_SYS_ID, SUB_BRANCH, OTHER_SORT_CODE, OTHER_BANK_NAME);
    persistFinancialInstitution(otherFinancialInstitution);

    final FinancialInstitution anotherFinancialInstitution =
        createFinancialInstitution(3L, SUB_BRANCH, SORT_CODE, "Bank 3");
    persistFinancialInstitution(anotherFinancialInstitution);

    final List<FinancialInstitution> found =
        testSubject.findFinancialInstitution(SORT_CODE, SUB_BRANCH);

    assertThat(found.size(), is(2));
    assertThat(
        found,
        contains(
            samePropertyValuesAs(financialInstitution),
            samePropertyValuesAs(anotherFinancialInstitution)));
  }

  @Test
  void shouldFindFinancialInstitutionsWithMatchingSortCode() {
    final FinancialInstitution financialInstitution =
        createFinancialInstitution(SYS_ID, SUB_BRANCH, SORT_CODE, BANK_NAME);
    persistFinancialInstitution(financialInstitution);

    final FinancialInstitution otherFinancialInstitution =
        createFinancialInstitution(OTHER_SYS_ID, SUB_BRANCH, OTHER_SORT_CODE, OTHER_BANK_NAME);
    persistFinancialInstitution(otherFinancialInstitution);

    final List<FinancialInstitution> found =
        testSubject.findFinancialInstitution(SORT_CODE, SUB_BRANCH);

    assertThat(found.size(), is(1));
    assertThat(found, contains(samePropertyValuesAs(financialInstitution)));
  }

  @Test
  void shouldFindFinancialInstitutionsThatAreNotSubBranches() {
    final FinancialInstitution financialInstitution =
        createFinancialInstitution(SYS_ID, SUB_BRANCH, SORT_CODE, BANK_NAME);
    persistFinancialInstitution(financialInstitution);

    final FinancialInstitution otherFinancialInstitution =
        createFinancialInstitution(OTHER_SYS_ID, true, SORT_CODE, OTHER_BANK_NAME);
    persistFinancialInstitution(otherFinancialInstitution);

    final List<FinancialInstitution> found =
        testSubject.findFinancialInstitution(SORT_CODE, SUB_BRANCH);

    assertThat(found.size(), is(1));
    assertThat(found, contains(samePropertyValuesAs(financialInstitution)));
  }

  @Test
  void shouldFindFinancialInstitutionsThatAreNotClosed() {
    final FinancialInstitution financialInstitution =
        createFinancialInstitution(SYS_ID, SUB_BRANCH, SORT_CODE, BANK_NAME);
    persistFinancialInstitution(financialInstitution);

    final LocalDateTime closed = LocalDateTime.now();
    final FinancialInstitution otherFinancialInstitution =
        createFinancialInstitution(OTHER_SYS_ID, SUB_BRANCH, SORT_CODE, OTHER_BANK_NAME)
            .toBuilder()
            .closedDate(closed)
            .build();
    persistFinancialInstitution(otherFinancialInstitution);

    final List<FinancialInstitution> found =
        testSubject.findFinancialInstitution(SORT_CODE, SUB_BRANCH);

    assertThat(found.size(), is(1));
    assertThat(found, contains(samePropertyValuesAs(financialInstitution)));
  }

  @Test
  void shouldReturnEmptyListWhenNoMatchingFinancialInstitutions() {
    final FinancialInstitution otherFinancialInstitution =
        createFinancialInstitution(OTHER_SYS_ID, SUB_BRANCH, OTHER_SORT_CODE, OTHER_BANK_NAME);
    persistFinancialInstitution(otherFinancialInstitution);

    final List<FinancialInstitution> found =
        testSubject.findFinancialInstitution(SORT_CODE, SUB_BRANCH);

    assertThat(found.size(), is(0));
  }

  private void persistFinancialInstitution(final FinancialInstitution financialInstitution) {
    coreTestEntityManager.persistAndFlush(financialInstitution);
    coreTestEntityManager.clear();
  }

  private static FinancialInstitution createFinancialInstitution(
      final long sysId, final boolean isSubBranch, final long sortCode, final String bankName) {
    return FinancialInstitution.builder()
        .sysId(sysId)
        .subBranch(isSubBranch)
        .sortCode(sortCode)
        .bankName(bankName)
        .build();
  }
}
