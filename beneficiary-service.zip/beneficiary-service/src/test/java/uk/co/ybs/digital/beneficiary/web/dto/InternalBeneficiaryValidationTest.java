package uk.co.ybs.digital.beneficiary.web.dto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.beneficiary.utils.TestHelper.validateRequest;
import static uk.co.ybs.digital.beneficiary.web.dto.FieldErrorMatcher.fieldError;

import java.util.Arrays;
import java.util.Collections;
import javax.validation.groups.Default;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.validation.BindingResult;
import org.springframework.validation.SmartValidator;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ValidationAutoConfiguration.class)
class InternalBeneficiaryValidationTest {

  @Autowired
  @Qualifier("defaultValidator")
  private SmartValidator validator;

  @Test
  void shouldValidateValidRequestAllFields() {
    final InternalBeneficiary beneficiary = buildAllFields();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @Test
  void shouldValidateValidRequestAllFieldsExistingBeneficiary() {
    final InternalBeneficiary beneficiary = buildAllFields();

    final BindingResult bindingResult =
        validateRequest(
            beneficiary, validator, Default.class, ExistingBeneficiaryValidationGroup.class);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @Test
  void shouldValidateValidRequestOptionalFields() {
    final InternalBeneficiary beneficiary =
        buildAllFields().toBuilder().beneficiaryId(null).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @Test
  void shouldDetectMissingFields() {
    final InternalBeneficiary beneficiary = InternalBeneficiary.builder().build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError("accountNumber", "You must specify an account number"))));
  }

  @Test
  void shouldDetectMissingFieldsExistingBeneficiary() {
    final InternalBeneficiary beneficiary = InternalBeneficiary.builder().build();

    final BindingResult bindingResult =
        validateRequest(
            beneficiary, validator, Default.class, ExistingBeneficiaryValidationGroup.class);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("beneficiaryId", "You must specify a beneficiary identifier"),
                fieldError("accountNumber", "You must specify an account number"))));
  }

  @ParameterizedTest
  @ValueSource(strings = {"000000000", "00000000000", "000000000X"})
  void shouldDetectInvalidAccountNumber(final String accountNumber) {
    final InternalBeneficiary beneficiary =
        buildAllFields().toBuilder().accountNumber(accountNumber).build();

    final BindingResult bindingResult = validateRequest(beneficiary, validator);
    assertThat(bindingResult.hasErrors(), is(true));
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singletonList(
                fieldError("accountNumber", "Account number must be 10 digits"))));
  }

  private InternalBeneficiary buildAllFields() {
    return InternalBeneficiary.builder()
        .beneficiaryId("abc123")
        .accountNumber("1234567890")
        .build();
  }
}
