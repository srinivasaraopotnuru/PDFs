package uk.co.ybs.digital.beneficiary.service.product.dto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class ProductInfoTest {

  @ParameterizedTest
  @MethodSource("getAnniversaryWithdrawalLimits")
  void getAnniversaryWithdrawalLimitShouldReturnOptionalContainingAnniversaryWithdrawalLimit(
      final ProductInfo productInfo, final Optional<Integer> expected) {
    assertThat(productInfo.getAnniversaryWithdrawalLimit(), is(expected));
  }

  private static Stream<Arguments> getAnniversaryWithdrawalLimits() {
    return Stream.of(
        Arguments.of(ProductInfo.builder().build(), Optional.empty()),
        Arguments.of(
            ProductInfo.builder().withdrawals(ProductInfo.Withdrawals.builder().build()).build(),
            Optional.empty()),
        Arguments.of(
            ProductInfo.builder()
                .withdrawals(
                    ProductInfo.Withdrawals.builder()
                        .limits(ProductInfo.Withdrawals.Limits.builder().build())
                        .build())
                .build(),
            Optional.empty()),
        Arguments.of(
            ProductInfo.builder()
                .withdrawals(
                    ProductInfo.Withdrawals.builder()
                        .limits(
                            ProductInfo.Withdrawals.Limits.builder()
                                .number(
                                    ProductInfo.NumberPeriodLimits.builder()
                                        .month(1)
                                        .year(2)
                                        .taxYear(3)
                                        .productTerm(4)
                                        .build())
                                .build())
                        .build())
                .build(),
            Optional.empty()),
        Arguments.of(
            ProductInfo.builder()
                .withdrawals(
                    ProductInfo.Withdrawals.builder()
                        .limits(
                            ProductInfo.Withdrawals.Limits.builder()
                                .number(
                                    ProductInfo.NumberPeriodLimits.builder()
                                        .anniversaryYear(1)
                                        .build())
                                .build())
                        .build())
                .build(),
            Optional.of(1)));
  }

  @ParameterizedTest
  @MethodSource("hasAnniversaryWithdrawalLimits")
  void hasAnniversaryWithdrawalLimitShouldReturnFalseUnlessAnniversaryWithdrawalLimitExists(
      final ProductInfo productInfo, final boolean expectedHasAnniversaryWithdrawalLimit) {
    assertThat(
        productInfo.hasAnniversaryWithdrawalLimit(), is(expectedHasAnniversaryWithdrawalLimit));
  }

  private static Stream<Arguments> hasAnniversaryWithdrawalLimits() {
    return Stream.of(
        Arguments.of(ProductInfo.builder().build(), false),
        Arguments.of(
            ProductInfo.builder().withdrawals(ProductInfo.Withdrawals.builder().build()).build(),
            false),
        Arguments.of(
            ProductInfo.builder()
                .withdrawals(
                    ProductInfo.Withdrawals.builder()
                        .limits(ProductInfo.Withdrawals.Limits.builder().build())
                        .build())
                .build(),
            false),
        Arguments.of(
            ProductInfo.builder()
                .withdrawals(
                    ProductInfo.Withdrawals.builder()
                        .limits(
                            ProductInfo.Withdrawals.Limits.builder()
                                .number(
                                    ProductInfo.NumberPeriodLimits.builder()
                                        .month(1)
                                        .year(2)
                                        .taxYear(3)
                                        .productTerm(4)
                                        .build())
                                .build())
                        .build())
                .build(),
            false),
        Arguments.of(
            ProductInfo.builder()
                .withdrawals(
                    ProductInfo.Withdrawals.builder()
                        .limits(
                            ProductInfo.Withdrawals.Limits.builder()
                                .number(
                                    ProductInfo.NumberPeriodLimits.builder()
                                        .anniversaryYear(1)
                                        .build())
                                .build())
                        .build())
                .build(),
            true));
  }
}
