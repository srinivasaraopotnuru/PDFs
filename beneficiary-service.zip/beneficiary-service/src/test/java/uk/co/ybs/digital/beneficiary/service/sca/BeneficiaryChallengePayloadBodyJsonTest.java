package uk.co.ybs.digital.beneficiary.service.sca;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

@JsonTest
class BeneficiaryChallengePayloadBodyJsonTest {

  @Autowired private JacksonTester<BeneficiaryChallengePayloadBody> tester;

  @Value("classpath:sca/externalBeneficiaryChallengePayloadBody.json")
  private Resource external;

  @Value("classpath:sca/internalBeneficiaryChallengePayloadBody.json")
  private Resource internal;

  @Test
  void shouldSerializeExternal() throws IOException {
    assertThat(tester.write(buildExternal())).isEqualToJson(external, JSONCompareMode.STRICT);
  }

  @Test
  void shouldDeserializeExternal() throws IOException {
    assertThat(tester.read(external)).isEqualTo(buildExternal());
  }

  @Test
  void shouldSerializeInternal() throws IOException {
    assertThat(tester.write(buildInternal())).isEqualToJson(internal, JSONCompareMode.STRICT);
  }

  @Test
  void shouldDeserializeInternal() throws IOException {
    assertThat(tester.read(internal)).isEqualTo(buildInternal());
  }

  private BeneficiaryChallengePayloadBody buildExternal() {
    return new BeneficiaryChallengePayloadBody(
        WorkLog.Operation.UPDATE,
        ExternalBeneficiary.builder()
            .name("MR B TEST")
            .accountNumber("12345679")
            .accountSortCode("112244")
            .reference("B REF")
            .memorableName("Joint Account")
            .build());
  }

  private BeneficiaryChallengePayloadBody buildInternal() {
    return new BeneficiaryChallengePayloadBody(
        WorkLog.Operation.UPDATE, InternalBeneficiary.builder().accountNumber("12345678").build());
  }
}
