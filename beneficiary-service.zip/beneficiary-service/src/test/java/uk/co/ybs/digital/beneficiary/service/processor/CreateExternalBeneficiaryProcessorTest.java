package uk.co.ybs.digital.beneficiary.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;
import static uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationExceptionReason.DUPLICATE;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.repository.core.BillPaymentInstructionCoreRepository;
import uk.co.ybs.digital.beneficiary.repository.core.FinancialInstitutionCoreRepository;
import uk.co.ybs.digital.beneficiary.repository.core.NonYbsBankAccountCoreRepository;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryAuditor;
import uk.co.ybs.digital.beneficiary.service.BeneficiaryInformationFactory;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.utilities.BeneficiaryUtils;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class CreateExternalBeneficiaryProcessorTest {

  private static final long ACCOUNT_NUMBER = 1L;
  private static final String ACCOUNT_NUMBER_STRING = String.valueOf(ACCOUNT_NUMBER);
  private static final String PAYEE_ACCOUNT_NUMBER = "12345678";
  private static final String SORT_CODE = "112233";
  private static final String REFERENCE = "reference";
  private static final String EXPECTED_REFERENCE = REFERENCE;
  private static final String NAME = "name";
  private static final String EXPECTED_NAME = "NAME";
  private static final String MEMORABLE_NAME = "memorable-name";
  private static final String EXPECTED_MEMORABLE_NAME = MEMORABLE_NAME;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final int BENEFICIARIES_LIMIT = 10;

  private static final String CREATED_AT = "0795";
  private static final String CREATED_BY = "SAPP";
  private static final LocalDateTime TIMESTAMP = LocalDateTime.parse("1900-01-01T00:00:00");

  @Mock private BeneficiaryAuditor beneficiaryAuditor;
  @Mock private BeneficiaryInformationFactory beneficiaryInformationFactory;
  @Mock private FinancialInstitutionCoreRepository financialInstitutionCoreRepository;
  @Mock private NonYbsBankAccountCoreRepository nonYbsBankAccountCoreRepository;
  @Mock private BillPaymentInstructionCoreRepository billPaymentInstructionCoreRepository;
  @Mock private BeneficiaryUtils beneficiaryUtils;
  @InjectMocks private CreateExternalBeneficiaryProcessor testSubject;

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfLimitIsExceeded() {
    executeShouldThrowBeneficiaryValidationExceptionIfLimitIsExceeded(
        BENEFICIARIES_LIMIT, BENEFICIARIES_LIMIT);
  }

  private void executeShouldThrowBeneficiaryValidationExceptionIfLimitIsExceeded(
      final Integer savedLimit, final int expectedLimit) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();

    when(billPaymentInstructionCoreRepository.findActiveExternalBeneficiaries(
            ACCOUNT_NUMBER, PROCESS_TIME))
        .thenReturn(expectedLimit);

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.execute(
                    new BeneficiaryRequestArguments<>(
                        ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, savedLimit)));

    assertThat(
        exception.getMessage(),
        is("External beneficiary limit exceeded for account: " + ACCOUNT_NUMBER_STRING));
    verifyNoInteractions(financialInstitutionCoreRepository);
    verifyNoInteractions(nonYbsBankAccountCoreRepository);
    verify(billPaymentInstructionCoreRepository, never()).saveAndFlush(any());
    verify(billPaymentInstructionCoreRepository, never())
        .updateExternalBeneficiaryAuthenticRecord(anyLong());
  }

  @Test
  void executeShouldThrowBeneficiaryValidationExceptionIfBeneficiaryAlreadyExists() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();
    final BillPaymentInstruction bpi =
        BillPaymentInstruction.builder()
            .sysId(null)
            .accountNumber(ACCOUNT_NUMBER)
            .reference(REFERENCE)
            .build();

    when(billPaymentInstructionCoreRepository.findExistingExternalBeneficiaries(
            ACCOUNT_NUMBER,
            Long.parseLong(SORT_CODE),
            Long.parseLong(PAYEE_ACCOUNT_NUMBER),
            null,
            PROCESS_TIME))
        .thenReturn(Collections.singletonList(bpi));

    when(beneficiaryUtils.compareReferences(bpi.getReference(), beneficiary.getReference()))
        .thenReturn(true);
    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.execute(
                    new BeneficiaryRequestArguments<>(
                        ACCOUNT_NUMBER,
                        requestMetadata,
                        PROCESS_TIME,
                        beneficiary,
                        BENEFICIARIES_LIMIT)));

    assertThat(
        exception.getMessage(),
        is("Requested beneficiary already exists for account: " + ACCOUNT_NUMBER_STRING));
    verifyNoInteractions(financialInstitutionCoreRepository);
    verifyNoInteractions(nonYbsBankAccountCoreRepository);
    verify(billPaymentInstructionCoreRepository, never()).saveAndFlush(any());
    verify(billPaymentInstructionCoreRepository, never())
        .updateExternalBeneficiaryAuthenticRecord(anyLong());
  }

  @Test
  void executeShouldThrowExceptionIfFinancialInstitutionNotFound() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();

    final List<FinancialInstitution> institutions = Collections.emptyList();
    when(financialInstitutionCoreRepository.findFinancialInstitution(112233L, false))
        .thenReturn(institutions);

    final Exception exception =
        assertThrows(
            Exception.class,
            () ->
                testSubject.execute(
                    new BeneficiaryRequestArguments<>(
                        ACCOUNT_NUMBER,
                        requestMetadata,
                        PROCESS_TIME,
                        beneficiary,
                        BENEFICIARIES_LIMIT)));

    assertThat(exception.getMessage(), is("Financial Institution for sortcode 112233 not found"));
    verifyNoInteractions(nonYbsBankAccountCoreRepository);
    verify(billPaymentInstructionCoreRepository, never()).saveAndFlush(any());
    verify(billPaymentInstructionCoreRepository, never())
        .updateExternalBeneficiaryAuthenticRecord(anyLong());
  }

  @ParameterizedTest
  @ValueSource(ints = {0, 1, BENEFICIARIES_LIMIT - 1})
  void executeShouldCreateBeneficiary(final int numberOfExistingBeneficiaries) {
    executeShouldCreateBeneficiary(
        BENEFICIARIES_LIMIT,
        numberOfExistingBeneficiaries,
        REFERENCE,
        EXPECTED_REFERENCE,
        NAME,
        EXPECTED_NAME,
        MEMORABLE_NAME,
        EXPECTED_MEMORABLE_NAME);
  }

  @ParameterizedTest
  @CsvSource({
    "Leading white space,              ' \t\nvalue'",
    "Trailing white space,             'value \t\n'",
    "Leading and trailing white space, ' \t\nvalue \t\n'"
  })
  void executeShouldCreateBeneficiaryTrimmingWhitespaceFromReferenceAndNameAndMemorableName(
      @SuppressWarnings("unused") final String label, final String value) {
    executeShouldCreateBeneficiary(
        BENEFICIARIES_LIMIT, 0, value, "value", value, "VALUE", value, "value");
  }

  @Test
  void executeShouldCreateBeneficiaryHandlingNullReferenceAndMemorableName() {
    executeShouldCreateBeneficiary(
        BENEFICIARIES_LIMIT, 0, null, null, NAME, EXPECTED_NAME, null, null);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private void executeShouldCreateBeneficiary(
      final Integer savedLimit,
      final int numberOfExistingBeneficiaries,
      final String reference,
      final String expectedReference,
      final String name,
      final String expectedName,
      final String memorableName,
      final String expectedMemorableName) {
    final long sortCode = 112233L;
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary =
        createExternalBeneficiary()
            .toBuilder()
            .reference(reference)
            .name(name)
            .memorableName(memorableName)
            .build();

    when(billPaymentInstructionCoreRepository.findActiveExternalBeneficiaries(
            ACCOUNT_NUMBER, PROCESS_TIME))
        .thenReturn(numberOfExistingBeneficiaries);

    final FinancialInstitution institution =
        FinancialInstitution.builder().bankName("Bank").sortCode(sortCode).subBranch(false).build();
    final List<FinancialInstitution> institutions = Collections.singletonList(institution);
    when(financialInstitutionCoreRepository.findFinancialInstitution(sortCode, false))
        .thenReturn(institutions);

    final NonYbsBankAccount expectedNonYbsBankAccount =
        NonYbsBankAccount.builder()
            .accountNumber(Long.parseLong(beneficiary.getAccountNumber()))
            .bankName(institution.getBankName())
            .createdAt(CREATED_AT)
            .createdBy(CREATED_BY)
            .createdDate(TIMESTAMP)
            .financialInstitution(institution)
            .name(expectedName)
            .sortCode(sortCode)
            .startDate(TIMESTAMP)
            .build();
    when(nonYbsBankAccountCoreRepository.saveAndFlush(any())).thenReturn(expectedNonYbsBankAccount);

    final BillPaymentInstruction expectedInstruction =
        BillPaymentInstruction.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .availableAtm(true)
            .createdAt(CREATED_AT)
            .createdBy(CREATED_BY)
            .createdDate(PROCESS_TIME)
            .fpChangeReason("OOBAD")
            .fpTrustStatus(true)
            .memorableName(expectedMemorableName)
            .nonYbsBankAccount(expectedNonYbsBankAccount)
            .reference(expectedReference)
            .startDate(PROCESS_TIME)
            .status("ACTIVE")
            .build();

    testSubject.execute(
        new BeneficiaryRequestArguments<>(
            ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, savedLimit));

    verify(nonYbsBankAccountCoreRepository)
        .saveAndFlush(argThat(samePropertyValuesAs(expectedNonYbsBankAccount)));
    verify(billPaymentInstructionCoreRepository)
        .saveAndFlush(argThat(samePropertyValuesAs(expectedInstruction)));
    verify(billPaymentInstructionCoreRepository)
        .updateExternalBeneficiaryAuthenticRecord(ACCOUNT_NUMBER);
  }

  @Test
  void auditSuccessShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();

    final ExternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createExternalBeneficiaryInformation(
            ACCOUNT_NUMBER_STRING, PAYEE_ACCOUNT_NUMBER);
    when(beneficiaryInformationFactory.buildExternal(ACCOUNT_NUMBER, beneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditSuccess(
        new BeneficiaryRequestArguments<>(
            ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, BENEFICIARIES_LIMIT));

    verify(beneficiaryAuditor).auditBeneficiaryCreateSuccess(expectedAuditBody, requestMetadata);
  }

  @Test
  void auditFailureShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final ExternalBeneficiary beneficiary = createExternalBeneficiary();

    final ExternalBeneficiaryInformation expectedAuditBody =
        TestHelper.createExternalBeneficiaryInformation(
            ACCOUNT_NUMBER_STRING, PAYEE_ACCOUNT_NUMBER);
    when(beneficiaryInformationFactory.buildExternal(ACCOUNT_NUMBER, beneficiary))
        .thenReturn(expectedAuditBody);

    testSubject.auditFailure(
        new BeneficiaryRequestArguments<>(
            ACCOUNT_NUMBER, requestMetadata, PROCESS_TIME, beneficiary, BENEFICIARIES_LIMIT),
        DUPLICATE);

    verify(beneficiaryAuditor)
        .auditBeneficiaryCreateFailure(expectedAuditBody, "Duplicate Beneficiary", requestMetadata);
  }

  private ExternalBeneficiary createExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .beneficiaryId("abc123")
        .accountSortCode(SORT_CODE)
        .accountNumber(PAYEE_ACCOUNT_NUMBER)
        .reference(REFERENCE)
        .name(NAME)
        .memorableName(MEMORABLE_NAME)
        .build();
  }
}
