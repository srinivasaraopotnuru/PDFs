package uk.co.ybs.digital.beneficiary.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.beneficiary.model.core.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.core.FinancialInstitution;
import uk.co.ybs.digital.beneficiary.model.core.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("beneficiaryProcessorTransactionManager")
public class BillPaymentInstructionCoreRepositoryTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-07-13T14:56:30");
  private static final String CREATED_AT = "0795";
  private static final String CREATED_BY = "SAPP";
  private static final String REFERENCE = "REF";
  private static final long ACCOUNT_NUMBER = 1001L;
  private static final long SORT_CODE = 112233L;
  private static final String NAME = "MR TEST";
  private static final long DEBTOR_ACCOUNT_NUMBER = 2001L;

  @Autowired private BillPaymentInstructionCoreRepository testSubject;

  @Autowired private TestEntityManager coreTestEntityManager;

  private FinancialInstitution institution;

  @BeforeEach
  void setup() {
    institution = createFinancialInstitution();
    coreTestEntityManager.persistAndFlush(institution);
    coreTestEntityManager.clear();
  }

  @Test
  void shouldFindById() {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstructionAllFields(nonYbsBankAccount);
    Long sysId = coreTestEntityManager.persistAndFlush(billPaymentInstruction).getSysId();
    coreTestEntityManager.clear();

    final Optional<BillPaymentInstruction> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(billPaymentInstruction));
    assertThat(found.get(), samePropertyValuesAs(billPaymentInstruction));
  }

  @ParameterizedTest
  @CsvSource({"2002,0", "2001,1"})
  void findExistingExternalBeneficiariesShouldFindBeneficiariesWithMatchingDebtorAccount(
      final Long accountNumberLong, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount);
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject
            .findExistingExternalBeneficiaries(
                accountNumberLong, SORT_CODE, ACCOUNT_NUMBER, null, NOW)
            .size();
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"ONEOFF,0", "CANC,0", "ACTIVE,1"})
  void findExistingExternalBeneficiariesShouldOnlyFindActiveRecords(
      final String status, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount).toBuilder().status(status).build();
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject
            .findExistingExternalBeneficiaries(
                DEBTOR_ACCOUNT_NUMBER, SORT_CODE, ACCOUNT_NUMBER, null, NOW)
            .size();
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"false,0", "true,1"})
  void findExistingExternalBeneficiariesShouldOnlyFindAvailableAtmRecords(
      final boolean availableAtm, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount)
            .toBuilder()
            .availableAtm(availableAtm)
            .build();
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject
            .findExistingExternalBeneficiaries(
                DEBTOR_ACCOUNT_NUMBER, SORT_CODE, ACCOUNT_NUMBER, null, NOW)
            .size();
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"2020-07-13T14:56:29,0", "2020-07-13T14:56:30,0", "2020-07-13T14:56:31,1", ",1"})
  void findExistingExternalBeneficiariesShouldOnlyFindRecordsWhereInstructionIsNotEnded(
      final LocalDateTime instructionEndDate, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount)
            .toBuilder()
            .endDate(instructionEndDate)
            .build();
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject
            .findExistingExternalBeneficiaries(
                DEBTOR_ACCOUNT_NUMBER, SORT_CODE, ACCOUNT_NUMBER, null, NOW)
            .size();
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"1002,0", "1001,1"})
  void findExistingExternalBeneficiariesShouldOnlyFindRecordsWithMatchingAccountNumber(
      final long accountNumber, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount =
        createNonYbsBankAccount(institution).toBuilder().accountNumber(accountNumber).build();
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount);
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject
            .findExistingExternalBeneficiaries(
                DEBTOR_ACCOUNT_NUMBER, SORT_CODE, ACCOUNT_NUMBER, null, NOW)
            .size();
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"112244,0", "112233,1"})
  void findExistingExternalBeneficiariesShouldOnlyFindRecordsWithMatchingSortCode(
      final long sortCode, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount =
        createNonYbsBankAccount(institution).toBuilder().sortCode(sortCode).build();
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount);
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject
            .findExistingExternalBeneficiaries(
                DEBTOR_ACCOUNT_NUMBER, SORT_CODE, ACCOUNT_NUMBER, null, NOW)
            .size();
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"2020-07-13T14:56:29,0", "2020-07-13T14:56:30,0", "2020-07-13T14:56:31,1", ",1"})
  void findExistingExternalBeneficiariesShouldOnlyFindRecordsWhereNonYbsAccountIsNotEnded(
      final LocalDateTime instructionEndDate, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount =
        createNonYbsBankAccount(institution).toBuilder().endDate(instructionEndDate).build();
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount);
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count =
        testSubject
            .findExistingExternalBeneficiaries(
                DEBTOR_ACCOUNT_NUMBER, SORT_CODE, ACCOUNT_NUMBER, null, NOW)
            .size();
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"2002,0", "2001,1"})
  void findActiveExternalBeneficiariesShouldFindBeneficiariesWithMatchingDebtorAccount(
      final Long accountNumberLong, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount);
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count = testSubject.findActiveExternalBeneficiaries(accountNumberLong, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"ONEOFF,0", "CANC,0", "ACTIVE,1"})
  void findActiveExternalBeneficiariesShouldOnlyFindActiveRecords(
      final String status, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount).toBuilder().status(status).build();
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count = testSubject.findActiveExternalBeneficiaries(DEBTOR_ACCOUNT_NUMBER, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"2020-07-13T14:56:29,0", "2020-07-13T14:56:30,0", "2020-07-13T14:56:31,1", ",1"})
  void findActiveExternalBeneficiariesShouldOnlyFindRecordsWhereInstructionIsNotEnded(
      final LocalDateTime instructionEndDate, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount)
            .toBuilder()
            .endDate(instructionEndDate)
            .build();
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final int count = testSubject.findActiveExternalBeneficiaries(DEBTOR_ACCOUNT_NUMBER, NOW);
    assertThat(count, is(expectedCount));
  }

  @ParameterizedTest
  @CsvSource({"true,0", "false,1"})
  void findExistingExternalBeneficiariesShouldIgnoreUpdatingSysId(
      final boolean updatingSameSysId, final int expectedCount) {
    final NonYbsBankAccount nonYbsBankAccount = createNonYbsBankAccount(institution);
    coreTestEntityManager.persistAndFlush(nonYbsBankAccount);
    coreTestEntityManager.clear();

    final BillPaymentInstruction billPaymentInstruction =
        createBillPaymentInstruction(nonYbsBankAccount);
    coreTestEntityManager.persistAndFlush(billPaymentInstruction);
    coreTestEntityManager.clear();

    final Long instructionSysId = billPaymentInstruction.getSysId();
    long updatingSysId = updatingSameSysId ? instructionSysId : instructionSysId + 1;

    final int count =
        testSubject
            .findExistingExternalBeneficiaries(
                DEBTOR_ACCOUNT_NUMBER, SORT_CODE, ACCOUNT_NUMBER, updatingSysId, NOW)
            .size();
    assertThat(count, is(expectedCount));
  }

  private static FinancialInstitution createFinancialInstitution() {
    return FinancialInstitution.builder()
        .sysId(1L)
        .subBranch(false)
        .sortCode(112233L)
        .bankName("Bank 1")
        .build();
  }

  private static NonYbsBankAccount createNonYbsBankAccount(final FinancialInstitution institution) {
    return NonYbsBankAccount.builder()
        .financialInstitution(institution)
        .accountNumber(ACCOUNT_NUMBER)
        .name(NAME)
        .sortCode(SORT_CODE)
        .bankName("Bank 1")
        .startDate(NOW)
        .createdAt(CREATED_AT)
        .createdBy(CREATED_BY)
        .createdDate(NOW)
        .build();
  }

  private static BillPaymentInstruction createBillPaymentInstruction(
      final NonYbsBankAccount nonYbsBankAccount) {
    return BillPaymentInstruction.builder()
        .nonYbsBankAccount(nonYbsBankAccount)
        .accountNumber(DEBTOR_ACCOUNT_NUMBER)
        .status("ACTIVE")
        .availableAtm(true)
        .startDate(NOW)
        .reference(REFERENCE)
        .atmOrderNumber(1)
        .createdAt(CREATED_AT)
        .createdBy(CREATED_BY)
        .createdDate(NOW)
        .fpTrustStatus(true)
        .fpChangeReason("OOBAD")
        .memorableName("Mem")
        .build();
  }

  private static BillPaymentInstruction createBillPaymentInstructionAllFields(
      final NonYbsBankAccount nonYbsBankAccount) {
    return createBillPaymentInstruction(nonYbsBankAccount)
        .toBuilder()
        .endDate(NOW)
        .endedAt(CREATED_AT)
        .endedBy(CREATED_BY)
        .endedDate(NOW)
        .build();
  }
}
