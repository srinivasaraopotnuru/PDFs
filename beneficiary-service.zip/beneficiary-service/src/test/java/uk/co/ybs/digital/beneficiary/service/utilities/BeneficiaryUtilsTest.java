package uk.co.ybs.digital.beneficiary.service.utilities;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.beneficiary.model.adgcore.BillPaymentInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.ItInstruction;
import uk.co.ybs.digital.beneficiary.model.adgcore.NonYbsBankAccount;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.BeneficiaryRequest;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

class BeneficiaryUtilsTest {

  private static final long SYS_ID = 1L;
  private static final long SORT_CODE = 123456L;
  private static final long ACCOUNT_NUMBER = 12345678L;
  private static final String REFERENCE_18_CHARACTERS = "aBcDeFgHiJkLmNoPqR";
  private static final String REFERENCE_18_CHARACTERS_OPPOSITE_CASE = "AbCdEfGhIjKlMnOpQr";
  private static final String MEMORABLE_NAME = "MemorableName";
  public static final String INTERNAL = "INTERNAL";
  public static final String EXTERNAL = "EXTERNAL";

  private final BeneficiaryUtils testSubject = new BeneficiaryUtils();

  @ParameterizedTest
  @CsvSource({
    REFERENCE_18_CHARACTERS + "," + REFERENCE_18_CHARACTERS,
    REFERENCE_18_CHARACTERS + "," + REFERENCE_18_CHARACTERS_OPPOSITE_CASE
  })
  void compareReferencesShouldCaseInsensitiveCompareReferences(
      final String referenceA, final String referenceB) {
    final boolean matches = testSubject.compareReferences(referenceA, referenceB);

    assertThat(matches, is(true));
  }

  @ParameterizedTest
  @MethodSource("referenceIndexes")
  void compareReferencesShouldDetectMismatches(final int changeIndex) {
    final StringBuilder builder = new StringBuilder(REFERENCE_18_CHARACTERS);
    builder.setCharAt(changeIndex, 'x');
    final String modifiedReference = builder.toString();

    final boolean matches =
        testSubject.compareReferences(REFERENCE_18_CHARACTERS, modifiedReference);

    assertThat(matches, is(false));
  }

  private static IntStream referenceIndexes() {
    return IntStream.range(0, 18);
  }

  @ParameterizedTest
  @WhitespaceSource
  void compareReferencesShouldTrimWhitespace(
      @SuppressWarnings("unused") final String label,
      final String referenceA,
      final String referenceB) {
    final boolean matches = testSubject.compareReferences(referenceA, referenceB);

    assertThat(matches, is(true));
  }

  @ParameterizedTest
  @CsvSource({
    "' " + REFERENCE_18_CHARACTERS + "x'," + REFERENCE_18_CHARACTERS,
    REFERENCE_18_CHARACTERS + ",' " + REFERENCE_18_CHARACTERS + "x'"
  })
  void compareReferencesShouldTrimWhitespaceBeforeTruncating(
      final String referenceA, final String referenceB) {
    final boolean matches = testSubject.compareReferences(referenceA, referenceB);

    assertThat(matches, is(true));
  }

  @Test
  void compareReferencesShouldTruncateReferenceWhenOverLengthLimit() {
    final String referenceA = REFERENCE_18_CHARACTERS + "x";
    final String referenceB = REFERENCE_18_CHARACTERS + "y";

    final boolean matches = testSubject.compareReferences(referenceA, referenceB);

    assertThat(matches, is(true));
  }

  @ParameterizedTest
  @MethodSource("nullReferenceCombinations")
  void compareReferencesShouldHandleNullReferences(
      final String referenceA, final String referenceB, final boolean expectMatch) {
    final boolean matches = testSubject.compareReferences(referenceA, referenceB);

    assertThat(matches, is(expectMatch));
  }

  @ParameterizedTest
  @CsvSource(
      value = {
        "18 characters with last different,abcdefghijklmnopqr,abcdefghijklmnopqx,false",
        "18 characters matching,abcdefghijklmnopqr,abcdefghijklmnopqr,true",
        "19 and 18 characters,abcdefghijklmnopqrx,abcdefghijklmnopqr,true",
        "18 and 19 characters,abcdefghijklmnopqr,abcdefghijklmnopqry,true",
        "19 characters with last different,abcdefghijklmnopqrx,abcdefghijklmnopqry,true"
      })
  void compareReferencesShouldOnlyMatchRecordsWithMatchingReferenceWithLengthOver18(
      @SuppressWarnings("unused") final String label,
      final String instructionReference,
      final String queryReference,
      final boolean expectedResult) {

    boolean result = testSubject.compareReferences(instructionReference, queryReference);

    assertThat(result, is(expectedResult));
  }

  private static Stream<Arguments> nullReferenceCombinations() {
    return Stream.of(
        Arguments.of(null, null, true),
        Arguments.of(REFERENCE_18_CHARACTERS, null, false),
        Arguments.of(null, REFERENCE_18_CHARACTERS, false));
  }

  @ParameterizedTest
  @MethodSource("instructionTypes")
  void findMatchingWorkLogShouldReturnMatchingWorkLog(final String type) {
    final ItInstruction internalInstruction = ItInstruction.builder().sysId(SYS_ID).build();
    final BillPaymentInstruction externalInstruction =
        buildInstruction(
            SYS_ID, SORT_CODE, ACCOUNT_NUMBER, REFERENCE_18_CHARACTERS + "y", MEMORABLE_NAME);

    Beneficiary beneficiary;
    if (INTERNAL.equals(type)) {
      beneficiary = buildInternalBeneficiary();
    } else {
      beneficiary = buildExternalBeneficiary();
    }

    WorkLog expectedWorkLog = buildWorkLog(SYS_ID, beneficiary);
    final List<WorkLog> logs =
        Arrays.asList(expectedWorkLog, buildWorkLog(SYS_ID - 1, beneficiary));

    final Optional<WorkLog> log;
    if (INTERNAL.equals(type)) {
      log = testSubject.findMatchingWorkLog(internalInstruction, logs);
    } else {
      log = testSubject.findMatchingWorkLog(externalInstruction, logs);
    }

    assertThat(log, is(Optional.of(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("instructionTypes")
  void findMatchingWorkLogShouldReturnEmptyOptionalIfNoMatch(final String type) {
    final ItInstruction internalInstruction = ItInstruction.builder().sysId(SYS_ID + 1).build();
    final BillPaymentInstruction externalInstruction =
        buildInstruction(
            SYS_ID + 1, SORT_CODE, ACCOUNT_NUMBER, REFERENCE_18_CHARACTERS + "y", MEMORABLE_NAME);

    Beneficiary beneficiary;
    if (INTERNAL.equals(type)) {
      beneficiary = buildInternalBeneficiary();
    } else {
      beneficiary = buildExternalBeneficiary();
    }
    WorkLog expectedWorkLog = buildWorkLog(SYS_ID, beneficiary);
    final List<WorkLog> logs =
        Arrays.asList(expectedWorkLog, buildWorkLog(SYS_ID - 1, beneficiary));

    final Optional<WorkLog> log;
    if (INTERNAL.equals(type)) {
      log = testSubject.findMatchingWorkLog(internalInstruction, logs);
    } else {
      log = testSubject.findMatchingWorkLog(externalInstruction, logs);
    }

    assertThat(log, is(Optional.empty()));
  }

  private static Stream<Arguments> instructionTypes() {
    return Stream.of(Arguments.of(INTERNAL), Arguments.of(EXTERNAL));
  }

  private static ExternalBeneficiary buildExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .accountNumber(String.valueOf(ACCOUNT_NUMBER))
        .accountSortCode(String.valueOf(SORT_CODE))
        .memorableName(MEMORABLE_NAME)
        .name("NAME")
        .reference(REFERENCE_18_CHARACTERS)
        .build();
  }

  private static InternalBeneficiary buildInternalBeneficiary() {
    return InternalBeneficiary.builder().accountNumber(String.valueOf(ACCOUNT_NUMBER)).build();
  }

  private BillPaymentInstruction buildInstruction(
      final Long sysId,
      final Long sortCode,
      final Long accountNumber,
      final String reference,
      final String memorableName) {
    return BillPaymentInstruction.builder()
        .sysId(sysId)
        .nonYbsBankAccount(
            NonYbsBankAccount.builder().sortCode(sortCode).accountNumber(accountNumber).build())
        .reference(reference)
        .memorableName(memorableName)
        .build();
  }

  private WorkLog buildWorkLog(final Long sysId, final Beneficiary beneficiary) {
    return WorkLog.builder()
        .message(
            BeneficiaryRequest.builder()
                .payload(
                    BeneficiaryRequest.Payload.builder()
                        .sysId(sysId)
                        .beneficiary(beneficiary)
                        .build())
                .metadata(TestHelper.createRequestMetadata())
                .build())
        .build();
  }

  @CsvSource({
    "A leading white space,              ' \t\nreference',      'reference'",
    "A trailing white space,             'reference \t\n',      'reference'",
    "A leading and trailing white space, ' \t\nreference \t\n', 'reference'",
    "B leading white space,              'reference',           ' \t\nreference'",
    "B trailing white space,             'reference',           'reference \t\n'",
    "B leading and trailing white space, 'reference',           ' \t\nreference \t\n'"
  })
  @Target(ElementType.METHOD)
  @Retention(RetentionPolicy.RUNTIME)
  @interface WhitespaceSource {}
}
