package uk.co.ybs.digital.beneficiary.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.time.Duration;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.beneficiary.exception.ScaRequiredException;
import uk.co.ybs.digital.beneficiary.model.digitalbeneficiary.WorkLog;
import uk.co.ybs.digital.beneficiary.service.sca.BeneficiaryChallengePayloadBody;
import uk.co.ybs.digital.beneficiary.service.sca.BeneficiaryIdChallengePayloadBody;
import uk.co.ybs.digital.beneficiary.utils.TestHelper;
import uk.co.ybs.digital.beneficiary.web.dto.Beneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.RequestMetadata;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@ExtendWith(MockitoExtension.class)
class ScaManagerTest {

  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final Duration CHALLENGE_TIMEOUT = Duration.ofMinutes(1);
  public static final String MOCK_CHALLENGE = "mockChallenge";
  public static final String MOCK_RESPONSE = "mockResponse";
  public static final String MOCK_BASE_64_ENCODED_PUBLIC_KEY = "mockBase64EncodedPublicKey";

  @InjectMocks private ScaManager testSubject;

  @Mock private ScaChallengeService scaChallengeService;

  @Mock private BeneficiaryAuditor beneficiaryAuditor;

  @Test
  void validateScaShouldThrowScaRequiredExceptionIfScaCredentialsNotProvided() {
    final RequestMetadata metadata = buildRequestMetadata();
    final Beneficiary beneficiary = buildBeneficiary();
    final BeneficiaryChallengePayloadBody expectedChallengePayloadBody =
        new BeneficiaryChallengePayloadBody(WorkLog.Operation.UPDATE, beneficiary);
    final String challenge = "the-challenge";

    when(scaChallengeService.generateChallenge(
            expectedChallengePayloadBody, SESSION_ID, CHALLENGE_TIMEOUT))
        .thenReturn(challenge);

    final ScaRequiredException exception =
        assertThrows(
            ScaRequiredException.class,
            () -> testSubject.validateSca(WorkLog.Operation.UPDATE, beneficiary, metadata, null));

    assertThat(exception.getChallenge(), is(challenge));
    verifyNoMoreInteractions(scaChallengeService);
    verify(beneficiaryAuditor).auditBeneficiaryChallenge(metadata);
  }

  @Test
  void validateDeleteScaShouldThrowScaRequiredExceptionIfScaCredentialsNotProvided() {
    final RequestMetadata metadata = buildRequestMetadata();
    final Beneficiary beneficiary = buildBeneficiary();
    final BeneficiaryIdChallengePayloadBody expectedChallengePayloadBody =
        new BeneficiaryIdChallengePayloadBody(
            WorkLog.Operation.DELETE, beneficiary.getBeneficiaryId());
    final String challenge = "the-challenge";

    when(scaChallengeService.generateChallenge(
            expectedChallengePayloadBody, SESSION_ID, CHALLENGE_TIMEOUT))
        .thenReturn(challenge);

    final ScaRequiredException exception =
        assertThrows(
            ScaRequiredException.class,
            () ->
                testSubject.validateDeleteSca(
                    WorkLog.Operation.DELETE, beneficiary.getBeneficiaryId(), metadata, null));

    assertThat(exception.getChallenge(), is(challenge));
    verifyNoMoreInteractions(scaChallengeService);
  }

  @Test
  void validateScaShouldValidateProvidedScaCredentials() {
    final RequestMetadata metadata = buildRequestMetadata();
    final Beneficiary beneficiary = buildBeneficiary();
    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, MOCK_BASE_64_ENCODED_PUBLIC_KEY);
    final BeneficiaryChallengePayloadBody expectedChallengePayloadBody =
        new BeneficiaryChallengePayloadBody(WorkLog.Operation.UPDATE, beneficiary);

    testSubject.validateSca(WorkLog.Operation.UPDATE, beneficiary, metadata, scaCredentials);

    verify(scaChallengeService)
        .validateChallenge(
            scaCredentials,
            expectedChallengePayloadBody,
            BeneficiaryChallengePayloadBody.class,
            SESSION_ID);
    verify(beneficiaryAuditor).auditBeneficiaryChallengeSuccess(metadata);
  }

  @Test
  void validateDeleteScaShouldValidateProvidedScaCredentials() {
    final RequestMetadata metadata = buildRequestMetadata();
    final Beneficiary beneficiary = buildBeneficiary();
    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, MOCK_BASE_64_ENCODED_PUBLIC_KEY);
    final BeneficiaryIdChallengePayloadBody expectedChallengePayloadBody =
        new BeneficiaryIdChallengePayloadBody(
            WorkLog.Operation.DELETE, beneficiary.getBeneficiaryId());

    testSubject.validateDeleteSca(
        WorkLog.Operation.DELETE, beneficiary.getBeneficiaryId(), metadata, scaCredentials);

    verify(scaChallengeService)
        .validateChallenge(
            scaCredentials,
            expectedChallengePayloadBody,
            BeneficiaryIdChallengePayloadBody.class,
            SESSION_ID);
  }

  @Test
  void validateScaShouldHandleAndRethrowInvalidScaExceptions() {
    final RequestMetadata metadata = buildRequestMetadata();
    final Beneficiary beneficiary = buildBeneficiary();
    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, MOCK_BASE_64_ENCODED_PUBLIC_KEY);
    final BeneficiaryChallengePayloadBody expectedChallengePayloadBody =
        new BeneficiaryChallengePayloadBody(WorkLog.Operation.UPDATE, beneficiary);

    final InvalidScaException exception = new InvalidScaException("");
    doThrow(exception)
        .when(scaChallengeService)
        .validateChallenge(
            scaCredentials,
            expectedChallengePayloadBody,
            BeneficiaryChallengePayloadBody.class,
            SESSION_ID);

    final InvalidScaException thrownException =
        assertThrows(
            InvalidScaException.class,
            () ->
                testSubject.validateSca(
                    WorkLog.Operation.UPDATE, beneficiary, metadata, scaCredentials));

    assertThat(thrownException, is(exception));
    verify(beneficiaryAuditor)
        .auditBeneficiaryChallengeFailure(metadata, "Invalid Challenge Response");
  }

  @Test
  void validateDeleteScaShouldHandleAndRethrowInvalidScaExceptions() {
    final RequestMetadata metadata = buildRequestMetadata();
    final Beneficiary beneficiary = buildBeneficiary();
    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, MOCK_BASE_64_ENCODED_PUBLIC_KEY);
    final BeneficiaryIdChallengePayloadBody expectedChallengePayloadBody =
        new BeneficiaryIdChallengePayloadBody(
            WorkLog.Operation.DELETE, beneficiary.getBeneficiaryId());

    final InvalidScaException exception = new InvalidScaException("");
    doThrow(exception)
        .when(scaChallengeService)
        .validateChallenge(
            scaCredentials,
            expectedChallengePayloadBody,
            BeneficiaryIdChallengePayloadBody.class,
            SESSION_ID);

    final InvalidScaException thrownException =
        assertThrows(
            InvalidScaException.class,
            () ->
                testSubject.validateDeleteSca(
                    WorkLog.Operation.DELETE,
                    beneficiary.getBeneficiaryId(),
                    metadata,
                    scaCredentials));

    assertThat(thrownException, is(exception));
    verify(beneficiaryAuditor)
        .auditBeneficiaryChallengeFailure(metadata, "Invalid Challenge Response");
  }

  private RequestMetadata buildRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(SESSION_ID, 443);
  }

  private ExternalBeneficiary buildBeneficiary() {
    return TestHelper.createExternalBeneficiary("12345678", "d7298b74546d4d52a1607343cfc74359");
  }
}
