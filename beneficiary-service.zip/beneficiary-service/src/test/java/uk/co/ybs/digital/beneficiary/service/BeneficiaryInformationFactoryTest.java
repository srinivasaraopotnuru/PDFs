package uk.co.ybs.digital.beneficiary.service;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.ExternalUpdateBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.service.audit.dto.InternalBeneficiaryInformation;
import uk.co.ybs.digital.beneficiary.web.dto.ExternalBeneficiary;
import uk.co.ybs.digital.beneficiary.web.dto.InternalBeneficiary;

class BeneficiaryInformationFactoryTest {

  private static final long DEBTOR_ACCOUNT_NUMBER = 1234567890L;
  private static final long CREDITOR_INTERNAL_ACCOUNT_NUMBER = 1234567892L;
  private static final long CREDITOR_EXTERNAL_ACCOUNT_NUMBER = 12345679L;

  private static final String BENEFICIARY_ID = "123abc";
  private static final String SORT_CODE = "111166";
  private static final String PAYEE_NAME = "PAYEE_NAME";
  private static final String REFERENCE = "REFERENCE";
  private static final String MEMORABLE_NAME = "MEMORABLE_NAME";
  private static final String NEW_REFERENCE = "NEW REFERENCE";
  private static final String NEW_MEMORABLE_NAME = "NEW MEMORABLE_NAME";

  private final BeneficiaryInformationFactory testSubject = new BeneficiaryInformationFactory();

  @Test
  void buildExternalShouldReturnResult() {
    final ExternalBeneficiary externalBeneficiary = buildExternalBeneficiary();

    final ExternalBeneficiaryInformation expected =
        ExternalBeneficiaryInformation.builder()
            .accountNumber(String.valueOf(DEBTOR_ACCOUNT_NUMBER))
            .payeeAccountNumber(String.valueOf(CREDITOR_EXTERNAL_ACCOUNT_NUMBER))
            .payeeSortCode(SORT_CODE)
            .payeeName(PAYEE_NAME)
            .reference(REFERENCE)
            .memorableName(MEMORABLE_NAME)
            .build();

    final ExternalBeneficiaryInformation actual =
        testSubject.buildExternal(DEBTOR_ACCOUNT_NUMBER, externalBeneficiary);
    assertThat(actual, is(expected));
  }

  @Test
  void buildInternalShouldReturnResult() {
    final InternalBeneficiary internalBeneficiary = buildInternalBeneficiary();

    final InternalBeneficiaryInformation expected =
        InternalBeneficiaryInformation.builder()
            .accountNumber(String.valueOf(DEBTOR_ACCOUNT_NUMBER))
            .payeeAccountNumber(String.valueOf(CREDITOR_INTERNAL_ACCOUNT_NUMBER))
            .build();

    final InternalBeneficiaryInformation actual =
        testSubject.buildInternal(DEBTOR_ACCOUNT_NUMBER, internalBeneficiary);
    assertThat(actual, is(expected));
  }

  @Test
  void buildExternalUpdateShouldReturnResult() {
    final ExternalBeneficiary request = buildExternalBeneficiaryUpdate();
    final ExternalBeneficiary originalBeneficiary = buildExternalBeneficiary();

    final ExternalUpdateBeneficiaryInformationWrapper expected =
        new ExternalUpdateBeneficiaryInformationWrapper(
            ExternalBeneficiaryInformation.builder()
                .accountNumber(String.valueOf(DEBTOR_ACCOUNT_NUMBER))
                .payeeAccountNumber(String.valueOf(CREDITOR_EXTERNAL_ACCOUNT_NUMBER))
                .payeeSortCode(SORT_CODE)
                .payeeName(PAYEE_NAME)
                .reference(REFERENCE)
                .memorableName(MEMORABLE_NAME)
                .build(),
            ExternalUpdateBeneficiaryInformation.builder()
                .reference(NEW_REFERENCE)
                .memorableName(NEW_MEMORABLE_NAME)
                .build());

    final ExternalUpdateBeneficiaryInformationWrapper actual =
        testSubject.buildExternalUpdate(DEBTOR_ACCOUNT_NUMBER, request, originalBeneficiary);
    assertThat(actual, is(expected));
  }

  @Retention(RUNTIME)
  @Target(METHOD)
  @CsvSource({
    "1,0000000001", "11,0000000011", "111,0000000111", "1111,0000001111", "11111,0000011111",
    "111111,0000111111", "1111111,0001111111", "11111111,0011111111", "111111111,0111111111",
        "1111111111,1111111111"
  })
  private @interface InternalAccountNumbersSource {}

  @ParameterizedTest
  @InternalAccountNumbersSource
  void buildExternalShouldLeftPadDebtorAccountNumber(
      final long accountNumber, final String expectedAccountNumber) {
    final ExternalBeneficiary externalBeneficiary = buildExternalBeneficiary();

    final ExternalBeneficiaryInformation actual =
        testSubject.buildExternal(accountNumber, externalBeneficiary);
    assertThat(actual.getAccountNumber(), is(expectedAccountNumber));
  }

  @ParameterizedTest
  @InternalAccountNumbersSource
  void buildInternalShouldLeftPadDebtorAccountNumber(
      final long accountNumber, final String expectedAccountNumber) {
    final InternalBeneficiary internalBeneficiary = buildInternalBeneficiary();

    final InternalBeneficiaryInformation actual =
        testSubject.buildInternal(accountNumber, internalBeneficiary);
    assertThat(actual.getAccountNumber(), is(expectedAccountNumber));
  }

  @ParameterizedTest
  @InternalAccountNumbersSource
  void buildExternalUpdateShouldLeftPadDebtorAccountNumber(
      final long accountNumber, final String expectedAccountNumber) {
    final ExternalBeneficiary request = buildExternalBeneficiaryUpdate();
    final ExternalBeneficiary originalBeneficiary = buildExternalBeneficiary();

    final ExternalUpdateBeneficiaryInformationWrapper actual =
        testSubject.buildExternalUpdate(accountNumber, request, originalBeneficiary);
    assertThat(actual.getBeneficiaryInformation().getAccountNumber(), is(expectedAccountNumber));
  }

  private ExternalBeneficiary buildExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .accountNumber(String.valueOf(CREDITOR_EXTERNAL_ACCOUNT_NUMBER))
        .accountSortCode(SORT_CODE)
        .name(PAYEE_NAME)
        .reference(REFERENCE)
        .memorableName(MEMORABLE_NAME)
        .build();
  }

  private InternalBeneficiary buildInternalBeneficiary() {
    return InternalBeneficiary.builder()
        .accountNumber(String.valueOf(CREDITOR_INTERNAL_ACCOUNT_NUMBER))
        .build();
  }

  private ExternalBeneficiary buildExternalBeneficiaryUpdate() {
    return ExternalBeneficiary.builder()
        .beneficiaryId(BENEFICIARY_ID)
        .accountNumber(String.valueOf(CREDITOR_EXTERNAL_ACCOUNT_NUMBER))
        .accountSortCode(SORT_CODE)
        .name(PAYEE_NAME)
        .reference(NEW_REFERENCE)
        .memorableName(NEW_MEMORABLE_NAME)
        .build();
  }
}
