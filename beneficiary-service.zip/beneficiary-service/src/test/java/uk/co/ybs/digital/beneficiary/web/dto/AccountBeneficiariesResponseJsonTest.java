package uk.co.ybs.digital.beneficiary.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class AccountBeneficiariesResponseJsonTest {

  @Autowired private JacksonTester<List<Beneficiary>> json;

  private List<Beneficiary> response;

  @Value("classpath:api/accountBeneficiaries/response.json")
  private Resource responseFile;

  @BeforeEach
  void setup() {
    response =
        Arrays.asList(
            InternalBeneficiary.builder()
                .beneficiaryId("123abc")
                .accountNumber("1234567890")
                .build(),
            ExternalBeneficiary.builder()
                .beneficiaryId("124abc")
                .name("MR B TEST")
                .accountNumber("12345679")
                .accountSortCode("112244")
                .reference("B REF")
                .memorableName("Joint Account")
                .build());
  }

  @Test
  void serializes() throws IOException {
    assertThat(json.write(response)).isEqualToJson(responseFile, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    assertThat(json.read(responseFile)).isEqualTo(response);
  }
}
