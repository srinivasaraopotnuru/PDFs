package uk.co.ybs.digital.beneficiary.service.utilities;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import uk.co.ybs.digital.beneficiary.exception.BeneficiaryValidationException;
import uk.co.ybs.digital.beneficiary.service.product.dto.ProductInfo;

public class ProductBeneficiaryLimitValidatorTest {

  private static final String ACCOUNT_NUMBER = "12345678";
  private static final int LIMIT_EXTERNAL = 4;
  private static final int LIMIT_INTERNAL = 2;

  private final ProductBeneficiaryLimitValidator testSubject =
      new ProductBeneficiaryLimitValidator();

  @ParameterizedTest
  @ValueSource(ints = {LIMIT_EXTERNAL - 2, LIMIT_EXTERNAL - 1})
  void shouldValidateExternalBeneficiaryLimit(final int numberOfExistingBeneficiaries) {
    final ProductInfo productInfo = createProductInfo();

    final int limit =
        testSubject.validateExternalBeneficiaryLimit(
            ACCOUNT_NUMBER, numberOfExistingBeneficiaries, productInfo);

    assertThat(limit, is(LIMIT_EXTERNAL));
  }

  @ParameterizedTest
  @ValueSource(ints = {LIMIT_EXTERNAL, LIMIT_EXTERNAL + 1})
  void shouldThrowExceptionWhenExternalBeneficiariesWouldBeExceeded(
      final int numberOfExistingBeneficiaries) {
    final ProductInfo productInfo = createProductInfo();

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateExternalBeneficiaryLimit(
                    ACCOUNT_NUMBER, numberOfExistingBeneficiaries, productInfo));

    assertThat(
        exception.getMessage(),
        is("External beneficiary limit exceeded for account: " + ACCOUNT_NUMBER));
  }

  @ParameterizedTest
  @ValueSource(ints = {LIMIT_INTERNAL - 2, LIMIT_INTERNAL - 1})
  void shouldValidateInternalBeneficiaryLimit(final int numberOfExistingBeneficiaries) {
    final ProductInfo productInfo = createProductInfo();

    final int limit =
        testSubject.validateInternalBeneficiaryLimit(
            ACCOUNT_NUMBER, numberOfExistingBeneficiaries, productInfo);

    assertThat(limit, is(LIMIT_INTERNAL));
  }

  @ParameterizedTest
  @ValueSource(ints = {LIMIT_INTERNAL, LIMIT_INTERNAL + 1})
  void shouldThrowExceptionWhenInternalBeneficiariesWouldBeExceeded(
      final int numberOfExistingBeneficiaries) {
    final ProductInfo productInfo = createProductInfo();

    final BeneficiaryValidationException exception =
        assertThrows(
            BeneficiaryValidationException.class,
            () ->
                testSubject.validateInternalBeneficiaryLimit(
                    ACCOUNT_NUMBER, numberOfExistingBeneficiaries, productInfo));

    assertThat(
        exception.getMessage(),
        is("Internal beneficiary limit exceeded for account: " + ACCOUNT_NUMBER));
  }

  private static ProductInfo createProductInfo() {
    return ProductInfo.builder()
        .beneficiaries(
            ProductInfo.Beneficiaries.builder()
                .external(LIMIT_EXTERNAL)
                .internal(LIMIT_INTERNAL)
                .build())
        .build();
  }
}
