#!/usr/bin/env bash
set -e

# Get a GITLAB_TOKEN token and export to GITLAB_TOKEN before running this script
if [ "$GITLAB_TOKEN" = "" ]; then
  echo "Please export your GitLab API token as GITLAB_TOKEN" >&2
  exit
fi
mkdir -p target

# Source the gitlab utils
. $(dirname "${BASH_SOURCE:-$0}")/gitlab-utils.sh
GetAllGroups
GetAllProjects

ALL_GROUPS=$(jq -s 'add' target/groups*.json)
GROUP_IDS_SQUADS=$(echo "$ALL_GROUPS" | jq '.|=sort_by(.full_path) | .[] | select(.full_path|test(".*-maintainers.*")) | .id')
GROUP_IDS_OTHERS=$(echo "$ALL_GROUPS" | jq '.|=sort_by(.full_path) | .[] | select(.full_path|test("^(?!.*-maintainers).*")) | .id')
GROUP_SETS=("$GROUP_IDS_SQUADS" "$GROUP_IDS_OTHERS")
PARENT_GROUP="PARENT_GROUP"
DIVIDER="------------------------------"
GROUP_SET_NAME="Squad"

for GROUP_IDS in "${GROUP_SETS[@]}"
do
  REPORT_HTML="$REPORT_HTML<table border='1'><tr><th colspan='2'>$GROUP_SET_NAME  Group Memberships</th></tr><tr><th>Group</th><th>Subgroup</th></tr>"
  echo "$GROUP_SET_NAME Group Memberships:"
  GROUP_SET_NAME="Domain"
  echo "$DIVIDER"
  for GROUP_ID in $GROUP_IDS
  do
    MEMBERS=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/groups/$GROUP_ID/members")
    if [ "$MEMBERS" != "[]" ]; then
      GROUP_JSON=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/groups/$GROUP_ID")
      GROUP_NAME=$(echo "$GROUP_JSON" | jq -r '.name')
      GROUP_NAMESPACE=$(echo "$GROUP_JSON" | jq -r '.full_path')
      PREFIX=""
      SUFFIX=""
      if [[ "$GROUP_NAMESPACE" =~ $PARENT_GROUP/.* ]]; then
        TAB="    "
        PREFIX="<td/>"
      else
        TAB=""
        SUFFIX="<td/>"
        PARENT_GROUP=$GROUP_NAMESPACE
      fi
      echo "$TAB$GROUP_NAME : $GROUP_NAMESPACE (ID: $GROUP_ID)"
      MEMBER_NAMES=$(echo "$MEMBERS" | jq -r '.[] | "'"$TAB"'\(.name) : \(if .access_level >= 50 then "Owner"'\
' elif .access_level >= 40 then "Maintainer"'\
' elif .access_level >= 30 then "Developer"'\
' elif .access_level >= 20 then "Reporter"'\
' elif .access_level >= 10 then "Guest" else "Unkonwn" end)"')
      echo "$MEMBER_NAMES"
      echo "$DIVIDER"
      REPORT_HTML="$REPORT_HTML<tr>$PREFIX<td><b>$GROUP_NAME</b> ($GROUP_NAMESPACE)<br/>$(sed 's|$|<br/>|g' <<<"$MEMBER_NAMES" | tr -d '\n')</td>$SUFFIX</tr>"
      # echo "REPORT_HTML=$REPORT_HTML"
    fi
  done
  REPORT_HTML="$REPORT_HTML</table>"
done

PROJ_IDS=$(jq -s 'add' target/projs*.json | jq '.|=sort_by(.path_with_namespace) | .[] | .id')

REPORT_HTML="$REPORT_HTML<table border='1'><tr><th>Project Memberships</th></tr>"
echo ""
echo "Project Memberships:"
echo "$DIVIDER"
for PROJ_ID in $PROJ_IDS
do
  MEMBERS=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/members")
  if [ "$MEMBERS" != "[]" ]; then
    PROJECT_JSON=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID")
    PROJECT_NAME=$(echo "$PROJECT_JSON" | jq -r '.name')
    PROJECT_NAMESPACE=$(echo "$PROJECT_JSON" | jq -r '.path_with_namespace')
    if [[ "$PROJECT_NAMESPACE" =~ U[0-9]{5}.* ]]; then
      continue
    fi
    echo "$PROJECT_NAME : $PROJECT_NAMESPACE (ID: $PROJ_ID)"
    MEMBER_NAMES=$(echo "$MEMBERS" | jq -r '.[] | "\(.name) : \(if .access_level >= 50 then "Owner"'\
' elif .access_level >= 40 then "Maintainer"'\
' elif .access_level >= 30 then "Developer"'\
' elif .access_level >= 20 then "Reporter"'\
' elif .access_level >= 10 then "Guest" else "Unkonwn" end)"')
    echo "$MEMBER_NAMES"
    echo "$DIVIDER"
    REPORT_HTML="$REPORT_HTML<tr><td><b>$PROJECT_NAME</b> ($PROJECT_NAMESPACE)<br/>$(sed 's|$|<br/>|g' <<<"$MEMBER_NAMES" | tr -d '\n')</td></tr>"
  fi
done

REPORT_HTML="$REPORT_HTML</table>"
