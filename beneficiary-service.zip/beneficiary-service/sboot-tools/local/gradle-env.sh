#!/bin/bash
export gwd=`git rev-parse --show-toplevel`
#export GRADLE_USER_HOME="$gwd/.gradle"

### Default for VM
PROXY_HOST="127.0.0.1"
PROXY_PORT="3128"
if [[ "$(uname -s)" == MINGW* ]]; then
    ### Windows OS
    PROXY_HOST="ybsproxyvip"
    PROXY_PORT="80"
fi

export GRADLE_OPTS="-Djavax.net.ssl.trustStore=$gwd/sboot-tools/certs/cacerts.jks \
-Djavax.net.ssl.trustStorePassword=changeit \
-Dhttp.proxyHost=$PROXY_HOST \
-Dhttps.proxyHost=$PROXY_HOST \
-Dhttp.proxyPort=$PROXY_PORT \
-Dhttps.proxyPort=$PROXY_PORT \
-Dorg.gradle.internal.launcher.welcomeMessageEnabled=true \
-Dorg.gradle.parallel=true \
-Djava.security.properties=$gwd/.gradle-ci/java.security"
