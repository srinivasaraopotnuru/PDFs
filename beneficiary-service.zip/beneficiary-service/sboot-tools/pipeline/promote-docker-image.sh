#!/usr/bin/env bash
set -e

echo ""
echo "Promoting image: $DOCKER_NAME:$VERSION"
echo ""

if [ "" != "$ARTIFACTORY_HOST" ] && [ "" != "$DOCKER_NAME" ] && [ "" != "$VERSION" ]; then
RESP=$(curl -k --write-out ''%{http_code}'' -u$ARTIFACTORY_USERNAME:$ARTIFACTORY_PASSWORD \
 -v -X POST "https://$ARTIFACTORY_HOST/artifactory/api/docker/digital-docker-nonprod-local/v2/promote" \
 -H "Content-Type: application/json" -d '{
    "targetRepo" : "digital-docker-prod-local", 
    "dockerRepository" : "'"$DOCKER_NAME"'", 
    "tag" : "'"$VERSION"'",
    "targetTag" : "'"$VERSION"'",
    "copy": false
}') || true
  HTTP_CODE="${RESP:${#RESP}-3}"
  BODY="${RESP:0:${#RESP}-3}"
  echo HTTP_CODE=$HTTP_CODE
  echo BODY=$BODY
  if [ ! "${HTTP_CODE:0:2}" = "20" ]; then
    exit 1
  fi
else
  echo "ARTIFACTORY_HOST, DOCKER_NAME & VERSION must be defined before promoting"
  exit 1
fi
