#!/usr/bin/env bash

set -e

if [ ! -d $BASE_PATH ];
then
  exit 0
fi

echo ""
echo "INFO: Compiling template files in directory: $BASE_PATH"
echo ""

HIDDEN_FILES=`find $BASE_PATH -path '*/\.*' -and -path '*/*_template.json' | tr '\r\n' ' '`
TEMPLATE_LIST=$HIDDEN_FILES`find $BASE_PATH -type f -not -path '*/\.*' -and \( -path '*/*_template.json' -or -path '*/*_template.yml' -or -path '*/*_template.yaml' \) | tr '\r\n' ' '`
SUBSTITUTION_LIST="ARTIFACTORY_USERNAME ARTIFACTORY_PASSWORD APPLICATION OPENSHIFT_DEPLOY_NAMESPACE ROUTE_DOMAIN REFSBOOT_CLIENT_USERNAME REFSBOOT_CLIENT_PASSWORD_DEV VERSION SERVICE_DOMAIN"

echo ""
echo "INFO: Compiling files: "$TEMPLATE_LIST

for TEMPLATE in $TEMPLATE_LIST;
do
  if [ ! -d $TEMPLATE ] && [ -f $TEMPLATE ]
  then

    echo ""
    echo "INFO: Compiling file: "$TEMPLATE

    ################################
    #### SUBSTITUTING VARIABLES ####
    ################################

    FILE=`echo $TEMPLATE | sed 's/_template//g'`
    cat $TEMPLATE > $FILE

    echo "INFO: Substituting variables"

    if grep \$\(var: $FILE >/dev/null 2>&1;
    then
      for VAR in $SUBSTITUTION_LIST;
      do
        sed -i 's/$(var:'$VAR')/'${!VAR}'/g' $FILE
      done
    fi

    ############################
    #### SUBSTITUTING FILES ####
    ############################

    echo "INFO: Substituting files"

    if grep \$\(file: $FILE;
    then
      echo "INFO: Fetching filename from file"
      FILE_COPY=`cat $FILE | tr '\r\n' ' ' | sed 's/^.*\$(file:\(\.[a-z]*\.[a-z]*\)).*$/\1/'`

      echo "INFO: Prepending base directory to file name"
      DIRECTORY=`dirname $FILE`
      FILE_COPY=$DIRECTORY"/"$FILE_COPY

      echo "INFO: Escaping dollar symbol and removing whitespace"
      FILE_COPY=`cat $FILE_COPY | sed 's/\\$/\\\\$/g'`
      FILE_COPY=`echo $FILE_COPY | tr -d "[:space:]"`

      echo $FILE_COPY

      echo "INFO: Copyfing file contents in appropriate location"
      sed -i 's/\$(file:\(\.[a-z]*\.[a-z]*\))/'$FILE_COPY'/' $FILE
    fi

    #############################
    #### SUBSTITUTING BASE64 ####
    #############################

    echo "INFO: Substituting base64"

    if grep \$\(base64: $FILE;
    then
      TEMP_FILE=$FILE.tmp
      while read LINE;
      do
        echo $LINE >> $TEMP_FILE
        BASE_64_INPUT=`echo $LINE | sed -n 's/^.*\$(base64:\(.*\)).*$/\1/p'`
        BASE_64=`echo $BASE_64_INPUT | tr -d '[:space:]' | base64 | tr -d '[:space:]'`
        sed -i 's/$(base64:.*)/'`echo $BASE_64`'/g' $TEMP_FILE
      done < $FILE
      cp $TEMP_FILE $FILE
      rm -f $TEMP_FILE
    fi

    echo "INFO: Produced file: "$FILE

  fi
done
echo ""
exit 0
