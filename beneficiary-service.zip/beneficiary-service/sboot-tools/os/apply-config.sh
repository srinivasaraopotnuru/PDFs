#!/usr/bin/env bash
set -eo pipefail

seperator=--------------------
seperator=$seperator$seperator

if [ "$ENVIRONMENT_NAME" == "" ]; then
  # Old ci/cd configs use ENVIRONMENT_TYPE rather than ENVIRONMENT_NAME
  ENVIRONMENT_NAME=$ENVIRONMENT_TYPE
fi
echo "$seperator"
echo "Checking: $OPENSHIFT_CONFIG_DIR/$ENVIRONMENT_NAME"
if [ "" != "$OPENSHIFT_CONFIG_DIR" ] && [ "" != "$ENVIRONMENT_NAME" ] && [ -d "$OPENSHIFT_CONFIG_DIR/$ENVIRONMENT_NAME/" ]; then
  FILE_LIST=$(find "$OPENSHIFT_CONFIG_DIR/$ENVIRONMENT_NAME/" -not -path '*/\.*' -and \( -path '*/*.json' -o -path '*/*.yaml' -o -path '*/*.yml' \) -and -not -path '*template*' | tr '\r\n' ' ')
fi

if [ "" != "$FILE_LIST" ]; then
  echo ""
  echo "Creating / Updating application config from static content"

  for FILE in $FILE_LIST;
  do
    echo ""

    DEPLOY_TYPE=$(<<<"$FILE" rev | cut -d'/' -f2 | rev)
    if [[ "deploy-request" != "$DEPLOY_TYPE" ]] && [[ "$OPENSHIFT_DEPLOY_INCLUDES" == "ALL" || "$OPENSHIFT_DEPLOY_INCLUDES" =~ .*\/$DEPLOY_TYPE\/.* ]]; then
      echo "Configuring: ($DEPLOY_TYPE) $FILE"
    else
      echo "NOT configuring: ($DEPLOY_TYPE) $FILE"
      continue
    fi

    if oc get -f $FILE >/dev/null 2>&1;
    then
      if grep PersistentVolumeClaim $FILE >/dev/null 2>&1;
      then
        echo "WARN: Volume already exists, skipping"
        continue
      fi
    fi

    if DEPLOYMENT_LOG=$(oc apply -f $FILE 2>&1); then
      echo "Configured OK"
      CONFIG_STATUS=SUCCESS
    else
      echo "Configuration ERROR"
      CONFIG_STATUS=FAILED
    fi
    echo "$DEPLOYMENT_LOG"

    sleep 1
  done
fi

echo ""
echo "CONFIG_STATUS=$CONFIG_STATUS"

if [ "$CONFIG_STATUS" != "SUCCESS" ]; then
  echo "Errors occurred when applying config"
  exit 1
fi
