#!/usr/bin/env bash
set -e
QUIET=$1

echo ""
echo "Working on $OPENSHIFT_CONFIG_DIR"

TEMPLATE_FILE="$OPENSHIFT_CONFIG_DIR/template/template.json"
TEMPLATE_FILE_YML="$OPENSHIFT_CONFIG_DIR/template/template.yml"
TEMPLATE_FILE_YAML="$OPENSHIFT_CONFIG_DIR/template/template.yaml"
APPLICATION_CFG="$OPENSHIFT_CONFIG_DIR/template/application.cfg"
if [ "" == "$OPENSHIFT_DEPLOY_INCLUDES" ]; then
  #Default inclusions for deployments (ALL, assume non-template deployment)
  OPENSHIFT_DEPLOY_INCLUDES=ALL
fi
if [ "" == "$APP_TYPE" ]; then
  #Default app type to dc; deployment config, rather than sts; stateful set
  APP_TYPE=dc
fi

echo ""
echo "INFO: Configuring $APP_NAME into project $OPENSHIFT_DEPLOY_NAMESPACE"

if [ ! -f "$TEMPLATE_FILE" ]; then
  TEMPLATE_FILE=$TEMPLATE_FILE_YML
fi
if [ ! -f "$TEMPLATE_FILE" ]; then
  TEMPLATE_FILE=$TEMPLATE_FILE_YAML
fi
if [ -f "$TEMPLATE_FILE" ]; then

  echo "Loading application config: $APPLICATION_CFG"
  . $APPLICATION_CFG

  if [ "$OPENSHIFT_DEPLOYER_TAG" == "" ]; then
    OPENSHIFT_DEPLOYER_TAG=$OPENSHIFT_DEPLOY_USER
  fi
  OPENSHIFT_DEPLOYER_DATE=$(date --utc +%FT%TZ)

  TEMPLATE_PARAMS=""
  IFS=',' read -ra PARAMS_ARR <<< "$OPENSHIFT_TEMPLATE_PARAMS"
  for i in ${PARAMS_ARR[@]}
  do
    if [ "" != "${!i}" ]; then
      TEMPLATE_PARAMS="$TEMPLATE_PARAMS -p $i=${!i}"
    fi
  done

  echo ""
  echo "Creating application config from Template"
  PROCESSED_CFG=$(oc process -f "$TEMPLATE_FILE" \
  -p OPENSHIFT_DEPLOYER_TAG="$OPENSHIFT_DEPLOYER_TAG" \
  -p OPENSHIFT_DEPLOYER_DATE="$OPENSHIFT_DEPLOYER_DATE" \
  -p OPENSHIFT_DEPLOYER_HOST="$HOSTNAME" \
  $TEMPLATE_PARAMS \
  --param-file="$APPLICATION_CFG")
  export PROCESSED_CFG
  if [ "-q" != "$QUIET" ]; then
    echo "$PROCESSED_CFG" | jq .
  fi
fi
