package uk.co.ybs.digital.login.model;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "E_SECURITY_HISTORY")
public final class SecurityHistory {

  public static final String CODE_LOGIN_OK = "LO";

  @Id
  @Column(name = "SYSID")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ESH_SYSID_SEQ")
  @SequenceGenerator(sequenceName = "ESH_SYSID_SEQ", allocationSize = 1, name = "ESH_SYSID_SEQ")
  private Long sysId;

  @Column(name = "EVENT_TIME")
  private LocalDateTime eventTime;

  @Column(name = "HISTORY_CODE")
  private String code;

  @Column(name = "USERID")
  private String userId;

  @Column(name = "OPERATOR_ID")
  private String operatorId;

  @Column(name = "OTHER_CHANNEL_CODE")
  private String channel;
}
