package uk.co.ybs.digital.login.web.dto;

import io.swagger.annotations.ApiModelProperty;
import java.time.Instant;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class LoginDetails {

  @NonNull
  @ApiModelProperty(required = true, example = "2019-04-02T10:21:41.894Z")
  private final Instant loginTime;

  @NonNull
  @ApiModelProperty(required = true, example = "2019-04-01T23:35:04.329Z")
  private final Instant lastLoginTime;
}
