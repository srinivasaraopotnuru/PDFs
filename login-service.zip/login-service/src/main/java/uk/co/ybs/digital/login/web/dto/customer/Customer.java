package uk.co.ybs.digital.login.web.dto.customer;

import java.time.LocalDate;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
public class Customer {
  private final String partyId;
  private final String title;
  private final String forename;
  private final String surname;
  private final LocalDate deceasedDate;
  private final String email;
}
