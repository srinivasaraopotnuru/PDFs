package uk.co.ybs.digital.login.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.login.model.SecurityHistory;

public interface SecurityHistoryRepository extends JpaRepository<SecurityHistory, Long> {}
