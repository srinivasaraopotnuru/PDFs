package uk.co.ybs.digital.login.service;

import java.time.Instant;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.login.service.ValidateLoginService.CustomerInformation;
import uk.co.ybs.digital.login.web.dto.LoginRequest;
import uk.co.ybs.digital.login.web.dto.LoginResponse;

@Slf4j
@Service
@RequiredArgsConstructor
public class LoginService {

  private final ValidateLoginService validateLoginService;
  private final AuditLoginService auditLoginService;
  private final LoginResponseMapper loginResponseMapper;

  public LoginResponse login(
      final LoginRequest loginRequest, final RequestMetadata requestMetadata) {
    final CustomerInformation customerInformation =
        validateLoginService.validateLogin(loginRequest, requestMetadata);
    final Instant loginTime = auditLoginService.auditLogin(customerInformation.getLdapPerson());

    log.info(
        "Login Details - partyId : {} | canonicalPartyId : {} | customerNumber : {}",
        loginRequest.getPartyId(),
        customerInformation.getCustomer().getPartyId(),
        customerInformation.getLdapPerson().getCustomerNumber());

    return loginResponseMapper.map(
        customerInformation.getCustomer(),
        loginTime,
        customerInformation.getLdapPerson().getAccessTime());
  }
}
