package uk.co.ybs.digital.login.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class CustomerDetails {

  @ApiModelProperty(required = true, example = "1234567890")
  private final long partyId;

  @NonNull
  @ApiModelProperty(required = true, example = "John")
  private final String forename;

  @NonNull
  @ApiModelProperty(required = true, example = "Smith")
  private final String surname;

  @ApiModelProperty(example = "Mr")
  private final String title;

  @ApiModelProperty(example = "john.smith@gmail.com")
  private final String email;

  @JsonProperty("customerNumber")
  @ApiModelProperty(required = true, example = "1234567890")
  public long getCustomerNumber() {
    return partyId;
  }
}
