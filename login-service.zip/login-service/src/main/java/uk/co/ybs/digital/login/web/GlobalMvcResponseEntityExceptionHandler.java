package uk.co.ybs.digital.login.web;

import static uk.co.ybs.digital.login.web.dto.ErrorResponse.ErrorItem;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import uk.co.ybs.digital.login.web.dto.ErrorResponse;

@ControllerAdvice
@Order(
    Ordered.HIGHEST_PRECEDENCE) // Consult this ControllerAdvice first, before any service specific
// advice
@Slf4j
public class GlobalMvcResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      final MethodArgumentNotValidException exception,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    List<ErrorItem> errors =
        exception.getBindingResult().getFieldErrors().stream()
            .map(
                error -> {
                  if (Objects.isNull(error.getRejectedValue())) {
                    return ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_MISSING)
                        .message(error.getDefaultMessage())
                        .build();
                  } else {
                    return ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_INVALID)
                        .message(error.getDefaultMessage())
                        .build();
                  }
                })
            .collect(Collectors.toList());

    ErrorResponse response =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Invalid request body")
            .errors(errors)
            .build();

    return handleExceptionInternal(exception, response, headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
      final HttpRequestMethodNotSupportedException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    log.error("Handled HttpRequestMethodNotSupportedException: {}", ex.toString());
    pageNotFoundLogger.warn(ex.getMessage());

    Set<HttpMethod> supportedMethods = ex.getSupportedHttpMethods();
    if (!CollectionUtils.isEmpty(supportedMethods)) {
      headers.setAllow(supportedMethods);
    }

    final ErrorResponse body =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNSUPPORTED_METHOD)
                    .message("Unsupported method")
                    .build())
            .build();

    return handleExceptionInternal(ex, body, headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(
      final HttpMessageNotReadableException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    log.error("Handled HttpMessageNotReadableException: {}", ex.toString());

    final ErrorResponse.ErrorResponseBuilder response =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Unable to parse request body");

    response.error(
        ErrorResponse.ErrorItem.builder()
            .errorCode(ErrorItem.RESOURCE_INVALID_FORMAT)
            .message("An unexpected error occurred when attempting to parse the request body")
            .build());

    return handleExceptionInternal(ex, response.build(), headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
      final HttpMediaTypeNotSupportedException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    log.error("Handled HttpMediaTypeNotSupportedException: {}", ex.toString());

    List<MediaType> mediaTypes = ex.getSupportedMediaTypes();
    if (!CollectionUtils.isEmpty(mediaTypes)) {
      headers.setAccept(mediaTypes);
    }

    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.HEADER_INVALID)
                    .message("Content-Type header is invalid")
                    .path(HttpHeaders.CONTENT_TYPE)
                    .build())
            .build();

    return handleExceptionInternal(ex, errorResponse, headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleExceptionInternal(
      final Exception ex,
      Object body,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    if (body == null && !HttpStatus.NOT_ACCEPTABLE.equals(status)) {
      // Put a generic error response body in with the right status
      body =
          ErrorResponse.builder(status)
              .id(RequestIdHelper.getRequestId(request))
              .error(
                  ErrorItem.builder()
                      .errorCode(ErrorItem.UNEXPECTED_ERROR)
                      .message("Unexpected Error")
                      .build())
              .build();
    }

    return super.handleExceptionInternal(ex, body, headers, status, request);
  }
}
