package uk.co.ybs.digital.login.service;

import java.time.Instant;
import org.mapstruct.Mapper;
import uk.co.ybs.digital.login.web.dto.LoginDetails;
import uk.co.ybs.digital.login.web.dto.LoginResponse;
import uk.co.ybs.digital.login.web.dto.customer.Customer;

@Mapper(componentModel = "spring")
public interface LoginResponseMapper {

  LoginResponse map(Customer customer, LoginDetails login);

  LoginDetails map(Instant loginTime, Instant lastLoginTime);

  default LoginResponse map(
      final Customer customer, final Instant loginTime, final Instant lastLoginTime) {
    return map(customer, map(loginTime, lastLoginTime));
  }
}
