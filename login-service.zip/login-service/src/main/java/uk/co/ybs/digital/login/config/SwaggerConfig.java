package uk.co.ybs.digital.login.config;

import java.util.Arrays;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import uk.co.ybs.digital.security.HttpHeaderNames;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
  @Bean
  public Docket api() {
    return new Docket(DocumentationType.SWAGGER_2)
        .select()
        .apis(RequestHandlerSelectors.basePackage("uk.co.ybs.digital"))
        .paths(PathSelectors.any())
        .build()
        .pathMapping("/login")
        .globalOperationParameters(
            Arrays.asList(
                new ParameterBuilder()
                    .name("x-ybs-request-id")
                    .description("Unique identifier for the request")
                    .modelRef(new ModelRef("uuid"))
                    .parameterType("header")
                    .required(false)
                    .build(),
                new ParameterBuilder()
                    .name(HttpHeaderNames.REQUEST_SIGNATURE)
                    .description("Base64 encoded request signature")
                    .modelRef(new ModelRef("string"))
                    .parameterType("header")
                    .required(true)
                    .build(),
                new ParameterBuilder()
                    .name(HttpHeaderNames.REQUEST_SIGNATURE_KEY_ID)
                    .description("Identifier for the key used to sign the request")
                    .modelRef(new ModelRef("string"))
                    .parameterType("header")
                    .required(true)
                    .build()));
  }
}
