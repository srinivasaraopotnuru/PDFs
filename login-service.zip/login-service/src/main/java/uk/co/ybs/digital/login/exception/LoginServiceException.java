package uk.co.ybs.digital.login.exception;

public class LoginServiceException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public LoginServiceException(final String message) {
    super(message);
  }

  public LoginServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
