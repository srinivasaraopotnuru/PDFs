package uk.co.ybs.digital.login.config;

import java.net.URL;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnectorFactory;

@Configuration
public class CustomerServiceConfig {

  @Value("${uk.co.ybs.digital.customer.url}")
  private URL customerUrl;

  @Bean
  public WebClient customerServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(customerUrl.toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }
}
