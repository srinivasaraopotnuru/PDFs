package uk.co.ybs.digital.login.web.dto.customer;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class CustomerResponse {

  @JsonProperty(value = "party")
  private final Customer customer;
}
