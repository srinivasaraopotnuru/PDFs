package uk.co.ybs.digital.login.service;

import com.google.common.base.Strings;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.springframework.ldap.NamingException;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.login.exception.CustomerNotFoundException;
import uk.co.ybs.digital.login.exception.CustomerServiceException;
import uk.co.ybs.digital.login.exception.LoginDeniedException;
import uk.co.ybs.digital.login.exception.LoginServiceException;
import uk.co.ybs.digital.login.model.LdapPerson;
import uk.co.ybs.digital.login.repository.LdapPersonRepository;
import uk.co.ybs.digital.login.web.dto.LoginRequest;
import uk.co.ybs.digital.login.web.dto.customer.Customer;

@Service
@RequiredArgsConstructor
class ValidateLoginService {

  private final CustomerService customerService;
  private final LdapPersonRepository ldapPersonRepository;

  /** create validateLogin Method */
  public CustomerInformation validateLogin(
      final LoginRequest loginRequest, final RequestMetadata requestMetadata) {
    final Customer customer = validateCustomer(loginRequest, requestMetadata); // NOPMD
    final LdapPerson ldapPerson = validateLdapPerson(loginRequest); // NOPMD
    return new CustomerInformation(customer, ldapPerson);
  }

  private Customer validateCustomer(
      final LoginRequest loginRequest, final RequestMetadata requestMetadata) {
    final Customer customer = getCustomer(loginRequest.getPartyId(), requestMetadata); // NOPMD

    if (customer.getDeceasedDate() != null) {
      throw new LoginDeniedException(
          LoginDeniedException.Reason.CUSTOMER_DECEASED,
          String.format(
              "Customer %s has deceased date %s recorded",
              customer.getPartyId(), customer.getDeceasedDate()));
    }

    return customer;
  }

  private Customer getCustomer(final long partyId, final RequestMetadata requestMetadata) {
    try {
      return customerService.getCustomer(partyId, requestMetadata);
    } catch (CustomerNotFoundException exception) {
      throw new LoginDeniedException(
          LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_CUSTOMER_HUB,
          String.format("Customer %s not found", partyId),
          exception);
    } catch (CustomerServiceException exception) {
      throw new LoginServiceException(
          String.format("Error calling customer service for customer %s", partyId), exception);
    }
  }

  private LdapPerson validateLdapPerson(final LoginRequest loginRequest) {
    final String uid = Strings.padStart(String.valueOf(loginRequest.getPartyId()), 10, '0');
    final Optional<LdapPerson> ldapPersonOptional = getLdapPerson(uid);

    final LdapPerson ldapPerson = // NOPMD
        ldapPersonOptional.orElseThrow(
            () ->
                new LoginDeniedException(
                    LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_LDAP,
                    String.format("LdapPerson %s not found", uid)));

    if (!ldapPerson.isInDirectGroup()) {
      throw new LoginDeniedException(
          LoginDeniedException.Reason.CUSTOMER_INVALID_GROUP,
          String.format(
              "LdapPerson %s has groups %s, expected %s",
              uid, ldapPerson.getGroups(), LdapPerson.GROUP_DIRECT));
    }

    if (!ldapPerson.isPasswordStateOk()) {
      throw new LoginDeniedException(
          LoginDeniedException.Reason.CUSTOMER_INVALID_PASSWORD_STATE,
          String.format(
              "LdapPerson %s has password state %s, expected %s",
              uid, ldapPerson.getPasswordState(), LdapPerson.PASSWORD_STATE_OK));
    }

    return ldapPerson;
  }

  private Optional<LdapPerson> getLdapPerson(final String uid) {
    try {
      return ldapPersonRepository.findByUid(uid);
    } catch (NamingException ex) {
      throw new LoginServiceException(
          String.format("Error calling LDAP for LdapPerson %s", uid), ex);
    }
  }

  /** create CustomerInformation class */
  @Value
  public static class CustomerInformation {
    public Customer customer;
    public LdapPerson ldapPerson;
  }
}
