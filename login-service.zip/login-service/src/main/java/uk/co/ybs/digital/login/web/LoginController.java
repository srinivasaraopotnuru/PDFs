package uk.co.ybs.digital.login.web;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.login.service.LoginService;
import uk.co.ybs.digital.login.service.RequestMetadata;
import uk.co.ybs.digital.login.web.dto.LoginRequest;
import uk.co.ybs.digital.login.web.dto.LoginResponse;

@RestController
@RequiredArgsConstructor
public class LoginController {

  private final LoginService loginService;

  @PostMapping(
      value = "/login",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @ApiOperation(value = "Login a customer")
  /** create Login Method */
  public LoginResponse login(
      @RequestBody @Validated @ApiParam(value = "Login request information", required = true)
          final LoginRequest loginRequest,
      @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME) @ApiParam(hidden = true)
          final UUID requestId) {
    final RequestMetadata requestMetadata =
        RequestMetadata.builder()
            .requestId(requestId)
            .brandCode(loginRequest.getBrandCode())
            .build();

    return loginService.login(loginRequest, requestMetadata);
  }
}
