package uk.co.ybs.digital.login.service;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.login.model.LdapPerson;
import uk.co.ybs.digital.login.model.SecurityHistory;
import uk.co.ybs.digital.login.repository.LdapPersonRepository;
import uk.co.ybs.digital.login.repository.SecurityHistoryRepository;

@Service
@RequiredArgsConstructor
public class AuditLoginService {

  private final LdapPersonRepository ldapPersonRepository;
  private final SecurityHistoryRepository securityHistoryRepository;
  private final Clock clock;
  private static final String APP_CHANNEL = "SAPP";

  /** create auditLogin Method */
  public Instant auditLogin(final LdapPerson ldapPerson) {
    Instant loginTime = Instant.now(clock);
    updateLdapPerson(ldapPerson, loginTime);
    insertSecurityHistory(ldapPerson.getUid(), loginTime);
    return loginTime;
  }

  private void updateLdapPerson(final LdapPerson ldapPerson, final Instant loginTime) {
    final LdapPerson ldapPersonUpdated = ldapPerson.toBuilder().accessTime(loginTime).build();

    ldapPersonRepository.save(ldapPersonUpdated);
  }

  private void insertSecurityHistory(final String uid, final Instant loginTime) {
    final SecurityHistory securityHistory =
        SecurityHistory.builder()
            .eventTime(LocalDateTime.ofInstant(loginTime, clock.getZone()))
            .code(SecurityHistory.CODE_LOGIN_OK)
            .userId(uid)
            .operatorId(uid)
            .channel(APP_CHANNEL)
            .build();

    securityHistoryRepository.save(securityHistory);
  }
}
