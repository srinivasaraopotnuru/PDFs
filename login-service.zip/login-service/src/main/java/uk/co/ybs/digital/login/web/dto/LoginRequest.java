package uk.co.ybs.digital.login.web.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = LoginRequest.LoginRequestBuilder.class)
public class LoginRequest {

  @NotNull(message = "You must specify a party id")
  @Positive(message = "${validatedValue} is not a valid party id; value must be positive")
  @ApiModelProperty(required = true, example = "1234567890")
  private final Long partyId;

  @NotNull(message = "You must specify a brand code")
  @ApiModelProperty(required = true, example = "YBS")
  private final String brandCode;

  @JsonPOJOBuilder(withPrefix = "")
  public static class LoginRequestBuilder {
    @JsonAlias("customerNumber")
    public LoginRequestBuilder partyId(final Long partyId) {
      this.partyId = partyId;
      return this;
    }
  }
}
