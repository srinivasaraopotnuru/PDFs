package uk.co.ybs.digital.login.web;

import com.google.common.collect.ImmutableMap;
import java.util.Map;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.login.exception.LoginDeniedException;
import uk.co.ybs.digital.login.web.dto.ErrorResponse;
import uk.co.ybs.digital.login.web.dto.ErrorResponse.ErrorItem;

@ControllerAdvice
@Slf4j
public class LoginServiceExceptionHandler {

  private static final Map<LoginDeniedException.Reason, ErrorItem>
      LOGIN_DENIED_EXCEPTION_REASON_MAP = buildLoginDeniedExceptionReasonMap();

  @ExceptionHandler(RuntimeException.class)
  public ResponseEntity<ErrorResponse> handleUnexpectedException(
      final RuntimeException exception, final WebRequest request) {
    log.error(
        "Unhandled unexpected exception, returning 500 Internal Server Error: {}",
        exception.toString(),
        exception);

    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNEXPECTED_ERROR)
                    .message("Internal Server Error")
                    .build())
            .build();
    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(LoginDeniedException.class)
  public ResponseEntity<ErrorResponse> handleLoginDeniedException(
      final LoginDeniedException exception, final WebRequest request) {
    log.info("Handled LoginDeniedException, returning 403 Forbidden: {}", exception.toString());

    final HttpStatus status = HttpStatus.FORBIDDEN;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(getErrorResponseItemForLoginDeniedExceptionReason(exception.getReason()))
            .build();
    return ResponseEntity.status(status).body(errorResponse);
  }

  private static Map<LoginDeniedException.Reason, ErrorItem> buildLoginDeniedExceptionReasonMap() {
    return ImmutableMap.<LoginDeniedException.Reason, ErrorResponse.ErrorItem>builder()
        .put(
            LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_CUSTOMER_HUB,
            ErrorItem.builder()
                .errorCode(ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_NOT_FOUND_CUSTOMER_HUB)
                .message("Customer was not found on Customer Hub")
                .build())
        .put(
            LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_LDAP,
            ErrorItem.builder()
                .errorCode(ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_NOT_FOUND_LDAP)
                .message("Customer was not found on LDAP")
                .build())
        .put(
            LoginDeniedException.Reason.CUSTOMER_DECEASED,
            ErrorItem.builder()
                .errorCode(ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_DECEASED)
                .message("Customer is deceased")
                .build())
        .put(
            LoginDeniedException.Reason.CUSTOMER_INVALID_GROUP,
            ErrorItem.builder()
                .errorCode(ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_INVALID_GROUP)
                .message("Customer has an invalid group")
                .build())
        .put(
            LoginDeniedException.Reason.CUSTOMER_INVALID_PASSWORD_STATE,
            ErrorItem.builder()
                .errorCode(ErrorItem.ACCESS_DENIED_LOGIN_DENIED_CUSTOMER_INVALID_PASSWORD_STATE)
                .message("Customer has an invalid password state")
                .build())
        .build();
  }

  private ErrorResponse.ErrorItem getErrorResponseItemForLoginDeniedExceptionReason(
      final LoginDeniedException.Reason reason) {
    return Optional.ofNullable(LOGIN_DENIED_EXCEPTION_REASON_MAP.get(reason))
        .orElseThrow(
            () ->
                new IllegalArgumentException("Unexpected LoginDeniedException.Reason: " + reason));
  }
}
