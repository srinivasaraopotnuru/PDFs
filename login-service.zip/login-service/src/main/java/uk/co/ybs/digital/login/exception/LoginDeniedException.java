package uk.co.ybs.digital.login.exception;

import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.Value;

@Value
@EqualsAndHashCode(callSuper = true)
public class LoginDeniedException extends LoginServiceException {

  private static final long serialVersionUID = 1L;

  @NonNull private final Reason reason;

  public LoginDeniedException(final Reason reason, final String message) {
    this(reason, message, null);
  }

  public LoginDeniedException(final Reason reason, final String message, final Throwable cause) {
    super(message, cause);
    this.reason = reason;
  }

  public enum Reason {
    CUSTOMER_NOT_FOUND_CUSTOMER_HUB,
    CUSTOMER_NOT_FOUND_LDAP,
    CUSTOMER_DECEASED,
    CUSTOMER_INVALID_GROUP,
    CUSTOMER_INVALID_PASSWORD_STATE
  }
}
