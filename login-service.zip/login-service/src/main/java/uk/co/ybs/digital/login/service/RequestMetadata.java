package uk.co.ybs.digital.login.service;

import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class RequestMetadata {
  @NonNull private UUID requestId;
  @NonNull private String brandCode;
}
