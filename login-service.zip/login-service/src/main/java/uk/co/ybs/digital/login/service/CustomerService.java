package uk.co.ybs.digital.login.service;

import static uk.co.ybs.digital.login.web.dto.ErrorResponse.ErrorItem;

import io.micrometer.core.annotation.Timed;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.logging.calls.CallLogged;
import uk.co.ybs.digital.login.exception.CustomerNotFoundException;
import uk.co.ybs.digital.login.exception.CustomerServiceException;
import uk.co.ybs.digital.login.web.dto.ErrorResponse;
import uk.co.ybs.digital.login.web.dto.customer.Customer;
import uk.co.ybs.digital.login.web.dto.customer.CustomerResponse;

@Component
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class CustomerService {

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";

  private final WebClient customerServiceWebClient;

  /** create getCustomer Method */
  public Customer getCustomer(final long partyId, final RequestMetadata requestMetadata) {
    return customerServiceWebClient
        .get()
        .uri("/customer/{partyId}", partyId)
        .header(HEADER_REQUEST_ID, requestMetadata.getRequestId().toString())
        .header(HEADER_BRAND_CODE, requestMetadata.getBrandCode())
        .exchange()
        .onErrorMap(e -> new CustomerServiceException("Error calling customer service", e))
        .flatMap(response -> handleResponse(partyId, response))
        .blockOptional()
        .orElseThrow(() -> new CustomerServiceException("Empty response calling customer service"))
        .getCustomer();
  }

  private Mono<? extends CustomerResponse> handleResponse(
      final long partyId, final ClientResponse response) {
    if (response.statusCode() == HttpStatus.OK) {
      return response.bodyToMono(CustomerResponse.class);
    } else {
      return response
          .bodyToMono(ErrorResponse.class)
          .flatMap(
              errorResponse ->
                  Mono.error(handleErrorResponse(response.statusCode(), errorResponse, partyId)));
    }
  }

  private static CustomerServiceException handleErrorResponse(
      final HttpStatus httpStatus, final ErrorResponse errorResponse, final long partyId) {
    if (httpStatus == HttpStatus.NOT_FOUND) {
      if (errorResponse.containsOnlyErrorCode(ErrorItem.RESOURCE_NOT_FOUND)) {
        return new CustomerNotFoundException(String.format("Customer %s not found", partyId));
      }
    }
    return new CustomerServiceException(
        String.format("Error calling customer service: %s", httpStatus));
  }
}
