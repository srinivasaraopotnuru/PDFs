package uk.co.ybs.digital.login.repository;

import java.util.Optional;
import org.springframework.data.ldap.repository.LdapRepository;
import uk.co.ybs.digital.login.model.LdapPerson;

public interface LdapPersonRepository extends LdapRepository<LdapPerson> {
  Optional<LdapPerson> findByUid(String uid);
}
