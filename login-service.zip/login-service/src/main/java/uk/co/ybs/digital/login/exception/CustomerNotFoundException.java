package uk.co.ybs.digital.login.exception;

public class CustomerNotFoundException extends CustomerServiceException {

  private static final long serialVersionUID = 1L;

  public CustomerNotFoundException(final String message) {
    super(message);
  }
}
