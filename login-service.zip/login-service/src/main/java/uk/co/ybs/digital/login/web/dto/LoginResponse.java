package uk.co.ybs.digital.login.web.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class LoginResponse {

  @NonNull
  @ApiModelProperty(required = true)
  private final CustomerDetails customer;

  @NonNull
  @ApiModelProperty(required = true)
  private final LoginDetails login;
}
