package uk.co.ybs.digital.login.model;

import java.time.Instant;
import java.util.List;
import javax.naming.Name;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.ldap.odm.annotations.Attribute;
import org.springframework.ldap.odm.annotations.Entry;
import org.springframework.ldap.odm.annotations.Id;

@Entry(objectClasses = "person", base = "ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk")
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public final class LdapPerson {

  public static final String GROUP_DIRECT = "direct";
  public static final String PASSWORD_STATE_OK = "PWD_OK";

  @Id private Name id;

  private String uid;

  @Attribute(name = "accesstime")
  private long accessTimeEpochSecond;

  @Attribute(name = "groupusers")
  private List<String> groups;

  @Attribute(name = "passwordstate")
  private String passwordState;

  @Attribute(name = "customernumber")
  private String customerNumber;

  public boolean isInDirectGroup() {
    return groups.contains(GROUP_DIRECT);
  }

  public boolean isPasswordStateOk() {
    return PASSWORD_STATE_OK.equals(passwordState);
  }

  public Instant getAccessTime() {
    return Instant.ofEpochSecond(accessTimeEpochSecond);
  }

  public static class LdapPersonBuilder {
    public LdapPersonBuilder accessTime(final Instant instant) {
      accessTimeEpochSecond = instant.getEpochSecond();
      return this;
    }
  }
}
