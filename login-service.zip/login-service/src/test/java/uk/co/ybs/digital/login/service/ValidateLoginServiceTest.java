package uk.co.ybs.digital.login.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ldap.CommunicationException;
import org.springframework.ldap.support.LdapUtils;
import uk.co.ybs.digital.login.exception.CustomerNotFoundException;
import uk.co.ybs.digital.login.exception.CustomerServiceException;
import uk.co.ybs.digital.login.exception.LoginDeniedException;
import uk.co.ybs.digital.login.exception.LoginServiceException;
import uk.co.ybs.digital.login.model.LdapPerson;
import uk.co.ybs.digital.login.repository.LdapPersonRepository;
import uk.co.ybs.digital.login.service.ValidateLoginService.CustomerInformation;
import uk.co.ybs.digital.login.utils.TestHelper;
import uk.co.ybs.digital.login.web.dto.LoginRequest;
import uk.co.ybs.digital.login.web.dto.customer.Customer;

@ExtendWith(MockitoExtension.class)
public class ValidateLoginServiceTest {

  private static final long PARTY_ID = 123456;
  private static final String CUSTOMER_LDAP_PERSON_UID = "0000123456";

  @InjectMocks private ValidateLoginService validateLoginService;

  @Mock private CustomerService customerService;

  @Mock private LdapPersonRepository ldapPersonRepository;

  @Test
  void shouldValidateLogin() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();
    final Customer customer = buildCustomer();
    final LdapPerson ldapPerson = buildLdapPerson();

    when(customerService.getCustomer(PARTY_ID, requestMetadata)).thenReturn(customer);
    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID))
        .thenReturn(Optional.of(ldapPerson));

    CustomerInformation customerInformation =
        validateLoginService.validateLogin(loginRequest, requestMetadata);
    assertThat(customerInformation.getCustomer(), is(customer));
    assertThat(customerInformation.getLdapPerson(), is(ldapPerson));
  }

  @Test
  void shouldRejectLoginIfCustomerDeceased() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();
    final Customer customer =
        buildCustomer().toBuilder().deceasedDate(LocalDate.of(2019, 12, 4)).build();

    when(customerService.getCustomer(anyLong(), any())).thenReturn(customer);

    final LoginDeniedException exception =
        assertThrows(
            LoginDeniedException.class,
            () -> validateLoginService.validateLogin(loginRequest, requestMetadata));
    assertThat(exception.getReason(), is(LoginDeniedException.Reason.CUSTOMER_DECEASED));
    assertThat(
        exception.getMessage(),
        is("Customer " + PARTY_ID + " has deceased date 2019-12-04 recorded"));
  }

  @Test
  void shouldMapCustomerNotFoundException() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();

    when(customerService.getCustomer(anyLong(), any())).thenThrow(CustomerNotFoundException.class);

    LoginDeniedException exception =
        assertThrows(
            LoginDeniedException.class,
            () -> validateLoginService.validateLogin(loginRequest, requestMetadata));
    assertThat(
        exception.getReason(), is(LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_CUSTOMER_HUB));
    assertThat(exception.getMessage(), is("Customer " + PARTY_ID + " not found"));
    assertThat(exception.getCause(), isA(CustomerNotFoundException.class));
  }

  @Test
  void shouldMapCustomerServiceException() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();

    when(customerService.getCustomer(anyLong(), any())).thenThrow(CustomerServiceException.class);

    LoginServiceException exception =
        assertThrows(
            LoginServiceException.class,
            () -> validateLoginService.validateLogin(loginRequest, requestMetadata));
    assertThat(exception, isA(LoginServiceException.class)); // Expect not a sub-class here
    assertThat(
        exception.getMessage(), is("Error calling customer service for customer " + PARTY_ID));
    assertThat(exception.getCause(), isA(CustomerServiceException.class));
  }

  @Test
  void shouldMapCommunicationException() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();
    final Customer customer = buildCustomer();
    final CommunicationException communicationException =
        new CommunicationException(new javax.naming.CommunicationException());

    when(customerService.getCustomer(PARTY_ID, requestMetadata)).thenReturn(customer);
    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID))
        .thenThrow(communicationException);

    LoginServiceException exception =
        assertThrows(
            LoginServiceException.class,
            () -> validateLoginService.validateLogin(loginRequest, requestMetadata));
    assertThat(
        exception.getMessage(),
        is("Error calling LDAP for LdapPerson " + CUSTOMER_LDAP_PERSON_UID));
    assertThat(exception.getCause(), is(communicationException));
  }

  @Test
  void shouldHandleLdapPersonNotFound() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();
    final Customer customer = buildCustomer();

    when(customerService.getCustomer(PARTY_ID, requestMetadata)).thenReturn(customer);
    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID)).thenReturn(Optional.empty());

    LoginDeniedException exception =
        assertThrows(
            LoginDeniedException.class,
            () -> validateLoginService.validateLogin(loginRequest, requestMetadata));
    assertThat(exception.getReason(), is(LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_LDAP));
    assertThat(exception.getMessage(), is("LdapPerson " + CUSTOMER_LDAP_PERSON_UID + " not found"));
  }

  @Test
  void shouldHandleLdapPersonUnexpectedGroup() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();
    final Customer customer = buildCustomer();
    final LdapPerson ldapPerson =
        buildLdapPerson().toBuilder().groups(Collections.singletonList("admin")).build();

    when(customerService.getCustomer(PARTY_ID, requestMetadata)).thenReturn(customer);
    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID))
        .thenReturn(Optional.of(ldapPerson));

    LoginDeniedException exception =
        assertThrows(
            LoginDeniedException.class,
            () -> validateLoginService.validateLogin(loginRequest, requestMetadata));
    assertThat(exception.getReason(), is(LoginDeniedException.Reason.CUSTOMER_INVALID_GROUP));
    assertThat(
        exception.getMessage(),
        is("LdapPerson " + CUSTOMER_LDAP_PERSON_UID + " has groups [admin], expected direct"));
  }

  @Test
  void shouldHandleLdapPersonUnexpectedPasswordState() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();
    final Customer customer = buildCustomer();
    final LdapPerson ldapPerson =
        buildLdapPerson().toBuilder().passwordState("PWD_MANUALCREATE").build();

    when(customerService.getCustomer(PARTY_ID, requestMetadata)).thenReturn(customer);
    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID))
        .thenReturn(Optional.of(ldapPerson));

    LoginDeniedException exception =
        assertThrows(
            LoginDeniedException.class,
            () -> validateLoginService.validateLogin(loginRequest, requestMetadata));
    assertThat(
        exception.getReason(), is(LoginDeniedException.Reason.CUSTOMER_INVALID_PASSWORD_STATE));
    assertThat(
        exception.getMessage(),
        is(
            "LdapPerson "
                + CUSTOMER_LDAP_PERSON_UID
                + " has password state PWD_MANUALCREATE, expected PWD_OK"));
  }

  private Customer buildCustomer() {
    return Customer.builder()
        .partyId("123456")
        .title("Mr")
        .forename("John")
        .surname("Smith")
        .build();
  }

  private LdapPerson buildLdapPerson() {
    return LdapPerson.builder()
        .id(LdapUtils.newLdapName("uid=0000123456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))
        .accessTime(Instant.parse("2019-04-01T23:35:04.329Z"))
        .uid("0000123456")
        .groups(Collections.singletonList("direct"))
        .passwordState("PWD_OK")
        .build();
  }
}
