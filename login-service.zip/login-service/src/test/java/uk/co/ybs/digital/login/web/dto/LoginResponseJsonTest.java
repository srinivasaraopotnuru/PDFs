package uk.co.ybs.digital.login.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
class LoginResponseJsonTest {

  @Autowired private JacksonTester<LoginResponse> tester;

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void serialize(final LoginResponse loginResponse, final ClassPathResource json) throws Exception {
    assertThat(tester.write(loginResponse)).isEqualToJson(json, JSONCompareMode.STRICT);
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(buildLoginResponse(), new ClassPathResource("api/LoginResponse.json")),
        Arguments.of(
            buildLoginResponseWithoutEmailAndTitle(),
            new ClassPathResource("api/LoginResponseWithoutEmailAndTitle.json")));
  }

  private static LoginResponse buildLoginResponse() {
    return LoginResponse.builder()
        .customer(
            CustomerDetails.builder()
                .partyId(123456)
                .forename("John")
                .surname("Smith")
                .title("Mr")
                .email("john.smith@gmail.com")
                .build())
        .login(
            LoginDetails.builder()
                .loginTime(Instant.parse("2019-04-02T10:21:41.894Z"))
                .lastLoginTime(Instant.parse("2019-04-01T23:35:04.329Z"))
                .build())
        .build();
  }

  private static LoginResponse buildLoginResponseWithoutEmailAndTitle() {
    return LoginResponse.builder()
        .customer(
            CustomerDetails.builder().partyId(123456).forename("John").surname("Smith").build())
        .login(
            LoginDetails.builder()
                .loginTime(Instant.parse("2019-04-02T10:21:41.894Z"))
                .lastLoginTime(Instant.parse("2019-04-01T23:35:04.329Z"))
                .build())
        .build();
  }
}
