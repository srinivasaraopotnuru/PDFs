package uk.co.ybs.digital.login.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
class LoginRequestJsonTest {

  @Autowired private JacksonTester<LoginRequest> tester;

  private LoginRequest loginRequest;

  @BeforeEach
  void setUp() {
    loginRequest = LoginRequest.builder().partyId(123456L).brandCode("YBS").build();
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void deserialize(final ClassPathResource json) throws IOException {
    assertThat(tester.read(json)).isEqualTo(loginRequest);
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(new ClassPathResource("api/LoginRequest.json")),
        Arguments.of(new ClassPathResource("api/LoginRequestWithCustomerNumber.json")));
  }
}
