package uk.co.ybs.digital.login.utils;

import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

/*
 * For testing we want to create a mock customer service on a random port and connect to it.
 * Find a port during startup and store it to the corresponding system property, meaning that the application can
 * continue to initialise in the normal way from the properties.
 */
public class CustomerServiceRandomPortInitializer
    implements ApplicationContextInitializer<ConfigurableApplicationContext> {

  @Override
  public void initialize(final ConfigurableApplicationContext applicationContext) {
    int randomPort = SocketUtils.findAvailableTcpPort();
    TestPropertySourceUtils.addInlinedPropertiesToEnvironment(
        applicationContext, "uk.co.ybs.digital.customer-test-port=" + randomPort);
  }
}
