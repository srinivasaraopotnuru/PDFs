package uk.co.ybs.digital.login;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.StringReader;
import java.security.PrivateKey;
import java.security.Security;
import java.util.Objects;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.WebTestClientConfigurer;
import uk.co.ybs.digital.security.requestsigning.ClientHttpRequestSigner;
import uk.co.ybs.digital.security.requestsigning.PayloadBuilder;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnector;
import uk.co.ybs.digital.security.requestsigning.RequestSigningKeyRegistry;
import uk.co.ybs.digital.security.requestsigning.SignatureFactory;

@TestConfiguration
public class IntegrationTestConfig {

  @Value("${test.request.private.key}")
  String requestSigningPrivateKeyPem;

  @Bean
  public PrivateKey requestSigningPrivateKey() throws IOException {
    Security.addProvider(new BouncyCastleProvider());

    try (PEMParser parser = new PEMParser(new StringReader(requestSigningPrivateKeyPem))) {
      PEMKeyPair pemObject =
          (PEMKeyPair)
              Objects.requireNonNull(
                  parser.readObject(),
                  "Could not construct a PrivateKey from " + requestSigningPrivateKeyPem);
      return BouncyCastleProvider.getPrivateKey(pemObject.getPrivateKeyInfo());
    }
  }

  @Bean
  public WebTestClient signingWebTestClient(
      final ClientHttpConnector connector,
      final PrivateKey requestSigningPrivateKey,
      final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(
            new RequestSigningClientHttpConnector(
                connector,
                new ClientHttpRequestSigner(
                    new SignatureFactory(),
                    new PayloadBuilder(),
                    new RequestSigningKeyRegistry(
                        "FKbfNeQxsVQL5CwAJKP0q5fWOVe9ukn1K0lw", requestSigningPrivateKey))))
        .apply(webTestClientConfigurer)
        .build();
  }

  @Bean
  public WebTestClient nonSigningWebTestClient(
      final ClientHttpConnector connector, final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(connector).apply(webTestClientConfigurer).build();
  }

  @Bean
  public WebTestClientConfigurer webTestClientConfigurer(final ObjectMapper objectMapper) {
    return new ObjectMapperJsonWebTestClientConfigurer(objectMapper);
  }
}
