package uk.co.ybs.digital.login.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.time.LocalDate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.login.web.dto.customer.Customer;
import uk.co.ybs.digital.login.web.dto.customer.CustomerResponse;

@JsonTest
class CustomerResponseJsonTest {

  @Autowired private JacksonTester<CustomerResponse> tester;

  @Value("classpath:api/customer/CustomerResponseDeceased.json")
  private Resource json;

  private CustomerResponse customerResponse;

  @BeforeEach
  void setUp() {
    customerResponse =
        CustomerResponse.builder()
            .customer(
                Customer.builder()
                    .partyId("123456")
                    .title("Mr")
                    .forename("John")
                    .surname("Smith")
                    .deceasedDate(LocalDate.of(2019, 12, 4))
                    .build())
            .build();
  }

  @Test
  void deserialize() throws IOException {
    assertThat(tester.read(json)).isEqualTo(customerResponse);
  }
}
