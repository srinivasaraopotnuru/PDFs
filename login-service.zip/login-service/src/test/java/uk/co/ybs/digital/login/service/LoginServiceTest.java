package uk.co.ybs.digital.login.service;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ldap.support.LdapUtils;
import uk.co.ybs.digital.login.exception.LoginDeniedException;
import uk.co.ybs.digital.login.model.LdapPerson;
import uk.co.ybs.digital.login.service.ValidateLoginService.CustomerInformation;
import uk.co.ybs.digital.login.utils.TestHelper;
import uk.co.ybs.digital.login.web.dto.CustomerDetails;
import uk.co.ybs.digital.login.web.dto.LoginDetails;
import uk.co.ybs.digital.login.web.dto.LoginRequest;
import uk.co.ybs.digital.login.web.dto.LoginResponse;
import uk.co.ybs.digital.login.web.dto.customer.Customer;

@ExtendWith(MockitoExtension.class)
class LoginServiceTest {

  private static final long PARTY_ID = 123456;
  private static final String CUSTOMER_LDAP_PERSON_UID = "0000123456";

  @InjectMocks private LoginService loginService;

  @Mock private ValidateLoginService validateLoginService;

  @Mock private AuditLoginService auditLoginService;

  @Mock private LoginResponseMapper loginResponseMapper;

  @Test
  void shouldLogin() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();

    final Instant loginTime = Instant.parse("2019-04-02T10:21:41.894Z");
    final Instant lastLoginTime = Instant.parse("2019-04-01T23:35:04.329Z");
    final Instant lastLoginTimeTruncated = Instant.parse("2019-04-01T23:35:04Z");

    final Customer customer =
        Customer.builder()
            .partyId(String.valueOf(PARTY_ID))
            .title("Mr")
            .forename("John")
            .surname("Smith")
            .email("john.smith@gmail.com")
            .build();

    final LdapPerson ldapPerson =
        LdapPerson.builder()
            .id(LdapUtils.newLdapName("uid=0000123456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))
            .customerNumber("987654")
            .accessTime(lastLoginTime)
            .uid(CUSTOMER_LDAP_PERSON_UID)
            .groups(Collections.singletonList("direct"))
            .passwordState("PWD_OK")
            .build();

    final CustomerInformation customerInformation = new CustomerInformation(customer, ldapPerson);

    final LoginResponse expectedLoginResponse =
        LoginResponse.builder()
            .customer(
                CustomerDetails.builder()
                    .partyId(PARTY_ID)
                    .forename("John")
                    .surname("Smith")
                    .title("Mr")
                    .email("john.smith@gmail.com")
                    .build())
            .login(
                LoginDetails.builder()
                    .loginTime(loginTime)
                    .lastLoginTime(lastLoginTimeTruncated)
                    .build())
            .build();

    when(validateLoginService.validateLogin(loginRequest, requestMetadata))
        .thenReturn(customerInformation);
    when(auditLoginService.auditLogin(ldapPerson)).thenReturn(loginTime);
    when(loginResponseMapper.map(customer, loginTime, lastLoginTimeTruncated))
        .thenReturn(expectedLoginResponse);

    LoginResponse loginResponse = loginService.login(loginRequest, requestMetadata);
    assertThat(loginResponse, is(expectedLoginResponse));
  }

  @Test
  void shouldNotAuditLoginWhenValidationFails() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginRequest loginRequest = LoginRequest.builder().partyId(PARTY_ID).build();

    when(validateLoginService.validateLogin(loginRequest, requestMetadata))
        .thenThrow(
            new LoginDeniedException(
                LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_CUSTOMER_HUB, ""));
    assertThrows(
        LoginDeniedException.class, () -> loginService.login(loginRequest, requestMetadata));

    verifyNoInteractions(auditLoginService);
  }
}
