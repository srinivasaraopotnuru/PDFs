package uk.co.ybs.digital.login;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.WebTestClientConfigurer;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.server.adapter.WebHttpHandlerBuilder;

/**
 * {@link WebTestClient} doesn't seem to get properly configured with the Spring context {@link
 * ObjectMapper}. Manually do this instead.
 */
@RequiredArgsConstructor
public class ObjectMapperJsonWebTestClientConfigurer implements WebTestClientConfigurer {

  private final ObjectMapper objectMapper;

  @Override
  public void afterConfigurerAdded(
      final WebTestClient.Builder builder,
      final WebHttpHandlerBuilder httpHandlerBuilder,
      final ClientHttpConnector connector) {
    builder.exchangeStrategies(
        ExchangeStrategies.builder()
            .codecs(
                (configurer) -> {
                  configurer
                      .defaultCodecs()
                      .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                  configurer
                      .defaultCodecs()
                      .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                })
            .build());
  }
}
