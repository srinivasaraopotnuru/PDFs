package uk.co.ybs.digital.login.repository;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.ldap.DataLdapTest;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.test.context.junit4.SpringRunner;
import uk.co.ybs.digital.login.model.LdapPerson;

@RunWith(SpringRunner.class)
@DataLdapTest(
    properties = {
      "spring.ldap.urls=",
      "spring.ldap.embedded.base-dn=o=ybs.co.uk,dc=ybs,dc=co,dc=uk",
      "spring.ldap.embedded.ldif=classpath:repository/personRepository.ldif",
      "spring.ldap.embedded.validation.enabled=false"
    })
class LdapPersonRepositoryTest {

  @Autowired private LdapPersonRepository ldapPersonRepository;

  @Test
  void shouldRetrieveLdapPersonForUid() {
    final LdapPerson expected =
        LdapPerson.builder()
            .id(LdapUtils.newLdapName("uid=0000123456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))
            .accessTime(Instant.parse("2019-04-02T10:21:41.894Z"))
            .uid("0000123456")
            .groups(Arrays.asList("eview", "direct"))
            .passwordState("PWD_OK")
            .customerNumber("000987654")
            .build();

    final Optional<LdapPerson> result = ldapPersonRepository.findByUid("0000123456");
    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), is(expected));
  }

  @Test
  void shouldRetrieveLdapPersonForUidInvalidPasswordState() {
    final LdapPerson expected =
        LdapPerson.builder()
            .id(LdapUtils.newLdapName("uid=0000223456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))
            .accessTime(Instant.parse("2019-04-02T10:21:41.894Z"))
            .uid("0000223456")
            .groups(Collections.singletonList("direct"))
            .passwordState("PWD_MANUALCREATE")
            .customerNumber("0000223456")
            .build();

    final Optional<LdapPerson> result = ldapPersonRepository.findByUid("0000223456");
    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), is(expected));
  }

  @Test
  void shouldNotRetrieveLdapPersonForNonExistentUid() {
    final Optional<LdapPerson> result = ldapPersonRepository.findByUid("0000923456");
    assertThat(result.isPresent(), is(false));
  }

  @Test
  void shouldUpdateLdapPersonForUid() {
    final LdapPerson toSave =
        LdapPerson.builder()
            .id(LdapUtils.newLdapName("uid=0000323456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))
            .accessTime(Instant.parse("2019-04-02T10:21:41.894Z"))
            .uid("0000323456")
            .groups(Collections.singletonList("direct"))
            .passwordState("PWD_OK")
            .build();
    ldapPersonRepository.save(toSave);

    final Optional<LdapPerson> result = ldapPersonRepository.findByUid("0000323456");
    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), is(toSave));
  }
}
