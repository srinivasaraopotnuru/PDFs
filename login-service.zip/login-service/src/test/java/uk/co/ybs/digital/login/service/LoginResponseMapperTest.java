package uk.co.ybs.digital.login.service;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.time.Instant;
import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import uk.co.ybs.digital.login.web.dto.CustomerDetails;
import uk.co.ybs.digital.login.web.dto.LoginDetails;
import uk.co.ybs.digital.login.web.dto.LoginResponse;
import uk.co.ybs.digital.login.web.dto.customer.Customer;

class LoginResponseMapperTest {

  @Test
  void shouldMapToLoginResponse() {
    final Customer customer =
        Customer.builder()
            .partyId("123456")
            .title("Mr")
            .forename("John")
            .surname("Smith")
            .title("Mr")
            .email("john.smith@gmail.com")
            .build();

    final Instant loginTime = Instant.parse("2019-04-02T10:21:41.894Z");
    final Instant lastLoginTime = Instant.parse("2019-04-01T23:35:04.329Z");

    final LoginResponse expectedLoginResponse =
        LoginResponse.builder()
            .customer(
                CustomerDetails.builder()
                    .partyId(123456)
                    .forename("John")
                    .surname("Smith")
                    .title("Mr")
                    .email("john.smith@gmail.com")
                    .build())
            .login(
                LoginDetails.builder()
                    .loginTime(Instant.parse("2019-04-02T10:21:41.894Z"))
                    .lastLoginTime(Instant.parse("2019-04-01T23:35:04.329Z"))
                    .build())
            .build();

    final LoginResponseMapper testSubject = Mappers.getMapper(LoginResponseMapper.class);
    final LoginResponse loginResponse = testSubject.map(customer, loginTime, lastLoginTime);
    assertThat(loginResponse, is(expectedLoginResponse));
  }
}
