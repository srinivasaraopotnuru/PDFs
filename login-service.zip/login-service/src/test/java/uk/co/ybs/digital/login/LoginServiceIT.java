package uk.co.ybs.digital.login;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static uk.co.ybs.digital.login.web.dto.ErrorResponse.ErrorItem;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Instant;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.persistence.EntityManager;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.data.ldap.AutoConfigureDataLdap;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.logging.filters.session.SessionIdSourceType;
import uk.co.ybs.digital.login.model.LdapPerson;
import uk.co.ybs.digital.login.model.SecurityHistory;
import uk.co.ybs.digital.login.repository.LdapPersonRepository;
import uk.co.ybs.digital.login.repository.SecurityHistoryRepository;
import uk.co.ybs.digital.login.utils.CustomerServiceRandomPortInitializer;
import uk.co.ybs.digital.login.utils.TestHelper;
import uk.co.ybs.digital.login.web.dto.CustomerDetails;
import uk.co.ybs.digital.login.web.dto.ErrorResponse;
import uk.co.ybs.digital.login.web.dto.LoginRequest;
import uk.co.ybs.digital.login.web.dto.LoginResponse;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class},
    properties = {
      "spring.ldap.urls=",
      "spring.ldap.embedded.base-dn=o=ybs.co.uk,dc=ybs,dc=co,dc=uk",
      "spring.ldap.embedded.ldif=classpath:repository/personRepository.ldif",
      "spring.ldap.embedded.validation.enabled=false"
    })
@AutoConfigureDataLdap
@ContextConfiguration(initializers = CustomerServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
public class LoginServiceIT {

  private static final String BASE_PATH = "/login";
  private static final String PATH_LOGIN = "/login";

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_SESSION_ID = "x-ybs-session-id";

  private static final long PARTY_ID_VALID = 123456;
  private static final long PARTY_ID_VALID_FOR_FAILURE_TESTS = 323456;
  private static final long PARTY_ID_INVALID_PASSWORD_STATE = 223456;
  private static final String CUSTOMER_LDAP_PERSON_UID_VALID = "0000123456";
  private static final String CUSTOMER_LDAP_PERSON_UID_VALID_FOR_FAILURE_TESTS = "0000323456";
  private static final String CUSTOMER_LDAP_PERSON_UID_INVALID_PASSWORD_STATE = "0000223456";
  private static final String APP_CHANNEL = "SAPP";

  private static final String BRAND_CODE_YBS = "YBS";

  private static final String CONTENT_TYPE = "Content-Type";
  private static final String APPLICATION_JSON = "application/json";
  private static final String LOCAL_HOST = "localhost";

  @LocalServerPort private int port;

  @Autowired private WebTestClient signingWebTestClient;

  @Value("${uk.co.ybs.digital.customer-test-port}")
  private int mockCustomerServicePort;

  private MockWebServer mockCustomerService;

  @Autowired private TransactionTemplate transactionTemplate;

  @Autowired private EntityManager entityManager;

  @Autowired private LdapPersonRepository ldapPersonRepository;

  @Autowired private SecurityHistoryRepository securityHistoryRepository;

  @BeforeEach
  void setUp() throws Exception {
    mockCustomerService = new MockWebServer();
    mockCustomerService.start(mockCustomerServicePort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockCustomerService.shutdown();
    tearDownDb();
  }

  @Test
  void shouldLogin() throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final UUID sessionId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest(PARTY_ID_VALID);

    mockCustomerService.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(readClassPathResource("api/customer/CustomerResponse.json")));

    signingWebTestClient
        .post()
        .uri(getURI(PATH_LOGIN))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCAL_HOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SESSION_ID, sessionId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(LoginResponse.class)
        .value(
            loginResponse -> {
              assertThat(
                  loginResponse.getCustomer(),
                  is(
                      CustomerDetails.builder()
                          .partyId(PARTY_ID_VALID)
                          .forename("John")
                          .surname("Smith")
                          .title("Mr")
                          .email("john.smith@gmail.com")
                          .build()));
              assertThat(loginResponse.getLogin().getLoginTime(), notNullValue());
              assertThat(
                  loginResponse.getLogin().getLastLoginTime(),
                  is(Instant.parse("2019-04-02T10:21:41Z")));
            });

    final RecordedRequest recordedRequest = mockCustomerService.takeRequest();
    assertThat(recordedRequest.getPath(), is("/customer/customer/" + PARTY_ID_VALID));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST), is("localhost:" + mockCustomerServicePort));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is("*/*"));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(recordedRequest.getHeader("x-ybs-request-signature"), notNullValue());
    assertThat(
        recordedRequest.getHeader("x-ybs-request-signature-key-id"), is("login-service-nonprod-1"));

    final Optional<LdapPerson> ldapPerson =
        ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID_VALID);
    assertThat(ldapPerson.isPresent(), is(true));
    assertThat(ldapPerson.get().getAccessTime(), is(not(Instant.parse("2019-04-02T10:21:41Z"))));

    final List<SecurityHistory> all = securityHistoryRepository.findAll();
    assertThat(all, hasSize(1));
    assertThat(all.get(0).getEventTime(), is(notNullValue()));
    assertThat(all.get(0).getCode(), is("LO"));
    assertThat(all.get(0).getUserId(), is(CUSTOMER_LDAP_PERSON_UID_VALID));
    assertThat(all.get(0).getOperatorId(), is(CUSTOMER_LDAP_PERSON_UID_VALID));
    assertThat(all.get(0).getChannel(), is(APP_CHANNEL));
  }

  @Test
  void shouldRejectLoginWhenCustomerDeceased() throws IOException {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest(PARTY_ID_VALID_FOR_FAILURE_TESTS);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorItem.builder()
                    .errorCode("AccessDenied.LoginDenied.CustomerDeceased")
                    .message("Customer is deceased")
                    .build())
            .build();

    mockCustomerService.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(readClassPathResource("api/customer/CustomerResponseDeceased.json")));

    signingWebTestClient
        .post()
        .uri(getURI(PATH_LOGIN))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCAL_HOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    final Optional<LdapPerson> ldapPerson =
        ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID_VALID_FOR_FAILURE_TESTS);
    assertThat(ldapPerson.isPresent(), is(true));
    assertThat(ldapPerson.get().getAccessTime(), is(Instant.parse("2019-04-01T23:35:04Z")));

    final List<SecurityHistory> all = securityHistoryRepository.findAll();
    assertThat(all, empty());
  }

  @Test
  void shouldReturnInternalServerErrorWhenWhenCustomerServiceReturnsUnexpectedError()
      throws IOException {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest(PARTY_ID_VALID_FOR_FAILURE_TESTS);

    final ErrorResponse expectedResponse =
        TestHelper.buildErrorResponseInternalServerError(requestId);

    mockCustomerService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.FORBIDDEN.value())
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(
                readClassPathResource(
                    "api/customer/ResponseErrorAccessDeniedInvalidRequestSignature.json")));

    signingWebTestClient
        .post()
        .uri(getURI(PATH_LOGIN))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCAL_HOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    final Optional<LdapPerson> ldapPerson =
        ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID_VALID_FOR_FAILURE_TESTS);
    assertThat(ldapPerson.isPresent(), is(true));
    assertThat(ldapPerson.get().getAccessTime(), is(Instant.parse("2019-04-01T23:35:04Z")));

    final List<SecurityHistory> all = securityHistoryRepository.findAll();
    assertThat(all, empty());
  }

  @Test
  void shouldRejectLoginWhenInvalidPasswordState() throws IOException {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest(PARTY_ID_INVALID_PASSWORD_STATE);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorItem.builder()
                    .errorCode("AccessDenied.LoginDenied.CustomerInvalidPasswordState")
                    .message("Customer has an invalid password state")
                    .build())
            .build();

    mockCustomerService.enqueue(
        new MockResponse()
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(readClassPathResource("api/customer/CustomerResponse.json")));

    signingWebTestClient
        .post()
        .uri(getURI(PATH_LOGIN))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCAL_HOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    final Optional<LdapPerson> ldapPerson =
        ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID_INVALID_PASSWORD_STATE);
    assertThat(ldapPerson.isPresent(), is(true));
    assertThat(ldapPerson.get().getAccessTime(), is(Instant.parse("2019-04-02T10:21:41Z")));

    final List<SecurityHistory> all = securityHistoryRepository.findAll();
    assertThat(all, empty());
  }

  @Test
  void shouldReturnForbiddenWhenSignatureIsInvalid() {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest(PARTY_ID_VALID);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message("Access Denied")
                    .build())
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_LOGIN))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCAL_HOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header("x-ybs-request-signature-key-id", "FKbfNeQxsVQL5CwAJKP0q5fWOVe9ukn1K0lw")
        .header("x-ybs-request-signature", "invalid-signature")
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturnBadRequestWhenSessionIdIsInvalid() {
    final UUID requestId = UUID.randomUUID();
    final String sessionId = "invalid_session_id";
    final LoginRequest request = buildLoginRequest(PARTY_ID_VALID);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("400 Bad Request")
            .message("Bad Request")
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("Header.Invalid")
                        .message("SessionId is not a valid UUID")
                        .path(SessionIdSourceType.HEADER.toString())
                        .build()))
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_LOGIN))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCAL_HOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SESSION_ID, sessionId)
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  private LoginRequest buildLoginRequest(final Long partyId) {
    return LoginRequest.builder().partyId(partyId).brandCode(BRAND_CODE_YBS).build();
  }

  private void tearDownDb() {
    transactionTemplate.execute(
        status -> entityManager.createQuery("delete from SecurityHistory").executeUpdate());
  }

  private URI getURI(final String path) {
    return URI.create("http://localhost:" + port + BASE_PATH + path);
  }

  private String readClassPathResource(final ClassPathResource classPathResource)
      throws IOException {
    return new String(
        Files.readAllBytes(classPathResource.getFile().toPath()), StandardCharsets.UTF_8);
  }

  private String readClassPathResource(final String classPathResource) throws IOException {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }
}
