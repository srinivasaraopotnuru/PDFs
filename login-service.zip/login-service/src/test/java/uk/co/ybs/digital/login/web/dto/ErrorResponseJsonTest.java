package uk.co.ybs.digital.login.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.google.common.collect.ImmutableList;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class ErrorResponseJsonTest {

  @Autowired private JacksonTester<ErrorResponse> json;

  @Value("classpath:api/ErrorResponse.json")
  private Resource file;

  private ErrorResponse fullyPopulated;

  @BeforeEach
  void beforeEach() {
    final UUID requestId = UUID.fromString("564e6e5c-7fac-4c68-b721-4e466645c7e3");

    fullyPopulated =
        ErrorResponse.builder()
            .id(requestId)
            .code("code")
            .message("message")
            .errors(
                ImmutableList.of(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("errorCode0")
                        .message("errorMessage0")
                        .build(),
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("errorCode1")
                        .message("errorMessage1")
                        .build()))
            .build();
  }

  @Test
  void testSerialize() throws Exception {
    assertThat(json.write(fullyPopulated)).isEqualToJson(file, JSONCompareMode.STRICT);
  }

  @Test
  void testDeserialize() throws Exception {
    assertThat(json.read(file)).isEqualTo(fullyPopulated);
  }
}
