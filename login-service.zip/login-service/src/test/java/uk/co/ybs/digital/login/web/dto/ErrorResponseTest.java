package uk.co.ybs.digital.login.web.dto;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static uk.co.ybs.digital.login.web.dto.ErrorResponse.ErrorItem;

import java.util.UUID;
import org.junit.jupiter.api.Test;

class ErrorResponseTest {

  private static final String CODE = "code";
  private static final String MESSAGE = "message";
  private static final String ABC = "abc";

  @Test
  void containsOnlyErrorCodeShouldReturnTrueIfOnlyErrorItemMatches() {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(CODE)
            .message(MESSAGE)
            .error(ErrorItem.builder().errorCode(ABC).message(MESSAGE).build())
            .build();

    assertThat(errorResponse.containsOnlyErrorCode(ABC), is(true));
  }

  @Test
  void containsOnlyErrorCodeShouldReturnFalseIfOnlyErrorItemMismatches() {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(CODE)
            .message(MESSAGE)
            .error(ErrorItem.builder().errorCode("xyz").message(MESSAGE).build())
            .build();

    assertThat(errorResponse.containsOnlyErrorCode(ABC), is(false));
  }

  @Test
  void containsOnlyErrorCodeShouldReturnFalseForNoErrorItems() {
    final ErrorResponse errorResponse =
        ErrorResponse.builder().id(UUID.randomUUID()).code(CODE).message(MESSAGE).build();

    assertThat(errorResponse.containsOnlyErrorCode(ABC), is(false));
  }

  @Test
  void containsOnlyErrorCodeShouldReturnFalseForMultipleMatchingErrorItems() {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(CODE)
            .message(MESSAGE)
            .error(ErrorItem.builder().errorCode(ABC).message(MESSAGE).build())
            .error(ErrorItem.builder().errorCode(ABC).message(MESSAGE).build())
            .build();

    assertThat(errorResponse.containsOnlyErrorCode(ABC), is(false));
  }
}
