package uk.co.ybs.digital.login.utils;

import java.util.UUID;
import uk.co.ybs.digital.login.service.RequestMetadata;
import uk.co.ybs.digital.login.web.dto.ErrorResponse;
import uk.co.ybs.digital.login.web.dto.ErrorResponse.ErrorItem;

public final class TestHelper {

  private TestHelper() {}

  public static RequestMetadata buildRequestMetadata(final UUID requestId) {
    return RequestMetadata.builder().requestId(requestId).brandCode("YBS").build();
  }

  public static ErrorResponse buildErrorResponseInternalServerError(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("500 Internal Server Error")
        .message("Internal Server Error")
        .error(
            ErrorItem.builder()
                .errorCode("UnexpectedError")
                .message("Internal Server Error")
                .build())
        .build();
  }
}
