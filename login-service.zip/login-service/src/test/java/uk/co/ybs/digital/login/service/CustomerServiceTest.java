package uk.co.ybs.digital.login.service;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.reactive.function.client.ClientHttpConnectorAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.login.config.CustomerServiceConfig;
import uk.co.ybs.digital.login.exception.CustomerNotFoundException;
import uk.co.ybs.digital.login.exception.CustomerServiceException;
import uk.co.ybs.digital.login.utils.CustomerServiceRandomPortInitializer;
import uk.co.ybs.digital.login.utils.TestHelper;
import uk.co.ybs.digital.login.web.dto.customer.Customer;
import uk.co.ybs.digital.security.requestsigning.RequestSigningAutoConfiguration;

@SpringBootTest(
    classes = {
      CustomerService.class,
      CustomerServiceConfig.class,
      RequestSigningAutoConfiguration.class,
      ClientHttpConnectorAutoConfiguration
          .class // Required by the WebClient bean defined in AccountServiceConfig
    },
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = CustomerServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class CustomerServiceTest {

  private static final long PARTY_ID = 123456;

  @Autowired private CustomerService customerService;

  @Value("${uk.co.ybs.digital.customer-test-port}")
  private int mockCustomerServicePort;

  private MockWebServer mockCustomerService;

  @BeforeEach
  void setUp() throws IOException {
    mockCustomerService = new MockWebServer();
    mockCustomerService.start(mockCustomerServicePort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockCustomerService.shutdown();
  }

  private static final String CONTENT_TYPE = "Content-Type";
  private static final String APPLICATION_JSON = "application/json";

  @Test
  void shouldGetCustomer() throws IOException, InterruptedException {
    final String body = readClassPathResource("api/customer/CustomerResponseDeceased.json");
    mockCustomerService.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(requestId);
    final Customer customer = customerService.getCustomer(PARTY_ID, requestMetadata);
    assertThat(
        customer,
        is(
            Customer.builder()
                .partyId("123456")
                .title("Mr")
                .forename("John")
                .surname("Smith")
                .deceasedDate(LocalDate.of(2019, 12, 4))
                .build()));

    final RecordedRequest recordedRequest = mockCustomerService.takeRequest();
    assertThat(recordedRequest.getMethod(), is(("GET")));
    assertThat(recordedRequest.getPath(), is(("/customer/customer/" + PARTY_ID)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST), is("localhost:" + mockCustomerServicePort));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is("*/*"));
    assertThat(recordedRequest.getHeader("x-ybs-request-id"), is(requestId.toString()));
    assertThat(recordedRequest.getHeader("x-ybs-request-signature"), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader("x-ybs-request-signature-key-id"), is("login-service-nonprod-1"));
  }

  @Test
  void shouldThrowDecodingExceptionForInvalidJson() {
    final String body = "abc";
    mockCustomerService.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(UUID.randomUUID());
    assertThrows(
        org.springframework.core.codec.DecodingException.class,
        () -> customerService.getCustomer(PARTY_ID, requestMetadata));
  }

  @Test
  void shouldThrowCustomerServiceExceptionForEmptyResponse() {
    final String body = "";
    mockCustomerService.enqueue(
        new MockResponse().setHeader(CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(UUID.randomUUID());
    final CustomerServiceException exception =
        assertThrows(
            CustomerServiceException.class,
            () -> customerService.getCustomer(PARTY_ID, requestMetadata));
    assertThat(exception.getMessage(), equalTo("Empty response calling customer service"));
  }

  @Test
  void shouldThrowCustomerServiceExceptionForConnectionError() throws IOException {
    mockCustomerService.shutdown();

    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(UUID.randomUUID());
    final CustomerServiceException exception =
        assertThrows(
            CustomerServiceException.class,
            () -> customerService.getCustomer(PARTY_ID, requestMetadata));
    assertThat(exception.getMessage(), is("Error calling customer service"));
  }

  @Test
  void shouldThrowCustomerNotFoundExceptionForHttpStatus404AndErrorCodeNotFound()
      throws IOException {
    final String body = readClassPathResource("api/customer/ResponseErrorResourceNotFound.json");
    mockCustomerService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.NOT_FOUND.value())
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(body));

    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(UUID.randomUUID());
    final CustomerNotFoundException exception =
        assertThrows(
            CustomerNotFoundException.class,
            () -> customerService.getCustomer(PARTY_ID, requestMetadata));
    assertThat(exception.getMessage(), is("Customer " + PARTY_ID + " not found"));
  }

  @ParameterizedTest
  @MethodSource("unexpectedHttpStatusesAndBodies")
  void shouldThrowCustomerServiceExceptionForUnexpectedHttpStatusAndBody(
      final HttpStatus httpStatus, final ClassPathResource bodyResource) throws IOException {
    final String body = readClassPathResource(bodyResource);
    mockCustomerService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(CONTENT_TYPE, APPLICATION_JSON)
            .setBody(body));

    final RequestMetadata requestMetadata = TestHelper.buildRequestMetadata(UUID.randomUUID());
    final CustomerServiceException exception =
        assertThrows(
            CustomerServiceException.class,
            () -> customerService.getCustomer(PARTY_ID, requestMetadata));
    assertThat(
        exception.getClass(), is(CustomerServiceException.class)); // Expect not a sub-class here
    assertThat(exception.getMessage(), is("Error calling customer service: " + httpStatus));
  }

  private static Stream<Arguments> unexpectedHttpStatusesAndBodies() {
    return Stream.of(
        // Unexpected response code with expected body
        Arguments.of(
            HttpStatus.FORBIDDEN,
            new ClassPathResource("api/customer/ResponseErrorResourceNotFound.json")),
        // Expected response code with unexpected body
        Arguments.of(
            HttpStatus.NOT_FOUND,
            new ClassPathResource("api/customer/ResponseErrorResourceNotFoundWithAdditional.json")),
        Arguments.of(
            HttpStatus.NOT_FOUND,
            new ClassPathResource(
                "api/customer/ResponseErrorAccessDeniedInvalidRequestSignature.json")));
  }

  private String readClassPathResource(final ClassPathResource classPathResource)
      throws IOException {
    return new String(
        Files.readAllBytes(classPathResource.getFile().toPath()), StandardCharsets.UTF_8);
  }

  private String readClassPathResource(final String classPathResource) throws IOException {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }
}
