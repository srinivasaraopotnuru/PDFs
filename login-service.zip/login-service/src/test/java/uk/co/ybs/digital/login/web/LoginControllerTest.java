package uk.co.ybs.digital.login.web;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static uk.co.ybs.digital.login.web.dto.ErrorResponse.ErrorItem;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.Instant;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.login.exception.LoginDeniedException;
import uk.co.ybs.digital.login.exception.LoginServiceException;
import uk.co.ybs.digital.login.service.LoginService;
import uk.co.ybs.digital.login.service.RequestMetadata;
import uk.co.ybs.digital.login.utils.TestHelper;
import uk.co.ybs.digital.login.web.dto.CustomerDetails;
import uk.co.ybs.digital.login.web.dto.ErrorResponse;
import uk.co.ybs.digital.login.web.dto.LoginDetails;
import uk.co.ybs.digital.login.web.dto.LoginRequest;
import uk.co.ybs.digital.login.web.dto.LoginResponse;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(controllers = LoginController.class)
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter
  RequestVerificationSecurityAutoConfiguration.class, // Signature verification
  FilterErrorResponseFactory.class,
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class // Metrics
})
@ActiveProfiles({"test", "text-logging"})
class LoginControllerTest {

  private static final String PATH_LOGIN = "/login";
  private static final String HOST_HEADER_VALUE = "loginservice.ybs.co.uk:443";

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_SESSION_ID = "x-ybs-session-id";

  private static final long PARTY_ID = 123456;
  private static final String BRAND_CODE_YBS = "YBS";

  @Autowired private MockMvc mockMvc;

  @Autowired private ObjectMapper objectMapper;

  @MockBean private RequestSigningVerificationService requestSigningVerificationService;

  @MockBean private LoginService loginService;

  @BeforeEach
  void beforeEach() {
    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
  }

  @Test
  void shouldLogin() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final UUID sessionId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest();

    final RequestMetadata expectedRequestMetadata = TestHelper.buildRequestMetadata(requestId);
    final LoginResponse expectedResponse =
        LoginResponse.builder()
            .customer(
                CustomerDetails.builder()
                    .partyId(123456)
                    .forename("John")
                    .surname("Smith")
                    .title("Mr")
                    .email("john.smith@gmail.com")
                    .build())
            .login(
                LoginDetails.builder()
                    .loginTime(Instant.parse("2019-04-02T10:21:41.894Z"))
                    .lastLoginTime(Instant.parse("2019-04-01T23:35:04.329Z"))
                    .build())
            .build();

    when(loginService.login(request, expectedRequestMetadata)).thenReturn(expectedResponse);

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_SESSION_ID, sessionId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @ParameterizedTest
  @MethodSource("loginDeniedExceptionReasons")
  void shouldReturnForbiddenIfLoginDeniedExceptionThrown(
      final LoginDeniedException.Reason reason,
      final String errorItemErrorCode,
      final String errorItemMessage)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorItem.builder().errorCode(errorItemErrorCode).message(errorItemMessage).build())
            .build();

    doThrow(new LoginDeniedException(reason, "")).when(loginService).login(any(), any());

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  private static Stream<Arguments> loginDeniedExceptionReasons() {
    return Stream.of(
        Arguments.of(
            LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_CUSTOMER_HUB,
            "AccessDenied.LoginDenied.CustomerNotFoundCustomerHub",
            "Customer was not found on Customer Hub"),
        Arguments.of(
            LoginDeniedException.Reason.CUSTOMER_NOT_FOUND_LDAP,
            "AccessDenied.LoginDenied.CustomerNotFoundLdap",
            "Customer was not found on LDAP"),
        Arguments.of(
            LoginDeniedException.Reason.CUSTOMER_DECEASED,
            "AccessDenied.LoginDenied.CustomerDeceased",
            "Customer is deceased"),
        Arguments.of(
            LoginDeniedException.Reason.CUSTOMER_INVALID_GROUP,
            "AccessDenied.LoginDenied.CustomerInvalidGroup",
            "Customer has an invalid group"),
        Arguments.of(
            LoginDeniedException.Reason.CUSTOMER_INVALID_PASSWORD_STATE,
            "AccessDenied.LoginDenied.CustomerInvalidPasswordState",
            "Customer has an invalid password state"));
  }

  @Test
  void shouldReturnInternalServerErrorIfLoginServiceExceptionThrown() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest();

    final ErrorResponse errorResponse = TestHelper.buildErrorResponseInternalServerError(requestId);

    doThrow(new LoginServiceException("")).when(loginService).login(any(), any());

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void shouldReturnBadRequestIfRequestIsNotJson() throws Exception {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse errorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Unable to parse request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Resource.InvalidFormat")
                    .message(
                        "An unexpected error occurred when attempting to parse the request body")
                    .build())
            .build();

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content("abc"))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));

    verifyNoInteractions(loginService);
  }

  @Test
  void shouldReturnBadRequestIfRequestDoesNotContainAPartyId() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest().toBuilder().partyId(null).build();

    final ErrorResponse errorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify a party id")
                    .build())
            .build();

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));

    verifyNoInteractions(loginService);
  }

  @Test
  void shouldReturnBadRequestIfRequestDoesNotContainABrandCode() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest().toBuilder().brandCode(null).build();

    final ErrorResponse errorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify a brand code")
                    .build())
            .build();

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));

    verifyNoInteractions(loginService);
  }

  @ParameterizedTest
  @ValueSource(longs = {-1, 0})
  void shouldReturnBadRequestIfRequestContainsANonPositivePartyId(final long partyId)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest().toBuilder().partyId(partyId).build();

    final ErrorResponse errorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message(partyId + " is not a valid party id; value must be positive")
                    .build())
            .build();

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));

    verifyNoInteractions(loginService);
  }

  @Test
  void shouldReturnMethodNotSupportedIfMethodNotSupported() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("405 Method Not Allowed")
            .id(requestId)
            .message("Method Not Allowed")
            .error(
                ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method")
                    .build())
            .build();

    mockMvc
        .perform(
            get(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.POST.name())));

    verifyNoInteractions(loginService);
  }

  @Test
  void shouldReturnMethodNotSupportedIfMediaTypeNotSupported() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("415 Unsupported Media Type")
            .id(requestId)
            .message("Unsupported Media Type")
            .error(
                ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("Content-Type header is invalid")
                    .path("Content-Type")
                    .build())
            .build();

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.TEXT_PLAIN)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isUnsupportedMediaType())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ACCEPT, is(MediaType.APPLICATION_JSON_VALUE)));

    verifyNoInteractions(loginService);
  }

  @Test
  void shouldIncludeResponseBodyIfUnexpectedSpringInternalExceptionThrown() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final LoginRequest request = buildLoginRequest();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException()).when(loginService).login(any(), any());

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void shouldReturnBadRequestIfRequestIdIsNotAUUID() throws Exception {
    final String requestId = "not-a-uuid";
    final LoginRequest request = buildLoginRequest();

    mockMvc
        .perform(
            post(PATH_LOGIN)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            jsonPath("$.id", notNullValue())) // Will be a different value to what we specified
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(HEADER_REQUEST_ID)));

    verifyNoInteractions(loginService);
  }

  private LoginRequest buildLoginRequest() {
    return LoginRequest.builder().partyId(PARTY_ID).brandCode(BRAND_CODE_YBS).build();
  }
}
