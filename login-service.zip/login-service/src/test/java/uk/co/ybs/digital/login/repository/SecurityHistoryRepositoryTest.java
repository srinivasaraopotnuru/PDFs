package uk.co.ybs.digital.login.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import uk.co.ybs.digital.login.model.SecurityHistory;

@DataJpaTest
class SecurityHistoryRepositoryTest {

  @Autowired private SecurityHistoryRepository securityHistoryRepository;

  @Test
  void shouldSave() {
    SecurityHistory securityHistory =
        SecurityHistory.builder()
            .eventTime(LocalDateTime.now())
            .code("LO")
            .userId("0000123456")
            .operatorId("0000123456")
            .channel("SAPP")
            .build();
    securityHistoryRepository.save(securityHistory);

    assertThat(
        securityHistoryRepository.findById(securityHistory.getSysId()).get(), is(securityHistory));
  }
}
