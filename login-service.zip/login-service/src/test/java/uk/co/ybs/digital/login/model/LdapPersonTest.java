package uk.co.ybs.digital.login.model;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.Test;

class LdapPersonTest {

  @Test
  void shouldCheckGroupDirect() {
    LdapPerson person = LdapPerson.builder().groups(Arrays.asList("direct", "eview")).build();
    assertThat(person.isInDirectGroup(), is(true));
  }

  @Test
  void shouldCheckGroupOther() {
    LdapPerson person = LdapPerson.builder().groups(Arrays.asList("admin", "eview")).build();
    assertThat(person.isInDirectGroup(), is(false));
  }

  @Test
  void shouldCheckNoGroups() {
    LdapPerson person = LdapPerson.builder().groups(Collections.emptyList()).build();
    assertThat(person.isInDirectGroup(), is(false));
  }

  @Test
  void shouldCheckPasswordStateOk() {
    LdapPerson person = LdapPerson.builder().passwordState("PWD_OK").build();
    assertThat(person.isPasswordStateOk(), is(true));
  }

  @Test
  void shouldCheckPasswordStateOther() {
    LdapPerson person = LdapPerson.builder().passwordState("PWD_MANUALCREATE").build();
    assertThat(person.isPasswordStateOk(), is(false));
  }

  @Test
  void shouldGetAccessTime() {
    LdapPerson person =
        LdapPerson.builder()
            .accessTimeEpochSecond(Instant.parse("2019-04-02T10:21:41.894Z").getEpochSecond())
            .build();
    assertThat(person.getAccessTime(), is(Instant.parse("2019-04-02T10:21:41Z")));
  }

  @Test
  void shouldSetAccessTime() {
    LdapPerson person =
        LdapPerson.builder().accessTime(Instant.parse("2019-04-02T10:21:41.894Z")).build();
    assertThat(
        person.getAccessTimeEpochSecond(),
        is(Instant.parse("2019-04-02T10:21:41Z").getEpochSecond()));
  }
}
