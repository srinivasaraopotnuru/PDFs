package uk.co.ybs.digital.login.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ldap.support.LdapUtils;
import uk.co.ybs.digital.login.model.LdapPerson;
import uk.co.ybs.digital.login.model.SecurityHistory;
import uk.co.ybs.digital.login.repository.LdapPersonRepository;
import uk.co.ybs.digital.login.repository.SecurityHistoryRepository;

@ExtendWith(MockitoExtension.class)
class AuditLoginServiceTest {

  private static final String CUSTOMER_LDAP_PERSON_UID = "0000123456";
  private static final String APP_CHANNEL = "SAPP";

  @Mock private LdapPersonRepository ldapPersonRepository;

  @Mock private SecurityHistoryRepository securityHistoryRepository;

  @Test
  void shouldAuditLoginBst() {
    final Clock clock =
        Clock.fixed(Instant.parse("2019-04-02T10:21:41.894Z"), ZoneId.of("Europe/London"));
    final AuditLoginService auditLoginService =
        new AuditLoginService(ldapPersonRepository, securityHistoryRepository, clock);

    final LdapPerson ldapPerson = buildLdapPerson(Instant.parse("2019-04-01T23:35:04.329Z"));
    final LdapPerson expectedSavedLdapPerson =
        buildLdapPerson(Instant.parse("2019-04-02T10:21:41.894Z"));
    final SecurityHistory expectedSavedSecurityHistory =
        buildSecurityHistory(
            LocalDateTime.of(
                2019, 4, 2, 11, 21, 41, 894000000)); // 2019-04-02T11:21:41.894Z (in BST)

    final Instant loginTime = auditLoginService.auditLogin(ldapPerson);
    assertThat(loginTime, is(Instant.parse("2019-04-02T10:21:41.894Z")));

    verify(ldapPersonRepository).save(expectedSavedLdapPerson);
    verify(securityHistoryRepository).save(expectedSavedSecurityHistory);
  }

  @Test
  void shouldAuditLoginGmt() {
    final Clock clock =
        Clock.fixed(Instant.parse("2019-02-02T10:21:41.894Z"), ZoneId.of("Europe/London"));
    final AuditLoginService auditLoginService =
        new AuditLoginService(ldapPersonRepository, securityHistoryRepository, clock);

    final LdapPerson ldapPerson = buildLdapPerson(Instant.parse("2019-02-01T23:35:04.329Z"));
    final LdapPerson expectedSavedLdapPerson =
        buildLdapPerson(Instant.parse("2019-02-02T10:21:41.894Z"));
    final SecurityHistory expectedSavedSecurityHistory =
        buildSecurityHistory(
            LocalDateTime.of(
                2019, 2, 2, 10, 21, 41, 894000000)); // 2019-02-02T10:21:41.894Z (in GMT))

    final Instant loginTime = auditLoginService.auditLogin(ldapPerson);
    assertThat(loginTime, is(Instant.parse("2019-02-02T10:21:41.894Z")));

    verify(ldapPersonRepository).save(expectedSavedLdapPerson);
    verify(securityHistoryRepository).save(expectedSavedSecurityHistory);
  }

  private LdapPerson buildLdapPerson(final Instant accessTime) {
    return LdapPerson.builder()
        .id(LdapUtils.newLdapName("uid=0000123456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))
        .accessTime(accessTime)
        .uid(CUSTOMER_LDAP_PERSON_UID)
        .groups(Collections.singletonList("direct"))
        .passwordState("PWD_OK")
        .build();
  }

  private SecurityHistory buildSecurityHistory(final LocalDateTime eventTime) {
    return SecurityHistory.builder()
        .eventTime(eventTime)
        .code(SecurityHistory.CODE_LOGIN_OK)
        .userId(CUSTOMER_LDAP_PERSON_UID)
        .operatorId(CUSTOMER_LDAP_PERSON_UID)
        .channel(APP_CHANNEL)
        .build();
  }
}
