drop table if exists E_SECURITY_HISTORY;
create table E_SECURITY_HISTORY
(
	SYSID NUMBER(10) not null
		constraint ESH_PK
			primary key,
	EVENT_TIME TIMESTAMP(6) not null,
	HISTORY_CODE VARCHAR2(3) not null,
	USERID VARCHAR2(10) not null,
	OPERATOR_ID VARCHAR2(10),
	OTHER_CHANNEL_CODE VARCHAR2(6),
	constraint ESH_UK
		unique (EVENT_TIME, USERID)
);

comment on column E_SECURITY_HISTORY.USERID is 'the user logon id';

create index ESH_OPT1
	on E_SECURITY_HISTORY (USERID);

drop sequence if exists ESH_SYSID_SEQ;
create sequence ESH_SYSID_SEQ
	nocache;
