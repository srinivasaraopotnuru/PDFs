#!/usr/bin/env bash
set -eo pipefail

. "$(dirname "$0")"/../os/login.sh
. "$(dirname "$0")"/../os/apply-config.sh
. "$(dirname "$0")"/../os/deploy.sh
