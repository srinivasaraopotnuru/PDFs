#!/usr/bin/env sh

set -e

##If DOCKER_REGISTRY_PUSH is not defined, use DOCKER_REGISTRY
if [ "$DOCKER_REGISTRY_PUSH" == "" ]; then
  DOCKER_REGISTRY_PUSH="$DOCKER_REGISTRY"
fi

echo ""
echo "Logging in with username: "$ARTIFACTORY_USERNAME
docker login -u "$ARTIFACTORY_USERNAME" -p "$ARTIFACTORY_PASSWORD" $DOCKER_REGISTRY
echo ""

IMAGE_NAME=$DOCKER_REGISTRY_PUSH/$DOCKER_NAME
APP_PATH=.
if [ "" != "$APPLICATION" ]; then
    APP_PATH=$APPLICATION
fi

echo ""
echo "Building image: "$IMAGE_NAME:$VERSION
echo ""

#DO NOT EVER USE AUTH HERE!
HTTP_PROXY=http://172.17.0.1:3128/

docker build \
    --file $APP_PATH/Dockerfile \
    --tag $IMAGE_NAME:$VERSION \
    --build-arg http_proxy=$HTTP_PROXY \
    --build-arg https_proxy=$HTTP_PROXY \
    $DOCKER_PARAMS \
    .
