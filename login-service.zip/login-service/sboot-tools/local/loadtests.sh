#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
echo pwd=`pwd`
pushd $gwd

pipenv run locust --locustfile=$gwd/loadtests/locustfile.py
popd