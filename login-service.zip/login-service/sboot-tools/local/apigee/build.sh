#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
. "$gwd/sboot-tools/local/gradle-env.sh"
echo pwd=`pwd`

export ARTIFACTORY_USERNAME=$AD_USERNAME
export ARTIFACTORY_PASSWORD=`echo -n $AD_PASSWORD_B64 | base64 --decode`

##Show the gradle versions
$gwd/sboot-tools/apigee/gradle/gradlew -v

##Run Gradle Build
$gwd/sboot-tools/apigee/gradle/gradlew assemble $@

##Clean up env vars
export ARTIFACTORY_USERNAME=
export ARTIFACTORY_PASSWORD=
