#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
. "$gwd/sboot-tools/local/gradle-env.sh"
echo pwd=`pwd`

if [ "" == "$AD_USERNAME" ]; then
  echo "INFO: Run: \`. ./sboot-tools/set-env.sh\` to persist env vars in this shell"
  . $gwd/sboot-tools/set-env.sh
fi
export ARTIFACTORY_USERNAME=$AD_USERNAME
export ARTIFACTORY_PASSWORD=`echo -n $AD_PASSWORD_B64 | base64 --decode`

export VERSION=`$gwd/sboot-tools/gradle/gradlew --quiet printVersion`
echo VERSION=$VERSION
##Run Gradle Build
$gwd/sboot-tools/gradle/gradlew build -x check $@
if [ ! -d build ]; then
    mkdir build
fi
echo $VERSION > build/version.txt

##Clean up env vars
export ARTIFACTORY_USERNAME=
export ARTIFACTORY_PASSWORD=
