#!/usr/bin/env bash
gwd=$(git rev-parse --show-toplevel)
export gwd
#echo $gwd

if [ "" == "$AD_USERNAME" ]; then
  echo "INFO: Run: \`. ./sboot-tools/set-env.sh\` to persist env vars in this shell"
  . $gwd/sboot-tools/set-env.sh
fi

VERSION=$(cat "$gwd/build/version.txt")
export VERSION

mkdir -p "$gwd/target/dependency"
unzip -oq "$gwd/$SERVICE_DIR/build/libs/*.jar" -d "$gwd/target/dependency"
##If DOCKER_REGISTRY_PUSH is not defined, use DOCKER_REGISTRY
if [ "$DOCKER_REGISTRY_PUSH" == "" ]; then
  DOCKER_REGISTRY_PUSH="$DOCKER_REGISTRY"
fi

##Dockerize
echo "Logging in to $DOCKER_REGISTRY as $AD_USERNAME (for pull)"
echo -n "$AD_PASSWORD_B64" | base64 --decode | docker login -u "$AD_USERNAME" --password-stdin "$DOCKER_REGISTRY"
echo "Logging in to $DOCKER_REGISTRY_PUSH as $AD_USERNAME (for push)"
echo -n "$AD_PASSWORD_B64" | base64 --decode | docker login -u "$AD_USERNAME" --password-stdin "$DOCKER_REGISTRY_PUSH"
docker build -t "$DOCKER_REGISTRY_PUSH/$DOCKER_NAME:$VERSION" .

DNS_SERVERS="--dns 10.70.69.10 --dns 10.4.44.103 --dns 10.34.2.116 --dns 10.0.0.1"
echo "To push, use the following command:"
echo "docker push $DOCKER_REGISTRY_PUSH/$DOCKER_NAME:$VERSION"
echo "To run, use the following command:"
echo "docker run -it $DNS_SERVERS -m 512M -p 8080:8080 -p 8083:8083 $DOCKER_REGISTRY_PUSH/$DOCKER_NAME:$VERSION"
echo "To run, with env vars, use the following command:"
#echo "docker run -m 512M -p 8080:8080 --env-file ./services/dev.env $DOCKER_REGISTRY/$DOCKER_NAME:$VERSION"
if [ -f $gwd/services/dev.env ]; then
  ENVS=$(cat "$gwd/services/dev.env" | sed -n '/^[^\t]/s/=[[:alnum:]"/*].*//p' | sed '/^$/d' | sed 's/^/-e /g' | tr '\n' ' ')
  echo "docker run -it $DNS_SERVERS -m 512M -p 8080:8080 -p 8083:8083 $ENVS $DOCKER_REGISTRY_PUSH/$DOCKER_NAME:$VERSION"
fi
