#!/bin/bash
export gwd=`git rev-parse --show-toplevel`
export MAVEN_OPTS="-Djavax.net.ssl.trustStore=$gwd/sboot-tools/certs/cacerts.jks \
-Djavax.net.ssl.trustStorePassword=changeit \
-Dhttp.proxyHost=ybsproxyvip \
-Dhttps.proxyHost=ybsproxyvip \
-Dhttp.proxyPort=80 \
-Dhttps.proxyPort=80"
export MAVEN_USER_HOME="$gwd/.mvn"
