#!/usr/bin/env bash
set -e

# Get a GITLAB_TOKEN token and export to GITLAB_TOKEN before running this script
if [ "$GITLAB_TOKEN" = "" ]; then
  echo "Please export your GitLab API token as GITLAB_TOKEN" >&2
  exit
fi
mkdir -p target

# Source the gitlab utils
. $(dirname "$0")/gitlab-utils.sh
GetAllDomainProjects

for PROJ_ID in $PROJ_IDS
do
  TAG=$(curl -s --request GET --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/repository/tags" | jq -r '.[0] | .name')
  if [ ! "$TAG" = 'null' ]; then
    PROJECT_NAME=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID" | jq -r '"\(.name) : \(.path_with_namespace)"')
    for i in {1..10..1}
    do
      PASSED_DEPLOY_PROD_JOB_0_COMMIT_ID=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/jobs?scope=success&page=$i&per_page=100" \
        | jq -r '[.[] | select(.name == "deploy-prod" or .name == "deploy-os3-prod" or .name == "deploy-os4-prod" or .name == "deploy-to-prod")][0] | .commit.id')
      if [ !  "$PASSED_DEPLOY_PROD_JOB_0_COMMIT_ID" = 'null' ]; then
        break
      fi
    done
    DEPLOYED_TAG=$(curl -s --request GET --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/repository/tags" \
      | jq -r --arg COMMIT "$PASSED_DEPLOY_PROD_JOB_0_COMMIT_ID"  '[.[] | select(.commit.id == $COMMIT)][0]  .name')
    if [ ! "$DEPLOYED_TAG" = 'null' ]; then
      echo "$PROJECT_NAME"
      echo 'latest tag:           '"$TAG"
      echo 'tag deployed to prod: '"$DEPLOYED_TAG"
      if [ "$DEPLOYED_TAG" != "$TAG" ]; then
        echo 'WARNING: Out of date!'
      fi
      echo '--------------------------------------'
    fi
  fi
done
