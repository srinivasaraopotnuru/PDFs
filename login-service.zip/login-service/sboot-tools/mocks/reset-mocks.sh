mkdir -p target
curl -X PUT "https://ds-mocks-dev.apps.ostest.ybs.com/mockserver/reset" > target/reset.txt
