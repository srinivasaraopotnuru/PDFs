#!/usr/bin/env bash
set -e

# Get a GITLAB token and export to GITLAB_TOKEN before running this script
# Parameter 1 should be a list of gropup names, e.g: selfserve-squad-maintainers selfserve-squad-maintainers%2Fselfserve-squad-developers selfserve-squad-maintainers%2Fselfserve-squad-testers
GROUPNAMES="$1"
# Parameter 2 should be an exclusion regex, e.g: "U11111|U22222|U33333"
EXCLUDE="$2"

for GROUP in $GROUPNAMES
do
  NAMES="$NAMES
$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/groups/${GROUP//\//%2F}/members" | jq '.[] | select(.state == "active") | .name')"
done

# If $EXCLUDE is empty, "\(\)" will not match anything.
{
  echo "Use the first available reviewer from this list:"
  echo "$NAMES" \
    | grep -Ev "\($EXCLUDE\)" \
    | sort -u \
    | sed '/^ *$/d; s/"//g;' \
    | while read line; do echo "$RANDOM:$line"; done \
    | sort -n \
    | cut -d: -f2- \
    | nl -s '. ' \
    | grep . || echo "-- No reviewers found; throw some dice yourself. --"
} >&2
