'''scans for changes against merge base and only deploys modified KVMs,
this ignores untracked files so these should be added to the index if they
should be included'''

import itertools
import json
import os
import shutil
import stat
import sys
from base64 import b64decode
from tempfile import TemporaryDirectory

import compare_hashes
import git_utils
import hashing
import os_utils
from apigee import Apigee

DIR_STRUCTURE_ENV_FIRST = "ENV_FIRST"
DIR_STRUCTURE_ENV_LAST = "ENV_LAST"

CFG_ROOT_DIR = "apg-config"
CFG_KVM = "kvm"
CFG_APIPROD = "product"
CFG_DEV = "developer"
CFG_APP = "app"
CFG_REF = "reference"
CFG_TARGSERV = "target-server"
CFG_VIRTHOST = "virtual-host"

CFG_SCOPE_ORG="org"
CFG_SCOPE_ENV="env"
CFG_SCOPE_PROXY="proxy"

def update_apiproducts(apigee):
    update_configs(apigee, CFG_APIPROD)

def update_developers(apigee):
    update_configs(apigee, CFG_DEV)

def update_apps(apigee):
    update_configs(apigee, CFG_APP)

def update_kvms(apigee):
    update_configs(apigee, CFG_KVM, CFG_SCOPE_ORG)
    update_configs(apigee, CFG_KVM, CFG_SCOPE_ENV)
    update_configs(apigee, CFG_KVM, CFG_SCOPE_ENV, dir_structure=DIR_STRUCTURE_ENV_FIRST)
    update_configs(apigee, CFG_KVM, CFG_SCOPE_PROXY)

def update_ref(apigee):
    update_configs(apigee, CFG_REF, CFG_SCOPE_ENV)

def update_targserv(apigee):
    update_configs(apigee, CFG_TARGSERV, CFG_SCOPE_ENV) 

def update_virthost(apigee):
    update_configs(apigee, CFG_VIRTHOST, CFG_SCOPE_ENV)          

def update_configs(apigee, config_type, cfg_scope=None, proxy_name=None, dir_structure=DIR_STRUCTURE_ENV_LAST):
    print("------------------------------")
    org=os.getenv('APIGEE_DEPLOY_ORG')
    env=os.getenv('TARGET_ENV')

    ###Default to org based.
    config_path = None
    versions_path = os.path.join('org', org)
    if CFG_SCOPE_ORG == cfg_scope:
        config_path = os.path.join('org', org)
        versions_path = os.path.join('org', org)
    elif CFG_SCOPE_ENV == cfg_scope:
        if DIR_STRUCTURE_ENV_FIRST == dir_structure:
          config_path = os.path.join('env', 'nonprod', env)
          versions_path = os.path.join('env', env)
        else:
          config_path = os.path.join('env', env)
          versions_path = os.path.join('env', env)
    elif CFG_SCOPE_PROXY == cfg_scope:
        config_path = 'proxy'
        versions_path = 'proxy'

    repo = git_utils.find_git_root(os.getcwd())
    git_root_dir = repo.working_tree_dir

    # TODO make this nicer
    base_branch = repo.remotes.origin.refs.master

    is_ci = os.getenv('CI')
    # Cannot use default argument here as it is resoved before calling getenv
    if is_ci:
        branch_from_env = os.getenv('CI_COMMIT_REF_NAME')
        this_branch = repo.remotes.origin.refs[branch_from_env]
    else:
        this_branch = repo.active_branch

    print(base_branch, this_branch)
    merge_base = repo.merge_base(
        base_branch,
        this_branch
    )[0]

    with TemporaryDirectory() as versions_repo_dir:

        if env != "dev":
            ci_user = os.getenv('GITLAB_PUSH_USER')
            ci_token = os.getenv('GITLAB_PUSH_TOKEN')
            git_prj_ns = os.getenv('GIT_PROJECT_NAMESPACE')
            git_prj_name = os.getenv('GIT_PROJECT_NAME')
            versions_repo = git_utils.clone(
                'https://{}:{}@ecommgit.ybs.com/{}/{}-versions.git'.format(ci_user, ci_token, git_prj_ns, git_prj_name),
                versions_repo_dir
            )
            typeDir = os.path.join(versions_repo_dir, CFG_ROOT_DIR, config_type + "s")
            cfgVsnFile = os.path.join(typeDir, versions_path, 'versions.json')
        else:
            script_dir = os.path.dirname(os.path.realpath(__file__))
            typeDir = os.path.join(script_dir, 'scratch', config_type + "s")
            cfgVsnFile = os.path.join(typeDir, versions_path, this_branch.name, 'versions.json')

        saved_revisions = {}
        print("saved_revisions file:", cfgVsnFile)
        if os.path.isfile(cfgVsnFile):
            with open(cfgVsnFile, 'r') as saved_revisions:
                saved_revisions = json.load(saved_revisions)
                print("saved_revisions: ", saved_revisions)
        elif env == "dev":
            gitDir = os.path.join(CFG_ROOT_DIR, config_type + "s")
            if config_path is not None:
                if DIR_STRUCTURE_ENV_FIRST == dir_structure:
                    gitDir = os.path.join(CFG_ROOT_DIR, config_path, config_type + "s")
                else:
                    gitDir = os.path.join(CFG_ROOT_DIR, config_type + "s", config_path)
            changed_files = git_utils.git_changed_files(repo, merge_base, gitDir)
            print("changed_files: ", gitDir, ": ", changed_files)
            if len(changed_files) == 0:
                print("No changes detected")
                return

        tags = []
        typeDir = os.path.join(git_root_dir, CFG_ROOT_DIR, config_type + "s")
        if config_path is not None:
            if DIR_STRUCTURE_ENV_FIRST == dir_structure:
                typeDir = os.path.join(git_root_dir, CFG_ROOT_DIR, config_path, config_type + "s")
            else:
                typeDir = os.path.join(git_root_dir, CFG_ROOT_DIR, config_type + "s", config_path)
        if os.path.isdir(typeDir):
            configEntries = os.listdir(typeDir)
            proxyCfgEntries = []
            if CFG_SCOPE_PROXY == cfg_scope:
                for proxyName in configEntries:
                    print("proxyName:", proxyName)
                    proxyEntries = os.listdir(os.path.join(typeDir, proxyName))
                    for kvmName in proxyEntries:
                        proxyKvmPath = os.path.join(proxyName, kvmName)
                        print("proxyKvmPath:", proxyKvmPath)
                        proxyCfgEntries.append(proxyKvmPath)
                configEntries = proxyCfgEntries
            print(proxyCfgEntries)
            for configItem in configEntries:
                apgName = configItem
                proxyName = None
                if CFG_SCOPE_PROXY == cfg_scope:
                    proxyName = configItem.split("/")[0]
                    apgName = configItem.split("/")[1]
                if DIR_STRUCTURE_ENV_FIRST == dir_structure:
                    cfgFile = os.path.join(typeDir, configItem)
                else:
                    cfgFile = os.path.join(typeDir, configItem, 'detail.json')
                if os.path.isfile(cfgFile):
                    cfgMeta = os.path.join(typeDir, configItem, 'meta-data.json')
                    metaJson = {}
                    if os.path.isfile(cfgMeta):
                        with open(cfgMeta, 'r') as f:
                            metaJson = json.load(f)
                    print(configItem, " meta: ", metaJson)
                    if "name" in metaJson:
                        apgName = metaJson["name"]
                    if "ownerKey" in metaJson:
                        apgOwnerKey = metaJson["ownerKey"]

                    #kvmFile = os.path.join(typeDir, configItem)
                    md5 = hashing.hash_file(cfgFile)
                    newMd5 = md5.hexdigest()
                    #print("newMd5: ", newMd5)
                    #kvm_name=os.path.splitext(configItem)[0]
                    curMd5 = saved_revisions.get(configItem, {}).get("hash", 0)
                    #print("curMd5: ", curMd5)
                    curVsn = saved_revisions.get(configItem, {}).get("revision", 0)
                    #print("curVsn: ", curVsn)

                    if newMd5 != curMd5:
                        print(config_type.upper(), ": ", configItem, " changed, updating in APIGee")
                        curVsn += 1
                        with open(cfgFile, 'r') as f:
                            cfgJson = json.load(f)
                        print(configItem, " cfig: ", cfgJson)

                        if CFG_KVM == config_type:
                            if CFG_SCOPE_ORG == cfg_scope:
                                old_kvm = apigee.get_kvm(kvm_name=apgName, env=None)
                                apigee.upsert_kvm(kvm_name=apgName, env=None, kvm_dict=cfgJson, proxy_name=None, proxy_version=None, old_kvm=old_kvm)
                            elif CFG_SCOPE_ENV == cfg_scope:
                                old_kvm = apigee.get_kvm(kvm_name=apgName, env=env)
                                apigee.upsert_kvm(kvm_name=apgName, env=env, kvm_dict=cfgJson, proxy_name=None, proxy_version=None, old_kvm=old_kvm)
                            elif CFG_SCOPE_PROXY == cfg_scope:
                                old_kvm = apigee.get_kvm(kvm_name=apgName, env=None, proxy_name=proxyName, proxy_version=None)
                                apigee.upsert_kvm(kvm_name=apgName, env=None, kvm_dict=cfgJson, proxy_name=proxyName, proxy_version=None, old_kvm=old_kvm)
                        elif CFG_APIPROD == config_type:
                            old_product = apigee.get_apiproduct(apgName)
                            apigee.upsert_apiproduct(prod_name=apgName, new_product=cfgJson, old_product=old_product)
                        elif CFG_DEV == config_type:
                            old_developer = apigee.get_developer(apgName)
                            apigee.upsert_developer(dev_email=apgName, new_dev=cfgJson, old_dev=old_developer)
                        elif CFG_REF == config_type:
                            old_ref = apigee.get_ref(ref_name=apgName, env=env)
                            apigee.upsert_ref(ref_name=apgName, env=env, new_ref=cfgJson, old_ref=old_ref)                            
                        elif CFG_TARGSERV == config_type:
                            old_targserv = apigee.get_targserv(targserv_name=apgName, env=env)
                            apigee.upsert_targserv(targserv_name=apgName, env=env, new_targserv=cfgJson, old_targserv=old_targserv)  
                        elif CFG_VIRTHOST == config_type:
                            old_virthost = apigee.get_virthost(virthost_name=apgName, env=env)
                            apigee.upsert_virthost(virthost_name=apgName, env=env, new_virthost=cfgJson, old_virthost=old_virthost)                          
                        elif CFG_REF == config_type:
                            old_ref = apigee.get_ref(ref_name=apgName, env=env)
                            apigee.upsert_ref(ref_name=apgName, env=env, new_ref=cfgJson, old_ref=old_ref)                                                      
                        
                        elif CFG_APP == config_type:
                            old_app = apigee.get_app(apgOwnerKey, apgName)
                            ###If you update the app, the apiProduct will be created again even if they already exist.
                            #Find existing apiProducts
                            allProducts = []
                            if old_app is not None and "credentials" in old_app and len(old_app["credentials"]) > 0:
                                for credential in old_app["credentials"]:
                                    if "apiProducts" in credential and len(credential["apiProducts"]) > 0:
                                        for apiProd in credential["apiProducts"]:
                                            allProducts.append(apiProd["apiproduct"])
                            #Remove existing apiProducts from update.
                            for prodName in allProducts:
                                if prodName in cfgJson["apiProducts"]:
                                    cfgJson["apiProducts"].remove(prodName)
                                    print("Removed ", prodName, " to prevent duplicates.")
                            print(configItem, " cfig: ", cfgJson)
                            apigee.upsert_app(dev_email=apgOwnerKey, app_name=apgName, new_app=cfgJson, old_app=old_app)

                        tags.append(repo.create_tag('{}/{}/{}'.format(config_type, configItem, curVsn), force=True))
                        saved_revisions.setdefault(configItem,{}).update({
                            'hash': newMd5,
                            'revision': curVsn
                        })
                    else:
                        print(config_type.upper(), ": ", configItem, " is unchanged")
                else:
                    print(cfgFile, "not found")

            os.makedirs(os.path.dirname(cfgVsnFile), exist_ok=True)
            with open(cfgVsnFile, 'w') as file:
                json.dump(saved_revisions, file, indent=4, sort_keys=True)

            if env != "dev" and len(tags) > 0:
                ### For testenv (master branch) push a tag to GIT, for rollback.
                tags_push_url = 'https://{}:{}@ecommgit.ybs.com/{}/{}.git'.format(ci_user, ci_token, git_prj_ns, git_prj_name)

                print('Updating versions repository...')
                versions_repo.index.add([CFG_ROOT_DIR + "/" + config_type + 's/' + versions_path + '/versions.json'])
                this_commit = repo.head.commit
                versions_repo.index.commit('update for commit: {}\n{}'.format(this_commit, this_commit.message))
                for push in versions_repo.remotes.origin.push():
                    print('Pushed new ', config_type.upper(), ' versions to versions repository:', push.summary)

                print('Pushing tags:')
                try:
                    ci_tag_remote = repo.remotes.ci_tags
                    ci_tag_remote.set_url(tags_push_url)
                except:
                    ci_tag_remote = repo.create_remote('ci_tags', tags_push_url)

                for push in ci_tag_remote.push(tags):
                    print('\t', push.local_ref, '->', push.remote_ref)
        else:
            print("No ", config_type.upper(), "s found here: ", typeDir)
        os_utils.chmod_dir(versions_repo_dir, 0o777)

def main():
    apg_password = os.getenv('APIGEE_DEPLOY_PASSWORD')
    if apg_password is None or apg_password == "":
        apg_password = b64decode(os.getenv('APIGEE_DEPLOY_PASSWORD_B64')).decode("ascii")
    apigee = Apigee(
        os.getenv('APIGEE_DEPLOY_ORG'),
        os.getenv('APIGEE_DEPLOY_USER'),
        apg_password
    )

    if 'master' in sys.argv:
        if  os.getenv('CI') or input("this script is meant to be run on CI, are you sure you want to run it locally? (y/N) ").lower() == 'y':
            update_kvms(apigee)
            update_apiproducts(apigee)
            update_developers(apigee)
            update_apps(apigee)
            update_ref(apigee)
            update_targserv(apigee)
            update_virthost(apigee)
    else:
        update_kvms(apigee)
        update_apiproducts(apigee)
        update_developers(apigee)
        update_apps(apigee)
        update_ref(apigee)
        update_targserv(apigee)
        update_virthost(apigee)        
    print("FINISHED")

if __name__ == '__main__':
    main()
