import config
import ecdsa
import expected_json_schema
import hashlib
import jsonschema
import os
import requests
import uuid
from signer import Signer

host = os.getenv('SERVICE_HOST', default='localhost:8080')
protocol = os.getenv('SERVICE_PROTOCOL', default='http://')
target_env = os.getenv('SMOKE_TARGET_ENV', default='test')

base_path = '/login'
login_path = '/login'
host_presented = host
x_request_id = str(uuid.uuid4())
request_signing_key_id = 'auth-service-nonprod-1'

if target_env == 'dev' or target_env == 'test':
    party_id = '3656867'
elif target_env == 'flex':
    party_id = '3656867'
else:
    raise Exception('Unexpected SMOKE_TARGET_ENV: {}'.format(target_env))

signer = Signer({
    request_signing_key_id: ecdsa.SigningKey.from_pem(config.request_signature_private_key, hashlib.sha256)
})


valid_login_request = {
    'partyId': party_id,
    'brandCode': 'YBS'
}


def test_login_should_succeed_with_valid_signature():
    response = make_request(f'{login_path}', json=valid_login_request, key_id=request_signing_key_id)
    assert response.status_code == 200

    response_body = response.json()
    jsonschema.validate(response_body, expected_json_schema.expected_login_response_schema)


def test_login_should_fail_without_signature():
    response = make_request(f'{login_path}', json=valid_login_request, key_id=request_signing_key_id, no_sign=True)
    assert response.status_code == 403
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


def make_request(path, json, key_id=None, no_sign=False):
    url = protocol + host + base_path + path

    headers = {
        'Host': host_presented,
        'x-ybs-request-id': x_request_id
    }

    def add_header_if_not_none(header, value):
        if value is not None:
            headers[header] = value

    add_header_if_not_none('x-ybs-request-signature-key-id', key_id)

    request = requests.Request('post', url, headers, json=json).prepare()
    if not no_sign:
        signer.sign_request(request)
    return requests.session().send(request, verify=False)

