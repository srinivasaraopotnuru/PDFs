expected_login_response_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "customer": {
            "type": "object",
            "properties": {
                "customerNumber": {
                    "type": "integer"
                },
                "partyId": {
                     "type": "integer"
                },
                "forename": {
                    "type": "string"
                },
                "surname": {
                    "type": "string"
                },
                "title": {
                    "type": "string"
                },
                "email": {
                    "type": "string"
                }
            },
            "required": [
                "customerNumber",
                "partyId",
                "forename",
                "surname"
            ],
            "additionalProperties": False
        },
        "login": {
            "type": "object",
            "properties": {
                "loginTime": {
                    "type": "string"
                },
                "lastLoginTime": {
                    "type": "string"
                }
            },
            "required": [
                "loginTime",
                "lastLoginTime"
            ],
            "additionalProperties": False
        }
    },
    "required": [
        "customer",
        "login"
    ],
    "additionalProperties": False
}
