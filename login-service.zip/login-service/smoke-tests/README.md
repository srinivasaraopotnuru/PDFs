# Smoke tests
From the smoke-tests directory (/login-service/smoke-tests/.) run:
```
pipenv install
pipenv run pytest
```

NB: You need to have the service running at http://localhost:8080

### Notes
- To see the output of print statements, you can run ```pipenv run pytest -s```
- The tests use environment variables to for the url