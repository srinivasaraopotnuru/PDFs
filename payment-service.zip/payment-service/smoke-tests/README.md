# Smoke tests
The smoke tests should be run using Pipenv so that it can satisfy the dependencies for us
```
pipenv install
pipenv run pytest
```

NB: You need to have the service running at http://localhost:8080

### Notes
- To see the output of print statements, you can run ```pipenv run pytest -s```
- The tests use environment variables to for the url