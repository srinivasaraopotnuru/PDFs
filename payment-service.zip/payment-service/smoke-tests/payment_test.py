import ecdsa
import hashlib
import os
import pytest
import requests
import uuid
from base64 import b64encode
from jwt import (
    JWT,
    jwk_from_pem,
)
from time import time

import config
from signer import Signer

host = os.getenv('SERVICE_HOST', default='localhost:8080')
protocol = os.getenv('SERVICE_PROTOCOL', default='http://')
target_env = os.getenv('SMOKE_TARGET_ENV', default='test')

jwt_alg = 'RS256'
base_path = '/payment'
payment_path = '/payment'
validate_path = '/validate'
validate_payee_path = '/validate/payee'
private_validate_payee_path = '/private/validate/payee'
payment_failure_path = '/failure'
payment_method = 'POST'
host_presented = host
x_request_id = str(uuid.uuid4())
request_signing_key_id_public = 'apigee-nonprod-1'
request_signing_key_id_private_isa = 'isa-transfer-service-nonprod-1'
sca_signing_key_id = 'sca_key'

signer = Signer({
    request_signing_key_id_public: ecdsa.SigningKey.from_pem(config.request_signature_private_key_public, hashlib.sha256),
    request_signing_key_id_private_isa: ecdsa.SigningKey.from_pem(config.request_signature_private_key_private_isa, hashlib.sha256),
    sca_signing_key_id: ecdsa.SigningKey.from_pem(config.sca_private_key, hashlib.sha256)
})

test_data = {
    'test': {
        'customer_number': '3871726',
        'debtor_account_number': '4039285807',
        'creditor_account_number': '4039245907',
        # Passes MOD_X checks but not a live account
        'external_account_number': '12345678',
        'non_ybs_sort_code': '300045',
        'beneficiary_id': '1deef68116be8c9560d088cc36a0b8e1339dbaff9e6712a85ef8c2ed36618c64'
    },
    'flex': {
        'customer_number': '1625284',
        'debtor_account_number': '9377291120',
        'creditor_account_number': '9140112601',
        # Passes MOD_X checks but not a live account
        'external_account_number': '12345678',
        'non_ybs_sort_code': '300045',
        'beneficiary_id': '73c04e0804166b74d858b3cfc174050c245199ce90f1008e76f6a1c46dbb4c4c'
    }
}
test_data['dev'] = test_data['test']


@pytest.fixture
def customer_number():
    return test_data[target_env]['customer_number']


@pytest.fixture
def valid_external_payment_request_with_creditor_details(customer_number):
    # Return a request with a new idempotency key each time
    return {
        'type': 'EXTERNAL',
        'idempotencyKey': str(uuid.uuid4()),
        'amount': '1.00',
        'currency': 'GBP',
        'reference': 'SOME REFERENCE',
        'debtor': {
            'accountNumber': test_data[target_env]['debtor_account_number']
        },
        'creditor': {
            'type': 'DETAILS',
            'externalAccountNumber': '80948780',  # taken from NON_YBS_BANK_ACCOUNTS table
            'sortCode': '201995',
            'name': 'Mr Joe Bloggs'
        }
    }


@pytest.fixture
def valid_external_payment_request_with_creditor_beneficiary(customer_number):
    # Return a request with a new idempotency key each time
    return {
        'type': 'EXTERNAL',
        'idempotencyKey': str(uuid.uuid4()),
        'amount': '1.00',
        'currency': 'GBP',
        'debtor': {
            'accountNumber': test_data[target_env]['debtor_account_number']
        },
        'creditor': {
            'type': 'BENEFICIARY',
            'beneficiaryId': test_data[target_env]['beneficiary_id']
        }
    }


"""
Beneficiary set up:
 Set up against debtor_account_number manually via ECOM, with details (if the details match, the beneficiaryId will 
 match):
    {
      'beneficiaryId': '53b6f8260f2fc11042f1aa7a35ba4d4ba381f15db1f3abca949514698136751a',
      'type': 'EXTERNAL',
      'accountNumber': '80948780',
      'accountSortCode': '201995',
      'name': 'MR JOE BLOGGS',
      'reference': 'TEST',
      'memorableName': 'Test Payee'
    }
"""


@pytest.fixture
def valid_internal_payment_request(customer_number):
    # Return a request with a new idempotency key each time
    return {
        'type': 'INTERNAL',
        'idempotencyKey': str(uuid.uuid4()),
        'amount': '1.00',
        'currency': 'GBP',
        'debtor': {
            'accountNumber': test_data[target_env]['debtor_account_number']
        },
        'creditor': {
            'accountNumber': test_data[target_env]['creditor_account_number']
        }
    }


@pytest.fixture
def valid_payment_failure_request(customer_number):
    return {
        'idempotencyKey': str(uuid.uuid4()),
        'debtor': {
            'accountNumber': test_data[target_env]['debtor_account_number']
        }
    }


@pytest.fixture
def valid_validate_external_payee_request():
    return {
        'externalAccountNumber': test_data[target_env]['external_account_number'],
        'sortCode': test_data[target_env]['non_ybs_sort_code'],
    }


@pytest.fixture
def valid_validate_internal_payee_request():
    return {
        'type': 'INTERNAL',
        'accountNumber': test_data[target_env]['creditor_account_number'],
    }


@pytest.mark.parametrize('valid_payment_request', [
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_details')),
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_beneficiary')),
    (pytest.lazy_fixture('valid_internal_payment_request'))
])
def test_validate_payment_should_succeed_with_signature_and_payments_scope(customer_number, valid_payment_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT ACCOUNT_READ BENEFICIARY'))
    response = make_request(validate_path, json=valid_payment_request, authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert response.status_code == 200


@pytest.mark.parametrize('valid_payment_request', [
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_details')),
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_beneficiary')),
    (pytest.lazy_fixture('valid_internal_payment_request'))
])
def test_validate_payment_should_fail_without_payments_scope(customer_number, valid_payment_request):
    authorization = create_authorization(create_jwt(customer_number, 'OTHER'))
    response = make_request(validate_path, json=valid_payment_request, authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert_access_denied(response)


def test_send_payment_failure_should_succeed_with_signature_and_payments_scope(customer_number,
                                                                               valid_payment_failure_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT ACCOUNT_READ BENEFICIARY'))
    response = make_request(payment_failure_path, json=valid_payment_failure_request, authorization=authorization,
                            key_id=request_signing_key_id_public)

    assert response.status_code == 204, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.content == b''


def test_send_payment_failure_should_fail_without_payments_scope(customer_number, valid_payment_failure_request):
    authorization = create_authorization(create_jwt(customer_number, 'OTHER'))
    response = make_request(payment_failure_path, json=valid_payment_failure_request, authorization=authorization,
                            key_id=request_signing_key_id_public)

    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'


@pytest.mark.parametrize('valid_payment_request', [
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_details')),
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_beneficiary')),
    (pytest.lazy_fixture('valid_internal_payment_request'))
])
def test_make_payment_should_succeed_with_signature_and_payments_scope(customer_number, valid_payment_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT ACCOUNT_READ BENEFICIARY'))
    response = make_request(payment_path, json=valid_payment_request, authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'

    challenge = response.headers.get("x-ybs-sca-challenge")
    challenge_response = signer.create_ecdsa_signature(sca_signing_key_id, challenge)
    response = make_request(payment_path, json=valid_payment_request, authorization=authorization,
                            challenge=challenge,
                            challenge_response=challenge_response, key_id=request_signing_key_id_public)
    assert response.status_code == 204, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.content == b''


@pytest.mark.parametrize('valid_payment_request', [
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_details')),
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_beneficiary')),
    (pytest.lazy_fixture('valid_internal_payment_request'))
])
def test_make_payment_should_fail_without_payments_scope(customer_number, valid_payment_request):
    authorization = create_authorization(create_jwt(customer_number, 'OTHER'))
    response = make_request(payment_path, json=valid_payment_request, authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert_access_denied(response)

@pytest.mark.parametrize('valid_payment_request', [
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_details')),
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_beneficiary')),
    (pytest.lazy_fixture('valid_internal_payment_request'))
])
def test_make_payment_should_fail_without_signature(customer_number, valid_payment_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT ACCOUNT_READ BENEFICIARY'))
    response = make_request(payment_path, json=valid_payment_request, key_id=request_signing_key_id_public,
                            authorization=authorization, no_sign=True)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


@pytest.mark.parametrize('valid_payment_request', [
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_details')),
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_beneficiary')),
    (pytest.lazy_fixture('valid_internal_payment_request'))
])
def test_make_payment_should_fail_without_bearer_token(valid_payment_request):
    response = make_request(payment_path, json=valid_payment_request, key_id=request_signing_key_id_public)
    assert_request_unauthorized(response)


def test_send_payment_failure_should_fail_without_bearer_token(valid_payment_failure_request):
    response = make_request(payment_failure_path, json=valid_payment_failure_request, key_id=request_signing_key_id_public)
    assert_request_unauthorized(response)


@pytest.mark.parametrize('valid_payment_request', [
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_details')),
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_beneficiary')),
    (pytest.lazy_fixture('valid_internal_payment_request'))
])
def test_make_payment_should_fail_without_sca_challenge_response(customer_number, valid_payment_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT ACCOUNT_READ BENEFICIARY'))
    response = make_request(payment_path, json=valid_payment_request, authorization=authorization,
                            key_id=request_signing_key_id_public)

    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Strong customer authentication required',
        'errors': [
            {
                'errorCode': 'SCA.Required',
                'message': 'Please sign the value in x-ybs-sca-challenge header with the request'
            }
        ]
    }


@pytest.mark.parametrize('valid_payment_request', [
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_details')),
    (pytest.lazy_fixture('valid_external_payment_request_with_creditor_beneficiary')),
    (pytest.lazy_fixture('valid_internal_payment_request'))
])
def test_payment_should_fail_with_invalid_challenge_response(customer_number, valid_payment_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT ACCOUNT_READ BENEFICIARY'))

    # This could be any string. It happens to be a challenge for a different payment
    different_challenge = "resJrtazyCjl5ocCfl6ti5GSLp//ZjyC0b2UTx/DfHQoe03h/gqmT5VmEyjUMW9aO/l09USJ0HB7Yg4Rex5P8YMoHbfEeYUVS4rZUMXehGTfNPe07N7iPbohDWJORboBmMh4omkYf0FLKrrl0Wh2jYJ68PLEztjivua48X7gWJMAXQMMRN5H+Z1SEesSeTqG28rA3h3dGRNxeKmnhELPKjfiiIkTENLK9zg6tZbNiA7a0uZcrav0bmPadJOio76702ihZIKDjNyd+YQggGdh/n30jr1ykNaUx16Q9GzCVHOL+CR5528+yHP+KPLQ1IFMGK8OncLA7ZRtLKXFs5g0PA=="

    sk = ecdsa.SigningKey.from_pem(config.sca_private_key, hashlib.sha256)
    challenge_response = signer.create_ecdsa_signature(sca_signing_key_id, different_challenge)
    response = make_request(payment_path, json=valid_payment_request, authorization=authorization,
                            challenge=different_challenge,
                            challenge_response=challenge_response, key_id=request_signing_key_id_public)
    assert_access_denied(response)


# Validate internal/external payee
@pytest.mark.parametrize('valid_validate_payee_request', [
    (pytest.lazy_fixture('valid_validate_external_payee_request')),
    (pytest.lazy_fixture('valid_validate_internal_payee_request'))
])
def test_validate_payee_should_succeed_with_signature_and_payments_scope_user_jwt(customer_number, valid_validate_payee_request):
    authorization = create_authorization(create_jwt(customer_number, 'ACCOUNT_READ'))
    response = make_request(validate_payee_path, json=valid_validate_payee_request, authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert response.status_code == 204


@pytest.mark.parametrize('valid_validate_payee_request', [
    (pytest.lazy_fixture('valid_validate_external_payee_request')),
    (pytest.lazy_fixture('valid_validate_internal_payee_request'))
])
def test_private_validate_payee_should_succeed_with_signature_and_payments_scope_user_jwt(customer_number, valid_validate_payee_request):
    authorization = create_authorization(create_jwt(customer_number, 'ACCOUNT_READ'))
    response = make_request(private_validate_payee_path, json=valid_validate_payee_request, authorization=authorization,
                            key_id=request_signing_key_id_private_isa)
    assert response.status_code == 204


def test_validate_payee_should_succeed_with_signature_and_payments_scope_system_jwt(customer_number, valid_validate_external_payee_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT_READ'))
    response = make_request(validate_payee_path, json=valid_validate_external_payee_request, authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert response.status_code == 204


def test_private_validate_payee_should_succeed_with_signature_and_payments_scope_system_jwt(customer_number, valid_validate_external_payee_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT_READ'))
    response = make_request(private_validate_payee_path, json=valid_validate_external_payee_request, authorization=authorization,
                            key_id=request_signing_key_id_private_isa)
    assert response.status_code == 204

@pytest.mark.parametrize('valid_validate_payee_request', [
    (pytest.lazy_fixture('valid_validate_external_payee_request')),
    (pytest.lazy_fixture('valid_validate_internal_payee_request'))
])
def test_validate_payee_should_fail_without_bearer_token(valid_validate_payee_request):
    response = make_request(validate_payee_path, json=valid_validate_payee_request, key_id=request_signing_key_id_public)
    assert_request_unauthorized(response)


@pytest.mark.parametrize('valid_validate_payee_request', [
    (pytest.lazy_fixture('valid_validate_external_payee_request')),
    (pytest.lazy_fixture('valid_validate_internal_payee_request'))
])
def test_validate_payee_should_fail_without_payments_scope(customer_number, valid_validate_payee_request):
    authorization = create_authorization(create_jwt(customer_number, 'OTHER'))
    response = make_request(validate_payee_path, json=valid_validate_payee_request, authorization=authorization,
                            key_id=request_signing_key_id_public)
    assert_access_denied(response)


@pytest.mark.parametrize('valid_validate_payee_request', [
    (pytest.lazy_fixture('valid_validate_external_payee_request')),
    (pytest.lazy_fixture('valid_validate_internal_payee_request'))
])
def test_validate_payee_should_fail_without_signature(customer_number, valid_validate_payee_request):
    authorization = create_authorization(create_jwt(customer_number, 'PAYMENT ACCOUNT_READ BENEFICIARY'))
    response = make_request(validate_payee_path, json=valid_validate_payee_request, authorization=authorization,
                            key_id=request_signing_key_id_public, no_sign=True)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


def assert_request_unauthorized(response):
    assert response.status_code == 401, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == unauthorized_error_response()


def unauthorized_error_response():
    return {
        'id': x_request_id,
        'code': '401 Unauthorized',
        'message': 'Unauthorized',
        'errors': [
            {
                'errorCode': 'Unauthorized',
                'message': 'Unauthorized'
            }
        ]
    }


def assert_access_denied(response):
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == access_denied_error_response()


def access_denied_error_response():
    return {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied',
                'message': 'Access Denied'
            }
        ]
    }


def make_request(path, json, authorization=None, challenge=None, challenge_response=None, key_id=None,
                 no_sign=False):
    url = protocol + host + base_path + path

    headers = {
        'x-ybs-request-id': x_request_id,
        'Host': host_presented,
    }

    def add_header_if_not_none(header, value):
        if value is not None:
            headers[header] = value

    add_header_if_not_none('Authorization', authorization)
    add_header_if_not_none('x-ybs-request-signature-key-id', key_id)
    add_header_if_not_none('x-ybs-sca-challenge', challenge)
    add_header_if_not_none('x-ybs-sca-challenge-response', challenge_response)
    if challenge_response or challenge:
        headers['x-ybs-sca-key'] = b64encode(config.sca_public_key.encode("utf-8")).decode()

    request = requests.Request('post', url, headers, json=json).prepare()
    if not no_sign:
        signer.sign_request(request)
    return requests.session().send(request, verify=False)


def create_authorization(bearer_token):
    return 'Bearer ' + bearer_token


def create_jwt(customer_number, scope):
    signing_key = jwk_from_pem(config.jwt_private_key.encode())
    jwt = JWT()

    headers = {
        'kid': 'OPAa9voYNByjE_lpbtHanOFKiV4',
        'alg': jwt_alg
    }

    message = {
        'jti': str(uuid.uuid4()),
        'sid': str(uuid.uuid4()),
        'sub': customer_number,
        'iat': time(),
        'sid': str(uuid.uuid4()),
        'aud': 'DIGITAL_API',
        'sid': str(uuid.uuid4()),
        'brand_code': 'YBS',
        'scope': scope,
        'channel': 'SAPP',
        'registration_id': str(uuid.uuid4()),
        'verification_method': 'BIOMETRIC',
        'customer_title': 'Mr',
        'customer_email': 'YBSSavingsApp@ybs.co.uk',
        'customer_last_name': 'Bloggs',
        'party_id': customer_number,
        'sub_type': 'customer'
    }
    return jwt.encode(message, signing_key, jwt_alg, headers)

def create_jwt_system(scope):
    signing_key = jwk_from_pem(config.jwt_private_key.encode())
    jwt = JWT()

    headers = {
        'kid': 'OPAa9voYNByjE_lpbtHanOFKiV4',
        'alg': jwt_alg
    }

    message = {
        'jti': str(uuid.uuid4()),
        'sid': str(uuid.uuid4()),
        'sub': customer_number,
        'sub_type': 'system',
        'iat': time(),
        'aud': 'DIGITAL_API',
        'brand_code': 'YBS',
        'scope': scope
    }
    return jwt.encode(message, signing_key, jwt_alg, headers)
