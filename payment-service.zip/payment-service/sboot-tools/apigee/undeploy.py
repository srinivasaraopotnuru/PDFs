'''scans for changes against merge base and only deploys modified bundles,
this ignores untracked files so these should be added to the index if they
should be included'''

#from tempfile import TemporaryDirectory

import itertools
import json
import os
import shutil
import sys
from base64 import b64decode

import urllib3

import git_utils
import os_utils
from apigee import Apigee, BundleType


def delete_branch_deploy_state(branch_name):
    script_dir = os.path.dirname(os.path.realpath(__file__))
    scratch_dir = os.path.join(script_dir, 'scratch')
    filename = os.path.join(scratch_dir, branch_name + '.json')

    if os.path.exists(filename):
        os.remove(filename)

def run_local_feature_undeploy(apigee, feature):
    print("Undeploying Feature " + feature)

    apigee.remove_feature_from_apiproducts(feature)

    apigee.remove_feature_item(feature, BundleType.APIPROXY)

    apigee.remove_feature_item(feature, BundleType.SHAREDFLOW)

    delete_branch_deploy_state(feature)

    print("Completed undeploying Feature " + feature)
    os_utils.updateEnv("APIGEE_DEPLOY_STATUS","UNDEPLOYED")

def main():
    apg_password = os.getenv('APIGEE_DEPLOY_PASSWORD')
    if apg_password is None or apg_password == "":
        apg_password = b64decode(os.getenv('APIGEE_DEPLOY_PASSWORD_B64')).decode("ascii")
    apigee = Apigee(
        os.getenv('APIGEE_DEPLOY_ORG'),
        os.getenv('APIGEE_DEPLOY_USER'),
        apg_password
    )

    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    if len(sys.argv) == 2:
        feature = sys.argv[1]
    else:
        repo = git_utils.find_git_root(os.getcwd())
        this_branch = repo.active_branch
        feature = this_branch.name
    
    run_local_feature_undeploy(apigee,feature)

if __name__ == '__main__':
    main()
