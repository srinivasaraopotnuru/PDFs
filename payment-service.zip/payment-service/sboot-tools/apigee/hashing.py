'''provides utilities for calculating the hashes directories'''
import hashlib
import json
import os
import sys
import git_utils
from zipfile import ZipFile 


def hash_file(filename, md5=None):
    '''Updates the md5 with the contents of the file'''
    if md5 is None:
        md5 = hashlib.md5()
    if os.path.isfile(filename):
        with open(filename, 'rb') as file:
            md5.update(file.read())
    return md5


def all_files(directory):
    '''lists all files in the directory and subdirectories recursively'''
    for root, _, files in os.walk(directory):
        for filename in files:
            yield os.path.join(root, filename)


def hash_zips(zips):
    '''generates hash of each  zip file by hashing each files crc in the zip with its name'''
    hashes = {}

    for zip in zips:

        md5 = hashlib.md5()

        with ZipFile(zip.path, 'r') as zip: 
     
            for info in zip.infolist():
                    md5.update((info.filename+ "|" + str(info.CRC)).encode('utf-8'))
    
        hashes[os.path.basename(zip.filename)] = md5.hexdigest()

    return hashes


def hash_directories(directories, subdir=None, list_function=all_files):
    '''generates hash of each directory by hashing all the filenames found
    with hashfunc'''
    hashes = {}

    for directory in directories:
        md5 = hashlib.md5()

        try:
            thedir = directory
            if subdir is not None:
                thedir = os.path.join(directory, subdir)
            for filename in list_function(thedir):
                hash_file(os.path.join(thedir, filename), md5)
        except FileNotFoundError:
            pass

        hashes[os.path.basename(directory)] = md5.hexdigest()

    return hashes


def main():
    '''main entrypoint into the program if invoked as an executable'''
    directories = [os.getcwd()] if len(sys.argv) < 2 else sys.argv[1:]
    is_git_root = git_utils.find_git_root(directories[0]) is not None
    list_func = git_utils.list_files if is_git_root else all_files
    hashes = hash_directories(directories, list_func)
    json.dump(hashes, sys.stdout, indent=4)


if __name__ == '__main__':
    main()
