#!/usr/bin/env bash
set -e
$(dirname "$0")/running-pipelines.sh e2e
