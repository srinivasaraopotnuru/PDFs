#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
. "$gwd/sboot-tools/local/gradle-env.sh"
echo pwd=`pwd`
echo "Checking Python Virtual Environment"

if [ "$REQUESTS_CA_BUNDLE" = "" ]; then
    export REQUESTS_CA_BUNDLE=$(pipenv --where)/sboot-tools/certs/cacert.pem
    echo REQUESTS_CA_BUNDLE set to $REQUESTS_CA_BUNDLE
fi

if [ "$WORKON_HOME" == "" ] && [ "$(uname -s)" != "Linux" ]; then
    if [ -d "$=C:/api/.virtualenvs" ]; then
        mkdir -p c:/api/.virtualenvs
    fi
    export WORKON_HOME=c:/api/.virtualenvs
    echo WORKON_HOME set to $WORKON_HOME
fi

pipenv run python -c "print('Checking Virtual Environment....')"

if [ "$(pipenv run pip config list| grep global.cert)" = "" ]; then
    echo Setting Global Cert to $REQUESTS_CA_BUNDLE

    pipenv run pip config  set global.cert $REQUESTS_CA_BUNDLE

fi

export response="$(pipenv run python $gwd/sboot-tools/local/check_virtenv.py)"

if [ "$response"  = "NoDependancies" ]
then
    echo 'installing dependancies'
    pipenv install --dev --skip-lock
    export response="$(pipenv run python $gwd/sboot-tools/local/check_virtenv.py)"
fi

echo "Finished checking Python Virtual Environment: $response"