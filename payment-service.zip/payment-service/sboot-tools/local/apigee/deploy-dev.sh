#!/bin/bash
export gwd=`git rev-parse --show-toplevel`
#cd "$gwd"

#Include function to write to .env file.
. "$gwd/sboot-tools/common/functions.sh"
WritePropertyInFile $gwd/.env TARGET_ENV test
echo Running against APIGEE test environment

source "$gwd/sboot-tools/local/check_virtenv.sh"

if [ "$response" = "APIGEE_DEPLOY_ORG" ]
then
    echo "APIGEE_DEPLOY_ORG not set. Please run: '. set-env.sh' to set up your APIGEE deployment env vars."
    exit 1
fi

if [ "$response" = "APIGEE_DEPLOY_USER" ]
then
    echo "APIGEE_DEPLOY_USER not set. Please run: '. set-env.sh' to set up your APIGEE deployment env vars."
    exit 1
fi

if [ "$response" = "APIGEE_DEPLOY_PASSWORD" ]
then
    echo "APIGEE_DEPLOY_PASSWORD not set. Please run: '. set-env.sh' to set up your APIGEE deployment env vars."
    exit 1
fi

pipenv run apigeetools local-deploy

WritePropertyInFile $gwd/.env UNIT_TEST_FEATURE False
WritePropertyInFile $gwd/.env APIGEE_DEPLOY_STATUS DEPLOYED
