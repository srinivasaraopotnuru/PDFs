#!/usr/bin/env sh
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
#cd "$gwd"
echo Checking installed version...
apglint_vsn=`npm list -g --depth=0 apigeelint | grep apigeelint`
echo Found version: $apglint_vsn

#Check if apigeelint not already installed
if [ "$apglint_vsn" = "" ]; then
    echo Need to install apigeelint
    ### Install apigeelint node package
    if [ "$(uname -s)" = "Linux" ]; then
        #Need sudo here. (write access to /usr/local/lib is required)
        sudo npm install -g apigeelint
    elif [[ "$(uname -s)" == MINGW* ]]; then
        npm install -g apigeelint
    fi
fi

"$gwd/sboot-tools/assurance/apigeelint.sh"