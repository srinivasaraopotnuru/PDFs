#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
. "$gwd/sboot-tools/local/gradle-env.sh"
echo pwd=`pwd`

export ARTIFACTORY_USERNAME=$AD_USERNAME
export ARTIFACTORY_PASSWORD=`echo -n $AD_PASSWORD_B64 | base64 --decode`

bundleType=${1:-feature}

for arg do
  shift
  [ "$arg" = "dev" ] || [ "$arg" = "feature" ] && continue
  set -- "$@" "$arg"
done

##Run Gradle Build
if [ "$bundleType" = "dev" ]; then
    $gwd/sboot-tools/apigee/gradle/gradlew buildBundles $@
else
    $gwd/sboot-tools/apigee/gradle/gradlew buildFeatureBundles $@
fi

##Clean up env vars
export ARTIFACTORY_USERNAME=
export ARTIFACTORY_PASSWORD=
