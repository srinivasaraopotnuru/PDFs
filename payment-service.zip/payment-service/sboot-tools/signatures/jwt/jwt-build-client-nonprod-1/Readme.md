'Create the RSA key pair
ssh-keygen -t rsa -b 4096 -m pem -f ./id_rsa
'Create a PEM version of the public key
openssl rsa -in id_rsa -pubout -out id_rsa_pub.pem
