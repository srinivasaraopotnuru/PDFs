## Reads a file vulns.json (output from clair scan) and re-formats to text output.
## Author: Eliot Clark
import json
import sys, getopt

try:
  optlist, args = getopt.getopt(sys.argv[1:], 'f:c:')
except getopt.GetoptError as err:
  # print help information and exit:
  print(err)
  print("Usage: formatter.py [-ffilename.json -ccvss]")
  print("options: ")
  print("        -f filename - default vulns.json")
  print("        -c categorisation severity|cvss - default severity")
  sys.exit(2)
filename = 'vulns.json'
by_cvss = False
for o, v in optlist:
  if o == "-c" and v == "cvss":
    by_cvss = True
  if o == "-f":
    filename = v
if by_cvss:
  print("Categorised by CVSS")
else:
  print("Categorised by Severity")
thresholds = [10, 9, 7, 4, 1, 0]
severities = ['Defcon1', 'Critical', 'High', 'Medium', 'Low', 'Negligible']
with open(filename) as json_file:
  data = json.load(json_file)
  if not isinstance(data, list):
    data = [data]
  sev_idx = -1
  for severity in ['Defcon1', 'Critical', 'High', 'Medium', 'Low', 'Negligible']:
    sev_idx += 1
    vulns = {}
    for v in data:
      for json_sev in v["Vulnerabilities"]:
        for vuln in v["Vulnerabilities"][json_sev]:
          v_name = vuln["Name"]
          score = "n/a"
          cvss3 = {}
          this_sev = json_sev
          if "Metadata" in vuln:
            cvss2 = vuln["Metadata"]["NVD"]["CVSSv2"]
            cvss3 = vuln["Metadata"]["NVD"]["CVSSv3"]
            score = max(cvss2["Score"], cvss3["Score"])
            if by_cvss:
              thr_idx = -1
              for threshold in thresholds:
                thr_idx += 1
                if score >= threshold:
                  this_sev = severities[thr_idx]
                  break
          if "ProjectName" not in v:
            v["ProjectName"] = "unset-unset"
          if "ImageName" not in v:
            v["ImageName"] = "unset"
          osv = ""
          if '/' in v['ProjectName']:
            osv = v['ProjectName'].split('/')[0] + '/'
          osv_env_and_image = osv + v['ProjectName'].split('-')[-1] + '/' + v["ImageName"]
          if this_sev == severity:
            if 'sandpit' not in v['ProjectName']:
              if v_name in vulns:
                d = vulns[v_name]
                d["count"] += 1
                d["images"].append(osv_env_and_image)
                vulns[v_name] = d
              else:
                desc = vuln["Description"] if "Description" in vuln else ""
                vulns[v_name] = {'score': score, 'cvss3': cvss3, 'desc': desc, 'count': 1, 'images': [osv_env_and_image],
                                 'namespace': vuln["NamespaceName"]}
    print("** " + severity + ": " + str(len(vulns)) + " **")
    print("--------------------")
    for key in vulns:
      print(key)
      print("CVSS(max)  : " + str(vulns[key]["score"]))
      if bool(vulns[key]["cvss3"]):
        print("CVSS3      : " + json.dumps(vulns[key]["cvss3"]))
      print("Base image : " + vulns[key]["namespace"])
      print("Description: " + vulns[key]["desc"])
      print("Usage count: " + str(vulns[key]["count"]))
      print("Services   : " + ', '.join(list(set(vulns[key]["images"]))))
