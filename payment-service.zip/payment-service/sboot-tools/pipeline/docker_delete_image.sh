#!/usr/bin/env sh
set -e

##If DOCKER_REGISTRY_PUSH is not defined, use DOCKER_REGISTRY
if [ "$DOCKER_REGISTRY_PUSH" == "" ]; then
  DOCKER_REGISTRY_PUSH="$DOCKER_REGISTRY"
fi

IMAGE_NAME=$DOCKER_REGISTRY_PUSH/$DOCKER_NAME

echo ""
echo "Deleting image: "$IMAGE_NAME:$VERSION
echo ""

if [ "" != "$DOCKER_REGISTRY_PUSH" ] && [ "" != "$DOCKER_NAME" ]; then
  docker rmi $IMAGE_NAME:$VERSION
fi

exit 0
