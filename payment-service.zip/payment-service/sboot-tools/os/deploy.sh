#!/usr/bin/env bash
set -eo pipefail

seperator=--------------------
seperator=$seperator$seperator
START=$SECONDS

CONFIG_STATUS=N/A
if [ "" == "$OPENSHIFT_DEPLOY_INCLUDES" ]; then
  #Default inclusions for deployments (ALL, assume non-template deployment)
  OPENSHIFT_DEPLOY_INCLUDES=ALL
fi
if [ "" == "$DEPLOYMENT_TYPE" ]; then
  # Old ci/cd configs use APP_TYPE rather than DEPLOYMENT_TYPE
  DEPLOYMENT_TYPE=$APP_TYPE
fi
if [ "" == "$DEPLOYMENT_TYPE" ]; then
  #Default app type to dc; deployment config, rather than sts; stateful set
  DEPLOYMENT_TYPE=dc
fi
if [ "$OPENSHIFT_TEMPLATES_AND_PARAMS" = "" ]; then
  OPENSHIFT_TEMPLATES_AND_PARAMS="template/template.yaml:template/application.cfg"
fi
deploymentList=" "

echo ""
echo "$seperator"
echo "Working in $OPENSHIFT_CONFIG_DIR"

for template_and_params in $OPENSHIFT_TEMPLATES_AND_PARAMS;
do
  TEMPLATE_FILE=${template_and_params%:*}
  PARAMS_FILE=${template_and_params##*:}
  echo "Processing $TEMPLATE_FILE with $PARAMS_FILE"

  if [ ! -f "$OPENSHIFT_CONFIG_DIR/$TEMPLATE_FILE" ]; then
    echo "Template file: '$OPENSHIFT_CONFIG_DIR/$TEMPLATE_FILE' not found"
    exit 1
  fi
  if [ ! -f "$OPENSHIFT_CONFIG_DIR/$PARAMS_FILE" ]; then
    echo "Params file: '$OPENSHIFT_CONFIG_DIR/$PARAMS_FILE' not found"
    exit 1
  fi
  echo "Loading params file: $OPENSHIFT_CONFIG_DIR/$PARAMS_FILE"
  . "$OPENSHIFT_CONFIG_DIR/$PARAMS_FILE"
  if [ "$DEPLOYMENT_NAME" = "" ]; then
    DEPLOYMENT_NAME=$APP_NAME
  fi
  if [ "$DEPLOYMENT_NAME" = "" ]; then
    echo "Please define DEPLOYMENT_NAME/APP_NAME or both"
    exit 1
  fi
  if [[ "$deploymentList" != *" $DEPLOYMENT_NAME "* ]]; then
    deploymentList="$deploymentList$DEPLOYMENT_NAME "
  fi

  if [ "$OPENSHIFT_DEPLOYER_TAG" == "" ]; then
    OPENSHIFT_DEPLOYER_TAG=$OPENSHIFT_DEPLOY_USER
  fi
  OPENSHIFT_DEPLOYER_DATE=$(date --utc +%FT%TZ)

  if [ "$OPENSHIFT_TEMPLATE_EXTRA_PARAMS" = "" ]; then
    OPENSHIFT_TEMPLATE_EXTRA_PARAMS=$OPENSHIFT_TEMPLATE_PARAMS
  fi
  TEMPLATE_PARAMS=""
  IFS=',' read -ra PARAMS_ARR <<< "$OPENSHIFT_TEMPLATE_EXTRA_PARAMS"
  for i in ${PARAMS_ARR[@]}
  do
    if [ "" != "${!i}" ]; then
      TEMPLATE_PARAMS="$TEMPLATE_PARAMS -p $i=${!i}"
    fi
  done

  echo ""
  echo "Creating / Updating Template: $OPENSHIFT_CONFIG_DIR/$TEMPLATE_FILE"
  oc apply -f "$OPENSHIFT_CONFIG_DIR/$TEMPLATE_FILE"
  echo "Creating / Updating application config from Template"
  oc process -f "$OPENSHIFT_CONFIG_DIR/$TEMPLATE_FILE" \
  -p OPENSHIFT_DEPLOYER_TAG="$OPENSHIFT_DEPLOYER_TAG" \
  -p OPENSHIFT_DEPLOYER_DATE="$OPENSHIFT_DEPLOYER_DATE" \
  -p OPENSHIFT_DEPLOYER_HOST="$HOSTNAME" \
  $TEMPLATE_PARAMS \
  --param-file="$OPENSHIFT_CONFIG_DIR/$PARAMS_FILE" \
  | oc apply -f -
  CONFIG_STATUS=SUCCESS
  echo "$seperator"
done;

if [ "$CONFIG_STATUS" = "SUCCESS" ]; then
  echo "Preparing to rollout: $deploymentList"
  sleep 5

  for deployment in $deploymentList;
  do
    echo "Triggering rollout of '$DEPLOYMENT_TYPE/$deployment' into project $OPENSHIFT_DEPLOY_NAMESPACE"

    if [ "dc" == "$DEPLOYMENT_TYPE" ]; then
      echo ""
      if oc rollout history "$DEPLOYMENT_TYPE/$deployment" | cut -f3 | grep Running >/dev/null 2>&1;
      then
        echo "Deployment already running for $DEPLOYMENT_TYPE/$deployment"
      elif oc rollout history "$DEPLOYMENT_TYPE/$deployment" | cut -f3 | grep Pending >/dev/null 2>&1;
      then
        echo "Deployment pending for $DEPLOYMENT_TYPE/$deployment"
      else
        echo "Triggering deployment of $DEPLOYMENT_TYPE/$deployment"
        oc rollout latest "$DEPLOYMENT_TYPE/$deployment"
      fi
    fi

    echo ""
    echo "Waiting for deployment to complete rollout..."
    OPENSHIFT_DEPLOY_TIMEOUT=${OPENSHIFT_DEPLOY_TIMEOUT:-600}
    oc rollout status "$DEPLOYMENT_TYPE/$deployment" --request-timeout="$OPENSHIFT_DEPLOY_TIMEOUT"
    echo ""
    echo "Finished $DEPLOYMENT_TYPE/$deployment"
    echo "$seperator"
  done;
elif [ "$CONFIG_STATUS" = "N/A" ]; then
  echo "Not deploying. No Config has been applied!"
  exit 1
else
  echo "Not deploying. Errors occurred when applying updated config"
  exit 1
fi

echo ""
echo "Finding routes for app: $APP_NAME ($OPENSHIFT_APP_SERVICE_SUFFIX)"
oc get routes -l "app=$APP_NAME" --field-selector="spec.to.name=$APP_NAME$OPENSHIFT_APP_SERVICE_SUFFIX" -o json | jq -r '.items[].status.ingress[]?.host' | tee deploy_targets_openshift.txt

DURATION=$(( SECONDS - START ))
echo ""
echo "Completed in $DURATION seconds"
