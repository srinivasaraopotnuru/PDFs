#!/usr/bin/env bash
###############
# Verifies the configmaps and secrets for the OS DeploymentConfig
# are not using values indicating generic db user account is in use.
###############
set -e

# Source the login script
. "sboot-tools/os/login.sh"
# Source the template into var: PROCESSED_CFG
. "sboot-tools/os/process-template.sh" -q
CFGMAPS=$(echo "$PROCESSED_CFG" | jq -r '.items[] | select(.kind=="DeploymentConfig") | .spec.template.spec.containers[0].envFrom[].configMapRef.name // empty')
SECRETS=$(echo "$PROCESSED_CFG" | jq -r '.items[] | select(.kind=="DeploymentConfig") | .spec.template.spec.containers[0].envFrom[].secretRef.name // empty')

PROHIBITED_USERS=" coreown coreupd ecomuser ecommsecenq "
EXITCODE=0

echo "--------------------"
for CFGMAP in $CFGMAPS;
  do
    CFGMAP_KEYPAIRS=$(oc get configmap -o=json "$CFGMAP" | jq -rc 'select(.data != null) | .data | to_entries[]')
    if [ "" != "$CFGMAP_KEYPAIRS" ]; then
      while read -r CFGMAP_KEYPAIR;
        do
          KEY=$(echo "$CFGMAP_KEYPAIR" | jq -r '.key')
          VAL=$(echo "$CFGMAP_KEYPAIR" | jq -r '.value')
          VAL=$(echo "$VAL" | tr -d '\n')
          if grep -q -- " $VAL " <<< "$PROHIBITED_USERS"; then
            echo "PROHIBITED $OPENSHIFT_DEPLOY_NAMESPACE/configmap/$CFGMAP: $KEY=$VAL"
            EXITCODE=$((EXITCODE+1))
          fi
      done <<< "$CFGMAP_KEYPAIRS"
    fi
done;

for SECRET in $SECRETS;
  do
    SECRET_KEYPAIRS=$(oc get secret -o=json "$SECRET" | jq -rc 'select(.data != null) | .data | to_entries[]')
    if [ "" != "$SECRET_KEYPAIRS" ]; then
      while read -r SECRET_KEYPAIR;
        do
          KEY=$(echo "$SECRET_KEYPAIR" | jq -r '.key')
          VAL=$(echo "$SECRET_KEYPAIR" | jq -r '.value')
          if [ "" != "$VAL" ] && [ "null" != "$VAL" ]; then
            VAL=$(echo -n "$VAL" | base64 --decode)
          fi
          VAL=$(echo "$VAL" | tr -d '\n')
          if grep -q -- " $VAL " <<< "$PROHIBITED_USERS"; then
            echo "PROHIBITED $OPENSHIFT_DEPLOY_NAMESPACE/secret/$SECRET: $KEY=$VAL"
            EXITCODE=$((EXITCODE+1))
          fi
      done <<< "$SECRET_KEYPAIRS"
    fi
done;
echo "--------------------"
echo "FINISHED: $EXITCODE prohibited configs found"

exit $EXITCODE