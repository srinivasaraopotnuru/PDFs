# Test configuration
import hashlib
import importlib
import json
import os
import time
import uuid
import ecdsa
import requests
from base64 import b64encode
from jwt import JWT, jwk_from_pem
from requests.auth import HTTPBasicAuth

pytest_conf = importlib.import_module("sboot-tools.pytestconf")
sign_keys = importlib.import_module("sboot-tools.pytestconf.signkeys")
Signer = getattr(importlib.import_module("sboot-tools.pytestconf.signer"), "Signer")

try:
    import git
except ImportError:
    print("Failed to import git")

# ENVIRONMENT_TIER values
ENV_TIER_DEVELOPMENT = "development"
ENV_TIER_TESTING = "testing"
ENV_TIER_STAGING = "staging"
ENV_TIER_PRODUCTION = "production"
# ENVIRONMENT_NAME values
ENV_DEV = "dev"
ENV_TEST = "test"
ENV_FLEX = "flex"
ENV_PROD = "prod"

SERVICE_HOST = os.getenv('SERVICE_HOST')
SERVICE_PROTOCOL = os.getenv('SERVICE_PROTOCOL')
OS_DOMAIN = os.getenv('OPENSHIFT_DOMAIN')
ENV_TIER = os.getenv('ENVIRONMENT_TIER')
ENV_TYPE = os.getenv('ENVIRONMENT_TYPE')
if ENV_TYPE in (None, ""):
    ENV_TYPE = os.getenv('TARGET_ENV')
ENV_NAME = ENV_TYPE
if ENV_TIER_STAGING == ENV_NAME:
    ENV_NAME = ENV_FLEX
if ENV_TIER_PRODUCTION == ENV_NAME:
    ENV_NAME = ENV_PROD
if ENV_NAME in (None, ""):
    ENV_NAME = os.getenv('ENVIRONMENT_NAME').split("/", 1)[-1]
ENV_GROUP = "nonprod"

MOCKS_HOST = "ds-mocks-{}.{}".format(ENV_NAME, OS_DOMAIN)
API_HOST_PUBLIC = "api-digital-{}.ybs.co.uk".format(ENV_NAME)
API_HOST_PRIVAT = "ybsg-digital-nonprod-{}.apigee.net".format(ENV_NAME)
if ENV_NAME.startswith("prod"):
    API_HOST_PUBLIC = "api.ybs.co.uk"
    API_HOST_PRIVAT = "api.ybs.co.uk"
    ENV_GROUP = "prod"
SERVICE_USER = os.getenv('SERVICE_USER')
SERVICE_PASS = os.getenv('SERVICE_PASS')
# CLIENT_ID     = 'digitaldev'
# clientPassKey = 'REFSBOOT_CLIENT_PASSWORD_' + os.getenv('ENVIRONMENT_TYPE').upper()
# CLIENT_SECRET = os.getenv(clientPassKey)

# Default JWT key
jwt_key_id = "jwt-build-client-nonprod-1"
JWT_ALG = 'RS256'

# Default signature key
sig_key_id = "build-client-nonprod-1"
sig_prv_key = pytest_conf.signkeys.sig_private_key_build_client
SIGNATURE_ENABLED = True

APP_TYPE_DEFAULT = "default"
APP_TYPE_API_DEFAULT = "api-default"
APP_TYPE_API_LOW_QUOTA = "api-low-quota"
APP_TYPE_API_LOW_SPIKE = "api-low-spike"

APP_NAME_REF_APP = "RefApp"
APP_NAME_MAX_BOR = "MaxBor"
APP_NAME_SAV_APP = "SavApp"
APP_NAME_SSRV_APP = "SelfServeApp"
APP_NAME_IDV_APP = "IdvApp"

TOKEN_TYPE_JWT = "JWT"
TOKEN_TYPE_OPAQUE = "opaque"
CLIENT_CREDENTIALS = {
    "IdvApp": {
        "default": {  # Direct to service
            "client-id": "b5478289-e8a3-45b6-8128-ed6314203bac",
            "client-secret": "ae7ce0f5e25123a1e54adeb09f821bd1",
            "sig_key_id": "build-client-nonprod-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_build_client
        },
        "api-default": {  # Default via API
            "client-id": "b5478289-e8a3-45b6-8128-ed6314203bac",
            "client-secret": "ae7ce0f5e25123a1e54adeb09f821bd1"
        },
        "api-incorrect-key-id": {
            "client-id": "b5478289-e8a3-45b6-8128-ed6314203bac",
            "client-secret": "ae7ce0f5e25123a1e54adeb09f821bd1"
        },
        "api-incorrect-prv-key": {
            "client-id": "b5478289-e8a3-45b6-8128-ed6314203bac",
            "client-secret": "ae7ce0f5e25123a1e54adeb09f821bd1"
        }
    },
    "RefApp": {
        "id_uri": {
            "opaque": "/ent/v1/identity/token",
            "jwt": "/ent/v1/identity/token"
        },
        "default": {  # Direct to service
            "client-id": "iF4dDYlHfxAQUAec2WPpRQkeGg5RKs73",
            "client-secret": "OxJB231kzoFZUg8X",
            "sig_key_id": "build-client-nonprod-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_build_client
        },
        "api-default": {  # Default via API
            "client-id": "iF4dDYlHfxAQUAec2WPpRQkeGg5RKs73",
            "client-secret": "OxJB231kzoFZUg8X",
            "sig_key_id": "outsystems-sign-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_outsystems_sign_1
        },
        "api-incorrect-key-id": {
            "client-id": "iF4dDYlHfxAQUAec2WPpRQkeGg5RKs73",
            "client-secret": "OxJB231kzoFZUg8X",
            "sig_key_id": "incorrect-id-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_outsystems_sign_1
        },
        "api-incorrect-prv-key": {
            "client-id": "iF4dDYlHfxAQUAec2WPpRQkeGg5RKs73",
            "client-secret": "OxJB231kzoFZUg8X",
            "sig_key_id": "outsystems-sign-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_invalid
        }
    },
    "MaxBor": {
        "id_uri": {
            "opaque": "/dxp/v1/identity/token",
            "jwt": "/dxp/v2/identity/token"
        },
        "default": {  # Direct to service
            "client-id": "9fIdMR8qDs9VmpX1rDqPfwEDwoX4Zj5X",
            "client-secret": "ZLH54mAXzeko8cVY",
            "sig_key_id": "build-client",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_build_client
        },
        "api-default": {  # Default via API
            "client-id": "9fIdMR8qDs9VmpX1rDqPfwEDwoX4Zj5X",
            "client-secret": "ZLH54mAXzeko8cVY",
            "sig_key_id": "outsystems-sign-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_outsystems_sign_1
        },
        "low-quota": {
            "client-id": "TVzhIj2Jeb277nqFGgvgbEHhiAHdTnhP",
            "client-secret": "DwHP7RMc37mWA3ds"
        },
        "low-spike": {
            "client-id": "7PHgApmnLh1fWrP1MkDSZeNcY1rG7jso",
            "client-secret": "Hdh75J6fpMVlLndj"
        },
        "api-incorrect-key-id": {
            "client-id": "9fIdMR8qDs9VmpX1rDqPfwEDwoX4Zj5X",
            "client-secret": "ZLH54mAXzeko8cVY",
            "sig_key_id": "incorrect-id-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_outsystems_sign_1
        },
        "api-incorrect-prv-key": {
            "client-id": "9fIdMR8qDs9VmpX1rDqPfwEDwoX4Zj5X",
            "client-secret": "ZLH54mAXzeko8cVY",
            "sig_key_id": "outsystems-sign-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_invalid
        }
    },
    "SavApp": {
        "id_uri": {
            "opaque": "/dxp/v1/identity/token",
            "jwt": "/dxp/v2/identity/token"
        },
        "default": {  # Direct to service
            "client-id": "BcCDie6ezwfa4wyVEUieFn0s1TNIPKAB",
            "client-secret": "biY3mwdZjr8YLcTD",
            "sig_key_id": "build-client-nonprod-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_build_client
        },
        "api-default": {  # Default via API
            "client-id": "BcCDie6ezwfa4wyVEUieFn0s1TNIPKAB",
            "client-secret": "biY3mwdZjr8YLcTD",
            "sig_key_id": "outsystems-sign-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_outsystems_sign_1
        },
        "api-incorrect-key-id": {
            "client-id": "BcCDie6ezwfa4wyVEUieFn0s1TNIPKAB",
            "client-secret": "biY3mwdZjr8YLcTD",
            "sig_key_id": "incorrect-id-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_outsystems_sign_1
        },
        "api-incorrect-prv-key": {
            "client-id": "BcCDie6ezwfa4wyVEUieFn0s1TNIPKAB",
            "client-secret": "biY3mwdZjr8YLcTD",
            "sig_key_id": "outsystems-sign-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_invalid
        }
    },
    "SelfServeApp": {
        "id_uri": {
            "opaque": "/idam/v1/identity/token",
            "jwt": "/idam/v1/identity/token"
        },
        "default": {  # Direct to service
            "client-id": "OvYdOy3eWTeSAC3GJhvyS6GdXGG2v93H",
            "client-secret": "TwE5TGQWeniVfFhm",
            "sig_key_id": "build-client-nonprod-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_build_client
        },
        "api-default": {  # Default via API
            "client-id": "OvYdOy3eWTeSAC3GJhvyS6GdXGG2v93H",
            "client-secret": "TwE5TGQWeniVfFhm",
            "sig_key_id": "outsystems-sign-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_outsystems_sign_1
        },
        "api-incorrect-key-id": {
            "client-id": "OvYdOy3eWTeSAC3GJhvyS6GdXGG2v93H",
            "client-secret": "TwE5TGQWeniVfFhm",
            "sig_key_id": "incorrect-id-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_outsystems_sign_1
        },
        "api-incorrect-prv-key": {
            "client-id": "OvYdOy3eWTeSAC3GJhvyS6GdXGG2v93H",
            "client-secret": "TwE5TGQWeniVfFhm",
            "sig_key_id": "outsystems-sign-1",
            "sig_prv_key": pytest_conf.signkeys.sig_private_key_invalid
        }
    }
}

# Get environment suffix for reading env vars
envSuffix = ENV_NAME.upper()

# Override SERVICE_USER and SERVICE_PASS if set as ENV vars (i.e in CI/CD)
svc_usr_key = "SERVICE_USER_" + envSuffix
svc_usr_val = os.getenv(svc_usr_key)
if svc_usr_val is not None:
    SERVICE_USER = svc_usr_val
svc_psw_key = "SERVICE_PASS_" + envSuffix
svc_psw_val = os.getenv(svc_psw_key)
if svc_psw_val is not None:
    SERVICE_PASS = svc_psw_val

# Override client ID and secret if set as ENV vars (i.e in CI/CD)
for key in CLIENT_CREDENTIALS.keys():
    print(key)
    cli_id_key = key + "_CLIENT_ID_" + envSuffix
    env_cli_id = os.getenv(cli_id_key)
    if env_cli_id is not None:
        CLIENT_CREDENTIALS[key]['api-default']['client-id'] = env_cli_id
    cli_secret_key = key + "_CLIENT_SECRET_" + envSuffix
    env_cli_secret = os.getenv(cli_secret_key)
    if env_cli_secret is not None:
        CLIENT_CREDENTIALS[key]['api-default']['client-secret'] = env_cli_secret
    sig_key_id_val = os.getenv(key + "_" + "SIG_KEY_ID" + "_" + envSuffix)
    sig_prv_key_val = os.getenv(key + "_" + "SIG_PRV_KEY" + "_" + envSuffix)
    if (sig_key_id_val is not None) and (sig_prv_key_val is not None):
        CLIENT_CREDENTIALS[key]['default']['sig_key_id'] = sig_key_id_val
        CLIENT_CREDENTIALS[key]['default']['sig_prv_key'] = sig_prv_key_val

# Default signature key
sig_key_id = os.getenv("REQ_SIGN_KEYID_" + ENV_GROUP.upper())
sig_prv_key = os.getenv("REQ_SIGN_PRIVATEKEY_" + ENV_GROUP.upper())
print("sig_key_id:", sig_key_id)

# Default JWT key
jwt_key_id = os.getenv("JWT_SIGN_KEYID_" + ENV_GROUP.upper())
jwt_key_pem = os.getenv("JWT_SIGN_PRIVATEKEY_" + ENV_GROUP.upper())
JWT_ALG = 'RS256'
print("jwt_key_id:", jwt_key_id)

if sig_key_id is not None:
    # Signing create Signer
    signer = Signer({sig_key_id: ecdsa.SigningKey.from_pem(sig_prv_key, hashlib.sha256)})


def get_client_credentials(app_name, app_type="default"):
    return CLIENT_CREDENTIALS[app_name][app_type]


def find_git_root(directory):
    '''determines whether the specified directory is in a git repository and
    returns a Repo object that wraps it. Otherwise returns None'''
    while directory != '':
        if '.git' in map(lambda entry: entry.name, os.scandir(directory)):
            break

        directory = os.path.dirname(directory)

    try:
        repo = git.Repo(directory)
    except git.InvalidGitRepositoryError:
        return None

    return repo


def determine_base_path(base_path, feature_base_path):
    if(os.getenv('UNIT_TEST_FEATURE') == "True"):
        repo = find_git_root(os.getcwd())
        feature_name = repo.active_branch.name
        feature_name = feature_name.replace("/", "-")
        return feature_base_path.format(feature_name)
    else:
        return base_path


def get_env_name():
    """ dev / test / flex / prod """
    return ENV_NAME


def get_env_tier():
    """ development / testing / staging / production """
    return ENV_TIER


def get_env_group():
    """ nonprod or prod """
    return ENV_GROUP


def mocks_host_url():
    return SERVICE_PROTOCOL + "://" + MOCKS_HOST


def svc_host_url(svc_base_path=None):
    prot = SERVICE_PROTOCOL
    host_url = prot + "://" + svc_host(svc_base_path)
    return host_url


def svc_host(svc_base_path=None):
    the_host = SERVICE_HOST
    if svc_base_path is not None:
        the_host = the_host + svc_base_path
    return the_host


def api_host_url(public_host=True, base_path=None):
    host_url = SERVICE_PROTOCOL + "://" + api_host(public_host, base_path)
    return host_url


def api_host(public_host=True, base_path=None):
    the_host = API_HOST_PUBLIC
    if not public_host:
        the_host = API_HOST_PRIVAT
    if base_path is not None:
        the_host = the_host + base_path
    return the_host


def via_api():
    via_api_val = os.getenv('VIA_API', 'false')
    print("via_api:", via_api_val)
    return via_api_val.lower() == "true"


def jwt_headers(add_headers, jwt_token, app_name=None):
    # Get headers including JWT OAuth token
    headers = add_headers
    if app_name != APP_NAME_MAX_BOR or via_api():
        headers["Authorization"] = "Bearer " + jwt_token
    else:
        headers = basic_auth_headers(headers)
    return headers


def basic_auth_headers(add_headers, app_name=None, app_type=APP_TYPE_DEFAULT):
    # Get headers including Basic auth header
    headers = add_headers
    if via_api():
        client_creds = get_client_credentials(app_name, app_type)['client-id'] + ":" + get_client_credentials(app_name, app_type)['client-secret']
    else:
        client_creds = SERVICE_USER + ":" + SERVICE_PASS
    user_and_pass = b64encode(bytearray(client_creds, "UTF-8")).decode("ascii")
    headers["Authorization"] = "Basic " + user_and_pass
    return headers


def add_headers(public_host=True):
    username = os.getenv('USERNAME')
    if username is None or username == "":
        username = os.getenv('AD_USERNAME')
    headers = {
        "Cache-Control": "no-cache",
        "Content-Type": "application/json",
        "Host": api_host(public_host) if via_api() else svc_host(),
        "Pragma": "no-cache",
        "Referer": "e2etest-client",
        "x-ybs-brand-code": "YBS",
        "x-ybs-request-id": str(uuid.uuid4())
    }
    if sig_key_id is not None:
        headers["x-ybs-request-signature-key-id"] = sig_key_id
    if username is not None:
        headers["x-ybs-user-id"] = username
    return headers


def create_jwt(app_name, app_type=APP_TYPE_API_DEFAULT, scope="HELLO_READ", token_type=TOKEN_TYPE_OPAQUE,
               from_apigee=True, party_id=None, sid: uuid = uuid.uuid4()):
    if from_apigee:
        headers = {
            "x-ybs-request-id": str(uuid.uuid4()),
            "Cache-Control": "no-cache",
            "Pragma": "no-cache"
        }
        username = os.getenv('USERNAME')
        if username is not None:
            headers["x-ybs-user-id"] = username
        # Cannot currently pass a client cert to the fetch_token method, so have to do this manually.
        # client = BackendApplicationClient(client_id=client_id)
        # oauth = OAuth2Session(client=client)
        # token = oauth.fetch_token(
        #     token_url=api_domain(isMTLS) + IDENTITY_URI,
        #     headers=headers, auth=auth, cert=ref_client_cert)
        id_type = "opaque"
        if token_type == TOKEN_TYPE_JWT:
            id_type = "jwt"
        headers["Content-Type"] = "application/x-www-form-urlencoded"

        req = requests.post(
            "https://" + API_HOST_PUBLIC + CLIENT_CREDENTIALS[app_name]["id_uri"][id_type],
            auth=http_auth(app_name, app_type),
            headers=headers, data="grant_type=client_credentials")
        token_dict = req.json()

        print("oauth_token: ", token_dict)
        return token_dict['access_token']
    else:
        signing_key = jwk_from_pem(jwt_key_pem.encode())
        jwt = JWT()

        headers = {
            'kid': jwt_key_id,
            'alg': JWT_ALG
        }

        message = {
            'aud': 'DIGITAL_API',
            'iss': 'Apigee',
            'iat': time.time(),
            'client': 'SmokeTest',
            'client_id': CLIENT_CREDENTIALS[app_name][app_type]["client-id"],
            'sub': 'my-customer-id',
            'sub_type': 'system',
            'scope': scope,
            'brand_code': 'YBS',
            'channel': 'WEB',
            'verification_method': 'PASSWORD',
            'sid': str(sid)
        }
        if party_id is not None:
            message['sub'] = party_id
            message['party_id'] = party_id
            message['sub_type'] = 'customer'

        return jwt.encode(message, signing_key, JWT_ALG, headers)


def http_auth(app_name, app_type="default"):
    return HTTPBasicAuth(get_client_credentials(app_name, app_type)['client-id'],
                         get_client_credentials(app_name, app_type)['client-secret'])


def proxies():
    proxy = {
        'http': None,
        'https': None,
        'no': None,
        'no_proxy': None
    }
    env_proxy = os.getenv('PYHTTP_PROXY')
    if env_proxy is not None:
        proxy['http'] = env_proxy
    env_proxy_ssl = os.getenv('PYHTTPS_PROXY')
    if env_proxy_ssl is not None:
        proxy['https'] = env_proxy_ssl
    env_no_proxy = os.getenv('PYNO_PROXY')
    if env_no_proxy is not None:
        proxy['no'] = env_no_proxy
        proxy['no_proxy'] = env_no_proxy
    print("proxy:", proxy)
    return proxy


def validate(actual_value, expected_value, parameter_name):
    if actual_value == expected_value:
        print("Value of {} is {} as expected".format(parameter_name, actual_value))
    else:
        assert False, print(
            "Value of {} is {} while the expected is {}".format(parameter_name, actual_value, expected_value))


def read_from_file(file_name):
    json_dir = os.path.dirname(file_name)
    file_to_open = os.path.join(json_dir, file_name)
    with open(file_to_open) as json_file:
        json_data = json.load(json_file)
    return json_data


def key_exists(json_data, payload_path):
    try:
        eval("json_data" + payload_path)
        return True
    except:
        return False


def product_types():
    return ["SAVER", "FBOND"]
