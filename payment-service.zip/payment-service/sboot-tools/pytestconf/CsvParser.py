import os
import re
from collections import OrderedDict

import pandas as pd
import pytest


def csv_test_data(script_dir, csv_file_name):
    print("Name of the csv file is ", csv_file_name)

    file_to_open = os.path.join(script_dir, csv_file_name)
    # making data frame from csv file
    df = pd.read_csv(file_to_open, header=None, prefix="COLUMN", skipinitialspace=True, keep_default_na=False,
                     na_values=['_'])
    attr_list = df.COLUMN0.values

    value_at_column = ""
    payload_row_count = 0
    run_flag_index = 0
    start_payload_index = 0
    product_type_index = 0

    while value_at_column != "EndOfPayload":
        print("The value is :", attr_list[payload_row_count])
        value_at_column = attr_list[payload_row_count]

        if value_at_column == "RunFlag":
            run_flag_index = payload_row_count

        if value_at_column == "StartOfPayload":
            start_payload_index = payload_row_count

        if value_at_column == "ProductType":
            product_type_index = payload_row_count

        payload_row_count = payload_row_count + 1
        print("The total count is :", payload_row_count)

    test_data = list()
    test_data_dict = {}

    for column_number in range(1, len(df.columns)):
        if product_type_index != 0:
            product_type_list = df.iloc[product_type_index, column_number].split(",")
            product_type_count = len(product_type_list)
        else:
            product_type_list = ["SAVER"]
            product_type_count = 1

        for product_type in range(0, product_type_count):
            payload = OrderedDict()
            payload_and_details = {}
            run_flag = df.iloc[run_flag_index, column_number]
            print(run_flag)

            test_data_dict = OrderedDict()

            col_values = df.iloc[:, column_number].values

            for index in range(start_payload_index + 1, payload_row_count - 1):
                c = df.iloc[index, column_number]
                value = str(col_values[index])

                # convert into relevant data type ...ideally we don't need this now for saveapp
                patternStr = re.compile("[A-Za-z]+")
                if patternStr.fullmatch(value):
                    if value.lower() in ("true"):
                        value = bool(True)
                    elif value.lower() in ("false"):
                        value = bool(False)

                test_data_dict[attr_list[index]] = value
            for key, value in test_data_dict.items():
                if value != "NA":
                    key_ar = key.split("/")  # splitting each element with / and storing in keyAr
                    cur_dict = payload
                    el_count = 0  # elCount- this is to hold the incremented value elements in the keyAr

                    # Below for loop is to set up the current dict
                    for key_el in key_ar:
                        el_count = el_count + 1
                        if el_count < len(key_ar):
                            ar_el = None
                            if key_el.endswith("]"):  # To find out if it is a list i.e. applicants
                                key_el_ar = key_el.split("[")  # split with [
                                key_el = key_el_ar[0]  # get the first element i.e. applicants
                                ar_el = key_el_ar[1][0:-1]
                            cur_dict = cur_dict[key_el]
                            if ar_el is not None:
                                cur_dict = cur_dict[int(ar_el)]

                    last_key = key_ar[len(key_ar) - 1]  # identify the key to be inserted into current dictionary which
                    # would be the last element in the array splitted by /

                    # below is to check if the value is to be inserted into list, which dict under list it is
                    ar_no = None  # arNo- to hold which dictionary in the list is being referred i.e. 0th, 1st
                    if last_key.endswith("]"):
                        last_key_ar = last_key.split("[")
                        last_key = last_key_ar[0]
                        ar_no = last_key_ar[1][0:-1]

                    # below if else create dict/ list/ key-value entry according to test data column value
                    if value == "CreateData":  # if value is CreateData in csv column
                        if ar_no is None:  # and arNo is none meaning dict is not part of list
                            cur_dict[last_key] = {}  # then create a dict with the column name
                        else:
                            cur_dict[last_key].insert(int(ar_no), {})  # inserts a dict on arNo position
                    elif value == "CreateList":  # if value is CreateList in csv column
                        cur_dict[last_key] = []  # then create a list
                    else:
                        cur_dict[last_key] = value  # else insert the value in the current dict

            for index in range(payload_row_count, len(attr_list)):
                c = df.iloc[index, column_number]
                value = str(col_values[index])
                payload_and_details[attr_list[index]] = col_values[index]

            payload_and_details['payload'] = payload
            payload_and_details['testCaseName'] = df.iloc[0, column_number]
            payload_and_details['testCaseDescription'] = df.iloc[1, column_number]
            payload_and_details['productType'] = product_type_list[product_type]

            my_marks = []
            if "dev" in run_flag:
                my_marks.append(pytest.mark.dev)
            if "test" in run_flag:
                my_marks.append(pytest.mark.test)
            if "flex" in run_flag:
                my_marks.append(pytest.mark.flex)
            if len(my_marks) == 0:
                my_marks.append(pytest.mark.skip)

            test_data.append(pytest.param(payload_and_details, marks=my_marks))

    return test_data
