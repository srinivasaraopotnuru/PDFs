import json
import os
import time
import cx_Oracle

stagingDbConnection = None
coreDbConnection = None
foDbConnection = None
copyDbConnection = None
isaDbConnection = None

CORE_DB_USER_NAME = os.getenv('CORE_DB_USER_NAME')
CORE_DB_PASSWORD = os.getenv('CORE_DB_PASSWORD')
CORE_DB_CONNECTION_STRING = os.getenv('CORE_DB_CONNECTION_STRING')

STAGING_DB_USER_NAME = os.getenv('STAGING_DB_USER_NAME')
STAGING_DB_PASSWORD = os.getenv('STAGING_DB_PASSWORD')
STAGING_DB_CONNECTION_STRING = os.getenv('STAGING_DB_CONNECTION_STRING')

FO_DB_USER_NAME = os.getenv('FO_DB_USER_NAME')
FO_DB_PASSWORD = os.getenv('FO_DB_PASSWORD')
FO_DB_CONNECTION_STRING = os.getenv('FO_DB_CONNECTION_STRING')

COPY_DB_USER_NAME = os.getenv('COPY_DB_USER_NAME')
COPY_DB_PASSWORD = os.getenv('COPY_DB_PASSWORD')
COPY_DB_CONNECTION_STRING = os.getenv('COPY_DB_CONNECTION_STRING')

ISA_DB_USER_NAME = os.getenv('ISA_DB_USER_NAME')
ISA_DB_PASSWORD = os.getenv('ISA_DB_PASSWORD')
ISA_DB_CONNECTION_STRING = os.getenv('ISA_DB_CONNECTION_STRING')

def connect_to_db(db_user_name, db_password, db_connection_string):
    return cx_Oracle.connect(db_user_name, db_password, db_connection_string)


def get_staging_db():
    global stagingDbConnection
    if stagingDbConnection is None:
        stagingDbConnection = connect_to_db(STAGING_DB_USER_NAME, STAGING_DB_PASSWORD, STAGING_DB_CONNECTION_STRING)
    return stagingDbConnection


def get_core_db():
    global coreDbConnection
    if coreDbConnection is None:
        coreDbConnection = connect_to_db(CORE_DB_USER_NAME, CORE_DB_PASSWORD, CORE_DB_CONNECTION_STRING)
    return coreDbConnection


def get_fo_db():
    global foDbConnection
    if foDbConnection is None:
        foDbConnection = connect_to_db(FO_DB_USER_NAME, FO_DB_PASSWORD, FO_DB_CONNECTION_STRING)
    return foDbConnection

def get_copy_db():
    global copyDbConnection
    if copyDbConnection is None:
        copyDbConnection = connect_to_db(COPY_DB_USER_NAME, COPY_DB_PASSWORD, COPY_DB_CONNECTION_STRING)
    return copyDbConnection

def get_isa_transfer_db():
    global isaDbConnection
    if isaDbConnection is None:
        isaDbConnection = connect_to_db(ISA_DB_USER_NAME, ISA_DB_PASSWORD, ISA_DB_CONNECTION_STRING)
    return isaDbConnection

def get_core_data(cursor_core, sql_query, parameters=None):
    # below code block is to fetch core database values

    if parameters is None:
        cursor_core.execute(sql_query)
    else:
        cursor_core.execute(sql_query, parameters)
    column_names = {}
    field_number = 0
    for desc in cursor_core.description:
        column_names[desc[0]] = field_number
        field_number += 1

    # fetchall() fetches all the rows of a query result. It returns all the rows as a list of tuples. An empty list is returned if there is no record to fetch
    result_set_core = cursor_core.fetchall()
    return result_set_core, column_names


def get_staging_data(uuid, staging_status):
    query_status = "select STATUS from saving_applications t where t.application_data.uuid =:uuid"
    query_clob = "select APPLICATION_DATA from saving_applications t where t.application_data.uuid =:uuid"
    # staging_json_data = {}

    try:

        cursor_staging = get_staging_db().cursor()

        named_params_staging = {'uuid': uuid}
        print("named_params_staging :", named_params_staging)
        timeout = 40.0  # Keepig max time as 40 seconds
        granularity = 1.0
        end_time = time.time() + timeout  # compute the maximal end time
        status = "wrong status"  # condition check, no need to wait if condition already True
        while status not in staging_status and time.time() < end_time:  # loop until the condition is false and timeout not exhausted
            time.sleep(granularity)
            cursor_staging.execute(query_status, named_params_staging)
            result_set = cursor_staging.fetchall()
            for row in result_set:
                print("Status is :", row[0])
                status = row[0]  # check condition

        if status in staging_status:
            for clob, in cursor_staging.execute(query_clob, named_params_staging):
                data = clob.read()
                staging_json_data = json.loads(data)
                print("\nstaging_json_data :\n", json.dumps(staging_json_data))
        else:
            assert status == staging_status, "Status couldn't reach to expected status :{}".format(staging_status)

        return staging_json_data

    except cx_Oracle.DatabaseError as e:
        print("There is a problem with Oracle", e)

    get_staging_db().close()


def get_fo_db_data(cursor_fo, sql_query, parameter):
    named_params = {'parameter': parameter}
    cursor_fo.execute(sql_query, named_params)
    column_names = {}
    field_number = 0

    for desc in cursor_fo.description:
        column_names[desc[0]] = field_number
        field_number += 1

    # fetchall() fetches all the rows of a query result. It returns all the rows as a list of tuples.
    # An empty list is returned if there is no record to fetch
    result_set_fo_db = cursor_fo.fetchall()
    return result_set_fo_db, column_names

def get_copy_data(cursor_copy, sql_query, parameters=None):
    # below code block is to fetch copy database values

    if parameters is None:
        cursor_copy.execute(sql_query)
    else:
        cursor_copy.execute(sql_query, parameters)
    column_names = {}
    field_number = 0
    for desc in cursor_copy.description:
        column_names[desc[0]] = field_number
        field_number += 1

    # fetchall() fetches all the rows of a query result. It returns all the rows as a list of tuples. An empty list is returned if there is no record to fetch
    result_set_copy = cursor_copy.fetchall()
    return result_set_copy, column_names

def get_isa_transfer_data(uuid, isa_status):
    query_status = "select STATUS from  DIGITAL_ISATRN_OWNER.ISA_TRANSFERS where DIGITAL_ISATRN_OWNER.ISA_TRANSFERS.UUID = '" + uuid + "'"
    query_clob = "select TRANSFER_DATA from DIGITAL_ISATRN_OWNER.ISA_TRANSFERS where DIGITAL_ISATRN_OWNER.ISA_TRANSFERS.UUID = '" + uuid + "'"
    print("query_status: ",query_status)
    # staging_json_data = {}
    cursor_isa = get_isa_transfer_db().cursor()
    # named_params_isa = {'uuid': uuid}
    cursor_isa.execute(query_status)
    result_set = cursor_isa.fetchall()
    for row in result_set:
        print("Status is :", row[0])
        status = row[0]  # check condition


        if status in isa_status:
            for clob, in cursor_isa.execute(query_clob):
            # (id, clob) = cur.fetchone()
                data = clob.read()
                isa_json_data = json.loads(data)
                print("\nisa_json_data :\n", json.dumps(isa_json_data))

        else:
            assert status == isa_status, "Status couldn't reach to expected status :{}".format(isa_status)

        return isa_json_data


def update_table(cursor_core, sql_query, parameter):
    named_params = {'parameter': parameter}
    try:
        cursor_core.execute(sql_query, named_params)
    except cx_Oracle.DatabaseError as e:
        print("There is a problem with Oracle", e)
