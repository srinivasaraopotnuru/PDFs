package uk.co.ybs.digital.payment.service.sca.event;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;

class PaymentPlaybackFactoryTest {
  private static final String CURRENCY = "GBP";
  private static final String AMOUNT_AS_STRING = "123.45";
  private static final BigDecimal AMOUNT = new BigDecimal(AMOUNT_AS_STRING);
  private static final String REFERENCE = "reference";
  private static final String DEBTOR_ACCOUNT_NUMBER_INTERNAL = "1234567890";
  private static final String DEBTOR_SORT_CODE_INTERNAL = "998877";
  private static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL = "0123456789";
  private static final String CREDITOR_ACCOUNT_NUMBER_EXTERNAL = "12345678";
  private static final String CREDITOR_SORT_CODE_EXTERNAL = "001122";

  private Clock clock;

  private PaymentPlaybackFactory testSubject;

  @BeforeEach
  void beforeEach() {
    clock = Clock.fixed(Instant.parse("2020-01-07T13:45:00Z"), ZoneId.of("Europe/London"));
    testSubject = new PaymentPlaybackFactory(clock);
  }

  @Test
  void shouldCreatePaymentPlaybackForExternalPayment() {
    final ValidatedExternalPaymentRequest paymentRequest = externalPaymentRequestBuilder().build();

    final PaymentPlayback actual = testSubject.createPaymentPlayback(paymentRequest);

    final PaymentPlayback expected =
        PaymentPlayback.builder()
            .amount(
                PaymentPlayback.Amount.builder()
                    .amount(AMOUNT_AS_STRING)
                    .currency(CURRENCY)
                    .build())
            .instructionDate(LocalDate.parse("2020-01-07"))
            .payee(
                PaymentPlayback.Payee.builder()
                    .accountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
                    .sortCode(CREDITOR_SORT_CODE_EXTERNAL)
                    .build())
            .reference(REFERENCE)
            .source(
                PaymentPlayback.Source.builder()
                    .accountNumber(DEBTOR_ACCOUNT_NUMBER_INTERNAL)
                    .sortCode(DEBTOR_SORT_CODE_INTERNAL)
                    .build())
            .build();
    assertThat(actual, is(expected));
  }

  @Test
  void shouldCreatePaymentPlaybackForInternalPayment() {
    final ValidatedInternalPaymentRequest paymentRequest = internalPaymentRequestBuilder().build();

    final PaymentPlayback actual = testSubject.createPaymentPlayback(paymentRequest);

    final PaymentPlayback expected =
        PaymentPlayback.builder()
            .amount(
                PaymentPlayback.Amount.builder()
                    .amount(AMOUNT_AS_STRING)
                    .currency(CURRENCY)
                    .build())
            .instructionDate(LocalDate.parse("2020-01-07"))
            .payee(
                PaymentPlayback.Payee.builder()
                    .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
                    .build())
            .source(
                PaymentPlayback.Source.builder()
                    .accountNumber(DEBTOR_ACCOUNT_NUMBER_INTERNAL)
                    .build())
            .build();
    assertThat(actual, is(expected));
  }

  @ParameterizedTest
  @CsvSource({
    "123.45,123.45",
    "123.40,123.4",
    "123.4,123.4",
    "123.00,123.0",
    "123.0,123.0",
    "123,123.0"
  })
  void shouldMapAmountToStringWithCorrectNumberOfDecimalPlaces(
      final BigDecimal requestAmount, final String expectedString) {
    final ValidatedExternalPaymentRequest paymentRequest =
        externalPaymentRequestBuilder().amount(requestAmount).build();

    final PaymentPlayback actual = testSubject.createPaymentPlayback(paymentRequest);

    assertThat(actual.getAmount().getAmount(), is(expectedString));
  }

  @ParameterizedTest
  @MethodSource("referenceValues")
  void createPaymentPlaybackShouldMapReference(
      final String label, final String reference, final String expected) {
    final ValidatedExternalPaymentRequest paymentRequest =
        externalPaymentRequestBuilder().reference(reference).build();

    final PaymentPlayback paymentPlayback = testSubject.createPaymentPlayback(paymentRequest);
    assertThat(paymentPlayback.getReference(), is(expected));
  }

  static Stream<Arguments> referenceValues() {
    return Stream.of(
        Arguments.of("null", null, null),
        Arguments.of("empty", "", null),
        Arguments.of("Long value truncated", "12345678901234567890", "123456789012345678"),
        Arguments.of("whitespace stripped", "   123 abc   ", "123abc"),
        Arguments.of("accented characters stripped", "\u00E9123\u00E9abc\u00E9", "123abc"),
        Arguments.of(
            "non-word characters stripped", "!1@2£3$4%5^6&7*8", CREDITOR_ACCOUNT_NUMBER_EXTERNAL),
        Arguments.of("non-word characters stripped", "(9)0_a-b+c=d{e}f", "90abcdef"),
        Arguments.of(
            "non-word characters stripped",
            "[1]2;3:4'5\"6\\7|8",
            CREDITOR_ACCOUNT_NUMBER_EXTERNAL));
  }

  private ValidatedExternalPaymentRequest.ValidatedExternalPaymentRequestBuilder
      externalPaymentRequestBuilder() {
    return ValidatedExternalPaymentRequest.builder()
        .amount(AMOUNT)
        .creditorDetails(externalCreditorDetails())
        .currency(CURRENCY)
        .debtorAccount(debtoryAccount())
        .idempotencyKey(UUID.randomUUID())
        .reference(REFERENCE);
  }

  private ValidatedInternalPaymentRequest.ValidatedInternalPaymentRequestBuilder
      internalPaymentRequestBuilder() {
    return ValidatedInternalPaymentRequest.builder()
        .amount(AMOUNT)
        .creditorAccount(internalCreditorAccount())
        .currency(CURRENCY)
        .debtorAccount(debtoryAccount())
        .idempotencyKey(UUID.randomUUID());
  }

  private ExternalCreditorDetails externalCreditorDetails() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .name("name")
        .sortCode(CREDITOR_SORT_CODE_EXTERNAL)
        .build();
  }

  private Account debtoryAccount() {
    return Account.builder()
        .accountNumber(DEBTOR_ACCOUNT_NUMBER_INTERNAL)
        .accountSortCode(DEBTOR_SORT_CODE_INTERNAL)
        .build();
  }

  private Account internalCreditorAccount() {
    return Account.builder().accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL).build();
  }
}
