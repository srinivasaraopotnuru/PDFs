package uk.co.ybs.digital.payment.audit;

import java.io.IOException;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class AuditPaymentFailureRequestJsonTest {
  @Autowired private JacksonTester<AuditPaymentFailureRequest> json;

  @Value("classpath:api/audit/request/AuditPaymentFailure.json")
  private Resource requestFile;

  private AuditPaymentFailureRequest fullyPopulated;

  @BeforeEach
  void beforeEach() {
    fullyPopulated =
        AuditPaymentFailureRequest.builder()
            .trackingId(UUID.fromString("eea9f3ff-c521-42c5-0932-84497301206a"))
            .trackingCode("my-tracking-code")
            .ipAddress("12.66.53.145")
            .paymentDetails(
                SimplePaymentDetails.builder()
                    .uniqueReference(UUID.fromString("3bf0faa4-223f-11ea-978f-2e728ce88125"))
                    .build())
            .build();
  }

  @Test
  void canSerializeRequest() throws IOException {
    Assertions.assertThat(json.write(fullyPopulated))
        .isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @Test
  void canDeserializeRequest() throws IOException {
    Assertions.assertThat(json.read(requestFile)).isEqualTo(fullyPopulated);
  }
}
