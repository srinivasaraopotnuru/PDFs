package uk.co.ybs.digital.payment.account;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@JsonTest
class BeneficiaryJsonTest {

  @Autowired private JacksonTester<Beneficiary> tester;

  @ParameterizedTest
  @MethodSource("payloads")
  void serializes(final Beneficiary beneficiary, final Resource jsonResource) throws IOException {
    assertThat(tester.write(beneficiary)).isEqualToJson(jsonResource, JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("payloads")
  void deserializes(final Beneficiary beneficiary, final Resource jsonResource) throws IOException {
    assertThat(tester.read(jsonResource)).isEqualTo(beneficiary);
  }

  private static Stream<Arguments> payloads() {
    return Stream.of(
        Arguments.of(
            ExternalBeneficiary.builder()
                .beneficiaryId("124abc")
                .accountNumber("12345679")
                .accountSortCode("112244")
                .name("MR B TEST")
                .reference("B REF")
                .memorableName("Joint Account")
                .build(),
            new ClassPathResource("jsonTest/ExternalBeneficiary.json")),
        Arguments.of(
            InternalBeneficiary.builder().beneficiaryId("123abc").accountNumber("12345678").build(),
            new ClassPathResource("jsonTest/InternalBeneficiary.json")));
  }
}
