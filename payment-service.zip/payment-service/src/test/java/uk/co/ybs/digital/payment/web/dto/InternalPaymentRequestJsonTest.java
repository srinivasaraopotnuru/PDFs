package uk.co.ybs.digital.payment.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class InternalPaymentRequestJsonTest {

  @Autowired private JacksonTester<PaymentRequest> jacksonTester;

  @Value("classpath:jsonTest/InternalPaymentRequest.json")
  private Resource requestJsonFile;

  @Test
  void objectMapperSerializesRequest() throws IOException {
    assertThat(jacksonTester.write(buildRequest()))
        .isEqualToJson(requestJsonFile, JSONCompareMode.STRICT);
  }

  @Test
  void objectMapperDeserializesRequest() throws IOException {
    assertThat(jacksonTester.read(requestJsonFile)).isEqualTo(buildRequest());
  }

  private InternalPaymentRequest buildRequest() {
    return InternalPaymentRequest.builder()
        .idempotencyKey(UUID.fromString("abcd1234-ab65-4f3e-a3d3-abcdef123456"))
        .currency("GBP")
        .amount(new BigDecimal("100.00"))
        .debtor(Debtor.builder().accountNumber("0123456789").build())
        .creditor(
            InternalCreditorDetails.builder()
                .accountNumber("1234567890")
                .saveBeneficiary(true)
                .build())
        .build();
  }
}
