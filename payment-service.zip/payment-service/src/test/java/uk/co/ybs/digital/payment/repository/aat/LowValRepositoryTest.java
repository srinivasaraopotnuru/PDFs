package uk.co.ybs.digital.payment.repository.aat;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.payment.model.aat.ScaLvtCount;
import uk.co.ybs.digital.payment.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class LowValRepositoryTest {
  private static final Long PARTY_ID = 3714448L;
  private static final int LVT_COUNT = 6;
  private static final LocalDateTime CREATED_DATE = LocalDateTime.now();

  @Autowired LowValRepository testSubject;
  @Autowired TestEntityManager aatTestEntityManager;

  @Test
  void shouldGetLowVal() {
    Boolean acessedFlag = false;
    ScaLvtCount expectedScaLvtCount =
        ScaLvtCount.builder()
            .lvtCount(LVT_COUNT)
            .partyId(PARTY_ID)
            .accessedFlag(acessedFlag)
            .createdBy("Test")
            .createdDate(CREATED_DATE)
            .build();
    testSubject.save(expectedScaLvtCount);
    aatTestEntityManager.flush();
    aatTestEntityManager.clear();

    Optional<ScaLvtCount> scaLvtCount = testSubject.findById(PARTY_ID);

    assertThat(scaLvtCount.get().getLvtCount(), is(LVT_COUNT));
  }
}
