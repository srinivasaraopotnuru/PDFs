package uk.co.ybs.digital.payment.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_DEBTOR_ACC;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_MIN_BAL;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_PARTY_SYSID;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_CUST_WARNINGS;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_PAYMENT_ACCHLDR_ROLE;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_PAYMENT_ACC_STATUS;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_VALID_WITCD;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_WEB_ENABLED;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.SOA_PAYACC_WARNINGS;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.model.adgcore.db.AccountPaymentDetails;
import uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsException;
import uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository;

@ExtendWith(MockitoExtension.class)
class AccountPaymentDetailsServiceTest {

  private static final String BANK_ACCOUNT_NUMBER = "12345678";
  private static final Long BANK_ACCOUNT_NUMBER_AS_LONG = Long.parseLong(BANK_ACCOUNT_NUMBER);
  private static final String PARTY_ID = "123456";
  private static final Long PARTY_ID_AS_LONG = Long.parseLong(PARTY_ID);
  private static final String INVALID = "Invalid";
  private static final String NO = "No";
  private static final String VALID = "Valid";
  private static final String YES = "Yes";

  @Mock private AccountPaymentDetailsRepository accountPaymentDetailsRepository;

  private AccountPaymentDetailsService accountPaymentDetailsService;

  @BeforeEach
  void setUp() {
    accountPaymentDetailsService =
        new AccountPaymentDetailsService(accountPaymentDetailsRepository);
  }

  @Test
  void getAccountDetailsAllNegative() {

    Map<String, Object> getAccountDetailsOutputParameters =
        new HashMap<String, Object>() {
          {
            put(PN_DEBTOR_ACC, BANK_ACCOUNT_NUMBER);
            put(PN_PARTY_SYSID, PARTY_ID);
            put(PN_MIN_BAL, new BigDecimal("0.00"));
            put(PS_PAYMENT_ACC_STATUS, INVALID);
            put(PS_PAYMENT_ACCHLDR_ROLE, INVALID);
            put(SOA_PAYACC_WARNINGS, new Object[] {});
            put(PS_VALID_WITCD, INVALID);
            put(PS_WEB_ENABLED, NO);
            put(PS_CUST_WARNINGS, NO);
          }
        };

    when(accountPaymentDetailsRepository.getAccountDetails(
            BANK_ACCOUNT_NUMBER_AS_LONG, PARTY_ID_AS_LONG))
        .thenReturn(getAccountDetailsOutputParameters);

    AccountPaymentDetails accountDetails =
        accountPaymentDetailsService.getAccountDetails(BANK_ACCOUNT_NUMBER, PARTY_ID);

    AccountPaymentDetails expected =
        AccountPaymentDetails.builder()
            .minimumBalance(new BigDecimal("0.00"))
            .validPaymentAccountStatus(false)
            .validPaymentAccountHolderRole(false)
            .validWithdrawalCode(false)
            .webEnabled(false)
            .customerWarnings(false)
            .paymentAccountWarnings(Collections.emptyList())
            .build();

    assertThat(accountDetails, is(expected));
  }

  @Test
  void getAccountDetailsAllPositive() {

    AccountPaymentDetails.PaymentAccountWarning paymentAccountWarning =
        AccountPaymentDetails.PaymentAccountWarning.builder()
            .warningCode("CODE")
            .message("MESSAGE")
            .build();
    Map<String, Object> getAccountDetailsOutputParameters =
        new HashMap<String, Object>() {
          {
            put(PN_DEBTOR_ACC, BANK_ACCOUNT_NUMBER);
            put(PN_PARTY_SYSID, PARTY_ID);
            put(PN_MIN_BAL, new BigDecimal("100.00"));
            put(PS_PAYMENT_ACC_STATUS, VALID);
            put(PS_PAYMENT_ACCHLDR_ROLE, VALID);
            put(SOA_PAYACC_WARNINGS, new Object[] {paymentAccountWarning});
            put(PS_VALID_WITCD, VALID);
            put(PS_WEB_ENABLED, YES);
            put(PS_CUST_WARNINGS, YES);
          }
        };

    when(accountPaymentDetailsRepository.getAccountDetails(
            BANK_ACCOUNT_NUMBER_AS_LONG, PARTY_ID_AS_LONG))
        .thenReturn(getAccountDetailsOutputParameters);

    AccountPaymentDetails accountDetails =
        accountPaymentDetailsService.getAccountDetails(BANK_ACCOUNT_NUMBER, PARTY_ID);

    AccountPaymentDetails expected =
        AccountPaymentDetails.builder()
            .minimumBalance(new BigDecimal("100.00"))
            .validPaymentAccountStatus(true)
            .validPaymentAccountHolderRole(true)
            .validWithdrawalCode(true)
            .webEnabled(true)
            .customerWarnings(true)
            .paymentAccountWarnings(Collections.singletonList(paymentAccountWarning))
            .build();

    assertThat(accountDetails, is(expected));
  }

  @Test
  void getAccountDetailsThrowsException() {

    final String failureMessage = "Failure Message";

    when(accountPaymentDetailsRepository.getAccountDetails(
            BANK_ACCOUNT_NUMBER_AS_LONG, PARTY_ID_AS_LONG))
        .thenThrow(new AccountPaymentDetailsException(failureMessage, new Exception()));

    final AccountPaymentDetailsException exception =
        assertThrows(
            AccountPaymentDetailsException.class,
            () -> accountPaymentDetailsService.getAccountDetails(BANK_ACCOUNT_NUMBER, PARTY_ID));

    assertThat(exception.getMessage(), is(equalTo(failureMessage)));
  }
}
