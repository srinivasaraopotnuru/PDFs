package uk.co.ybs.digital.payment.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import lombok.NonNull;
import org.hibernate.exception.GenericJDBCException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.jpa.JpaSystemException;
import uk.co.ybs.digital.payment.exception.BankDetailsNotFoundException;
import uk.co.ybs.digital.payment.model.adgcore.BankDetails;
import uk.co.ybs.digital.payment.repository.adgcore.BankRepository;

@ExtendWith(MockitoExtension.class)
class BankAccountServiceTest {

  private static final String BANK_SORT_CODE = "404786";
  public static final String BANK_ACCOUNT_NUMBER = "12345678";

  @Mock private BankRepository bankRepository;

  private BankAccountService bankAccountService;

  @BeforeEach
  void setUp() {
    bankAccountService = new BankAccountService(bankRepository);
  }

  @Test
  void validSortCode() {

    Map<String, Object> getBankDetailsPackageCallOutputParameters =
        buildGetBankDetailsPackageCallOutputParameters();

    when(bankRepository.getBankDetails(Long.parseLong(BANK_SORT_CODE)))
        .thenReturn(getBankDetailsPackageCallOutputParameters);

    boolean result = bankAccountService.validSortCode(BANK_SORT_CODE);

    assertThat(result, is(true));
  }

  @Test
  void validSortCodeReturnsFalseWhenAddressNotFound() {

    when(bankRepository.getBankDetails(Long.parseLong(BANK_SORT_CODE)))
        .thenThrow(buildAddressNotFoundPackageException());

    boolean result = bankAccountService.validSortCode(BANK_SORT_CODE);

    assertThat(result, is(false));
  }

  @ParameterizedTest
  @ValueSource(strings = {"Y", "N"})
  void validAccount(final String response) {

    when(bankRepository.validateBankAccount(
            Long.parseLong(BANK_SORT_CODE), Long.parseLong(BANK_ACCOUNT_NUMBER)))
        .thenReturn(response);

    boolean result = bankAccountService.validAccount(BANK_SORT_CODE, BANK_ACCOUNT_NUMBER);

    assertThat(result, is("Y".equals(response)));
  }

  @ParameterizedTest
  @ValueSource(strings = {"Y", "N"})
  void acceptsFasterPayments(final String response) {

    when(bankRepository.acceptsFasterPayments(BANK_SORT_CODE)).thenReturn(response);

    boolean result = bankAccountService.acceptsFasterPayments(BANK_SORT_CODE);

    assertThat(result, is("Y".equals(response)));
  }

  @Test
  void getBankDetailsSucceeds() {

    Map<String, Object> getBankDetailsPackageCallOutputParameters =
        buildGetBankDetailsPackageCallOutputParameters();

    when(bankRepository.getBankDetails(Long.parseLong(BANK_SORT_CODE)))
        .thenReturn(getBankDetailsPackageCallOutputParameters);

    BankDetails result = bankAccountService.getBankDetails(BANK_SORT_CODE);

    BankDetails expected =
        BankDetails.builder()
            .name("Name")
            .branchTitle("Title")
            .addressLine1("Line1")
            .addressLine2("Line2")
            .addressLine3("Line3")
            .addressLine4("Line4")
            .addressLine5("Line5")
            .postCode("Postcode")
            .telephoneNumber("Tel Num")
            .build();

    assertThat(result, is(expected));
  }

  @Test
  void getBankDetailsFailsWithBankNotFound() {

    JpaSystemException ex = buildAddressNotFoundPackageException();

    when(bankRepository.getBankDetails(Long.parseLong(BANK_SORT_CODE))).thenThrow(ex);

    final BankDetailsNotFoundException exception =
        assertThrows(
            BankDetailsNotFoundException.class,
            () -> bankAccountService.getBankDetails(BANK_SORT_CODE));

    assertThat(
        exception.getMessage(),
        is(String.format("Bank details not found for sortcode: %s", BANK_SORT_CODE)));
  }

  @Test
  void getBankDetailsFailsWithOtherException() {

    JpaSystemException ex =
        new JpaSystemException(
            new GenericJDBCException(
                "An Error", new SQLException("Another Type Of Error", "72000"), "sql"));

    when(bankRepository.getBankDetails(404786L)).thenThrow(ex);

    final JpaSystemException exception =
        assertThrows(
            JpaSystemException.class, () -> bankAccountService.getBankDetails(BANK_SORT_CODE));

    assertThat(
        exception.getMessage(),
        is("An Error; nested exception is org.hibernate.exception.GenericJDBCException: An Error"));
  }

  @NonNull
  private JpaSystemException buildAddressNotFoundPackageException() {
    GenericJDBCException ex =
        new GenericJDBCException(
            "",
            new SQLException(
                "ORA-20022: YBS-26779:- Bank Name and Address Details Not Found- (In -   PACKAGE BODY COREOWN.SOA_VALIDATEBANKACCIDENTITY.PR_GET_BANK_DETAILS){}\n"
                    + "ORA-06512: at \"COREOWN.YBS_APPLICATION_ERROR\", line 134\n"
                    + "ORA-06512: at \"COREOWN.SOA_VALIDATEBANKACCIDENTITY\", line 185\n"
                    + "ORA-06512: at line 1",
                "72000"),
            "sql");

    return new JpaSystemException(ex);
  }

  @NonNull
  private Map<String, Object> buildGetBankDetailsPackageCallOutputParameters() {
    return new HashMap<String, Object>() {
      {
        put("PS_BANK_NAME", "Name");
        put("PS_BRANCH_TITLE", "Title");
        put("PS_BANK_ADD_LINE1", "Line1");
        put("PS_BANK_ADD_LINE2", "Line2");
        put("PS_BANK_ADD_LINE3", "Line3");
        put("PS_BANK_ADD_LINE4", "Line4");
        put("PS_BANK_ADD_LINE5", "Line5");
        put("PS_BANK_POSTCODE", "Postcode");
        put("PS_BANK_TEL_NUM", "Tel Num");
      }
    };
  }
}
