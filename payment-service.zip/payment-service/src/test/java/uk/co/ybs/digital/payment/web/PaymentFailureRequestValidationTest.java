package uk.co.ybs.digital.payment.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyIterable;
import static uk.co.ybs.digital.payment.web.PaymentRequestValidationTestHelper.fieldError;

import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;
import java.util.stream.Stream;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.Validator;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;

@SpringBootTest(
    classes = {ValidationAutoConfiguration.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
class PaymentFailureRequestValidationTest {

  @Autowired
  @Qualifier("defaultValidator")
  Validator validator;

  @Test
  void validRequestPassesValidation() {
    final PaymentFailureRequest request = builderWithPaymentFailureDetails().build();

    BindingResult bindingResult = validatePaymentFailureRequest(request);

    assertThat(bindingResult.getFieldErrors(), emptyIterable());
  }

  @Test
  void missingPaymentFailureRequestRequiredFieldsFailsValidation() {
    final PaymentFailureRequest request = PaymentFailureRequest.builder().build();

    BindingResult bindingResult = validatePaymentFailureRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("idempotencyKey", "You must specify a UUID idempotency key"),
                fieldError("debtor", "You must specify the debtor details"))));
  }

  @ParameterizedTest
  @MethodSource("debtorAccountNumberValidationArguments")
  void shouldValidateDebtorAccountNumber(
      final String accountNumber,
      final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    final PaymentFailureRequest request =
        builderWithPaymentFailureDetails()
            .debtor(Debtor.builder().accountNumber(accountNumber).build())
            .build();

    BindingResult bindingResult = validatePaymentFailureRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  private static Stream<Arguments> debtorAccountNumberValidationArguments() {
    return Stream.of(
        Arguments.of(
            "",
            contains(
                fieldError(
                    "debtor.accountNumber",
                    " is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number"))),
        Arguments.of(
            "0000000",
            contains(
                fieldError(
                    "debtor.accountNumber",
                    "0000000 is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number"))),
        Arguments.of(
            "000000000",
            contains(
                fieldError(
                    "debtor.accountNumber",
                    "000000000 is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number"))));
  }

  private BindingResult validatePaymentFailureRequest(final PaymentFailureRequest request) {
    BindingResult bindingResult = new MapBindingResult(new HashMap<>(), "request");
    validator.validate(request, bindingResult);
    return bindingResult;
  }

  private PaymentFailureRequest.PaymentFailureRequestBuilder builderWithPaymentFailureDetails() {
    return PaymentFailureRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .debtor(Debtor.builder().accountNumber("0123456789").build());
  }
}
