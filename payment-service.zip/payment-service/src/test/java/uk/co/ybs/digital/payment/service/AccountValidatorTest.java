package uk.co.ybs.digital.payment.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.UUID;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.AccountValidatorException;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;

@ExtendWith(MockitoExtension.class)
class AccountValidatorTest {
  private static final String PARTY_ID = "9876543210";
  private static final String DEBTOR_ACCOUNT_NUMBER = "0123456789";
  private static final String DEBTOR_ACCOUNT_NOT_FOUND_ERROR_MESSAGE =
      "Failed to find debtor account: " + DEBTOR_ACCOUNT_NUMBER;

  @Mock private AccountService accountService;

  @ParameterizedTest
  @ValueSource(
      classes = {
        AccountServiceEntityNotFoundException.class,
        AccountServiceEntityAccessDeniedException.class
      })
  void shouldThrowAccountValidatorExceptionWhenDebtorAccountNotFound(
      final Class<? extends Throwable> accountServiceException) {
    AccountValidator accountValidator = new AccountValidator(accountService);

    final RequestMetadata requestMetadata = buildRequestMetadata();
    final PaymentFailureRequest paymentFailureRequest = buildPaymentFailureRequest();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenThrow(accountServiceException);

    final AccountValidatorException exception =
        assertThrows(
            AccountValidatorException.class,
            () ->
                accountValidator.validateDebtorAccount(
                    paymentFailureRequest.getDebtor(), requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(DEBTOR_ACCOUNT_NOT_FOUND_ERROR_MESSAGE)));
  }

  private RequestMetadata buildRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
  }

  private PaymentFailureRequest buildPaymentFailureRequest() {
    return TestHelper.buildPaymentFailureRequest();
  }
}
