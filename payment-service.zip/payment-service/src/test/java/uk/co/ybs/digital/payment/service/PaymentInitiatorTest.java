package uk.co.ybs.digital.payment.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.service.authentic.AuthenticService;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;

@ExtendWith(MockitoExtension.class)
class PaymentInitiatorTest {
  private static final String REFERENCE = "ELECTRIC BILL";
  private static final String CHANNEL = "SAPP";
  private static final BigDecimal AMOUNT = new BigDecimal("100.00");
  private static final String CURRENCY_CODE = "GBP";
  private static final String NAME = "Mr Creditor";

  private static final String DEBTOR_ACCOUNT_NUMBER = "0123456789";
  private static final String DEBTOR_ACCOUNT_SORT_CODE = "111111";

  private static final String CREDITOR_ACCOUNT_NUMBER_EXTERNAL = "12345678";
  private static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL = "1234567890";
  private static final String CREDITOR_SORT_CODE_EXTERNAL = "332211";
  private static final String CREDITOR_SORT_CODE_INTERNAL = "112233";

  private static final UUID REQUEST_ID = UUID.fromString("38c36e91-8f48-425d-89e2-8d1fe9833834");
  private static final UUID IDEMPOTENCY_KEY =
      UUID.fromString("a21d20aa-609a-48c9-abf5-128a30600e62");

  private PaymentInitiator testSubject;

  @Mock private AuthenticService authenticService;

  @BeforeEach
  public void beforeEach() {
    testSubject = new PaymentInitiator(authenticService);
  }

  @Test
  void shouldInitiateExternalPayment() throws Exception {
    final String paymentId = "PAYMENT-CREATED";
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    ValidatedExternalPaymentRequest validatedExternalPaymentRequest = buildExternalPaymentRequest();

    when(authenticService.initiatePayment(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(paymentId);
    final String actual =
        testSubject.initiatePayment(validatedExternalPaymentRequest, requestMetadata);

    assertThat(actual, is(paymentId));
  }

  @Test
  void shouldInitiateInternalPayment() throws Exception {
    final String paymentId = "PAYMENT-CREATED";
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    ValidatedInternalPaymentRequest validatedInternalPaymentRequest = buildInternalPaymentRequest();

    when(authenticService.initiatePayment(validatedInternalPaymentRequest, requestMetadata))
        .thenReturn(paymentId);

    final String actual =
        testSubject.initiatePayment(validatedInternalPaymentRequest, requestMetadata);

    assertThat(actual, is(paymentId));
  }

  private RequestMetadata buildValidRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(REQUEST_ID, CHANNEL);
  }

  private ValidatedExternalPaymentRequest buildExternalPaymentRequest() {
    return ValidatedExternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(CURRENCY_CODE)
        .amount(AMOUNT)
        .reference(REFERENCE)
        .debtorAccount(debtorAccount())
        .creditorDetails(buildExternalCreditorDetails())
        .build();
  }

  private ExternalCreditorDetails buildExternalCreditorDetails() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .sortCode(CREDITOR_SORT_CODE_EXTERNAL)
        .name(NAME)
        .build();
  }

  private ValidatedInternalPaymentRequest buildInternalPaymentRequest() {
    return ValidatedInternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(CURRENCY_CODE)
        .amount(AMOUNT)
        .debtorAccount(debtorAccount())
        .creditorAccount(
            Account.builder()
                .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
                .accountSortCode(CREDITOR_SORT_CODE_INTERNAL)
                .build())
        .build();
  }

  private Account debtorAccount() {
    return Account.builder()
        .accountNumber(DEBTOR_ACCOUNT_NUMBER)
        .accountSortCode(DEBTOR_ACCOUNT_SORT_CODE)
        .build();
  }
}
