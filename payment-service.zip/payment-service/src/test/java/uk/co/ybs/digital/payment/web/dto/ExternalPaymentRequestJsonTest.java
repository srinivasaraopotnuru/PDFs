package uk.co.ybs.digital.payment.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class ExternalPaymentRequestJsonTest {

  @Autowired private JacksonTester<PaymentRequest> jacksonTester;

  @Value("classpath:jsonTest/ExternalPaymentRequestWithCreditorDetails.json")
  private Resource requestWithCreditorDetailsJsonFile;

  @Value("classpath:jsonTest/ExternalPaymentRequestWithCreditorBeneficiary.json")
  private Resource requestWithCreditorBeneficiaryJsonFile;

  @Value("classpath:jsonTest/ExternalPaymentRequestWithoutCreditorType.json")
  private Resource requestWithoutCreditorTypeJsonFile;

  @Test
  void objectMapperSerializesRequestWithCreditorDetails() throws IOException {
    assertThat(jacksonTester.write(buildRequestWithCreditorDetails()))
        .isEqualToJson(requestWithCreditorDetailsJsonFile, JSONCompareMode.STRICT);
  }

  @Test
  void objectMapperSerializesRequestWithCreditorBeneficiary() throws IOException {
    assertThat(jacksonTester.write(buildRequestWithCreditorBeneficiary()))
        .isEqualToJson(requestWithCreditorBeneficiaryJsonFile, JSONCompareMode.STRICT);
  }

  @Test
  void objectMapperDeserializesRequestWithCreditorDetails() throws IOException {
    assertThat(jacksonTester.read(requestWithCreditorDetailsJsonFile))
        .isEqualTo(buildRequestWithCreditorDetails());
  }

  @Test
  void objectMapperDeserializesRequestWithCreditorBeneficiary() throws IOException {
    assertThat(jacksonTester.read(requestWithCreditorBeneficiaryJsonFile))
        .isEqualTo(buildRequestWithCreditorBeneficiary());
  }

  @Test
  void objectMapperDeserializesRequestWithoutCreditorType() throws IOException {
    assertThat(jacksonTester.read(requestWithoutCreditorTypeJsonFile))
        .isEqualTo(buildRequestWithCreditorDetails());
  }

  private ExternalPaymentRequest buildRequestWithCreditorDetails() {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(UUID.fromString("abcd1234-ab65-4f3e-a3d3-abcdef123456"))
        .currency("GBP")
        .amount(new BigDecimal("100.00"))
        .reference("ELECTRIC BILL")
        .debtor(Debtor.builder().accountNumber("0123456789").build())
        .creditor(
            ExternalCreditorDetails.builder()
                .externalAccountNumber("12345678")
                .sortCode("112233")
                .name("Mr Joe Bloggs")
                .build())
        .build();
  }

  private ExternalPaymentRequest buildRequestWithCreditorBeneficiary() {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(UUID.fromString("abcd1234-ab65-4f3e-a3d3-abcdef123456"))
        .currency("GBP")
        .amount(new BigDecimal("100.00"))
        .reference("ELECTRIC BILL")
        .debtor(Debtor.builder().accountNumber("0123456789").build())
        .creditor(ExternalCreditorBeneficiary.builder().beneficiaryId("124abc").build())
        .build();
  }
}
