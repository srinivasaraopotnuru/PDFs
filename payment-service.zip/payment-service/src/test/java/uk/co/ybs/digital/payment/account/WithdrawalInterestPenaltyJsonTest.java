package uk.co.ybs.digital.payment.account;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.math.BigDecimal;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class WithdrawalInterestPenaltyJsonTest {

  @Autowired private JacksonTester<WithdrawalInterestPenalty> json;

  @Value("classpath:jsonTest/WithdrawalInterestPenalty.json")
  private Resource responseFile;

  private WithdrawalInterestPenalty withdrawalInterestPenalty;

  @BeforeEach
  void setup() {
    withdrawalInterestPenalty = new WithdrawalInterestPenalty(new BigDecimal("123.45"));
  }

  @Test
  void serializes() throws IOException {
    assertThat(json.write(withdrawalInterestPenalty))
        .isEqualToJson(responseFile, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    assertThat(json.read(responseFile)).isEqualTo(withdrawalInterestPenalty);
  }
}
