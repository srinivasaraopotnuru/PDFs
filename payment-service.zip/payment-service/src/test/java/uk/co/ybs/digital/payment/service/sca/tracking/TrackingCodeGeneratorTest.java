package uk.co.ybs.digital.payment.service.sca.tracking;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.service.sca.event.AuthenticationEvent;

@ExtendWith(MockitoExtension.class)
class TrackingCodeGeneratorTest {
  @Mock private ObjectMapper objectMapper;

  private TrackingCodeGenerator testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new TrackingCodeGenerator(objectMapper);
  }

  @Test
  void shouldGenerateTrackingCode() throws JsonProcessingException {
    final UUID authenticationEventId = UUID.fromString("6c461a33-05f3-4af5-be82-07ebf936ab25");

    final AuthenticationEvent event = authenticationEvent(authenticationEventId);

    when(objectMapper.writeValueAsString(event))
        .thenReturn("{\"authenticationEvent\":\"serialized\"}");

    final TrackingCode trackingCode = testSubject.generateTrackingCode(event);
    assertThat(
        trackingCode,
        is(
            TrackingCode.builder()
                .id(authenticationEventId)
                .code(
                    "eyJhbGciOiJIUzI1NiJ9..goY586QBkfEHBmr_2uqDh9LmU8QfGZx5dF2xLxVe0LU") // generated on https://jwt.io/
                .build()));
  }

  @Test
  void
      shouldThrowTrackingCodeGenerationExceptionWhenObjectMapperCannotSerializeAuthenticationEvent()
          throws JsonProcessingException {
    final UUID authenticationEventId = UUID.fromString("6c461a33-05f3-4af5-be82-07ebf936ab25");

    final AuthenticationEvent event = authenticationEvent(authenticationEventId);

    when(objectMapper.writeValueAsString(event))
        .thenThrow(JsonMappingException.fromUnexpectedIOE(new IOException("oops")));

    assertThrows(
        TrackingCodeGenerationException.class,
        () -> {
          testSubject.generateTrackingCode(event);
        });
  }

  private AuthenticationEvent authenticationEvent(final UUID authenticationEventId) {
    return AuthenticationEvent.builder()
        .id(authenticationEventId)
        .eventContext("eee")
        .paymentPlayback("ppp")
        .build();
  }
}
