package uk.co.ybs.digital.payment.audit;

import java.io.IOException;
import java.util.UUID;
import java.util.stream.Stream;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
class AuditPaymentAuthFailureRequestJsonTest {
  private static final UUID UNIQUE_REFERENCE =
      UUID.fromString("3bf0faa4-223f-11ea-978f-2e728ce88125");
  private static final String AUDIT_REQUEST_BASE_PATH = "api/audit/request";
  public static final String CHALLENGE_FAILURE_TYPE = "CHALLENGE";
  public static final String CLIENT_FAILURE_TYPE = "CLIENT";
  public static final String IP_ADDRESS = "12.66.53.145";
  private static final String DEBTOR_ACCOUNT_NUMBER = "1234567890";

  @Autowired private JacksonTester<AuditPaymentAuthFailureRequest> json;

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void canSerializeRequest(
      final AuditPaymentAuthFailureRequest request, final ClassPathResource requestFile)
      throws IOException {
    Assertions.assertThat(json.write(request)).isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void canDeserializeRequest(
      final AuditPaymentAuthFailureRequest request, final ClassPathResource requestFile)
      throws IOException {
    Assertions.assertThat(json.read(requestFile)).isEqualTo(request);
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(
            buildAuditPaymentFailureRequestChallengeFailureType(),
            new ClassPathResource(
                AUDIT_REQUEST_BASE_PATH
                    + "/AuditPaymentAuthenticationFailureChallengeFailureType.json")),
        Arguments.of(
            buildAuditPaymentFailureRequestClientFailureType(),
            new ClassPathResource(
                AUDIT_REQUEST_BASE_PATH
                    + "/AuditPaymentAuthenticationFailureClientFailureType.json")));
  }

  private static AuditPaymentAuthFailureRequest
      buildAuditPaymentFailureRequestChallengeFailureType() {
    return AuditPaymentAuthFailureRequest.builder()
        .paymentDetails(
            AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                .uniqueReference(UNIQUE_REFERENCE)
                .failureType(CHALLENGE_FAILURE_TYPE)
                .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                .build())
        .ipAddress(IP_ADDRESS)
        .build();
  }

  private static AuditPaymentAuthFailureRequest buildAuditPaymentFailureRequestClientFailureType() {
    return AuditPaymentAuthFailureRequest.builder()
        .paymentDetails(
            AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                .uniqueReference(UNIQUE_REFERENCE)
                .failureType(CLIENT_FAILURE_TYPE)
                .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                .build())
        .ipAddress(IP_ADDRESS)
        .build();
  }
}
