package uk.co.ybs.digital.payment.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
public class InternalAccountRequestJsonTest {

  @Autowired private JacksonTester<InternalAccountDetails> jacksonTester;

  @Value("classpath:jsonTest/InternalAccount.json")
  private Resource requestWithAccountDetailsJsonFile;

  @Test
  void objectMapperSerializesRequestWithAccountDetails() throws IOException {
    assertThat(jacksonTester.write(buildRequestWithInternalAccountDetails()))
        .isEqualToJson(requestWithAccountDetailsJsonFile, JSONCompareMode.STRICT);
  }

  @Test
  void objectMapperDeserializesRequestWithAccountDetails() throws IOException {
    assertThat(jacksonTester.read(requestWithAccountDetailsJsonFile))
        .isEqualTo(buildRequestWithInternalAccountDetails());
  }

  private InternalAccountDetails buildRequestWithInternalAccountDetails() {
    return InternalAccountDetails.builder().accountNumber("0123456789").build();
  }
}
