package uk.co.ybs.digital.payment.service.sca.event;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class AuthenticationEventJsonTest {

  @Autowired private JacksonTester<AuthenticationEvent> jacksonTester;

  @Value("classpath:jsonTest/AuthenticationEventFullyPopulated.json")
  private Resource fullyPopulated;

  private AuthenticationEvent authenticationEvent;

  @BeforeEach
  public void beforeEach() {
    authenticationEvent =
        AuthenticationEvent.builder()
            .id(UUID.fromString("9ed43549-f911-4c89-a401-594fc683e7ca"))
            .eventContext("{\"eventContext\":\"eventContextJson\"}")
            .paymentPlayback("{\"paymentPlayback\":\"paymentPlaybackJson\"}")
            .build();
  }

  @Test
  void shouldSerializeFullyPopulated() throws IOException {
    // NOTE:  The serialized json is used to compute a hash, so it is critical that we prove
    // that the serialized string is identical to what is expected (i.e. including property order
    // and whitespace)
    // This means we cannot use the normal json asserts
    assertThat(jacksonTester.write(authenticationEvent).getJson())
        .isEqualTo(IOUtils.toString(fullyPopulated.getInputStream(), StandardCharsets.UTF_8));
  }
}
