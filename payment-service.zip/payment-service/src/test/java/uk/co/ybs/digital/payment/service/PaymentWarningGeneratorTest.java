package uk.co.ybs.digital.payment.service;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.Value;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.account.InterestPenalty;
import uk.co.ybs.digital.payment.account.Isa;
import uk.co.ybs.digital.payment.account.WithdrawalInterestPenalty;
import uk.co.ybs.digital.payment.account.WithdrawalLimit;
import uk.co.ybs.digital.payment.account.Withdrawals;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.PaymentWarning;
import uk.co.ybs.digital.payment.web.dto.WarningCategory;

@ExtendWith(MockitoExtension.class)
class PaymentWarningGeneratorTest {

  private static final String ACCOUNT_NUMBER = "1234567890";
  private static final String CHANNEL = "SAPP";
  private static final RequestMetadata REQUEST_METADATA =
      TestHelper.buildValidRequestMetadata(UUID.randomUUID(), CHANNEL);
  private static final BigDecimal WITHDRAWAL_AMOUNT = new BigDecimal("123.45");

  // Withdrawal days
  private static final int WITHDRAWALS_AVAILABLE = 3;
  private static final int WITHDRAWALS_PERMITTED = 4;
  private static final LocalDate WITHDRAWALS_PERIOD_END = LocalDate.of(2020, 12, 31);
  private static final String WITHDRAWALS_PERIOD_END_DESCRIPTION = "31-Dec-2020";

  // Interest penalty
  private static final int WITHDRAWAL_INTEREST_PENALTY_DAYS = 30;
  private static final BigDecimal WITHDRAWAL_INTEREST_PENALTY_VALUE = new BigDecimal("10.50");

  @InjectMocks private PaymentWarningGenerator testSubject;

  @Mock private AccountService accountService;

  @Test
  void generateShouldReturnEmptyListForAccountWithoutWarnings() {
    final Account debtorAccount = buildAccountWithoutWarnings();
    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);
    final List<PaymentWarning> expectedWarnings = Collections.emptyList();

    final List<PaymentWarning> warnings =
        testSubject.generate(
            validatedPaymentRequest,
            TestHelper.buildValidRequestMetadata(UUID.randomUUID(), CHANNEL));
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoInteractions(accountService);
  }

  @Test
  void generateShouldReturnFlexibleIsaWarning() {
    final Account debtorAccount =
        buildAccountWithoutWarnings().toBuilder().isa(Isa.builder().flexible(true).build()).build();
    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);
    final List<PaymentWarning> expectedWarnings =
        Collections.singletonList(
            PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA_FLEXIBLE).build());

    final List<PaymentWarning> warnings =
        testSubject.generate(
            validatedPaymentRequest,
            TestHelper.buildValidRequestMetadata(UUID.randomUUID(), CHANNEL));
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoInteractions(accountService);
  }

  @Test
  void generateShouldReturnHelpToBuyIsaWarning() {
    final Account debtorAccount =
        buildAccountWithoutWarnings()
            .toBuilder()
            .isa(Isa.builder().helpToBuy(true).build())
            .build();
    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);
    final List<PaymentWarning> expectedWarnings =
        Collections.singletonList(
            PaymentWarning.builder()
                .code(WarningCategory.DEBTOR_WITHDRAWAL_ISA_HELP_TO_BUY)
                .build());

    final List<PaymentWarning> warnings =
        testSubject.generate(
            validatedPaymentRequest,
            TestHelper.buildValidRequestMetadata(UUID.randomUUID(), CHANNEL));
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoInteractions(accountService);
  }

  @Test
  void generateShouldReturnClassicIsaWarning() {
    final Account debtorAccount =
        buildAccountWithoutWarnings().toBuilder().isa(Isa.builder().build()).build();
    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);
    final List<PaymentWarning> expectedWarnings =
        Collections.singletonList(
            PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA).build());

    final List<PaymentWarning> warnings =
        testSubject.generate(
            validatedPaymentRequest,
            TestHelper.buildValidRequestMetadata(UUID.randomUUID(), CHANNEL));
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoInteractions(accountService);
  }

  @Test
  void generateShouldReturnFlexibleIsaWarningWhenBothFlexibleAndHelpToBuy() {
    final Account debtorAccount =
        buildAccountWithoutWarnings()
            .toBuilder()
            .isa(Isa.builder().flexible(true).helpToBuy(true).build())
            .build();
    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);
    final List<PaymentWarning> expectedWarnings =
        Collections.singletonList(
            PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA_FLEXIBLE).build());

    final List<PaymentWarning> warnings =
        testSubject.generate(
            validatedPaymentRequest,
            TestHelper.buildValidRequestMetadata(UUID.randomUUID(), CHANNEL));
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoInteractions(accountService);
  }

  @Test
  void generateShouldReturnInterestPenaltyWarning() {
    final Account debtorAccount =
        buildAccountWithoutWarnings()
            .toBuilder()
            .withdrawals(
                Withdrawals.builder()
                    .interestPenalty(
                        InterestPenalty.builder().days(WITHDRAWAL_INTEREST_PENALTY_DAYS).build())
                    .build())
            .build();
    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);
    final List<PaymentWarning> expectedWarnings =
        Collections.singletonList(
            PaymentWarning.builder()
                .code(WarningCategory.DEBTOR_WITHDRAWAL_INTEREST_PENALTY)
                .parameters(
                    PaymentWarning.Parameters.builder()
                        .days(WITHDRAWAL_INTEREST_PENALTY_DAYS)
                        .amount(WITHDRAWAL_INTEREST_PENALTY_VALUE)
                        .build())
                .build());

    when(accountService.getWithdrawalInterestPenalty(
            ACCOUNT_NUMBER, WITHDRAWAL_AMOUNT, REQUEST_METADATA))
        .thenReturn(new WithdrawalInterestPenalty(WITHDRAWAL_INTEREST_PENALTY_VALUE));

    final List<PaymentWarning> warnings =
        testSubject.generate(validatedPaymentRequest, REQUEST_METADATA);
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoMoreInteractions(accountService);
  }

  @Test
  void generateShouldReturnWithdrawalDaysWarning() {
    final Account debtorAccount =
        buildAccountWithoutWarnings()
            .toBuilder()
            .withdrawals(
                Withdrawals.builder()
                    .limit(
                        WithdrawalLimit.builder()
                            .available(WITHDRAWALS_AVAILABLE)
                            .permitted(WITHDRAWALS_PERMITTED)
                            .periodEnd(WITHDRAWALS_PERIOD_END)
                            .build())
                    .build())
            .build();
    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);
    final List<PaymentWarning> expectedWarnings =
        Collections.singletonList(
            PaymentWarning.builder()
                .code(WarningCategory.DEBTOR_WITHDRAWAL_DAYS)
                .displayMessage(
                    "You have "
                        + WITHDRAWALS_AVAILABLE
                        + " withdrawal days remaining until "
                        + WITHDRAWALS_PERIOD_END_DESCRIPTION)
                .build());

    final List<PaymentWarning> warnings =
        testSubject.generate(
            validatedPaymentRequest,
            TestHelper.buildValidRequestMetadata(UUID.randomUUID(), CHANNEL));
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoInteractions(accountService);
  }

  @Test
  void generateShouldReturnWithdrawalDaysWarningWithoutPeriodEnd() {
    final Account debtorAccount =
        buildAccountWithoutWarnings()
            .toBuilder()
            .withdrawals(
                Withdrawals.builder()
                    .limit(
                        WithdrawalLimit.builder()
                            .available(WITHDRAWALS_AVAILABLE)
                            .permitted(WITHDRAWALS_PERMITTED)
                            .build())
                    .build())
            .build();
    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);
    final List<PaymentWarning> expectedWarnings =
        Collections.singletonList(
            PaymentWarning.builder()
                .code(WarningCategory.DEBTOR_WITHDRAWAL_DAYS)
                .displayMessage("You have " + WITHDRAWALS_AVAILABLE + " withdrawal days remaining")
                .build());

    final List<PaymentWarning> warnings =
        testSubject.generate(
            validatedPaymentRequest,
            TestHelper.buildValidRequestMetadata(UUID.randomUUID(), CHANNEL));
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoInteractions(accountService);
  }

  @Test
  void generateShouldReturnAllWarningTypesSortedByCode() {
    final Account debtorAccount =
        buildAccountWithoutWarnings()
            .toBuilder()
            .isa(Isa.builder().flexible(true).build())
            .withdrawals(
                Withdrawals.builder()
                    .interestPenalty(
                        InterestPenalty.builder().days(WITHDRAWAL_INTEREST_PENALTY_DAYS).build())
                    .limit(
                        WithdrawalLimit.builder()
                            .available(WITHDRAWALS_AVAILABLE)
                            .permitted(WITHDRAWALS_PERMITTED)
                            .periodEnd(WITHDRAWALS_PERIOD_END)
                            .build())
                    .build())
            .build();

    final ValidatedPaymentRequest validatedPaymentRequest =
        new ConcreteValidatedPaymentRequest(WITHDRAWAL_AMOUNT, debtorAccount);

    final List<PaymentWarning> expectedWarnings =
        Arrays.asList(
            PaymentWarning.builder()
                .code(WarningCategory.DEBTOR_WITHDRAWAL_DAYS)
                .displayMessage(
                    "You have "
                        + WITHDRAWALS_AVAILABLE
                        + " withdrawal days remaining until "
                        + WITHDRAWALS_PERIOD_END_DESCRIPTION)
                .build(),
            PaymentWarning.builder()
                .code(WarningCategory.DEBTOR_WITHDRAWAL_INTEREST_PENALTY)
                .parameters(
                    PaymentWarning.Parameters.builder()
                        .days(WITHDRAWAL_INTEREST_PENALTY_DAYS)
                        .amount(WITHDRAWAL_INTEREST_PENALTY_VALUE)
                        .build())
                .build(),
            PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA_FLEXIBLE).build());

    when(accountService.getWithdrawalInterestPenalty(
            ACCOUNT_NUMBER, WITHDRAWAL_AMOUNT, REQUEST_METADATA))
        .thenReturn(new WithdrawalInterestPenalty(WITHDRAWAL_INTEREST_PENALTY_VALUE));

    final List<PaymentWarning> warnings =
        testSubject.generate(validatedPaymentRequest, REQUEST_METADATA);
    assertThat(warnings, equalTo(expectedWarnings));
    verifyNoMoreInteractions(accountService);
  }

  private static Account buildAccountWithoutWarnings() {
    return Account.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .withdrawals(Withdrawals.builder().build())
        .build();
  }

  @Value
  @EqualsAndHashCode(callSuper = true)
  @ToString(callSuper = true)
  private static class ConcreteValidatedPaymentRequest extends ValidatedPaymentRequest {
    public ConcreteValidatedPaymentRequest(final BigDecimal amount, final Account debtorAccount) {
      super(UUID.randomUUID(), "GBP", amount, debtorAccount);
    }

    @Override
    public <R> R accept(final ValidatedPaymentRequestVisitor<R> visitor) {
      throw new UnsupportedOperationException();
    }
  }
}
