package uk.co.ybs.digital.payment.service.sca.event;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.ExemptReasonCode;
import uk.co.ybs.digital.payment.audit.sca.Sca;

@JsonTest
class EventContextJsonTest {

  @Autowired private JacksonTester<EventContext> jacksonTester;

  @Value("classpath:jsonTest/EventContextFullyPopulated.json")
  private Resource fullyPopulated;

  @Value("classpath:jsonTest/EventContextWithMissingOptionalProperties.json")
  private Resource withMissingOptionalProperties;

  @Test
  void shouldSerializeFullyPopulated() throws IOException {
    final EventContext eventContext =
        EventContext.builder()
            .channel("channel")
            .eventType(EventContext.Type.PAYMENT_TRANSACTION)
            .sca(
                Sca.builder()
                    .decisionStatus(DecisionStatus.APPLIED)
                    .exemptReasonCode(ExemptReasonCode.LOWVAL)
                    .build())
            .subEventType(EventContext.SubType.SINGLE)
            .transactionReferenceId(UUID.fromString("7bf98529-008a-4e64-b4e6-98fd0d1e092f"))
            .build();

    // NOTE:  The serialized json is used to compute a hash, so it is critical that we prove
    // that the serialized string is identical to what is expected (i.e. including property order
    // and whitespace)
    // This means we cannot use the normal json asserts
    assertThat(jacksonTester.write(eventContext).getJson())
        .isEqualTo(IOUtils.toString(fullyPopulated.getInputStream(), StandardCharsets.UTF_8));
  }

  @Test
  void shouldSerializeWithMissingOptionalProperties() throws IOException {
    final EventContext eventContext =
        EventContext.builder()
            .channel("channel")
            .eventType(EventContext.Type.PAYMENT_TRANSACTION)
            .sca(Sca.builder().decisionStatus(DecisionStatus.APPLIED).build())
            .subEventType(EventContext.SubType.SINGLE)
            .transactionReferenceId(UUID.fromString("7bf98529-008a-4e64-b4e6-98fd0d1e092f"))
            .build();

    // NOTE:  The serialized json is used to compute a hash, so it is critical that we prove
    // that the serialized string is identical to what is expected (i.e. including property order
    // and whitespace)
    // This means we cannot use the normal json asserts
    assertThat(jacksonTester.write(eventContext).getJson())
        .isEqualTo(
            IOUtils.toString(
                withMissingOptionalProperties.getInputStream(), StandardCharsets.UTF_8));
  }
}
