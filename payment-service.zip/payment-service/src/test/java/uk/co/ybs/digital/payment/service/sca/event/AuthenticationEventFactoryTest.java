package uk.co.ybs.digital.payment.service.sca.event;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.Sca;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;

@ExtendWith(MockitoExtension.class)
class AuthenticationEventFactoryTest {
  private static final String REFERENCE = "reference";
  private static final String SAPP_CHANNEL = "SAPP";
  private static final String PAYMENT_PLAYBACK_JSON = "{\"payment\":\"serialized\"}";
  private static final String EVENT_CONTEXT_JSON = "{\"eventContext\":\"serialized\"}";

  private AuthenticationEventFactory testSubject;

  @Mock private ObjectMapper objectMapper;
  @Mock private EventContextFactory eventContextFactory;
  @Mock private PaymentPlaybackFactory paymentPlaybackFactory;

  @BeforeEach
  void beforeEach() {
    testSubject =
        new AuthenticationEventFactory(objectMapper, eventContextFactory, paymentPlaybackFactory);
  }

  @Test
  void shouldCreateAuthenticationEventForExternalPaymentRequest() throws JsonProcessingException {
    final UUID idempotencyKey = UUID.randomUUID();
    final ValidatedExternalPaymentRequest paymentRequest = externalPaymentRequest(idempotencyKey);
    final String channel = SAPP_CHANNEL;

    final EventContext eventContext = mappedEventContext(idempotencyKey, channel);
    when(eventContextFactory.createSinglePaymentScaEventContext(
            idempotencyKey, channel, null, null))
        .thenReturn(eventContext);
    when(objectMapper.writeValueAsString(eventContext)).thenReturn(EVENT_CONTEXT_JSON);

    final PaymentPlayback paymentPlayback = mappedPaymentPlayback();
    when(paymentPlaybackFactory.createPaymentPlayback(paymentRequest)).thenReturn(paymentPlayback);
    when(objectMapper.writeValueAsString(paymentPlayback)).thenReturn(PAYMENT_PLAYBACK_JSON);

    final AuthenticationEvent authenticationEvent =
        testSubject.createAuthenticationEvent(paymentRequest, channel);
    assertThat(authenticationEvent.getId(), is(notNullValue()));
    assertThat(authenticationEvent.getEventContext(), is(EVENT_CONTEXT_JSON));
    assertThat(authenticationEvent.getPaymentPlayback(), is(PAYMENT_PLAYBACK_JSON));
  }

  @Test
  void shouldCreateAuthenticationEventForInternalPaymentRequest() throws JsonProcessingException {
    final UUID idempotencyKey = UUID.randomUUID();
    final ValidatedInternalPaymentRequest paymentRequest = internalPaymentRequest(idempotencyKey);
    final String channel = SAPP_CHANNEL;

    final EventContext eventContext = mappedEventContext(idempotencyKey, channel);
    when(eventContextFactory.createSinglePaymentScaEventContext(
            idempotencyKey, channel, null, null))
        .thenReturn(eventContext);
    when(objectMapper.writeValueAsString(eventContext)).thenReturn(EVENT_CONTEXT_JSON);

    final PaymentPlayback paymentPlayback = mappedPaymentPlayback();
    when(paymentPlaybackFactory.createPaymentPlayback(paymentRequest)).thenReturn(paymentPlayback);
    when(objectMapper.writeValueAsString(paymentPlayback)).thenReturn(PAYMENT_PLAYBACK_JSON);

    final AuthenticationEvent authenticationEvent =
        testSubject.createAuthenticationEvent(paymentRequest, channel);
    assertThat(authenticationEvent.getId(), is(notNullValue()));
    assertThat(authenticationEvent.getEventContext(), is(EVENT_CONTEXT_JSON));
    assertThat(authenticationEvent.getPaymentPlayback(), is(PAYMENT_PLAYBACK_JSON));
  }

  @Test
  void shouldThrowAuthenticationEventMappingExceptionWhenCannotSerializeEventContext()
      throws JsonProcessingException {
    final UUID idempotencyKey = UUID.randomUUID();
    final ValidatedExternalPaymentRequest paymentRequest = externalPaymentRequest(idempotencyKey);
    final String channel = SAPP_CHANNEL;

    final EventContext eventContext = mappedEventContext(idempotencyKey, channel);
    when(eventContextFactory.createSinglePaymentScaEventContext(
            idempotencyKey, channel, null, null))
        .thenReturn(eventContext);
    when(objectMapper.writeValueAsString(eventContext))
        .thenThrow(JsonMappingException.fromUnexpectedIOE(new IOException("oops")));

    assertThrows(
        AuthenticationEventCreationException.class,
        () -> {
          testSubject.createAuthenticationEvent(paymentRequest, channel);
        });
  }

  @Test
  void shouldThrowAuthenticationEventCreationExceptionWhenCannotSerializePaymentPlayback()
      throws JsonProcessingException {
    final UUID idempotencyKey = UUID.randomUUID();
    final ValidatedExternalPaymentRequest paymentRequest = externalPaymentRequest(idempotencyKey);
    final String channel = SAPP_CHANNEL;

    final EventContext eventContext = mappedEventContext(idempotencyKey, channel);
    when(eventContextFactory.createSinglePaymentScaEventContext(
            idempotencyKey, channel, null, null))
        .thenReturn(eventContext);
    when(objectMapper.writeValueAsString(eventContext)).thenReturn(EVENT_CONTEXT_JSON);

    final PaymentPlayback paymentPlayback = mappedPaymentPlayback();
    when(paymentPlaybackFactory.createPaymentPlayback(paymentRequest)).thenReturn(paymentPlayback);
    when(objectMapper.writeValueAsString(paymentPlayback))
        .thenThrow(JsonMappingException.fromUnexpectedIOE(new IOException("oops")));

    assertThrows(
        AuthenticationEventCreationException.class,
        () -> {
          testSubject.createAuthenticationEvent(paymentRequest, channel);
        });
  }

  private ValidatedExternalPaymentRequest externalPaymentRequest(final UUID idempotencyKey) {
    return ValidatedExternalPaymentRequest.builder()
        .amount(BigDecimal.TEN)
        .creditorDetails(externalCreditorDetails())
        .reference(REFERENCE)
        .currency("GBP")
        .debtorAccount(debtoryAccount())
        .idempotencyKey(idempotencyKey)
        .build();
  }

  private ExternalCreditorDetails externalCreditorDetails() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber("12345678")
        .sortCode("332211")
        .build();
  }

  private ValidatedInternalPaymentRequest internalPaymentRequest(final UUID idempotencyKey) {
    return ValidatedInternalPaymentRequest.builder()
        .amount(BigDecimal.TEN)
        .creditorAccount(Account.builder().accountNumber("0987654321").build())
        .currency("GBP")
        .debtorAccount(debtoryAccount())
        .idempotencyKey(idempotencyKey)
        .build();
  }

  private Account debtoryAccount() {
    return Account.builder().accountNumber("1234567890").accountSortCode("112233").build();
  }

  private EventContext mappedEventContext(final UUID idempotencyKey, final String channel) {
    return EventContext.builder()
        .eventType(EventContext.Type.PAYMENT_TRANSACTION)
        .channel(channel)
        .sca(Sca.builder().decisionStatus(DecisionStatus.APPLIED).build())
        .subEventType(EventContext.SubType.SINGLE)
        .transactionReferenceId(idempotencyKey)
        .build();
  }

  private PaymentPlayback mappedPaymentPlayback() {
    return PaymentPlayback.builder()
        .amount(PaymentPlayback.Amount.builder().amount("10.0").currency("GBP").build())
        .instructionDate(LocalDate.now())
        .payee(PaymentPlayback.Payee.builder().accountNumber("12345678").build())
        .source(PaymentPlayback.Source.builder().accountNumber("1234567890").build())
        .build();
  }
}
