package uk.co.ybs.digital.payment.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.AccountDetailsFilter;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.account.Balance;
import uk.co.ybs.digital.payment.account.DepositLimit;
import uk.co.ybs.digital.payment.account.Deposits;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.account.InternalBeneficiary;
import uk.co.ybs.digital.payment.account.Withdrawals;
import uk.co.ybs.digital.payment.beneficiary.BeneficiaryService;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNoCustomerRelationshipException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.BeneficiaryServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.InvalidPaymentException;
import uk.co.ybs.digital.payment.exception.UnexpectedReferenceException;
import uk.co.ybs.digital.payment.model.adgcore.db.AccountPaymentDetails;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequestVisitor;

@ExtendWith(MockitoExtension.class)
class PaymentValidatorTest {

  private static final UUID IDEMPOTENCY_KEY = UUID.randomUUID();
  private static final String BRAND_CODE = "YBS";
  private static final BigDecimal AMOUNT = new BigDecimal("100.00");
  private static final BigDecimal TEST_AMOUNT = new BigDecimal("10.00");
  private static final BigDecimal LESS_THAN_AMOUNT = new BigDecimal("99.99");
  private static final BigDecimal MAX_PRODUCT_BALANCE = new BigDecimal("1000.00");
  private static final BigDecimal MAX_PRODUCT_BALANCE_TEST_AMOUNT = new BigDecimal("1200.00");
  private static final BigDecimal EXCEEDED_MAX_PRODUCT_BALANCE_AMOUNT = new BigDecimal("1100.00");
  private static final String REFERENCE = "ELECTRIC BILL";
  private static final String NEW_REFERENCE_FROM_REQUEST = "NEW REFERENCE";
  private static final String CURRENCY_CODE = "GBP";
  private static final String PARTY_ID = "9876543210";
  private static final String DEBTOR_ACCOUNT_NUMBER = "0123456789";
  private static final String DEBTOR_SORT_CODE = "609204";
  private static final String DEBTOR_ACCOUNT_NOT_ALLOWED_WITHDRAWALS_ERROR_MESSAGE =
      "Debtor account " + DEBTOR_ACCOUNT_NUMBER + " withdrawals are not permitted over api";
  private static final String DEBTOR_ACCOUNT_NOT_FOUND_ERROR_MESSAGE =
      "Failed to find debtor account: " + DEBTOR_ACCOUNT_NUMBER;

  private static final String CREDITOR_ACCOUNT_NUMBER_EXTERNAL = "12345678";
  private static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL = "1234567890";
  private static final String CREDITOR_SORT_CODE_INTERNAL = "112233";
  public static final String CREDITORS_SORT_CODE_IS_INTERNAL_MESSAGE =
      "Creditor sort code "
          + CREDITOR_SORT_CODE_INTERNAL
          + " is a YBS internal sort code, so payment should be made with internal account number";
  private static final String CREDITOR_SORT_CODE_EXTERNAL = "332211";
  private static final String CREDITOR_BENEFICIARY_ID = "123abc";

  private static final String CREDITOR_ACCOUNT_NOT_ALLOWED_DEPOSITS_ERROR_MESSAGE =
      "Creditor account "
          + CREDITOR_ACCOUNT_NUMBER_INTERNAL
          + " deposits are not permitted over api";
  private static final String CREDITOR_ACCOUNT_DEPOSIT_LIMIT_ERROR_MESSAGE =
      "Creditor account "
          + CREDITOR_ACCOUNT_NUMBER_INTERNAL
          + " available deposit limit 99.99 exceeded";
  private static final String CREDITOR_ACCOUNT_NOT_FOUND_ERROR_MESSAGE =
      "Failed to find creditor account: " + CREDITOR_ACCOUNT_NUMBER_INTERNAL;
  private static final String CHELSEA_SORT_CODE = "609595";
  private static final String CREDITORS_SORT_CODE_MUST_BE_IN_SORT_CODE_DIRECTORY_MESSAGE =
      "Creditor's Sort Code must be in sort code directory";
  private static final String CREDITORS_ACCOUNT_NUMBER_MUST_BE_VALID_MESSAGE =
      "Creditor's Account Number must be valid";
  private static final String
      CREDITORS_ACCOUNT_MUST_BE_AN_ACCOUNT_THAT_CAN_RECEIVE_AN_FASTER_PAYMENTS_MESSAGE =
          "Creditor's Account must be an account that can receive an faster payments";

  private PaymentValidator paymentValidator;

  @Mock private AccountService accountService;
  @Mock private BeneficiaryService beneficiaryService;
  @Mock private BrandSortCodeMappings brandSortCodeMappings;
  @Mock private AccountPaymentDetailsService accountPaymentDetailsService;
  @Mock private BankAccountService bankAccountService;

  @BeforeEach
  void setUp() {
    paymentValidator =
        new PaymentValidator(
            accountService,
            beneficiaryService,
            brandSortCodeMappings,
            accountPaymentDetailsService,
            bankAccountService);
  }

  @Test
  void shouldValidateExternalPayee() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final ExternalCreditorDetails externalPayee = buildExternalPayee();

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_EXTERNAL, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_EXTERNAL))
        .thenReturn(false);

    paymentValidator.validateExternalCreditor(externalPayee, requestMetadata);
  }

  @Test
  void shouldRejectValidatingExternalPayeeWithSortCodeForBrand() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final ExternalCreditorDetails externalPayee = buildExternalPayeeWithBrandSortCode();

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_INTERNAL))
        .thenReturn(true);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validateExternalCreditor(externalPayee, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(CREDITORS_SORT_CODE_IS_INTERNAL_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT_INTERNAL_SORT_CODE));

    verifyNoInteractions(bankAccountService);
  }

  @Test
  void shouldValidateExternalPaymentWithCreditorDetails() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalPaymentRequest paymentRequest = buildExternalPaymentRequestWithCreditorDetails();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_EXTERNAL, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_EXTERNAL))
        .thenReturn(false);

    final ValidatedExternalPaymentRequest validatedPaymentRequest =
        paymentValidator.validatePayment(paymentRequest, requestMetadata);
    assertThat(
        validatedPaymentRequest,
        is(
            ValidatedExternalPaymentRequest.builder()
                .idempotencyKey(IDEMPOTENCY_KEY)
                .amount(AMOUNT)
                .currency(CURRENCY_CODE)
                .creditorDetails(buildExternalCreditorDetails())
                .debtorAccount(debtorAccount)
                .reference(REFERENCE)
                .build()));
  }

  @Test
  void shouldValidateExternalPaymentWithCreditorBeneficiary() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalBeneficiary externalBeneficiary = buildExternalBeneficiary();
    final ExternalPaymentRequest paymentRequest =
        buildExternalPaymentRequestWithCreditorBeneficiary();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_EXTERNAL, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    when(beneficiaryService.getBeneficiary(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_BENEFICIARY_ID, requestMetadata))
        .thenReturn(externalBeneficiary);
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_EXTERNAL))
        .thenReturn(false);

    final ValidatedExternalPaymentRequest validatedPaymentRequest =
        paymentValidator.validatePayment(paymentRequest, requestMetadata);
    assertThat(
        validatedPaymentRequest,
        is(
            ValidatedExternalPaymentRequest.builder()
                .idempotencyKey(IDEMPOTENCY_KEY)
                .amount(AMOUNT)
                .currency(CURRENCY_CODE)
                .creditorDetails(buildExternalCreditorDetails())
                .debtorAccount(debtorAccount)
                .reference(REFERENCE)
                .beneficiary(externalBeneficiary)
                .build()));
  }

  @Test
  void shouldValidateWebChannelExternalPaymentWithCreditorBeneficiaryWithReference() {
    final RequestMetadata requestMetadataWithWebChannel = buildRequestMetadataWithWebChannel();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalBeneficiary externalBeneficiary = buildExternalBeneficiary();
    final ExternalPaymentRequest paymentRequest =
        buildExternalPaymentRequestWithCreditorBeneficiary()
            .toBuilder()
            .reference(NEW_REFERENCE_FROM_REQUEST)
            .build();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadataWithWebChannel))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_EXTERNAL, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    when(beneficiaryService.getBeneficiary(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_BENEFICIARY_ID, requestMetadataWithWebChannel))
        .thenReturn(externalBeneficiary);
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_EXTERNAL))
        .thenReturn(false);

    final ValidatedExternalPaymentRequest validatedPaymentRequest =
        paymentValidator.validatePayment(paymentRequest, requestMetadataWithWebChannel);

    assertThat(
        validatedPaymentRequest,
        is(
            ValidatedExternalPaymentRequest.builder()
                .idempotencyKey(IDEMPOTENCY_KEY)
                .amount(AMOUNT)
                .currency(CURRENCY_CODE)
                .creditorDetails(buildExternalCreditorDetails())
                .debtorAccount(debtorAccount)
                .reference(NEW_REFERENCE_FROM_REQUEST)
                .beneficiary(externalBeneficiary)
                .build()));
  }

  @Test
  void shouldValidateWebChannelExternalPaymentWithCreditorBeneficiaryWithoutReference() {
    final RequestMetadata requestMetadataWithWebChannel = buildRequestMetadataWithWebChannel();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalBeneficiary externalBeneficiary = buildExternalBeneficiary();
    final ExternalPaymentRequest paymentRequest =
        buildExternalPaymentRequestWithCreditorBeneficiary();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadataWithWebChannel))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_EXTERNAL, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    when(beneficiaryService.getBeneficiary(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_BENEFICIARY_ID, requestMetadataWithWebChannel))
        .thenReturn(externalBeneficiary);
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_EXTERNAL))
        .thenReturn(false);

    final ValidatedExternalPaymentRequest validatedPaymentRequest =
        paymentValidator.validatePayment(paymentRequest, requestMetadataWithWebChannel);

    assertThat(
        validatedPaymentRequest,
        is(
            ValidatedExternalPaymentRequest.builder()
                .idempotencyKey(IDEMPOTENCY_KEY)
                .amount(AMOUNT)
                .currency(CURRENCY_CODE)
                .creditorDetails(buildExternalCreditorDetails())
                .debtorAccount(debtorAccount)
                .reference(REFERENCE)
                .beneficiary(externalBeneficiary)
                .build()));
  }

  @ParameterizedTest
  @ValueSource(
      classes = {
        AccountServiceEntityNotFoundException.class,
        AccountServiceEntityAccessDeniedException.class
      })
  void shouldRejectExternalPaymentWhenCannotFindDebtorAccount(
      final Class<? extends Throwable> accountServiceException) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final ExternalPaymentRequest paymentRequest = buildExternalPaymentRequestWithCreditorDetails();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenThrow(accountServiceException);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(DEBTOR_ACCOUNT_NOT_FOUND_ERROR_MESSAGE)));
    assertThat(
        exception.getReasons(), containsInAnyOrder(InvalidPaymentException.Reason.DEBTOR_ACCOUNT));

    verifyNoInteractions(accountPaymentDetailsService);
    verifyNoInteractions(bankAccountService);
  }

  @Test
  void shouldRejectExternalPaymentForDebtorAccountWithdrawalsNotPermittedOverApi() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(false);
    final ExternalPaymentRequest paymentRequest = buildExternalPaymentRequestWithCreditorDetails();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(), is(equalTo(DEBTOR_ACCOUNT_NOT_ALLOWED_WITHDRAWALS_ERROR_MESSAGE)));
    assertThat(
        exception.getReasons(), containsInAnyOrder(InvalidPaymentException.Reason.DEBTOR_ACCOUNT));

    verifyNoInteractions(accountPaymentDetailsService);
    verifyNoInteractions(bankAccountService);
  }

  @Test
  void shouldRejectExternalPaymentToCreditorDetailsWithInternalSortCodeForBrand() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalPaymentRequest paymentRequest =
        buildExternalPaymentRequestWithCreditorDetailsAndInternalSortCode();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_INTERNAL))
        .thenReturn(true);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(CREDITORS_SORT_CODE_IS_INTERNAL_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT_INTERNAL_SORT_CODE));
  }

  @Test
  void shouldRejectExternalPaymentToCreditorDetailsWhenExternalSortCodeNotFound() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalPaymentRequest paymentRequest = buildExternalPaymentRequestWithCreditorDetails();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_EXTERNAL))
        .thenReturn(false);

    stubValidateSortCode(CREDITOR_SORT_CODE_EXTERNAL, false);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(equalTo(CREDITORS_SORT_CODE_MUST_BE_IN_SORT_CODE_DIRECTORY_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));
  }

  @Test
  void shouldRejectExternalPaymentToCreditorDetailsWhenExternalAccountNotValid() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalPaymentRequest paymentRequest = buildExternalPaymentRequestWithCreditorDetails();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_EXTERNAL))
        .thenReturn(false);

    stubValidateSortCode(CREDITOR_SORT_CODE_EXTERNAL, true);
    stubValidateAccount(CREDITOR_SORT_CODE_EXTERNAL, CREDITOR_ACCOUNT_NUMBER_EXTERNAL, false);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(CREDITORS_ACCOUNT_NUMBER_MUST_BE_VALID_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));
  }

  @Test
  void shouldRejectExternalPaymentToCreditorDetailsWhenExternalBankDoesNotAcceptFasterPayments() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalPaymentRequest paymentRequest = buildExternalPaymentRequestWithCreditorDetails();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_EXTERNAL))
        .thenReturn(false);

    stubValidateSortCode(CREDITOR_SORT_CODE_EXTERNAL, true);
    stubValidateAccount(CREDITOR_SORT_CODE_EXTERNAL, CREDITOR_ACCOUNT_NUMBER_EXTERNAL, true);
    stubAcceptsFasterPayments(CREDITOR_SORT_CODE_EXTERNAL, false);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(
            equalTo(
                CREDITORS_ACCOUNT_MUST_BE_AN_ACCOUNT_THAT_CAN_RECEIVE_AN_FASTER_PAYMENTS_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));
  }

  @Test
  void shouldRejectExternalPaymentToCreditorBeneficiaryWithInternalSortCodeForBrand() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalBeneficiary externalBeneficiary = buildExternalBeneficiaryWithInternalSortCode();
    final ExternalPaymentRequest paymentRequest =
        buildExternalPaymentRequestWithCreditorBeneficiary();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);
    when(beneficiaryService.getBeneficiary(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_BENEFICIARY_ID, requestMetadata))
        .thenReturn(externalBeneficiary);
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CREDITOR_SORT_CODE_INTERNAL))
        .thenReturn(true);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(CREDITORS_SORT_CODE_IS_INTERNAL_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT_INTERNAL_SORT_CODE));
  }

  private void stubValidateCreditorDependenciesSuccess() {
    stubGetAccountPaymentDetails(true, true);
  }

  private void stubValidateExternalAccountDependenciesSuccess(
      @SuppressWarnings("SameParameterValue") final String sortCode,
      @SuppressWarnings("SameParameterValue") final String accountNumber) {

    stubValidateSortCode(sortCode, true);
    stubValidateAccount(sortCode, accountNumber, true);
    stubAcceptsFasterPayments(sortCode, true);
  }

  private void stubGetAccountPaymentDetails(
      final boolean validAccountHolderRole, final boolean validWithdrawalCode) {

    when(accountPaymentDetailsService.getAccountDetails(eq(DEBTOR_ACCOUNT_NUMBER), eq(PARTY_ID)))
        .thenReturn(
            AccountPaymentDetails.builder()
                .minimumBalance(new BigDecimal("100"))
                .validPaymentAccountStatus(true)
                .validPaymentAccountHolderRole(validAccountHolderRole)
                .validWithdrawalCode(validWithdrawalCode)
                .webEnabled(true)
                .customerWarnings(false)
                .paymentAccountWarnings(Collections.emptyList())
                .build());
  }

  @Test
  void shouldRejectExternalPaymentWithCreditorBeneficiaryReferencingInternalBeneficiary() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final InternalBeneficiary internalBeneficiary =
        InternalBeneficiary.builder()
            .beneficiaryId(CREDITOR_BENEFICIARY_ID)
            .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
            .build();
    final ExternalPaymentRequest paymentRequest =
        buildExternalPaymentRequestWithCreditorBeneficiary();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(beneficiaryService.getBeneficiary(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_BENEFICIARY_ID, requestMetadata))
        .thenReturn(internalBeneficiary);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(),
        is("External payment references internal beneficiary: " + CREDITOR_BENEFICIARY_ID));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));

    verifyNoInteractions(bankAccountService);
  }

  @Test
  void shouldRejectExternalPaymentWithCreditorBeneficiaryAndReference() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalPaymentRequest paymentRequest =
        buildExternalPaymentRequestWithCreditorBeneficiary()
            .toBuilder()
            .reference(REFERENCE)
            .build();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    final UnexpectedReferenceException exception =
        assertThrows(
            UnexpectedReferenceException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), startsWith("Request contains reference and beneficiary: "));

    verifyNoInteractions(bankAccountService);
  }

  @Test
  void shouldRejectExternalPaymentWhenCannotFindBeneficiary() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final ExternalPaymentRequest paymentRequest =
        buildExternalPaymentRequestWithCreditorBeneficiary();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(beneficiaryService.getBeneficiary(
            DEBTOR_ACCOUNT_NUMBER, CREDITOR_BENEFICIARY_ID, requestMetadata))
        .thenThrow(BeneficiaryServiceEntityNotFoundException.class);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(
            "Failed to find creditor beneficiary: "
                + CREDITOR_BENEFICIARY_ID
                + " - account number: "
                + DEBTOR_ACCOUNT_NUMBER));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));
    assertThat(exception.getCause(), isA(BeneficiaryServiceEntityNotFoundException.class));

    verifyNoInteractions(bankAccountService);
  }

  @ParameterizedTest
  @MethodSource("validInternalPaymentCreditorAccounts")
  void shouldValidateInternalPayment(final Account creditorAccount) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenReturn(creditorAccount);

    final ValidatedInternalPaymentRequest validatedPaymentRequest =
        paymentValidator.validatePayment(paymentRequest, requestMetadata);
    assertThat(
        validatedPaymentRequest,
        is(
            ValidatedInternalPaymentRequest.builder()
                .idempotencyKey(IDEMPOTENCY_KEY)
                .amount(AMOUNT)
                .currency(CURRENCY_CODE)
                .debtorAccount(debtorAccount)
                .creditorAccount(creditorAccount)
                .build()));
  }

  private static Stream<Arguments> validInternalPaymentCreditorAccounts() {
    return Stream.of(
        // no deposit limit
        Arguments.of(buildCreditorAccount(buildDeposits(true))),
        // deposit limit not exceeded by requested amount
        Arguments.of(buildCreditorAccount(buildDepositsWithLimit(AMOUNT))),
        // null deposit limit
        Arguments.of(buildCreditorAccount(buildDepositsWithLimit(null))),
        // null max product balance limit deposit limit
        Arguments.of(buildCreditorAccount(buildDepositsWithMaxProductBalance(null))),
        // deposit limit not exceeded by max product balance limit deposit limit
        Arguments.of(buildCreditorAccount(buildDepositsWithMaxProductBalance(MAX_PRODUCT_BALANCE))),
        // Fully populated
        Arguments.of(buildCreditorAccount(buildDepositsLimits(true, AMOUNT, MAX_PRODUCT_BALANCE))),
        // a possible combination
        Arguments.of(buildCreditorAccount(buildDepositsLimits(true, null, MAX_PRODUCT_BALANCE))),
        // all nulls
        Arguments.of(buildCreditorAccount(buildDepositsLimits(true, null, null))),
        // a possible combination
        Arguments.of(buildCreditorAccount(buildDepositsLimits(true, AMOUNT, null))));
  }

  @ParameterizedTest
  @ValueSource(
      classes = {
        AccountServiceEntityNotFoundException.class,
        AccountServiceEntityAccessDeniedException.class
      })
  void shouldRejectInternalPaymentWhenCannotFindDebtorAccount(
      final Class<? extends Throwable> accountServiceException) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenThrow(accountServiceException);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(DEBTOR_ACCOUNT_NOT_FOUND_ERROR_MESSAGE)));
    assertThat(
        exception.getReasons(), containsInAnyOrder(InvalidPaymentException.Reason.DEBTOR_ACCOUNT));

    verifyNoInteractions(accountPaymentDetailsService);
  }

  private static Stream<Arguments> paymentRequests() {
    return Stream.of(
        Arguments.of(buildInternalPaymentRequest()),
        Arguments.of(buildExternalPaymentRequestWithCreditorDetails()));
  }

  @ParameterizedTest
  @MethodSource("paymentRequests") // NOPMD
  void shouldRejectPaymentWhenSessionBrandDoesNotMatchCreditorAccountBrand(
      final PaymentRequest paymentRequest) {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Account debtorAccount =
        buildDebtorAccount(true).toBuilder().accountSortCode(CHELSEA_SORT_CODE).build();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, CHELSEA_SORT_CODE)).thenReturn(false);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentRequest.accept(new ValidatePaymentVisitor(requestMetadata)));

    assertThat(
        exception.getMessage(), is(equalTo("Customers brand code must match account brand code")));
    assertThat(
        exception.getReasons(), containsInAnyOrder(InvalidPaymentException.Reason.DEBTOR_ACCOUNT));
  }

  @ParameterizedTest
  @MethodSource("paymentRequests") // NOPMD
  void shouldRejectPaymentWhenInvalidAccountHolderRole(final PaymentRequest paymentRequest) {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Account debtorAccount = buildDebtorAccount(true);

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubGetAccountPaymentDetails(false, true);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentRequest.accept(new ValidatePaymentVisitor(requestMetadata)));

    assertThat(exception.getMessage(), is(equalTo("Invalid Debtor's Account holder status")));
    assertThat(
        exception.getReasons(), containsInAnyOrder(InvalidPaymentException.Reason.DEBTOR_ACCOUNT));
  }

  @ParameterizedTest
  @MethodSource("paymentRequests") // NOPMD
  void shouldRejectPaymentWhenMultipleSignatoriesRequired(final PaymentRequest paymentRequest) {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Account debtorAccount = buildDebtorAccount(true);

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubGetAccountPaymentDetails(true, false);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentRequest.accept(new ValidatePaymentVisitor(requestMetadata)));

    assertThat(
        exception.getMessage(),
        is(equalTo("Invalid Withdrawal Instruction Type for Debtor Account")));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(
            InvalidPaymentException.Reason.DEBTOR_ACCOUNT_MULTIPLE_SIGNATORIES_REQUIRED));
  }

  @ParameterizedTest
  @MethodSource("paymentRequests") // NOPMD
  void shouldRejectPaymentWhenAmountOverBalance(final PaymentRequest paymentRequest) {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Account debtorAccount =
        buildDebtorAccount(true)
            .toBuilder()
            .balances(
                Arrays.asList(
                    Balance.builder().type("InterimAvailable").amount(TEST_AMOUNT).build(),
                    Balance.builder().type("InterimBooked").amount(TEST_AMOUNT).build()))
            .build();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubGetAccountPaymentDetails(true, true);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentRequest.accept(new ValidatePaymentVisitor(requestMetadata)));

    assertThat(
        exception.getMessage(),
        is(equalTo("Payment amount must be less than or equal to Debtor's Available Balance")));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.DEBTOR_ACCOUNT_INSUFFICIENT_FUNDS));
  }

  @ParameterizedTest
  @MethodSource("paymentRequests") // NOPMD
  void shouldRejectPaymentWhenAAccountHasNoBalance(final PaymentRequest paymentRequest) {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final Account debtorAccount =
        buildDebtorAccount(true).toBuilder().balances(Collections.emptyList()).build();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubGetAccountPaymentDetails(true, true);

    final IllegalArgumentException exception =
        assertThrows(
            IllegalArgumentException.class,
            () -> paymentRequest.accept(new ValidatePaymentVisitor(requestMetadata)));

    assertThat(
        exception.getMessage(),
        is(
            equalTo(
                String.format(
                    "Failed to find Interim for account %s: %s",
                    debtorAccount, debtorAccount.getBalances()))));
  }

  @Test
  void shouldValidateInternalPaymentWhenCreditorAccountHasNoCustomerRelationship() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final Account creditorAccount = buildCreditorAccount(buildDeposits(true));

    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenThrow(AccountServiceEntityNoCustomerRelationshipException.class);
    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Arrays.asList(
                AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT, AccountDetailsFilter.OTHER_ACCOUNT),
            requestMetadata))
        .thenReturn(creditorAccount);

    paymentValidator.validatePayment(paymentRequest, requestMetadata);
  }

  @Test
  void shouldRejectInternalPaymentForDebtorAccountWithdrawalsNotPermittedOverApi() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(false);
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(), is(equalTo(DEBTOR_ACCOUNT_NOT_ALLOWED_WITHDRAWALS_ERROR_MESSAGE)));
    assertThat(
        exception.getReasons(), containsInAnyOrder(InvalidPaymentException.Reason.DEBTOR_ACCOUNT));
  }

  @Test
  void shouldRejectInternalPaymentForDebtorAccountWhenPaymentExceedsOtherCreditorDepositLimit() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();

    Account creditorAccount =
        buildCreditorAccount(buildDepositsLimits(true, TEST_AMOUNT, (MAX_PRODUCT_BALANCE)));

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubValidateCreditorDependenciesSuccess();

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenThrow(
            new AccountServiceEntityNoCustomerRelationshipException(
                String.format(
                    "Party %s doesn't have customer relationship to access %s",
                    requestMetadata.getPartyId(), CREDITOR_ACCOUNT_NUMBER_INTERNAL)));

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Arrays.asList(
                AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT, AccountDetailsFilter.OTHER_ACCOUNT),
            requestMetadata))
        .thenReturn(creditorAccount);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(equalTo("Creditor account 1234567890 available deposit limit 10.00 exceeded")));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));
  }
  // cause a max balance product issue and test that the generated exception is  correctly rewritten
  @Test
  void shouldInvokeMaxProductRethrowException() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();

    Account creditorAccount =
        buildCreditorAccount(buildDepositsLimits(true, new BigDecimal("100.00"), TEST_AMOUNT));

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    stubValidateCreditorDependenciesSuccess();

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenThrow(
            new AccountServiceEntityNoCustomerRelationshipException(
                String.format(
                    "Party %s doesn't have customer relationship to access %s",
                    requestMetadata.getPartyId(), CREDITOR_ACCOUNT_NUMBER_INTERNAL)));

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Arrays.asList(
                AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT, AccountDetailsFilter.OTHER_ACCOUNT),
            requestMetadata))
        .thenReturn(creditorAccount);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(
            equalTo(
                "Creditor account 1234567890 maximum product balance 10.00 exceeded amount being processed 100.00")));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));
  }

  @ParameterizedTest
  @ValueSource(
      classes = {
        AccountServiceEntityNotFoundException.class,
        AccountServiceEntityAccessDeniedException.class
      })
  void shouldRejectInternalPaymentWhenCannotFindCreditorAccount(
      final Class<? extends Throwable> accountServiceException) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();
    final Account debtorAccount = buildDebtorAccount(true);

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenThrow(accountServiceException);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(CREDITOR_ACCOUNT_NOT_FOUND_ERROR_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));

    verify(accountService, never())
        .getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.OTHER_ACCOUNT),
            requestMetadata);
  }

  @ParameterizedTest
  @ValueSource(
      classes = {
        AccountServiceEntityNotFoundException.class,
        AccountServiceEntityAccessDeniedException.class
      })
  void shouldRejectInternalPaymentWhenAccountServiceThrowsExceptionWhenOtherAccountFilterWasPresent(
      final Class<? extends Throwable> accountServiceException) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();
    final Account debtorAccount = buildDebtorAccount(true);

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenThrow(AccountServiceEntityNoCustomerRelationshipException.class);
    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Arrays.asList(
                AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT, AccountDetailsFilter.OTHER_ACCOUNT),
            requestMetadata))
        .thenThrow(accountServiceException);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(CREDITOR_ACCOUNT_NOT_FOUND_ERROR_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));
  }

  @Test
  void shouldRejectInternalPaymentForCreditorAccountDepositNotPermittedOverApi() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final Account creditorAccount = buildCreditorAccount(buildDeposits(false));
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenReturn(creditorAccount);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(), is(equalTo(CREDITOR_ACCOUNT_NOT_ALLOWED_DEPOSITS_ERROR_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT));
  }

  @Test
  void shouldRejectInternalPaymentForAmountExceedsCreditorDepositLimit() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final Account creditorAccount = buildCreditorAccount(buildDepositsWithLimit(LESS_THAN_AMOUNT));
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest();

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenReturn(creditorAccount);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(CREDITOR_ACCOUNT_DEPOSIT_LIMIT_ERROR_MESSAGE)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.CREDITOR_ACCOUNT_DEPOSIT_LIMIT));
  }

  @ParameterizedTest
  @MethodSource("shouldValidateInternalPaymentAgainstMaxProductBalanceLimitArguments")
  void shouldValidateInternalPaymentAgainstMaxProductBalanceLimit(
      final Account creditorAccount, final BigDecimal amount) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest(amount);

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenReturn(creditorAccount);

    final ValidatedInternalPaymentRequest validatedPaymentRequest =
        paymentValidator.validatePayment(paymentRequest, requestMetadata);

    assertThat(
        validatedPaymentRequest,
        is(
            ValidatedInternalPaymentRequest.builder()
                .idempotencyKey(IDEMPOTENCY_KEY)
                .amount(amount)
                .currency(CURRENCY_CODE)
                .debtorAccount(debtorAccount)
                .creditorAccount(creditorAccount)
                .build()));
  }

  private static Stream<Arguments>
      shouldValidateInternalPaymentAgainstMaxProductBalanceLimitArguments() {
    return Stream.of(

        // Test that a transaction will be processed if it is below the maximum product
        // balance.
        Arguments.of(
            buildCreditorAccount(buildDepositsLimits(true, AMOUNT, MAX_PRODUCT_BALANCE)), AMOUNT),
        // Test that a transaction is still processed correctly is there is an empty transaction and
        // a valid max product balance this account.
        Arguments.of(
            buildCreditorAccount(buildDepositsLimits(true, null, MAX_PRODUCT_BALANCE)), AMOUNT),
        // Test to that a transaction is still made if there is an empty max product balance
        // remaining for this account.
        Arguments.of(buildCreditorAccount(buildDepositsLimits(true, AMOUNT, null)), AMOUNT),

        // Attempt to make a deposit that will come within a penny of the max product
        // balance.shouldValidateInternalPaymentAgainstMaxProductBalanceLimit,
        Arguments.of(
            buildCreditorAccount(buildDepositsWithMaxProductBalance(MAX_PRODUCT_BALANCE)),
            new BigDecimal("999.99")));
  }

  @Test
  void shouldRejectInternalPaymentForAmountExceedsMaxProductBalance() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final Account debtorAccount = buildDebtorAccount(true);
    final Account creditorAccount =
        buildCreditorAccount(
            buildDepositsLimits(true, MAX_PRODUCT_BALANCE_TEST_AMOUNT, MAX_PRODUCT_BALANCE));
    final InternalPaymentRequest paymentRequest =
        buildInternalPaymentRequest(EXCEEDED_MAX_PRODUCT_BALANCE_AMOUNT);

    when(accountService.getAccount(DEBTOR_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(debtorAccount);

    stubValidateCreditorDependenciesSuccess();
    when(brandSortCodeMappings.isSortCodeForBrand(BRAND_CODE, DEBTOR_SORT_CODE)).thenReturn(true);

    when(accountService.getAccount(
            CREDITOR_ACCOUNT_NUMBER_INTERNAL,
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            requestMetadata))
        .thenReturn(creditorAccount);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    final String expectedFailMessage =
        "Creditor account "
            + creditorAccount.getAccountNumber()
            + " maximum product balance "
            + creditorAccount.getDeposits().getLimit().getMaxProductBalRemaining()
            + " exceeded amount being processed "
            + EXCEEDED_MAX_PRODUCT_BALANCE_AMOUNT;
    assertThat(exception.getMessage(), is(equalTo(expectedFailMessage)));

    assertThat(
        exception.getReasons(),
        containsInAnyOrder(
            InvalidPaymentException.Reason.CREDITOR_ACCOUNT_MAX_PRODUCT_BALANCE_EXCEEDED));
  }

  @Test
  void shouldRejectInternalPaymentForCreditorAccountSameAsDebtorAccount() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final InternalPaymentRequest paymentRequest =
        buildInternalPaymentRequest(DEBTOR_ACCOUNT_NUMBER);

    final InvalidPaymentException exception =
        assertThrows(
            InvalidPaymentException.class,
            () -> paymentValidator.validatePayment(paymentRequest, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(equalTo("Debtor and creditor account are the same: " + DEBTOR_ACCOUNT_NUMBER)));
    assertThat(
        exception.getReasons(),
        containsInAnyOrder(InvalidPaymentException.Reason.DEBTOR_AND_CREDITOR_ACCOUNT_SAME));
  }

  private RequestMetadata buildRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(IDEMPOTENCY_KEY, PARTY_ID);
  }

  private RequestMetadata buildRequestMetadataWithWebChannel() {
    return TestHelper.buildValidRequestMetadataWithChannel(
        IDEMPOTENCY_KEY, UUID.randomUUID(), PARTY_ID, "127.0.0.1", "WEB");
  }

  private ExternalCreditorDetails buildExternalPayee() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .sortCode(CREDITOR_SORT_CODE_EXTERNAL)
        .build();
  }

  private ExternalCreditorDetails buildExternalPayeeWithBrandSortCode() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .sortCode(CREDITOR_SORT_CODE_INTERNAL)
        .build();
  }

  private static ExternalPaymentRequest buildExternalPaymentRequestWithCreditorDetails() {
    return buildExternalPaymentRequestWithCreditorDetails(CREDITOR_SORT_CODE_EXTERNAL);
  }

  private static ExternalPaymentRequest
      buildExternalPaymentRequestWithCreditorDetailsAndInternalSortCode() {
    return buildExternalPaymentRequestWithCreditorDetails(CREDITOR_SORT_CODE_INTERNAL);
  }

  private Account buildDebtorAccount(final boolean withdrawalPermittedOverApi) {
    return Account.builder()
        .accountNumber(DEBTOR_ACCOUNT_NUMBER)
        .accountSortCode(DEBTOR_SORT_CODE)
        .withdrawals(Withdrawals.builder().permittedOverApi(withdrawalPermittedOverApi).build())
        .balances(
            Arrays.asList(
                Balance.builder()
                    .type("InterimAvailable")
                    .amount(new BigDecimal("100000.00"))
                    .build(),
                Balance.builder()
                    .type("InterimBooked")
                    .amount(new BigDecimal("100000.00"))
                    .build()))
        .build();
  }

  private static Deposits buildDeposits(final boolean depositPermittedOverApi) {
    return buildDepositsLimits(depositPermittedOverApi, null, null);
  }

  private static Deposits buildDepositsWithLimit(final BigDecimal available) {
    return buildDepositsLimits(true, available, null);
  }

  private static Deposits buildDepositsWithMaxProductBalance(final BigDecimal maxProductBalance) {
    return buildDepositsLimits(true, null, maxProductBalance);
  }

  private static Deposits buildDepositsLimits(
      final boolean permittedOverApi,
      final BigDecimal available,
      final BigDecimal maxProductBalRemaining) {
    return Deposits.builder()
        .permittedOverApi(permittedOverApi)
        .limit(
            DepositLimit.builder()
                .available(available)
                .maxProductBalRemaining(maxProductBalRemaining)
                .build())
        .build();
  }

  private static Account buildCreditorAccount(final Deposits deposits) {
    return Account.builder()
        .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
        .accountSortCode(CREDITOR_SORT_CODE_INTERNAL)
        .deposits(deposits)
        .build();
  }

  private ExternalCreditorDetails buildExternalCreditorDetails() {
    return buildExternalCreditorDetails(CREDITOR_SORT_CODE_EXTERNAL);
  }

  private static ExternalCreditorDetails buildExternalCreditorDetails(
      final String creditorSortCode) {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .sortCode(creditorSortCode)
        .name("Mr Joe Bloggs")
        .build();
  }

  private static ExternalPaymentRequest buildExternalPaymentRequestWithCreditorDetails(
      final String creditorSortCode) {
    return buildExternalPaymentRequest(buildExternalCreditorDetails(creditorSortCode), REFERENCE);
  }

  private ExternalPaymentRequest buildExternalPaymentRequestWithCreditorBeneficiary() {
    return buildExternalPaymentRequest(
        ExternalCreditorBeneficiary.builder().beneficiaryId(CREDITOR_BENEFICIARY_ID).build(), null);
  }

  private static ExternalPaymentRequest buildExternalPaymentRequest(
      final ExternalCreditor creditor, final String reference) {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(CURRENCY_CODE)
        .amount(AMOUNT)
        .reference(reference)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(creditor)
        .build();
  }

  private ExternalBeneficiary buildExternalBeneficiary() {
    return buildExternalBeneficiary(CREDITOR_SORT_CODE_EXTERNAL);
  }

  private ExternalBeneficiary buildExternalBeneficiaryWithInternalSortCode() {
    return buildExternalBeneficiary(CREDITOR_SORT_CODE_INTERNAL);
  }

  private ExternalBeneficiary buildExternalBeneficiary(final String sortCode) {
    return ExternalBeneficiary.builder()
        .beneficiaryId(CREDITOR_BENEFICIARY_ID)
        .accountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .accountSortCode(sortCode)
        .name("Mr Joe Bloggs")
        .reference(REFERENCE)
        .build();
  }

  private static InternalPaymentRequest buildInternalPaymentRequest() {
    return buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
  }

  private static InternalPaymentRequest buildInternalPaymentRequest(
      final String creditorAccountNumber) {
    return buildInternalPaymentRequest(creditorAccountNumber, AMOUNT);
  }

  private static InternalPaymentRequest buildInternalPaymentRequest(final BigDecimal amount) {
    return buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, amount);
  }

  private static InternalPaymentRequest buildInternalPaymentRequest(
      final String creditorAccountNumber, final BigDecimal amount) {
    return InternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(CURRENCY_CODE)
        .amount(amount)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(InternalCreditorDetails.builder().accountNumber(creditorAccountNumber).build())
        .build();
  }

  private void stubValidateSortCode(final String sortCode, final boolean valid) {
    when(bankAccountService.validSortCode(eq(sortCode))).thenReturn(valid);
  }

  private void stubValidateAccount(
      final String sortCode, final String accountNumber, final boolean valid) {
    when(bankAccountService.validAccount(eq(sortCode), eq(accountNumber))).thenReturn(valid);
  }

  private void stubAcceptsFasterPayments(
      final String sortCode, final boolean acceptsFasterPayments) {
    when(bankAccountService.acceptsFasterPayments(eq(sortCode))).thenReturn(acceptsFasterPayments);
  }

  @AllArgsConstructor
  private class ValidatePaymentVisitor implements PaymentRequestVisitor<ValidatedPaymentRequest> {
    @NonNull private final RequestMetadata requestMetaData;

    @Override
    public ValidatedPaymentRequest visit(final ExternalPaymentRequest paymentRequest) {
      return paymentValidator.validatePayment(paymentRequest, requestMetaData);
    }

    @Override
    public ValidatedPaymentRequest visit(final InternalPaymentRequest paymentRequest) {
      return paymentValidator.validatePayment(paymentRequest, requestMetaData);
    }
  }
}
