package uk.co.ybs.digital.payment.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class PaymentFailureRequestJsonTest {
  @Autowired private JacksonTester<PaymentFailureRequest> jacksonTester;

  private PaymentFailureRequest paymentFailureRequest;

  @Value("classpath:jsonTest/PaymentFailureRequest.json")
  private Resource paymentFailureRequestJsonFile;

  @BeforeEach
  void setUp() {
    paymentFailureRequest =
        PaymentFailureRequest.builder()
            .idempotencyKey(UUID.fromString("abcd1234-ab65-4f3e-a3d3-abcdef123456"))
            .debtor(Debtor.builder().accountNumber("0123456789").build())
            .build();
  }

  @Test
  void serializes() throws IOException {
    assertThat(jacksonTester.write(paymentFailureRequest))
        .isEqualToJson(paymentFailureRequestJsonFile);
  }

  @Test
  void deserializes() throws IOException {
    assertThat(jacksonTester.read(paymentFailureRequestJsonFile)).isEqualTo(paymentFailureRequest);
  }
}
