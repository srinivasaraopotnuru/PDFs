package uk.co.ybs.digital.payment.service.authentic;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidAccount;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidRequestMetadata;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidatedExternalPaymentRequest;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidatedExternalPaymentRequestEmptyReference;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidatedExternalPaymentRequestNullReference;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidatedInternalPaymentRequest;
import static uk.co.ybs.digital.payment.utils.TestHelper.readClassPathResource;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.Diff;
import uk.co.ybs.digital.payment.config.AuthenticConfig;
import uk.co.ybs.digital.payment.config.PaymentServiceConfig;
import uk.co.ybs.digital.payment.exception.InitiatePaymentServiceException;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.utils.ServiceRandomPortInitializer;

@SpringBootTest(
    classes = {AuthenticService.class, AuthenticConfig.class, PaymentServiceConfig.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AuthenticServiceTest {

  private static final String INITIATE_PAYMENT_SERVICE_EXCEPTION = "Initiate payment error: 3";

  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling authentic service";

  private static final String EMPTY_RESPONSE_MESSAGE = "Authentic service returned empty response";
  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String PARTY_ID = "6666666";
  private static final String DEFAULT_FILE_LOCATION = "api/authentic/payment/";

  private static final Instant CLOCK_INSTANT_1 = Instant.parse("2022-02-04T13:49:58.111Z");
  private static final Instant CLOCK_INSTANT_2 = Instant.parse("2022-02-04T13:59:07.007Z");
  private static final ZoneId CLOCK_ZONE_ID = ZoneId.of("Europe/London");

  @MockBean private Clock clock;

  private MockWebServer mockAuthenticWebAuth;

  @Autowired private AuthenticService authenticService;

  private static final UUID REQUEST_ID = UUID.fromString("38c36e91-8f48-425d-89e2-8d1fe9833834");

  @Value("${uk.co.ybs.digital.authentic.webauth.port}")
  private int webAuthTestPort;

  @BeforeEach
  void setUp() throws IOException {
    mockAuthenticWebAuth = new MockWebServer();
    mockAuthenticWebAuth.start(webAuthTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockAuthenticWebAuth.shutdown();
  }

  private static Stream<Arguments> paymentRequests() {
    return Stream.of(
        Arguments.of(
            buildValidatedExternalPaymentRequest(buildValidAccount()), "OneOffPaymentRequest.xml"),
        Arguments.of(
            buildValidatedExternalPaymentRequestEmptyReference(buildValidAccount()),
            "OneOffPaymentRequestEmptyReference.xml"),
        Arguments.of(
            buildValidatedExternalPaymentRequestNullReference(buildValidAccount()),
            "OneOffPaymentRequestEmptyReference.xml"));
  }

  @MethodSource("paymentRequests")
  @ParameterizedTest
  void shouldInitiateExternalPaymentSuccess(
      final ValidatedExternalPaymentRequest paymentRequest, final String expected)
      throws Exception {
    stubAuthenticService(DEFAULT_FILE_LOCATION + "OneOffPaymentResponse.xml");

    when(clock.instant()).thenReturn(CLOCK_INSTANT_1);
    when(clock.getZone()).thenReturn(CLOCK_ZONE_ID);

    String actualResponse =
        authenticService.initiatePayment(
            paymentRequest,
            buildValidRequestMetadata(
                REQUEST_ID, UUID.randomUUID(), PARTY_ID, IP_ADDRESS, "YBS", "API"));

    assertEquals("B000004318", actualResponse);

    final RecordedRequest recordedRequest = mockAuthenticWebAuth.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/oneoffpayment"));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.CONTENT_TYPE), is(MediaType.APPLICATION_XML_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_XML_VALUE));

    String actualRequest = recordedRequest.getBody().readUtf8();
    final String expectedRequest = readClassPathResource(DEFAULT_FILE_LOCATION + expected);

    Diff requestDiff =
        DiffBuilder.compare(actualRequest)
            .withTest(expectedRequest)
            .ignoreWhitespace()
            .withNodeFilter(node -> !"urn".equals(node.getNodeName()))
            .checkForIdentical()
            .build();
    assertFalse(requestDiff.hasDifferences(), requestDiff.toString());
  }

  @Test
  void shouldInitiateInternalPaymentSuccess() throws Exception {
    stubAuthenticService(DEFAULT_FILE_LOCATION + "OneOffTransferResponse.xml");

    when(clock.instant()).thenReturn(CLOCK_INSTANT_2);
    when(clock.getZone()).thenReturn(CLOCK_ZONE_ID);

    String actualResponse =
        authenticService.initiatePayment(
            buildValidatedInternalPaymentRequest(buildValidAccount()),
            buildValidRequestMetadata(
                REQUEST_ID, UUID.randomUUID(), PARTY_ID, IP_ADDRESS, "CHE", "SAPP"));

    assertEquals("B000004319", actualResponse);

    final RecordedRequest recordedRequest = mockAuthenticWebAuth.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/oneofftransfer"));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.CONTENT_TYPE), is(MediaType.APPLICATION_XML_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_XML_VALUE));

    String actualRequest = recordedRequest.getBody().readUtf8();
    final String expectedRequest =
        readClassPathResource(DEFAULT_FILE_LOCATION + "OneOffTransferRequest.xml");

    Diff requestDiff =
        DiffBuilder.compare(actualRequest)
            .withTest(expectedRequest)
            .ignoreWhitespace()
            .withNodeFilter(node -> !node.getNodeName().equals("urn")) // NOPMD
            .checkForIdentical()
            .build();
    assertFalse(requestDiff.hasDifferences(), requestDiff.toString());
  }

  @ParameterizedTest
  @MethodSource("paymentSourceWhenErrorResponseIsNot0")
  void initiatePaymentShouldThrowAuthenticServiceExceptionWhenConnectionErrorConnectingToAuthentic(
      final Function<AuthenticService, Executable> source) throws IOException {
    mockAuthenticWebAuth.shutdown();
    when(clock.instant()).thenReturn(CLOCK_INSTANT_1);
    when(clock.getZone()).thenReturn(CLOCK_ZONE_ID);

    final AuthenticServiceException exception =
        Assertions.assertThrows(AuthenticServiceException.class, source.apply(authenticService));
    assertThat(exception.getMessage(), equalTo(UNEXPECTED_ERROR_MESSAGE));
  }

  @ParameterizedTest
  @MethodSource("paymentSourceWhenErrorResponseIsNot0")
  void initiatePaymentShouldThrowInitiatePaymentServiceExceptionWhenResponseCodeIsNot0(
      final Function<AuthenticService, Executable> source, final String filePath)
      throws IOException {

    stubAuthenticService(DEFAULT_FILE_LOCATION + filePath);

    when(clock.instant()).thenReturn(CLOCK_INSTANT_1);
    when(clock.getZone()).thenReturn(CLOCK_ZONE_ID);
    final AuthenticServiceException exception =
        Assertions.assertThrows(
            InitiatePaymentServiceException.class, source.apply(authenticService));

    assertThat(exception.getMessage(), equalTo(INITIATE_PAYMENT_SERVICE_EXCEPTION));
  }

  private static Stream<Arguments> paymentSourceWhenErrorResponseIsNot0() {
    final RequestMetadata requestMetadata =
        buildValidRequestMetadata(
            REQUEST_ID, UUID.randomUUID(), PARTY_ID, IP_ADDRESS, "YBS", "API");

    final Function<AuthenticService, Executable> initiateExternalPayment =
        service ->
            () ->
                service.initiatePayment(
                    buildValidatedExternalPaymentRequest(buildValidAccount()), requestMetadata);
    final Function<AuthenticService, Executable> initiateInternalPayment =
        service ->
            () ->
                service.initiatePayment(
                    buildValidatedInternalPaymentRequest(buildValidAccount()), requestMetadata);

    return Stream.of(
        Arguments.of(initiateExternalPayment, "OneOffPaymentErrorResponse.xml"),
        Arguments.of(initiateInternalPayment, "OneOffTransferErrorResponse.xml"));
  }

  @ParameterizedTest
  @MethodSource("paymentSourceWhenEmptyErrorResponse")
  void initiatePaymentShouldThrowAuthenticServiceExceptionsWhenResponseIsEmpty(
      final Function<AuthenticService, Executable> source, final String filePath)
      throws IOException {

    stubAuthenticService(DEFAULT_FILE_LOCATION + filePath);

    when(clock.instant()).thenReturn(CLOCK_INSTANT_1);
    when(clock.getZone()).thenReturn(CLOCK_ZONE_ID);

    final AuthenticServiceException exception =
        Assertions.assertThrows(AuthenticServiceException.class, source.apply(authenticService));
    assertThat(exception.getMessage(), is(EMPTY_RESPONSE_MESSAGE));
    assertThat(exception.getCause(), not(instanceOf(AuthenticServiceException.class)));
  }

  private static Stream<Arguments> paymentSourceWhenEmptyErrorResponse() {
    final RequestMetadata requestMetadata =
        buildValidRequestMetadata(
            REQUEST_ID, UUID.randomUUID(), PARTY_ID, IP_ADDRESS, "YBS", "API");

    final Function<AuthenticService, Executable> initiateExternalPayment =
        service ->
            () ->
                service.initiatePayment(
                    buildValidatedExternalPaymentRequest(buildValidAccount()), requestMetadata);
    final Function<AuthenticService, Executable> initiateInternalPayment =
        service ->
            () ->
                service.initiatePayment(
                    buildValidatedInternalPaymentRequest(buildValidAccount()), requestMetadata);

    return Stream.of(
        Arguments.of(initiateExternalPayment, "OneOffPaymentEmptyResponse.xml"),
        Arguments.of(initiateInternalPayment, "OneOffTransferEmptyResponse.xml"));
  }

  @MethodSource("currencySource")
  @ParameterizedTest
  void testFormatCurrency(final BigDecimal amount, final String expected) {
    String actual = authenticService.formatCurrency(amount);
    assertEquals(expected, actual);
  }

  private static Stream<Arguments> currencySource() {
    return Stream.of(
        Arguments.of(new BigDecimal("1.01"), "101"),
        Arguments.of(new BigDecimal("1.2"), "120"),
        Arguments.of(new BigDecimal("1.29"), "129"),
        Arguments.of(new BigDecimal("1"), "100"), // NOPMD
        Arguments.of(new BigDecimal("0.01"), "1"),
        Arguments.of(new BigDecimal("0.1"), "10"),
        Arguments.of(new BigDecimal("1.010000"), "101"));
  }

  private void stubAuthenticService(final String filePath) throws IOException {
    mockAuthenticWebAuth.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader("Content-type", MediaType.APPLICATION_XML_VALUE)
            .setBody(readClassPathResource(filePath)));
  }
}
