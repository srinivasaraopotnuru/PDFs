package uk.co.ybs.digital.payment.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import uk.co.ybs.digital.payment.service.sca.ScaPasswordChallengeResponseExtractor;

class ScaPasswordChallengeResponseExtractorTest {

  private final ScaPasswordChallengeResponseExtractor testSubject =
      new ScaPasswordChallengeResponseExtractor();

  @Test
  public void extractScaPasswordChallengeResponseShouldReturnScaChallengeResponse() {
    final String challengeResponse = "challenge-response";
    final HttpHeaders headers = new HttpHeaders();
    headers.add("x-ybs-sca-challenge-response", challengeResponse);

    final Optional<String> extractedResponse =
        testSubject.extractScaPasswordChallengeResponse(headers);
    assertThat(extractedResponse.isPresent(), is(true));
    assertThat(extractedResponse.get(), is(challengeResponse));
  }

  @Test
  public void
      extractScaPasswordChallengeResponseShouldReturnEmptyOptionalWhenScaChallengeResponseHeaderNotPresent() {
    final HttpHeaders headers = new HttpHeaders();

    final Optional<String> extractedResponse =
        testSubject.extractScaPasswordChallengeResponse(headers);
    assertThat(extractedResponse.isPresent(), is(false));
  }
}
