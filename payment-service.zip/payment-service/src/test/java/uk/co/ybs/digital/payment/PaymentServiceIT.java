package uk.co.ybs.digital.payment;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_DEBTOR_ACC;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_MIN_BAL;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_PARTY_SYSID;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_CUST_WARNINGS;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_PAYMENT_ACCHLDR_ROLE;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_PAYMENT_ACC_STATUS;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_VALID_WITCD;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_WEB_ENABLED;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.SOA_PAYACC_WARNINGS;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.hibernate.exception.GenericJDBCException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.audit.AuditPaymentAuthFailureRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentAuthSuccessRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentDecisionRequest;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails.ExternalPaymentDebtor;
import uk.co.ybs.digital.payment.audit.LinkInternalPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkPaymentRequest;
import uk.co.ybs.digital.payment.audit.SimplePaymentDetails;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.ExemptReasonCode;
import uk.co.ybs.digital.payment.audit.sca.Sca;
import uk.co.ybs.digital.payment.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.payment.model.aat.ScaLvtCount;
import uk.co.ybs.digital.payment.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository;
import uk.co.ybs.digital.payment.repository.adgcore.BankRepository;
import uk.co.ybs.digital.payment.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.payment.utils.SigningUtils;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentWarning;
import uk.co.ybs.digital.payment.web.dto.WarningCategory;
import uk.co.ybs.digital.sca.service.digitaluser.dto.DigitalUserReverifyChallengeRequest;

@SuppressWarnings({"SameParameterValue", "NewClassNamingConvention", "PMD.ExcessiveClassLength"})
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class PaymentServiceIT {

  private static final String PRIVATE_BASE_PATH = "/private";
  private static final String PAYMENT_PATH = "/payment";
  private static final String VALIDATE_PATH = "/validate";
  private static final String VALIDATE_PAYEE_PATH = "/validate/payee";

  private static final String PRIVATE_VALIDATE_PAYEE_PATH = PRIVATE_BASE_PATH + VALIDATE_PAYEE_PATH;
  private static final String PAYMENT_FAILURE_PATH = "/failure";
  private static final String ACCOUNT_DETAIL_QUERY_PARAMS = "?include=availableDepositLimit";
  private static final String ACCOUNT_DETAIL_OTHER_QUERY_PARAMS =
      "?include=availableDepositLimit,otherAccount";

  private static final String CLAIM_SCOPE = "scope";
  private static final String CLAIM_CHANNEL = "channel";
  private static final String CLAIM_BRAND_CODE = "brand_code";
  private static final String CLAIM_AUD = "aud";
  private static final String CLAIM_SUB = "sub";
  private static final String CLAIM_SUB_TYPE = "sub_type";
  private static final String CLAIM_PARTY_ID = "party_id";
  private static final String CLAIM_SID = "sid";

  private static final String CLAIM_TITLE = "customer_title";
  private static final String CLAIM_EMAIL = "customer_email";
  private static final String CLAIM_LAST_NAME = "customer_last_name";

  private static final String SAPP_CHANNEL = "SAPP";
  private static final String WEB_CHANNEL = "WEB";
  private static final String BRAND_CODE = "YBS";
  private static final String TITLE = "Mr";
  private static final String EMAIL = "joe.bloggs@ybs.co.uk";
  private static final String SURNAME = "Bloggs";
  private static final String AUTHORIZATION_BEARER_VALUE = "Bearer ";
  private static final String LOCALHOST_URL = "localhost:";
  private static final String WITHDRAWAL_COMPLETE_STATUS = "WITHDRAWAL_COMPLETE";
  private static final String PAYMENT_SERVICE_KEY_VALUE = "payment-service-nonprod-1";

  private static final UUID PAYMENT_IDEMPOTENCY_KEY =
      UUID.fromString("3bf0faa4-223f-11ea-978f-2e728ce88125");
  private static final String PARTY_ID = "666";
  private static final String SUB = "987654321";
  private static final String SUB_TYPE_CUSTOMER = "customer";
  private static final String SUB_TYPE_SYSTEM = "system";
  private static final String REFERENCE = "ELECTRIC BILL";

  private static final String AMOUNT_AS_STRING = "100.00";
  private static final String EXEMPTED_AMOUNT_AS_STRING = "20.00";
  private static final BigDecimal EXEMPTED_AMOUNT = new BigDecimal(EXEMPTED_AMOUNT_AS_STRING);
  private static final BigDecimal AMOUNT = new BigDecimal(AMOUNT_AS_STRING);
  private static final String CURRENCY = "GBP";
  private static final String DEBTOR_ACCOUNT_NUMBER = "0123456789";
  private static final String DEBTOR_SORT_CODE = "609204";
  private static final String CREDITOR_ACCOUNT_NUMBER_EXTERNAL = "12345678";
  private static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL = "1234567890";
  private static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT = "3698521470";
  private static final String CREDITOR_SORT_CODE_VALID = "112233";
  private static final String CREDITOR_SORT_CODE_YBS = "609204";
  private static final String CREDITOR_NAME = "Mr Joe Bloggs";
  private static final String CREDITOR_BENEFICIARY_ID = "124abc";
  private static final String CREDITOR_BENEFICIARY_MEMORABLE_NAME = "Joint Account";

  private static final String TRANSACTION_ID_EXTERNAL = "B000004318";
  private static final String TRANSACTION_ID_INTERNAL = "B000004319";

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature-key-id";
  private static final String HEADER_SCA_KEY = "x-ybs-sca-key";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";

  private static final String REQUIRED_SCOPES = "PAYMENT ACCOUNT_READ";
  private static final String ACCOUNT_READ_SCOPE = "ACCOUNT_READ";
  private static final String PAYMENT_READ_SCOPE = "PAYMENT_READ";
  private static final String OTHER_SCOPE = "OTHER";
  private static final String HEADER_SCA_CHALLENGE = "x-ybs-sca-challenge";
  private static final String HEADER_SCA_CHALLENGE_RESPONSE = "x-ybs-sca-challenge-response";
  private static final String X_FORWARDED_FOR_HEADER = "X-Forwarded-For";
  private static final String CLIENT_IP = "12.66.53.145";
  private static final String HTTP_GET = "GET";

  private static final String CLIENT_FAILURE_TYPE = "CLIENT";
  private static final String CHALLENGE_FAILURE_TYPE = "CHALLENGE";
  private static final int SCA_LVT_COUNT_BELOW_THRESHOLD = 2;
  private static final String EXPECTED_WEB_PASSWORD_POSITIONS_CHALLENGE = "1,4,7";
  private static final String PASSWORD_CHARS_CHALLENGE_RESPONSE =
      "encryptedStringContainingPasswordCharsList";

  private static final String SCA_REQUIRED_MESSAGE_SAPP =
      "Please sign the value in x-ybs-sca-challenge header with the request";
  private static final String SCA_REQUIRED_MESSAGE_WEB =
      "Please send the encrypted password characters in the x-ybs-sca-challenge-response header";

  public static final UUID REQUEST_ID = UUID.randomUUID();
  public static final UUID SESSION_ID = UUID.randomUUID();

  @LocalServerPort private int port;

  @Value("${spring.security.ybs.request-signature.signing.key-id}")
  private String requestSignatureSigningKeyId; // NOPMD

  @Autowired private WebTestClient signingWebClientPublic;

  @Autowired private WebTestClient signingWebClientPrivate;

  @Autowired private WebTestClient nonSigningWebClient;

  @Autowired private PrivateKey jwtSigningPrivateKey;

  @Value("${uk.co.ybs.digital.account-test-port}")
  private int mockAccountServicePort;

  private MockWebServer mockAccountService;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int mockAuditServicePort;

  private MockWebServer mockAuditService;

  @Value("${uk.co.ybs.digital.beneficiary-test-port}")
  private int mockBeneficiaryServicePort;

  @Value("${uk.co.ybs.digital.sca.digital-user-service-test-port}")
  private int mockDigitalUserServicePort;

  @Value("${uk.co.ybs.digital.authentic.webauth.port}")
  private int mockAuthenticWebAuthTestPort;

  private MockWebServer mockAuthenticWebAuth;

  private MockWebServer mockBeneficiaryService;

  private MockWebServer mockDigitalUserService;

  @Autowired private ObjectMapper objectMapper;

  @Autowired private TransactionTemplate transactionTemplate;
  @Autowired private TestEntityManager frontOfficeTestEntityManager;
  @Autowired private TestEntityManager aatTestEntityManager;

  @MockBean private AccountPaymentDetailsRepository accountPaymentDetailsRepository;

  @MockBean private BankRepository bankRepository;

  private KeyPair keyPair;

  @BeforeEach
  void setUp() throws Exception {
    mockAccountService = new MockWebServer();
    mockAccountService.start(mockAccountServicePort);

    mockAuditService = new MockWebServer();
    mockAuditService.start(mockAuditServicePort);

    mockBeneficiaryService = new MockWebServer();
    mockBeneficiaryService.start(mockBeneficiaryServicePort);

    mockDigitalUserService = new MockWebServer();
    mockDigitalUserService.start(mockDigitalUserServicePort);

    mockAuthenticWebAuth = new MockWebServer();
    mockAuthenticWebAuth.start(mockAuthenticWebAuthTestPort);

    keyPair = SigningUtils.generateKeyPair();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockAccountService.shutdown();
    mockAuditService.shutdown();
    mockBeneficiaryService.shutdown();
    mockDigitalUserService.shutdown();
    mockAuthenticWebAuth.shutdown();
    tearDownDb();
  }

  @Test
  void validateInternalAccountRequestShouldSucceedWithValidRequestPayload() throws Exception {
    validateInternalAccountRequestShouldSucceedWithValidRequestPayload(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void privateValidateInternalAccountRequestShouldSucceedWithValidRequestPayload()
      throws Exception {
    validateInternalAccountRequestShouldSucceedWithValidRequestPayload(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  @Test
  void validatePayeeShouldSucceedIfValidatePayeeRequestIsValid() {
    validatePayeeShouldSucceedIfValidatePayeeRequestIsValid(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void privateValidatePayeeShouldSucceedIfValidatePayeeRequestIsValid() {
    validatePayeeShouldSucceedIfValidatePayeeRequestIsValid(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  private void validatePayeeShouldSucceedIfValidatePayeeRequestIsValid(
      final String endpoint,
      final WebTestClient webTestClient,
      final Map<String, Object> validJwt) {
    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildValidExternalPayeeRequest();
    final String jwt = buildJwt(validJwt);

    stubValidateCreditorDependenciesSuccess();
    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    webTestClient
        .post()
        .uri(getURI(endpoint))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  private void validateInternalAccountRequestShouldSucceedWithValidRequestPayload(
      final String path, final WebTestClient signingWebClient, final Map<String, Object> validJwt)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();
    String jwt = buildJwt(validJwt);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    signingWebClient
        .post()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  void validateInternalAccountRequestShouldReturnConflictIfAccountIsNotFound() throws Exception {
    validateInternalAccountRequestShouldReturnConflictIfAccountIsNotFound(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void privateValidateInternalAccountRequestShouldReturnConflictIfAccountIsNotFound()
      throws Exception {
    validateInternalAccountRequestShouldReturnConflictIfAccountIsNotFound(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  void validateInternalAccountRequestShouldReturnConflictIfAccountIsNotFound(
      final String path, final WebTestClient signingWebClient, final Map<String, Object> validJwt)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();
    final String jwt = buildJwt(validJwt);
    final String accountNumber = request.getAccountNumber();

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("409 Conflict")
            .message("Conflict")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("InternalPayee.Invalid")
                    .message("Failed to find internal account: " + accountNumber)
                    .build())
            .build();

    stubAccountServiceEntityNotFound();

    signingWebClient
        .post()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void validateInternalAccountRequestShouldReturnConflictIfAccountRequestAccessDenied()
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final String accountNumber = request.getAccountNumber();

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("409 Conflict")
            .message("Conflict")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("InternalPayee.Invalid")
                    .message("Failed to find internal account: " + accountNumber)
                    .build())
            .build();

    stubAccountServiceEntityAccessDenied();

    signingWebClientPublic
        .post()
        .uri(getURI(VALIDATE_PAYEE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void validateInternalAccountRequestShouldReturnBadRequestWithInvalidRequestPayload() {
    final UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();
    final String jwt = buildJwt(systemClaimsMap(PAYMENT_READ_SCOPE));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("400 Bad Request")
            .message("Bad Request")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("InternalPayee.Invalid")
                    .message("Missing field: party_id")
                    .build())
            .build();

    signingWebClientPublic
        .post()
        .uri(getURI(VALIDATE_PAYEE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.BAD_REQUEST)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void validateExternalCreditorRequestShouldSucceedWithValidRequestPayload() {
    validateExternalCreditorRequestShouldSucceedWithValidRequestPayload(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void privateValidateExternalCreditorRequestShouldSucceedWithValidRequestPayload() {
    validateExternalCreditorRequestShouldSucceedWithValidRequestPayload(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  private void validateExternalCreditorRequestShouldSucceedWithValidRequestPayload(
      final String endpoint,
      final WebTestClient webTestClient,
      final Map<String, Object> validJwt) {
    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildValidExternalPayeeRequest();
    final String jwt = buildJwt(validJwt);

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    webTestClient
        .post()
        .uri(getURI(endpoint))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  void
      validateExternalCreditorRequestShouldReturnConflictWhenExternalCreditorDetailsContainBrandSortCode() {
    validateExternalCreditorRequestShouldReturnConflictWhenExternalCreditorDetailsContainBrandSortCode(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void
      privateValidateExternalCreditorRequestShouldReturnConflictWhenExternalCreditorDetailsContainBrandSortCode() {
    validateExternalCreditorRequestShouldReturnConflictWhenExternalCreditorDetailsContainBrandSortCode(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  private void
      validateExternalCreditorRequestShouldReturnConflictWhenExternalCreditorDetailsContainBrandSortCode(
          final String endpoint,
          final WebTestClient webTestClient,
          final Map<String, Object> validJwt) {
    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildExternalPayeeWithYBSSortCode();
    final String jwt = buildJwt(validJwt);
    final ErrorResponse errorResponse =
        TestHelper.validatePayeeRejectedCreditorAccountInternalSortCode(requestId);

    webTestClient
        .post()
        .uri(getURI(endpoint))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void validatePayeeShouldReturnConflictWhenPayeeDetailsContainBrandSortCode() {
    validatePayeeShouldReturnConflictWhenPayeeDetailsContainBrandSortCode(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void privateValidatePayeeShouldReturnConflictWhenPayeeDetailsContainBrandSortCode() {
    validatePayeeShouldReturnConflictWhenPayeeDetailsContainBrandSortCode(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  private void validatePayeeShouldReturnConflictWhenPayeeDetailsContainBrandSortCode(
      final String endpoint,
      final WebTestClient webTestClient,
      final Map<String, Object> validJwt) {
    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildExternalPayeeWithYBSSortCode();
    final String jwt = buildJwt(validJwt);
    final ErrorResponse errorResponse =
        TestHelper.validatePayeeRejectedCreditorAccountInternalSortCode(requestId);

    webTestClient
        .post()
        .uri(getURI(endpoint))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void validateExternalCreditorRequestShouldReturnConflictWhenExternalSortCodeNotFound()
      throws Exception {
    validateExternalCreditorRequestShouldReturnConflictWhenExternalSortCodeNotFound(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void privateExternalCreditorRequestShouldReturnConflictWhenExternalSortCodeNotFound()
      throws Exception {
    validateExternalCreditorRequestShouldReturnConflictWhenExternalSortCodeNotFound(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  private void validateExternalCreditorRequestShouldReturnConflictWhenExternalSortCodeNotFound(
      final String endpoint, final WebTestClient webTestClient, final Map<String, Object> validJwt)
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildValidExternalPayeeRequest();
    final String jwt = buildJwt(validJwt);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateSortCode(CREDITOR_SORT_CODE_VALID, false);

    webTestClient
        .post()
        .uri(getURI(endpoint))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void validateExternalCreditorRequestShouldReturnConflicWhenExternalAccountNotValid()
      throws Exception {
    validateExternalCreditorRequestShouldReturnConflictWhenExternalAccountNotValid(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void privateExternalCreditorRequestShouldReturnConflictWhenExternalAccountNotValid()
      throws Exception {
    validateExternalCreditorRequestShouldReturnConflictWhenExternalAccountNotValid(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  private void validateExternalCreditorRequestShouldReturnConflictWhenExternalAccountNotValid(
      final String endpoint, final WebTestClient webTestClient, final Map<String, Object> validJwt)
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildValidExternalPayeeRequest();
    final String jwt = buildJwt(validJwt);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateSortCode(CREDITOR_SORT_CODE_VALID, true);
    stubValidateAccount(CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL, false);

    webTestClient
        .post()
        .uri(getURI(endpoint))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void
      validateExternalCreditorRequestShouldReturnConflictWhenExternalBankDoesNotAcceptFasterPayments()
          throws Exception {
    validateExternalCreditorRequestShouldReturnConflictWhenExternalBankDoesNotAcceptFasterPayments(
        VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void
      privateExternalCreditorRequestShouldReturnConflictWhenExternalBankDoesNotAcceptFasterPayments()
          throws Exception {
    validateExternalCreditorRequestShouldReturnConflictWhenExternalBankDoesNotAcceptFasterPayments(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(PAYMENT_READ_SCOPE));
  }

  private void
      validateExternalCreditorRequestShouldReturnConflictWhenExternalBankDoesNotAcceptFasterPayments(
          final String endpoint,
          final WebTestClient webTestClient,
          final Map<String, Object> validJwt)
          throws Exception {

    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildValidExternalPayeeRequest();
    final String jwt = buildJwt(validJwt);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateSortCode(CREDITOR_SORT_CODE_VALID, true);
    stubValidateAccount(CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL, true);
    stubAcceptsFasterPayments(CREDITOR_SORT_CODE_VALID, false);

    webTestClient
        .post()
        .uri(getURI(endpoint))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void validatePayeeShouldReturnForbiddenWhenIncorrectlySigned() {
    validatePayeeShouldReturnForbiddenWhenIncorrectlySigned(
        VALIDATE_PAYEE_PATH, signingWebClientPrivate, claimsMap(ACCOUNT_READ_SCOPE));
  }

  @Test
  void privateValidatePayeeShouldReturnForbiddenWhenIncorrectlySigned() {
    validatePayeeShouldReturnForbiddenWhenIncorrectlySigned(
        PRIVATE_VALIDATE_PAYEE_PATH, signingWebClientPublic, claimsMap(ACCOUNT_READ_SCOPE));
  }

  private void validatePayeeShouldReturnForbiddenWhenIncorrectlySigned(
      final String endpoint,
      final WebTestClient webTestClient,
      final Map<String, Object> validJwt) {
    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildValidExternalPayeeRequest();
    final String jwt = buildJwt(validJwt);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.INVALID_REQUEST_SIGNATURE)
                    .message("Access Denied")
                    .build())
            .build();

    webTestClient
        .post()
        .uri(getURI(endpoint))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @CsvSource({PAYMENT_PATH, PAYMENT_FAILURE_PATH, VALIDATE_PATH})
  void otherPaymentResourcesShouldFailIfSystemJwtIsProvided(final String path) {
    final UUID requestId = UUID.randomUUID();
    final ExternalCreditorDetails request = buildValidExternalPayeeRequest();
    final String jwt = buildJwt(systemClaimsMap(PAYMENT_READ_SCOPE));

    signingWebClientPublic
        .post()
        .uri(getURI(path))
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isBadRequest();
  }

  @Test
  void paymentFailureShouldSucceedIfPaymentFailureRequestIsValid() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    final String jwt = buildJwt(claimsMap(REQUIRED_SCOPES));

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    stubAuditSuccess();

    signingWebClientPublic
        .post()
        .uri(getURI(PAYMENT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isNoContent();

    verifyAuditAuthenticationFailure(requestId, jwt, CLIENT_FAILURE_TYPE);
    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
  }

  @Test
  void paymentFailureShouldSucceedIfSendEmailFails() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    stubAuditSuccess();

    signingWebClientPublic
        .post()
        .uri(getURI(PAYMENT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isNoContent();

    verifyAuditAuthenticationFailure(requestId, jwt, CLIENT_FAILURE_TYPE);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloads") // NOPMD
  void validatePaymentShouldSucceedAndDisplayWarningsIfPaymentRequestIsValid(
      final ExternalPaymentRequest request, final boolean beneficiary) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource("api/account/withdrawalInterestPenalty/response.json"));

    signingWebClientPublic
        .post()
        .uri(getURI(VALIDATE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(new ParameterizedTypeReference<List<PaymentWarning>>() {})
        .value(
            equalTo(
                Arrays.asList(
                    PaymentWarning.builder()
                        .code(WarningCategory.DEBTOR_WITHDRAWAL_DAYS)
                        .displayMessage("You have 3 withdrawal days remaining until 31-Dec-2020")
                        .build(),
                    PaymentWarning.builder()
                        .code(WarningCategory.DEBTOR_WITHDRAWAL_INTEREST_PENALTY)
                        .parameters(
                            PaymentWarning.Parameters.builder()
                                .days(30)
                                .amount(new BigDecimal("123.45"))
                                .build())
                        .build(),
                    PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA).build())));

    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    if (beneficiary) {
      verifyFindBeneficiary(requestId, jwt);
    }
    verifyCalculateWithdrawalInterestPenalty(DEBTOR_ACCOUNT_NUMBER, AMOUNT, requestId, jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloadsWhereScaExempted")
  void makeExternalPaymentShouldSucceedWhereScaExempted(
      final ExternalPaymentRequest request,
      final boolean isTrustedBeneficiary,
      final Integer scaLvtCount,
      final BigDecimal paymentAmount,
      final ExemptReasonCode exemptReasonCode,
      final boolean accessedFlag)
      throws Throwable {

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwt(claimsMap(REQUIRED_SCOPES, WEB_CHANNEL));

    if (scaLvtCount != null) {
      setupScaLvtCount(scaLvtCount, accessedFlag);
    }

    // Request validated and initiated
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();
    stubInitiatePaymentAuthentic("api/authentic/payment/OneOffPaymentResponse.xml");

    if (isTrustedBeneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubAuditSuccess();
    stubAuditSuccess();

    postPaymentWithoutSca(request, requestId, jwt);

    verifyAuditDecision(
        requestId,
        jwt,
        Sca.builder()
            .decisionStatus(DecisionStatus.EXEMPTED)
            .exemptReasonCode(exemptReasonCode)
            .build());

    final LinkPaymentRequest expectedLinkPaymentRequest =
        LinkPaymentRequest.builder()
            .trackingId(UUID.randomUUID())
            .trackingCode("random_generated_tracking_code")
            .ipAddress(CLIENT_IP)
            .paymentDetails(
                LinkExternalPaymentDetails.builder()
                    .uniqueReference(PAYMENT_IDEMPOTENCY_KEY)
                    .transactionId(TRANSACTION_ID_EXTERNAL)
                    .amount(paymentAmount)
                    .reference(REFERENCE)
                    .debtor(
                        ExternalPaymentDebtor.builder()
                            .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                            .sortCode(DEBTOR_SORT_CODE)
                            .build())
                    .sca(
                        Sca.builder()
                            .exemptReasonCode(exemptReasonCode)
                            .decisionStatus(DecisionStatus.EXEMPTED)
                            .build())
                    .creditorDetails(
                        LinkExternalPaymentDetails.ExternalPaymentCreditorDetails.builder()
                            .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
                            .sortCode(CREDITOR_SORT_CODE_VALID)
                            .name(CREDITOR_NAME)
                            .beneficiary(
                                isTrustedBeneficiary
                                    ? LinkExternalPaymentDetails.ExternalPaymentCreditorDetails
                                        .ExternalCreditorBeneficiaryDetails.builder()
                                        .memorableName(CREDITOR_BENEFICIARY_MEMORABLE_NAME)
                                        .build()
                                    : null)
                            .build())
                    .build())
            .build();
    verifyAuditLinkPaymentCheck(
        requestId,
        jwt,
        expectedLinkPaymentRequest.getPaymentDetails(),
        expectedLinkPaymentRequest.getIpAddress());

    final SavingsTransactionLogEntry expected =
        SavingsTransactionLogEntry.builder()
            .accountNumber(Long.parseLong(DEBTOR_ACCOUNT_NUMBER))
            .amount(paymentAmount)
            .bankAccountName(CREDITOR_NAME)
            .bankReference(REFERENCE)
            .bankSortCode(Integer.parseInt(CREDITOR_SORT_CODE_VALID))
            .closure("N")
            .partySysId(Long.parseLong(PARTY_ID))
            .status(WITHDRAWAL_COMPLETE_STATUS)
            .targetAccountNumber(Long.parseLong(CREDITOR_ACCOUNT_NUMBER_EXTERNAL))
            .transferIndicator("E")
            .build();
    assertSingleTransactionLogEntry(logEntryMatching(expected));
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloads") // NOPMD
  void makeExternalPaymentForAppShouldSucceedWhereScaRequired(
      final ExternalPaymentRequest request,
      final boolean beneficiary,
      final boolean saveBeneficiary)
      throws Throwable {
    makeExternalPaymentShouldSucceedWhereScaRequired(
        request, beneficiary, saveBeneficiary, SAPP_CHANNEL, null, AMOUNT, false);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloadsForWebNotScaExempt")
  void makeExternalPaymentForWebShouldSucceedWhereScaRequired(
      final ExternalPaymentRequest request,
      final boolean beneficiary,
      final boolean saveBeneficiary,
      final Integer scaLvtCount,
      final BigDecimal paymentAmount,
      final boolean accessedFlag)
      throws Throwable {
    makeExternalPaymentShouldSucceedWhereScaRequired(
        request,
        beneficiary,
        saveBeneficiary,
        WEB_CHANNEL,
        scaLvtCount,
        paymentAmount,
        accessedFlag);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private void makeExternalPaymentShouldSucceedWhereScaRequired(
      final ExternalPaymentRequest request,
      final boolean beneficiary,
      final boolean saveBeneficiary,
      final String channel,
      final Integer scaLvtCount,
      final BigDecimal paymentAmount,
      final boolean accessedFlag)
      throws Throwable {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwt(claimsMap(REQUIRED_SCOPES, channel));
    final boolean isWebChannel = WEB_CHANNEL.equals(channel);

    if (isWebChannel && scaLvtCount != null) {
      setupScaLvtCount(scaLvtCount, accessedFlag);
    }

    // First request validated
    stubExternalPaymentRequestForScaChallenge(beneficiary, isWebChannel);

    // Second request validated and initiated
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();
    stubInitiatePaymentAuthentic("api/authentic/payment/OneOffPaymentResponse.xml");

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);
    stubAuditSuccess();
    stubAuditSuccess();

    if (saveBeneficiary) {
      stubSaveBeneficiarySuccess();
    }

    final String challenge =
        postPaymentRequestForScaChallenge(requestId, request, jwt, isWebChannel);
    final String encodedPublicKey = SigningUtils.encodePublicKey(keyPair);

    if (isWebChannel) {
      assertThat(challenge, is(EXPECTED_WEB_PASSWORD_POSITIONS_CHALLENGE));
      stubDigitalUserServiceReverifyChallengeResponse();
      postWebPaymentWithSca(request, requestId, jwt, PASSWORD_CHARS_CHALLENGE_RESPONSE)
          .expectStatus()
          .isNoContent();
      verifyDigitalUserServiceReAuthChallengeRequest(requestId, jwt);
      verifyDigitalUserServiceReverifyChallengeRequest(
          requestId, jwt, PASSWORD_CHARS_CHALLENGE_RESPONSE);
    } else {
      final String challengeResponse = SigningUtils.signWithPrivateKey(keyPair, challenge);
      postPaymentWithSca(request, requestId, jwt, challenge, challengeResponse, encodedPublicKey)
          .expectStatus()
          .isNoContent();
    }

    verifyExternalPaymentRequestForScaChallenge(beneficiary, requestId, jwt);
    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    if (beneficiary) {
      verifyFindBeneficiary(requestId, jwt);
    }

    final AuditPaymentAuthSuccessRequest actualPaymentAuthRequest =
        verifyAuditAuthenticationSuccess(requestId, jwt);

    final LinkPaymentRequest expectedLinkPaymentRequest =
        LinkPaymentRequest.builder()
            .trackingId(actualPaymentAuthRequest.getTrackingId())
            .trackingCode(actualPaymentAuthRequest.getTrackingCode())
            .ipAddress(CLIENT_IP)
            .paymentDetails(
                LinkExternalPaymentDetails.builder()
                    .uniqueReference(PAYMENT_IDEMPOTENCY_KEY)
                    .transactionId(TRANSACTION_ID_EXTERNAL)
                    .amount(paymentAmount)
                    .reference(REFERENCE)
                    .debtor(
                        ExternalPaymentDebtor.builder()
                            .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                            .sortCode(DEBTOR_SORT_CODE)
                            .build())
                    .sca(Sca.builder().decisionStatus(DecisionStatus.APPLIED).build())
                    .creditorDetails(
                        LinkExternalPaymentDetails.ExternalPaymentCreditorDetails.builder()
                            .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
                            .sortCode(CREDITOR_SORT_CODE_VALID)
                            .name(CREDITOR_NAME)
                            .beneficiary(
                                beneficiary
                                    ? LinkExternalPaymentDetails.ExternalPaymentCreditorDetails
                                        .ExternalCreditorBeneficiaryDetails.builder()
                                        .memorableName(CREDITOR_BENEFICIARY_MEMORABLE_NAME)
                                        .build()
                                    : null)
                            .build())
                    .build())
            .build();
    verifyAuditLinkPayment(requestId, jwt, expectedLinkPaymentRequest);

    if (saveBeneficiary) {
      verifySaveBeneficiary(requestId, jwt, request);
    }

    final SavingsTransactionLogEntry expected =
        SavingsTransactionLogEntry.builder()
            .accountNumber(Long.parseLong(DEBTOR_ACCOUNT_NUMBER))
            .amount(paymentAmount)
            .bankAccountName(CREDITOR_NAME)
            .bankReference(REFERENCE)
            .bankSortCode(Integer.parseInt(CREDITOR_SORT_CODE_VALID))
            .closure("N")
            .partySysId(Long.parseLong(PARTY_ID))
            .status(WITHDRAWAL_COMPLETE_STATUS)
            .targetAccountNumber(Long.parseLong(CREDITOR_ACCOUNT_NUMBER_EXTERNAL))
            .transferIndicator("E")
            .build();
    assertSingleTransactionLogEntry(logEntryMatching(expected));
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpointsAndExternalPaymentPayloads") // NOPMD
  void makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenInvalidAccountHolderRole(
      final String path,
      final ExternalPaymentRequest request,
      @SuppressWarnings("unused") final boolean beneficiary) // NOPMD
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedDebtorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubGetAccountPaymentDetails(false, true);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpointsAndExternalPaymentPayloads") // NOPMD
  void makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenMultipleSignatoriesRequired(
      final String path,
      final ExternalPaymentRequest request,
      @SuppressWarnings("unused") final boolean beneficiary) // NOPMD
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse =
        TestHelper.paymentRejectedDebtorAccountMultipleSignatoriesRequired(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubGetAccountPaymentDetails(true, false);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpointsAndExternalPaymentPayloads") // NOPMD
  void
      makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenSessionBrandDoesNotMatchCreditorAccountBrand(
          final String path,
          final ExternalPaymentRequest request,
          @SuppressWarnings("unused") final boolean beneficiary) // NOPMD
          throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedDebtorAccount(requestId);

    stubFindAccountSuccessChelsea();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpointsAndExternalPaymentPayloads") // NOPMD
  void makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenInsufficientFunds(
      final String path,
      final ExternalPaymentRequest request,
      @SuppressWarnings("unused") final boolean beneficiary) // NOPMD
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse =
        TestHelper.paymentRejectedDebtorAccountInsufficientFunds(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER); // Debtor
    stubValidateCreditorDependenciesSuccess();

    postRequestWithoutSca(
            path, request.toBuilder().amount(new BigDecimal("200000.00")).build(), requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpointsAndExternalPaymentPayloads") // NOPMD
  void makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenExternalSortCodeNotFound(
      final String path, final ExternalPaymentRequest request, final boolean beneficiary)
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateSortCode(CREDITOR_SORT_CODE_VALID, false);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpointsAndExternalPaymentPayloads") // NOPMD
  void makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenExternalAccountNotValid(
      final String path, final ExternalPaymentRequest request, final boolean beneficiary)
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateSortCode(CREDITOR_SORT_CODE_VALID, true);
    stubValidateAccount(CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL, false);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpointsAndExternalPaymentPayloads") // NOPMD
  void
      makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenExternalBankDoesNotAcceptFasterPayments(
          final String path, final ExternalPaymentRequest request, final boolean beneficiary)
          throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateSortCode(CREDITOR_SORT_CODE_VALID, true);
    stubValidateAccount(CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL, true);
    stubAcceptsFasterPayments(CREDITOR_SORT_CODE_VALID, false);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpointsAndExternalPaymentPayloads") // NOPMD
  void makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenDebtorAccountAccessDenied(
      final String path, final ExternalPaymentRequest request) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedDebtorAccount(requestId);

    stubAccountServiceEntityAccessDenied();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void sendPaymentFailureShouldReturnConflictWhenDebtorAccountAccessDenied() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentFailureNotification(requestId);

    stubAccountServiceEntityAccessDenied();

    signingWebClientPublic
        .post()
        .uri(getURI(PAYMENT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void
      makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenCreditorDetailsContainsYbsSortCode(
          final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalPaymentRequest request =
        buildExternalPaymentRequestWithCreditorDetails(CREDITOR_SORT_CODE_YBS, AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse =
        TestHelper.paymentRejectedCreditorAccountInternalSortCode(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    stubValidateCreditorDependenciesSuccess();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void
      makeExternalPaymentAndValidatePaymentShouldReturnConflictWhenCreditorBeneficiaryContainsYbsSortCode(
          final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ExternalPaymentRequest request =
        buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse =
        TestHelper.paymentRejectedCreditorAccountInternalSortCode(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    stubBeneficiaryServiceResponse(
        HttpStatus.OK,
        readClassPathResource("api/account/beneficiary/ResponseExternalYbsSortCode.json"));

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloads") // NOPMD
  void makeExternalPaymentShouldReturnInternalServerErrorWhenInitiatePaymentReturnsFault(
      final ExternalPaymentRequest request, final boolean beneficiary) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);

    setupScaLvtCountBelowThreshold();

    // First request validated
    stubExternalPaymentRequestForScaChallenge(beneficiary, false);

    // Second request validated and initiated
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();
    stubInitiatePaymentAuthentic("api/authentic/payment/OneOffPaymentErrorResponse.xml");

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubAuditSuccess();
    stubAuditSuccess();

    final String challenge = postPaymentRequestForScaChallenge(requestId, request, jwt, false);
    final String challengeResponse = SigningUtils.signWithPrivateKey(keyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(keyPair);
    final ErrorResponse expectedResponse = TestHelper.internalError(requestId);

    postPaymentWithSca(request, requestId, jwt, challenge, challengeResponse, encodedPublicKey)
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyExternalPaymentRequestForScaChallenge(beneficiary, requestId, jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloads") // NOPMD
  void makeExternalPaymentShouldReturnInternalServerErrorWhenAuditFails(
      final ExternalPaymentRequest request, final boolean beneficiary) throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.internalError(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    mockAuditService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.FORBIDDEN.value())
            .setBody(
                readClassPathResource("api/audit/response/ErrorResponseInvalidSignature.json")));

    postPaymentWithoutSca(request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloads") // NOPMD
  void makeExternalPaymentForAppShouldReturnForbiddenWhenScaChallengeRequired(
      final ExternalPaymentRequest request, final boolean beneficiary)
      throws IOException, InterruptedException {
    makeExternalPaymentShouldReturnForbiddenWhenScaChallengeRequired(
        request, beneficiary, null, SAPP_CHANNEL);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloadsForWebNotScaExemptErrorTest") // NOPMD
  void makeExternalPaymentForWebShouldReturnForbiddenWhenScaChallengeRequired(
      final ExternalPaymentRequest request, final boolean beneficiary, final Integer scaLvtCount)
      throws IOException, InterruptedException {
    makeExternalPaymentShouldReturnForbiddenWhenScaChallengeRequired(
        request, beneficiary, scaLvtCount, WEB_CHANNEL);
  }

  private void makeExternalPaymentShouldReturnForbiddenWhenScaChallengeRequired(
      final ExternalPaymentRequest request,
      final boolean beneficiary,
      final Integer scaLvtCount,
      final String channel)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwt(claimsMap(REQUIRED_SCOPES, channel));
    final boolean isWebChannel = WEB_CHANNEL.equals(channel);
    final ErrorResponse expectedResponse =
        TestHelper.scaRequired(
            requestId, isWebChannel ? SCA_REQUIRED_MESSAGE_WEB : SCA_REQUIRED_MESSAGE_SAPP);

    if (isWebChannel && scaLvtCount != null) {
      setupScaLvtCount(scaLvtCount);
    }

    if (isWebChannel) {
      stubDigitalUserServiceReAuthChallengeResponse();
    }
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubAuditSuccess();

    postPaymentWithoutSca(request, requestId, jwt)
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
    if (isWebChannel) {
      verifyDigitalUserServiceReAuthChallengeRequest(requestId, jwt);
    }
    verifyAuditDecision(requestId, jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloadsForWebNotScaExemptErrorTest") // NOPMD
  void makeExternalPaymentForWebShouldReturnInternalServerErrorWhenErrorObtainingScaChallenge(
      final ExternalPaymentRequest request, final boolean beneficiary, final Integer scaLvtCount)
      throws IOException, InterruptedException {
    List<Integer> reauthErrorResponses = Arrays.asList(400, 401, 403, 404, 500, 503); // NOPMD
    for (Integer errorResponse : reauthErrorResponses) {
      makeExternalPaymentForWebShouldReturnInternalServerErrorWhenErrorObtainingScaChallenge(
          request, beneficiary, scaLvtCount, errorResponse);
      tearDownDb();
    }
  }

  private void
      makeExternalPaymentForWebShouldReturnInternalServerErrorWhenErrorObtainingScaChallenge(
          final ExternalPaymentRequest request,
          final boolean beneficiary,
          final Integer scaLvtCount,
          final int reauthErrorResponse)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwt(claimsMap(REQUIRED_SCOPES, WEB_CHANNEL));

    if (scaLvtCount != null) {
      setupScaLvtCount(scaLvtCount);
    }

    stubDigitalUserServiceReAuthChallengeFailResponse(reauthErrorResponse);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubAuditSuccess();

    postPaymentWithoutSca(request, requestId, jwt)
        .expectStatus()
        .is5xxServerError()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON);

    verifyDigitalUserServiceReAuthChallengeRequest(requestId, jwt);
    verifyAuditDecision(requestId, jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloads") // NOPMD
  void makeExternalPaymentShouldReturnForbiddenWhenChallengeDoesNotMatchChallengeResponse(
      final ExternalPaymentRequest request, final boolean beneficiary) throws Exception {
    makeExternalPaymentShouldReturnForbiddenWhenChallengeDoesNotMatchChallengeResponse(
        request, beneficiary, claimsMap(REQUIRED_SCOPES));
  }

  private void makeExternalPaymentShouldReturnForbiddenWhenChallengeDoesNotMatchChallengeResponse(
      final ExternalPaymentRequest request,
      final boolean beneficiary,
      final Map<String, Object> claims)
      throws Exception {
    String encodedPublicKey = SigningUtils.encodePublicKey(keyPair);

    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwt(claims);

    setupScaLvtCountBelowThreshold();

    // First request validated
    stubExternalPaymentRequestForScaChallenge(beneficiary, false);

    final String challenge = postPaymentRequestForScaChallenge(requestId, request, jwt, false);
    String signedWithWrongKey =
        SigningUtils.signWithPrivateKey(SigningUtils.generateKeyPair(), challenge);
    ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    stubAuditSuccess();

    postPaymentWithSca(request, requestId, jwt, challenge, signedWithWrongKey, encodedPublicKey)
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyExternalPaymentRequestForScaChallenge(beneficiary, requestId, jwt);

    final RecordedRequest auditAuthFailRequest = mockAuditService.takeRequest();
    assertThat(
        auditAuthFailRequest.getPath(), is(equalTo("/audit/payment/authentication/failure")));
    assertThat(
        auditAuthFailRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditAuthFailRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(
        auditAuthFailRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditAuthFailRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditAuthFailRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("externalPaymentPayloads") // NOPMD
  void makeExternalPaymentShouldReturnForbiddenWhenPayloadDoesNotMatchChallenge(
      final ExternalPaymentRequest request) throws Exception {
    makeExternalPaymentShouldReturnForbiddenWhenPayloadDoesNotMatchChallenge(
        request, claimsMap(REQUIRED_SCOPES));
  }

  private void makeExternalPaymentShouldReturnForbiddenWhenPayloadDoesNotMatchChallenge(
      final ExternalPaymentRequest request, final Map<String, Object> claims) throws Exception {
    final String encodedPublicKey = SigningUtils.encodePublicKey(keyPair);
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);
    final String jwt = buildJwt(claims);
    final String challenge = "foobar";
    final String challengeResponse = SigningUtils.signWithPrivateKey(keyPair, challenge);

    stubAuditSuccess();

    postPaymentWithSca(request, requestId, jwt, challenge, challengeResponse, encodedPublicKey)
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource({"externalPaymentPayloadsForWebNotScaExemptErrorTest"}) // NOPMD
  void
      makeExternalPaymentForWebShouldReturnForbiddenWithPasswordAttemptsRemainingWhenChallengeResponseIsIncorrectAndThereAreAttemptsRemaining(
          final ExternalPaymentRequest request,
          final boolean beneficiary,
          final Integer scaLvtCount)
          throws Exception {
    final UUID requestId = UUID.randomUUID();
    ErrorResponse expectedResponseBody =
        TestHelper.accessDeniedWithPasswordAttemptsRemainingErrorResponse(
            requestId, "2 attempts remaining");
    makeExternalPaymentForWebShouldReturnErrorWhenChallengeResponseIsNotSuccessfullyVerified(
        request,
        beneficiary,
        scaLvtCount,
        requestId,
        HttpStatus.FORBIDDEN.value(),
        readClassPathResource(
            "api/digitaluser/ReverifyForbiddenResponseWithPasswordAttemptsRemaining.json"),
        HttpStatus.FORBIDDEN.value(),
        expectedResponseBody);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource({"externalPaymentPayloadsForWebNotScaExemptErrorTest"}) // NOPMD
  void
      makeExternalPaymentForWebShouldReturnForbiddenWithZeroPasswordAttemptsRemainingWhenChallengeResponseIsIncorrectAndThereAreNoAttemptsRemaining(
          final ExternalPaymentRequest request,
          final boolean beneficiary,
          final Integer scaLvtCount)
          throws Exception {
    final UUID requestId = UUID.randomUUID();
    ErrorResponse expectedResponseBody =
        TestHelper.accessDeniedWithPasswordAttemptsRemainingErrorResponse(
            requestId, "0 attempts remaining");
    makeExternalPaymentForWebShouldReturnErrorWhenChallengeResponseIsNotSuccessfullyVerified(
        request,
        beneficiary,
        scaLvtCount,
        requestId,
        HttpStatus.FORBIDDEN.value(),
        readClassPathResource(
            "api/digitaluser/ReverifyForbiddenResponseWhenMaxPasswordAttemptedReached.json"),
        HttpStatus.FORBIDDEN.value(),
        expectedResponseBody);

    final RecordedRequest auditAccountLockedRequest = mockAuditService.takeRequest();

    assertThat(
        auditAccountLockedRequest.getPath(),
        is(equalTo("/audit/payment/authentication/account-locked")));
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource({"externalPaymentPayloadsForWebNotScaExemptErrorTest"}) // NOPMD
  void
      makeExternalPaymentForWebShouldReturnForbiddenWhenChallengeResponseIsIncorrectAndPasswordAttemptsRemainingNotInReverifyResponse(
          final ExternalPaymentRequest request,
          final boolean beneficiary,
          final Integer scaLvtCount)
          throws Exception {
    final UUID requestId = UUID.randomUUID();
    ErrorResponse expectedResponseBody = TestHelper.accessDeniedErrorResponse(requestId);
    makeExternalPaymentForWebShouldReturnErrorWhenChallengeResponseIsNotSuccessfullyVerified(
        request,
        beneficiary,
        scaLvtCount,
        requestId,
        HttpStatus.FORBIDDEN.value(),
        readClassPathResource("api/digitaluser/ReverifyForbiddenResponse.json"),
        HttpStatus.FORBIDDEN.value(),
        expectedResponseBody);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource({"externalPaymentPayloadsForWebNotScaExemptErrorTest"}) // NOPMD
  void
      makeExternalPaymentForWebShouldReturnInternalServerErrorWhenUnexpectedErrorOnReverifyEndpoint(
          final ExternalPaymentRequest request,
          final boolean beneficiary,
          final Integer scaLvtCount)
          throws Exception {
    final UUID requestId = UUID.randomUUID();
    ErrorResponse expectedResponseBody = TestHelper.internalError(requestId);
    List<Integer> reverifyErrorResponses = Arrays.asList(400, 401, 404, 500, 503); // NOPMD
    for (Integer errorResponse : reverifyErrorResponses) {
      makeExternalPaymentForWebShouldReturnErrorWhenChallengeResponseIsNotSuccessfullyVerified(
          request,
          beneficiary,
          scaLvtCount,
          requestId,
          errorResponse,
          null,
          HttpStatus.INTERNAL_SERVER_ERROR.value(),
          expectedResponseBody);
      tearDownDb();
    }
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private void
      makeExternalPaymentForWebShouldReturnErrorWhenChallengeResponseIsNotSuccessfullyVerified(
          final ExternalPaymentRequest request,
          final boolean beneficiary,
          final Integer scaLvtCount,
          final UUID requestId,
          final int reverifyResponseHttpStatus,
          final String digitalUserServiceReverifyResponseBody,
          final int expectedPaymentServiceHttpStatus,
          final ErrorResponse expectedResponseBody)
          throws Exception {

    final String jwt = buildJwt(claimsMap(REQUIRED_SCOPES, WEB_CHANNEL));

    if (scaLvtCount != null) {
      setupScaLvtCount(scaLvtCount);
    }

    // First request validated
    stubExternalPaymentRequestForScaChallenge(beneficiary, true);

    postPaymentRequestForScaChallenge(requestId, request, jwt, true);

    stubDigitalUserServiceReverifyChallengeFailResponse(
        reverifyResponseHttpStatus, digitalUserServiceReverifyResponseBody);
    stubAuditSuccess();
    stubAuditSuccess();

    postWebPaymentWithSca(request, requestId, jwt, PASSWORD_CHARS_CHALLENGE_RESPONSE)
        .expectStatus()
        .isEqualTo(expectedPaymentServiceHttpStatus)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponseBody);

    verifyExternalPaymentRequestForScaChallenge(beneficiary, requestId, jwt);
    verifyDigitalUserServiceReAuthChallengeRequest(requestId, jwt);
    verifyDigitalUserServiceReverifyChallengeRequest(
        requestId, jwt, PASSWORD_CHARS_CHALLENGE_RESPONSE);

    if (HttpStatus.FORBIDDEN.value() == expectedPaymentServiceHttpStatus) {
      final RecordedRequest auditAuthFailRequest = mockAuditService.takeRequest();

      assertThat(
          auditAuthFailRequest.getPath(), is(equalTo("/audit/payment/authentication/failure")));
      assertThat(
          auditAuthFailRequest.getHeader(HttpHeaders.AUTHORIZATION),
          is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
      assertThat(
          auditAuthFailRequest.getHeader(HttpHeaders.HOST),
          is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
      assertThat(
          auditAuthFailRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
      assertThat(auditAuthFailRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
      assertThat(
          auditAuthFailRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
          is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
    }
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makeExternalPaymentAndValidateWithBeneficiaryShouldReturnConflictWhenBeneficiaryNotFound(
      final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ExternalPaymentRequest request =
        buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    stubBeneficiaryServiceEntityNotFound();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void
      makeExternalPaymentAndValidateWithBeneficiaryShouldReturnInternalServerErrorWhenBeneficiaryAccessDenied(
          final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ExternalPaymentRequest request =
        buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT);
    final ErrorResponse expectedResponse = TestHelper.internalError(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    stubBeneficiaryServiceAccessDenied();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makeExternalPaymentAndValidateWithBeneficiaryShouldReturnBadRequestWhenReferenceSpecified(
      final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ExternalPaymentRequest request =
        buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT)
            .toBuilder()
            .reference(REFERENCE)
            .build();
    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("Specifying a reference with a beneficiary is unsupported")
                    .path("reference")
                    .build())
            .build();

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    stubAccountServiceEntityAccessDenied();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.BAD_REQUEST)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makeExternalPaymentAndValidateWithBeneficiaryShouldReturnConflictWhenBeneficiaryIsInternal(
      final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ExternalPaymentRequest request =
        buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    stubBeneficiaryServiceResponse(
        HttpStatus.OK, readClassPathResource("api/account/beneficiary/ResponseInternal.json"));

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  public void makeInternalPaymentForAppShouldSucceedWhereScaRequired() throws Throwable {
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
    makeInternalPaymentShouldSucceedWhereScaRequired(request, false, null, AMOUNT, SAPP_CHANNEL);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("internalPaymentPayloadsForWebNotScaExempt")
  public void makeInternalPaymentForWebShouldSucceedWhereScaRequired(
      final InternalPaymentRequest request,
      final boolean saveBeneficiary,
      final Integer scaLvtCount,
      final BigDecimal paymentAmount)
      throws Throwable {
    makeInternalPaymentShouldSucceedWhereScaRequired(
        request, saveBeneficiary, scaLvtCount, paymentAmount, WEB_CHANNEL);
  }

  private void makeInternalPaymentShouldSucceedWhereScaRequired(
      final InternalPaymentRequest request,
      final boolean saveBeneficiary,
      final Integer scaLvtCount,
      final BigDecimal paymentAmount,
      final String channel)
      throws Throwable {
    final UUID requestId = UUID.randomUUID();

    final String jwt = buildJwt(claimsMap(REQUIRED_SCOPES, channel));
    final boolean isWebChannel = WEB_CHANNEL.equals(channel);

    if (isWebChannel && scaLvtCount != null) {
      setupScaLvtCount(scaLvtCount);
    }

    // First request validated
    stubInternalPaymentRequestForScaChallenge(isWebChannel);
    if (isWebChannel && !saveBeneficiary) {
      stubGetBeneficiariesByAccountNumberNoneFound();
      stubGetOwnedAccountsNoneFound();
    }

    // Second request validated and initiated
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();
    stubInitiatePaymentAuthentic("api/authentic/payment/OneOffTransferResponse.xml");
    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubFindAccountSuccess(CREDITOR_ACCOUNT_NUMBER_INTERNAL);

    stubAuditSuccess();
    stubAuditSuccess();
    stubSaveBeneficiarySuccess();

    final String challenge =
        postPaymentRequestForScaChallenge(requestId, request, jwt, isWebChannel);

    if (isWebChannel) {
      assertThat(challenge, is(EXPECTED_WEB_PASSWORD_POSITIONS_CHALLENGE));
      stubDigitalUserServiceReverifyChallengeResponse();
      postWebPaymentWithSca(request, requestId, jwt, PASSWORD_CHARS_CHALLENGE_RESPONSE)
          .expectStatus()
          .isNoContent();
      verifyDigitalUserServiceReAuthChallengeRequest(requestId, jwt);
      verifyDigitalUserServiceReverifyChallengeRequest(
          requestId, jwt, PASSWORD_CHARS_CHALLENGE_RESPONSE);
    } else {
      final String challengeResponse = SigningUtils.signWithPrivateKey(keyPair, challenge);
      final String encodedPublicKey = SigningUtils.encodePublicKey(keyPair);
      postPaymentWithSca(request, requestId, jwt, challenge, challengeResponse, encodedPublicKey)
          .expectStatus()
          .isNoContent();
    }

    verifyInternalPaymentRequestForScaChallenge(requestId, jwt);

    if (isWebChannel && !saveBeneficiary) {
      verifyFindGroupedAccounts(requestId, jwt);
      verifyGetBeneficiariesByAccountNumber(requestId, jwt, DEBTOR_ACCOUNT_NUMBER);
    }
    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    verifyFindAccount(
        CREDITOR_ACCOUNT_NUMBER_INTERNAL, ACCOUNT_DETAIL_QUERY_PARAMS, requestId, jwt);

    final AuditPaymentAuthSuccessRequest actualPaymentAuthRequest =
        verifyAuditAuthenticationSuccess(requestId, jwt);

    final LinkPaymentRequest expectedLinkPaymentRequest =
        LinkPaymentRequest.builder()
            .trackingId(actualPaymentAuthRequest.getTrackingId())
            .trackingCode(actualPaymentAuthRequest.getTrackingCode())
            .ipAddress(CLIENT_IP)
            .paymentDetails(
                LinkInternalPaymentDetails.builder()
                    .uniqueReference(PAYMENT_IDEMPOTENCY_KEY)
                    .transactionId(TRANSACTION_ID_INTERNAL)
                    .amount(paymentAmount)
                    .debtor(
                        LinkInternalPaymentDetails.InternalPaymentAccountDetails.builder()
                            .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                            .build())
                    .sca(Sca.builder().decisionStatus(DecisionStatus.APPLIED).build())
                    .creditorDetails(
                        LinkInternalPaymentDetails.InternalPaymentAccountDetails.builder()
                            .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
                            .build())
                    .build())
            .build();
    verifyAuditLinkPayment(requestId, jwt, expectedLinkPaymentRequest);

    final SavingsTransactionLogEntry expected =
        SavingsTransactionLogEntry.builder()
            .accountNumber(Long.parseLong(DEBTOR_ACCOUNT_NUMBER))
            .amount(paymentAmount)
            .closure("N")
            .partySysId(Long.parseLong(PARTY_ID))
            .status(WITHDRAWAL_COMPLETE_STATUS)
            .targetAccountNumber(Long.parseLong(CREDITOR_ACCOUNT_NUMBER_INTERNAL))
            .transferIndicator("I")
            .build();
    assertSingleTransactionLogEntry(logEntryMatching(expected));
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("internalPaymentPayloadsWhereScaExempted")
  public void makeInternalPaymentShouldSucceedWhereScaExempted(
      final InternalPaymentRequest request,
      final Integer scaLvtCount,
      final BigDecimal paymentAmount,
      final ExemptReasonCode exemptReasonCode)
      throws Throwable {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwt(claimsMap(REQUIRED_SCOPES, WEB_CHANNEL));

    if (scaLvtCount != null) {
      setupScaLvtCount(scaLvtCount);
    }

    // Request validated and initiated
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();
    stubInitiatePaymentAuthentic("api/authentic/payment/OneOffTransferResponse.xml");
    stubFindAccountSuccess(CREDITOR_ACCOUNT_NUMBER_INTERNAL);

    // Stub service calls for sca exemption check
    if (exemptReasonCode.equals(ExemptReasonCode.TRBENF)) {
      stubGetBeneficiariesByAccountNumberFindsBeneficiaryMatchingCreditor();
    }
    if (exemptReasonCode.equals(ExemptReasonCode.OACTRN)) {
      stubGetBeneficiariesByAccountNumberNoneFound();
      stubGetOwnedAccountsOwnedMatchingCreditorFound();
    }
    if (exemptReasonCode.equals(ExemptReasonCode.LOWVAL)) {
      stubGetBeneficiariesByAccountNumberNoneFound();
      stubGetOwnedAccountsNoneFound();
    }

    stubAuditSuccess();
    stubAuditSuccess();

    postPaymentWithoutSca(request, requestId, jwt);

    verifyAuditDecision(
        requestId,
        jwt,
        Sca.builder()
            .decisionStatus(DecisionStatus.EXEMPTED)
            .exemptReasonCode(exemptReasonCode)
            .build());

    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    verifyFindAccount(
        CREDITOR_ACCOUNT_NUMBER_INTERNAL, ACCOUNT_DETAIL_QUERY_PARAMS, requestId, jwt);

    // Verify service calls for sca exemption check
    if (exemptReasonCode.equals(ExemptReasonCode.TRBENF)) {
      verifyGetBeneficiariesByAccountNumber(requestId, jwt, DEBTOR_ACCOUNT_NUMBER);
    }
    if (exemptReasonCode.equals(ExemptReasonCode.OACTRN)) {
      verifyGetBeneficiariesByAccountNumber(requestId, jwt, DEBTOR_ACCOUNT_NUMBER);
      verifyFindGroupedAccounts(requestId, jwt);
    }
    if (exemptReasonCode.equals(ExemptReasonCode.LOWVAL)) {
      verifyGetBeneficiariesByAccountNumber(requestId, jwt, DEBTOR_ACCOUNT_NUMBER);
      verifyFindGroupedAccounts(requestId, jwt);
    }

    final LinkPaymentRequest expectedLinkPaymentRequest =
        LinkPaymentRequest.builder()
            .trackingId(UUID.randomUUID())
            .trackingCode("random_generated_tracking_code")
            .ipAddress(CLIENT_IP)
            .paymentDetails(
                LinkInternalPaymentDetails.builder()
                    .uniqueReference(PAYMENT_IDEMPOTENCY_KEY)
                    .transactionId(TRANSACTION_ID_INTERNAL)
                    .amount(paymentAmount)
                    .debtor(
                        LinkInternalPaymentDetails.InternalPaymentAccountDetails.builder()
                            .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                            .build())
                    .sca(
                        Sca.builder()
                            .decisionStatus(DecisionStatus.EXEMPTED)
                            .exemptReasonCode(exemptReasonCode)
                            .build())
                    .creditorDetails(
                        LinkInternalPaymentDetails.InternalPaymentAccountDetails.builder()
                            .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
                            .build())
                    .build())
            .build();
    verifyAuditLinkPaymentCheck(
        requestId,
        jwt,
        expectedLinkPaymentRequest.getPaymentDetails(),
        expectedLinkPaymentRequest.getIpAddress());

    final SavingsTransactionLogEntry expected =
        SavingsTransactionLogEntry.builder()
            .accountNumber(Long.parseLong(DEBTOR_ACCOUNT_NUMBER))
            .amount(paymentAmount)
            .closure("N")
            .partySysId(Long.parseLong(PARTY_ID))
            .status(WITHDRAWAL_COMPLETE_STATUS)
            .targetAccountNumber(Long.parseLong(CREDITOR_ACCOUNT_NUMBER_INTERNAL))
            .transferIndicator("I")
            .build();
    assertSingleTransactionLogEntry(logEntryMatching(expected));
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makeInternalPaymentAndValidatePaymentShouldReturnConflictWhenDebtorAccountAccessDenied(
      final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedDebtorAccount(requestId);

    stubAccountServiceEntityAccessDenied();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makeInternalPaymentAndValidatePaymentShouldReturnConflictWhenCreditorAccountAccessDenied(
      final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubAccountServiceEntityAccessDenied();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void
      makeInternalPaymentAndValidatePaymentShouldReturnConflictWhenPaymentExceedsCreditorDepositLimit(
          final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT, AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse =
        TestHelper.paymentRejectedCreditorAccountDepositLimitExceeded(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();

    stubFindAccountSuccess(CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    verifyFindAccount(
        CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT,
        ACCOUNT_DETAIL_QUERY_PARAMS,
        requestId,
        jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void
      makeInternalPaymentAndValidatePaymentShouldReturnConflictWhenPaymentExceedsOtherCreditorDepositLimit(
          final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT, AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedCreditorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER); // Debtor

    stubValidateCreditorDependenciesSuccess();

    stubAccountServiceEntityNoCustomerRelationshipException(); // Creditor - debtor doesn't own
    // account
    stubFindAccountSuccess(CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT); // Creditor

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    verifyFindAccount(
        CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT,
        ACCOUNT_DETAIL_QUERY_PARAMS,
        requestId,
        jwt);
    verifyFindAccount(
        CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT,
        ACCOUNT_DETAIL_OTHER_QUERY_PARAMS,
        requestId,
        jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makeInternalPaymentAndValidatePaymentShouldReturnConflictWhenInvalidAccountHolderRole(
      final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedDebtorAccount(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER); // Debtor
    stubGetAccountPaymentDetails(false, true);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makeInternalPaymentAndValidatePaymentShouldReturnConflictWhenMultipleSignatoriesRequired(
      final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse =
        TestHelper.paymentRejectedDebtorAccountMultipleSignatoriesRequired(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER); // Debtor
    stubGetAccountPaymentDetails(true, false);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void
      makeInternalPaymentAndValidatePaymentShouldReturnConflictWhenSessionBrandDoesNotMatchCreditorAccountBrand(
          final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.paymentRejectedDebtorAccount(requestId);

    stubFindAccountSuccessChelsea(); // Debtor

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makeInternalPaymentAndValidatePaymentShouldReturnConflictWhenInsufficientBalance(
      final String path) throws Exception {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, new BigDecimal("200000.00"));
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse =
        TestHelper.paymentRejectedDebtorAccountInsufficientFunds(requestId);

    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER); // Debtor
    stubValidateCreditorDependenciesSuccess();

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("saveBeneficiaryErrorResponses")
  void makePaymentShouldReturnOKWhenSavingBeneficiaryFails(
      final HttpStatus status, final String body, final ErrorResponse expectedResponse)
      throws Exception {
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);

    final ExternalPaymentRequest request =
        buildValidExternalPaymentRequestWithCreditorDetailsAndSaveBeneficiary(AMOUNT);

    setupScaLvtCountBelowThreshold();

    // First request validated
    stubExternalPaymentRequestForScaChallenge(false, false);

    // Second request validated and initiated
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);

    stubValidateCreditorDependenciesSuccess();
    stubInitiatePaymentAuthentic("api/authentic/payment/OneOffPaymentResponse.xml");

    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubAuditSuccess();
    stubAuditSuccess();

    stubSaveBeneficiaryFailure(status, body);

    final String challenge = postPaymentRequestForScaChallenge(REQUEST_ID, request, jwt, false);
    final String challengeResponse = SigningUtils.signWithPrivateKey(keyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(keyPair);

    postPaymentWithSca(request, REQUEST_ID, jwt, challenge, challengeResponse, encodedPublicKey)
        .expectStatus()
        .isOk()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void makePaymentShouldReturnBadRequestWhenScaKeyInvalid() {
    final UUID requestId = UUID.randomUUID();
    final PaymentRequest request = buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT);
    final ErrorResponse expectedResponse = TestHelper.badPemKey(requestId);
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);

    final String challenge = "some-challenge";
    final String challengeResponse = "some-challenge-response";
    final String encodedPublicKey = "invalidPemKey";

    postPaymentWithSca(request, requestId, jwt, challenge, challengeResponse, encodedPublicKey)
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makePaymentAndValidatePaymentShouldReturnUnauthorisedWhenBearerTokenIsNotValidJwt(
      final String path) {
    final UUID requestId = UUID.randomUUID();
    final PaymentRequest request = ExternalPaymentRequest.builder().build();
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);
    final String invalidJwt = "invalid.bearer.token";

    postRequestWithoutSca(path, request, requestId, invalidJwt)
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void sendPaymentFailureShouldReturnUnauthorisedWhenBearerTokenIsNotValidJwt() {
    final UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    final String jwt = "invalid.bearer.token";
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(getURI(PAYMENT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @ValueSource(strings = {CLAIM_AUD, CLAIM_SUB, CLAIM_BRAND_CODE})
  void makePaymentShouldReturnUnauthorisedWhenJwtMissingRequiredClaim(final String missingClaim) {
    final UUID requestId = UUID.randomUUID();
    final PaymentRequest request = ExternalPaymentRequest.builder().build();
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    final Map<String, Object> claims = claimsMap(REQUIRED_SCOPES);
    claims.remove(missingClaim);

    final String jwtWithMissingClaim = buildJwt(claims);

    postPaymentWithoutSca(request, requestId, jwtWithMissingClaim)
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @ValueSource(strings = {CLAIM_AUD, CLAIM_SUB, CLAIM_BRAND_CODE})
  void sendPaymentFailureShouldReturnUnauthorisedWhenJwtMissingRequiredClaim(
      final String missingClaim) {
    final UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    final Map<String, Object> claims = claimsMap(REQUIRED_SCOPES);
    claims.remove(missingClaim);

    final String jwtWithMissingClaim = buildJwt(claims);

    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(getURI(PAYMENT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwtWithMissingClaim)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makePaymentAndValidatePaymentShouldReturnForbiddenWhenJwtLacksRequiredScope(
      final String path) {
    final UUID requestId = UUID.randomUUID();
    final PaymentRequest request = buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT);
    final String jwtWithoutRequiredScope = buildJwtWithScope(OTHER_SCOPE);
    final ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    postRequestWithoutSca(path, request, requestId, jwtWithoutRequiredScope)
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void sendPaymentFailureShouldReturnForbiddenWhenJwtLacksRequiredScope() {
    final UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    final String jwtWithoutRequiredScope = buildJwtWithScope(OTHER_SCOPE);
    final ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(getURI(PAYMENT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwtWithoutRequiredScope)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makePaymentAndValidatePaymentShouldReturnForbiddenWhenSignatureIsInvalid(final String path) {
    final UUID requestId = UUID.randomUUID();
    final PaymentRequest request = ExternalPaymentRequest.builder().build();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.invalidRequestSignature(requestId);

    nonSigningWebClient
        .post()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, "request-signature-key-id-public")
        .header(HEADER_REQUEST_SIGNATURE, "invalid-signature")
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void sendPaymentFailureShouldReturnForbiddenWhenSignatureIsInvalid() {
    final UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = TestHelper.invalidRequestSignature(requestId);

    nonSigningWebClient
        .post()
        .uri(getURI(PAYMENT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, "request-signature-key-id-public")
        .header(HEADER_REQUEST_SIGNATURE, "invalid-signature")
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} - {arguments}") // NOPMD
  @MethodSource("validatedEndpoints") // NOPMD
  void makePaymentAndValidatePaymentShouldReturnBadRequestWhenRequestFailsBasicValidation(
      final String path) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ExternalPaymentRequest request =
        buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT)
            .toBuilder()
            .idempotencyKey(null)
            .build();
    final ErrorResponse expectedResponse = buildBadRequestErrorResponse(requestId);

    postRequestWithoutSca(path, request, requestId, jwt)
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void sendPaymentFailureShouldReturnBadRequestWhenRequestFailsBasicValidation() {
    final UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request =
        buildPaymentFailureRequest().toBuilder().idempotencyKey(null).build();
    final String jwt = buildJwtWithScope(REQUIRED_SCOPES);
    final ErrorResponse expectedResponse = buildBadRequestErrorResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(getURI(PAYMENT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, "request-signature-key-id-public")
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void makeInternalPaymentReturnForbiddenWhenSessionIdChanged() throws Throwable {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
    final Map<String, Object> claims = claimsMap(REQUIRED_SCOPES);
    final String jwt = buildJwt(claims);

    claims.remove(CLAIM_SID);
    claims.put(CLAIM_SID, UUID.randomUUID());

    final String jwtWithDiffSessionId = buildJwt(claims);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.ACCESS_DENIED)
                    .message("Access Denied")
                    .build())
            .build();

    setupScaLvtCountBelowThreshold();

    // First request validated
    stubInternalPaymentRequestForScaChallenge(false);

    // Second request validated and initiated
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    stubFindAccountSuccess(CREDITOR_ACCOUNT_NUMBER_INTERNAL);

    stubValidateCreditorDependenciesSuccess();
    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);

    stubAuditSuccess();
    stubAuditSuccess();

    final String challenge = postPaymentRequestForScaChallenge(requestId, request, jwt, false);
    final String challengeResponse = SigningUtils.signWithPrivateKey(keyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(keyPair);

    postPaymentWithSca(
            request,
            requestId,
            jwtWithDiffSessionId,
            challenge,
            challengeResponse,
            encodedPublicKey)
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);

    verifyAuditDecision(requestId, jwt);
    verifyAuditAuthenticationFailure(requestId, jwtWithDiffSessionId, CHALLENGE_FAILURE_TYPE);
  }

  @Test
  void shouldReturnUnauthorisedWhenBearerTokenIsMissing() {
    final UUID requestId = UUID.randomUUID();
    final InternalPaymentRequest request =
        buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT);
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    signingWebClientPublic
        .post()
        .uri(getURI(PAYMENT_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  private static Stream<String> validatedEndpoints() {
    return Stream.of(VALIDATE_PATH, PAYMENT_PATH);
  }

  private static Stream<Arguments> validatedEndpointsAndExternalPaymentPayloads() {
    return Stream.of(
        Arguments.of(
            VALIDATE_PATH, buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT), false),
        Arguments.of(
            VALIDATE_PATH, buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT), true),
        Arguments.of(
            PAYMENT_PATH, buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT), false),
        Arguments.of(
            PAYMENT_PATH, buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT), true));
  }

  private static Stream<Arguments> externalPaymentPayloads() {
    return Stream.of(
        Arguments.of(buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT), false, false),
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetailsAndSaveBeneficiary(AMOUNT),
            false,
            true),
        Arguments.of(buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT), true, false));
  }

  private static Stream<Arguments> externalPaymentPayloadsForWebNotScaExempt() {
    return Stream.of(
        // Not exempt as amount too high
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT),
            false,
            false,
            2,
            AMOUNT,
            false),
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT),
            false,
            false,
            2,
            AMOUNT,
            true),
        // Not exempt as saving beneficiary
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetailsAndSaveBeneficiary(EXEMPTED_AMOUNT),
            false,
            true,
            2,
            EXEMPTED_AMOUNT,
            false),
        // Not exempt as low val transaction count too high
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetails(EXEMPTED_AMOUNT),
            false,
            false,
            6,
            EXEMPTED_AMOUNT,
            false),
        // Not exempt as accessed_flag set to true, will return low_val transaction count + 1
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetails(EXEMPTED_AMOUNT),
            false,
            false,
            4,
            EXEMPTED_AMOUNT,
            true));
  }

  private static Stream<Arguments> externalPaymentPayloadsForWebNotScaExemptErrorTest() {
    return Stream.of(
        // Not exempt as amount too high
        Arguments.of(buildValidExternalPaymentRequestWithCreditorDetails(AMOUNT), false, 2),
        // Not exempt as saving beneficiary
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetailsAndSaveBeneficiary(EXEMPTED_AMOUNT),
            false,
            2),
        // Not exempt as low val transaction count too high
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetails(EXEMPTED_AMOUNT), false, 6));
  }

  private static Stream<Arguments> externalPaymentPayloadsWhereScaExempted() {
    return Stream.of(
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetails(EXEMPTED_AMOUNT),
            false,
            4,
            EXEMPTED_AMOUNT,
            ExemptReasonCode.LOWVAL,
            false),
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetails(EXEMPTED_AMOUNT),
            false,
            null,
            EXEMPTED_AMOUNT,
            ExemptReasonCode.LOWVAL,
            false),
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorBeneficiary(AMOUNT),
            true,
            4,
            AMOUNT,
            ExemptReasonCode.TRBENF,
            false),
        Arguments.of(
            buildValidExternalPaymentRequestWithCreditorDetails(EXEMPTED_AMOUNT),
            false,
            1,
            EXEMPTED_AMOUNT,
            ExemptReasonCode.LOWVAL,
            true));
  }

  private static Stream<Arguments> internalPaymentPayloadsWhereScaExempted() {
    return Stream.of(
        Arguments.of(
            buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, EXEMPTED_AMOUNT),
            4,
            EXEMPTED_AMOUNT,
            ExemptReasonCode.LOWVAL),
        Arguments.of(
            buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, EXEMPTED_AMOUNT),
            null,
            EXEMPTED_AMOUNT,
            ExemptReasonCode.LOWVAL),
        Arguments.of(
            buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT),
            4,
            AMOUNT,
            ExemptReasonCode.TRBENF),
        Arguments.of(
            buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT),
            4,
            AMOUNT,
            ExemptReasonCode.OACTRN));
  }

  private static Stream<Arguments> internalPaymentPayloadsForWebNotScaExempt() {
    return Stream.of(
        // Not exempt as amount too high
        Arguments.of(
            buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, AMOUNT),
            false,
            2,
            AMOUNT),
        // Not exempt as saving beneficiary
        Arguments.of(
            buildInternalPaymentRequestWithSaveBeneficiary(
                CREDITOR_ACCOUNT_NUMBER_INTERNAL, EXEMPTED_AMOUNT),
            true,
            2,
            EXEMPTED_AMOUNT),
        // Not exempt as low val transaction count too high
        Arguments.of(
            buildInternalPaymentRequest(CREDITOR_ACCOUNT_NUMBER_INTERNAL, EXEMPTED_AMOUNT),
            false,
            6,
            EXEMPTED_AMOUNT));
  }

  private static Stream<Arguments> saveBeneficiaryErrorResponses() throws JsonProcessingException {
    ErrorResponse conflictResponse =
        ErrorResponse.builder(HttpStatus.CONFLICT)
            .id(REQUEST_ID)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Beneficiary.Limit")
                    .message("Beneficiary limit reached")
                    .build())
            .build();

    String conflictResponseAsString = new ObjectMapper().writeValueAsString(conflictResponse);

    return Stream.of(
        Arguments.of(
            HttpStatus.CONFLICT,
            "asd",
            TestHelper.buildBeneficiaryTechnicalErrorResponse(REQUEST_ID)),
        Arguments.of(
            HttpStatus.CONFLICT, "", TestHelper.buildBeneficiaryTechnicalErrorResponse(REQUEST_ID)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            "",
            TestHelper.buildBeneficiaryTechnicalErrorResponse(REQUEST_ID)),
        Arguments.of(HttpStatus.CONFLICT, conflictResponseAsString, conflictResponse));
  }

  private URI getPaymentsURI() {
    return getURI(PAYMENT_PATH);
  }

  private URI getURI(final String path) {
    return URI.create("http://" + LOCALHOST_URL + port + PAYMENT_PATH + path);
  }

  private String readClassPathResource(final ClassPathResource classPathResource)
      throws IOException {
    return new String(
        Files.readAllBytes(classPathResource.getFile().toPath()), StandardCharsets.UTF_8);
  }

  private String readClassPathResource(final String classPathResource) throws IOException {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  private static Map<String, Object> claimsMap(final String scope, final String channel) {
    final Map<String, Object> claims = new HashMap<>();
    claims.put(CLAIM_SUB, SUB);
    claims.put(CLAIM_AUD, "DIGITAL_API");
    claims.put(CLAIM_BRAND_CODE, BRAND_CODE);
    claims.put(CLAIM_CHANNEL, channel);
    claims.put(CLAIM_SCOPE, scope);
    claims.put(CLAIM_TITLE, TITLE);
    claims.put(CLAIM_EMAIL, EMAIL);
    claims.put(CLAIM_LAST_NAME, SURNAME);
    claims.put(CLAIM_PARTY_ID, PARTY_ID);
    claims.put(CLAIM_SID, SESSION_ID);
    claims.put(CLAIM_SUB_TYPE, SUB_TYPE_CUSTOMER);
    return claims;
  }

  private static Map<String, Object> claimsMap(final String scope) {
    return claimsMap(scope, SAPP_CHANNEL);
  }

  private static Map<String, Object> systemClaimsMap(final String scope) {
    final Map<String, Object> claims = new HashMap<>();
    claims.put(CLAIM_SUB, SUB);
    claims.put(CLAIM_AUD, "DIGITAL_API");
    claims.put(CLAIM_BRAND_CODE, BRAND_CODE);
    claims.put(CLAIM_SCOPE, scope);
    claims.put(CLAIM_SUB_TYPE, SUB_TYPE_SYSTEM);
    return claims;
  }

  private String buildJwtWithScope(final String scope) {
    return buildJwt(claimsMap(scope));
  }

  private String buildJwt(final Map<String, Object> claims) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .addClaims(claims)
        .signWith(SignatureAlgorithm.RS256, jwtSigningPrivateKey)
        .compact();
  }

  private static ExternalPaymentRequest buildValidExternalPaymentRequestWithCreditorDetails(
      final BigDecimal amount) {
    return buildExternalPaymentRequestWithCreditorDetails(CREDITOR_SORT_CODE_VALID, amount);
  }

  private static ExternalPaymentRequest
      buildValidExternalPaymentRequestWithCreditorDetailsAndSaveBeneficiary(
          final BigDecimal amount) {
    return buildExternalPaymentRequest(
        ExternalCreditorDetails.builder()
            .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
            .sortCode(CREDITOR_SORT_CODE_VALID)
            .name(CREDITOR_NAME)
            .saveBeneficiary(true)
            .memorableName(CREDITOR_BENEFICIARY_MEMORABLE_NAME)
            .build(),
        REFERENCE,
        amount);
  }

  private static ExternalPaymentRequest buildExternalPaymentRequestWithCreditorDetails(
      final String creditorSortCode, final BigDecimal amount) {
    return buildExternalPaymentRequest(
        ExternalCreditorDetails.builder()
            .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
            .sortCode(creditorSortCode)
            .name(CREDITOR_NAME)
            .build(),
        REFERENCE,
        amount);
  }

  private static ExternalPaymentRequest buildValidExternalPaymentRequestWithCreditorBeneficiary(
      final BigDecimal amount) {
    return buildExternalPaymentRequest(
        ExternalCreditorBeneficiary.builder().beneficiaryId(CREDITOR_BENEFICIARY_ID).build(),
        null,
        amount);
  }

  private static ExternalPaymentRequest buildExternalPaymentRequest(
      final ExternalCreditor creditor, final String reference, final BigDecimal amount) {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(PAYMENT_IDEMPOTENCY_KEY)
        .currency(CURRENCY)
        .amount(amount)
        .reference(reference)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(creditor)
        .build();
  }

  private static InternalPaymentRequest buildInternalPaymentRequestWithSaveBeneficiary(
      final String creditorAccountNumber, final BigDecimal amount) {
    return buildInternalPaymentRequest(creditorAccountNumber, amount, true);
  }

  private static InternalPaymentRequest buildInternalPaymentRequest(
      final String creditorAccountNumber, final BigDecimal amount) {
    return buildInternalPaymentRequest(creditorAccountNumber, amount, false);
  }

  private static InternalPaymentRequest buildInternalPaymentRequest(
      final String creditorAccountNumber, final BigDecimal amount, final boolean saveBeneficiary) {
    return InternalPaymentRequest.builder()
        .idempotencyKey(PAYMENT_IDEMPOTENCY_KEY)
        .currency(CURRENCY)
        .amount(amount)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(
            InternalCreditorDetails.builder()
                .accountNumber(creditorAccountNumber)
                .saveBeneficiary(saveBeneficiary)
                .build())
        .build();
  }

  private String postPaymentRequestForScaChallenge(
      final UUID requestId,
      final PaymentRequest request,
      final String jwt,
      final boolean isWebChannel) {
    final ErrorResponse expectedResponse =
        TestHelper.scaRequired(
            requestId, isWebChannel ? SCA_REQUIRED_MESSAGE_WEB : SCA_REQUIRED_MESSAGE_SAPP);

    final EntityExchangeResult<ErrorResponse> result =
        postPaymentWithoutSca(request, requestId, jwt)
            .expectStatus()
            .isForbidden()
            .expectBody(ErrorResponse.class)
            .isEqualTo(expectedResponse)
            .returnResult();

    return result.getResponseHeaders().getFirst("x-ybs-sca-challenge");
  }

  private WebTestClient.ResponseSpec postPaymentWithoutSca(
      final PaymentRequest request, final UUID requestId, final String jwt) {
    return postRequestWithoutSca(PAYMENT_PATH, request, requestId, jwt);
  }

  private WebTestClient.ResponseSpec postRequestWithoutSca(
      final String path, final PaymentRequest request, final UUID requestId, final String jwt) {
    return signingWebClientPublic
        .post()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange();
  }

  private WebTestClient.ResponseSpec postPaymentWithSca(
      final PaymentRequest request,
      final UUID requestId,
      final String jwt,
      final String challenge,
      final String challengeResponse,
      final String encodedPublicKey) {
    return signingWebClientPublic
        .post()
        .uri(getPaymentsURI())
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .bodyValue(request)
        .exchange();
  }

  private WebTestClient.ResponseSpec postWebPaymentWithSca(
      final PaymentRequest request,
      final UUID requestId,
      final String jwt,
      final String challengeResponse) {
    return signingWebClientPublic
        .post()
        .uri(getPaymentsURI())
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .bodyValue(request)
        .exchange();
  }

  private void stubExternalPaymentRequestForScaChallenge(
      final boolean beneficiary, final boolean isWebChannel) throws IOException {
    if (isWebChannel) {
      stubDigitalUserServiceReAuthChallengeResponse();
    }
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }
    stubValidateCreditorDependenciesSuccess();
    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);
    stubAuditSuccess();
  }

  private void verifyExternalPaymentRequestForScaChallenge(
      final boolean beneficiary, final UUID requestId, final String jwt)
      throws InterruptedException, IOException {
    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    if (beneficiary) {
      verifyFindBeneficiary(requestId, jwt);
    }
    verifyAuditDecision(requestId, jwt);
  }

  private void stubInternalPaymentRequestForScaChallenge(final boolean isWebChannel)
      throws IOException {
    if (isWebChannel) {
      stubDigitalUserServiceReAuthChallengeResponse();
    }
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    stubFindAccountSuccess(CREDITOR_ACCOUNT_NUMBER_INTERNAL);
    stubAuditSuccess();
  }

  private void verifyInternalPaymentRequestForScaChallenge(final UUID requestId, final String jwt)
      throws InterruptedException, IOException {
    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    verifyFindAccount(
        CREDITOR_ACCOUNT_NUMBER_INTERNAL, ACCOUNT_DETAIL_QUERY_PARAMS, requestId, jwt);
    verifyAuditDecision(requestId, jwt);
  }

  private void stubFindAccountSuccess(final String accountNumber) throws IOException {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource(
            String.format("api/account/account/ResponseAccountNumber%s.json", accountNumber)));
  }

  private void stubFindAccountSuccessChelsea() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource("api/account/account/ResponseAccountNumberChelsea.json"));
  }

  private void stubSaveBeneficiarySuccess() {
    stubBeneficiaryServiceResponse(HttpStatus.ACCEPTED, "");
  }

  private void stubSaveBeneficiaryFailure(final HttpStatus status, final String body) {
    stubBeneficiaryServiceResponse(status, body);
  }

  private void stubFindBeneficiarySuccess() throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.OK, readClassPathResource("api/account/beneficiary/ResponseExternal.json"));
  }

  private void stubGetBeneficiariesByAccountNumberNoneFound() throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.OK,
        readClassPathResource("api/account/beneficiary/ResponseEmptyBeneficiaryList.json"));
  }

  private void stubGetBeneficiariesByAccountNumberFindsBeneficiaryMatchingCreditor()
      throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.OK,
        readClassPathResource(
            "api/account/beneficiary/ResponseListWithBeneficiaryMatchingCreditor.json"));
  }

  private void stubAccountServiceEntityAccessDenied() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.FORBIDDEN, readClassPathResource("api/account/ResponseErrorAccessDenied.json"));
  }

  private void stubAccountServiceEntityNotFound() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.NOT_FOUND,
        readClassPathResource("api/account/ResponseErrorResourceNotFound.json"));
  }

  private void stubGetOwnedAccountsNoneFound() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource("api/account/account/ResponseAccountGroupNoOwned.json"));
  }

  private void stubGetOwnedAccountsOwnedMatchingCreditorFound() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource(
            "api/account/account/ResponseAccountGroupOwnedMatchingCreditor.json"));
  }

  private void stubAccountServiceEntityNoCustomerRelationshipException() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.FORBIDDEN,
        readClassPathResource("api/account/ResponseErrorAccessDeniedNoCustomerRelationship.json"));
  }

  private void stubBeneficiaryServiceAccessDenied() throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.FORBIDDEN, readClassPathResource("api/account/ResponseErrorAccessDenied.json"));
  }

  private void stubBeneficiaryServiceEntityNotFound() throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.NOT_FOUND,
        readClassPathResource("api/account/ResponseErrorResourceNotFound.json"));
  }

  private void stubAccountServiceResponse(final HttpStatus httpStatus, final String response) {
    mockAccountService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(response));
  }

  private void stubBeneficiaryServiceResponse(final HttpStatus httpStatus, final String response) {
    mockBeneficiaryService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(response));
  }

  private void stubDigitalUserServiceReAuthChallengeResponse() throws IOException {
    mockDigitalUserService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(readClassPathResource("api/digitaluser/ReauthChallengeResponse.json")));
  }

  private void stubDigitalUserServiceReAuthChallengeFailResponse(final int httpStatus) {
    mockDigitalUserService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
  }

  private void stubDigitalUserServiceReverifyChallengeResponse() {
    mockDigitalUserService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
  }

  private void stubDigitalUserServiceReverifyChallengeFailResponse(
      final int httpStatus, final String body) {
    if (body == null) {
      mockDigitalUserService.enqueue(
          new MockResponse()
              .setResponseCode(httpStatus)
              .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
    } else {
      mockDigitalUserService.enqueue(
          new MockResponse()
              .setResponseCode(httpStatus)
              .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
              .setBody(body));
    }
  }

  private void verifyFindAccount(final String accountNumber, final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockAccountService.takeRequest();
    assertThat(
        accountServiceRequest.getPath(),
        is(equalTo(String.format("/account/private/accounts/%s", accountNumber))));
    verifyFindAccount(accountServiceRequest, requestId, jwt);
  }

  private void verifyFindAccount(
      final String accountNumber, final String queryParams, final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockAccountService.takeRequest();
    assertThat(
        accountServiceRequest.getPath(),
        is(equalTo(String.format("/account/private/accounts/%s%s", accountNumber, queryParams))));
    verifyFindAccount(accountServiceRequest, requestId, jwt);
  }

  private void verifyFindAccount(
      final RecordedRequest accountServiceRequest, final UUID requestId, final String jwt) {
    assertThat(accountServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAccountServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  private void verifyFindGroupedAccounts(final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockAccountService.takeRequest();
    assertThat(accountServiceRequest.getPath(), is("/account/private/accounts/grouped"));
    verifyFindGroupedAccounts(accountServiceRequest, requestId, jwt);
  }

  private void verifyFindGroupedAccounts(
      final RecordedRequest accountServiceRequest, final UUID requestId, final String jwt) {
    assertThat(accountServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAccountServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  private void verifyGetBeneficiariesByAccountNumber(
      final UUID requestId, final String jwt, final String accountNumber)
      throws InterruptedException {
    final RecordedRequest beneficiaryServiceRequest = mockBeneficiaryService.takeRequest();
    assertThat(
        beneficiaryServiceRequest.getPath(),
        is("/beneficiary/accounts/" + accountNumber + "/beneficiaries"));
    verifyGetBeneficiariesByAccountNumber(beneficiaryServiceRequest, requestId, jwt);
  }

  private void verifyGetBeneficiariesByAccountNumber(
      final RecordedRequest beneficiaryServiceRequest, final UUID requestId, final String jwt) {
    assertThat(beneficiaryServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        beneficiaryServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        beneficiaryServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockBeneficiaryServicePort)));
    assertThat(
        beneficiaryServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(beneficiaryServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        beneficiaryServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  private void verifyCalculateWithdrawalInterestPenalty(
      final String accountNumber,
      final BigDecimal withdrawalAmount,
      final UUID requestId,
      final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockAccountService.takeRequest();
    assertThat(accountServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        accountServiceRequest.getPath(),
        is(
            equalTo(
                String.format(
                    "/account/private/accounts/%s/withdrawal-interest-penalty?withdrawalAmount=%s",
                    accountNumber, withdrawalAmount))));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAccountServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  private void verifyFindBeneficiary(final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockBeneficiaryService.takeRequest();
    assertThat(accountServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        accountServiceRequest.getPath(),
        is(
            equalTo(
                "/beneficiary/private/accounts/"
                    + DEBTOR_ACCOUNT_NUMBER
                    + "/beneficiaries/"
                    + CREDITOR_BENEFICIARY_ID)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockBeneficiaryServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  private void verifySaveBeneficiary(
      final UUID requestId, final String jwt, final ExternalPaymentRequest paymentRequest)
      throws Exception {
    final RecordedRequest accountServiceRequest = mockBeneficiaryService.takeRequest();
    assertThat(accountServiceRequest.getMethod(), is("POST"));
    assertThat(
        accountServiceRequest.getPath(),
        is(equalTo("/beneficiary/private/accounts/" + DEBTOR_ACCOUNT_NUMBER + "/beneficiaries")));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockBeneficiaryServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    assertThat(paymentRequest.getCreditor(), instanceOf(ExternalCreditorDetails.class));
    ExternalCreditorDetails details = ((ExternalCreditorDetails) paymentRequest.getCreditor());
    ExternalBeneficiary expectedBeneficiary =
        ExternalBeneficiary.builder()
            .accountNumber(details.getExternalAccountNumber())
            .accountSortCode(details.getSortCode())
            .name(details.getName())
            .reference(paymentRequest.getReference())
            .memorableName(details.getMemorableName())
            .build();

    assertThat(
        accountServiceRequest.getBody().readUtf8(),
        equalTo(objectMapper.writeValueAsString(expectedBeneficiary)));
  }

  private void verifyDigitalUserServiceReAuthChallengeRequest(
      final UUID requestId, final String jwt) throws InterruptedException {
    final RecordedRequest reAuthRequest = mockDigitalUserService.takeRequest();
    assertThat(reAuthRequest.getMethod(), is(HTTP_GET));
    assertThat(reAuthRequest.getPath(), is(equalTo("/digitaluser/reauth-challenge")));
    assertThat(
        reAuthRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        reAuthRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockDigitalUserServicePort)));
    assertThat(reAuthRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(reAuthRequest.getHeader(HEADER_BRAND_CODE), is(equalTo(BRAND_CODE)));
    assertThat(reAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        reAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  private void verifyDigitalUserServiceReverifyChallengeRequest(
      final UUID requestId, final String jwt, final String challengeResponse)
      throws InterruptedException, IOException {
    final RecordedRequest reAuthRequest = mockDigitalUserService.takeRequest();
    assertThat(reAuthRequest.getMethod(), is("POST"));
    assertThat(reAuthRequest.getPath(), is(equalTo("/digitaluser/reverify-challenge")));
    final DigitalUserReverifyChallengeRequest expectedBody =
        DigitalUserReverifyChallengeRequest.builder().passwordCharacters(challengeResponse).build();
    final DigitalUserReverifyChallengeRequest actualBody =
        objectMapper.readValue(
            reAuthRequest.getBody().readUtf8(), DigitalUserReverifyChallengeRequest.class);
    assertThat(actualBody, is(equalTo(expectedBody)));
    assertThat(
        reAuthRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        reAuthRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockDigitalUserServicePort)));
    assertThat(reAuthRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(reAuthRequest.getHeader(HEADER_BRAND_CODE), is(equalTo(BRAND_CODE)));
    assertThat(reAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        reAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  private void stubAuditSuccess() {
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  private void verifyAuditDecision(final UUID requestId, final String jwt)
      throws IOException, InterruptedException {

    verifyAuditDecision(
        requestId, jwt, Sca.builder().decisionStatus(DecisionStatus.APPLIED).build());
  }

  private void verifyAuditDecision(final UUID requestId, final String jwt, final Sca sca)
      throws InterruptedException, IOException {
    final RecordedRequest auditDecisionRequest = mockAuditService.takeRequest();
    assertThat(auditDecisionRequest.getMethod(), is("POST"));
    assertThat(auditDecisionRequest.getPath(), is(equalTo("/audit/payment/decision")));
    assertThat(
        auditDecisionRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditDecisionRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(
        auditDecisionRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditDecisionRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditDecisionRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final AuditPaymentDecisionRequest actualPaymentDecisionRequest =
        objectMapper.readValue(
            auditDecisionRequest.getBody().readUtf8(), AuditPaymentDecisionRequest.class);
    assertThat(actualPaymentDecisionRequest.getIpAddress(), is(CLIENT_IP));
    assertThat(
        actualPaymentDecisionRequest.getPaymentDetails(),
        is(
            SimplePaymentDetails.builder()
                .uniqueReference(PAYMENT_IDEMPOTENCY_KEY)
                .sca(sca)
                .build()));
  }

  private AuditPaymentAuthSuccessRequest verifyAuditAuthenticationSuccess(
      final UUID requestId, final String jwt) throws InterruptedException, JsonProcessingException {
    final RecordedRequest auditAuthRequest = mockAuditService.takeRequest();
    assertThat(auditAuthRequest.getPath(), is(equalTo("/audit/payment/authentication/success")));
    assertThat(
        auditAuthRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditAuthRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(auditAuthRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final AuditPaymentAuthSuccessRequest actualPaymentAuthRequest =
        objectMapper.readValue(
            auditAuthRequest.getBody().readUtf8(), AuditPaymentAuthSuccessRequest.class);
    assertThat(actualPaymentAuthRequest.getTrackingId(), notNullValue());
    assertThat(actualPaymentAuthRequest.getTrackingCode(), notNullValue());
    assertThat(actualPaymentAuthRequest.getIpAddress(), is(CLIENT_IP));
    assertThat(
        actualPaymentAuthRequest.getPaymentDetails(),
        is(SimplePaymentDetails.builder().uniqueReference(PAYMENT_IDEMPOTENCY_KEY).build()));
    return actualPaymentAuthRequest;
  }

  private void verifyAuditLinkPayment(
      final UUID requestId, final String jwt, final LinkPaymentRequest expectedLinkPaymentRequest)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest auditPaymentLinkRequest = mockAuditService.takeRequest();
    assertThat(auditPaymentLinkRequest.getPath(), is(equalTo("/audit/payment/link")));
    assertThat(
        auditPaymentLinkRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditPaymentLinkRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(
        auditPaymentLinkRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditPaymentLinkRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditPaymentLinkRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final LinkPaymentRequest actualPaymentLinkRequest =
        objectMapper.readValue(
            auditPaymentLinkRequest.getBody().readUtf8(), LinkPaymentRequest.class);

    assertThat(actualPaymentLinkRequest, is(expectedLinkPaymentRequest));
  }

  private void verifyAuditLinkPaymentCheck(
      final UUID requestId,
      final String jwt,
      final LinkPaymentDetails expectedLinkPaymentDetails,
      final String expectedIpAddress)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest auditPaymentLinkRequest = mockAuditService.takeRequest();
    assertThat(auditPaymentLinkRequest.getPath(), is(equalTo("/audit/payment/link")));
    assertThat(
        auditPaymentLinkRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditPaymentLinkRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(
        auditPaymentLinkRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditPaymentLinkRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditPaymentLinkRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final LinkPaymentRequest actualPaymentLinkRequest =
        objectMapper.readValue(
            auditPaymentLinkRequest.getBody().readUtf8(), LinkPaymentRequest.class);
    assertThat(actualPaymentLinkRequest.getTrackingCode(), is(notNullValue()));
    assertThat(actualPaymentLinkRequest.getTrackingId(), is(notNullValue()));

    assertThat(actualPaymentLinkRequest.getIpAddress(), is(expectedIpAddress));
    assertThat(actualPaymentLinkRequest.getPaymentDetails(), is(expectedLinkPaymentDetails));
  }

  private void verifyAuditAuthenticationFailure(
      final UUID requestId, final String jwt, final String failureType)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest auditAuthRequest = mockAuditService.takeRequest();
    assertThat(auditAuthRequest.getPath(), is(equalTo("/audit/payment/authentication/failure")));
    assertThat(
        auditAuthRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditAuthRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(auditAuthRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final AuditPaymentAuthFailureRequest actualPaymentFailureAuthRequest =
        objectMapper.readValue(
            auditAuthRequest.getBody().readUtf8(), AuditPaymentAuthFailureRequest.class);
    assertThat(actualPaymentFailureAuthRequest.getIpAddress(), is(CLIENT_IP));
    assertThat(
        actualPaymentFailureAuthRequest.getPaymentDetails(),
        is(
            AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                .uniqueReference(PAYMENT_IDEMPOTENCY_KEY)
                .failureType(failureType)
                .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                .build()));
  }

  private void stubInitiatePaymentAuthentic(final String response) throws IOException {
    mockAuthenticWebAuth.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(readClassPathResource(response)));
  }

  private ErrorResponse buildBadRequestErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("400 Bad Request")
        .message("Invalid request body")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Field.Missing")
                .message("You must specify a UUID idempotency key")
                .build())
        .build();
  }

  private static PaymentFailureRequest buildPaymentFailureRequest() {
    return PaymentFailureRequest.builder()
        .idempotencyKey(PAYMENT_IDEMPOTENCY_KEY)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .build();
  }

  private static ExternalCreditorDetails buildValidExternalPayeeRequest() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber("12345678")
        .sortCode("112233")
        .build();
  }

  private static InternalAccountDetails buildValidInternalAccountDetails() {
    return InternalAccountDetails.builder().accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL).build();
  }

  private ExternalCreditorDetails buildExternalPayeeWithYBSSortCode() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .sortCode(CREDITOR_SORT_CODE_YBS)
        .build();
  }

  private Matcher<SavingsTransactionLogEntry> logEntryMatching(
      final SavingsTransactionLogEntry expected) {
    return allOf(
        samePropertyValuesAs(expected, "sysId", "dailySequenceNumber", "startTime", "endTime"),
        hasProperty("sysId", notNullValue()),
        hasProperty("dailySequenceNumber", notNullValue()),
        hasProperty("startTime", notNullValue()),
        hasProperty("endTime", notNullValue()));
  }

  private void assertSingleTransactionLogEntry(final Matcher<SavingsTransactionLogEntry> expected) {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              frontOfficeTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from SavingsTransactionLogEntry e");

          @SuppressWarnings("unchecked")
          final List<SavingsTransactionLogEntry> actual = query.getResultList();

          assertThat(actual, contains(expected));
        });
  }

  private void tearDownDb() {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final EntityManager frontOfficeEntityManager =
              frontOfficeTestEntityManager.getEntityManager();
          frontOfficeEntityManager
              .createQuery("delete from SavingsTransactionLogEntry")
              .executeUpdate();
          final EntityManager aaEntityManager = aatTestEntityManager.getEntityManager();
          aaEntityManager.createQuery("delete from ScaLvtCount").executeUpdate();
        });
  }

  private void setupScaLvtCountBelowThreshold() {
    setupScaLvtCount(SCA_LVT_COUNT_BELOW_THRESHOLD);
  }

  private void setupScaLvtCount(final Integer scaLvtCount) {
    setupScaLvtCount(scaLvtCount, false);
  }

  private void setupScaLvtCount(final Integer scaLvtCount, final boolean accessedFlag) {
    transactionTemplate.execute(
        status ->
            aatTestEntityManager.persistAndFlush(
                ScaLvtCount.builder()
                    .partyId(Long.parseLong(PARTY_ID))
                    .lvtCount(scaLvtCount)
                    .createdBy("asmith")
                    .createdDate(LocalDateTime.now())
                    .accessedFlag(accessedFlag)
                    .build()));
  }

  private void stubValidateCreditorDependenciesSuccess() {
    stubGetAccountPaymentDetails(true, true);
  }

  private void stubValidateExternalAccountDependenciesSuccess(
      final String sortCode, final String accountNumber) {

    stubValidateSortCode(sortCode, true);
    stubValidateAccount(sortCode, accountNumber, true);
    stubAcceptsFasterPayments(sortCode, true);
  }

  private void stubGetAccountPaymentDetails(
      final boolean validAccountHolderRole, final boolean validWithdrawalCode) {

    Map<String, Object> getPackageCallOutputParameters =
        new HashMap<String, Object>() {
          {
            put(PN_DEBTOR_ACC, "0123456789");
            put(PN_PARTY_SYSID, "123456");
            put(PN_MIN_BAL, new BigDecimal("100"));
            put(PS_PAYMENT_ACC_STATUS, "Valid");
            put(PS_PAYMENT_ACCHLDR_ROLE, validAccountHolderRole ? "Valid" : "Invalid");
            put(SOA_PAYACC_WARNINGS, new Object[] {});
            put(PS_VALID_WITCD, validWithdrawalCode ? "Valid" : "Invalid");
            put(PS_WEB_ENABLED, "Yes");
            put(PS_CUST_WARNINGS, "No");
          }
        };

    when(accountPaymentDetailsRepository.getAccountDetails(
            eq(Long.parseLong(DEBTOR_ACCOUNT_NUMBER)), eq(Long.parseLong(PARTY_ID))))
        .thenReturn(getPackageCallOutputParameters);
  }

  private void stubValidateSortCode(final String sortCode, final boolean valid) {

    if (valid) {
      Map<String, Object> getBankDetailsPackageCallOutputParameters =
          new HashMap<String, Object>() {
            {
              put("PS_BANK_NAME", "Name");
              put("PS_BRANCH_TITLE", "Title");
              put("PS_BANK_ADD_LINE1", "Line1");
              put("PS_BANK_ADD_LINE2", "Line2");
              put("PS_BANK_ADD_LINE3", "Line3");
              put("PS_BANK_ADD_LINE4", "Line4");
              put("PS_BANK_ADD_LINE5", "Line5");
              put("PS_BANK_POSTCODE", "Postcode");
              put("PS_BANK_TEL_NUM", "Tel Num");
            }
          };

      when(bankRepository.getBankDetails(eq(Long.parseLong(sortCode))))
          .thenReturn(getBankDetailsPackageCallOutputParameters);
      return;
    }

    JpaSystemException ex =
        new JpaSystemException(
            new GenericJDBCException(
                "",
                new SQLException(
                    "ORA-20022: YBS-26779:- Bank Name and Address Details Not Found- (In -   PACKAGE BODY COREOWN.SOA_VALIDATEBANKACCIDENTITY.PR_GET_BANK_DETAILS){}\n"
                        + "ORA-06512: at \"COREOWN.YBS_APPLICATION_ERROR\", line 134\n"
                        + "ORA-06512: at \"COREOWN.SOA_VALIDATEBANKACCIDENTITY\", line 185\n"
                        + "ORA-06512: at line 1",
                    "72000"),
                "sql"));

    when(bankRepository.getBankDetails(Long.parseLong("112233"))).thenThrow(ex);
  }

  private void stubValidateAccount(
      final String sortCode, final String accountNumber, final boolean valid) {

    when(bankRepository.validateBankAccount(
            eq(Long.parseLong(sortCode)), eq(Long.parseLong(accountNumber))))
        .thenReturn(valid ? "Y" : "N");
  }

  private void stubAcceptsFasterPayments(
      final String sortCode, final boolean acceptsFasterPayments) {

    when(bankRepository.acceptsFasterPayments(eq(sortCode)))
        .thenReturn(acceptsFasterPayments ? "Y" : "N");
  }
}
