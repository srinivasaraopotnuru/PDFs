package uk.co.ybs.digital.payment;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.io.IOException;
import java.net.URI;
import java.security.PrivateKey;
import java.time.Duration;
import java.time.Instant;
import java.time.Period;
import java.util.Date;
import java.util.UUID;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.filter.OncePerRequestFilter;
import uk.co.ybs.digital.payment.WhitelabelErrorPageIT.WhitelabelErrorPageTestConfig;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, WhitelabelErrorPageTestConfig.class})
@ActiveProfiles("test")
class WhitelabelErrorPageIT {
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String PAYMENT_SCOPE = "PAYMENT";

  @LocalServerPort private int port;

  @Autowired private WebTestClient signingWebClientPublic;

  @Autowired private PrivateKey jwtSigningPrivateKey;

  @Test
  void
      whitelabelErrorPageShouldReturnInternalServerErrorWhenRequestFilterThrowsUnexpectedException() {
    final UUID requestId = UUID.randomUUID();
    final ExternalPaymentRequest request = ExternalPaymentRequest.builder().build();
    final String jwt = createJwtWithScope(PAYMENT_SCOPE);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("500 Internal Server Error")
            .message("Internal Server Error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected error")
                    .build())
            .build();

    signingWebClientPublic
        .post()
        .uri(getPaymentsURI())
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  private URI getPaymentsURI() {
    return URI.create("http://localhost:" + port + "/payment/payment");
  }

  private String createJwtWithScope(final String scope) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setSubject("my-customer-number")
        .setAudience("DIGITAL_API")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .claim("brand_code", "YBS")
        .claim("channel", "SAPP")
        .claim("sid", UUID.randomUUID().toString())
        .claim("scope", scope)
        .claim("registration_id", UUID.randomUUID().toString())
        .claim("verification_method", "BIOMETRIC")
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .signWith(SignatureAlgorithm.RS256, jwtSigningPrivateKey)
        .compact();
  }

  @TestConfiguration
  static class WhitelabelErrorPageTestConfig {
    @Bean
    FilterRegistrationBean<Filter> filterRegistrationBean() {
      return new FilterRegistrationBean<>(
          new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(
                final HttpServletRequest request,
                final HttpServletResponse response,
                final FilterChain filterChain)
                throws IOException {
              throw new IOException("Unexpected exception");
            }
          });
    }
  }
}
