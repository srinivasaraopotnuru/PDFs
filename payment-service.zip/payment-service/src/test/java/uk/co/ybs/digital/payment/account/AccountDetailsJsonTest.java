package uk.co.ybs.digital.payment.account;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class AccountDetailsJsonTest {

  @Autowired private JacksonTester<AccountDetails> json;

  @Value("classpath:jsonTest/AccountDetails.json")
  private Resource expectedJson;

  private final AccountDetails accountDetails =
      AccountDetails.builder()
          .account(
              Account.builder()
                  .accountNumber("0123456789")
                  .accountSortCode("123456")
                  .withdrawals(
                      Withdrawals.builder()
                          .permittedOverApi(true)
                          .limit(
                              WithdrawalLimit.builder()
                                  .permitted(4)
                                  .available(3)
                                  .periodEnd(LocalDate.parse("2020-12-31"))
                                  .build())
                          .interestPenalty(InterestPenalty.builder().days(30).build())
                          .build())
                  .deposits(
                      Deposits.builder()
                          .permittedOverApi(true)
                          .limit(
                              DepositLimit.builder()
                                  .available(new BigDecimal("50.44"))
                                  .maxProductBalRemaining(new BigDecimal("123.66"))
                                  .build())
                          .build())
                  .build())
          .build();

  @Test
  void serializes() throws IOException {
    assertThat(json.write(accountDetails)).isEqualToJson(expectedJson, JSONCompareMode.STRICT);
  }

  @Test
  void deserialize() throws IOException {
    assertThat(json.read(expectedJson)).isEqualTo(accountDetails);
  }
}
