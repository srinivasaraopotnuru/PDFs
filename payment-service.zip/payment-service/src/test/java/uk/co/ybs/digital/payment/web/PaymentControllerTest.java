package uk.co.ybs.digital.payment.web;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidInternalAccountDetails;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidRequestMetadata;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidSystemRequestMetadata;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.JwtRequestPostProcessor;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.logging.filters.session.SessionIdSourceType;
import uk.co.ybs.digital.payment.beneficiary.BeneficiaryService;
import uk.co.ybs.digital.payment.beneficiary.SaveBeneficiaryException;
import uk.co.ybs.digital.payment.exception.AccountValidatorException;
import uk.co.ybs.digital.payment.exception.InternalAccountValidatorException;
import uk.co.ybs.digital.payment.exception.InvalidPaymentException;
import uk.co.ybs.digital.payment.exception.ScaRequiredException;
import uk.co.ybs.digital.payment.exception.UnexpectedReferenceException;
import uk.co.ybs.digital.payment.exception.ValidatePaymentServiceException;
import uk.co.ybs.digital.payment.service.AccountValidator;
import uk.co.ybs.digital.payment.service.PaymentService;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.service.SystemRequestMetadata;
import uk.co.ybs.digital.payment.service.UserRequestMetadata;
import uk.co.ybs.digital.payment.service.sca.ScaCredentialsExtractor;
import uk.co.ybs.digital.payment.service.sca.ScaPasswordChallengeResponseExtractor;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.sca.exception.InvalidPasswordCharsScaException;
import uk.co.ybs.digital.sca.exception.InvalidPemKeyException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.exception.PublicKeyFactoryException;
import uk.co.ybs.digital.sca.exception.VerifySignatureException;
import uk.co.ybs.digital.sca.service.ScaCredentials;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(controllers = PaymentController.class)
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter
  RequestVerificationSecurityAutoConfiguration.class,
  FilterErrorResponseFactory.class, // Spring Security
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class, // Metrics
  ScaCredentialsExtractor.class,
  ScaPasswordChallengeResponseExtractor.class
})
@ActiveProfiles("test")
class PaymentControllerTest {
  private static final String PARTY_ID = "11111";
  private static final String HOST_HEADER_VALUE = "paymentservice.ybs.co.uk:443";
  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String MOCK_KEY = "some-key";
  private static final String MOCK_CHALLENGE_RESPONSE = "some-challenge-response";
  private static final String MOCK_CHALLENGE = "some-challenge";
  private static final String SIGNATURE_KEY_ID_HEADER = "x-ybs-request-signature-key-id";
  private static final String SCA_CHALLENGE_HEADER = "x-ybs-sca-challenge";
  private static final String SCA_CHALLENGE_RESPONSE_HEADER = "x-ybs-sca-challenge-response";
  private static final String SCA_KEY_HEADER = "x-ybs-sca-key";
  private static final String EMAIL = "joe.bloggs@ybs.co.uk";
  private static final String TITLE = "Mr";
  private static final String SURNAME = "Bloggs";
  private static final String REFERENCE = "ELECTRIC BILL";
  private static final UUID REQUEST_ID = UUID.fromString("ef390044-8c71-403c-a65d-73fec1ccb6a9");
  private static final String SCOPE = "PAYMENT ACCOUNT_READ";
  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String BRAND_CODE = "YBS";
  private static final String CHANNEL = "SAPP";
  private static final String VALIDATE_ENDPOINT_URL = "/validate";
  private static final String VALIDATE_PAYEE_ENDPOINT_URL = "/validate/payee";
  private static final String FAILURE_ENDPOINT_URL = "/failure";
  private static final String PAYMENT_ENDPOINT_URL = "/payment";
  private static final String KEY_ID_HEADER_VALUE = "key-id";
  private static final String JSON_PATH_ID = "$.id";
  private static final String JSON_PATH_CODE = "$.code";
  private static final String JSON_PATH_MESSAGE = "$.message";
  private static final String JSON_PATH_ERRORS_SIZE = "$.errors.size()";
  private static final String JSON_PATH_ERRORS_ERROR_CODE = "$.errors[0].errorCode";
  private static final String JSON_PATH_ERRORS_MESSAGE = "$.errors[0].message";
  private static final String JSON_PATH_ERRORS_PATH = "$.errors[0].path";
  private static final String HEADER_INVALID_ERROR_MESSAGE = "Header invalid";
  private static final String HEADER_INVALID_ERROR_CODE = "Header.Invalid";
  private static final String FIELD_INVALID_ERROR_CODE = "Field.Invalid";
  private static final String BAD_REQUEST_ERROR_CODE = "400 Bad Request";
  private static final String BAD_REQUEST_ERROR_MESSAGE = "Bad Request";

  private static final String CONFLICT_ERROR_CODE = "409 Conflict";
  private static final String CONFLICT_ERROR_MESSAGE = "Conflict";
  private static final String BAD_REQUEST_RESPONSE_MESSAGE = "Unable to parse request body";
  private static final String WEB_CHANNEL = "WEB";
  private static final String SUB = "987654321";
  private static final String SESSION_ID_ATTRIBUTE_NAME =
      "uk.co.ybs.digital.logging.session.SessionIdFilter.sessionId";
  private static final UUID SESSION_ID = UUID.fromString("83e4265c-e2b3-4859-ad93-83c27cd2fd33");
  private static final String IDEMPOTENCY_KEY = "idempotencyKey";

  @Autowired private MockMvc mockMvc;
  @Autowired private ObjectMapper objectMapper;
  @MockBean private PaymentService paymentService;
  @MockBean private AccountValidator accountValidator;
  @MockBean private RequestSigningVerificationService requestSigningVerificationService;
  @MockBean private BeneficiaryService beneficiaryService;
  private ScaCredentials scaCredentials;

  @BeforeEach
  void beforeEach() {
    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
    scaCredentials = new ScaCredentials(MOCK_CHALLENGE, MOCK_CHALLENGE_RESPONSE, MOCK_KEY);
  }

  @Test
  void validateRequestReturnsSuccessWithValidRequestPayload() throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    mockMvc
        .perform(
            post(VALIDATE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk())
        .andExpect(content().string("[]"));

    verify(paymentService).validate(request, requestMetadata);
  }

  @Test
  void validateExternalCreditorRequestReturnsSuccessWithValidRequestPayload() throws Exception {
    UUID requestId = UUID.randomUUID();
    ExternalCreditorDetails request = buildValidExternalCreditorAccount();
    RequestMetadata requestMetadata = buildValidSystemRequestMetadata(requestId, IP_ADDRESS);

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtWithScope(SCOPE)))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(paymentService).validateCreditor(request, requestMetadata);
  }

  @Test
  void validateInternalAccountRequestReturnsSuccessWithValidRequestPayload() throws Exception {
    UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(TestHelper.jwtCustomerWithScope(SCOPE)))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(paymentService).validateCreditor(request, requestMetadata);
  }

  @Test
  void validateInternalAccountRequestReturnsSuccessWithoutJWTSubType() throws Exception {
    UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();
    RequestMetadata requestMetadata = buildValidSystemRequestMetadata(requestId, IP_ADDRESS);

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtWithScope(SCOPE)))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(paymentService).validateCreditor(request, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource("internalAccountValidatorErrorResponses")
  void validateInternalAccountRequestShouldReturnFailureWhenPaymentServiceValidateCreditorFails(
      final String errorCode,
      final String errorMessage,
      final String errorItemMessage,
      final InternalAccountValidatorException.Reason reason,
      final int status)
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(errorCode)
            .message(errorMessage)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("InternalPayee.Invalid")
                    .message(errorItemMessage)
                    .build())
            .build();

    doThrow(new InternalAccountValidatorException(errorItemMessage, reason))
        .when(paymentService)
        .validateCreditor(any(), any());

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT_URL)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().is(status))
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @MethodSource("requestMetadata")
  void paymentFailureRequestReturnsSuccess(final Jwt jwt, final RequestMetadata requestMetadata)
      throws Exception {
    final PaymentFailureRequest request = buildPaymentFailureRequest();

    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwt))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, REQUEST_ID)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent())
        .andExpect(content().string(""));

    verify(paymentService).reportPaymentFailure(request, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource("requestMetadata")
  void appRequestWithAllScaHeadersReturnsSuccessWithTheRequestPayload(
      final Jwt jwt, final RequestMetadata requestMetadata) throws Exception {
    PaymentRequest request = buildValidPaymentRequest();

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwt))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, REQUEST_ID)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent())
        .andExpect(content().string(""));

    verify(paymentService).doPaymentWithScaApp(request, requestMetadata, scaCredentials);
    verify(beneficiaryService).saveBeneficiary(request, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource("requestMetadataWebPaymentWithSca")
  void webRequestWithScaChallengeResponseHeaderReturnsSuccessWithTheRequestPayload(
      final Jwt jwt, final RequestMetadata requestMetadata) throws Exception {
    PaymentRequest request = buildValidPaymentRequest();

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwt))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, REQUEST_ID)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent())
        .andExpect(content().string(""));

    verify(paymentService)
        .doPaymentWithScaWeb(request, requestMetadata, MOCK_CHALLENGE_RESPONSE, jwt);
    verify(beneficiaryService).saveBeneficiary(request, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource("requestMetadataWebPaymentWithoutSca")
  void webRequestWithRequestPayloadWithReference(
      final Jwt jwt, final RequestMetadata requestMetadata) throws Exception {
    ExternalPaymentRequest externalPaymentRequest =
        buildValidExternalPaymentRequestWithBeneficiary(REFERENCE);

    mockMvc
        .perform(
            post("/payment")
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwt))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, REQUEST_ID)
                .header(SIGNATURE_KEY_ID_HEADER, "key-id")
                .content(objectMapper.writeValueAsString(externalPaymentRequest)))
        .andExpect(status().isNoContent())
        .andExpect(content().string(""));

    verify(paymentService).doPaymentWithoutSca(externalPaymentRequest, requestMetadata, jwt);
    verify(beneficiaryService).updateExternalBeneficiary(externalPaymentRequest, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource("requestMetadataWebPaymentWithoutSca")
  void webRequestWithRequestPayloadWithoutReference(
      final Jwt jwt, final RequestMetadata requestMetadata) throws Exception {
    PaymentRequest request = buildValidExternalPaymentRequestWithBeneficiary(null);

    mockMvc
        .perform(
            post("/payment")
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwt))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, REQUEST_ID)
                .header(SIGNATURE_KEY_ID_HEADER, "key-id")
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent())
        .andExpect(content().string(""));

    verify(paymentService).doPaymentWithoutSca(request, requestMetadata, jwt);
    verifyNoInteractions(beneficiaryService);
  }

  private static Stream<Arguments> requestMetadata() {
    return Stream.of(
        Arguments.of(
            jwtWithScope(SCOPE),
            buildValidRequestMetadata(REQUEST_ID, SESSION_ID, PARTY_ID, IP_ADDRESS)),
        Arguments.of(
            jwtWithoutOptionalFieldsWithScope(SCOPE),
            buildValidRequestMetadataWithoutOptionalFields(
                REQUEST_ID, SESSION_ID, PARTY_ID, IP_ADDRESS, CHANNEL)));
  }

  private static Stream<Arguments> requestMetadataWebPaymentWithSca() {
    return Stream.of(
        Arguments.of(
            jwtWithScopeAndChannel(SCOPE, WEB_CHANNEL),
            buildValidRequestMetadata(
                REQUEST_ID, SESSION_ID, PARTY_ID, IP_ADDRESS, BRAND_CODE, WEB_CHANNEL)),
        Arguments.of(
            jwtWithoutOptionalFieldsWithScopeAndChannel(SCOPE, WEB_CHANNEL),
            buildValidRequestMetadataWithoutOptionalFields(
                REQUEST_ID, SESSION_ID, PARTY_ID, IP_ADDRESS, WEB_CHANNEL)));
  }

  private static Stream<Arguments> requestMetadataWebPaymentWithoutSca() {
    return Stream.of(
        Arguments.of(
            jwtWithScopeAndChannel(SCOPE, WEB_CHANNEL),
            buildValidRequestMetadata(
                REQUEST_ID, SESSION_ID, PARTY_ID, IP_ADDRESS, BRAND_CODE, WEB_CHANNEL)),
        Arguments.of(
            jwtWithoutOptionalFieldsWithScopeAndChannel(SCOPE, WEB_CHANNEL),
            buildValidRequestMetadataWithoutOptionalFields(
                REQUEST_ID, SESSION_ID, PARTY_ID, IP_ADDRESS, WEB_CHANNEL)));
  }

  @Test
  void paymentFailureRequestShouldReturnUnauthorizedWhenNoBearerTokenProvided() throws Exception {
    UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();

    ErrorResponse expectedErrorResponse = buildUnauthorizedErrorResponse(requestId);

    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isUnauthorized())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @MethodSource("validatedEndpoints") // NOPMD
  void requestShouldReturnUnauthorizedWhenNoBearerTokenProvided(
      final String endpoint, final Object request) throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse expectedErrorResponse = buildUnauthorizedErrorResponse(requestId);

    mockMvc
        .perform(
            post(endpoint)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isUnauthorized())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void paymentFailureRequestShouldReturnForbiddenWhenUserDoesNotHavePaymentsScope()
      throws Exception {
    UUID requestId = UUID.randomUUID();
    final PaymentFailureRequest request = buildPaymentFailureRequest();

    ErrorResponse expectedErrorResponse = buildForbiddenErrorResponse(requestId);

    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeOther()))
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {VALIDATE_ENDPOINT_URL, PAYMENT_ENDPOINT_URL})
  void requestShouldReturnForbiddenWhenUserDoesNotHavePaymentsScope(final String endpoint)
      throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();

    ErrorResponse expectedErrorResponse = buildForbiddenErrorResponse(requestId);

    mockMvc
        .perform(
            post(endpoint)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeOther()))
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void paymentFailureRequestShouldReturnBadRequestWhenRequestIdIsNotAUUID() throws Exception {
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    String requestId = "not-a-uuid";

    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath(JSON_PATH_ID, notNullValue()))
        .andExpect(jsonPath(JSON_PATH_CODE, is(BAD_REQUEST_ERROR_CODE)))
        .andExpect(jsonPath(JSON_PATH_MESSAGE, is(BAD_REQUEST_ERROR_MESSAGE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_SIZE, is(1)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_ERROR_CODE, is(HEADER_INVALID_ERROR_CODE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_MESSAGE, is(HEADER_INVALID_ERROR_MESSAGE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_PATH, is("x-ybs-request-id")));
  }

  @ParameterizedTest
  @MethodSource("validatedEndpoints") // NOPMD
  void requestShouldReturnBadRequestWhenRequestIdIsNotAUUID(final String endpoint)
      throws Exception {
    PaymentRequest request = buildValidPaymentRequest();
    String requestId = "not-a-uuid";

    mockMvc
        .perform(
            post(endpoint)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath(JSON_PATH_ID, notNullValue()))
        .andExpect(jsonPath(JSON_PATH_CODE, is(BAD_REQUEST_ERROR_CODE)))
        .andExpect(jsonPath(JSON_PATH_MESSAGE, is(BAD_REQUEST_ERROR_MESSAGE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_SIZE, is(1)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_ERROR_CODE, is(HEADER_INVALID_ERROR_CODE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_MESSAGE, is(HEADER_INVALID_ERROR_MESSAGE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_PATH, is("x-ybs-request-id")));
  }

  @Test
  void paymentFailureRequestShouldReturnBadRequestIfIdempotencyKeyIsNotAUUID() throws Exception {
    final PaymentFailureRequest paymentFailureRequest = buildPaymentFailureRequest();
    Map<String, Object> request =
        objectMapper.convertValue(
            paymentFailureRequest, new TypeReference<Map<String, Object>>() {});
    request.put(IDEMPOTENCY_KEY, "foo");

    ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(BAD_REQUEST_ERROR_CODE)
            .message(BAD_REQUEST_RESPONSE_MESSAGE)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR_CODE)
                    .message("`foo` is not a valid UUID")
                    .path(IDEMPOTENCY_KEY)
                    .build())
            .build();

    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {VALIDATE_ENDPOINT_URL, PAYMENT_ENDPOINT_URL})
  void requestShouldReturnBadRequestIfIdempotencyKeyIsNotAUUID(final String endpoint)
      throws Exception {
    PaymentRequest paymentRequest = buildValidPaymentRequest();
    Map<String, Object> request =
        objectMapper.convertValue(paymentRequest, new TypeReference<Map<String, Object>>() {});
    request.put(IDEMPOTENCY_KEY, "foo");

    ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(BAD_REQUEST_ERROR_CODE)
            .message(BAD_REQUEST_RESPONSE_MESSAGE)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR_CODE)
                    .message("`foo` is not a valid UUID")
                    .path(IDEMPOTENCY_KEY)
                    .build())
            .build();

    mockMvc
        .perform(
            post(endpoint)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @MethodSource("validatedEndpoints") // NOPMD
  void requestShouldReturnBadRequestWhenSessionIdIsNotAUUID(final String endpoint)
      throws Exception {
    PaymentRequest request = buildValidPaymentRequest();
    String sessionId = "invalid_session_id";

    mockMvc
        .perform(
            post(endpoint)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithSessionId(SCOPE, sessionId))
                .header(REQUEST_ID_HEADER, UUID.randomUUID().toString())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath(JSON_PATH_ID, notNullValue()))
        .andExpect(jsonPath(JSON_PATH_CODE, is(BAD_REQUEST_ERROR_CODE)))
        .andExpect(jsonPath(JSON_PATH_MESSAGE, is(BAD_REQUEST_ERROR_MESSAGE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_SIZE, is(1)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_ERROR_CODE, is(HEADER_INVALID_ERROR_CODE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_MESSAGE, is("SessionId is not a valid UUID")))
        .andExpect(jsonPath(JSON_PATH_ERRORS_PATH, is(SessionIdSourceType.JWT.toString())));
  }

  @ParameterizedTest
  @MethodSource("validatedEndpoints") // NOPMD
  void requestShouldReturnBadRequestWhenSessionIdJwtClaimIsMissing(final String endpoint)
      throws Exception {
    PaymentRequest request = buildValidPaymentRequest();

    mockMvc
        .perform(
            post(endpoint)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithoutSessionId(SCOPE))
                .header(REQUEST_ID_HEADER, UUID.randomUUID().toString())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath(JSON_PATH_ID, notNullValue()))
        .andExpect(jsonPath(JSON_PATH_CODE, is(BAD_REQUEST_ERROR_CODE)))
        .andExpect(jsonPath(JSON_PATH_MESSAGE, is(BAD_REQUEST_ERROR_MESSAGE)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_SIZE, is(1)))
        .andExpect(jsonPath(JSON_PATH_ERRORS_ERROR_CODE, is(HEADER_INVALID_ERROR_CODE)))
        .andExpect(
            jsonPath(JSON_PATH_ERRORS_MESSAGE, is("JWT does not contain a sessionId (sid) claim")))
        .andExpect(jsonPath(JSON_PATH_ERRORS_PATH, is(SessionIdSourceType.JWT.toString())));
  }

  @ParameterizedTest
  @ValueSource(strings = {VALIDATE_ENDPOINT_URL, PAYMENT_ENDPOINT_URL})
  void requestShouldReturnBadRequestIfPaymentRequestTypeIsMissing(final String endpoint)
      throws Exception {
    final Map<String, String> request = Collections.emptyMap();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(BAD_REQUEST_ERROR_CODE)
            .message(BAD_REQUEST_RESPONSE_MESSAGE)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("No PaymentRequest type id found")
                    .build())
            .build();

    mockMvc
        .perform(
            post(endpoint)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {VALIDATE_ENDPOINT_URL, PAYMENT_ENDPOINT_URL})
  void requestShouldReturnBadRequestIfPaymentRequestTypeIsInvalid(final String endpoint)
      throws Exception {
    final Map<String, String> request = ImmutableMap.of("type", "abc");

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(BAD_REQUEST_ERROR_CODE)
            .message(BAD_REQUEST_RESPONSE_MESSAGE)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR_CODE)
                    .message("`abc` is not a valid PaymentRequest type id")
                    .build())
            .build();

    mockMvc
        .perform(
            post(endpoint)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void paymentFailureRequestShouldReturnBadRequestIfRequestValidationFails() throws Exception {
    ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(BAD_REQUEST_ERROR_CODE)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify a UUID idempotency key")
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR_CODE)
                    .message(
                        "123 is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number")
                    .build())
            .build();

    final PaymentFailureRequest request =
        buildPaymentFailureRequest()
            .toBuilder()
            .idempotencyKey(null)
            .debtor(Debtor.builder().accountNumber("123").build())
            .build();

    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {VALIDATE_ENDPOINT_URL, PAYMENT_ENDPOINT_URL})
  void requestShouldReturnBadRequestIfRequestValidationFails(final String endpoint)
      throws Exception {
    ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(BAD_REQUEST_ERROR_CODE)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Missing")
                    .message("You must specify a UUID idempotency key")
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR_CODE)
                    .message(
                        "123 is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number")
                    .build())
            .build();

    ExternalPaymentRequest request =
        buildValidPaymentRequest()
            .toBuilder()
            .idempotencyKey(null)
            .debtor(Debtor.builder().accountNumber("123").build())
            .build();

    mockMvc
        .perform(
            post(endpoint)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @MethodSource("missingHeaders")
  void missingScaHeaderReturnsError(final List<String> missingHeaders) throws Exception {
    PaymentRequest request = buildValidPaymentRequest();

    String missingHeadersCommaDelimited =
        missingHeaders.stream().map(Object::toString).collect(Collectors.joining(", "));

    List<ErrorResponse.ErrorItem> errorItems =
        missingHeaders.stream()
            .map(
                header ->
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("Header.Missing")
                        .message("Missing headers: [" + missingHeadersCommaDelimited + "]")
                        .path(header)
                        .build())
            .collect(Collectors.toList());

    ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(BAD_REQUEST_ERROR_CODE)
            .message("Missing or invalid headers")
            .errors(errorItems)
            .build();

    HttpHeaders scaHeaders = new HttpHeaders();
    scaHeaders.put(SCA_CHALLENGE_HEADER, Collections.singletonList("mockChallenge"));
    scaHeaders.put(
        SCA_CHALLENGE_RESPONSE_HEADER, Collections.singletonList("mockChallengeResponse"));
    scaHeaders.put(SCA_KEY_HEADER, Collections.singletonList("mockScaKey"));

    missingHeaders.forEach(scaHeaders::remove);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .headers(scaHeaders)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  private static Stream<List<String>> missingHeaders() {
    return Stream.of(
        Collections.singletonList(SCA_CHALLENGE_HEADER),
        Collections.singletonList(SCA_CHALLENGE_RESPONSE_HEADER),
        Collections.singletonList(SCA_KEY_HEADER),
        Arrays.asList(SCA_CHALLENGE_HEADER, SCA_KEY_HEADER),
        Arrays.asList(SCA_CHALLENGE_RESPONSE_HEADER, SCA_KEY_HEADER));
  }

  @ParameterizedTest
  @ValueSource(strings = {CHANNEL, WEB_CHANNEL})
  void requestWithScaKeyOnlyReturnsErrorWithChallengeInHeader(final String channel)
      throws Exception {
    doRequestWithoutSca(MOCK_KEY, channel);
  }

  @ParameterizedTest
  @ValueSource(strings = {CHANNEL, WEB_CHANNEL})
  void requestWithoutScaHeadersReturnsErrorWithChallengeInHeader(final String channel)
      throws Exception {
    doRequestWithoutSca(null, channel);
  }

  private void doRequestWithoutSca(final String encodedPublicKey, final String channel)
      throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS, BRAND_CODE, channel);
    Jwt jwt = jwtScopeRequired();

    doThrow(
            new ScaRequiredException(
                "mockChallengeResponse",
                "Please sign the value in x-ybs-sca-challenge header with the request"))
        .when(paymentService)
        .doPaymentWithoutSca(request, requestMetadata, jwt);

    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.add(HttpHeaders.HOST, HOST_HEADER_VALUE);
    httpHeaders.add(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE);
    httpHeaders.add(REQUEST_ID_HEADER, requestId.toString());
    Optional.ofNullable(encodedPublicKey)
        .ifPresent(publicKey -> httpHeaders.add(SCA_KEY_HEADER, publicKey));

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtWithScopeAndChannel(SCOPE, channel)))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .headers(httpHeaders)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            content()
                .json(
                    objectMapper.writeValueAsString(
                        ErrorResponse.builder()
                            .code("403 Forbidden")
                            .id(requestId)
                            .message("Strong customer authentication required")
                            .error(
                                ErrorResponse.ErrorItem.builder()
                                    .errorCode("SCA.Required")
                                    .message(
                                        "Please sign the value in x-ybs-sca-challenge header with the request")
                                    .build())
                            .build())))
        .andExpect(header().string(SCA_CHALLENGE_HEADER, "mockChallengeResponse"));
  }

  @Test
  void invalidChallengeResponseForAppReturnsForbidden() throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    doThrow(new InvalidScaException("mockValidateChallengeException")) // NOPMD
        .when(paymentService)
        .doPaymentWithScaApp(request, requestMetadata, scaCredentials);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @ParameterizedTest
  @ValueSource(ints = {2, 1})
  void
      invalidChallengeResponseForWebReturnsForbiddenWithPasswordAttemptsRemainingValueFromException(
          final int passwordAttemptsRemaining) throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(
            requestId, SESSION_ID, PARTY_ID, IP_ADDRESS, BRAND_CODE, WEB_CHANNEL);
    final Jwt user = jwtWithScopeAndChannel(SCOPE, WEB_CHANNEL);

    final String expectedPasswordAttemptsRemainingMessage =
        passwordAttemptsRemaining == 1
            ? "1 attempt remaining"
            : passwordAttemptsRemaining + " attempts remaining";
    ErrorResponse expectedResponse =
        TestHelper.accessDeniedWithPasswordAttemptsRemainingErrorResponse(
            requestId, expectedPasswordAttemptsRemainingMessage);

    final RuntimeException cause = new RuntimeException();
    doThrow(
            new InvalidPasswordCharsScaException(
                "mockValidateChallengeException", cause, passwordAttemptsRemaining)) // NOPMD
        .when(paymentService)
        .doPaymentWithScaWeb(request, requestMetadata, MOCK_CHALLENGE_RESPONSE, user);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(user))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void invalidChallengeResponseForWebReturnsForbiddenWhenPasswordAttemptsRemainingIsNotInException()
      throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(
            requestId, SESSION_ID, PARTY_ID, IP_ADDRESS, BRAND_CODE, WEB_CHANNEL);
    final Jwt user = jwtWithScopeAndChannel(SCOPE, WEB_CHANNEL);

    ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    final RuntimeException cause = new RuntimeException();
    doThrow(
            new InvalidPasswordCharsScaException(
                "mockValidateChallengeException", cause, null)) // NOPMD
        .when(paymentService)
        .doPaymentWithScaWeb(request, requestMetadata, MOCK_CHALLENGE_RESPONSE, user);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(user))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void invalidSessionIdReturnsForbidden() throws Exception {
    UUID requestId = UUID.randomUUID();

    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    doThrow(new InvalidScaException("mockValidateChallengeException")) // NOPMD
        .when(paymentService)
        .doPaymentWithScaApp(request, requestMetadata, scaCredentials);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void sessionExpiredReturnsForbidden() throws Exception {
    UUID requestId = UUID.randomUUID();

    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    ErrorResponse expectedResponse = TestHelper.accessDeniedErrorResponse(requestId);

    doThrow(new InvalidScaException("mockValidateChallengeException")) // NOPMD
        .when(paymentService)
        .doPaymentWithScaApp(request, requestMetadata, scaCredentials);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void invalidPemKeyReturnsBadRequest() throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    ErrorResponse expectedResponse = TestHelper.badPemKey(requestId);

    doThrow(new InvalidPemKeyException("mockValidateChallengeException")) // NOPMD
        .when(paymentService)
        .doPaymentWithScaApp(request, requestMetadata, scaCredentials);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void saveBeneficiaryConflictAndErrorResponseReturns200WithErrorResponseBody() throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.CONFLICT)
            .id(UUID.randomUUID())
            .message("Invalid Beneficiary")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Beneficiary.Limit")
                    .message("Beneficiary limit reached")
                    .build())
            .build();

    final String bodyAsString = objectMapper.writeValueAsString(expectedResponse);

    final SaveBeneficiaryException exception =
        new SaveBeneficiaryException(HttpStatus.CONFLICT, bodyAsString);

    doThrow(exception).when(beneficiaryService).saveBeneficiary(request, requestMetadata);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk())
        .andExpect(content().json(bodyAsString));
  }

  @Test
  void saveBeneficiaryUnexpectedErrorReturns200WithTechnicalErrorErrorResponseBody()
      throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    ErrorResponse expectedResponse = TestHelper.buildBeneficiaryTechnicalErrorResponse(requestId);

    final SaveBeneficiaryException exception =
        new SaveBeneficiaryException(HttpStatus.BAD_REQUEST, null);

    doThrow(exception).when(beneficiaryService).saveBeneficiary(request, requestMetadata);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @ParameterizedTest
  @MethodSource("badConflictResponseBodies")
  void saveBeneficiaryConflictWithNonErrorResponseBodyReturnsTechnicalErrorErrorResponseBody(
      final String responseBody) throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    ErrorResponse expectedResponse = TestHelper.buildBeneficiaryTechnicalErrorResponse(requestId);

    final SaveBeneficiaryException exception =
        new SaveBeneficiaryException(HttpStatus.CONFLICT, responseBody);

    doThrow(exception).when(beneficiaryService).saveBeneficiary(request, requestMetadata);

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isOk())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void paymentFailureRequestShouldReturnConflictWhenPaymentValidationServiceValidationFails()
      throws Exception {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(CONFLICT_ERROR_CODE)
            .message(CONFLICT_ERROR_MESSAGE)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("PaymentFailureNotification.DebtorAccount")
                    .message(
                        "Unable to send notification using the debtor account details provided")
                    .build())
            .build();

    final PaymentFailureRequest request = buildPaymentFailureRequest();

    doThrow(new AccountValidatorException("Some message"))
        .when(paymentService)
        .reportPaymentFailure(any(), any());

    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isConflict())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  private PaymentFailureRequest buildPaymentFailureRequest() {
    return TestHelper.buildPaymentFailureRequest();
  }

  @ParameterizedTest
  @MethodSource("validateErrorReasonsAndExpectedErrorItemsArguments")
  void requestShouldReturnConflictWhenPaymentValidationServiceValidationFails(
      final InvalidPaymentException.Reason reason, final ErrorResponse.ErrorItem errorItem)
      throws Exception {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(CONFLICT_ERROR_CODE)
            .message(CONFLICT_ERROR_MESSAGE)
            .error(errorItem)
            .build();

    PaymentRequest request = buildValidPaymentRequest();

    final SortedSet<InvalidPaymentException.Reason> reasons =
        new TreeSet<>(ImmutableSet.of(reason));
    doThrow(new InvalidPaymentException("Some message", reasons, null))
        .when(paymentService)
        .doPaymentWithoutSca(any(), any(), any());

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isConflict())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void requestShouldReturnConflictWhenPaymentValidationServiceValidationFailsForMultipleReasons()
      throws Exception {
    final UUID requestId = UUID.randomUUID();

    final SortedSet<InvalidPaymentException.Reason> reasons = new TreeSet<>();
    final List<ErrorResponse.ErrorItem> errorItems = new ArrayList<>();
    validateErrorReasonsAndExpectedErrorItems()
        .forEach(
            (key, value) -> {
              reasons.add(key);
              errorItems.add(value);
            });

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(CONFLICT_ERROR_CODE)
            .message(CONFLICT_ERROR_MESSAGE)
            .errors(errorItems)
            .build();

    PaymentRequest request = buildValidPaymentRequest();

    doThrow(new InvalidPaymentException("Some message", reasons, null))
        .when(paymentService)
        .doPaymentWithoutSca(any(), any(), any());

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isConflict())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  private static Stream<Arguments> validateErrorReasonsAndExpectedErrorItemsArguments() {
    return validateErrorReasonsAndExpectedErrorItems().entrySet().stream()
        .map(entry -> Arguments.of(entry.getKey(), entry.getValue()));
  }

  private static Map<InvalidPaymentException.Reason, ErrorResponse.ErrorItem>
      validateErrorReasonsAndExpectedErrorItems() {
    final Map<InvalidPaymentException.Reason, ErrorResponse.ErrorItem>
        reasonsAndExpectedErrorItems = new LinkedHashMap<>();
    reasonsAndExpectedErrorItems.put(
        InvalidPaymentException.Reason.DEBTOR_ACCOUNT,
        ErrorResponse.ErrorItem.builder()
            .errorCode("PaymentRejected.DebtorAccount")
            .message("Unable to make payment from the debtor account details provided")
            .build());
    reasonsAndExpectedErrorItems.put(
        InvalidPaymentException.Reason.DEBTOR_ACCOUNT_INSUFFICIENT_FUNDS,
        ErrorResponse.ErrorItem.builder()
            .errorCode("PaymentRejected.DebtorAccount.InsufficientFunds")
            .message("Insufficient funds available to make payment")
            .build());
    reasonsAndExpectedErrorItems.put(
        InvalidPaymentException.Reason.DEBTOR_ACCOUNT_MULTIPLE_SIGNATORIES_REQUIRED,
        ErrorResponse.ErrorItem.builder()
            .errorCode("PaymentRejected.DebtorAccount.MultipleSignatoriesRequired")
            .message("Multiple signatories are required for withdrawals")
            .build());
    reasonsAndExpectedErrorItems.put(
        InvalidPaymentException.Reason.CREDITOR_ACCOUNT,
        ErrorResponse.ErrorItem.builder()
            .errorCode("PaymentRejected.CreditorAccount")
            .message("Unable to make payment to the creditor account details provided")
            .build());
    reasonsAndExpectedErrorItems.put(
        InvalidPaymentException.Reason.CREDITOR_ACCOUNT_INTERNAL_SORT_CODE,
        ErrorResponse.ErrorItem.builder()
            .errorCode("PaymentRejected.CreditorAccount.InternalSortCode")
            .message("Payments to internal accounts must be done using the internal account number")
            .build());
    reasonsAndExpectedErrorItems.put(
        InvalidPaymentException.Reason.CREDITOR_ACCOUNT_DEPOSIT_LIMIT,
        ErrorResponse.ErrorItem.builder()
            .errorCode("PaymentRejected.CreditorAccount.DepositLimit")
            .message("Cannot exceed deposit limit on the creditor account")
            .build());
    reasonsAndExpectedErrorItems.put(
        InvalidPaymentException.Reason.DEBTOR_AND_CREDITOR_ACCOUNT_SAME,
        ErrorResponse.ErrorItem.builder()
            .errorCode("PaymentRejected.DebtorAndCreditorAccountSame")
            .message("Cannot make payment from and to the same account")
            .build());
    return reasonsAndExpectedErrorItems;
  }

  @Test
  void shouldReturnBadRequestWhenUnexpectedReferenceExceptionThrown() throws Exception {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message("Specifying a reference with a beneficiary is unsupported")
                    .path("reference")
                    .build())
            .build();

    final PaymentRequest request = buildValidPaymentRequest();

    doThrow(UnexpectedReferenceException.class)
        .when(paymentService)
        .doPaymentWithoutSca(any(), any(), any());

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @MethodSource("unexpectedExceptions")
  void shouldReturnInternalErrorWhenUnexpectedExceptionOccurs(final Exception exception)
      throws Exception {
    UUID requestId = UUID.randomUUID();
    PaymentRequest request = buildValidPaymentRequest();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    ErrorResponse expectedResponse = TestHelper.internalError(requestId);

    doThrow(exception)
        .when(paymentService)
        .doPaymentWithScaApp(request, requestMetadata, scaCredentials);
    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .header(SCA_CHALLENGE_HEADER, MOCK_CHALLENGE)
                .header(SCA_CHALLENGE_RESPONSE_HEADER, MOCK_CHALLENGE_RESPONSE)
                .header(SCA_KEY_HEADER, MOCK_KEY)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isInternalServerError())
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  private static Stream<Arguments> unexpectedExceptions() {
    return Stream.of(
        Arguments.of(
            new PublicKeyFactoryException("mockPublicKeyFactoryException", new Throwable())),
        Arguments.of(new VerifySignatureException("mockVerifySignatureException", new Throwable())),
        Arguments.of(
            new ValidatePaymentServiceException(
                "mockValidatePaymentServiceException", new Throwable())));
  }

  @ParameterizedTest
  @ValueSource(strings = {PAYMENT_ENDPOINT_URL, VALIDATE_ENDPOINT_URL, FAILURE_ENDPOINT_URL})
  void requestShouldReturnBadRequestWhenContentNotParseable(final String endpoint)
      throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code(BAD_REQUEST_ERROR_CODE)
            .id(requestId)
            .message(BAD_REQUEST_RESPONSE_MESSAGE)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Resource.InvalidFormat")
                    .message(
                        "An unexpected error occurred when attempting to parse the request body")
                    .build())
            .build();

    mockMvc
        .perform(
            post(endpoint)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content("some content text"))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {PAYMENT_ENDPOINT_URL, VALIDATE_ENDPOINT_URL, FAILURE_ENDPOINT_URL})
  void requestShouldReturnBadRequestWhenNoRequestBodyProvided(final String endpoint)
      throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code(BAD_REQUEST_ERROR_CODE)
            .id(requestId)
            .message(BAD_REQUEST_RESPONSE_MESSAGE)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Resource.InvalidFormat")
                    .message(
                        "An unexpected error occurred when attempting to parse the request body")
                    .build())
            .build();

    mockMvc
        .perform(
            post(endpoint)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(new byte[0]))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @ParameterizedTest
  @ValueSource(strings = {PAYMENT_ENDPOINT_URL, VALIDATE_ENDPOINT_URL, FAILURE_ENDPOINT_URL})
  void requestShouldReturnUnsupportedMediaTypeErrorWhenContentTypeNotJson(final String endpoint)
      throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("415 Unsupported Media Type")
            .id(requestId)
            .message("Unsupported Media Type")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(HEADER_INVALID_ERROR_CODE)
                    .message("Content-Type header is invalid")
                    .build())
            .build();

    mockMvc
        .perform(
            post(endpoint)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.TEXT_PLAIN)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content("some content text"))
        .andExpect(status().isUnsupportedMediaType())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ACCEPT, is(MediaType.APPLICATION_JSON_VALUE)));
  }

  @Test
  void failureRequestShouldReturnNotAcceptableErrorWhenAcceptNotJson() throws Exception {
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    UUID requestId = UUID.randomUUID();

    // Cannot return a response body if there is no acceptable content type.
    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_XML)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNotAcceptable())
        .andExpect(content().bytes(new byte[0]));
  }

  @ParameterizedTest
  @ValueSource(strings = {PAYMENT_ENDPOINT_URL, VALIDATE_ENDPOINT_URL})
  void paymentRequestShouldReturnNotAcceptableErrorWhenAcceptNotJson(final String endpoint)
      throws Exception {
    PaymentRequest request = buildValidPaymentRequest();
    UUID requestId = UUID.randomUUID();

    // Cannot return a response body if there is no acceptable content type.
    mockMvc
        .perform(
            post(endpoint)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_XML)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNotAcceptable())
        .andExpect(content().bytes(new byte[0]));
  }

  @Test
  void paymentFailureRequestShouldReturnMethodNotAllowedWhenMethodNotAllowed() throws Exception {
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("405 Method Not Allowed")
            .id(requestId)
            .message("Method Not Allowed")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method")
                    .build())
            .build();

    mockMvc
        .perform(
            put(FAILURE_ENDPOINT_URL)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.POST.name())));
  }

  @ParameterizedTest
  @ValueSource(strings = {PAYMENT_ENDPOINT_URL, VALIDATE_ENDPOINT_URL})
  void paymentRequestShouldReturnMethodNotAllowedWhenMethodNotAllowed(final String endpoint)
      throws Exception {
    PaymentRequest request = buildValidPaymentRequest();
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("405 Method Not Allowed")
            .id(requestId)
            .message("Method Not Allowed")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method")
                    .build())
            .build();

    mockMvc
        .perform(
            put(endpoint)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.POST.name())));
  }

  @Test
  void paymentFailureRequestShouldIncludeResponseBodyWhenUnexpectedSpringInternalExceptionThrown()
      throws Exception {
    final PaymentFailureRequest request = buildPaymentFailureRequest();
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException())
        .when(paymentService)
        .reportPaymentFailure(any(), any());

    mockMvc
        .perform(
            post(FAILURE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void requestShouldIncludeResponseBodyWhenUnexpectedSpringInternalExceptionThrown()
      throws Exception {
    PaymentRequest request = buildValidPaymentRequest();
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException())
        .when(paymentService)
        .doPaymentWithoutSca(any(), any(), any());

    mockMvc
        .perform(
            post(PAYMENT_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void validateShouldIncludeResponseBodyWhenUnexpectedSpringInternalExceptionThrown()
      throws Exception {
    PaymentRequest request = buildValidPaymentRequest();
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException()).when(paymentService).validate(any(), any());

    mockMvc
        .perform(
            post(VALIDATE_ENDPOINT_URL)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  private static Stream<Arguments> internalAccountValidatorErrorResponses() {
    return Stream.of(
        Arguments.of(
            CONFLICT_ERROR_CODE,
            CONFLICT_ERROR_MESSAGE,
            "Failed to find internal account: 0123456789",
            InternalAccountValidatorException.Reason.ACCOUNT_NUMBER,
            409),
        Arguments.of(
            BAD_REQUEST_ERROR_CODE,
            BAD_REQUEST_ERROR_MESSAGE,
            "Missing field: party_id",
            InternalAccountValidatorException.Reason.PARTY_ID,
            400));
  }

  private JwtRequestPostProcessor jwt(final Jwt jwt) {
    return SecurityMockMvcRequestPostProcessors.jwt().jwt(jwt);
  }

  private Jwt jwtScopeRequired() {
    return jwtWithScope(SCOPE);
  }

  private Jwt jwtScopeOther() {
    return jwtWithScope("OTHER");
  }

  private static Jwt jwtWithScope(final String scope) {
    return jwtWithScopeAndChannel(scope, CHANNEL);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Jwt jwtWithScopeAndChannel(final String scope, final String channel) {
    return Jwt.withTokenValue("<jwt>")
        .header("kid", KEY_ID_HEADER_VALUE)
        .subject(SUB)
        .claim("scope", scope)
        .claim("sid", SESSION_ID)
        .claim("brand_code", BRAND_CODE)
        .claim("channel", channel)
        .claim("registration_id", UUID.randomUUID().toString())
        .claim("customer_email", EMAIL)
        .claim("customer_title", TITLE)
        .claim("customer_last_name", SURNAME)
        .claim("party_id", PARTY_ID)
        .build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private String jwtWithSessionId(final String scope, final String sessionId) {
    return Jwts.builder()
        .setHeaderParam("kid", KEY_ID_HEADER_VALUE)
        .setSubject(SUB)
        .claim("sub_type", "customer")
        .claim("scope", scope)
        .claim("sid", sessionId)
        .claim("brand_code", BRAND_CODE)
        .claim("channel", CHANNEL)
        .claim("registration_id", UUID.randomUUID().toString())
        .claim("customer_email", EMAIL)
        .claim("customer_title", TITLE)
        .claim("customer_last_name", SURNAME)
        .claim("party_id", PARTY_ID)
        .signWith(SignatureAlgorithm.HS256, "my_private_key")
        .compact();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private String jwtWithoutSessionId(final String scope) {
    return Jwts.builder()
        .setHeaderParam("kid", KEY_ID_HEADER_VALUE)
        .setSubject(SUB)
        .claim("scope", scope)
        .claim("sub_type", "customer")
        .claim("brand_code", BRAND_CODE)
        .claim("channel", CHANNEL)
        .claim("registration_id", UUID.randomUUID().toString())
        .claim("customer_email", EMAIL)
        .claim("customer_title", TITLE)
        .claim("customer_last_name", SURNAME)
        .claim("party_id", PARTY_ID)
        .signWith(SignatureAlgorithm.HS256, "my_private_key")
        .compact();
  }

  private static ExternalPaymentRequest buildValidPaymentRequest() {
    return TestHelper.buildValidExternalPaymentRequest();
  }

  private static ExternalCreditorDetails buildValidExternalCreditorAccount() {
    return TestHelper.buildValidExternalCreditorAccount();
  }

  private static ExternalPaymentRequest buildValidExternalPaymentRequestWithBeneficiary(
      final String reference) {
    return TestHelper.buildValidExternalPaymentRequestWithBeneficiary(reference);
  }

  private static Jwt jwtWithoutOptionalFieldsWithScope(final String scope) {
    return jwtWithoutOptionalFieldsWithScopeAndChannel(scope, CHANNEL);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Jwt jwtWithoutOptionalFieldsWithScopeAndChannel(
      final String scope, final String channel) {
    return Jwt.withTokenValue("<jwt>")
        .header("kid", KEY_ID_HEADER_VALUE)
        .subject(SUB)
        .claim("scope", scope)
        .claim("brand_code", BRAND_CODE)
        .claim("channel", channel)
        .claim("registration_id", UUID.randomUUID().toString())
        .claim("party_id", PARTY_ID)
        .claim("sid", SESSION_ID)
        .build();
  }

  private static RequestMetadata buildValidRequestMetadataWithoutOptionalFields(
      final UUID requestId,
      final UUID sessionID,
      final String partyId,
      final String ipAddress,
      final String channel) {
    return RequestMetadata.builder()
        .systemRequestMetadata(
            SystemRequestMetadata.builder()
                .requestId(requestId)
                .host(InetSocketAddress.createUnresolved("paymentservice.ybs.co.uk", 443))
                .brandCode(BRAND_CODE)
                .forwardingAuth("<jwt>")
                .ipAddress(ipAddress)
                .build())
        .userRequestMetadata(
            UserRequestMetadata.builder()
                .sessionId(sessionID)
                .partyId(partyId)
                .channel(channel)
                .surname(null)
                .build())
        .build();
  }

  private ErrorResponse buildForbiddenErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied")
                .message("Access Denied")
                .build())
        .build();
  }

  private ErrorResponse buildUnauthorizedErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("401 Unauthorized")
        .message("Unauthorized")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Unauthorized")
                .message("Unauthorized")
                .build())
        .build();
  }

  private static Stream<Arguments> validatedEndpoints() {
    return Stream.of(
        Arguments.of(VALIDATE_ENDPOINT_URL, buildValidPaymentRequest()),
        Arguments.of(PAYMENT_ENDPOINT_URL, buildValidPaymentRequest()),
        Arguments.of(VALIDATE_PAYEE_ENDPOINT_URL, buildValidExternalCreditorAccount()),
        Arguments.of(VALIDATE_PAYEE_ENDPOINT_URL, buildValidInternalAccountDetails()));
  }

  private static Stream<String> badConflictResponseBodies() {
    return Stream.of("", "abc");
  }
}
