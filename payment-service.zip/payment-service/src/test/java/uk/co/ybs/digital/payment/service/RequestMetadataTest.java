package uk.co.ybs.digital.payment.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;

import java.net.InetSocketAddress;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class RequestMetadataTest {

  @Test
  void toStringShouldNotIncludeForwardingAuth() {
    final RequestMetadata metadata =
        RequestMetadata.builder()
            .systemRequestMetadata(
                SystemRequestMetadata.builder()
                    .requestId(UUID.randomUUID())
                    .host(InetSocketAddress.createUnresolved("host", 443))
                    .brandCode("YBS")
                    .forwardingAuth("<jwt>")
                    .ipAddress("12.66.53.145")
                    .build())
            .userRequestMetadata(
                UserRequestMetadata.builder()
                    .sessionId(UUID.randomUUID())
                    .partyId("1234567890")
                    .channel("SAPP")
                    .build())
            .build();

    final String toString = metadata.toString();

    assertThat(
        toString, allOf(not(containsString("forwardingAuth")), not(containsString("<jwt>"))));
  }
}
