package uk.co.ybs.digital.payment.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
class PaymentWarningJsonTest {
  @Autowired private JacksonTester<PaymentWarning> jacksonTester;

  @ParameterizedTest
  @MethodSource("buildData")
  void serializes(
      final PaymentWarning paymentWarning, final ClassPathResource paymentWarningResponseJsonFile)
      throws IOException {
    assertThat(jacksonTester.write(paymentWarning)).isEqualToJson(paymentWarningResponseJsonFile);
  }

  @ParameterizedTest
  @MethodSource("buildData")
  void deserializes(
      final PaymentWarning paymentWarning, final ClassPathResource paymentWarningResponseJsonFile)
      throws IOException {
    assertThat(jacksonTester.read(paymentWarningResponseJsonFile)).isEqualTo(paymentWarning);
  }

  private static Stream<Arguments> buildData() {
    return Stream.of(
        Arguments.of(
            PaymentWarning.builder()
                .code(WarningCategory.DEBTOR_WITHDRAWAL_INTEREST_PENALTY)
                .parameters(
                    PaymentWarning.Parameters.builder()
                        .days(10)
                        .amount(new BigDecimal("10.00"))
                        .build())
                .build(),
            new ClassPathResource("jsonTest/PaymentWarningInterestPenaltyResponse.json")),
        Arguments.of(
            PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA).build(),
            new ClassPathResource("jsonTest/PaymentWarningIsaWithdrawalResponse.json")),
        Arguments.of(
            PaymentWarning.builder()
                .code(WarningCategory.DEBTOR_WITHDRAWAL_DAYS)
                .displayMessage("You have 3 withdrawal days remaining until 31-Dec-2020")
                .build(),
            new ClassPathResource("jsonTest/PaymentWarningWithdrawalDaysResponse.json")));
  }
}
