package uk.co.ybs.digital.payment.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyIterable;
import static uk.co.ybs.digital.payment.web.PaymentRequestValidationTestHelper.fieldError;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.UUID;
import java.util.stream.Stream;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.Validator;
import uk.co.ybs.digital.payment.service.PaymentService;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;

@SpringBootTest(
    classes = {ValidationAutoConfiguration.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
class InternalPaymentRequestValidationTest {

  @Autowired
  @Qualifier("defaultValidator")
  Validator validator;

  @MockBean PaymentService paymentService;

  private static final String CREDITOR_ACCOUNT_NUMBER_FIELD = "creditor.accountNumber";

  @Test
  void validRequestPassesValidation() {
    InternalPaymentRequest request = builderWithValidExternalPaymentDetails().build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), emptyIterable());
  }

  @Test
  void missingPaymentRequestRequiredFieldsFailsValidation() {
    InternalPaymentRequest request = InternalPaymentRequest.builder().build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("idempotencyKey", "You must specify a UUID idempotency key"),
                fieldError("creditor", "You must specify the creditor"),
                fieldError("debtor", "You must specify the debtor"),
                fieldError("amount", "You must specify an amount to transfer"),
                fieldError("currency", "You must specify a currency code"))));
  }

  @ParameterizedTest
  @ValueSource(strings = {"100", "100.1", "100.123"})
  void incorrectlyFormattedAmountPaymentRequestFailsValidation(final String paymentAmount) {
    InternalPaymentRequest request =
        builderWithValidExternalPaymentDetails().amount(new BigDecimal(paymentAmount)).build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singleton(
                fieldError(
                    "amount",
                    paymentAmount
                        + " is not an acceptable currency amount; value must be to two decimal places and between 1.00 and 250000.00"))));
  }

  @ParameterizedTest
  @MethodSource("creditorAccountNumberValidationArguments")
  void shouldValidateCreditorAccountNumber(
      final String accountNumber,
      final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    InternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(InternalCreditorDetails.builder().accountNumber(accountNumber).build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  static Stream<Arguments> creditorAccountNumberValidationArguments() {
    return Stream.of(
        Arguments.of(
            null,
            contains(
                fieldError(
                    CREDITOR_ACCOUNT_NUMBER_FIELD, "You must specify a creditor account number"))),
        Arguments.of(
            "",
            contains(
                fieldError(
                    CREDITOR_ACCOUNT_NUMBER_FIELD,
                    " is not an acceptable creditor account number; value must be a 10-digit, YBS internal account number"))),
        Arguments.of(
            "000000000",
            contains(
                fieldError(
                    CREDITOR_ACCOUNT_NUMBER_FIELD,
                    "000000000 is not an acceptable creditor account number; value must be a 10-digit, YBS internal account number"))),
        Arguments.of("0000000000", emptyIterable()),
        Arguments.of(
            "00000000000",
            contains(
                fieldError(
                    CREDITOR_ACCOUNT_NUMBER_FIELD,
                    "00000000000 is not an acceptable creditor account number; value must be a 10-digit, YBS internal account number"))));
  }

  private BindingResult validatePaymentRequest(final InternalPaymentRequest request) {
    BindingResult bindingResult = new MapBindingResult(new HashMap<>(), "request");
    validator.validate(request, bindingResult);
    return bindingResult;
  }

  private InternalPaymentRequest.InternalPaymentRequestBuilder
      builderWithValidExternalPaymentDetails() {
    return InternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency("GBP")
        .amount(new BigDecimal("100.00"))
        .debtor(Debtor.builder().accountNumber("0123456789").build())
        .creditor(InternalCreditorDetails.builder().accountNumber("0987654321").build());
  }
}
