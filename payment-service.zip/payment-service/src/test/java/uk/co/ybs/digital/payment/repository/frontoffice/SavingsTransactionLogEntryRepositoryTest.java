package uk.co.ybs.digital.payment.repository.frontoffice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.payment.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.payment.repository.YbsDataJpaTest;

@YbsDataJpaTest
class SavingsTransactionLogEntryRepositoryTest {

  private static final Long PARTY_ID = 1001L;

  private static final Long DEBTOR_ACCOUNT_NUMBER = 1000000000L;

  private static final BigDecimal AMOUNT = new BigDecimal("100.00");

  private static final Long CREDITOR_INTERNAL_ACCOUNT_NUMBER = 2000000000L;

  private static final Long CREDITOR_EXTERNAL_ACCOUNT_NUMBER = 20000000L;
  private static final Integer CREDITOR_EXTERNAL_SORT_CODE = 300000;
  private static final String CREDITOR_EXTERNAL_NAME = "Creditor Name";
  private static final String CREDITOR_EXTERNAL_REFERENCE = "Reference";

  private static final LocalDateTime START_TIME = LocalDateTime.parse("2020-04-06T12:34:56");
  private static final LocalDateTime END_TIME = START_TIME.plusSeconds(1);

  @Autowired SavingsTransactionLogEntryRepository testSubject;

  @Autowired TestEntityManager frontOfficeTestEntityManager;

  @ParameterizedTest
  @MethodSource("paymentLogEntries")
  void shouldSave(final SavingsTransactionLogEntry initial) {
    final SavingsTransactionLogEntry persisted = testSubject.save(initial);

    frontOfficeTestEntityManager.flush();
    frontOfficeTestEntityManager.clear();

    final Long sysId = persisted.getSysId();
    assertThat(sysId, notNullValue());

    final Long dailySequenceNumber = persisted.getDailySequenceNumber();
    assertThat(dailySequenceNumber, notNullValue());

    final Optional<SavingsTransactionLogEntry> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(
        found.get(),
        allOf(
            samePropertyValuesAs(initial, "sysId", "dailySequenceNumber"),
            hasProperty("sysId", is(sysId)),
            hasProperty("dailySequenceNumber", is(dailySequenceNumber))));
  }

  static Stream<Arguments> paymentLogEntries() {
    return Stream.of(
        Arguments.of(
            // External payment
            SavingsTransactionLogEntry.builder()
                .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                .amount(AMOUNT)
                .bankAccountName(CREDITOR_EXTERNAL_NAME)
                .bankReference(CREDITOR_EXTERNAL_REFERENCE)
                .bankSortCode(CREDITOR_EXTERNAL_SORT_CODE)
                .closure(SavingsTransactionLogEntry.CLOSURE_NO)
                .startTime(START_TIME)
                .endTime(END_TIME)
                .partySysId(PARTY_ID)
                .status(SavingsTransactionLogEntry.STATUS_WITHDRAWAL_END)
                .targetAccountNumber(CREDITOR_EXTERNAL_ACCOUNT_NUMBER)
                .transferIndicator(SavingsTransactionLogEntry.TRANSFER_INDICATOR_EXTERNAL)
                .build()),
        Arguments.of(
            // Internal payment
            SavingsTransactionLogEntry.builder()
                .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                .amount(AMOUNT)
                .closure(SavingsTransactionLogEntry.CLOSURE_NO)
                .startTime(START_TIME)
                .endTime(END_TIME)
                .partySysId(PARTY_ID)
                .status(SavingsTransactionLogEntry.STATUS_WITHDRAWAL_END)
                .targetAccountNumber(CREDITOR_INTERNAL_ACCOUNT_NUMBER)
                .transferIndicator(SavingsTransactionLogEntry.TRANSFER_INDICATOR_INTERNAL)
                .build()));
  }
}
