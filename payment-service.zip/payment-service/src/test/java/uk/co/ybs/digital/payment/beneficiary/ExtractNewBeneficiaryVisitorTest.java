package uk.co.ybs.digital.payment.beneficiary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.payment.account.Beneficiary;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.account.InternalBeneficiary;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;

class ExtractNewBeneficiaryVisitorTest {

  public static final String EXTERNAL_BENEFICIARY_ACCOUNT_NUMBER = "12345678";
  public static final String EXTERNAL_BENEFICIARY_NAME = "Mr Joe Bloggs";
  public static final String EXTERNAL_BENEFICIARY_SORT_CODE = "112233";
  public static final String MEMORABLE_NAME = "Big J Dog";
  public static final String PAYMENT_REFERENCE = "Petrol Money";
  public static final String INTERNAL_BENEFICIARY_ACCOUNT_NUMBER = "1234567890";

  public static final Debtor DEBTOR = Debtor.builder().accountNumber("0123456789").build();

  public static final ExternalCreditorDetails SAVABLE_EXTERNAL_CREDITOR_DETAILS =
      ExternalCreditorDetails.builder()
          .externalAccountNumber(EXTERNAL_BENEFICIARY_ACCOUNT_NUMBER)
          .sortCode(EXTERNAL_BENEFICIARY_SORT_CODE)
          .name(EXTERNAL_BENEFICIARY_NAME)
          .memorableName(MEMORABLE_NAME)
          .saveBeneficiary(true)
          .build();

  public static final InternalCreditorDetails SAVABLE_INTERNAL_CREDITOR_DETAILS =
      InternalCreditorDetails.builder()
          .accountNumber(INTERNAL_BENEFICIARY_ACCOUNT_NUMBER)
          .saveBeneficiary(true)
          .build();

  public static final ExternalPaymentRequest SAVABLE_EXTERNAL_PAYMENT_REQUEST =
      ExternalPaymentRequest.builder()
          .amount(BigDecimal.ONE)
          .currency("GBP")
          .idempotencyKey(UUID.randomUUID())
          .reference(PAYMENT_REFERENCE)
          .debtor(DEBTOR)
          .creditor(SAVABLE_EXTERNAL_CREDITOR_DETAILS)
          .build();

  public static final InternalPaymentRequest SAVABLE_INTERNAL_PAYMENT_REQUEST =
      InternalPaymentRequest.builder()
          .amount(BigDecimal.ONE)
          .currency("GBP")
          .idempotencyKey(UUID.randomUUID())
          .debtor(DEBTOR)
          .creditor(SAVABLE_INTERNAL_CREDITOR_DETAILS)
          .build();

  @Test
  void visitReturnsExternalBeneficiaryIfSaveBeneficiaryIsTrue() {
    final Optional<Beneficiary> actual =
        SAVABLE_EXTERNAL_PAYMENT_REQUEST.accept(new ExtractNewBeneficiaryVisitor());
    final Optional<Beneficiary> expected =
        Optional.of(
            ExternalBeneficiary.builder()
                .beneficiaryId(null)
                .reference(PAYMENT_REFERENCE)
                .name(EXTERNAL_BENEFICIARY_NAME)
                .accountNumber(EXTERNAL_BENEFICIARY_ACCOUNT_NUMBER)
                .accountSortCode(EXTERNAL_BENEFICIARY_SORT_CODE)
                .memorableName(MEMORABLE_NAME)
                .build());

    assertThat(actual, equalTo(expected));
  }

  @Test
  void visitReturnsInternalBeneficiaryIfSaveBeneficiaryIsTrue() {
    final Optional<Beneficiary> actual =
        SAVABLE_INTERNAL_PAYMENT_REQUEST.accept(new ExtractNewBeneficiaryVisitor());
    final Optional<InternalBeneficiary> expected =
        Optional.of(
            InternalBeneficiary.builder()
                .accountNumber(INTERNAL_BENEFICIARY_ACCOUNT_NUMBER)
                .beneficiaryId(null)
                .build());
    assertThat(actual, equalTo(expected));
  }

  @ParameterizedTest
  @MethodSource("nonBeneficiarySavingRequests")
  void visitReturnsEmptyOptionalWhenNoValidBeneficiaryIsRequestedToBeSaved(
      final PaymentRequest request) {
    Optional<Beneficiary> beneficiary = request.accept(new ExtractNewBeneficiaryVisitor());
    assertThat(beneficiary, equalTo(Optional.empty()));
  }

  private static Stream<PaymentRequest> nonBeneficiarySavingRequests() {

    return Stream.of(
        SAVABLE_EXTERNAL_PAYMENT_REQUEST
            .toBuilder()
            .creditor(SAVABLE_EXTERNAL_CREDITOR_DETAILS.toBuilder().saveBeneficiary(false).build())
            .build(),
        SAVABLE_EXTERNAL_PAYMENT_REQUEST
            .toBuilder()
            .creditor(ExternalCreditorBeneficiary.builder().beneficiaryId("beneficiaryId").build())
            .build(),
        SAVABLE_INTERNAL_PAYMENT_REQUEST
            .toBuilder()
            .creditor(SAVABLE_INTERNAL_CREDITOR_DETAILS.toBuilder().saveBeneficiary(false).build())
            .build(),
        SAVABLE_INTERNAL_PAYMENT_REQUEST
            .toBuilder()
            .creditor(SAVABLE_INTERNAL_CREDITOR_DETAILS.toBuilder().saveBeneficiary(null).build())
            .build());
  }
}
