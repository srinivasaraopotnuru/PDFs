package uk.co.ybs.digital.payment.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyIterable;
import static uk.co.ybs.digital.payment.utils.TestHelper.objectError;
import static uk.co.ybs.digital.payment.web.PaymentRequestValidationTestHelper.fieldError;

import com.google.common.base.Splitter;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.UUID;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;
import uk.co.ybs.digital.payment.service.PaymentService;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;

@SpringBootTest(
    classes = {ValidationAutoConfiguration.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
class ExternalPaymentRequestValidationTest {

  @Autowired
  @Qualifier("defaultValidator")
  Validator validator;

  @MockBean PaymentService paymentService;

  private static final String SORT_CODE = "000000";
  private static final String ACCOUNT_NUMBER = "00000000";
  private static final String CREDITOR_EXTERNAL_ACCOUNT_NUMBER_FIELD =
      "creditor.externalAccountNumber";
  private static final String CREDITOR_SORT_CODE_FIELD = "creditor.sortCode";
  private static final String CREDITOR_NAME_FIELD = "creditor.name";
  private static final String CREDITOR_MEMORABLE_NAME_FIELD = "creditor.memorableName";

  @Test
  void validRequestPassesValidation() {
    ExternalPaymentRequest request = builderWithValidExternalPaymentDetails().build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), emptyIterable());
  }

  @Test
  void missingPaymentRequestRequiredFieldsFailsValidation() {
    ExternalPaymentRequest request = ExternalPaymentRequest.builder().build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("idempotencyKey", "You must specify a UUID idempotency key"),
                fieldError("creditor", "You must specify the creditor"),
                fieldError("debtor", "You must specify the debtor"),
                fieldError("amount", "You must specify an amount to transfer"),
                fieldError("currency", "You must specify a currency code"))));
  }

  @ParameterizedTest
  @ValueSource(strings = {"100", "100.1", "100.123"})
  void incorrectlyFormattedAmountPaymentRequestFailsValidation(final String paymentAmount) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails().amount(new BigDecimal(paymentAmount)).build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singleton(
                fieldError(
                    "amount",
                    paymentAmount
                        + " is not an acceptable currency amount; value must be to two decimal places and between 1.00 and 250000.00"))));
  }

  @ParameterizedTest
  @MethodSource("referenceValidationArguments")
  void shouldValidateReference(
      final String reference, final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails().reference(reference).build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  @ParameterizedTest
  @MethodSource("invalidCharactersSource")
  void shouldFailForInvalidCharacterInReference(final String reference) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails().reference(reference).build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singleton(
                fieldError("reference", "Value must match pattern [A-Za-z0-9 ]*"))));
  }

  @ParameterizedTest
  @MethodSource("validCharactersSource")
  void shouldPassWithValidCharactersInReference(final String reference) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails().reference(reference).build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), emptyIterable());
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> referenceValidationArguments() {
    return Stream.of(
        Arguments.of(null, emptyIterable()),
        Arguments.of(
            "",
            contains(
                fieldError(
                    "reference", "Reference must contain at least one non-whitespace character."))),
        Arguments.of(
            "  ",
            contains(
                fieldError(
                    "reference", "Reference must contain at least one non-whitespace character."))),
        Arguments.of(" aaa ", emptyIterable()),
        Arguments.of("bbb", emptyIterable()));
  }

  @ParameterizedTest
  @MethodSource("creditorDetailsExternalAccountNumberValidationArguments")
  void shouldValidateCreditorDetailsExternalAccountNumber(
      final String accountNumber,
      final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(
                ExternalCreditorDetails.builder()
                    .externalAccountNumber(accountNumber)
                    .sortCode(SORT_CODE)
                    .build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  private static Stream<Arguments> creditorDetailsExternalAccountNumberValidationArguments() {
    return Stream.of(
        Arguments.of(
            null,
            contains(
                fieldError(
                    CREDITOR_EXTERNAL_ACCOUNT_NUMBER_FIELD,
                    "You must specify a creditor account number"))),
        Arguments.of(
            "",
            contains(
                fieldError(
                    CREDITOR_EXTERNAL_ACCOUNT_NUMBER_FIELD,
                    " is not an acceptable creditor account number; value must be 8 digits"))),
        Arguments.of(
            "0000000",
            contains(
                fieldError(
                    CREDITOR_EXTERNAL_ACCOUNT_NUMBER_FIELD,
                    "0000000 is not an acceptable creditor account number; value must be 8 digits"))),
        Arguments.of(ACCOUNT_NUMBER, emptyIterable()),
        Arguments.of(
            "000000000",
            contains(
                fieldError(
                    CREDITOR_EXTERNAL_ACCOUNT_NUMBER_FIELD,
                    "000000000 is not an acceptable creditor account number; value must be 8 digits"))));
  }

  @ParameterizedTest
  @MethodSource("creditorDetailsSortCodeValidationArguments")
  void shouldValidateCreditorDetailsSortCode(
      final String sortCode, final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(
                ExternalCreditorDetails.builder()
                    .externalAccountNumber(ACCOUNT_NUMBER)
                    .sortCode(sortCode)
                    .build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  private static Stream<Arguments> creditorDetailsSortCodeValidationArguments() {
    return Stream.of(
        Arguments.of(
            null,
            contains(
                fieldError(CREDITOR_SORT_CODE_FIELD, "You must specify a creditor sort code"))),
        Arguments.of(
            "",
            contains(
                fieldError(
                    CREDITOR_SORT_CODE_FIELD,
                    " is not a valid sort code; value must be of the form 112233"))),
        Arguments.of("112233", emptyIterable()),
        Arguments.of(
            "11223",
            contains(
                fieldError(
                    CREDITOR_SORT_CODE_FIELD,
                    "11223 is not a valid sort code; value must be of the form 112233"))),
        Arguments.of(
            "1122334",
            contains(
                fieldError(
                    CREDITOR_SORT_CODE_FIELD,
                    "1122334 is not a valid sort code; value must be of the form 112233"))),
        Arguments.of(
            "11-22-33",
            contains(
                fieldError(
                    CREDITOR_SORT_CODE_FIELD,
                    "11-22-33 is not a valid sort code; value must be of the form 112233"))));
  }

  @ParameterizedTest
  @MethodSource("creditorDetailsNameValidationArguments")
  void shouldValidateCreditorDetailsName(
      final String creditorName, final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(
                ExternalCreditorDetails.builder()
                    .externalAccountNumber(ACCOUNT_NUMBER)
                    .sortCode(SORT_CODE)
                    .name(creditorName)
                    .build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  private static Stream<Arguments> creditorDetailsNameValidationArguments() {
    return Stream.of(
        Arguments.of(null, emptyIterable()),
        Arguments.of(
            "",
            contains(
                fieldError(
                    CREDITOR_NAME_FIELD,
                    "Creditor name must be 30 characters or less and not all whitespace."))),
        Arguments.of(
            "  ",
            contains(
                fieldError(
                    CREDITOR_NAME_FIELD,
                    "Creditor name must be 30 characters or less and not all whitespace."))),
        Arguments.of(
            "1234567890123456789012345678901",
            contains(
                fieldError(
                    CREDITOR_NAME_FIELD,
                    "Creditor name must be 30 characters or less and not all whitespace."))),
        Arguments.of("123456789012345678901234567890", emptyIterable()),
        Arguments.of(" aaa ", emptyIterable()),
        Arguments.of("bbb", emptyIterable()));
  }

  @ParameterizedTest
  @MethodSource("invalidCharactersSource")
  void shouldFailForInvalidCharacterInCreditorName(final String creditorName) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(
                ExternalCreditorDetails.builder()
                    .externalAccountNumber(ACCOUNT_NUMBER)
                    .sortCode(SORT_CODE)
                    .name(creditorName)
                    .build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singleton(
                fieldError(CREDITOR_NAME_FIELD, "Value must match pattern [A-Za-z0-9 ]*"))));
  }

  @ParameterizedTest
  @MethodSource("validCharactersSource")
  void shouldPassForValidCharactersInCreditorName(final String creditorName) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(
                ExternalCreditorDetails.builder()
                    .externalAccountNumber(ACCOUNT_NUMBER)
                    .sortCode(SORT_CODE)
                    .name(creditorName)
                    .build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), emptyIterable());
  }

  @ParameterizedTest
  @MethodSource("creditorDetailsMemorableNameValidationArguments")
  void shouldValidateCreditorDetailsMemorableNameName(
      final String memorableName,
      final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(
                ExternalCreditorDetails.builder()
                    .externalAccountNumber(ACCOUNT_NUMBER)
                    .sortCode(SORT_CODE)
                    .memorableName(memorableName)
                    .build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  private static Stream<Arguments> creditorDetailsMemorableNameValidationArguments() {
    return Stream.of(
        Arguments.of(null, emptyIterable()),
        Arguments.of(
            "",
            containsInAnyOrder(
                fieldError(
                    CREDITOR_MEMORABLE_NAME_FIELD, "Memorable name must not be all whitespace"),
                fieldError(
                    CREDITOR_MEMORABLE_NAME_FIELD,
                    "Memorable name must be between 1 and 20 characters"))),
        Arguments.of(
            "  ",
            contains(
                fieldError(
                    CREDITOR_MEMORABLE_NAME_FIELD, "Memorable name must not be all whitespace"))),
        Arguments.of(
            "123456789012345678901",
            contains(
                fieldError(
                    CREDITOR_MEMORABLE_NAME_FIELD,
                    "Memorable name must be between 1 and 20 characters"))),
        Arguments.of("12345678901234567890", emptyIterable()),
        Arguments.of(" aaa ", emptyIterable()),
        Arguments.of("bbb", emptyIterable()));
  }

  @ParameterizedTest
  @MethodSource("invalidCharactersSource")
  void shouldFailForInvalidCharacterInMemorableName(final String memorableName) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(
                ExternalCreditorDetails.builder()
                    .externalAccountNumber(ACCOUNT_NUMBER)
                    .sortCode(SORT_CODE)
                    .memorableName(memorableName)
                    .build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Collections.singleton(
                fieldError(
                    CREDITOR_MEMORABLE_NAME_FIELD, "Value must match pattern [A-Za-z0-9 ]*"))));
  }

  @ParameterizedTest
  @MethodSource("validCharactersSource")
  void shouldPassForValidCharactersInMemorableName(final String memorableName) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(
                ExternalCreditorDetails.builder()
                    .externalAccountNumber(ACCOUNT_NUMBER)
                    .sortCode(SORT_CODE)
                    .memorableName(memorableName)
                    .build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), emptyIterable());
  }

  @ParameterizedTest
  @MethodSource("creditorBeneficiaryBeneficiaryIdValidationArguments")
  void shouldValidateCreditorBeneficiaryBeneficiaryId(
      final String beneficiaryId,
      final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ExternalPaymentRequest request =
        builderWithValidExternalPaymentDetails()
            .creditor(ExternalCreditorBeneficiary.builder().beneficiaryId(beneficiaryId).build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  private static Stream<Arguments> creditorBeneficiaryBeneficiaryIdValidationArguments() {
    return Stream.of(
        Arguments.of(
            null,
            contains(fieldError("creditor.beneficiaryId", "You must specify a beneficiaryId"))),
        Arguments.of(
            "",
            contains(
                fieldError(
                    "creditor.beneficiaryId",
                    "BeneficiaryId must contain at least one non-whitespace character"))),
        Arguments.of(
            "  ",
            contains(
                fieldError(
                    "creditor.beneficiaryId",
                    "BeneficiaryId must contain at least one non-whitespace character"))),
        Arguments.of(" aaa ", emptyIterable()),
        Arguments.of("bbb", emptyIterable()));
  }

  private BindingResult validatePaymentRequest(final ExternalPaymentRequest request) {
    BindingResult bindingResult = new MapBindingResult(new HashMap<>(), "request");
    validator.validate(request, bindingResult);
    return bindingResult;
  }

  private ExternalPaymentRequest.ExternalPaymentRequestBuilder
      builderWithValidExternalPaymentDetails() {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency("GBP")
        .amount(new BigDecimal("100.00"))
        .reference("ELECTRIC BILL")
        .debtor(Debtor.builder().accountNumber("0123456789").build())
        .creditor(
            ExternalCreditorDetails.builder()
                .externalAccountNumber("12345678")
                .sortCode("112233")
                .name("Mr Joe Bloggs")
                .build());
  }

  private static Stream<String> validCharactersSource() {
    final String all = " 01234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    // Split in to chunks so they will fit in to the smallest text field
    final Iterable<String> split = Splitter.fixedLength(18).split(all);
    return StreamSupport.stream(split.spliterator(), false);
  }

  private static Stream<String> invalidCharactersSource() {
    return Stream.of(
        "!", "@", "£", "$", "%", "^", "&", "*", "(", ")", "-", "_", "=", "+", "#", "[", "]", "{",
        "}", ";", "\\", ":", "\"", "|", ",", ".", "/", "<", ">", "?", "`", "~", "§", "±");
  }

  @ParameterizedTest
  @MethodSource("externalCreditorDetailsNameValidationArguments")
  void shouldValidateExternalCreditorName(
      final String name,
      final Boolean saveBeneficiaryFlag,
      final Matcher<Iterable<? extends ObjectError>> objectErrorsMatcher) {
    ExternalCreditorDetails request =
        ExternalCreditorDetails.builder()
            .externalAccountNumber(ACCOUNT_NUMBER)
            .sortCode("123456")
            .saveBeneficiary(saveBeneficiaryFlag)
            .name(name)
            .build();

    BindingResult bindingResult = validateExternalCreditorDetails(request);

    assertThat(bindingResult.getGlobalErrors(), objectErrorsMatcher);
  }

  private static Stream<Arguments> externalCreditorDetailsNameValidationArguments() {
    return Stream.of(
        Arguments.of(null, false, emptyIterable()),
        Arguments.of("Mr John Smith", true, emptyIterable()),
        Arguments.of(null, null, emptyIterable()),
        Arguments.of(
            null,
            true,
            contains(objectError("Creditor name is required when save beneficiary is true."))));
  }

  private BindingResult validateExternalCreditorDetails(final ExternalCreditorDetails request) {
    BindingResult bindingResult = new MapBindingResult(new HashMap<>(), "request");
    validator.validate(request, bindingResult);
    return bindingResult;
  }
}
