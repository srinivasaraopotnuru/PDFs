package uk.co.ybs.digital.payment.audit;

import java.io.IOException;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
@SuppressWarnings("PMD.TestClassWithoutTestCases")
class AuditPaymentAccountLockedRequestJsonTest {
  private static final UUID UNIQUE_REFERENCE =
      UUID.fromString("3bf0faa4-223f-11ea-978f-2e728ce88125");
  private static final String AUDIT_REQUEST_BASE_PATH = "api/audit/request";
  public static final String IP_ADDRESS = "12.66.53.145";
  private static final String DEBTOR_ACCOUNT_NUMBER = "1234567890";

  @Autowired private JacksonTester<AuditPaymentAccountLockedRequest> json;

  @Test
  void canSerializeRequest() throws IOException {
    Assertions.assertThat(json.write(buildAuditPaymentFailureRequestChallengeFailureType()))
        .isEqualToJson(
            new ClassPathResource(
                AUDIT_REQUEST_BASE_PATH + "/AuditPaymentAccountLockedFailure.json"),
            JSONCompareMode.STRICT);
  }

  @Test
  void canDeserializeRequest() throws IOException {
    Assertions.assertThat(
            json.read(
                new ClassPathResource(
                    AUDIT_REQUEST_BASE_PATH + "/AuditPaymentAccountLockedFailure.json")))
        .isEqualTo(buildAuditPaymentFailureRequestChallengeFailureType());
  }

  private static AuditPaymentAccountLockedRequest
      buildAuditPaymentFailureRequestChallengeFailureType() {
    return AuditPaymentAccountLockedRequest.builder()
        .paymentDetails(
            AuditPaymentAccountLockedRequest.PaymentFailureDetails.builder()
                .uniqueReference(UNIQUE_REFERENCE)
                .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                .build())
        .ipAddress(IP_ADDRESS)
        .build();
  }
}
