package uk.co.ybs.digital.payment.audit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.json.JSONException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.reactive.function.client.ClientHttpConnectorAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails.ExternalPaymentDebtor;
import uk.co.ybs.digital.payment.config.BigDecimalSerializer;
import uk.co.ybs.digital.payment.config.ServiceToServiceConfig;
import uk.co.ybs.digital.payment.exception.AuditServiceException;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.security.requestsigning.RequestSigningAutoConfiguration;

@SpringBootTest(
    classes = {
      AuditService.class,
      ServiceToServiceConfig.class,
      RequestSigningAutoConfiguration.class,
      BigDecimalSerializer.class, // Required to serialize link payment amount field
      ClientHttpConnectorAutoConfiguration
          .class // Required by the WebClient bean defined in AccountServiceConfig
    },
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AuditServiceTest {

  private static final String AUDIT_PAYMENT_DECISION_PATH = "/audit/payment/decision";
  private static final String AUDIT_PAYMENT_AUTHENTICATION_SUCCESS_PATH =
      "/audit/payment/authentication/success";
  private static final String AUDIT_PAYMENT_AUTHENTICATION_FAILURE_PATH =
      "/audit/payment/authentication/failure";

  private static final String AUDIT_PAYMENT_AUTHENTICATION_ACCOUNT_LOCKED_PATH =
      "/audit/payment/authentication/account-locked";
  private static final String LINK_PAYMENT_PATH = "/audit/payment/link";
  private static final String AUDIT_PAYMENT_FAILURE_PATH = "/audit/payment/failure";

  private static final String REQUEST_SIGNATURE_KEY_ID_HEADER = "x-ybs-request-signature-key-id";
  private static final String REQUEST_SIGNATURE_HEADER = "x-ybs-request-signature";
  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private static final UUID PAYMENT_UNIQUE_REFERENCE =
      UUID.fromString("3bf0faa4-223f-11ea-978f-2e728ce88125");
  private static final String REQUEST_SIGNATURE_KEY_ID = "payment-service-nonprod-1";

  private static final String AUTHORIZATION_BEARER_VALUE = "Bearer <jwt>";
  private static final String LOCALHOST_URL = "localhost:";

  private static final String PARTY_ID = "9876543210";
  private static final String CLIENT_IP_ADDRESS = "12.66.53.145";
  private static final UUID TRACKING_ID = UUID.fromString("eea9f3ff-c521-42c5-0932-84497301206a");
  private static final String TRACKING_CODE = "my-tracking-code";
  private static final String DEBTOR_ACCOUNT_NUMBER = "1234567890";

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Audit service returned error status: ";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling audit service";

  @Autowired private AuditService auditService;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  private MockWebServer mockWebServer;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start(auditTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void shouldAuditPaymentDecision() throws IOException, InterruptedException, JSONException {
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final AuditPaymentDecisionRequest auditRequest = buildValidAuditPaymentDecisionRequest();

    auditService.auditPaymentDecision(auditRequest, metadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is(AUDIT_PAYMENT_DECISION_PATH));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(AUTHORIZATION_BEARER_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.HOST), is(LOCALHOST_URL + auditTestPort));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(REQUEST_ID_HEADER), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE_HEADER), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID_HEADER), is(REQUEST_SIGNATURE_KEY_ID));

    final String expectedBody =
        readClassPathResource("api/audit/request/AuditPaymentDecision.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditPaymentAuthenticationSuccess()
      throws IOException, InterruptedException, JSONException {
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final AuditPaymentAuthSuccessRequest auditRequest = buildValidAuditPaymentAuthRequest();

    auditService.auditPaymentAuthenticationSuccess(auditRequest, metadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is((HttpMethod.POST.name())));
    assertThat(recordedRequest.getPath(), is(AUDIT_PAYMENT_AUTHENTICATION_SUCCESS_PATH));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(AUTHORIZATION_BEARER_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.HOST), is(LOCALHOST_URL + auditTestPort));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(REQUEST_ID_HEADER), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE_HEADER), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID_HEADER), is(REQUEST_SIGNATURE_KEY_ID));

    final String expectedBody =
        readClassPathResource("api/audit/request/AuditPaymentAuthenticationSuccess.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditPaymentAuthenticationFailure()
      throws IOException, InterruptedException, JSONException {
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final AuditPaymentAuthFailureRequest auditPaymentAuthFailureRequest =
        buildValidAuditPaymentAuthFailureRequest();

    auditService.auditPaymentAuthenticationFailure(auditPaymentAuthFailureRequest, metadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is((HttpMethod.POST.name())));
    assertThat(recordedRequest.getPath(), is(AUDIT_PAYMENT_AUTHENTICATION_FAILURE_PATH));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(AUTHORIZATION_BEARER_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.HOST), is(LOCALHOST_URL + auditTestPort));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(REQUEST_ID_HEADER), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE_HEADER), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID_HEADER), is(REQUEST_SIGNATURE_KEY_ID));

    final String expectedBody =
        readClassPathResource(
            "api/audit/request/AuditPaymentAuthenticationFailureChallengeFailureType.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditPaymentAccountLockedFailure()
      throws IOException, InterruptedException, JSONException {
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final AuditPaymentAccountLockedRequest auditPaymentAccountLockedFailureRequest =
        buildValidAuditPaymentAccountLockedFailureRequest();

    auditService.auditPaymentWithScaAccountLockedFailure(
        auditPaymentAccountLockedFailureRequest, metadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is((HttpMethod.POST.name())));
    assertThat(recordedRequest.getPath(), is(AUDIT_PAYMENT_AUTHENTICATION_ACCOUNT_LOCKED_PATH));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(AUTHORIZATION_BEARER_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.HOST), is(LOCALHOST_URL + auditTestPort));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(REQUEST_ID_HEADER), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE_HEADER), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID_HEADER), is(REQUEST_SIGNATURE_KEY_ID));

    final String expectedBody =
        readClassPathResource("api/audit/request/AuditPaymentAccountLockedFailure.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldLinkPayment() throws IOException, InterruptedException, JSONException {
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final LinkPaymentRequest auditRequest = buildLinkExternalPaymentRequest();

    auditService.linkPayment(auditRequest, metadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is((HttpMethod.POST.name())));
    assertThat(recordedRequest.getPath(), is(LINK_PAYMENT_PATH));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(AUTHORIZATION_BEARER_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.HOST), is(LOCALHOST_URL + auditTestPort));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(REQUEST_ID_HEADER), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE_HEADER), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID_HEADER), is(REQUEST_SIGNATURE_KEY_ID));

    final String expectedBody =
        readClassPathResource("api/audit/request/LinkExternalPaymentRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditPaymentFailure() throws IOException, InterruptedException, JSONException {
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final AuditPaymentFailureRequest auditRequest = buildValidAuditPaymentFailureRequest();

    auditService.auditPaymentFailure(auditRequest, metadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is((HttpMethod.POST.name())));
    assertThat(recordedRequest.getPath(), is(AUDIT_PAYMENT_FAILURE_PATH));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(AUTHORIZATION_BEARER_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.HOST), is(LOCALHOST_URL + auditTestPort));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(REQUEST_ID_HEADER), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE_HEADER), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID_HEADER), is(REQUEST_SIGNATURE_KEY_ID));

    final String expectedBody = readClassPathResource("api/audit/request/AuditPaymentFailure.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("auditMethods")
  void shouldThrowAuditServiceExceptionForConnectionError(
      final Function<AuditService, Executable> auditMethodGenerator) throws IOException {
    mockWebServer.shutdown();

    final AuditServiceException exception =
        assertThrows(AuditServiceException.class, auditMethodGenerator.apply(auditService));
    assertThat(exception.getMessage(), is(equalTo(UNEXPECTED_ERROR_MESSAGE)));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  private static Stream<Function<AuditService, Executable>> auditMethods() {
    final Function<AuditService, Executable> decision =
        auditService ->
            () ->
                auditService.auditPaymentDecision(
                    buildValidAuditPaymentDecisionRequest(),
                    buildValidRequestMetadata(UUID.randomUUID()));
    final Function<AuditService, Executable> authentication =
        auditService ->
            () ->
                auditService.auditPaymentAuthenticationSuccess(
                    buildValidAuditPaymentAuthRequest(),
                    buildValidRequestMetadata(UUID.randomUUID()));
    final Function<AuditService, Executable> authFailure =
        auditService ->
            () ->
                auditService.auditPaymentAuthenticationFailure(
                    buildValidAuditPaymentAuthFailureRequest(),
                    buildValidRequestMetadata(UUID.randomUUID()));
    final Function<AuditService, Executable> linkPayment =
        auditService ->
            () ->
                auditService.linkPayment(
                    buildLinkExternalPaymentRequest(),
                    buildValidRequestMetadata(UUID.randomUUID()));
    final Function<AuditService, Executable> paymentFailure =
        auditService ->
            () ->
                auditService.auditPaymentFailure(
                    buildValidAuditPaymentFailureRequest(),
                    buildValidRequestMetadata(UUID.randomUUID()));

    return Stream.of(decision, authentication, authFailure, linkPayment, paymentFailure);
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses") // NOPMD
  void auditPaymentDecisionShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final AuditPaymentDecisionRequest auditRequest = buildValidAuditPaymentDecisionRequest();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditPaymentDecision(auditRequest, metadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses") // NOPMD
  void auditPaymentAuthenticationShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final AuditPaymentAuthSuccessRequest auditRequest = buildValidAuditPaymentAuthRequest();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditPaymentAuthenticationSuccess(auditRequest, metadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses") // NOPMD
  void linkPaymentShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final LinkPaymentRequest auditRequest = buildLinkExternalPaymentRequest();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class, () -> auditService.linkPayment(auditRequest, metadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses")
  void auditAuthenticationFailureShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = buildValidRequestMetadata(requestId);
    final AuditPaymentAuthFailureRequest auditRequest = buildValidAuditPaymentAuthFailureRequest();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditPaymentAuthenticationFailure(auditRequest, metadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> auditServiceErrorResponses() throws IOException {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/audit/response/ErrorResponseInvalidSignature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/audit/response/ErrorResponseBadRequest.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400"),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/audit/response/UnexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/audit/response/EmptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/audit/response/TextResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/audit/response/TextResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")));
  }

  private static AuditPaymentDecisionRequest buildValidAuditPaymentDecisionRequest() {
    return AuditPaymentDecisionRequest.builder()
        .paymentDetails(
            SimplePaymentDetails.builder().uniqueReference(PAYMENT_UNIQUE_REFERENCE).build())
        .ipAddress(CLIENT_IP_ADDRESS)
        .build();
  }

  private static AuditPaymentAuthSuccessRequest buildValidAuditPaymentAuthRequest() {
    return AuditPaymentAuthSuccessRequest.builder()
        .paymentDetails(
            SimplePaymentDetails.builder().uniqueReference(PAYMENT_UNIQUE_REFERENCE).build())
        .ipAddress(CLIENT_IP_ADDRESS)
        .trackingId(TRACKING_ID)
        .trackingCode(TRACKING_CODE)
        .build();
  }

  private static AuditPaymentAuthFailureRequest buildValidAuditPaymentAuthFailureRequest() {
    return AuditPaymentAuthFailureRequest.builder()
        .paymentDetails(
            AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                .uniqueReference(PAYMENT_UNIQUE_REFERENCE)
                .failureType("CHALLENGE")
                .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                .build())
        .ipAddress(CLIENT_IP_ADDRESS)
        .build();
  }

  private static AuditPaymentAccountLockedRequest
      buildValidAuditPaymentAccountLockedFailureRequest() {
    return AuditPaymentAccountLockedRequest.builder()
        .paymentDetails(
            AuditPaymentAccountLockedRequest.PaymentFailureDetails.builder()
                .uniqueReference(PAYMENT_UNIQUE_REFERENCE)
                .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                .build())
        .ipAddress(CLIENT_IP_ADDRESS)
        .build();
  }

  private static LinkPaymentRequest buildLinkExternalPaymentRequest() {
    return LinkPaymentRequest.builder()
        .trackingId(TRACKING_ID)
        .trackingCode(TRACKING_CODE)
        .ipAddress(CLIENT_IP_ADDRESS)
        .paymentDetails(
            LinkExternalPaymentDetails.builder()
                .uniqueReference(PAYMENT_UNIQUE_REFERENCE)
                .transactionId("transaction-id")
                .debtor(
                    ExternalPaymentDebtor.builder()
                        .accountNumber("1234567890")
                        .sortCode("112233")
                        .build())
                .creditorDetails(
                    LinkExternalPaymentDetails.ExternalPaymentCreditorDetails.builder()
                        .externalAccountNumber("09876543")
                        .sortCode("332211")
                        .name("creditor name")
                        .beneficiary(
                            LinkExternalPaymentDetails.ExternalPaymentCreditorDetails
                                .ExternalCreditorBeneficiaryDetails.builder()
                                .memorableName("memorable name")
                                .build())
                        .build())
                .amount(new BigDecimal("123.45"))
                .reference("reference")
                .build())
        .build();
  }

  private static AuditPaymentFailureRequest buildValidAuditPaymentFailureRequest() {
    return AuditPaymentFailureRequest.builder()
        .paymentDetails(
            SimplePaymentDetails.builder().uniqueReference(PAYMENT_UNIQUE_REFERENCE).build())
        .ipAddress(CLIENT_IP_ADDRESS)
        .trackingId(TRACKING_ID)
        .trackingCode(TRACKING_CODE)
        .build();
  }

  private static RequestMetadata buildValidRequestMetadata(final UUID requestId) {
    return TestHelper.buildValidRequestMetadata(requestId, PARTY_ID, CLIENT_IP_ADDRESS);
  }

  private static String readClassPathResource(final String classPathResource) throws IOException {
    final ClassPathResource classpathResource = new ClassPathResource(classPathResource);
    return new String(
        Files.readAllBytes(classpathResource.getFile().toPath()), StandardCharsets.UTF_8);
  }
}
