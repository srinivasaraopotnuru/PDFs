package uk.co.ybs.digital.payment.web.dto;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.UUID;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse.ErrorItem;

class ErrorResponseTest {

  private static final String ERROR_RESPONSE_CODE = "code";
  private static final String ERROR_RESPONSE_MESSAGE = "message";
  private static final String ERROR_RESPONSE_ERROR_CODE = "abc";

  @Test
  void containsOnlyErrorCodeShouldReturnTrueIfOnlyErrorItemMatches() {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(ERROR_RESPONSE_CODE)
            .message(ERROR_RESPONSE_MESSAGE)
            .error(
                ErrorItem.builder()
                    .errorCode(ERROR_RESPONSE_ERROR_CODE)
                    .message(ERROR_RESPONSE_MESSAGE)
                    .build())
            .build();

    assertThat(errorResponse.containsOnlyErrorCode(ERROR_RESPONSE_ERROR_CODE), is(equalTo(true)));
  }

  @Test
  void containsOnlyErrorCodeShouldReturnFalseIfOnlyErrorItemMismatches() {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(ERROR_RESPONSE_CODE)
            .message(ERROR_RESPONSE_MESSAGE)
            .error(ErrorItem.builder().errorCode("xyz").message(ERROR_RESPONSE_MESSAGE).build())
            .build();

    assertThat(errorResponse.containsOnlyErrorCode(ERROR_RESPONSE_ERROR_CODE), is(equalTo(false)));
  }

  @Test
  void containsOnlyErrorCodeShouldReturnFalseForNoErrorItems() {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(ERROR_RESPONSE_CODE)
            .message(ERROR_RESPONSE_MESSAGE)
            .build();

    assertThat(errorResponse.containsOnlyErrorCode(ERROR_RESPONSE_ERROR_CODE), is(equalTo(false)));
  }

  @Test
  void containsOnlyErrorCodeShouldReturnFalseForMultipleMatchingErrorItems() {
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(ERROR_RESPONSE_CODE)
            .message(ERROR_RESPONSE_MESSAGE)
            .error(
                ErrorItem.builder()
                    .errorCode(ERROR_RESPONSE_ERROR_CODE)
                    .message(ERROR_RESPONSE_MESSAGE)
                    .build())
            .error(
                ErrorItem.builder()
                    .errorCode(ERROR_RESPONSE_ERROR_CODE)
                    .message(ERROR_RESPONSE_MESSAGE)
                    .build())
            .build();

    assertThat(errorResponse.containsOnlyErrorCode(ERROR_RESPONSE_ERROR_CODE), is(equalTo(false)));
  }
}
