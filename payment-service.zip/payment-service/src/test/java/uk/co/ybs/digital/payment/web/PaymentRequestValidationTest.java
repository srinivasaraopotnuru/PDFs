package uk.co.ybs.digital.payment.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyIterable;
import static uk.co.ybs.digital.payment.web.PaymentRequestValidationTestHelper.fieldError;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;
import java.util.stream.Stream;
import lombok.Builder;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.Validator;
import uk.co.ybs.digital.payment.service.PaymentService;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequestVisitor;

@SpringBootTest(
    classes = {ValidationAutoConfiguration.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
class PaymentRequestValidationTest {

  @Autowired
  @Qualifier("defaultValidator")
  Validator validator;

  @MockBean PaymentService paymentService;

  private static final String DEBTOR_ACCOUNT_NUMBER_FIELD = "debtor.accountNumber";

  @Test
  void validRequestPassesValidation() {
    ConcretePaymentRequest request = builderWithValidPaymentDetails().build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), emptyIterable());
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @Test
  void missingPaymentRequestRequiredFieldsFailsValidation() {
    ConcretePaymentRequest request = ConcretePaymentRequest.builder().build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("idempotencyKey", "You must specify a UUID idempotency key"),
                fieldError("debtor", "You must specify the debtor"),
                fieldError("amount", "You must specify an amount to transfer"),
                fieldError("currency", "You must specify a currency code"))));
  }

  @ParameterizedTest
  @MethodSource("amountValidationArguments")
  void shouldValidateAmount(
      final BigDecimal amount, final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ConcretePaymentRequest request = builderWithValidPaymentDetails().amount(amount).build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  static Stream<Arguments> amountValidationArguments() {
    return Stream.of(
        Arguments.of(
            new BigDecimal("0.99"),
            contains(
                fieldError(
                    "amount",
                    "0.99 is not an acceptable currency amount; value must be to two decimal places and between 1.00 and 250000.00"))),
        Arguments.of(new BigDecimal("1.00"), emptyIterable()),
        Arguments.of(new BigDecimal("1.01"), emptyIterable()),
        Arguments.of(new BigDecimal("249999.99"), emptyIterable()),
        Arguments.of(new BigDecimal("250000.00"), emptyIterable()),
        Arguments.of(
            new BigDecimal("250000.01"),
            contains(
                fieldError(
                    "amount",
                    "250000.01 is not an acceptable currency amount; value must be to two decimal places and between 1.00 and 250000.00"))),
        Arguments.of(
            null, contains(fieldError("amount", "You must specify an amount to transfer"))));
  }

  @ParameterizedTest
  @MethodSource("currencyValidationArguments")
  void shouldValidateCurrency(
      final String currency, final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ConcretePaymentRequest request = builderWithValidPaymentDetails().currency(currency).build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  static Stream<Arguments> currencyValidationArguments() {
    return Stream.of(
        Arguments.of(null, contains(fieldError("currency", "You must specify a currency code"))),
        Arguments.of(
            "",
            contains(
                fieldError("currency", " is not a valid payment currency; value must be GBP"))),
        Arguments.of("GBP", emptyIterable()),
        Arguments.of(
            "USD",
            contains(
                fieldError("currency", "USD is not a valid payment currency; value must be GBP"))));
  }

  @ParameterizedTest
  @MethodSource("debtorAccountNumberValidationArguments")
  void shouldValidateDebtorAccountNumber(
      final String accountNumber,
      final Matcher<Iterable<? extends FieldError>> fieldErrorsMatcher) {
    ConcretePaymentRequest request =
        builderWithValidPaymentDetails()
            .debtor(Debtor.builder().accountNumber(accountNumber).build())
            .build();

    BindingResult bindingResult = validatePaymentRequest(request);

    assertThat(bindingResult.getFieldErrors(), fieldErrorsMatcher);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  static Stream<Arguments> debtorAccountNumberValidationArguments() {
    return Stream.of(
        Arguments.of(
            null,
            contains(
                fieldError(
                    DEBTOR_ACCOUNT_NUMBER_FIELD, "You must specify a debtor account number"))),
        Arguments.of(
            "",
            contains(
                fieldError(
                    DEBTOR_ACCOUNT_NUMBER_FIELD,
                    " is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number"))),
        Arguments.of(
            "000000000",
            contains(
                fieldError(
                    DEBTOR_ACCOUNT_NUMBER_FIELD,
                    "000000000 is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number"))),
        Arguments.of("0000000000", emptyIterable()),
        Arguments.of(
            "00000000000",
            contains(
                fieldError(
                    DEBTOR_ACCOUNT_NUMBER_FIELD,
                    "00000000000 is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number"))));
  }

  private BindingResult validatePaymentRequest(final ConcretePaymentRequest request) {
    BindingResult bindingResult = new MapBindingResult(new HashMap<>(), "request");
    validator.validate(request, bindingResult);
    return bindingResult;
  }

  private ConcretePaymentRequest.ConcretePaymentRequestBuilder builderWithValidPaymentDetails() {
    return ConcretePaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency("GBP")
        .amount(new BigDecimal("100.00"))
        .debtor(Debtor.builder().accountNumber("0123456789").build());
  }

  private static class ConcretePaymentRequest extends PaymentRequest {
    @Builder
    public ConcretePaymentRequest(
        final UUID idempotencyKey,
        final String currency,
        final BigDecimal amount,
        final Debtor debtor) {
      super(idempotencyKey, currency, amount, debtor);
    }

    @Override
    public <T> T accept(final PaymentRequestVisitor<T> visitor) {
      throw new UnsupportedOperationException();
    }
  }
}
