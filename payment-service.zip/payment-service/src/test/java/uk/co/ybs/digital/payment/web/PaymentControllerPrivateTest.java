package uk.co.ybs.digital.payment.web;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidExternalCreditorDetails;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidInternalAccountDetails;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidRequestMetadata;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidSystemRequestMetadata;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.JwtRequestPostProcessor;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.payment.exception.InternalAccountValidatorException;
import uk.co.ybs.digital.payment.exception.InvalidPaymentException;
import uk.co.ybs.digital.payment.service.AccountValidator;
import uk.co.ybs.digital.payment.service.PaymentService;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(controllers = PaymentControllerPrivate.class)
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter
  RequestVerificationSecurityAutoConfiguration.class,
  FilterErrorResponseFactory.class, // Spring Security
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class // Metrics
})
@ActiveProfiles("test")
class PaymentControllerPrivateTest {
  private static final String BASE_PATH = "/private";
  private static final String VALIDATE_PAYEE_ENDPOINT = BASE_PATH + "/validate/payee";
  private static final String HOST_HEADER_VALUE = "paymentservice.ybs.co.uk:443";
  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String SIGNATURE_KEY_ID_HEADER = "x-ybs-request-signature-key-id";
  private static final String KEY_ID_HEADER_VALUE = "key-id";
  private static final String SCOPE = "PAYMENT_READ";
  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String BRAND_CODE = "YBS";
  private static final String CHANNEL = "SAPP";
  private static final String BAD_REQUEST_ERROR_CODE = "400 Bad Request";
  private static final String CONFLICT_ERROR_CODE = "409 Conflict";
  private static final String SUB = "987654321";
  private static final String PARTY_ID = "11111";
  private static final UUID SESSION_ID = UUID.fromString("83e4265c-e2b3-4859-ad93-83c27cd2fd33");
  private static final String SESSION_ID_ATTRIBUTE_NAME =
      "uk.co.ybs.digital.logging.session.SessionIdFilter.sessionId";

  @Autowired private MockMvc mockMvc;

  @Autowired private ObjectMapper objectMapper;

  @MockBean private PaymentService paymentService;
  @MockBean private AccountValidator accountValidator;
  @MockBean private RequestSigningVerificationService requestSigningVerificationService;

  @BeforeEach
  void beforeEach() {
    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
  }

  @Test
  void validateExternalCreditorRequestReturnsSuccessWithValidRequestPayload() throws Exception {
    UUID requestId = UUID.randomUUID();
    ExternalCreditorDetails request = buildValidExternalCreditorAccount();
    RequestMetadata requestMetadata = buildValidSystemRequestMetadata(requestId, IP_ADDRESS);

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtWithScope(SCOPE)))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(paymentService).validateCreditor(request, requestMetadata);
  }

  @Test
  void validateInternalAccountRequestReturnsSuccessWithValidRequestPayload() throws Exception {
    UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();
    RequestMetadata requestMetadata =
        buildValidRequestMetadata(requestId, SESSION_ID, PARTY_ID, IP_ADDRESS);

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(TestHelper.jwtCustomerWithScope(SCOPE)))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(paymentService).validateCreditor(request, requestMetadata);
  }

  @Test
  void validateInternalAccountRequestReturnsSuccessWithoutJWTSubType() throws Exception {
    UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();
    RequestMetadata requestMetadata = buildValidSystemRequestMetadata(requestId, IP_ADDRESS);

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt(jwtWithScope(SCOPE)))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isNoContent());

    verify(paymentService).validateCreditor(request, requestMetadata);
  }

  @Test
  void requestShouldReturnUnauthorizedWhenNoBearerTokenProvided() throws Exception {
    UUID requestId = UUID.randomUUID();
    ExternalCreditorDetails request = buildValidExternalCreditorAccount();

    ErrorResponse expectedErrorResponse = buildUnauthorizedErrorResponse(requestId);

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isUnauthorized())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  private static Stream<Arguments> internalAccountValidatorErrorResponses() {
    return Stream.of(
        Arguments.of(
            CONFLICT_ERROR_CODE,
            "Conflict",
            "Failed to find internal account: 0123456789",
            InternalAccountValidatorException.Reason.ACCOUNT_NUMBER,
            409),
        Arguments.of(
            BAD_REQUEST_ERROR_CODE,
            "Bad Request",
            "Missing field: party_id",
            InternalAccountValidatorException.Reason.PARTY_ID,
            400));
  }

  @ParameterizedTest
  @MethodSource("internalAccountValidatorErrorResponses")
  void validateInternalAccountRequestShouldReturnFailureWhenPaymentServiceValidateCreditorFails(
      final String errorCode,
      final String errorMessage,
      final String errorItemMessage,
      final InternalAccountValidatorException.Reason reason,
      final int status)
      throws Exception {

    final UUID requestId = UUID.randomUUID();
    final InternalAccountDetails request = buildValidInternalAccountDetails();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(errorCode)
            .message(errorMessage)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("InternalPayee.Invalid")
                    .message(errorItemMessage)
                    .build())
            .build();

    doThrow(new InternalAccountValidatorException(errorItemMessage, reason))
        .when(paymentService)
        .validateCreditor(any(), any());

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().is(status))
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void requestShouldReturnForbiddenWhenUserDoesNotHavePaymentsScope() throws Exception {
    UUID requestId = UUID.randomUUID();
    ExternalCreditorDetails request = buildValidExternalCreditorAccount();

    ErrorResponse expectedErrorResponse = buildForbiddenErrorResponse(requestId);

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeOther()))
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @Test
  void requestShouldReturnBadRequestWhenRequestIdIsNotAUUID() throws Exception {
    String requestId = "not-a-uuid";
    ExternalCreditorDetails request = buildValidExternalCreditorAccount();

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.id", notNullValue()))
        .andExpect(jsonPath("$.code", is(BAD_REQUEST_ERROR_CODE)))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is("x-ybs-request-id")));
  }

  @Test
  void validatePayeeRequestShouldReturnBadRequestIfRequestValidationFails() throws Exception {
    ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(UUID.randomUUID())
            .code(BAD_REQUEST_ERROR_CODE)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message(
                        "1234 is not an acceptable creditor account number; value must be 8 digits")
                    .build())
            .build();

    ExternalCreditorDetails request =
        ExternalCreditorDetails.builder().externalAccountNumber("1234").sortCode("123456").build();

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse)));
  }

  @ParameterizedTest
  @MethodSource("validatePayeeErrorReasonsAndExpectedErrorItemsArguments")
  void validatePayeeRequestShouldReturnConflictWhenPaymentValidationServiceValidationFails(
      final InvalidPaymentException.Reason reason, final ErrorResponse.ErrorItem errorItem)
      throws Exception {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code(CONFLICT_ERROR_CODE)
            .message("Conflict")
            .error(errorItem)
            .build();

    ExternalCreditorDetails request = buildValidExternalCreditorDetails();

    final SortedSet<InvalidPaymentException.Reason> reasons =
        new TreeSet<>(ImmutableSet.of(reason));
    doThrow(new InvalidPaymentException("Some message", reasons, null))
        .when(paymentService)
        .validateCreditor(any(), any());

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, expectedErrorResponse.getId())
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isConflict())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  private static Stream<Arguments> validatePayeeErrorReasonsAndExpectedErrorItemsArguments() {
    return validatePayeeErrorReasonsAndExpectedErrorItems().entrySet().stream()
        .map(entry -> Arguments.of(entry.getKey(), entry.getValue()));
  }

  private static Map<InvalidPaymentException.Reason, ErrorResponse.ErrorItem>
      validatePayeeErrorReasonsAndExpectedErrorItems() {
    final Map<InvalidPaymentException.Reason, ErrorResponse.ErrorItem>
        reasonsAndExpectedErrorItems = new LinkedHashMap<>();
    reasonsAndExpectedErrorItems.put(
        InvalidPaymentException.Reason.CREDITOR_ACCOUNT,
        ErrorResponse.ErrorItem.builder()
            .errorCode("PaymentRejected.CreditorAccount")
            .message("Unable to make payment to the creditor account details provided")
            .build());
    return reasonsAndExpectedErrorItems;
  }

  @Test
  void validatePayeeRequestShouldReturnBadRequestWhenContentNotParseable() throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code(BAD_REQUEST_ERROR_CODE)
            .id(requestId)
            .message("Unable to parse request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Resource.InvalidFormat")
                    .message(
                        "An unexpected error occurred when attempting to parse the request body")
                    .build())
            .build();

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content("some content text"))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void validatePayeeRequestShouldReturnBadRequestWhenNoRequestBodyProvided() throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code(BAD_REQUEST_ERROR_CODE)
            .id(requestId)
            .message("Unable to parse request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Resource.InvalidFormat")
                    .message(
                        "An unexpected error occurred when attempting to parse the request body")
                    .build())
            .build();

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(new byte[0]))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @Test
  void validatePayeeRequestShouldReturnUnsupportedMediaTypeErrorWhenContentTypeNotJson()
      throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("415 Unsupported Media Type")
            .id(requestId)
            .message("Unsupported Media Type")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("Content-Type header is invalid")
                    .build())
            .build();

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.TEXT_PLAIN)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content("some content text"))
        .andExpect(status().isUnsupportedMediaType())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ACCEPT, is(MediaType.APPLICATION_JSON_VALUE)));
  }

  @Test
  void validatePayeeRequestShouldReturnMethodNotAllowedWhenMethodNotAllowed() throws Exception {
    ExternalCreditorDetails request = buildValidExternalCreditorDetails();
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("405 Method Not Allowed")
            .id(requestId)
            .message("Method Not Allowed")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method")
                    .build())
            .build();

    mockMvc
        .perform(
            put(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.POST.name())));
  }

  @Test
  void validateShouldIncludeResponseBodyWhenUnexpectedSpringInternalExceptionThrown()
      throws Exception {
    ExternalCreditorDetails request = buildValidExternalCreditorDetails();
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException()).when(paymentService).validateCreditor(any(), any());

    mockMvc
        .perform(
            post(VALIDATE_PAYEE_ENDPOINT)
                .with(jwt(jwtScopeRequired()))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(REQUEST_ID_HEADER, requestId)
                .header(SIGNATURE_KEY_ID_HEADER, KEY_ID_HEADER_VALUE)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  private JwtRequestPostProcessor jwt(final Jwt jwt) {
    return SecurityMockMvcRequestPostProcessors.jwt().jwt(jwt);
  }

  private Jwt jwtScopeRequired() {
    return jwtWithScope(SCOPE);
  }

  private Jwt jwtScopeOther() {
    return jwtWithScope("OTHER");
  }

  private static Jwt jwtWithScope(final String scope) {
    return Jwt.withTokenValue("<jwt>")
        .header("kid", KEY_ID_HEADER_VALUE)
        .subject(SUB)
        .claim("scope", scope)
        .claim("brand_code", BRAND_CODE)
        .claim("channel", CHANNEL)
        .build();
  }

  private ErrorResponse buildForbiddenErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied")
                .message("Access Denied")
                .build())
        .build();
  }

  private ErrorResponse buildUnauthorizedErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("401 Unauthorized")
        .message("Unauthorized")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Unauthorized")
                .message("Unauthorized")
                .build())
        .build();
  }

  private static ExternalCreditorDetails buildValidExternalCreditorAccount() {
    return TestHelper.buildValidExternalCreditorAccount();
  }
}
