package uk.co.ybs.digital.payment.service.sca.event;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;

class EventContextFactoryTest {
  private EventContextFactory testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new EventContextFactory();
  }

  @Test
  void shouldCreateSinglePaymentScaAppliedEventContext() {
    final UUID transactionReferenceId = UUID.randomUUID();
    final String channel = "SAPP";

    final EventContext eventContext =
        testSubject.createSinglePaymentScaEventContext(transactionReferenceId, channel, null, null);
    assertThat(eventContext.getChannel(), is(channel));
    assertThat(eventContext.getEventType(), is(EventContext.Type.PAYMENT_TRANSACTION));
    assertThat(eventContext.getSca().getExemptReasonCode(), is(nullValue()));
    assertThat(eventContext.getSca().getDecisionStatus(), is(DecisionStatus.APPLIED));
    assertThat(eventContext.getSubEventType(), is(EventContext.SubType.SINGLE));
    assertThat(eventContext.getTransactionReferenceId(), is(transactionReferenceId));
  }
}
