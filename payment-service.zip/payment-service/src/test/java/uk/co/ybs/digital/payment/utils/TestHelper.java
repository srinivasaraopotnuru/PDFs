package uk.co.ybs.digital.payment.utils;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.UUID;
import lombok.experimental.UtilityClass;
import org.hamcrest.Matcher;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.ObjectError;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.Deposits;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.account.WithdrawalLimit;
import uk.co.ybs.digital.payment.account.Withdrawals;
import uk.co.ybs.digital.payment.audit.AuditPaymentAccountLockedRequest;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.service.SystemRequestMetadata;
import uk.co.ybs.digital.payment.service.UserRequestMetadata;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;
import uk.co.ybs.digital.payment.service.sca.PaymentChallengePayloadBody;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;

@UtilityClass
public class TestHelper {

  private static final String ACCOUNT_NUMBER = "0123456789";
  private static final String GBP = "GBP";
  private static final BigDecimal AMOUNT = new BigDecimal("100.00");
  private static final String CONFLICT_CODE = "409 Conflict";
  private static final String CONFLICT_MESSAGE = "Conflict";
  private static final String FORBIDDEN_CODE = "403 Forbidden";
  private static final String FORBIDDEN_MESSAGE = "Forbidden";
  private static final String JWT = "<jwt>";
  private static final String YBS = "YBS";
  private static final String SAPP = "SAPP";

  public static PaymentFailureRequest buildPaymentFailureRequest() {
    return PaymentFailureRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .debtor(Debtor.builder().accountNumber(ACCOUNT_NUMBER).build())
        .build();
  }

  public static InternalAccountDetails buildValidInternalAccountDetails() {
    return InternalAccountDetails.builder().accountNumber(ACCOUNT_NUMBER).build();
  }

  public static ExternalPaymentRequest buildValidExternalPaymentRequest() {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency(GBP)
        .amount(AMOUNT)
        .amount(new BigDecimal("100.00"))
        .reference("ELECTRIC BILL")
        .debtor(Debtor.builder().accountNumber(ACCOUNT_NUMBER).build())
        .creditor(buildValidExternalCreditorDetails())
        .build();
  }

  public static ExternalPaymentRequest buildValidExternalPaymentRequestWithBeneficiary(
      final String reference) {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency(GBP)
        .amount(new BigDecimal("100.00"))
        .reference(reference)
        .debtor(Debtor.builder().accountNumber("0123456789").build())
        .creditor(buildValidExternalCreditorBeneficiary())
        .build();
  }

  public static ExternalCreditorDetails buildValidExternalCreditorDetails() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber("12345678")
        .sortCode("112233")
        .name("Mr Joe Bloggs")
        .saveBeneficiary(true)
        .memorableName("Joint Account")
        .build();
  }

  public static ExternalCreditorDetails buildValidExternalCreditorAccount() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber("12345678")
        .sortCode("112233")
        .build();
  }

  public static ExternalCreditorBeneficiary buildValidExternalCreditorBeneficiary() {
    return ExternalCreditorBeneficiary.builder().beneficiaryId("123abc").build();
  }

  public static ExternalBeneficiary buildValidExternalBeneficiary() {
    return buildValidExternalBeneficiary("124abc");
  }

  public static ExternalBeneficiary buildValidExternalBeneficiary(final String id) {
    return ExternalBeneficiary.builder()
        .beneficiaryId(id)
        .accountNumber("12345679")
        .accountSortCode("112244")
        .name("MR B TEST")
        .reference("B REF")
        .memorableName("Joint Account")
        .build();
  }

  public static ExternalBeneficiary buildValidExternalBeneficiaryWithReference(
      final String reference) {
    return ExternalBeneficiary.builder()
        .beneficiaryId("124abc")
        .accountNumber("12345678")
        .accountSortCode("112233")
        .name("Mr Joe Bloggs")
        .reference(reference)
        .memorableName("Joint Account")
        .build();
  }

  public static ErrorResponse buildBeneficiaryTechnicalErrorResponse(final UUID requestId) {
    return ErrorResponse.builder(HttpStatus.INTERNAL_SERVER_ERROR)
        .id(requestId)
        .message("Unable to save beneficiary")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode(ErrorResponse.ErrorItem.SAVE_BENEFICIARY_FAILED_TECHNICAL_ERROR)
                .message("Unexpected error occurred when saving the beneficiary")
                .build())
        .build();
  }

  public static InternalPaymentRequest buildValidInternalPaymentRequest() {
    return InternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency(GBP)
        .amount(AMOUNT)
        .debtor(Debtor.builder().accountNumber(ACCOUNT_NUMBER).build())
        .creditor(InternalCreditorDetails.builder().accountNumber("0987654321").build())
        .build();
  }

  public static AuditPaymentAccountLockedRequest buildAuditPaymentAccountLockedFailureRequest(
      final PaymentChallengePayloadBody paymentChallengePayloadBody,
      final RequestMetadata requestMetadata) {

    return AuditPaymentAccountLockedRequest.builder()
        .ipAddress(requestMetadata.getIpAddress())
        .paymentDetails(
            AuditPaymentAccountLockedRequest.PaymentFailureDetails.builder()
                .uniqueReference(
                    paymentChallengePayloadBody.getPaymentRequest().getIdempotencyKey())
                .debtorAccountNumber(
                    paymentChallengePayloadBody.getPaymentRequest().getDebtor().getAccountNumber())
                .build())
        .build();
  }

  public static Jwt jwtCustomerWithScope(final String scope) {
    return Jwt.withTokenValue(JWT)
        .header("kid", "key-id")
        .subject("987654321")
        .claim("scope", scope)
        .claim("sid", UUID.fromString("83e4265c-e2b3-4859-ad93-83c27cd2fd33"))
        .claim("brand_code", YBS)
        .claim("channel", SAPP)
        .claim("registration_id", UUID.randomUUID().toString())
        .claim("customer_email", "joe.bloggs@ybs.co.uk")
        .claim("customer_title", "Mr")
        .claim("customer_last_name", "Bloggs")
        .claim("party_id", "11111")
        .claim("sub_type", "customer")
        .build();
  }

  public static RequestMetadata buildValidRequestMetadata(final UUID requestId) {
    return buildValidRequestMetadata(requestId, "666666");
  }

  public static RequestMetadata buildValidRequestMetadata(
      final UUID requestId, final String partyId) {
    return buildValidRequestMetadata(requestId, UUID.randomUUID(), partyId, "127.0.0.1", YBS, SAPP);
  }

  public static RequestMetadata buildValidRequestMetadata(
      final UUID requestId, final String partyId, final String ipAddress) {
    return buildValidRequestMetadata(requestId, UUID.randomUUID(), partyId, ipAddress, YBS, SAPP);
  }

  public static RequestMetadata buildValidRequestMetadata(
      final UUID requestId, final UUID sessionId, final String partyId, final String ipAddress) {
    return buildValidRequestMetadata(requestId, sessionId, partyId, ipAddress, YBS, SAPP);
  }

  public static RequestMetadata buildValidSystemRequestMetadata(
      final UUID requestId, final String ipAddress) {
    return RequestMetadata.builder()
        .systemRequestMetadata(
            SystemRequestMetadata.builder()
                .requestId(requestId)
                .host(InetSocketAddress.createUnresolved("paymentservice.ybs.co.uk", 443))
                .brandCode(YBS)
                .forwardingAuth(JWT)
                .ipAddress(ipAddress)
                .build())
        .build();
  }

  public static RequestMetadata buildValidRequestMetadata(
      final UUID requestId,
      final UUID sessionId,
      final String partyId,
      final String ipAddress,
      final String brandCode,
      final String channel) {
    return RequestMetadata.builder()
        .systemRequestMetadata(
            SystemRequestMetadata.builder()
                .requestId(requestId)
                .host(InetSocketAddress.createUnresolved("paymentservice.ybs.co.uk", 443))
                .brandCode(brandCode)
                .forwardingAuth(JWT)
                .ipAddress(ipAddress)
                .build())
        .userRequestMetadata(
            UserRequestMetadata.builder()
                .sessionId(sessionId)
                .partyId(partyId)
                .channel(channel)
                .email("joe.bloggs@ybs.co.uk")
                .title("Mr")
                .surname("Bloggs")
                .build())
        .build();
  }

  public static RequestMetadata buildValidRequestMetadataWithChannel(
      final UUID requestId,
      final UUID sessionId,
      final String partyId,
      final String ipAddress,
      final String channel) {
    return RequestMetadata.builder()
        .systemRequestMetadata(
            SystemRequestMetadata.builder()
                .requestId(requestId)
                .host(InetSocketAddress.createUnresolved("paymentservice.ybs.co.uk", 443))
                .brandCode(YBS)
                .forwardingAuth(JWT)
                .ipAddress(ipAddress)
                .build())
        .userRequestMetadata(
            UserRequestMetadata.builder()
                .sessionId(sessionId)
                .partyId(partyId)
                .channel(channel)
                .email("joe.bloggs@ybs.co.uk")
                .title("Mr")
                .surname("Bloggs")
                .build())
        .build();
  }

  public static Account buildValidAccount() {
    return Account.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .accountSortCode("123456")
        .withdrawals(
            Withdrawals.builder()
                .permittedOverApi(true)
                .limit(
                    WithdrawalLimit.builder()
                        .available(3)
                        .permitted(4)
                        .periodEnd(LocalDate.of(2020, 12, 31))
                        .build())
                .build())
        .deposits(Deposits.builder().permittedOverApi(true).build())
        .build();
  }

  public static ErrorResponse accessDeniedErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(FORBIDDEN_CODE)
        .message(FORBIDDEN_MESSAGE)
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied")
                .message("Access Denied")
                .build())
        .build();
  }

  public static ErrorResponse accessDeniedWithPasswordAttemptsRemainingErrorResponse(
      final UUID requestId, final String passwordAttemptsRemainingMessage) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(FORBIDDEN_CODE)
        .message(FORBIDDEN_MESSAGE)
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied")
                .message("Access Denied")
                .build())
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied.PwdAttemptsRemaining")
                .message(passwordAttemptsRemainingMessage)
                .build())
        .build();
  }

  public static ErrorResponse invalidRequestSignature(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(FORBIDDEN_CODE)
        .message(FORBIDDEN_MESSAGE)
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied.InvalidRequestSignature")
                .message("Access Denied")
                .build())
        .build();
  }

  public static ErrorResponse scaRequired(final UUID requestId, final String message) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(FORBIDDEN_CODE)
        .message("Strong customer authentication required")
        .error(ErrorResponse.ErrorItem.builder().errorCode("SCA.Required").message(message).build())
        .build();
  }

  public static ErrorResponse unauthorizedErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("401 Unauthorized")
        .message("Unauthorized")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Unauthorized")
                .message("Unauthorized")
                .build())
        .build();
  }

  public static ErrorResponse badPemKey(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("400 Bad Request")
        .message("SCA key could not be read")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Header.Invalid")
                .message("SCA key must be in PEM format and Base64 encoded")
                .path("x-ybs-sca-key")
                .build())
        .build();
  }

  public static ErrorResponse internalError(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("500 Internal Server Error")
        .message("Internal Server Error")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("UnexpectedError")
                .message("Internal Server Error")
                .build())
        .build();
  }

  public static ErrorResponse paymentRejectedDebtorAccount(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(CONFLICT_CODE)
        .message(CONFLICT_MESSAGE)
        .error(
            ErrorItem.builder()
                .errorCode("PaymentRejected.DebtorAccount")
                .message("Unable to make payment from the debtor account details provided")
                .build())
        .build();
  }

  public static ErrorResponse paymentRejectedDebtorAccountInsufficientFunds(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(CONFLICT_CODE)
        .message(CONFLICT_MESSAGE)
        .error(
            ErrorItem.builder()
                .errorCode("PaymentRejected.DebtorAccount.InsufficientFunds")
                .message("Insufficient funds available to make payment")
                .build())
        .build();
  }

  public static ErrorResponse paymentRejectedDebtorAccountMultipleSignatoriesRequired(
      final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(CONFLICT_CODE)
        .message(CONFLICT_MESSAGE)
        .error(
            ErrorItem.builder()
                .errorCode("PaymentRejected.DebtorAccount.MultipleSignatoriesRequired")
                .message("Multiple signatories are required for withdrawals")
                .build())
        .build();
  }

  public static ErrorResponse paymentFailureNotification(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(CONFLICT_CODE)
        .message(CONFLICT_MESSAGE)
        .error(
            ErrorItem.builder()
                .errorCode("PaymentFailureNotification.DebtorAccount")
                .message("Unable to send notification using the debtor account details provided")
                .build())
        .build();
  }

  public static ErrorResponse paymentRejectedCreditorAccount(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(CONFLICT_CODE)
        .message(CONFLICT_MESSAGE)
        .error(
            ErrorItem.builder()
                .errorCode("PaymentRejected.CreditorAccount")
                .message("Unable to make payment to the creditor account details provided")
                .build())
        .build();
  }

  public static ErrorResponse paymentRejectedCreditorAccountInternalSortCode(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(CONFLICT_CODE)
        .message(CONFLICT_MESSAGE)
        .error(
            ErrorItem.builder()
                .errorCode("PaymentRejected.CreditorAccount.InternalSortCode")
                .message(
                    "Payments to internal accounts must be done using the internal account number")
                .build())
        .build();
  }

  public static ErrorResponse validatePayeeRejectedCreditorAccountInternalSortCode(
      final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(CONFLICT_CODE)
        .message(CONFLICT_MESSAGE)
        .error(
            ErrorItem.builder()
                .errorCode("PaymentRejected.CreditorAccount.InternalSortCode")
                .message(
                    "Payments to internal accounts must be done using the internal account number")
                .build())
        .build();
  }

  public static ErrorResponse paymentRejectedCreditorAccountDepositLimitExceeded(
      final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code(CONFLICT_CODE)
        .message(CONFLICT_MESSAGE)
        .error(
            ErrorItem.builder()
                .errorCode("PaymentRejected.CreditorAccount.DepositLimit")
                .message("Cannot exceed deposit limit on the creditor account")
                .build())
        .build();
  }

  public static String readClassPathResource(final String classPathResource) throws IOException {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  public static String readClassPathResource(final Resource resource) throws IOException {
    return new String(Files.readAllBytes(resource.getFile().toPath()), StandardCharsets.UTF_8);
  }

  public static ValidatedExternalPaymentRequest buildValidatedExternalPaymentRequest(
      final Account debtorAccount) {
    return ValidatedExternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency(GBP)
        .amount(AMOUNT)
        .debtorAccount(debtorAccount)
        .creditorDetails(buildValidExternalCreditorDetails())
        .reference("ELECTRIC BILL")
        .build();
  }

  public static ValidatedExternalPaymentRequest buildValidatedExternalPaymentRequestNullReference(
      final Account debtorAccount) {
    return ValidatedExternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency(GBP)
        .amount(AMOUNT)
        .debtorAccount(debtorAccount)
        .creditorDetails(buildValidExternalCreditorDetails())
        .build();
  }

  public static ValidatedExternalPaymentRequest buildValidatedExternalPaymentRequestEmptyReference(
      final Account debtorAccount) {
    return ValidatedExternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency(GBP)
        .amount(AMOUNT)
        .reference("")
        .debtorAccount(debtorAccount)
        .creditorDetails(buildValidExternalCreditorDetails())
        .build();
  }

  public static ValidatedInternalPaymentRequest buildValidatedInternalPaymentRequest(
      final Account debtorAccount) {
    return ValidatedInternalPaymentRequest.builder()
        .idempotencyKey(UUID.randomUUID())
        .currency(GBP)
        .amount(new BigDecimal("5.00"))
        .debtorAccount(debtorAccount)
        .creditorAccount(Account.builder().accountNumber("0987654321").build())
        .build();
  }

  public static Matcher<ObjectError> objectError(final String defaultMessage) {
    return allOf(hasProperty("defaultMessage", is(defaultMessage)));
  }
}
