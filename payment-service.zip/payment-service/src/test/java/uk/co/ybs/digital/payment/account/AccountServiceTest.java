package uk.co.ybs.digital.payment.account;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.reactive.function.client.ClientHttpConnectorAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.codec.DecodingException;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.payment.config.ServiceToServiceConfig;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNoCustomerRelationshipException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.AccountServiceException;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.security.requestsigning.RequestSigningAutoConfiguration;

@SpringBootTest(
    classes = {
      AccountService.class,
      ServiceToServiceConfig.class,
      RequestSigningAutoConfiguration.class,
      ClientHttpConnectorAutoConfiguration
          .class // Required by the WebClient bean defined in AccountServiceConfig
    },
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AccountServiceTest {

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Account service returned error status: ";

  private static final String PARTY_ID = "9876543210";
  private static final String ACCOUNT_NUMBER = "0123456789";
  private static final String HEADER_CONTENT_TYPE = "Content-Type";
  private static final String APPLICATION_JSON = "application/json";
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  private static final String REQUEST_SIGNATURE_KEY_ID_VALUE = "payment-service-nonprod-1";
  private static final String HTTP_GET = "GET";
  private static final String LOCALHOST_URL = "localhost:";
  private static final String AUTHORIZATION_BEARER_VALUE = "Bearer <jwt>";

  @Autowired private AccountService accountService;

  @Autowired ObjectMapper objectMapper;

  @Value("${uk.co.ybs.digital.account-test-port}")
  private int accountTestPort;

  private MockWebServer mockWebServer;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start(accountTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void getAccountShouldReturnAccount() throws IOException, InterruptedException {
    final String body =
        readClassPathResource("api/account/account/ResponseAccountNumber0123456789.json");
    mockWebServer.enqueue(
        new MockResponse().setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);
    final Account account = accountService.getAccount(ACCOUNT_NUMBER, metadata);
    assertThat(account, is(equalTo(buildValidAccount())));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(equalTo((HTTP_GET))));
    assertThat(
        recordedRequest.getPath(), is(equalTo("/account/private/accounts/" + ACCOUNT_NUMBER)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST), is(equalTo(LOCALHOST_URL + accountTestPort)));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(REQUEST_SIGNATURE_KEY_ID_VALUE)));
  }

  @Test
  void getAccountShouldReturnAccountGroup() throws IOException, InterruptedException {
    final String body = readClassPathResource("api/account/account/ResponseAccountGroup.json");
    mockWebServer.enqueue(
        new MockResponse().setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);
    final GroupedAccountListResponse groupedAccountListResponse =
        accountService.getAccountGroup(metadata);
    assertThat(groupedAccountListResponse, is(equalTo((buildValidAccountGroup()))));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(equalTo((HTTP_GET))));
    assertThat(recordedRequest.getPath(), is(equalTo("/account/private/accounts/grouped")));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST), is(equalTo(LOCALHOST_URL + accountTestPort)));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(REQUEST_SIGNATURE_KEY_ID_VALUE)));
  }

  @ParameterizedTest
  @MethodSource("buildFiltersAndQueryParams")
  void getAccountWithFiltersShouldReturnAccount(
      final List<AccountDetailsFilter> filters, final String queryParams)
      throws IOException, InterruptedException {
    final String body =
        readClassPathResource("api/account/account/ResponseAccountNumber0123456789.json");
    mockWebServer.enqueue(
        new MockResponse().setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);
    final Account account = accountService.getAccount(ACCOUNT_NUMBER, filters, metadata);
    assertThat(account, is(equalTo(buildValidAccount())));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(equalTo((HTTP_GET))));
    assertThat(
        recordedRequest.getPath(),
        is(equalTo("/account/private/accounts/" + ACCOUNT_NUMBER + queryParams)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST), is(equalTo(LOCALHOST_URL + accountTestPort)));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(REQUEST_SIGNATURE_KEY_ID_VALUE)));
  }

  @Test
  void getWithdrawalInterestPenaltyShouldReturnValue() throws IOException, InterruptedException {
    final String body =
        readClassPathResource("api/account/withdrawalInterestPenalty/response.json");
    mockWebServer.enqueue(
        new MockResponse().setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);
    final WithdrawalInterestPenalty withdrawalInterestPenalty =
        accountService.getWithdrawalInterestPenalty(
            ACCOUNT_NUMBER, new BigDecimal("456.78"), metadata);
    assertThat(
        withdrawalInterestPenalty,
        equalTo(new WithdrawalInterestPenalty(new BigDecimal("123.45"))));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(equalTo((HTTP_GET))));
    assertThat(
        recordedRequest.getPath(),
        is(
            equalTo(
                "/account/private/accounts/"
                    + ACCOUNT_NUMBER
                    + "/withdrawal-interest-penalty?withdrawalAmount=456.78")));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST), is(equalTo(LOCALHOST_URL + accountTestPort)));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(REQUEST_SIGNATURE_KEY_ID_VALUE)));
  }

  @ParameterizedTest
  @MethodSource("serviceMethods") // NOPMD
  void methodShouldThrowAccountServiceExceptionForInvalidJson(
      final Function<AccountService, Executable> method) {
    final String body = "abc";
    mockWebServer.enqueue(
        new MockResponse().setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final AccountServiceException thrown =
        assertThrows(AccountServiceException.class, method.apply(accountService));

    assertThat(thrown.getMessage(), containsString("Error calling account service"));
    assertThat(thrown.getCause(), instanceOf(DecodingException.class));
  }

  @ParameterizedTest
  @MethodSource("serviceMethods") // NOPMD
  void methodShouldThrowAccountServiceExceptionForEmptyResponse(
      final Function<AccountService, Executable> method) {
    final String body = "";
    mockWebServer.enqueue(
        new MockResponse().setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final AccountServiceException exception =
        assertThrows(AccountServiceException.class, method.apply(accountService));
    assertThat(exception.getMessage(), containsString("Empty response calling account service"));
  }

  @ParameterizedTest
  @MethodSource("serviceMethods") // NOPMD
  void methodShouldThrowAccountServiceExceptionForConnectionError(
      final Function<AccountService, Executable> method) throws IOException {
    mockWebServer.shutdown();

    final AccountServiceException exception =
        assertThrows(AccountServiceException.class, method.apply(accountService));
    assertThat(exception.getMessage(), containsString("Error calling account service"));
  }

  @ParameterizedTest
  @MethodSource("serviceMethods")
  void methodShouldThrowAccountAccessDeniedExceptionForHttpStatus403AndErrorCodeAccessDenied(
      final Function<AccountService, Executable> method, final String entityDescription)
      throws IOException {
    final String body = readClassPathResource("api/account/ResponseErrorAccessDenied.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.FORBIDDEN.value())
            .setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON)
            .setBody(body));

    final AccountServiceEntityAccessDeniedException exception =
        assertThrows(AccountServiceEntityAccessDeniedException.class, method.apply(accountService));
    assertThat(
        exception.getMessage(),
        is(equalTo("Party " + PARTY_ID + " is not allowed access " + entityDescription)));
  }

  @ParameterizedTest
  @MethodSource("serviceMethods") // NOPMD
  void
      methodShouldThrowAccountServiceEntityNoCustomerRelationshipExceptionForHttpStatus403AndErrorCodeNoCustomerRelationship(
          final Function<AccountService, Executable> method, final String entityDescription)
          throws IOException {
    final String body =
        readClassPathResource("api/account/ResponseErrorAccessDeniedNoCustomerRelationship.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.FORBIDDEN.value())
            .setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON)
            .setBody(body));

    final AccountServiceEntityNoCustomerRelationshipException exception =
        assertThrows(
            AccountServiceEntityNoCustomerRelationshipException.class,
            method.apply(accountService));
    assertThat(
        exception.getMessage(),
        is(
            equalTo(
                "Party "
                    + PARTY_ID
                    + " doesn't have customer relationship to access "
                    + entityDescription)));
  }

  @ParameterizedTest
  @MethodSource("serviceMethodsForSingleAccount")
  void methodShouldThrowAccountNotFoundExceptionForHttpStatus404AndErrorCodeResourceNotFound(
      final Function<AccountService, Executable> method, final String entityDescription)
      throws IOException {
    final String body = readClassPathResource("api/account/ResponseErrorResourceNotFound.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.NOT_FOUND.value())
            .setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON)
            .setBody(body));

    final AccountServiceEntityNotFoundException exception =
        assertThrows(AccountServiceEntityNotFoundException.class, method.apply(accountService));
    assertThat(exception.getMessage(), is(equalTo("Failed to find " + entityDescription)));
  }

  @ParameterizedTest
  @MethodSource("unexpectedHttpStatusesAndBodies")
  void getAccountShouldThrowAccountServiceExceptionForUnexpectedHttpStatusAndBody(
      final HttpStatus httpStatus,
      final MediaType mediaType,
      final ClassPathResource bodyResource,
      final Matcher<String> expectedMessage)
      throws IOException {
    final String body = readClassPathResource(bodyResource);
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, mediaType)
            .setBody(body));

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final AccountServiceException exception =
        assertThrows(
            AccountServiceException.class,
            () -> accountService.getAccount(ACCOUNT_NUMBER, metadata));
    assertThat(
        exception.getClass(),
        is(equalTo(AccountServiceException.class))); // Expect not a sub-class here
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AccountServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("unexpectedHttpStatusesAndBodies")
  void getAccountsGroupedShouldThrowAccountServiceExceptionForUnexpectedHttpStatusAndBody(
      final HttpStatus httpStatus,
      final MediaType mediaType,
      final ClassPathResource bodyResource,
      final Matcher<String> expectedMessage)
      throws IOException {
    final String body = readClassPathResource(bodyResource);
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, mediaType)
            .setBody(body));

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final AccountServiceException exception =
        assertThrows(AccountServiceException.class, () -> accountService.getAccountGroup(metadata));
    assertThat(
        exception.getClass(),
        is(equalTo(AccountServiceException.class))); // Expect not a sub-class here
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AccountServiceException.class)));
  }

  private static Stream<Arguments> serviceMethods() {
    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);

    final Function<AccountService, Executable> getAccount = getAccount(metadata);
    final Function<AccountService, Executable> getWithdrawalInterestPenalty =
        getWithDrawalInterestPenalty(metadata);
    final Function<AccountService, Executable> getGroupedAccounts =
        service -> () -> service.getAccountGroup(metadata);

    return Stream.of(
        Arguments.of(getAccount, "account " + ACCOUNT_NUMBER),
        Arguments.of(
            getWithdrawalInterestPenalty,
            "withdrawal interest penalty for withdrawal of 123.45 from account " + ACCOUNT_NUMBER),
        Arguments.of(getGroupedAccounts, "accounts"));
  }

  private static Stream<Arguments> serviceMethodsForSingleAccount() {
    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);

    final Function<AccountService, Executable> getAccount = getAccount(metadata);
    final Function<AccountService, Executable> getWithdrawalInterestPenalty =
        getWithDrawalInterestPenalty(metadata);

    return Stream.of(
        Arguments.of(getAccount, "account " + ACCOUNT_NUMBER),
        Arguments.of(
            getWithdrawalInterestPenalty,
            "withdrawal interest penalty for withdrawal of 123.45 from account " + ACCOUNT_NUMBER));
  }

  @NotNull
  private static Function<AccountService, Executable> getAccount(final RequestMetadata metadata) {
    return service -> () -> service.getAccount(ACCOUNT_NUMBER, metadata);
  }

  @NotNull
  private static Function<AccountService, Executable> getWithDrawalInterestPenalty(
      final RequestMetadata metadata) {
    return service ->
        () ->
            service.getWithdrawalInterestPenalty(
                ACCOUNT_NUMBER, new BigDecimal("123.45"), metadata);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> unexpectedHttpStatusesAndBodies() {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDeniedWithAdditional.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied"),
                containsString("ErrorCodeOther"))),
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorResourceNotFound.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("Resource.NotFound"))),
        Arguments.of(
            HttpStatus.NOT_FOUND,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorResourceNotFoundWithAdditional.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "404"),
                containsString("Resource.NotFound"),
                containsString("ErrorCodeOther"))),
        Arguments.of(
            HttpStatus.NOT_FOUND,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDenied.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "404"),
                containsString("AccessDenied"))),
        Arguments.of(
            HttpStatus.INTERNAL_SERVER_ERROR,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDenied.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "500"),
                containsString("AccessDenied"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/UnexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/EmptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/TextResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            new ClassPathResource("api/audit/response/TextResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")));
  }

  private String readClassPathResource(final ClassPathResource classPathResource)
      throws IOException {
    return new String(
        Files.readAllBytes(classPathResource.getFile().toPath()), StandardCharsets.UTF_8);
  }

  private String readClassPathResource(final String classPathResource) throws IOException {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  private static Account buildValidAccount() {
    return Account.builder()
        .accountNumber("0123456789")
        .accountSortCode("609204")
        .balances(
            Arrays.asList(
                Balance.builder()
                    .type("InterimAvailable")
                    .amount(new BigDecimal("100000.00"))
                    .build(),
                Balance.builder()
                    .type("InterimBooked")
                    .amount(new BigDecimal("100000.00"))
                    .build()))
        .withdrawals(
            Withdrawals.builder()
                .permittedOverApi(true)
                .limit(
                    WithdrawalLimit.builder()
                        .available(3)
                        .permitted(4)
                        .periodEnd(LocalDate.of(2020, 12, 31))
                        .build())
                .interestPenalty(InterestPenalty.builder().days(30).build())
                .build())
        .deposits(Deposits.builder().permittedOverApi(true).build())
        .isa(Isa.builder().flexible(false).build())
        .build();
  }

  private static AccountSummary buildAccountSummary() {
    return AccountSummary.builder().accountName("test").accountNumber("12345678").build();
  }

  private static GroupedAccountListResponse.AccountGroup buildAccountGroup() {
    return (GroupedAccountListResponse.AccountGroup.builder()
        .accounts(Collections.singletonList(buildAccountSummary()))
        .build());
  }

  private static GroupedAccountListResponse buildValidAccountGroup() {
    return GroupedAccountListResponse.builder().owned(buildAccountGroup()).build();
  }

  private static Stream<Arguments> buildFiltersAndQueryParams() {
    return Stream.of(
        Arguments.of(Collections.emptyList(), ""),
        Arguments.of(
            Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
            "?include=availableDepositLimit"),
        Arguments.of(
            Collections.singletonList(AccountDetailsFilter.OTHER_ACCOUNT), "?include=otherAccount"),
        Arguments.of(
            Arrays.asList(
                AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT, AccountDetailsFilter.OTHER_ACCOUNT),
            "?include=availableDepositLimit,otherAccount"));
  }
}
