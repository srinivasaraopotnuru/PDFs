package uk.co.ybs.digital.payment.service;

import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.Mockito.verify;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;

import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.time.LocalDateTime;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.payment.repository.frontoffice.SavingsTransactionLogEntryRepository;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;

@ExtendWith(MockitoExtension.class)
class TransactionLogCreatorTest {
  private static final String REFERENCE = "ELECTRIC BILL";
  private static final String BRAND_CODE = "YBS";
  private static final String CHANNEL = "SAPP";
  private static final BigDecimal AMOUNT = new BigDecimal("100.00");
  private static final String CURRENCY_CODE = "GBP";
  private static final String NAME = "Mr Creditor";

  private static final String PARTY_ID = "666";

  private static final String DEBTOR_ACCOUNT_NUMBER = "0123456789";
  private static final String DEBTOR_ACCOUNT_SORT_CODE = "111111";

  private static final String CREDITOR_ACCOUNT_NUMBER_EXTERNAL = "12345678";
  private static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL = "1234567890";
  private static final String CREDITOR_SORT_CODE_EXTERNAL = "332211";
  private static final String CREDITOR_SORT_CODE_INTERNAL = "112233";

  private static final String TRANSFER_INDICATOR_INTERNAL = "I";
  private static final String TRANSFER_INDICATOR_EXTERNAL = "E";
  private static final String STATUS_WITHDRAWAL_COMPLETE = "WITHDRAWAL_COMPLETE";
  private static final String CLOSURE_NO = "N";

  private static final UUID REQUEST_ID = UUID.fromString("38c36e91-8f48-425d-89e2-8d1fe9833834");
  private static final UUID IDEMPOTENCY_KEY =
      UUID.fromString("a21d20aa-609a-48c9-abf5-128a30600e62");

  private static final LocalDateTime START_TIME = LocalDateTime.parse("2020-05-14T17:16:31");
  private static final LocalDateTime END_TIME = START_TIME.plusSeconds(2);

  private static final UUID SESSION_ID = UUID.fromString("83e4265c-e2b3-4859-ad93-83c27cd2fd33");

  private TransactionLogCreator testSubject;

  @Mock private SavingsTransactionLogEntryRepository savingsTransactionLogEntryRepository;

  @BeforeEach
  void beforeEach() {
    testSubject = new TransactionLogCreator(savingsTransactionLogEntryRepository);
  }

  @Test
  void shouldCreateTransactionLogEntryForValidatedExternalPaymentRequest() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ValidatedExternalPaymentRequest request = buildExternalPaymentRequest();

    testSubject.create(request, START_TIME, END_TIME, requestMetadata);

    final SavingsTransactionLogEntry expected =
        SavingsTransactionLogEntry.builder()
            .accountNumber(123456789L)
            .amount(AMOUNT)
            .bankAccountName(NAME)
            .bankReference(REFERENCE)
            .bankSortCode(332211)
            .closure(CLOSURE_NO)
            .endTime(END_TIME)
            .partySysId(666L)
            .startTime(START_TIME)
            .status(STATUS_WITHDRAWAL_COMPLETE)
            .targetAccountNumber(12345678L)
            .transferIndicator(TRANSFER_INDICATOR_EXTERNAL)
            .build();
    verify(savingsTransactionLogEntryRepository).save(argThat(samePropertyValuesAs(expected)));
  }

  @Test
  void shouldCreateTransactionLogEntryForValidatedInternalPaymentRequest() {
    final RequestMetadata requestMetadata = buildValidRequestMetadata();
    final ValidatedInternalPaymentRequest request = buildInternalPaymentRequest();

    testSubject.create(request, START_TIME, END_TIME, requestMetadata);

    final SavingsTransactionLogEntry expected =
        SavingsTransactionLogEntry.builder()
            .accountNumber(123456789L)
            .amount(AMOUNT)
            .closure(CLOSURE_NO)
            .endTime(END_TIME)
            .partySysId(666L)
            .startTime(START_TIME)
            .status(STATUS_WITHDRAWAL_COMPLETE)
            .targetAccountNumber(1234567890L)
            .transferIndicator(TRANSFER_INDICATOR_INTERNAL)
            .build();
    verify(savingsTransactionLogEntryRepository).save(argThat(samePropertyValuesAs(expected)));
  }

  private SystemRequestMetadata buildSystemRequestMetadata() {
    return SystemRequestMetadata.builder()
        .host(InetSocketAddress.createUnresolved("paymentservice.ybs.co.uk", 443))
        .requestId(REQUEST_ID)
        .brandCode(BRAND_CODE)
        .forwardingAuth("<jwt>")
        .ipAddress("127.0.0.1")
        .build();
  }

  private UserRequestMetadata buildUserRequestMetadata() {
    return UserRequestMetadata.builder()
        .sessionId(SESSION_ID)
        .channel(CHANNEL)
        .partyId(PARTY_ID)
        .email("joe.bloggs@ybs.co.uk")
        .title("Mr")
        .surname("Bloggs")
        .build();
  }

  private RequestMetadata buildValidRequestMetadata() {
    return RequestMetadata.builder()
        .systemRequestMetadata(buildSystemRequestMetadata())
        .userRequestMetadata(buildUserRequestMetadata())
        .build();
  }

  private ValidatedExternalPaymentRequest buildExternalPaymentRequest() {
    return ValidatedExternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(CURRENCY_CODE)
        .amount(AMOUNT)
        .reference(REFERENCE)
        .debtorAccount(debtorAccount())
        .creditorDetails(buildExternalCreditorDetails())
        .build();
  }

  private ExternalCreditorDetails buildExternalCreditorDetails() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .sortCode(CREDITOR_SORT_CODE_EXTERNAL)
        .name(NAME)
        .build();
  }

  private ValidatedInternalPaymentRequest buildInternalPaymentRequest() {
    return ValidatedInternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(CURRENCY_CODE)
        .amount(AMOUNT)
        .debtorAccount(debtorAccount())
        .creditorAccount(
            Account.builder()
                .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
                .accountSortCode(CREDITOR_SORT_CODE_INTERNAL)
                .build())
        .build();
  }

  private Account debtorAccount() {
    return Account.builder()
        .accountNumber(DEBTOR_ACCOUNT_NUMBER)
        .accountSortCode(DEBTOR_ACCOUNT_SORT_CODE)
        .build();
  }
}
