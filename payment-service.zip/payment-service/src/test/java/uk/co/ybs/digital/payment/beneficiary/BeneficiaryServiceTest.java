package uk.co.ybs.digital.payment.beneficiary;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doReturn;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.reactive.function.client.ClientHttpConnectorAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.payment.account.Beneficiary;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.account.InternalBeneficiary;
import uk.co.ybs.digital.payment.config.ServiceToServiceConfig;
import uk.co.ybs.digital.payment.exception.BeneficiaryServiceException;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.security.requestsigning.RequestSigningAutoConfiguration;

@SpringBootTest(
    classes = {
      BeneficiaryService.class,
      ServiceToServiceConfig.class,
      RequestSigningAutoConfiguration.class,
      ClientHttpConnectorAutoConfiguration
          .class // Required by the WebClient bean defined in AccountServiceConfig
    },
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class BeneficiaryServiceTest {

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Beneficiary service returned error status: ";

  private static final String PARTY_ID = "9876543210";
  private static final String ACCOUNT_NUMBER = "0123456789";
  private static final String ACCOUNT_NUMBER_NON_PADDED = "12345678";
  private static final String BENEFICIARY_ID = "123abc";
  private static final String APPLICATION_JSON = "application/json";
  private static final String HEADER_CONTENT_TYPE = "Content-Type";
  private static final String UNEXPECTED_HTTP_STATUSES_AND_BODY_SOURCE =
      "unexpectedHttpStatusesAndBodies";
  private static final String HTTP_GET = "GET";
  private static final String LOCALHOST_URL = "localhost:";
  private static final String PRIVATE_ACCOUNT_PATH = "/beneficiary/private/accounts/";
  private static final String AUTHORIZATION_BEARER_HEADER_VALUE = "Bearer <jwt>";
  private static final String PAYMENT_SERVICE_NONPROD = "payment-service-nonprod-1";
  private static final String REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  private static final String REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String REQUEST_ID = "x-ybs-request-id";
  @MockBean private ExtractNewBeneficiaryVisitor extractNewBeneficiaryVisitor;

  @Autowired private BeneficiaryService beneficiaryService;

  @Autowired ObjectMapper objectMapper;

  @Value("${uk.co.ybs.digital.beneficiary-test-port}")
  private int beneficiaryTestPort;

  private MockWebServer mockWebServer;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start(beneficiaryTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @ParameterizedTest
  @MethodSource(UNEXPECTED_HTTP_STATUSES_AND_BODY_SOURCE)
  void getBeneficiaryShouldThrowAccountServiceExceptionForUnexpectedHttpStatusAndBody(
      final HttpStatus httpStatus,
      final MediaType mediaType,
      final ClassPathResource bodyResource,
      final Matcher<String> expectedMessage)
      throws IOException {
    final String body = readClassPathResource(bodyResource);
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, mediaType)
            .setBody(body));

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final BeneficiaryServiceException exception =
        assertThrows(
            BeneficiaryServiceException.class,
            () -> beneficiaryService.getBeneficiary(ACCOUNT_NUMBER, BENEFICIARY_ID, metadata));
    assertThat(exception.getClass(), is(equalTo(BeneficiaryServiceException.class)));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(BeneficiaryServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource(UNEXPECTED_HTTP_STATUSES_AND_BODY_SOURCE)
  void
      getBeneficiariesByAccountNumberShouldThrowAccountServiceExceptionForUnexpectedHttpStatusAndBody(
          final HttpStatus httpStatus,
          final MediaType mediaType,
          final ClassPathResource bodyResource,
          final Matcher<String> expectedMessage)
          throws IOException {
    final String body = readClassPathResource(bodyResource);
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, mediaType)
            .setBody(body));

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final BeneficiaryServiceException exception =
        assertThrows(
            BeneficiaryServiceException.class,
            () -> beneficiaryService.getBeneficiariesByAccountNumber(ACCOUNT_NUMBER, metadata));
    assertThat(exception.getClass(), is(equalTo(BeneficiaryServiceException.class)));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(BeneficiaryServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("beneficiaryPayloads")
  void getBeneficiaryShouldReturnBeneficiary(
      final String payloadResource, final Beneficiary expectedBeneficiary)
      throws IOException, InterruptedException {
    final String body = readClassPathResource(payloadResource);
    mockWebServer.enqueue(
        new MockResponse().setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);
    final Beneficiary account =
        beneficiaryService.getBeneficiary(ACCOUNT_NUMBER, BENEFICIARY_ID, metadata);
    assertThat(account, is(expectedBeneficiary));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(equalTo((HTTP_GET))));
    assertThat(
        recordedRequest.getPath(),
        is(equalTo((PRIVATE_ACCOUNT_PATH + ACCOUNT_NUMBER + "/beneficiaries/" + BENEFICIARY_ID))));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_HEADER_VALUE)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + beneficiaryTestPort)));
    assertThat(recordedRequest.getHeader(REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID), is(equalTo(PAYMENT_SERVICE_NONPROD)));
  }

  @ParameterizedTest
  @MethodSource("beneficiaryListPayloads")
  void getBeneficiaryListShouldReturnBeneficiaryList(
      final String payloadResource, final List<Beneficiary> expectedBeneficiaryList)
      throws IOException, InterruptedException {
    final String body = readClassPathResource(payloadResource);
    mockWebServer.enqueue(
        new MockResponse().setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON).setBody(body));

    final UUID requestId = UUID.randomUUID();
    final RequestMetadata metadata = TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);
    final List<Beneficiary> beneficiaries =
        beneficiaryService.getBeneficiariesByAccountNumber(ACCOUNT_NUMBER, metadata);
    assertThat(beneficiaries, is(expectedBeneficiaryList));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(equalTo((HTTP_GET))));
    assertThat(
        recordedRequest.getPath(),
        is(equalTo(("/beneficiary/accounts/" + ACCOUNT_NUMBER + "/beneficiaries"))));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_HEADER_VALUE)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + beneficiaryTestPort)));
    assertThat(recordedRequest.getHeader(REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID), is(equalTo(PAYMENT_SERVICE_NONPROD)));
  }

  @Test
  void saveBeneficiaryShouldCallAccountServiceWithBeneficiary() throws Exception {
    mockWebServer.enqueue(new MockResponse().setResponseCode(202));

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final ExternalPaymentRequest paymentRequest = TestHelper.buildValidExternalPaymentRequest();
    final Beneficiary beneficiary = TestHelper.buildValidExternalBeneficiary(null);

    doReturn(Optional.of(beneficiary)).when(extractNewBeneficiaryVisitor).visit(paymentRequest);

    assertDoesNotThrow(() -> beneficiaryService.saveBeneficiary(paymentRequest, metadata));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(equalTo(("POST"))));
    assertThat(
        recordedRequest.getPath(),
        is(equalTo((PRIVATE_ACCOUNT_PATH + ACCOUNT_NUMBER + "/beneficiaries"))));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_HEADER_VALUE)));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + beneficiaryTestPort)));
    assertThat(
        recordedRequest.getHeader(REQUEST_ID), is(equalTo(metadata.getRequestId().toString())));
    assertThat(recordedRequest.getHeader(REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequest.getHeader(REQUEST_SIGNATURE_KEY_ID), is(equalTo(PAYMENT_SERVICE_NONPROD)));
    assertThat(recordedRequest.getBody(), notNullValue());

    ExternalBeneficiary actual =
        objectMapper.readValue(recordedRequest.getBody().readUtf8(), ExternalBeneficiary.class);

    assertThat(actual, is(equalTo(beneficiary)));
  }

  @Test
  void saveBeneficiaryShouldNotCallAccountServiceWhenNoNewBeneficiaryShouldBeSaved() {
    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final ExternalPaymentRequest paymentRequest = TestHelper.buildValidExternalPaymentRequest();

    doReturn(Optional.empty()).when(extractNewBeneficiaryVisitor).visit(paymentRequest);

    assertDoesNotThrow(() -> beneficiaryService.saveBeneficiary(paymentRequest, metadata));

    assertThat(mockWebServer.getRequestCount(), is(equalTo(0)));
  }

  @ParameterizedTest
  @MethodSource(UNEXPECTED_HTTP_STATUSES_AND_BODY_SOURCE)
  void saveBeneficiaryShouldThrowSaveBeneficiaryExceptionOnError(
      final HttpStatus httpStatus, final MediaType mediaType, final ClassPathResource bodyResource)
      throws IOException {
    final String body = readClassPathResource(bodyResource);
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, mediaType)
            .setBody(body));

    final ExternalPaymentRequest paymentRequest = TestHelper.buildValidExternalPaymentRequest();
    final Beneficiary beneficiary = TestHelper.buildValidExternalBeneficiary();

    doReturn(Optional.of(beneficiary)).when(extractNewBeneficiaryVisitor).visit(paymentRequest);

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final SaveBeneficiaryException exception =
        assertThrows(
            SaveBeneficiaryException.class,
            () -> beneficiaryService.saveBeneficiary(paymentRequest, metadata));

    assertThat(exception.getStatusCode(), equalTo(httpStatus));
    assertThat(exception.getBody(), equalTo(body));
  }

  @ParameterizedTest
  @MethodSource("getBeneficiaryServiceErrors")
  void getBeneficiaryShouldThrowAccountServiceExceptionForInvalidJson(
      final String body, final HttpStatus statusCode, final String expectedErrorMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON)
            .setResponseCode(statusCode.value())
            .setBody(body));

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final BeneficiaryServiceException thrown =
        assertThrows(
            BeneficiaryServiceException.class,
            () -> beneficiaryService.getBeneficiary(ACCOUNT_NUMBER, BENEFICIARY_ID, metadata));

    assertThat(thrown.getMessage(), is(equalTo(expectedErrorMessage)));
  }

  private static Stream<Arguments> getBeneficiaryServiceErrors() throws IOException {
    final String entityDescription =
        "beneficiary " + BENEFICIARY_ID + " for account " + ACCOUNT_NUMBER;
    final String accessDenied =
        readClassPathResource("api/account/ResponseErrorAccessDenied.json"); // NOPMD
    final String notFound = readClassPathResource("api/account/ResponseErrorResourceNotFound.json");
    return Stream.of(
        Arguments.of("abc", HttpStatus.OK, "Error calling beneficiary service"),
        Arguments.of("", HttpStatus.OK, "Empty response calling beneficiary service"),
        Arguments.of(
            accessDenied,
            HttpStatus.FORBIDDEN,
            "Party " + PARTY_ID + " is not allowed access " + entityDescription),
        Arguments.of(notFound, HttpStatus.NOT_FOUND, "Failed to find " + entityDescription));
  }

  @ParameterizedTest
  @MethodSource("getBeneficiariesByAccountNumberServiceErrors")
  void getBeneficiariesByAccountNumberShouldThrowAccountServiceExceptionForInvalidJson(
      final String body, final HttpStatus statusCode, final String expectedErrorMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HEADER_CONTENT_TYPE, APPLICATION_JSON)
            .setResponseCode(statusCode.value())
            .setBody(body));

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final BeneficiaryServiceException thrown =
        assertThrows(
            BeneficiaryServiceException.class,
            () -> beneficiaryService.getBeneficiariesByAccountNumber(ACCOUNT_NUMBER, metadata));

    assertThat(thrown.getMessage(), is(equalTo(expectedErrorMessage)));
  }

  @Test
  void updateExternalBeneficiaryShouldCallAccountServiceWithExternalBeneficiary() throws Exception {
    final String body = readClassPathResource("api/account/beneficiary/ResponseExternal.json");
    mockWebServer.enqueue(
        new MockResponse().setHeader(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON).setBody(body));
    mockWebServer.enqueue(new MockResponse().setResponseCode(202));

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    final ExternalPaymentRequest externalPaymentRequest =
        TestHelper.buildValidExternalPaymentRequestWithBeneficiary("new reference");

    beneficiaryService.updateExternalBeneficiary(externalPaymentRequest, metadata);

    final RecordedRequest recordedRequestGetBeneficiary = mockWebServer.takeRequest();
    verifyGetBeneficiaryRequest(recordedRequestGetBeneficiary, metadata);

    final RecordedRequest recordedRequestUpdateBeneficiary = mockWebServer.takeRequest();
    verifyUpdateBeneficiaryRequest(recordedRequestUpdateBeneficiary, metadata);

    ExternalBeneficiary actualExternalBeneficiary =
        objectMapper.readValue(
            recordedRequestUpdateBeneficiary.getBody().readUtf8(), ExternalBeneficiary.class);

    final ExternalBeneficiary expectedExternalBeneficiary =
        TestHelper.buildValidExternalBeneficiaryWithReference("new reference");

    assertThat(actualExternalBeneficiary, is(equalTo(expectedExternalBeneficiary)));
  }

  private void verifyGetBeneficiaryRequest(
      final RecordedRequest recordedRequestGetBeneficiary, final RequestMetadata metadata) {
    assertThat(recordedRequestGetBeneficiary.getMethod(), is(equalTo(("GET"))));
    assertThat(
        recordedRequestGetBeneficiary.getPath(),
        is(equalTo((PRIVATE_ACCOUNT_PATH + ACCOUNT_NUMBER + "/beneficiaries/" + BENEFICIARY_ID))));
    assertThat(
        recordedRequestGetBeneficiary.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_HEADER_VALUE)));

    assertThat(
        recordedRequestGetBeneficiary.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + beneficiaryTestPort)));
    assertThat(
        recordedRequestGetBeneficiary.getHeader(REQUEST_ID),
        is(equalTo(metadata.getRequestId().toString())));
    assertThat(recordedRequestGetBeneficiary.getHeader(REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequestGetBeneficiary.getHeader(REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_NONPROD)));
    assertThat(recordedRequestGetBeneficiary.getBody(), notNullValue());
  }

  private void verifyUpdateBeneficiaryRequest(
      final RecordedRequest recordedRequestUpdateBeneficiary, final RequestMetadata metadata) {
    assertThat(recordedRequestUpdateBeneficiary.getMethod(), is(equalTo(("PUT"))));
    assertThat(
        recordedRequestUpdateBeneficiary.getPath(),
        is(equalTo((PRIVATE_ACCOUNT_PATH + ACCOUNT_NUMBER + "/beneficiaries"))));
    assertThat(
        recordedRequestUpdateBeneficiary.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_HEADER_VALUE)));

    assertThat(
        recordedRequestUpdateBeneficiary.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + beneficiaryTestPort)));
    assertThat(
        recordedRequestUpdateBeneficiary.getHeader(REQUEST_ID),
        is(equalTo(metadata.getRequestId().toString())));
    assertThat(recordedRequestUpdateBeneficiary.getHeader(REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        recordedRequestUpdateBeneficiary.getHeader(REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_NONPROD)));
    assertThat(recordedRequestUpdateBeneficiary.getBody(), notNullValue());
  }

  @ParameterizedTest
  @MethodSource(UNEXPECTED_HTTP_STATUSES_AND_BODY_SOURCE)
  void updateExternalBeneficiaryShouldThrowUpdateBeneficiaryExceptionOnError(
      final HttpStatus httpStatus, final MediaType mediaType, final ClassPathResource bodyResource)
      throws IOException {

    final String getBeneficiaryResponseBody =
        readClassPathResource("api/account/beneficiary/ResponseExternal.json");
    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON)
            .setBody(getBeneficiaryResponseBody));

    final String updateBeneficiaryErrorResponseBody = readClassPathResource(bodyResource);
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, mediaType)
            .setBody(updateBeneficiaryErrorResponseBody));

    final ExternalPaymentRequest paymentRequest =
        TestHelper.buildValidExternalPaymentRequestWithBeneficiary("new reference");

    final RequestMetadata metadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);

    final UpdateBeneficiaryException exception =
        assertThrows(
            UpdateBeneficiaryException.class,
            () -> beneficiaryService.updateExternalBeneficiary(paymentRequest, metadata));

    assertThat(exception.getStatusCode(), equalTo(httpStatus));
    assertThat(exception.getBody(), equalTo(updateBeneficiaryErrorResponseBody));
  }

  private static Stream<Arguments> getBeneficiariesByAccountNumberServiceErrors()
      throws IOException {
    final String entityDescription = "beneficiaries for account " + ACCOUNT_NUMBER;
    final String accessDenied =
        readClassPathResource("api/account/ResponseErrorAccessDenied.json"); // NOPMD
    final String notFound =
        readClassPathResource("api/account/ResponseErrorResourceNotFound.json"); // NOPMD
    return Stream.of(
        Arguments.of(
            "abc",
            HttpStatus.OK,
            "Error calling beneficiary service get beneficiaries by account number"),
        Arguments.of(
            "",
            HttpStatus.OK,
            "Empty response calling beneficiary service get beneficiaries by account number"),
        Arguments.of(
            accessDenied,
            HttpStatus.FORBIDDEN,
            "Party " + PARTY_ID + " is not allowed access " + entityDescription),
        Arguments.of(notFound, HttpStatus.NOT_FOUND, "Failed to find " + entityDescription));
  }

  private static Stream<Arguments> beneficiaryPayloads() {
    return Stream.of(
        Arguments.of(
            "api/account/beneficiary/ResponseExternal.json",
            ExternalBeneficiary.builder()
                .name("Mr Joe Bloggs")
                .accountNumber(ACCOUNT_NUMBER_NON_PADDED)
                .accountSortCode("112233")
                .reference("ELECTRIC BILL")
                .beneficiaryId("124abc")
                .memorableName("Joint Account")
                .build()),
        Arguments.of(
            "api/account/beneficiary/ResponseInternal.json",
            InternalBeneficiary.builder()
                .beneficiaryId("123abc")
                .accountNumber(ACCOUNT_NUMBER_NON_PADDED)
                .build()));
  }

  private static Stream<Arguments> beneficiaryListPayloads() {
    return Stream.of(
        Arguments.of(
            "api/account/beneficiary/ResponseBeneficiaryList.json",
            Arrays.asList(
                ExternalBeneficiary.builder()
                    .name("Mr Joe Bloggs")
                    .accountNumber(ACCOUNT_NUMBER_NON_PADDED)
                    .accountSortCode("112233")
                    .reference("ELECTRIC BILL")
                    .beneficiaryId("124abc")
                    .memorableName("Joint Account")
                    .build(),
                InternalBeneficiary.builder()
                    .beneficiaryId("123abc")
                    .accountNumber(ACCOUNT_NUMBER_NON_PADDED)
                    .build())));
  }

  private static String readClassPathResource(final ClassPathResource classPathResource)
      throws IOException {
    return new String(
        Files.readAllBytes(classPathResource.getFile().toPath()), StandardCharsets.UTF_8);
  }

  private static String readClassPathResource(final String classPathResource) throws IOException {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals", "PMD.UnusedPrivateMethod"})
  private static Stream<Arguments> unexpectedHttpStatusesAndBodies() {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDeniedWithAdditional.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied"),
                containsString("ErrorCodeOther"))),
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorResourceNotFound.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("Resource.NotFound"))),
        Arguments.of(
            HttpStatus.NOT_FOUND,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorResourceNotFoundWithAdditional.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "404"),
                containsString("Resource.NotFound"),
                containsString("ErrorCodeOther"))),
        Arguments.of(
            HttpStatus.NOT_FOUND,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDenied.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "404"),
                containsString("AccessDenied"))),
        Arguments.of(
            HttpStatus.INTERNAL_SERVER_ERROR,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/account/ResponseErrorAccessDenied.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "500"),
                containsString("AccessDenied"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/UnexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/EmptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            new ClassPathResource("api/audit/response/TextResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            new ClassPathResource("api/audit/response/TextResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")));
  }
}
