package uk.co.ybs.digital.payment.service.sca;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.jwt.Jwt;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.account.AccountSummary;
import uk.co.ybs.digital.payment.account.Beneficiary;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.account.GroupedAccountListResponse;
import uk.co.ybs.digital.payment.audit.AuditPaymentAccountLockedRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentAuthFailureRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentAuthSuccessRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentDecisionRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentFailureRequest;
import uk.co.ybs.digital.payment.audit.AuditService;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails.ExternalPaymentCreditorDetails;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails.ExternalPaymentDebtor;
import uk.co.ybs.digital.payment.audit.LinkInternalPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkPaymentRequest;
import uk.co.ybs.digital.payment.audit.SimplePaymentDetails;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.ExemptReasonCode;
import uk.co.ybs.digital.payment.audit.sca.Sca;
import uk.co.ybs.digital.payment.beneficiary.BeneficiaryService;
import uk.co.ybs.digital.payment.beneficiary.ExtractNewBeneficiaryVisitor;
import uk.co.ybs.digital.payment.exception.AuditServiceException;
import uk.co.ybs.digital.payment.exception.ScaRequiredException;
import uk.co.ybs.digital.payment.model.aat.ScaLvtCount;
import uk.co.ybs.digital.payment.repository.aat.LowValRepository;
import uk.co.ybs.digital.payment.service.PaymentServiceProperties;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedPaymentRequest;
import uk.co.ybs.digital.payment.service.sca.event.AuthenticationEvent;
import uk.co.ybs.digital.payment.service.sca.event.AuthenticationEventFactory;
import uk.co.ybs.digital.payment.service.sca.tracking.TrackingCode;
import uk.co.ybs.digital.payment.service.sca.tracking.TrackingCodeGenerator;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.sca.exception.GenerateChallengeException;
import uk.co.ybs.digital.sca.exception.InvalidPasswordCharsScaException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;
import uk.co.ybs.digital.sca.service.ScaCredentials;
import uk.co.ybs.digital.sca.service.ScaPasswordCharsChallengeService;
import uk.co.ybs.digital.sca.service.digitaluser.DigitalUserServiceInvalidPasswordException;

@ExtendWith(MockitoExtension.class)
class ScaManagerTest {
  private static final String TRANSACTION_ID = "transaction-id";
  private static final String IP_ADDRESS = "192.168.1.1";
  private static final String REFERENCE_NO_BENEFICIARY = "ELECTRIC BILL";
  private static final String REFERENCE_BENEFICIARY = "BENEFICIARY REF";
  private static final BigDecimal AMOUNT = new BigDecimal("100.00");
  private static final BigDecimal EXEMPTED_AMOUNT = new BigDecimal("20.00");
  private static final int MAX_LVT_COUNT = 5;

  private static final String DEBTOR_ACCOUNT_NUMBER = "0123456789";
  private static final String DEBTOR_SORT_CODE = "332211";
  private static final String INVALID_PASSWORD_SCA_MESSAGE = "invalid password sca exception";

  private static final String CREDITOR_ACCOUNT_NUMBER_EXTERNAL = "12345678";
  private static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL = "1234567890";
  private static final String CREDITOR_SORT_CODE = "112233";
  private static final String CREDITOR_NAME = "Mr Joe Bloggs";
  private static final String CREDITOR_BENEFICIARY_MEMORABLE_NAME = "Joint Account";
  private static final String SAPP_CHANNEL = "SAPP";
  private static final String WEB_CHANNEL = "WEB";
  private static final String EVENT_CONTEXT = "event-context";
  private static final String PAYMENT_PLAYBACK = "payment-playback";
  private static final String TRACKING_CODE = "tracking-code";
  private static final String GBP = "GBP";

  private static final UUID IDEMPOTENCY_KEY = UUID.randomUUID();

  public static final String CLIENT_FAILURE_TYPE = "CLIENT";
  public static final String CHALLENGE_FAILURE_TYPE = "CHALLENGE";
  private static final String MOCK_RESPONSE = "mockResponse";
  private static final String MOCK_CHALLENGE = "mockChallenge";

  private static final Jwt JWT = TestHelper.jwtCustomerWithScope("PAYMENT_READ");

  @Mock private AuditService auditService;
  @Mock private AuthenticationEventFactory authenticationEventFactory;
  @Mock private TrackingCodeGenerator trackingCodeGenerator;
  @Mock private PaymentServiceProperties paymentServiceProperties;
  @Mock private ScaChallengeService scaChallengeService;
  @Mock private LowValRepository lowValRepository;
  @Mock private AccountService accountService;
  @Mock private ExtractNewBeneficiaryVisitor extractNewBeneficiaryVisitor;
  @Mock private BeneficiaryService beneficiaryService;
  @Mock private ScaPasswordCharsChallengeService scaPasswordCharsChallengeService;
  @Captor private ArgumentCaptor<ScaLvtCount> savedScaLvtCount;
  private ScaManager testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject =
        new ScaManager(
            auditService,
            authenticationEventFactory,
            trackingCodeGenerator,
            paymentServiceProperties,
            scaChallengeService,
            scaPasswordCharsChallengeService,
            lowValRepository,
            accountService,
            extractNewBeneficiaryVisitor,
            beneficiaryService);
  }

  @ParameterizedTest(
      name =
          "getExemptionShouldReturnEmptyAndAuditPaymentDecisionForNonExemptPaymentRequest {index}")
  @MethodSource("nonExemptRequests")
  @SuppressWarnings("PMD.ExcessiveParameterList")
  void getExemptionShouldReturnEmptyAndAuditPaymentDecisionForNonExemptPaymentRequest(
      final ValidatedPaymentRequest paymentRequest,
      final PaymentRequest scaPaymentRequest,
      final String channel,
      final Boolean exemptionsEnabled,
      final Optional<Beneficiary> saveBeneficiary,
      final Boolean isOwnedAccount,
      final Integer scaUserLvtCount,
      final BigDecimal amount) {
    final RequestMetadata requestMetadata = buildValidRequestMetadata(channel);
    final boolean isInternalRequest = scaPaymentRequest instanceof InternalPaymentRequest;

    if (WEB_CHANNEL.equals(channel)) {
      when(paymentServiceProperties.isScaExemptionsEnabled()).thenReturn(exemptionsEnabled);

      if (exemptionsEnabled) {

        if (!isOwnedAccount && isInternalRequest) {
          when(accountService.getAccountGroup((requestMetadata)))
              .thenReturn(GroupedAccountListResponse.builder().build());
        }

        if (!isInternalRequest) {
          when(extractNewBeneficiaryVisitor.visit((ExternalPaymentRequest) scaPaymentRequest))
              .thenReturn(saveBeneficiary);
        }
        if (isInternalRequest) {
          when(extractNewBeneficiaryVisitor.visit((InternalPaymentRequest) scaPaymentRequest))
              .thenReturn(saveBeneficiary);
        }

        when(paymentServiceProperties.getMaxLvtCount()).thenReturn(MAX_LVT_COUNT);
        when(paymentServiceProperties.getMaxLvtAmount()).thenReturn(new BigDecimal(30));

        if (!saveBeneficiary.isPresent() && amount.compareTo(new BigDecimal(30)) <= 0) {
          Long partyId = Long.parseLong(requestMetadata.getPartyId());
          if (scaUserLvtCount != null) {
            when(lowValRepository.findById(partyId)).thenReturn(buildScaLvtCount(scaUserLvtCount));
          } else {
            when(lowValRepository.findById(partyId)).thenReturn(Optional.empty());
          }
        }
      }
    }

    final Optional<ScaExemption> exemptionCode =
        testSubject.getExemption(paymentRequest, requestMetadata, scaPaymentRequest);

    assertThat(exemptionCode.isPresent(), is(false));

    final AuditPaymentDecisionRequest expectedAuditRequest =
        AuditPaymentDecisionRequest.builder()
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                SimplePaymentDetails.builder()
                    .uniqueReference(IDEMPOTENCY_KEY)
                    .sca(Sca.builder().decisionStatus(DecisionStatus.APPLIED).build())
                    .build())
            .build();
    verify(auditService).auditPaymentDecision(expectedAuditRequest, requestMetadata);
  }

  @ParameterizedTest(
      name = "getExemptionShouldAuditPaymentDecisionForExemptInternalPaymentRequest {index}")
  @MethodSource("exemptedInternalPayments")
  void getExemptionShouldAuditPaymentDecisionForExemptInternalPaymentRequest(
      final BigDecimal exemptedAmount,
      final Integer scaUserLvtCount,
      final ExemptReasonCode exemptReasonCode) {
    final InternalPaymentRequest internalPaymentRequest = buildInternalPaymentRequest();
    final ValidatedInternalPaymentRequest paymentRequest =
        buildValidatedInternalPaymentRequest(exemptedAmount);
    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);
    when(paymentServiceProperties.isScaExemptionsEnabled()).thenReturn(true);
    when(paymentServiceProperties.getMaxLvtCount()).thenReturn(MAX_LVT_COUNT);
    when(paymentServiceProperties.getMaxLvtAmount()).thenReturn(new BigDecimal(30));

    if (exemptReasonCode.equals(ExemptReasonCode.TRBENF)) {
      List<Beneficiary> beneficiaryList =
          Collections.singletonList(
              ExternalBeneficiary.builder()
                  .accountNumber(paymentRequest.getCreditorAccount().getAccountNumber())
                  .build());
      when(beneficiaryService.getBeneficiariesByAccountNumber(
              paymentRequest.getDebtorAccount().getAccountNumber(), requestMetadata))
          .thenReturn(beneficiaryList);
    }

    if (exemptReasonCode.equals(ExemptReasonCode.OACTRN)) {
      when(beneficiaryService.getBeneficiariesByAccountNumber(
              paymentRequest.getDebtorAccount().getAccountNumber(), requestMetadata))
          .thenReturn(Collections.emptyList());

      when(accountService.getAccountGroup(requestMetadata)).thenReturn(buildValidAccountGroup());
    }

    if (exemptReasonCode.equals(ExemptReasonCode.LOWVAL)) {
      when(beneficiaryService.getBeneficiariesByAccountNumber(
              paymentRequest.getDebtorAccount().getAccountNumber(), requestMetadata))
          .thenReturn(Collections.emptyList());

      when(accountService.getAccountGroup(requestMetadata))
          .thenReturn(GroupedAccountListResponse.builder().build());

      Long partyId = Long.parseLong(requestMetadata.getPartyId());
      Optional<ScaLvtCount> scaLvtCount = buildScaLvtCount(scaUserLvtCount);
      when(lowValRepository.findById(partyId)).thenReturn(scaLvtCount);
    }

    final UUID eventId = UUID.randomUUID();
    final AuthenticationEvent authenticationEvent =
        AuthenticationEvent.builder()
            .id(eventId)
            .eventContext(EVENT_CONTEXT)
            .paymentPlayback(PAYMENT_PLAYBACK)
            .build();

    when(authenticationEventFactory.createAuthenticationEvent(
            eq(paymentRequest), eq(WEB_CHANNEL), eq(DecisionStatus.EXEMPTED), eq(exemptReasonCode)))
        .thenReturn(authenticationEvent);

    final String code = TRACKING_CODE;
    final TrackingCode trackingCode = TrackingCode.builder().id(eventId).code(code).build();
    when(trackingCodeGenerator.generateTrackingCode(authenticationEvent)).thenReturn(trackingCode);

    Optional<ScaExemption> expectedScaExemption =
        Optional.of(
            ScaExemption.builder()
                .trackingCode(trackingCode)
                .exemptReasonCode(exemptReasonCode)
                .build());

    final Optional<ScaExemption> actualExemption =
        testSubject.getExemption(paymentRequest, requestMetadata, internalPaymentRequest);

    assertThat(actualExemption, is(expectedScaExemption));

    Sca scaExemptAudit =
        Sca.builder()
            .decisionStatus(DecisionStatus.EXEMPTED)
            .exemptReasonCode(exemptReasonCode)
            .build();

    final AuditPaymentDecisionRequest expectedAuditRequest =
        AuditPaymentDecisionRequest.builder()
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                SimplePaymentDetails.builder()
                    .uniqueReference(IDEMPOTENCY_KEY)
                    .sca(scaExemptAudit)
                    .build())
            .build();
    verify(auditService).auditPaymentDecision(expectedAuditRequest, requestMetadata);
  }

  @ParameterizedTest(
      name = "getExemptionShouldAuditPaymentDecisionForExemptExternalPaymentRequest {index}")
  @MethodSource("exemptedExternalPayments")
  public void getExemptionShouldAuditPaymentDecisionForExemptExternalPaymentRequest(
      final BigDecimal exemptedAmount,
      final Boolean isTrustedBeneficiary,
      final Integer scaUserLvtCount,
      final ExemptReasonCode exemptReasonCode) {

    ExternalPaymentRequest externalPaymentRequest = buildExternalPaymentRequest();
    if (isTrustedBeneficiary) {
      externalPaymentRequest = buildExternalPaymentRequestForTrustedBeneficiary();
    }

    final ValidatedExternalPaymentRequest paymentRequest =
        buildValidatedExternalPaymentRequest(exemptedAmount);
    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);
    when(paymentServiceProperties.isScaExemptionsEnabled()).thenReturn(true);
    when(paymentServiceProperties.getMaxLvtCount()).thenReturn(MAX_LVT_COUNT);
    when(paymentServiceProperties.getMaxLvtAmount()).thenReturn(new BigDecimal(30));

    if (exemptReasonCode.equals(ExemptReasonCode.LOWVAL)) {
      Long partyId = Long.parseLong(requestMetadata.getPartyId());
      Optional<ScaLvtCount> scaLvtCount = buildScaLvtCount(scaUserLvtCount);
      when(lowValRepository.findById(partyId)).thenReturn(scaLvtCount);
    }

    final UUID eventId = UUID.randomUUID();
    final AuthenticationEvent authenticationEvent =
        AuthenticationEvent.builder()
            .id(eventId)
            .eventContext(EVENT_CONTEXT)
            .paymentPlayback(PAYMENT_PLAYBACK)
            .build();

    when(authenticationEventFactory.createAuthenticationEvent(
            eq(paymentRequest), eq(WEB_CHANNEL), eq(DecisionStatus.EXEMPTED), eq(exemptReasonCode)))
        .thenReturn(authenticationEvent);

    final String code = TRACKING_CODE;
    final TrackingCode trackingCode = TrackingCode.builder().id(eventId).code(code).build();
    when(trackingCodeGenerator.generateTrackingCode(authenticationEvent)).thenReturn(trackingCode);

    Optional<ScaExemption> expectedScaExemption =
        Optional.of(
            ScaExemption.builder()
                .trackingCode(trackingCode)
                .exemptReasonCode(exemptReasonCode)
                .build());

    final Optional<ScaExemption> actualExemption =
        testSubject.getExemption(paymentRequest, requestMetadata, externalPaymentRequest);

    assertThat(actualExemption, is(expectedScaExemption));

    Sca exemptScaAudit =
        Sca.builder()
            .decisionStatus(DecisionStatus.EXEMPTED)
            .exemptReasonCode(exemptReasonCode)
            .build();

    final AuditPaymentDecisionRequest expectedAuditRequest =
        AuditPaymentDecisionRequest.builder()
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                SimplePaymentDetails.builder()
                    .uniqueReference(IDEMPOTENCY_KEY)
                    .sca(exemptScaAudit)
                    .build())
            .build();
    verify(auditService).auditPaymentDecision(expectedAuditRequest, requestMetadata);
  }

  private ExternalPaymentRequest buildExternalPaymentRequestForTrustedBeneficiary() {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(GBP)
        .amount(AMOUNT)
        .reference(REFERENCE_NO_BENEFICIARY)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(ExternalCreditorBeneficiary.builder().beneficiaryId("12345").build())
        .build();
  }

  @Test
  void generateAuthenticationCodeShouldGenerateTrackingCodeAndAuditPaymentAuthForExternalPayment() {
    final ValidatedExternalPaymentRequest paymentRequest =
        buildValidatedExternalPaymentRequest(AMOUNT);
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);

    final UUID eventId = UUID.randomUUID();
    final AuthenticationEvent authenticationEvent =
        AuthenticationEvent.builder()
            .id(eventId)
            .eventContext(EVENT_CONTEXT)
            .paymentPlayback(PAYMENT_PLAYBACK)
            .build();
    when(authenticationEventFactory.createAuthenticationEvent(eq(paymentRequest), eq(SAPP_CHANNEL)))
        .thenReturn(authenticationEvent);

    final String code = TRACKING_CODE;
    final TrackingCode trackingCode = TrackingCode.builder().id(eventId).code(code).build();
    when(trackingCodeGenerator.generateTrackingCode(authenticationEvent)).thenReturn(trackingCode);

    final TrackingCode actual =
        testSubject.generateAuthenticationCode(paymentRequest, requestMetadata);
    assertThat(actual, is(trackingCode));

    final AuditPaymentAuthSuccessRequest expectedAuditRequest =
        AuditPaymentAuthSuccessRequest.builder()
            .trackingId(eventId)
            .trackingCode(code)
            .ipAddress(IP_ADDRESS)
            .paymentDetails(SimplePaymentDetails.builder().uniqueReference(IDEMPOTENCY_KEY).build())
            .build();
    verify(auditService).auditPaymentAuthenticationSuccess(expectedAuditRequest, requestMetadata);
  }

  @Test
  void generateAuthenticationCodeShouldGenerateTrackingCodeAndAuditPaymentAuthForInternalPayment() {
    final ValidatedInternalPaymentRequest paymentRequest =
        buildValidatedInternalPaymentRequest(AMOUNT);
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);

    final UUID eventId = UUID.randomUUID();
    final AuthenticationEvent authenticationEvent =
        AuthenticationEvent.builder()
            .id(eventId)
            .eventContext(EVENT_CONTEXT)
            .paymentPlayback(PAYMENT_PLAYBACK)
            .build();
    when(authenticationEventFactory.createAuthenticationEvent(eq(paymentRequest), eq(SAPP_CHANNEL)))
        .thenReturn(authenticationEvent);

    final String code = TRACKING_CODE;
    final TrackingCode trackingCode = TrackingCode.builder().id(eventId).code(code).build();
    when(trackingCodeGenerator.generateTrackingCode(authenticationEvent)).thenReturn(trackingCode);

    final TrackingCode actual =
        testSubject.generateAuthenticationCode(paymentRequest, requestMetadata);
    assertThat(actual, is(trackingCode));

    final AuditPaymentAuthSuccessRequest expectedAuditRequest =
        AuditPaymentAuthSuccessRequest.builder()
            .trackingId(eventId)
            .trackingCode(code)
            .ipAddress(IP_ADDRESS)
            .paymentDetails(SimplePaymentDetails.builder().uniqueReference(IDEMPOTENCY_KEY).build())
            .build();
    verify(auditService).auditPaymentAuthenticationSuccess(expectedAuditRequest, requestMetadata);
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void linkPaymentShouldAuditLinkForExternalPayment(final boolean forBeneficiary) {
    final ValidatedExternalPaymentRequest paymentRequest =
        forBeneficiary
            ? buildValidatedExternalPaymentRequestForBeneficiary(AMOUNT)
            : buildValidatedExternalPaymentRequest(AMOUNT);
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);

    final UUID eventId = UUID.randomUUID();
    final String code = TRACKING_CODE;
    final TrackingCode trackingCode = TrackingCode.builder().id(eventId).code(code).build();

    testSubject.linkPayment(TRANSACTION_ID, paymentRequest, trackingCode, requestMetadata, null);

    final LinkPaymentRequest expectedAuditRequest =
        LinkPaymentRequest.builder()
            .trackingId(eventId)
            .trackingCode(code)
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                LinkExternalPaymentDetails.builder()
                    .uniqueReference(IDEMPOTENCY_KEY)
                    .transactionId(TRANSACTION_ID)
                    .amount(AMOUNT)
                    .reference(forBeneficiary ? REFERENCE_BENEFICIARY : REFERENCE_NO_BENEFICIARY)
                    .debtor(
                        ExternalPaymentDebtor.builder()
                            .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                            .sortCode(DEBTOR_SORT_CODE)
                            .build())
                    .creditorDetails(
                        ExternalPaymentCreditorDetails.builder()
                            .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
                            .sortCode(CREDITOR_SORT_CODE)
                            .name(CREDITOR_NAME)
                            .beneficiary(
                                forBeneficiary
                                    ? ExternalPaymentCreditorDetails
                                        .ExternalCreditorBeneficiaryDetails.builder()
                                        .memorableName(CREDITOR_BENEFICIARY_MEMORABLE_NAME)
                                        .build()
                                    : null)
                            .build())
                    .build())
            .build();
    verify(auditService).linkPayment(expectedAuditRequest, requestMetadata);
  }

  @Test
  void linkPaymentShouldAuditLinkForInternalPayment() {
    final ValidatedInternalPaymentRequest paymentRequest =
        buildValidatedInternalPaymentRequest(AMOUNT);
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);

    final UUID eventId = UUID.randomUUID();
    final String code = TRACKING_CODE;
    final TrackingCode trackingCode = TrackingCode.builder().id(eventId).code(code).build();

    testSubject.linkPayment(TRANSACTION_ID, paymentRequest, trackingCode, requestMetadata, null);

    final LinkPaymentRequest expectedAuditRequest =
        LinkPaymentRequest.builder()
            .trackingId(eventId)
            .trackingCode(code)
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                LinkInternalPaymentDetails.builder()
                    .uniqueReference(IDEMPOTENCY_KEY)
                    .transactionId(TRANSACTION_ID)
                    .amount(AMOUNT)
                    .debtor(
                        LinkInternalPaymentDetails.InternalPaymentAccountDetails.builder()
                            .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                            .build())
                    .creditorDetails(
                        LinkInternalPaymentDetails.InternalPaymentAccountDetails.builder()
                            .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
                            .build())
                    .build())
            .build();
    verify(auditService).linkPayment(expectedAuditRequest, requestMetadata);
  }

  @Test
  void linkPaymentShouldCatchAuditExceptionFromAuditPaymentLinkAndContinue() {
    final ValidatedExternalPaymentRequest paymentRequest =
        buildValidatedExternalPaymentRequest(AMOUNT);
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);
    final TrackingCode trackingCode = generateTrackingCode();

    doThrow(new AuditServiceException("Failed to write audit record"))
        .when(auditService)
        .linkPayment(any(), any());

    testSubject.linkPayment(TRANSACTION_ID, paymentRequest, trackingCode, requestMetadata, null);

    verify(auditService).linkPayment(any(), any());
  }

  @ParameterizedTest(name = "handleInvalidScaShouldAuditAccountLockedFailure: {0}")
  @MethodSource("paymentRequests") // NOPMD
  void handleWebInvalidAuditAccountLockedFailure(final PaymentRequest paymentRequest) {

    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);
    final int passwordAttemptsRemaining = 0;
    final DigitalUserServiceInvalidPasswordException cause =
        new DigitalUserServiceInvalidPasswordException(
            "InvalidPassword", passwordAttemptsRemaining);

    final String scaPasswordCharsChallengeResponse = MOCK_RESPONSE;

    doThrow(
            new InvalidPasswordCharsScaException(
                INVALID_PASSWORD_SCA_MESSAGE, cause, passwordAttemptsRemaining))
        .when(scaPasswordCharsChallengeService)
        .validateChallenge(
            requestMetadata.getRequestId().toString(),
            requestMetadata.getBrandCode(),
            JWT,
            scaPasswordCharsChallengeResponse);

    final InvalidPasswordCharsScaException exception =
        assertThrows(
            InvalidPasswordCharsScaException.class,
            () ->
                testSubject.validatePaymentPasswordCharsSca(
                    paymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT));

    assertThat(exception.getMessage(), is(INVALID_PASSWORD_SCA_MESSAGE));
    assertThat(exception.getCause(), is(cause));
    assertThat(exception.getPasswordAttemptsRemaining(), is(passwordAttemptsRemaining));

    PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();

    AuditPaymentAccountLockedRequest auditPaymentAccountLockedFailureRequest =
        TestHelper.buildAuditPaymentAccountLockedFailureRequest(
            paymentChallengePayloadBody, requestMetadata);
    verify(auditService)
        .auditPaymentWithScaAccountLockedFailure(
            auditPaymentAccountLockedFailureRequest, requestMetadata);
  }

  @ParameterizedTest(name = "handleInvalidScaShouldAuditAuthenticationFailure: {0}")
  @MethodSource("paymentRequests") // NOPMD
  void handleInvalidScaShouldAuditAuthenticationFailure(final PaymentRequest paymentRequest) {
    final PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);

    testSubject.handleInvalidSca(paymentChallengePayloadBody, requestMetadata);

    final AuditPaymentAuthFailureRequest auditAuthFailureRequest =
        AuditPaymentAuthFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                    .uniqueReference(IDEMPOTENCY_KEY)
                    .failureType(CHALLENGE_FAILURE_TYPE)
                    .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                    .build())
            .build();
    verify(auditService)
        .auditPaymentAuthenticationFailure(auditAuthFailureRequest, requestMetadata);
  }

  @Test
  void auditPaymentAuthFailureShouldAuditAuthenticationFailure() {
    final PaymentFailureRequest paymentFailureRequest = buildPaymentFailureRequest();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);
    testSubject.auditPaymentAuthFailure(paymentFailureRequest, requestMetadata);

    final AuditPaymentAuthFailureRequest auditAuthFailureRequest =
        AuditPaymentAuthFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                    .uniqueReference(IDEMPOTENCY_KEY)
                    .failureType(CLIENT_FAILURE_TYPE)
                    .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                    .build())
            .build();
    verify(auditService)
        .auditPaymentAuthenticationFailure(auditAuthFailureRequest, requestMetadata);
  }

  @Test
  void auditPaymentFailureShouldAuditPaymentFailure() {
    final ValidatedExternalPaymentRequest paymentRequest =
        buildValidatedExternalPaymentRequest(AMOUNT);
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);
    final TrackingCode trackingCode = generateTrackingCode();
    testSubject.auditPaymentFailure(paymentRequest, trackingCode, requestMetadata, null);

    final AuditPaymentFailureRequest auditPaymentFailureRequest =
        AuditPaymentFailureRequest.builder()
            .trackingCode(trackingCode.getCode())
            .trackingId(trackingCode.getId())
            .ipAddress(IP_ADDRESS)
            .paymentDetails(SimplePaymentDetails.builder().uniqueReference(IDEMPOTENCY_KEY).build())
            .build();

    verify(auditService).auditPaymentFailure(auditPaymentFailureRequest, requestMetadata);
  }

  @Test
  void auditPaymentFailureShouldAuditAccountLockedFailure() {

    final InternalPaymentRequest paymentRequest = buildInternalPaymentRequest(AMOUNT);
    final PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);
    final Integer passwordsRemaining = 0;
    testSubject.handleInvalidPasswordCharsSca(
        paymentChallengePayloadBody, requestMetadata, passwordsRemaining);
    AuditPaymentAccountLockedRequest auditPaymentAccountLockedFailureRequest =
        TestHelper.buildAuditPaymentAccountLockedFailureRequest(
            paymentChallengePayloadBody, requestMetadata);

    verify(auditService)
        .auditPaymentWithScaAccountLockedFailure(
            auditPaymentAccountLockedFailureRequest, requestMetadata);
  }

  @ParameterizedTest(name = "shouldGenerateScaChallengeForAppRequest: {0}")
  @MethodSource("paymentRequests") // NOPMD
  void shouldGenerateScaChallengeForAppRequest(final PaymentRequest paymentRequest) {

    final PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);
    when(scaChallengeService.generateChallenge(
            paymentChallengePayloadBody, requestMetadata.getSessionId(), Duration.ofSeconds(60)))
        .thenReturn(MOCK_CHALLENGE);

    ScaRequiredException exception =
        testSubject.generateScaRequiredException(paymentRequest, requestMetadata, JWT);

    assertThat(exception.getChallenge(), is(MOCK_CHALLENGE));
    assertThat(
        exception.getMessage(),
        is("Please sign the value in x-ybs-sca-challenge header with the request"));
    verify(scaChallengeService)
        .generateChallenge(
            paymentChallengePayloadBody, requestMetadata.getSessionId(), Duration.ofSeconds(60));
    verifyNoInteractions(scaPasswordCharsChallengeService);
  }

  @ParameterizedTest(name = "shouldGenerateScaPasswordCharsChallengeForWebRequest: {0}")
  @MethodSource("paymentRequests")
  void shouldGenerateScaPasswordCharsChallengeForWebRequest(final PaymentRequest paymentRequest) {

    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);
    when(scaPasswordCharsChallengeService.generateChallenge(
            requestMetadata.getRequestId().toString(), requestMetadata.getBrandCode(), JWT))
        .thenReturn(MOCK_CHALLENGE);

    ScaRequiredException exception =
        testSubject.generateScaRequiredException(paymentRequest, requestMetadata, JWT);

    assertThat(exception.getChallenge(), is(MOCK_CHALLENGE));
    assertThat(
        exception.getMessage(),
        is(
            "Please send the encrypted password characters in the x-ybs-sca-challenge-response header"));
    verify(scaPasswordCharsChallengeService)
        .generateChallenge(
            requestMetadata.getRequestId().toString(), requestMetadata.getBrandCode(), JWT);
    verifyNoInteractions(scaChallengeService);
  }

  @ParameterizedTest(name = "shouldRethrowExceptionFromGenerateChallenge: {0}")
  @MethodSource("paymentRequests") // NOPMD
  void shouldRethrowExceptionFromGenerateChallenge(final PaymentRequest paymentRequest) {

    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);

    doThrow(new GenerateChallengeException("Generate sca exception"))
        .when(scaPasswordCharsChallengeService)
        .generateChallenge(
            requestMetadata.getRequestId().toString(), requestMetadata.getBrandCode(), JWT);

    final GenerateChallengeException exception =
        assertThrows(
            GenerateChallengeException.class,
            () -> testSubject.generateScaRequiredException(paymentRequest, requestMetadata, JWT));

    assertThat(exception.getMessage(), is("Generate sca exception"));
  }

  @ParameterizedTest(name = "validatePaymentScaAppTest: {0}")
  @MethodSource("paymentRequests")
  void validatePaymentScaAppTest(final PaymentRequest paymentRequest) {

    final PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();

    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);

    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, "mockPemKey");

    testSubject.validatePaymentSca(paymentRequest, requestMetadata, scaCredentials);

    verify(scaChallengeService)
        .validateChallenge(
            scaCredentials,
            paymentChallengePayloadBody,
            PaymentChallengePayloadBody.class,
            requestMetadata.getSessionId());
    verifyNoInteractions(scaPasswordCharsChallengeService);
  }

  @ParameterizedTest(name = "validatePaymentScaWebTest: {0}")
  @MethodSource("paymentRequests") // NOPMD
  void validatePaymentScaWebTest(final PaymentRequest paymentRequest) {

    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);
    final String scaPasswordCharsChallengeResponse = MOCK_RESPONSE;

    testSubject.validatePaymentPasswordCharsSca(
        paymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT);

    verify(scaPasswordCharsChallengeService)
        .validateChallenge(
            requestMetadata.getRequestId().toString(),
            requestMetadata.getBrandCode(),
            JWT,
            scaPasswordCharsChallengeResponse);
    verifyNoInteractions(scaChallengeService);
  }

  @ParameterizedTest(name = "validatePaymentScaInvalidScaExceptionAppTest: {0}")
  @MethodSource("paymentRequests")
  void validatePaymentScaInvalidScaExceptionAppTest(final PaymentRequest paymentRequest) {

    final PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();

    final RequestMetadata requestMetadata = buildValidRequestMetadata(SAPP_CHANNEL);

    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, "mockPemKey");

    final AuditPaymentAuthFailureRequest expectedAuditPaymentAuthFailureRequest =
        AuditPaymentAuthFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .paymentDetails(
                AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                    .failureType(CHALLENGE_FAILURE_TYPE)
                    .uniqueReference(paymentRequest.getIdempotencyKey())
                    .debtorAccountNumber(paymentRequest.getDebtor().getAccountNumber())
                    .build())
            .build();

    doThrow(new InvalidScaException("invalid sca exception"))
        .when(scaChallengeService)
        .validateChallenge(
            scaCredentials,
            paymentChallengePayloadBody,
            PaymentChallengePayloadBody.class,
            requestMetadata.getSessionId());

    final InvalidScaException exception =
        assertThrows(
            InvalidScaException.class,
            () -> testSubject.validatePaymentSca(paymentRequest, requestMetadata, scaCredentials));

    assertThat(exception.getMessage(), is("invalid sca exception"));

    verify(auditService)
        .auditPaymentAuthenticationFailure(expectedAuditPaymentAuthFailureRequest, requestMetadata);
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void getExemptionShouldReturnCorrectLowValCountAndUpdateAccessedFlagIfRequired(
      final boolean accessedFlag) {
    final ValidatedExternalPaymentRequest validatedPaymentRequest =
        buildValidatedExternalPaymentRequest(BigDecimal.valueOf(20L));
    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);
    final PaymentRequest paymentRequest = buildExternalPaymentRequest();

    when(lowValRepository.findById(Long.parseLong(requestMetadata.getPartyId())))
        .thenReturn(buildScaLvtCount(4, accessedFlag));

    when(paymentServiceProperties.isScaExemptionsEnabled()).thenReturn(true);
    when(paymentServiceProperties.getMaxLvtAmount()).thenReturn(BigDecimal.valueOf(30L));
    when(paymentServiceProperties.getMaxLvtCount()).thenReturn(MAX_LVT_COUNT);

    if (!accessedFlag) {
      when(testSubject.generateAuthenticationCode(
              validatedPaymentRequest,
              requestMetadata,
              DecisionStatus.EXEMPTED,
              ExemptReasonCode.LOWVAL))
          .thenReturn(generateTrackingCode());
    }

    final Optional<ScaExemption> scaExemption =
        testSubject.getExemption(validatedPaymentRequest, requestMetadata, paymentRequest);

    verify(lowValRepository).findById(Long.parseLong(requestMetadata.getPartyId()));

    if (accessedFlag) {
      verifyNoMoreInteractions(lowValRepository);
      assertFalse(scaExemption.isPresent());
    } else {
      verify(lowValRepository).saveAndFlush(savedScaLvtCount.capture());
      assertTrue(savedScaLvtCount.getValue().getAccessedFlag());
      assertTrue(scaExemption.isPresent());
    }
  }

  @ParameterizedTest(name = "validatePaymentScaInvalidScaExceptionWebTest: {0}")
  @MethodSource("paymentRequests") // NOPMD
  void validatePaymentScaInvalidScaExceptionWebTest(final PaymentRequest paymentRequest) {

    final RequestMetadata requestMetadata = buildValidRequestMetadata(WEB_CHANNEL);
    final String scaPasswordCharsChallengeResponse = MOCK_RESPONSE;

    final AuditPaymentAuthFailureRequest expectedAuditPaymentAuthFailureRequest =
        AuditPaymentAuthFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .paymentDetails(
                AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                    .failureType(CHALLENGE_FAILURE_TYPE)
                    .uniqueReference(paymentRequest.getIdempotencyKey())
                    .debtorAccountNumber(paymentRequest.getDebtor().getAccountNumber())
                    .build())
            .build();

    final RuntimeException cause = new RuntimeException();
    final Integer passwordAttemptsRemaining = 2;
    doThrow(
            new InvalidPasswordCharsScaException(
                INVALID_PASSWORD_SCA_MESSAGE, cause, passwordAttemptsRemaining))
        .when(scaPasswordCharsChallengeService)
        .validateChallenge(
            requestMetadata.getRequestId().toString(),
            requestMetadata.getBrandCode(),
            JWT,
            scaPasswordCharsChallengeResponse);

    final InvalidPasswordCharsScaException exception =
        assertThrows(
            InvalidPasswordCharsScaException.class,
            () ->
                testSubject.validatePaymentPasswordCharsSca(
                    paymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT));

    assertThat(exception.getMessage(), is(INVALID_PASSWORD_SCA_MESSAGE));
    assertThat(exception.getCause(), is(cause));
    assertThat(exception.getPasswordAttemptsRemaining(), is(passwordAttemptsRemaining));

    verify(auditService)
        .auditPaymentAuthenticationFailure(expectedAuditPaymentAuthFailureRequest, requestMetadata);
  }

  private RequestMetadata buildValidRequestMetadata(final String channel) {
    return TestHelper.buildValidRequestMetadataWithChannel(
        UUID.randomUUID(), UUID.randomUUID(), "666", IP_ADDRESS, channel);
  }

  private static ExternalPaymentRequest buildExternalPaymentRequest() {
    return buildExternalPaymentRequest(AMOUNT);
  }

  private static ExternalPaymentRequest buildExternalPaymentRequest(final BigDecimal amount) {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(GBP)
        .amount(amount)
        .reference(REFERENCE_NO_BENEFICIARY)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(buildExternalCreditorDetails())
        .build();
  }

  private static InternalPaymentRequest buildInternalPaymentRequest() {
    return buildInternalPaymentRequest(AMOUNT);
  }

  private static InternalPaymentRequest buildInternalPaymentRequest(final BigDecimal amount) {
    return InternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(GBP)
        .amount(amount)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(
            InternalCreditorDetails.builder()
                .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
                .build())
        .build();
  }

  private static ValidatedExternalPaymentRequest buildValidatedExternalPaymentRequest(
      final BigDecimal amount) {
    return validatedExternalPaymentRequestBuilder(amount).build();
  }

  private static Optional<ScaLvtCount> buildScaLvtCount(final Integer scaLvtCount) {
    return buildScaLvtCount(scaLvtCount, false);
  }

  private static Optional<ScaLvtCount> buildScaLvtCount(
      final Integer scaLvtCount, final boolean accessedFlag) {
    if (scaLvtCount == null) {
      return Optional.empty();
    } else {
      return Optional.of(
          ScaLvtCount.builder().lvtCount(scaLvtCount).accessedFlag(accessedFlag).build());
    }
  }

  private ValidatedExternalPaymentRequest buildValidatedExternalPaymentRequestForBeneficiary(
      final BigDecimal amount) {
    return validatedExternalPaymentRequestBuilder(amount)
        .beneficiary(buildExternalBeneficiary())
        .reference(REFERENCE_BENEFICIARY)
        .build();
  }

  private static ValidatedExternalPaymentRequest.ValidatedExternalPaymentRequestBuilder
      validatedExternalPaymentRequestBuilder(final BigDecimal amount) {
    return ValidatedExternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(GBP)
        .amount(amount)
        .reference(REFERENCE_NO_BENEFICIARY)
        .debtorAccount(debtorAccount())
        .creditorDetails(buildExternalCreditorDetails());
  }

  private static Account debtorAccount() {
    return Account.builder()
        .accountNumber(DEBTOR_ACCOUNT_NUMBER)
        .accountSortCode(DEBTOR_SORT_CODE)
        .build();
  }

  private static ExternalCreditorDetails buildExternalCreditorDetails() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .sortCode(CREDITOR_SORT_CODE)
        .name(CREDITOR_NAME)
        .build();
  }

  private static ExternalBeneficiary buildExternalBeneficiary() {
    return ExternalBeneficiary.builder()
        .beneficiaryId("124abc")
        .accountNumber("12345679")
        .accountSortCode("112244")
        .name("MR B TEST")
        .reference("B REF")
        .memorableName(CREDITOR_BENEFICIARY_MEMORABLE_NAME)
        .build();
  }

  private static AccountSummary buildAccountSummary() {
    return AccountSummary.builder()
        .accountName("test")
        .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
        .build();
  }

  private static GroupedAccountListResponse.AccountGroup buildAccountGroup() {
    return (GroupedAccountListResponse.AccountGroup.builder()
        .accounts(Collections.singletonList(buildAccountSummary()))
        .build());
  }

  private static GroupedAccountListResponse buildValidAccountGroup() {
    return GroupedAccountListResponse.builder().owned(buildAccountGroup()).build();
  }

  private static ValidatedInternalPaymentRequest buildValidatedInternalPaymentRequest(
      final BigDecimal amount) {
    return ValidatedInternalPaymentRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .currency(GBP)
        .amount(amount)
        .debtorAccount(debtorAccount())
        .creditorAccount(Account.builder().accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL).build())
        .build();
  }

  private static PaymentFailureRequest buildPaymentFailureRequest() {
    return PaymentFailureRequest.builder()
        .idempotencyKey(IDEMPOTENCY_KEY)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .build();
  }

  private static TrackingCode generateTrackingCode() {
    final UUID eventId = UUID.randomUUID();
    final String code = TRACKING_CODE;
    return TrackingCode.builder().id(eventId).code(code).build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> nonExemptRequests() {
    return Stream.of(
        Arguments.of(
            buildValidatedExternalPaymentRequest(EXEMPTED_AMOUNT),
            buildExternalPaymentRequest(EXEMPTED_AMOUNT),
            SAPP_CHANNEL,
            true,
            Optional.empty(),
            false,
            4,
            EXEMPTED_AMOUNT),
        Arguments.of(
            buildValidatedExternalPaymentRequest(EXEMPTED_AMOUNT),
            buildExternalPaymentRequest(EXEMPTED_AMOUNT),
            WEB_CHANNEL,
            false,
            Optional.empty(),
            false,
            4,
            EXEMPTED_AMOUNT),
        Arguments.of(
            buildValidatedExternalPaymentRequest(EXEMPTED_AMOUNT),
            buildExternalPaymentRequest(EXEMPTED_AMOUNT),
            WEB_CHANNEL,
            true,
            Optional.empty(),
            false,
            5,
            EXEMPTED_AMOUNT),
        Arguments.of(
            buildValidatedExternalPaymentRequest(AMOUNT),
            buildExternalPaymentRequest(AMOUNT),
            WEB_CHANNEL,
            true,
            Optional.empty(),
            false,
            4,
            AMOUNT),
        Arguments.of(
            buildValidatedExternalPaymentRequest(AMOUNT),
            buildExternalPaymentRequest(AMOUNT),
            WEB_CHANNEL,
            true,
            Optional.empty(),
            false,
            6,
            AMOUNT),
        Arguments.of(
            buildValidatedExternalPaymentRequest(AMOUNT),
            buildExternalPaymentRequest(AMOUNT),
            SAPP_CHANNEL,
            false,
            Optional.empty(),
            false,
            6,
            AMOUNT),
        Arguments.of(
            buildValidatedExternalPaymentRequest(new BigDecimal("31.00")),
            buildExternalPaymentRequest(new BigDecimal("31.00")),
            WEB_CHANNEL,
            true,
            Optional.empty(),
            false,
            4,
            new BigDecimal("31.00")),
        Arguments.of(
            buildValidatedExternalPaymentRequest(new BigDecimal("23.00")),
            buildExternalPaymentRequest(new BigDecimal("23.00")),
            WEB_CHANNEL,
            true,
            Optional.of(buildExternalBeneficiary()),
            false,
            4,
            new BigDecimal("23.00")),
        Arguments.of(
            buildValidatedInternalPaymentRequest(EXEMPTED_AMOUNT),
            buildInternalPaymentRequest(EXEMPTED_AMOUNT),
            SAPP_CHANNEL,
            true,
            Optional.empty(),
            true,
            4,
            EXEMPTED_AMOUNT),
        Arguments.of(
            buildValidatedInternalPaymentRequest(EXEMPTED_AMOUNT),
            buildInternalPaymentRequest(EXEMPTED_AMOUNT),
            WEB_CHANNEL,
            true,
            Optional.empty(),
            false,
            5,
            EXEMPTED_AMOUNT),
        Arguments.of(
            buildValidatedInternalPaymentRequest(AMOUNT),
            buildInternalPaymentRequest(AMOUNT),
            WEB_CHANNEL,
            true,
            Optional.empty(),
            false,
            4,
            AMOUNT),
        Arguments.of(
            buildValidatedInternalPaymentRequest(AMOUNT),
            buildInternalPaymentRequest(AMOUNT),
            WEB_CHANNEL,
            true,
            Optional.empty(),
            false,
            6,
            AMOUNT),
        Arguments.of(
            buildValidatedInternalPaymentRequest(EXEMPTED_AMOUNT),
            buildInternalPaymentRequest(EXEMPTED_AMOUNT),
            WEB_CHANNEL,
            false,
            Optional.empty(),
            true,
            4,
            EXEMPTED_AMOUNT),
        Arguments.of(
            buildValidatedInternalPaymentRequest(AMOUNT),
            buildInternalPaymentRequest(AMOUNT),
            WEB_CHANNEL,
            false,
            Optional.empty(),
            true,
            4,
            AMOUNT),
        Arguments.of(
            buildValidatedInternalPaymentRequest(AMOUNT),
            buildInternalPaymentRequest(AMOUNT),
            SAPP_CHANNEL,
            false,
            Optional.empty(),
            false,
            6,
            AMOUNT),
        Arguments.of(
            buildValidatedInternalPaymentRequest(new BigDecimal("31.00")),
            buildInternalPaymentRequest(new BigDecimal("31.00")),
            WEB_CHANNEL,
            true,
            Optional.empty(),
            false,
            4,
            new BigDecimal("31.00")));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> exemptedExternalPayments() {
    return Stream.of(
        Arguments.of(new BigDecimal("0.00"), false, 4, ExemptReasonCode.LOWVAL),
        Arguments.of(new BigDecimal("20.59"), false, 4, ExemptReasonCode.LOWVAL),
        Arguments.of(new BigDecimal("30.00"), false, 4, ExemptReasonCode.LOWVAL),
        Arguments.of(new BigDecimal("30.00"), false, null, ExemptReasonCode.LOWVAL),
        Arguments.of(new BigDecimal("30.99"), true, 6, ExemptReasonCode.TRBENF));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> exemptedInternalPayments() {
    return Stream.of(
        Arguments.of(new BigDecimal("0.00"), 4, ExemptReasonCode.LOWVAL),
        Arguments.of(new BigDecimal("20.59"), 4, ExemptReasonCode.LOWVAL),
        Arguments.of(new BigDecimal("30.00"), 4, ExemptReasonCode.LOWVAL),
        Arguments.of(new BigDecimal("30.00"), null, ExemptReasonCode.LOWVAL),
        Arguments.of(new BigDecimal("30.99"), 6, ExemptReasonCode.TRBENF),
        Arguments.of(new BigDecimal("30.98"), 6, ExemptReasonCode.OACTRN));
  }

  private static Stream<Arguments> paymentRequests() {
    return Stream.of(
        Arguments.of(buildInternalPaymentRequest()), Arguments.of(buildExternalPaymentRequest()));
  }
}
