package uk.co.ybs.digital.payment.service.sca.event;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class PaymentPlaybackJsonTest {

  @Autowired private JacksonTester<PaymentPlayback> jacksonTester;

  @Value("classpath:jsonTest/PaymentPlaybackFullyPopulated.json")
  private Resource fullyPopulated;

  @Value("classpath:jsonTest/PaymentPlaybackWithMissingOptionalProperties.json")
  private Resource withMissingOptionalProperties;

  @Test
  void shouldSerializeFullyPopulated() throws IOException {
    final PaymentPlayback paymentPlayback =
        PaymentPlayback.builder()
            .amount(PaymentPlayback.Amount.builder().amount("123.4").currency("GBP").build())
            .instructionDate(LocalDate.parse("2020-01-07"))
            .payee(
                PaymentPlayback.Payee.builder()
                    .accountNumber("87654321")
                    .sortCode("887766")
                    .build())
            .reference("my reference")
            .source(
                PaymentPlayback.Source.builder()
                    .accountNumber("1234567890")
                    .sortCode("001122")
                    .build())
            .build();

    // NOTE:  The serialized json is used to compute a hash, so it is critical that we prove
    // that the serialized string is identical to what is expected (i.e. including property order
    // and whitespace)
    // This means we cannot use the normal json asserts
    assertThat(jacksonTester.write(paymentPlayback).getJson())
        .isEqualTo(IOUtils.toString(fullyPopulated.getInputStream(), StandardCharsets.UTF_8));
  }

  @Test
  void shouldSerializeWithMissingOptionalProperties() throws IOException {
    final PaymentPlayback paymentPlayback =
        PaymentPlayback.builder()
            .amount(PaymentPlayback.Amount.builder().amount("123.4").currency("GBP").build())
            .instructionDate(LocalDate.parse("2020-01-07"))
            .payee(PaymentPlayback.Payee.builder().accountNumber("87654321").build())
            .source(PaymentPlayback.Source.builder().accountNumber("1234567890").build())
            .build();

    // NOTE:  The serialized json is used to compute a hash, so it is critical that we prove
    // that the serialized string is identical to what is expected (i.e. including property order
    // and whitespace)
    // This means we cannot use the normal json asserts
    assertThat(jacksonTester.write(paymentPlayback).getJson())
        .isEqualTo(
            IOUtils.toString(
                withMissingOptionalProperties.getInputStream(), StandardCharsets.UTF_8));
  }
}
