package uk.co.ybs.digital.payment.web;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;

import lombok.experimental.UtilityClass;
import org.hamcrest.Matcher;
import org.springframework.validation.FieldError;

@UtilityClass
class PaymentRequestValidationTestHelper {

  static Matcher<FieldError> fieldError(final String field, final String defaultMessage) {
    return allOf(
        hasProperty("field", is(field)), hasProperty("defaultMessage", is(defaultMessage)));
  }
}
