package uk.co.ybs.digital.payment.utils;

import com.google.common.collect.Streams;
import java.util.Arrays;
import java.util.List;
import java.util.SortedSet;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

/*
 * For testing we want to create a mock services on random ports.
 * Find a port during startup and store it to the corresponding system property, meaning that the application can
 * continue to initialise in the normal way from the properties.
 */
public class ServiceRandomPortInitializer
    implements ApplicationContextInitializer<ConfigurableApplicationContext> {

  @Override
  public void initialize(final ConfigurableApplicationContext applicationContext) {
    final List<String> properties =
        Arrays.asList(
            "uk.co.ybs.digital.account-test-port=",
            "uk.co.ybs.digital.audit-test-port=",
            "uk.co.ybs.digital.email-test-port=",
            "uk.co.ybs.digital.authentic.webauth.port=");

    final SortedSet<Integer> availableTcpPorts =
        SocketUtils.findAvailableTcpPorts(properties.size());

    Streams.zip(
            availableTcpPorts.stream(), properties.stream(), (port, property) -> property + port)
        .forEach(
            s -> TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, s));
  }
}
