package uk.co.ybs.digital.payment.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.util.LinkedCaseInsensitiveMap;

class BrandSortCodeMappingsTest {
  private BrandSortCodeMappings testSubject;

  @BeforeEach
  void beforeEach() {
    final LinkedCaseInsensitiveMap<List<String>> mappings = new LinkedCaseInsensitiveMap<>();
    mappings.put("UPPER", Arrays.asList("111111"));
    mappings.put("lower", Arrays.asList("222222"));
    mappings.put("EMPTY", Arrays.asList());
    mappings.put("NULL", null);

    testSubject = new BrandSortCodeMappings(mappings);
  }

  @ParameterizedTest
  @CsvSource({
    "UPPER,111111",
    "upper,111111",
    "LOWER,222222",
    "lower,222222",
  })
  void isSortCodeForBrandShouldReturnTrueWhenSortCodeIsForBrand(
      final String brandCode, final String sortCode) {
    assertThat(testSubject.isSortCodeForBrand(brandCode, sortCode), is(true));
  }

  @ParameterizedTest
  @CsvSource({"UPPER,222222", "LOWER,111111", "EMPTY,111111", "NULL,111111", "UNKNOWN,111111"})
  void isSortCodeForBrandShouldReturnFalseWhenSortCodeIsNotForBrand(
      final String brandCode, final String sortCode) {
    assertThat(testSubject.isSortCodeForBrand(brandCode, sortCode), is(false));
  }
}
