package uk.co.ybs.digital.payment.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.payment.account.AccountDetailsFilter;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNoCustomerRelationshipException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.InternalAccountValidatorException;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;

@ExtendWith(MockitoExtension.class)
public class InternalAccountValidatorTest {
  private static final String PARTY_ID = "9876543210";
  private static final String ACCOUNT_NUMBER = "0123456789";
  private static final String INTERNAL_ACCOUNT_NOT_FOUND =
      "Failed to find internal account: " + ACCOUNT_NUMBER;
  private static final String PARTY_ID_NOT_FOUND = "Missing field: party_id";

  @Mock private AccountService accountService;
  private InternalAccountValidator testSubject;

  @BeforeEach
  void setUp() {
    testSubject = new InternalAccountValidator(accountService);
  }

  @Test
  void checkForAccountNumberShouldSucceedWhenAccountNumberIsFound() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final InternalAccountDetails internalAccountDetails = buildInternalAccountDetails();
    final String accountNumber = internalAccountDetails.getAccountNumber();

    assertDoesNotThrow(
        () -> testSubject.validateInternalAccount(internalAccountDetails, requestMetadata));

    verify(accountService).getAccount(accountNumber, requestMetadata);
  }

  @ParameterizedTest
  @ValueSource(
      classes = {
        AccountServiceEntityNotFoundException.class,
        AccountServiceEntityAccessDeniedException.class
      })
  void shouldThrowAccountValidatorExceptionWhenNoCustomerRelationshipAndAccountNotFound(
      final Class<? extends Throwable> accountServiceException) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final InternalAccountDetails internalAccountDetails = buildInternalAccountDetails();
    final String accountNumber = internalAccountDetails.getAccountNumber();

    when(accountService.getAccount(accountNumber, requestMetadata))
        .thenThrow(AccountServiceEntityNoCustomerRelationshipException.class);
    when(accountService.getAccount(
            accountNumber,
            Collections.singletonList(AccountDetailsFilter.OTHER_ACCOUNT),
            requestMetadata))
        .thenThrow(accountServiceException);

    final InternalAccountValidatorException exception =
        assertThrows(
            InternalAccountValidatorException.class,
            () -> testSubject.validateInternalAccount(internalAccountDetails, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(INTERNAL_ACCOUNT_NOT_FOUND)));
  }

  @ParameterizedTest
  @ValueSource(
      classes = {
        AccountServiceEntityNotFoundException.class,
        AccountServiceEntityAccessDeniedException.class
      })
  void shouldThrowAccountValidatorExceptionWhenAccountNotFound(
      final Class<? extends Throwable> accountServiceException) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final InternalAccountDetails internalAccountDetails = buildInternalAccountDetails();
    final String accountNumber = internalAccountDetails.getAccountNumber();

    when(accountService.getAccount(accountNumber, requestMetadata))
        .thenThrow(accountServiceException);

    final InternalAccountValidatorException exception =
        assertThrows(
            InternalAccountValidatorException.class,
            () -> testSubject.validateInternalAccount(internalAccountDetails, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(INTERNAL_ACCOUNT_NOT_FOUND)));
  }

  @Test
  void shouldCallAccountServiceWithOtherAccountFilterWhenNoCustomerRelationshipIsFound() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final InternalAccountDetails internalAccountDetails = buildInternalAccountDetails();
    final String accountNumber = internalAccountDetails.getAccountNumber();

    when(accountService.getAccount(accountNumber, requestMetadata))
        .thenThrow(AccountServiceEntityNoCustomerRelationshipException.class);

    assertDoesNotThrow(
        () -> testSubject.validateInternalAccount(internalAccountDetails, requestMetadata));

    verify(accountService)
        .getAccount(
            accountNumber,
            Collections.singletonList(AccountDetailsFilter.OTHER_ACCOUNT),
            requestMetadata);
  }

  @Test
  void shouldThrowAccountValidatorExceptionWhenPartyIdIsNull() {
    final RequestMetadata requestMetadata = buildSystemRequestMetadata();
    final InternalAccountDetails internalAccountDetails = buildInternalAccountDetails();
    final String accountNumber = internalAccountDetails.getAccountNumber();

    final InternalAccountValidatorException exception =
        assertThrows(
            InternalAccountValidatorException.class,
            () -> testSubject.validateInternalAccount(internalAccountDetails, requestMetadata));

    assertThat(exception.getMessage(), is(equalTo(PARTY_ID_NOT_FOUND)));

    verify(accountService, never()).getAccount(accountNumber, requestMetadata);
  }

  private RequestMetadata buildRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
  }

  private InternalAccountDetails buildInternalAccountDetails() {
    return TestHelper.buildValidInternalAccountDetails();
  }

  private RequestMetadata buildSystemRequestMetadata() {
    return TestHelper.buildValidSystemRequestMetadata(UUID.randomUUID(), "127.0.0.1");
  }
}
