package uk.co.ybs.digital.payment;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_DEBTOR_ACC;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_MIN_BAL;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_PARTY_SYSID;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_CUST_WARNINGS;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_PAYMENT_ACCHLDR_ROLE;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_PAYMENT_ACC_STATUS;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_VALID_WITCD;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_WEB_ENABLED;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.SOA_PAYACC_WARNINGS;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.sql.SQLException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.hibernate.exception.GenericJDBCException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.WebTestClient.ResponseSpec;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.audit.AuditPaymentAuthFailureRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentAuthSuccessRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentDecisionRequest;
import uk.co.ybs.digital.payment.audit.LinkPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkPaymentRequest;
import uk.co.ybs.digital.payment.audit.SimplePaymentDetails;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.Sca;
import uk.co.ybs.digital.payment.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.payment.model.aat.ScaLvtCount;
import uk.co.ybs.digital.payment.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository;
import uk.co.ybs.digital.payment.repository.adgcore.BankRepository;
import uk.co.ybs.digital.payment.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.payment.utils.SigningUtils;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.sca.service.digitaluser.dto.DigitalUserReverifyChallengeRequest;

@SuppressWarnings({"SameParameterValue", "NewClassNamingConvention"})
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
public class PaymentServiceITBase {
  static final String PRIVATE_BASE_PATH = "/private";
  static final String PAYMENT_PATH = "/payment";
  static final String VALIDATE_PATH = "/validate";
  static final String VALIDATE_PAYEE_PATH = "/validate/payee";
  static final String PRIVATE_VALIDATE_PAYEE_PATH = PRIVATE_BASE_PATH + VALIDATE_PAYEE_PATH;
  static final String PAYMENT_FAILURE_PATH = "/failure";
  static final String ACCOUNT_DETAIL_QUERY_PARAMS = "?include=availableDepositLimit";
  static final String ACCOUNT_DETAIL_OTHER_QUERY_PARAMS =
      "?include=availableDepositLimit,otherAccount";
  static final String CLAIM_SCOPE = "scope";
  static final String CLAIM_CHANNEL = "channel";
  static final String CLAIM_BRAND_CODE = "brand_code";
  static final String CLAIM_AUD = "aud";
  static final String CLAIM_SUB = "sub";
  static final String CLAIM_SUB_TYPE = "sub_type";
  static final String CLAIM_PARTY_ID = "party_id";
  static final String CLAIM_SID = "sid";
  static final String CLAIM_TITLE = "customer_title";
  static final String CLAIM_EMAIL = "customer_email";
  static final String CLAIM_LAST_NAME = "customer_last_name";
  static final String SAPP_CHANNEL = "SAPP";
  static final String WEB_CHANNEL = "WEB";
  static final String BRAND_CODE = "YBS";
  static final String TITLE = "Mr";
  static final String EMAIL = "joe.bloggs@ybs.co.uk";
  static final String SURNAME = "Bloggs";
  static final UUID PAYMENT_IDEMPOTENCY_KEY =
      UUID.fromString("3bf0faa4-223f-11ea-978f-2e728ce88125");
  static final String PARTY_ID = "666";
  static final String SUB = "987654321";
  static final String SUB_TYPE_CUSTOMER = "customer";
  static final String SUB_TYPE_SYSTEM = "system";
  static final String REFERENCE = "ELECTRIC BILL";
  private static final String AMOUNT_AS_STRING = "100.00";
  static final String EXEMPTED_AMOUNT_AS_STRING = "20.00";
  static final BigDecimal EXEMPTED_AMOUNT = new BigDecimal(EXEMPTED_AMOUNT_AS_STRING);
  static final BigDecimal AMOUNT = new BigDecimal(AMOUNT_AS_STRING);
  static final String CURRENCY = "GBP";
  static final String DEBTOR_ACCOUNT_NUMBER = "0123456789";
  static final String DEBTOR_SORT_CODE = "609204";
  static final String CREDITOR_ACCOUNT_NUMBER_EXTERNAL = "12345678";
  static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL = "1234567890";
  static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL_DEPOSIT_LIMIT = "3698521470";
  static final String CREDITOR_SORT_CODE_VALID = "112233";
  static final String CREDITOR_SORT_CODE_YBS = "609204";
  static final String CREDITOR_NAME = "Mr Joe Bloggs";
  static final String CREDITOR_BENEFICIARY_ID = "123abc";
  static final String CREDITOR_BENEFICIARY_MEMORABLE_NAME = "Joint Account";
  static final String TRANSACTION_ID_EXTERNAL = "B000004318";
  static final String TRANSACTION_ID_INTERNAL = "B000004319";
  static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature-key-id";
  static final String HEADER_SCA_KEY = "x-ybs-sca-key";
  static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  static final String REQUIRED_SCOPES = "PAYMENT ACCOUNT_READ";
  static final String ACCOUNT_READ_SCOPE = "ACCOUNT_READ";
  static final String PAYMENT_READ_SCOPE = "PAYMENT_READ";
  static final String OTHER_SCOPE = "OTHER";
  static final String HEADER_SCA_CHALLENGE = "x-ybs-sca-challenge";
  static final String HEADER_SCA_CHALLENGE_RESPONSE = "x-ybs-sca-challenge-response";
  static final String X_FORWARDED_FOR_HEADER = "X-Forwarded-For";
  static final String CLIENT_IP = "12.66.53.145";
  static final String CLIENT_FAILURE_TYPE = "CLIENT";
  static final String CHALLENGE_FAILURE_TYPE = "CHALLENGE";
  static final int SCA_LVT_COUNT_BELOW_THRESHOLD = 2;
  static final String EXPECTED_WEB_PASSWORD_POSITIONS_CHALLENGE = "1,4,7";
  static final String PASSWORD_CHARS_CHALLENGE_RESPONSE =
      "encryptedStringContainingPasswordCharsList";
  static final String SCA_REQUIRED_MESSAGE_SAPP =
      "Please sign the value in x-ybs-sca-challenge header with the request";
  static final String SCA_REQUIRED_MESSAGE_WEB =
      "Please send the encrypted password characters in the x-ybs-sca-challenge-response header";
  static final String AUTHORIZATION_BEARER_VALUE = "Bearer ";
  static final String WITHDRAWAL_COMPLETE_STATUS = "WITHDRAWAL_COMPLETE";
  static final String PAYMENT_SERVICE_KEY_VALUE = "payment-service-nonprod-1";
  static final String HTTP_GET = "GET";
  static final String LOCALHOST_URL = "localhost:";
  static final UUID REQUEST_ID = UUID.randomUUID();
  static final UUID SESSION_ID = UUID.randomUUID();
  @LocalServerPort int port;
  @Autowired public WebTestClient signingWebClientPublic;
  @Autowired WebTestClient signingWebClientPrivate;
  @Autowired WebTestClient nonSigningWebClient;
  @Autowired PrivateKey jwtSigningPrivateKey;

  @Value("${uk.co.ybs.digital.account-test-port}")
  int mockAccountServicePort;

  MockWebServer mockAccountService;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  int mockAuditServicePort;

  MockWebServer mockAuditService;

  @Value("${uk.co.ybs.digital.beneficiary-test-port}")
  int mockBeneficiaryServicePort;

  @Value("${uk.co.ybs.digital.sca.digital-user-service-test-port}")
  int mockDigitalUserServicePort;

  @Value("${uk.co.ybs.digital.authentic.webauth.port}")
  int mockAuthenticWebAuthTestPort;

  MockWebServer mockAuthenticWebAuth;
  MockWebServer mockBeneficiaryService;
  MockWebServer mockDigitalUserService;
  @Autowired ObjectMapper objectMapper;
  @Autowired TransactionTemplate transactionTemplate;
  @Autowired TestEntityManager frontOfficeTestEntityManager;
  @Autowired TestEntityManager aatTestEntityManager;
  @MockBean AccountPaymentDetailsRepository accountPaymentDetailsRepository;
  @MockBean BankRepository bankRepository;
  KeyPair keyPair;

  @BeforeEach
  void setUp() throws Exception {
    mockAccountService = new MockWebServer();
    mockAccountService.start(mockAccountServicePort);

    mockAuditService = new MockWebServer();
    mockAuditService.start(mockAuditServicePort);

    mockBeneficiaryService = new MockWebServer();
    mockBeneficiaryService.start(mockBeneficiaryServicePort);

    mockDigitalUserService = new MockWebServer();
    mockDigitalUserService.start(mockDigitalUserServicePort);

    mockAuthenticWebAuth = new MockWebServer();
    mockAuthenticWebAuth.start(mockAuthenticWebAuthTestPort);

    keyPair = SigningUtils.generateKeyPair();
  }

  @AfterEach
  void tearDown() throws IOException {
    mockAccountService.shutdown();
    mockAuditService.shutdown();
    mockBeneficiaryService.shutdown();
    mockDigitalUserService.shutdown();
    mockAuthenticWebAuth.shutdown();
    tearDownDb();
  }

  private URI getPaymentsURI() {
    return getURI(PAYMENT_PATH);
  }

  public URI getURI(final String path) {
    return URI.create("http://localhost:" + port + PAYMENT_PATH + path);
  }

  private String readClassPathResource(final ClassPathResource classPathResource)
      throws IOException {
    return new String(
        Files.readAllBytes(classPathResource.getFile().toPath()), StandardCharsets.UTF_8);
  }

  public String readClassPathResource(final String classPathResource) throws IOException {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  public static Map<String, Object> claimsMap(final String scope, final String channel) {
    final Map<String, Object> claims = new HashMap<>();
    claims.put(CLAIM_SUB, SUB);
    claims.put(CLAIM_AUD, "DIGITAL_API");
    claims.put(CLAIM_BRAND_CODE, BRAND_CODE);
    claims.put(CLAIM_CHANNEL, channel);
    claims.put(CLAIM_SCOPE, scope);
    claims.put(CLAIM_TITLE, TITLE);
    claims.put(CLAIM_EMAIL, EMAIL);
    claims.put(CLAIM_LAST_NAME, SURNAME);
    claims.put(CLAIM_PARTY_ID, PARTY_ID);
    claims.put(CLAIM_SID, SESSION_ID);
    claims.put(CLAIM_SUB_TYPE, SUB_TYPE_CUSTOMER);
    return claims;
  }

  public static Map<String, Object> claimsMap(final String scope) {
    return claimsMap(scope, SAPP_CHANNEL);
  }

  public static Map<String, Object> systemClaimsMap(final String scope) {
    final Map<String, Object> claims = new HashMap<>();
    claims.put(CLAIM_SUB, SUB);
    claims.put(CLAIM_AUD, "DIGITAL_API");
    claims.put(CLAIM_BRAND_CODE, BRAND_CODE);
    claims.put(CLAIM_SCOPE, scope);
    claims.put(CLAIM_SUB_TYPE, SUB_TYPE_SYSTEM);
    return claims;
  }

  public String buildJwtWithScope(final String scope) {
    return buildJwt(claimsMap(scope));
  }

  public String buildJwt(final Map<String, Object> claims) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .addClaims(claims)
        .signWith(SignatureAlgorithm.RS256, jwtSigningPrivateKey)
        .compact();
  }

  public static ExternalPaymentRequest buildValidExternalPaymentRequestWithCreditorDetails(
      final BigDecimal amount) {
    return buildExternalPaymentRequestWithCreditorDetails(CREDITOR_SORT_CODE_VALID, amount);
  }

  public static ExternalPaymentRequest
      buildValidExternalPaymentRequestWithCreditorDetailsAndSaveBeneficiary(
          final BigDecimal amount) {
    return buildExternalPaymentRequest(
        ExternalCreditorDetails.builder()
            .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
            .sortCode(CREDITOR_SORT_CODE_VALID)
            .name(CREDITOR_NAME)
            .saveBeneficiary(true)
            .memorableName(CREDITOR_BENEFICIARY_MEMORABLE_NAME)
            .build(),
        REFERENCE,
        amount);
  }

  public static ExternalPaymentRequest buildExternalPaymentRequestWithCreditorDetails(
      final String creditorSortCode, final BigDecimal amount) {
    return buildExternalPaymentRequest(
        ExternalCreditorDetails.builder()
            .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
            .sortCode(creditorSortCode)
            .name(CREDITOR_NAME)
            .build(),
        REFERENCE,
        amount);
  }

  public static ExternalPaymentRequest buildValidExternalPaymentRequestWithCreditorBeneficiary(
      final BigDecimal amount) {
    return buildExternalPaymentRequest(
        ExternalCreditorBeneficiary.builder().beneficiaryId(CREDITOR_BENEFICIARY_ID).build(),
        null,
        amount);
  }

  private static ExternalPaymentRequest buildExternalPaymentRequest(
      final ExternalCreditor creditor, final String reference, final BigDecimal amount) {
    return ExternalPaymentRequest.builder()
        .idempotencyKey(PAYMENT_IDEMPOTENCY_KEY)
        .currency(CURRENCY)
        .amount(amount)
        .reference(reference)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(creditor)
        .build();
  }

  public static InternalPaymentRequest buildInternalPaymentRequestWithSaveBeneficiary(
      final String creditorAccountNumber, final BigDecimal amount) {
    return buildInternalPaymentRequest(creditorAccountNumber, amount, true);
  }

  public static InternalPaymentRequest buildInternalPaymentRequest(
      final String creditorAccountNumber, final BigDecimal amount) {
    return buildInternalPaymentRequest(creditorAccountNumber, amount, false);
  }

  private static InternalPaymentRequest buildInternalPaymentRequest(
      final String creditorAccountNumber, final BigDecimal amount, final boolean saveBeneficiary) {
    return InternalPaymentRequest.builder()
        .idempotencyKey(PAYMENT_IDEMPOTENCY_KEY)
        .currency(CURRENCY)
        .amount(amount)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .creditor(
            InternalCreditorDetails.builder()
                .accountNumber(creditorAccountNumber)
                .saveBeneficiary(saveBeneficiary)
                .build())
        .build();
  }

  public String postPaymentRequestForScaChallenge(
      final UUID requestId,
      final PaymentRequest request,
      final String jwt,
      final boolean isWebChannel) {
    final ErrorResponse expectedResponse =
        TestHelper.scaRequired(
            requestId, isWebChannel ? SCA_REQUIRED_MESSAGE_WEB : SCA_REQUIRED_MESSAGE_SAPP);

    final EntityExchangeResult<ErrorResponse> result =
        postPaymentWithoutSca(request, requestId, jwt)
            .expectStatus()
            .isForbidden()
            .expectBody(ErrorResponse.class)
            .isEqualTo(expectedResponse)
            .returnResult();

    return result.getResponseHeaders().getFirst("x-ybs-sca-challenge");
  }

  public ResponseSpec postPaymentWithoutSca(
      final PaymentRequest request, final UUID requestId, final String jwt) {
    return postRequestWithoutSca(PAYMENT_PATH, request, requestId, jwt);
  }

  public ResponseSpec postRequestWithoutSca(
      final String path, final PaymentRequest request, final UUID requestId, final String jwt) {
    return signingWebClientPublic
        .post()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(request)
        .exchange();
  }

  public ResponseSpec postPaymentWithSca(
      final PaymentRequest request,
      final UUID requestId,
      final String jwt,
      final String challenge,
      final String challengeResponse,
      final String encodedPublicKey) {
    return signingWebClientPublic
        .post()
        .uri(getPaymentsURI())
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .bodyValue(request)
        .exchange();
  }

  public ResponseSpec postWebPaymentWithSca(
      final PaymentRequest request,
      final UUID requestId,
      final String jwt,
      final String challengeResponse) {
    return signingWebClientPublic
        .post()
        .uri(getPaymentsURI())
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.AUTHORIZATION, AUTHORIZATION_BEARER_VALUE + jwt)
        .header(X_FORWARDED_FOR_HEADER, CLIENT_IP)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .bodyValue(request)
        .exchange();
  }

  public void stubExternalPaymentRequestForScaChallenge(
      final boolean beneficiary, final boolean isWebChannel) throws IOException {
    if (isWebChannel) {
      stubDigitalUserServiceReAuthChallengeResponse();
    }
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    if (beneficiary) {
      stubFindBeneficiarySuccess();
    }
    stubValidateCreditorDependenciesSuccess();
    stubValidateExternalAccountDependenciesSuccess(
        CREDITOR_SORT_CODE_VALID, CREDITOR_ACCOUNT_NUMBER_EXTERNAL);
    stubAuditSuccess();
  }

  public void verifyExternalPaymentRequestForScaChallenge(
      final boolean beneficiary, final UUID requestId, final String jwt)
      throws InterruptedException, IOException {
    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    if (beneficiary) {
      verifyFindBeneficiary(requestId, jwt);
    }
    verifyAuditDecision(requestId, jwt);
  }

  public void stubInternalPaymentRequestForScaChallenge(final boolean isWebChannel)
      throws IOException {
    if (isWebChannel) {
      stubDigitalUserServiceReAuthChallengeResponse();
    }
    stubFindAccountSuccess(DEBTOR_ACCOUNT_NUMBER);
    stubFindAccountSuccess(CREDITOR_ACCOUNT_NUMBER_INTERNAL);
    stubAuditSuccess();
  }

  public void verifyInternalPaymentRequestForScaChallenge(final UUID requestId, final String jwt)
      throws InterruptedException, IOException {
    verifyFindAccount(DEBTOR_ACCOUNT_NUMBER, requestId, jwt);
    verifyFindAccount(
        CREDITOR_ACCOUNT_NUMBER_INTERNAL, ACCOUNT_DETAIL_QUERY_PARAMS, requestId, jwt);
    verifyAuditDecision(requestId, jwt);
  }

  public void stubFindAccountSuccess(final String accountNumber) throws IOException {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource(
            String.format("api/account/account/ResponseAccountNumber%s.json", accountNumber)));
  }

  public void stubFindAccountSuccessChelsea() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource("api/account/account/ResponseAccountNumberChelsea.json"));
  }

  public void stubSaveBeneficiarySuccess() {
    stubBeneficiaryServiceResponse(HttpStatus.ACCEPTED, "");
  }

  public void stubSaveBeneficiaryFailure(final HttpStatus status, final String body) {
    stubBeneficiaryServiceResponse(status, body);
  }

  public void stubFindBeneficiarySuccess() throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.OK, readClassPathResource("api/account/beneficiary/ResponseExternal.json"));
  }

  public void stubGetBeneficiariesByAccountNumberNoneFound() throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.OK,
        readClassPathResource("api/account/beneficiary/ResponseEmptyBeneficiaryList.json"));
  }

  public void stubGetBeneficiariesByAccountNumberFindsBeneficiaryMatchingCreditor()
      throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.OK,
        readClassPathResource(
            "api/account/beneficiary/ResponseListWithBeneficiaryMatchingCreditor.json"));
  }

  public void stubAccountServiceEntityAccessDenied() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.FORBIDDEN, readClassPathResource("api/account/ResponseErrorAccessDenied.json"));
  }

  public void stubAccountServiceEntityNotFound() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.NOT_FOUND,
        readClassPathResource("api/account/ResponseErrorResourceNotFound.json"));
  }

  public void stubGetOwnedAccountsNoneFound() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource("api/account/account/ResponseAccountGroupNoOwned.json"));
  }

  public void stubGetOwnedAccountsOwnedMatchingCreditorFound() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.OK,
        readClassPathResource(
            "api/account/account/ResponseAccountGroupOwnedMatchingCreditor.json"));
  }

  public void stubAccountServiceEntityNoCustomerRelationshipException() throws IOException {
    stubAccountServiceResponse(
        HttpStatus.FORBIDDEN,
        readClassPathResource("api/account/ResponseErrorAccessDeniedNoCustomerRelationship.json"));
  }

  public void stubBeneficiaryServiceAccessDenied() throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.FORBIDDEN, readClassPathResource("api/account/ResponseErrorAccessDenied.json"));
  }

  public void stubBeneficiaryServiceEntityNotFound() throws IOException {
    stubBeneficiaryServiceResponse(
        HttpStatus.NOT_FOUND,
        readClassPathResource("api/account/ResponseErrorResourceNotFound.json"));
  }

  public void stubAccountServiceResponse(final HttpStatus httpStatus, final String response) {
    mockAccountService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(response));
  }

  public void stubBeneficiaryServiceResponse(final HttpStatus httpStatus, final String response) {
    mockBeneficiaryService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(response));
  }

  public void stubDigitalUserServiceReAuthChallengeResponse() throws IOException {
    mockDigitalUserService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(readClassPathResource("api/digitaluser/ReauthChallengeResponse.json")));
  }

  public void stubDigitalUserServiceReAuthChallengeFailResponse(final int httpStatus) {
    mockDigitalUserService.enqueue(
        new MockResponse()
            .setResponseCode(httpStatus)
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
  }

  public void stubDigitalUserServiceReverifyChallengeResponse() {
    mockDigitalUserService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
  }

  public void stubDigitalUserServiceReverifyChallengeFailResponse(
      final int httpStatus, final String body) {
    if (body == null) {
      mockDigitalUserService.enqueue(
          new MockResponse()
              .setResponseCode(httpStatus)
              .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE));
    } else {
      mockDigitalUserService.enqueue(
          new MockResponse()
              .setResponseCode(httpStatus)
              .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
              .setBody(body));
    }
  }

  public void verifyFindAccount(final String accountNumber, final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockAccountService.takeRequest();
    assertThat(
        accountServiceRequest.getPath(),
        is(equalTo(String.format("/account/private/accounts/%s", accountNumber))));
    verifyFindAccount(accountServiceRequest, requestId, jwt);
  }

  public void verifyFindAccount(
      final String accountNumber, final String queryParams, final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockAccountService.takeRequest();
    assertThat(
        accountServiceRequest.getPath(),
        is(equalTo(String.format("/account/private/accounts/%s%s", accountNumber, queryParams))));
    verifyFindAccount(accountServiceRequest, requestId, jwt);
  }

  private void verifyFindAccount(
      final RecordedRequest accountServiceRequest, final UUID requestId, final String jwt) {
    assertThat(accountServiceRequest.getMethod(), is("GET"));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAccountServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  public void verifyFindGroupedAccounts(final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockAccountService.takeRequest();
    assertThat(accountServiceRequest.getPath(), is("/account/private/accounts/grouped"));
    verifyFindGroupedAccounts(accountServiceRequest, requestId, jwt);
  }

  private void verifyFindGroupedAccounts(
      final RecordedRequest accountServiceRequest, final UUID requestId, final String jwt) {
    assertThat(accountServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAccountServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  public void verifyGetBeneficiariesByAccountNumber(
      final UUID requestId, final String jwt, final String accountNumber)
      throws InterruptedException {
    final RecordedRequest beneficiaryServiceRequest = mockBeneficiaryService.takeRequest();
    assertThat(
        beneficiaryServiceRequest.getPath(),
        is("/beneficiary/accounts/" + accountNumber + "/beneficiaries"));
    verifyGetBeneficiariesByAccountNumber(beneficiaryServiceRequest, requestId, jwt);
  }

  private void verifyGetBeneficiariesByAccountNumber(
      final RecordedRequest beneficiaryServiceRequest, final UUID requestId, final String jwt) {
    assertThat(beneficiaryServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        beneficiaryServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        beneficiaryServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockBeneficiaryServicePort)));
    assertThat(
        beneficiaryServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(beneficiaryServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        beneficiaryServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  public void verifyCalculateWithdrawalInterestPenalty(
      final String accountNumber,
      final BigDecimal withdrawalAmount,
      final UUID requestId,
      final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockAccountService.takeRequest();
    assertThat(accountServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        accountServiceRequest.getPath(),
        is(
            equalTo(
                String.format(
                    "/account/private/accounts/%s/withdrawal-interest-penalty?withdrawalAmount=%s",
                    accountNumber, withdrawalAmount))));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAccountServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  public void verifyFindBeneficiary(final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest accountServiceRequest = mockBeneficiaryService.takeRequest();
    assertThat(accountServiceRequest.getMethod(), is(HTTP_GET));
    assertThat(
        accountServiceRequest.getPath(),
        is(
            equalTo(
                "/beneficiary/private/accounts/"
                    + DEBTOR_ACCOUNT_NUMBER
                    + "/beneficiaries/"
                    + CREDITOR_BENEFICIARY_ID)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockBeneficiaryServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  public void verifySaveBeneficiary(
      final UUID requestId, final String jwt, final ExternalPaymentRequest paymentRequest)
      throws Exception {
    final RecordedRequest accountServiceRequest = mockBeneficiaryService.takeRequest();
    assertThat(accountServiceRequest.getMethod(), is("POST"));
    assertThat(
        accountServiceRequest.getPath(),
        is(equalTo("/beneficiary/private/accounts/" + DEBTOR_ACCOUNT_NUMBER + "/beneficiaries")));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        accountServiceRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockBeneficiaryServicePort)));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        accountServiceRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    assertThat(paymentRequest.getCreditor(), instanceOf(ExternalCreditorDetails.class));
    ExternalCreditorDetails details = ((ExternalCreditorDetails) paymentRequest.getCreditor());
    ExternalBeneficiary expectedBeneficiary =
        ExternalBeneficiary.builder()
            .accountNumber(details.getExternalAccountNumber())
            .accountSortCode(details.getSortCode())
            .name(details.getName())
            .reference(paymentRequest.getReference())
            .memorableName(details.getMemorableName())
            .build();

    assertThat(
        accountServiceRequest.getBody().readUtf8(),
        equalTo(objectMapper.writeValueAsString(expectedBeneficiary)));
  }

  public void verifyDigitalUserServiceReAuthChallengeRequest(final UUID requestId, final String jwt)
      throws InterruptedException {
    final RecordedRequest reAuthRequest = mockDigitalUserService.takeRequest();
    assertThat(reAuthRequest.getMethod(), is(HTTP_GET));
    assertThat(reAuthRequest.getPath(), is(equalTo("/digitaluser/reauth-challenge")));
    assertThat(
        reAuthRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        reAuthRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockDigitalUserServicePort)));
    assertThat(reAuthRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(reAuthRequest.getHeader(HEADER_BRAND_CODE), is(equalTo(BRAND_CODE)));
    assertThat(reAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        reAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  public void verifyDigitalUserServiceReverifyChallengeRequest(
      final UUID requestId, final String jwt, final String challengeResponse)
      throws InterruptedException, IOException {
    final RecordedRequest reAuthRequest = mockDigitalUserService.takeRequest();
    assertThat(reAuthRequest.getMethod(), is("POST"));
    assertThat(reAuthRequest.getPath(), is(equalTo("/digitaluser/reverify-challenge")));
    final DigitalUserReverifyChallengeRequest expectedBody =
        DigitalUserReverifyChallengeRequest.builder().passwordCharacters(challengeResponse).build();
    final DigitalUserReverifyChallengeRequest actualBody =
        objectMapper.readValue(
            reAuthRequest.getBody().readUtf8(), DigitalUserReverifyChallengeRequest.class);
    assertThat(actualBody, is(equalTo(expectedBody)));
    assertThat(
        reAuthRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        reAuthRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockDigitalUserServicePort)));
    assertThat(reAuthRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(reAuthRequest.getHeader(HEADER_BRAND_CODE), is(equalTo(BRAND_CODE)));
    assertThat(reAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        reAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));
  }

  public void stubAuditSuccess() {
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  public void verifyAuditDecision(final UUID requestId, final String jwt)
      throws IOException, InterruptedException {

    verifyAuditDecision(
        requestId, jwt, Sca.builder().decisionStatus(DecisionStatus.APPLIED).build());
  }

  public void verifyAuditDecision(final UUID requestId, final String jwt, final Sca sca)
      throws InterruptedException, IOException {
    final RecordedRequest auditDecisionRequest = mockAuditService.takeRequest();
    assertThat(auditDecisionRequest.getMethod(), is("POST"));
    assertThat(auditDecisionRequest.getPath(), is(equalTo("/audit/payment/decision")));
    assertThat(
        auditDecisionRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditDecisionRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(
        auditDecisionRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditDecisionRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditDecisionRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final AuditPaymentDecisionRequest actualPaymentDecisionRequest =
        objectMapper.readValue(
            auditDecisionRequest.getBody().readUtf8(), AuditPaymentDecisionRequest.class);
    assertThat(actualPaymentDecisionRequest.getIpAddress(), is(CLIENT_IP));
    assertThat(
        actualPaymentDecisionRequest.getPaymentDetails(),
        is(
            SimplePaymentDetails.builder()
                .uniqueReference(PAYMENT_IDEMPOTENCY_KEY)
                .sca(sca)
                .build()));
  }

  public AuditPaymentAuthSuccessRequest verifyAuditAuthenticationSuccess(
      final UUID requestId, final String jwt) throws InterruptedException, JsonProcessingException {
    final RecordedRequest auditAuthRequest = mockAuditService.takeRequest();
    assertThat(auditAuthRequest.getPath(), is(equalTo("/audit/payment/authentication/success")));
    assertThat(
        auditAuthRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditAuthRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(auditAuthRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final AuditPaymentAuthSuccessRequest actualPaymentAuthRequest =
        objectMapper.readValue(
            auditAuthRequest.getBody().readUtf8(), AuditPaymentAuthSuccessRequest.class);
    assertThat(actualPaymentAuthRequest.getTrackingId(), notNullValue());
    assertThat(actualPaymentAuthRequest.getTrackingCode(), notNullValue());
    assertThat(actualPaymentAuthRequest.getIpAddress(), is(CLIENT_IP));
    assertThat(
        actualPaymentAuthRequest.getPaymentDetails(),
        is(SimplePaymentDetails.builder().uniqueReference(PAYMENT_IDEMPOTENCY_KEY).build()));
    return actualPaymentAuthRequest;
  }

  public void verifyAuditLinkPayment(
      final UUID requestId, final String jwt, final LinkPaymentRequest expectedLinkPaymentRequest)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest auditPaymentLinkRequest = mockAuditService.takeRequest();
    assertThat(auditPaymentLinkRequest.getPath(), is(equalTo("/audit/payment/link")));
    assertThat(
        auditPaymentLinkRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditPaymentLinkRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(
        auditPaymentLinkRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditPaymentLinkRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditPaymentLinkRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final LinkPaymentRequest actualPaymentLinkRequest =
        objectMapper.readValue(
            auditPaymentLinkRequest.getBody().readUtf8(), LinkPaymentRequest.class);

    assertThat(actualPaymentLinkRequest, is(expectedLinkPaymentRequest));
  }

  public void verifyAuditLinkPaymentCheck(
      final UUID requestId,
      final String jwt,
      final LinkPaymentDetails expectedLinkPaymentDetails,
      final String expectedIpAddress)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest auditPaymentLinkRequest = mockAuditService.takeRequest();
    assertThat(auditPaymentLinkRequest.getPath(), is(equalTo("/audit/payment/link")));
    assertThat(
        auditPaymentLinkRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditPaymentLinkRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(
        auditPaymentLinkRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditPaymentLinkRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditPaymentLinkRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final LinkPaymentRequest actualPaymentLinkRequest =
        objectMapper.readValue(
            auditPaymentLinkRequest.getBody().readUtf8(), LinkPaymentRequest.class);
    assertThat(actualPaymentLinkRequest.getTrackingCode(), is(notNullValue()));
    assertThat(actualPaymentLinkRequest.getTrackingId(), is(notNullValue()));

    assertThat(actualPaymentLinkRequest.getIpAddress(), is(expectedIpAddress));
    assertThat(actualPaymentLinkRequest.getPaymentDetails(), is(expectedLinkPaymentDetails));
  }

  public void verifyAuditAuthenticationFailure(
      final UUID requestId, final String jwt, final String failureType)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest auditAuthRequest = mockAuditService.takeRequest();
    assertThat(auditAuthRequest.getPath(), is(equalTo("/audit/payment/authentication/failure")));
    assertThat(
        auditAuthRequest.getHeader(HttpHeaders.AUTHORIZATION),
        is(equalTo(AUTHORIZATION_BEARER_VALUE + jwt)));
    assertThat(
        auditAuthRequest.getHeader(HttpHeaders.HOST),
        is(equalTo(LOCALHOST_URL + mockAuditServicePort)));
    assertThat(auditAuthRequest.getHeader(HEADER_REQUEST_ID), is(equalTo(requestId.toString())));
    assertThat(auditAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE), is(notNullValue()));
    assertThat(
        auditAuthRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(PAYMENT_SERVICE_KEY_VALUE)));

    final AuditPaymentAuthFailureRequest actualPaymentFailureAuthRequest =
        objectMapper.readValue(
            auditAuthRequest.getBody().readUtf8(), AuditPaymentAuthFailureRequest.class);
    assertThat(actualPaymentFailureAuthRequest.getIpAddress(), is(CLIENT_IP));
    assertThat(
        actualPaymentFailureAuthRequest.getPaymentDetails(),
        is(
            AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                .uniqueReference(PAYMENT_IDEMPOTENCY_KEY)
                .failureType(failureType)
                .debtorAccountNumber(DEBTOR_ACCOUNT_NUMBER)
                .build()));
  }

  public void stubInitiatePaymentAuthentic(final String response) throws IOException {
    mockAuthenticWebAuth.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(readClassPathResource(response)));
  }

  public ErrorResponse buildBadRequestErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("400 Bad Request")
        .message("Invalid request body")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Field.Missing")
                .message("You must specify a UUID idempotency key")
                .build())
        .build();
  }

  public static PaymentFailureRequest buildPaymentFailureRequest() {
    return PaymentFailureRequest.builder()
        .idempotencyKey(PAYMENT_IDEMPOTENCY_KEY)
        .debtor(Debtor.builder().accountNumber(DEBTOR_ACCOUNT_NUMBER).build())
        .build();
  }

  public static ExternalCreditorDetails buildValidExternalPayeeRequest() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber("12345678")
        .sortCode("112233")
        .build();
  }

  public static InternalAccountDetails buildValidInternalAccountDetails() {
    return InternalAccountDetails.builder().accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL).build();
  }

  public ExternalCreditorDetails buildExternalPayeeWithYBSSortCode() {
    return ExternalCreditorDetails.builder()
        .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
        .sortCode(CREDITOR_SORT_CODE_YBS)
        .build();
  }

  public Matcher<SavingsTransactionLogEntry> logEntryMatching(
      final SavingsTransactionLogEntry expected) {
    return allOf(
        samePropertyValuesAs(expected, "sysId", "dailySequenceNumber", "startTime", "endTime"),
        hasProperty("sysId", notNullValue()),
        hasProperty("dailySequenceNumber", notNullValue()),
        hasProperty("startTime", notNullValue()),
        hasProperty("endTime", notNullValue()));
  }

  public void assertSingleTransactionLogEntry(final Matcher<SavingsTransactionLogEntry> expected) {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              frontOfficeTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from SavingsTransactionLogEntry e");

          @SuppressWarnings("unchecked")
          final List<SavingsTransactionLogEntry> actual = query.getResultList();

          assertThat(actual, contains(expected));
        });
  }

  public void tearDownDb() {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final EntityManager frontOfficeEntityManager =
              frontOfficeTestEntityManager.getEntityManager();
          frontOfficeEntityManager
              .createQuery("delete from SavingsTransactionLogEntry")
              .executeUpdate();
          final EntityManager aaEntityManager = aatTestEntityManager.getEntityManager();
          aaEntityManager.createQuery("delete from ScaLvtCount").executeUpdate();
        });
  }

  public void setupScaLvtCountBelowThreshold() {
    setupScaLvtCount(SCA_LVT_COUNT_BELOW_THRESHOLD);
  }

  public void setupScaLvtCount(final Integer scaLvtCount) {
    setupScaLvtCount(scaLvtCount, false);
  }

  public void setupScaLvtCount(final Integer scaLvtCount, final boolean accessedFlag) {
    transactionTemplate.execute(
        status ->
            aatTestEntityManager.persistAndFlush(
                ScaLvtCount.builder()
                    .partyId(Long.parseLong(PARTY_ID))
                    .lvtCount(scaLvtCount)
                    .createdBy("asmith")
                    .createdDate(LocalDateTime.now())
                    .accessedFlag(accessedFlag)
                    .build()));
  }

  public void stubValidateCreditorDependenciesSuccess() {
    stubGetAccountPaymentDetails(true, true);
  }

  public void stubValidateExternalAccountDependenciesSuccess(
      final String sortCode, final String accountNumber) {

    stubValidateSortCode(sortCode, true);
    stubValidateAccount(sortCode, accountNumber, true);
    stubAcceptsFasterPayments(sortCode, true);
  }

  public void stubGetAccountPaymentDetails(
      final boolean validAccountHolderRole, final boolean validWithdrawalCode) {

    Map<String, Object> getPackageCallOutputParameters =
        new HashMap<String, Object>() {
          {
            put(PN_DEBTOR_ACC, "0123456789");
            put(PN_PARTY_SYSID, "123456");
            put(PN_MIN_BAL, new BigDecimal("100"));
            put(PS_PAYMENT_ACC_STATUS, "Valid");
            put(PS_PAYMENT_ACCHLDR_ROLE, validAccountHolderRole ? "Valid" : "Invalid");
            put(SOA_PAYACC_WARNINGS, new Object[] {});
            put(PS_VALID_WITCD, validWithdrawalCode ? "Valid" : "Invalid");
            put(PS_WEB_ENABLED, "Yes");
            put(PS_CUST_WARNINGS, "No");
          }
        };

    when(accountPaymentDetailsRepository.getAccountDetails(
            eq(Long.parseLong(DEBTOR_ACCOUNT_NUMBER)), eq(Long.parseLong(PARTY_ID))))
        .thenReturn(getPackageCallOutputParameters);
  }

  public void stubValidateSortCode(final String sortCode, final boolean valid) {

    if (valid) {
      Map<String, Object> getBankDetailsPackageCallOutputParameters =
          new HashMap<String, Object>() {
            {
              put("PS_BANK_NAME", "Name");
              put("PS_BRANCH_TITLE", "Title");
              put("PS_BANK_ADD_LINE1", "Line1");
              put("PS_BANK_ADD_LINE2", "Line2");
              put("PS_BANK_ADD_LINE3", "Line3");
              put("PS_BANK_ADD_LINE4", "Line4");
              put("PS_BANK_ADD_LINE5", "Line5");
              put("PS_BANK_POSTCODE", "Postcode");
              put("PS_BANK_TEL_NUM", "Tel Num");
            }
          };

      when(bankRepository.getBankDetails(eq(Long.parseLong(sortCode))))
          .thenReturn(getBankDetailsPackageCallOutputParameters);
      return;
    }

    JpaSystemException ex =
        new JpaSystemException(
            new GenericJDBCException(
                "",
                new SQLException(
                    "ORA-20022: YBS-26779:- Bank Name and Address Details Not Found- (In -   PACKAGE BODY COREOWN.SOA_VALIDATEBANKACCIDENTITY.PR_GET_BANK_DETAILS){}\n"
                        + "ORA-06512: at \"COREOWN.YBS_APPLICATION_ERROR\", line 134\n"
                        + "ORA-06512: at \"COREOWN.SOA_VALIDATEBANKACCIDENTITY\", line 185\n"
                        + "ORA-06512: at line 1",
                    "72000"),
                "sql"));

    when(bankRepository.getBankDetails(Long.parseLong("112233"))).thenThrow(ex);
  }

  public void stubValidateAccount(
      final String sortCode, final String accountNumber, final boolean valid) {

    when(bankRepository.validateBankAccount(
            eq(Long.parseLong(sortCode)), eq(Long.parseLong(accountNumber))))
        .thenReturn(valid ? "Y" : "N");
  }

  public void stubAcceptsFasterPayments(
      final String sortCode, final boolean acceptsFasterPayments) {

    when(bankRepository.acceptsFasterPayments(eq(sortCode)))
        .thenReturn(acceptsFasterPayments ? "Y" : "N");
  }
}
