package uk.co.ybs.digital.payment.audit;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails.ExternalPaymentDebtor;

@JsonTest
class LinkPaymentRequestJsonTest {
  private static final String TRACKING_CODE = "my-tracking-code";
  private static final UUID TRACKING_ID = UUID.fromString("eea9f3ff-c521-42c5-0932-84497301206a");

  private static final String IP_ADDRESS = "12.66.53.145";
  private static final UUID PAYMENT_UTR = UUID.fromString("3bf0faa4-223f-11ea-978f-2e728ce88125");
  private static final String TRANSACTION_ID = "transaction-id";
  private static final BigDecimal AMOUNT = new BigDecimal("123.45");

  private static final String CREDITOR_ACCOUNT_NUMBER_INTERNAL = "0987654321";
  private static final String CREDITOR_ACCOUNT_NUMBER_EXTERNAL = "09876543";

  private static final String DEBTOR_ACCOUNT_NUMBER = "1234567890";

  @Autowired private JacksonTester<LinkPaymentRequest> json;

  @Value("classpath:api/audit/request/LinkExternalPaymentRequest.json")
  private Resource linkExternalPaymentFile;

  @Value("classpath:api/audit/request/LinkInternalPaymentRequest.json")
  private Resource linkInternalPaymentFile;

  private LinkPaymentRequest fullyPopulatedLinkExternalPayment;
  private LinkPaymentRequest fullyPopulatedLinkInternalPayment;

  @BeforeEach
  void beforeEach() {
    fullyPopulatedLinkExternalPayment =
        LinkPaymentRequest.builder()
            .trackingId(TRACKING_ID)
            .trackingCode(TRACKING_CODE)
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                LinkExternalPaymentDetails.builder()
                    .uniqueReference(PAYMENT_UTR)
                    .transactionId(TRANSACTION_ID)
                    .debtor(
                        ExternalPaymentDebtor.builder()
                            .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                            .sortCode("112233")
                            .build())
                    .creditorDetails(
                        LinkExternalPaymentDetails.ExternalPaymentCreditorDetails.builder()
                            .externalAccountNumber(CREDITOR_ACCOUNT_NUMBER_EXTERNAL)
                            .sortCode("332211")
                            .name("creditor name")
                            .beneficiary(
                                LinkExternalPaymentDetails.ExternalPaymentCreditorDetails
                                    .ExternalCreditorBeneficiaryDetails.builder()
                                    .memorableName("memorable name")
                                    .build())
                            .build())
                    .amount(AMOUNT)
                    .reference("reference")
                    .build())
            .build();

    fullyPopulatedLinkInternalPayment =
        LinkPaymentRequest.builder()
            .trackingId(TRACKING_ID)
            .trackingCode(TRACKING_CODE)
            .ipAddress(IP_ADDRESS)
            .paymentDetails(
                LinkInternalPaymentDetails.builder()
                    .uniqueReference(PAYMENT_UTR)
                    .transactionId(TRANSACTION_ID)
                    .debtor(
                        LinkInternalPaymentDetails.InternalPaymentAccountDetails.builder()
                            .accountNumber(DEBTOR_ACCOUNT_NUMBER)
                            .build())
                    .creditorDetails(
                        LinkInternalPaymentDetails.InternalPaymentAccountDetails.builder()
                            .accountNumber(CREDITOR_ACCOUNT_NUMBER_INTERNAL)
                            .build())
                    .amount(AMOUNT)
                    .build())
            .build();
  }

  @Test
  void canSerializeLinkExternalPayment() throws IOException {
    Assertions.assertThat(json.write(fullyPopulatedLinkExternalPayment))
        .isEqualToJson(linkExternalPaymentFile, JSONCompareMode.STRICT);
  }

  @Test
  void canDeserializeLinkExternalPayment() throws IOException {
    Assertions.assertThat(json.read(linkExternalPaymentFile))
        .isEqualTo(fullyPopulatedLinkExternalPayment);
  }

  @Test
  void canSerializeLinkInternalPayment() throws IOException {
    Assertions.assertThat(json.write(fullyPopulatedLinkInternalPayment))
        .isEqualToJson(linkInternalPaymentFile, JSONCompareMode.STRICT);
  }

  @Test
  void canDeserializeLinkInternalPayment() throws IOException {
    Assertions.assertThat(json.read(linkInternalPaymentFile))
        .isEqualTo(fullyPopulatedLinkInternalPayment);
  }
}
