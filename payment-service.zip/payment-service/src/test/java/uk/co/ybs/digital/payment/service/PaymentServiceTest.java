package uk.co.ybs.digital.payment.service;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildPaymentFailureRequest;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidExternalCreditorDetails;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidExternalPaymentRequest;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidInternalAccountDetails;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidInternalPaymentRequest;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidatedExternalPaymentRequest;
import static uk.co.ybs.digital.payment.utils.TestHelper.buildValidatedInternalPaymentRequest;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.jwt.Jwt;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.ExemptReasonCode;
import uk.co.ybs.digital.payment.audit.sca.Sca;
import uk.co.ybs.digital.payment.exception.InitiatePaymentServiceException;
import uk.co.ybs.digital.payment.exception.ScaRequiredException;
import uk.co.ybs.digital.payment.service.authentic.AuthenticServiceException;
import uk.co.ybs.digital.payment.service.sca.ScaExemption;
import uk.co.ybs.digital.payment.service.sca.ScaManager;
import uk.co.ybs.digital.payment.service.sca.tracking.TrackingCode;
import uk.co.ybs.digital.payment.utils.TestHelper;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentWarning;
import uk.co.ybs.digital.payment.web.dto.WarningCategory;
import uk.co.ybs.digital.sca.exception.InvalidPasswordCharsScaException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaCredentials;
import uk.co.ybs.digital.sca.service.digitaluser.DigitalUserServiceInvalidPasswordException;

@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {
  private static final String PARTY_ID = "9876543210";
  private static final String CHALLENGE = "mockChallenge";
  private static final String CHALLENGE_RESPONSE = "mockResponse";
  private static final String CHALLENGE_MESSAGE = "mockChallengeMessage";
  private static final String PUBLIC_KEY = "mockPemKey";
  private static final String TRANSACTION_ID = "transaction-id";
  private static final Instant NOW_AS_INSTANT = Instant.parse("2020-05-14T12:01:02Z");
  private static final LocalDateTime NOW_AS_LOCALDATTIME =
      LocalDateTime.parse("2020-05-14T13:01:02");

  private static final Jwt JWT =
      Jwt.withTokenValue("<jwt>").header("kid", "key-id").claim("party_id", PARTY_ID).build();

  private final Clock clock = Clock.fixed(NOW_AS_INSTANT, ZoneId.of("Europe/London"));

  @Mock private ScaManager scaManager;

  @Mock private AccountValidator accountValidator;

  @Mock private PaymentValidator paymentValidator;

  @Mock private PaymentWarningGenerator paymentWarningGenerator;

  @Mock private PaymentInitiator paymentInitiator;

  @Mock private TransactionLogCreator transactionLogCreator;

  @Mock private InternalAccountValidator internalAccountValidator;

  private PaymentService paymentService;

  private RequestMetadata requestMetadata;
  private TrackingCode trackingCode;
  private Account debtorAccount;

  @BeforeEach
  void setUp() {
    paymentService =
        new PaymentService(
            clock,
            scaManager,
            accountValidator,
            paymentValidator,
            paymentWarningGenerator,
            paymentInitiator,
            transactionLogCreator,
            internalAccountValidator);

    requestMetadata = TestHelper.buildValidRequestMetadata(UUID.randomUUID(), PARTY_ID);
    trackingCode = TrackingCode.builder().id(UUID.randomUUID()).code("tracking-code").build();
    debtorAccount = TestHelper.buildValidAccount();
  }

  @Test
  void validateCreditorShouldSucceedForValidInternalCreditorRequest() {
    final InternalAccountDetails internalAccountDetails = buildValidInternalAccountDetails();

    paymentService.validateCreditor(internalAccountDetails, requestMetadata);

    verify(internalAccountValidator)
        .validateInternalAccount(internalAccountDetails, requestMetadata);
  }

  @Test
  void validateCreditorShouldSucceedForValidExternalCreditorRequest() {
    final ExternalCreditorDetails externalCreditorDetails = buildValidExternalCreditorDetails();

    paymentService.validateCreditor(externalCreditorDetails, requestMetadata);

    verify(paymentValidator).validateExternalCreditor(externalCreditorDetails, requestMetadata);
  }

  @Test
  void reportPaymentFailureShouldSucceedForValidPaymentFailureRequest() {
    final PaymentFailureRequest paymentFailureRequest = buildPaymentFailureRequest();

    when(accountValidator.validateDebtorAccount(paymentFailureRequest.getDebtor(), requestMetadata))
        .thenReturn(debtorAccount);
    paymentService.reportPaymentFailure(paymentFailureRequest, requestMetadata);

    verify(scaManager).auditPaymentAuthFailure(paymentFailureRequest, requestMetadata);
  }

  @Test
  void validatePaymentShouldReturnWarningsForAccounts() {
    final ExternalPaymentRequest externalPaymentRequest = buildValidExternalPaymentRequest();
    final ValidatedExternalPaymentRequest validatedExternalPaymentRequest =
        buildValidatedExternalPaymentRequest(debtorAccount);
    final List<PaymentWarning> expectedPaymentWarnings =
        Collections.singletonList(
            PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA_FLEXIBLE).build());

    when(paymentValidator.validatePayment(externalPaymentRequest, requestMetadata))
        .thenReturn(validatedExternalPaymentRequest);
    when(paymentWarningGenerator.generate(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(expectedPaymentWarnings);

    assertThat(
        paymentService.validate(externalPaymentRequest, requestMetadata),
        equalTo(expectedPaymentWarnings));
  }

  @Test
  void doExternalPaymentWithScaForAppShouldSucceed() {
    final ExternalPaymentRequest externalPaymentRequest = buildValidExternalPaymentRequest();
    final ValidatedExternalPaymentRequest validatedExternalPaymentRequest =
        buildValidatedExternalPaymentRequest(debtorAccount);
    final ScaCredentials scaCredentials =
        new ScaCredentials(CHALLENGE, CHALLENGE_RESPONSE, PUBLIC_KEY);

    when(paymentValidator.validatePayment(externalPaymentRequest, requestMetadata))
        .thenReturn(validatedExternalPaymentRequest);

    final String transactionId = TRANSACTION_ID;
    when(paymentInitiator.initiatePayment(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(transactionId);
    when(scaManager.generateAuthenticationCode(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(trackingCode);

    paymentService.doPaymentWithScaApp(externalPaymentRequest, requestMetadata, scaCredentials);

    verify(scaManager).validatePaymentSca(externalPaymentRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .linkPayment(
            transactionId,
            validatedExternalPaymentRequest,
            trackingCode,
            requestMetadata,
            Sca.builder().decisionStatus(DecisionStatus.APPLIED).build());
    verify(transactionLogCreator)
        .create(
            validatedExternalPaymentRequest,
            NOW_AS_LOCALDATTIME,
            NOW_AS_LOCALDATTIME,
            requestMetadata);
  }

  @Test
  void doExternalPaymentWithScaForWebShouldSucceed() {
    final ExternalPaymentRequest externalPaymentRequest = buildValidExternalPaymentRequest();
    final ValidatedExternalPaymentRequest validatedExternalPaymentRequest =
        buildValidatedExternalPaymentRequest(debtorAccount);
    final String scaPasswordCharsChallengeResponse = "mockPasswordCharsResponse";

    when(paymentValidator.validatePayment(externalPaymentRequest, requestMetadata))
        .thenReturn(validatedExternalPaymentRequest);

    final String transactionId = TRANSACTION_ID;
    when(paymentInitiator.initiatePayment(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(transactionId);
    when(scaManager.generateAuthenticationCode(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(trackingCode);

    paymentService.doPaymentWithScaWeb(
        externalPaymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT);

    verify(scaManager)
        .validatePaymentPasswordCharsSca(
            externalPaymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT);

    verify(scaManager)
        .linkPayment(
            transactionId,
            validatedExternalPaymentRequest,
            trackingCode,
            requestMetadata,
            Sca.builder().decisionStatus(DecisionStatus.APPLIED).build());
    verify(transactionLogCreator)
        .create(
            validatedExternalPaymentRequest,
            NOW_AS_LOCALDATTIME,
            NOW_AS_LOCALDATTIME,
            requestMetadata);
  }

  @Test
  void doExternalPaymentWithoutScaShouldMakePaymentWhenScaExempt() {
    final ExternalPaymentRequest externalPaymentRequest = buildValidExternalPaymentRequest();
    final ValidatedExternalPaymentRequest validatedExternalPaymentRequest =
        buildValidatedExternalPaymentRequest(debtorAccount);
    when(paymentValidator.validatePayment(externalPaymentRequest, requestMetadata))
        .thenReturn(validatedExternalPaymentRequest);

    final ScaExemption exemption =
        ScaExemption.builder()
            .trackingCode(trackingCode)
            .exemptReasonCode(ExemptReasonCode.LOWVAL)
            .build();
    when(scaManager.getExemption(
            validatedExternalPaymentRequest, requestMetadata, externalPaymentRequest))
        .thenReturn(Optional.of(exemption));

    final String transactionId = TRANSACTION_ID;
    when(paymentInitiator.initiatePayment(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(transactionId);

    paymentService.doPaymentWithoutSca(externalPaymentRequest, requestMetadata, JWT);

    verify(scaManager)
        .linkPayment(
            transactionId,
            validatedExternalPaymentRequest,
            trackingCode,
            requestMetadata,
            Sca.builder()
                .decisionStatus(DecisionStatus.EXEMPTED)
                .exemptReasonCode(ExemptReasonCode.LOWVAL)
                .build());
    verify(transactionLogCreator)
        .create(
            validatedExternalPaymentRequest,
            NOW_AS_LOCALDATTIME,
            NOW_AS_LOCALDATTIME,
            requestMetadata);
  }

  @Test
  void doExternalPaymentWithoutScaShouldGenerateScaChallengeWhenNotScaExempt() {
    final ExternalPaymentRequest externalPaymentRequest = buildValidExternalPaymentRequest();
    final ValidatedExternalPaymentRequest validatedExternalPaymentRequest =
        buildValidatedExternalPaymentRequest(debtorAccount);
    when(paymentValidator.validatePayment(externalPaymentRequest, requestMetadata))
        .thenReturn(validatedExternalPaymentRequest);
    when(scaManager.getExemption(
            validatedExternalPaymentRequest, requestMetadata, externalPaymentRequest))
        .thenReturn(Optional.empty());

    when(scaManager.generateScaRequiredException(externalPaymentRequest, requestMetadata, JWT))
        .thenReturn(new ScaRequiredException(CHALLENGE, CHALLENGE_MESSAGE));

    ScaRequiredException scaRequiredException =
        assertThrows(
            ScaRequiredException.class,
            () -> paymentService.doPaymentWithoutSca(externalPaymentRequest, requestMetadata, JWT));
    assertThat(scaRequiredException.getChallenge(), is(CHALLENGE));
    assertThat(scaRequiredException.getMessage(), is(CHALLENGE_MESSAGE));

    verify(paymentInitiator, never())
        .initiatePayment(any(ValidatedExternalPaymentRequest.class), any());
  }

  @Test
  void doInternalPaymentWithScaShouldSucceed() {
    final InternalPaymentRequest internalPaymentRequest = buildValidInternalPaymentRequest();
    final ValidatedInternalPaymentRequest validatedInternalPaymentRequest =
        buildValidatedInternalPaymentRequest(debtorAccount);
    final ScaCredentials scaCredentials =
        new ScaCredentials(CHALLENGE, CHALLENGE_RESPONSE, PUBLIC_KEY);

    when(paymentValidator.validatePayment(internalPaymentRequest, requestMetadata))
        .thenReturn(validatedInternalPaymentRequest);

    final String transactionId = TRANSACTION_ID;
    when(paymentInitiator.initiatePayment(validatedInternalPaymentRequest, requestMetadata))
        .thenReturn(transactionId);
    when(scaManager.generateAuthenticationCode(validatedInternalPaymentRequest, requestMetadata))
        .thenReturn(trackingCode);

    paymentService.doPaymentWithScaApp(internalPaymentRequest, requestMetadata, scaCredentials);

    verify(scaManager).validatePaymentSca(internalPaymentRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .linkPayment(
            transactionId,
            validatedInternalPaymentRequest,
            trackingCode,
            requestMetadata,
            Sca.builder().decisionStatus(DecisionStatus.APPLIED).build());
    verify(transactionLogCreator)
        .create(
            validatedInternalPaymentRequest,
            NOW_AS_LOCALDATTIME,
            NOW_AS_LOCALDATTIME,
            requestMetadata);
  }

  @Test
  void doInternalPaymentWithoutScaShouldMakePaymentWhenScaExempt() {
    final InternalPaymentRequest internalPaymentRequest = buildValidInternalPaymentRequest();
    final ValidatedInternalPaymentRequest validatedInternalPaymentRequest =
        buildValidatedInternalPaymentRequest(debtorAccount);
    when(paymentValidator.validatePayment(internalPaymentRequest, requestMetadata))
        .thenReturn(validatedInternalPaymentRequest);

    final ScaExemption exemption =
        ScaExemption.builder()
            .trackingCode(trackingCode)
            .exemptReasonCode(ExemptReasonCode.LOWVAL)
            .build();

    when(scaManager.getExemption(
            validatedInternalPaymentRequest, requestMetadata, internalPaymentRequest))
        .thenReturn(Optional.of(exemption));

    final String transactionId = TRANSACTION_ID;
    when(paymentInitiator.initiatePayment(validatedInternalPaymentRequest, requestMetadata))
        .thenReturn(transactionId);

    paymentService.doPaymentWithoutSca(internalPaymentRequest, requestMetadata, JWT);

    verify(scaManager)
        .linkPayment(
            transactionId,
            validatedInternalPaymentRequest,
            trackingCode,
            requestMetadata,
            Sca.builder()
                .decisionStatus(DecisionStatus.EXEMPTED)
                .exemptReasonCode(ExemptReasonCode.LOWVAL)
                .build());
    verify(transactionLogCreator)
        .create(
            validatedInternalPaymentRequest,
            NOW_AS_LOCALDATTIME,
            NOW_AS_LOCALDATTIME,
            requestMetadata);
  }

  @Test
  void doInternalPaymentWithoutScaShouldGenerateScaChallengeWhenNotScaExempt() {
    final InternalPaymentRequest internalPaymentRequest = buildValidInternalPaymentRequest();
    final ValidatedInternalPaymentRequest validatedInternalPaymentRequest =
        buildValidatedInternalPaymentRequest(debtorAccount);
    when(paymentValidator.validatePayment(internalPaymentRequest, requestMetadata))
        .thenReturn(validatedInternalPaymentRequest);
    when(scaManager.getExemption(
            validatedInternalPaymentRequest, requestMetadata, internalPaymentRequest))
        .thenReturn(Optional.empty());

    when(scaManager.generateScaRequiredException(internalPaymentRequest, requestMetadata, JWT))
        .thenReturn(new ScaRequiredException(CHALLENGE, CHALLENGE_MESSAGE));

    ScaRequiredException scaRequiredException =
        assertThrows(
            ScaRequiredException.class,
            () -> paymentService.doPaymentWithoutSca(internalPaymentRequest, requestMetadata, JWT));
    assertThat(scaRequiredException.getChallenge(), is(CHALLENGE));
    assertThat(scaRequiredException.getMessage(), is(CHALLENGE_MESSAGE));

    verify(paymentInitiator, never())
        .initiatePayment(any(ValidatedInternalPaymentRequest.class), any());
  }

  @Test
  void doPaymentWithInvalidScaForAppShouldHandleInvalidSca() {
    final PaymentRequest paymentRequest = buildValidExternalPaymentRequest();

    final ScaCredentials scaCredentials =
        new ScaCredentials(CHALLENGE, CHALLENGE_RESPONSE, PUBLIC_KEY);

    doThrow(new InvalidScaException("oops"))
        .when(scaManager)
        .validatePaymentSca(paymentRequest, requestMetadata, scaCredentials);

    assertThrows(
        InvalidScaException.class,
        () -> paymentService.doPaymentWithScaApp(paymentRequest, requestMetadata, scaCredentials));
    verifyNoInteractions(paymentValidator);
  }

  @Test
  void doPaymentWithInvalidScaForWebShouldHandleInvalidSca() {
    final PaymentRequest paymentRequest = buildValidExternalPaymentRequest();

    final String scaPasswordCharsChallengeResponse = "mockPasswordCharsResponse";

    doThrow(new InvalidScaException("oops"))
        .when(scaManager)
        .validatePaymentPasswordCharsSca(
            paymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT);

    assertThrows(
        InvalidScaException.class,
        () ->
            paymentService.doPaymentWithScaWeb(
                paymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT));
    verifyNoInteractions(paymentValidator);
  }

  @Test
  void doPaymentWithInvalidScaForWebShouldHandleInvalidScaPassword() {
    final PaymentRequest paymentRequest = buildValidExternalPaymentRequest();

    final String scaPasswordCharsChallengeResponse = "mockPasswordCharsResponse";

    final Integer passwordAttemptsRemaining = 0;
    final DigitalUserServiceInvalidPasswordException cause =
        new DigitalUserServiceInvalidPasswordException(
            "InvalidPassword", passwordAttemptsRemaining);

    doThrow(
            new InvalidPasswordCharsScaException(
                "invalid password", cause, passwordAttemptsRemaining))
        .when(scaManager)
        .validatePaymentPasswordCharsSca(
            paymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT);

    assertThrows(
        InvalidPasswordCharsScaException.class,
        () ->
            paymentService.doPaymentWithScaWeb(
                paymentRequest, requestMetadata, scaPasswordCharsChallengeResponse, JWT));
    verifyNoInteractions(paymentValidator);
  }

  @Test
  void initiatePaymentServiceExceptionShouldAuditError() {
    final ExternalPaymentRequest externalPaymentRequest = buildValidExternalPaymentRequest();
    final ValidatedExternalPaymentRequest validatedExternalPaymentRequest =
        buildValidatedExternalPaymentRequest(debtorAccount);
    final ScaCredentials scaCredentials =
        new ScaCredentials(CHALLENGE, CHALLENGE_RESPONSE, PUBLIC_KEY);

    when(paymentValidator.validatePayment(externalPaymentRequest, requestMetadata))
        .thenReturn(validatedExternalPaymentRequest);
    when(scaManager.generateAuthenticationCode(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(trackingCode);

    doThrow(new InitiatePaymentServiceException("oops"))
        .when(paymentInitiator)
        .initiatePayment(validatedExternalPaymentRequest, requestMetadata);

    assertThrows(
        InitiatePaymentServiceException.class,
        () ->
            paymentService.doPaymentWithScaApp(
                externalPaymentRequest, requestMetadata, scaCredentials));
    verify(scaManager)
        .auditPaymentFailure(
            validatedExternalPaymentRequest,
            trackingCode,
            requestMetadata,
            Sca.builder().decisionStatus(DecisionStatus.APPLIED).build());
  }

  @Test
  void authenticServiceExceptionShouldAuditError() {
    final ExternalPaymentRequest externalPaymentRequest = buildValidExternalPaymentRequest();
    final ValidatedExternalPaymentRequest validatedExternalPaymentRequest =
        buildValidatedExternalPaymentRequest(debtorAccount);
    final ScaCredentials scaCredentials =
        new ScaCredentials(CHALLENGE, CHALLENGE_RESPONSE, PUBLIC_KEY);

    when(paymentValidator.validatePayment(externalPaymentRequest, requestMetadata))
        .thenReturn(validatedExternalPaymentRequest);
    when(scaManager.generateAuthenticationCode(validatedExternalPaymentRequest, requestMetadata))
        .thenReturn(trackingCode);

    doThrow(new AuthenticServiceException("Authentic service returned empty response"))
        .when(paymentInitiator)
        .initiatePayment(validatedExternalPaymentRequest, requestMetadata);

    assertThrows(
        AuthenticServiceException.class,
        () ->
            paymentService.doPaymentWithScaApp(
                externalPaymentRequest, requestMetadata, scaCredentials));
    verify(scaManager)
        .auditPaymentFailure(
            validatedExternalPaymentRequest,
            trackingCode,
            requestMetadata,
            Sca.builder().decisionStatus(DecisionStatus.APPLIED).build());
  }
}
