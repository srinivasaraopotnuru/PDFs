create table IF NOT EXISTS SCA_LVT_COUNTS
(
  party_id      NUMBER(10) not null,
  lvt_count     NUMBER(2) not null,
  accessed_flag CHAR(1) not null,
  created_by    VARCHAR2(30) not null,
  created_date  DATE not null,
  updated_by    VARCHAR2(30),
  updated_date  DATE,
  CONSTRAINT "SCLVTC_PK" PRIMARY KEY ("PARTY_ID")
);


