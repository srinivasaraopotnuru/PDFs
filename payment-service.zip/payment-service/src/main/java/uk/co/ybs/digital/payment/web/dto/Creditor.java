package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.swagger.v3.oas.annotations.media.DiscriminatorMapping;
import io.swagger.v3.oas.annotations.media.Schema;

@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    property = "type",
    defaultImpl = ExternalCreditorDetails.class)
@JsonSubTypes({@JsonSubTypes.Type(name = "INTERNAL", value = InternalAccountDetails.class)})
@Schema(
    oneOf = {ExternalCreditorDetails.class, InternalAccountDetails.class},
    discriminatorProperty = "type",
    discriminatorMapping = {
      @DiscriminatorMapping(value = "INTERNAL", schema = InternalAccountDetails.class)
    })
public interface Creditor {
  <T> T accept(CreditorVisitor<T> visitor);
}
