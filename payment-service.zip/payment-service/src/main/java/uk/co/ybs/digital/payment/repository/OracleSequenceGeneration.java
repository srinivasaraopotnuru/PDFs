package uk.co.ybs.digital.payment.repository;

import java.util.Objects;
import org.hibernate.tuple.AnnotationValueGeneration;
import org.hibernate.tuple.GenerationTiming;
import org.hibernate.tuple.ValueGenerator;
import uk.co.ybs.digital.payment.model.OracleSequence;

public class OracleSequenceGeneration implements AnnotationValueGeneration<OracleSequence> {
  private static final long serialVersionUID = 1L;

  private static final String NEXTVAL_SUFFIX = ".nextval";

  private transient String function;
  private transient GenerationTiming generationTiming;

  @Override
  public void initialize(final OracleSequence annotation, final Class<?> propertyType) {
    function =
        Objects.requireNonNull(annotation.sequenceName(), "sequence name required")
            + NEXTVAL_SUFFIX;
    generationTiming =
        Objects.requireNonNull(annotation.generationTime(), "generation time required")
            .getEquivalent();
  }

  @Override
  public String getDatabaseGeneratedReferencedColumnValue() {
    return function;
  }

  @Override
  public GenerationTiming getGenerationTiming() {
    return generationTiming;
  }

  @Override
  public ValueGenerator<?> getValueGenerator() {
    // Returns null because value generated on the db
    return null;
  }

  @Override
  public boolean referenceColumnInSql() {
    return true;
  }
}
