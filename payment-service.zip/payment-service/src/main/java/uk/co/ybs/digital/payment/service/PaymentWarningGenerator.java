package uk.co.ybs.digital.payment.service;

import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.account.InterestPenalty;
import uk.co.ybs.digital.payment.account.WithdrawalInterestPenalty;
import uk.co.ybs.digital.payment.web.dto.PaymentWarning;
import uk.co.ybs.digital.payment.web.dto.WarningCategory;

@Component
@RequiredArgsConstructor
public class PaymentWarningGenerator {

  private static final DateTimeFormatter UK_DATE_FORMATTER =
      DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(Locale.UK);

  private final AccountService accountService;

  public List<PaymentWarning> generate(
      final ValidatedPaymentRequest paymentRequest, final RequestMetadata metadata) {
    return Stream.of(
            getIsaWarning(paymentRequest),
            getInterestPenaltyWarning(paymentRequest, metadata),
            getWithdrawalDaysWarning(paymentRequest))
        .filter(Optional::isPresent)
        .map(Optional::get)
        .sorted()
        .collect(Collectors.toList());
  }

  private Optional<PaymentWarning> getIsaWarning(final ValidatedPaymentRequest paymentRequest) {
    final Account debtorAccount = paymentRequest.getDebtorAccount();
    if (debtorAccount.getIsa() == null) {
      return Optional.empty();
    }

    if (debtorAccount.getIsa().isFlexible()) {
      return Optional.of(
          PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA_FLEXIBLE).build());
    } else if (debtorAccount.getIsa().isHelpToBuy()) {
      return Optional.of(
          PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA_HELP_TO_BUY).build());
    } else {
      return Optional.of(
          PaymentWarning.builder().code(WarningCategory.DEBTOR_WITHDRAWAL_ISA).build());
    }
  }

  private Optional<PaymentWarning> getInterestPenaltyWarning(
      final ValidatedPaymentRequest paymentRequest, final RequestMetadata metadata) {
    final Account debtorAccount = paymentRequest.getDebtorAccount();
    final InterestPenalty interestPenalty = debtorAccount.getWithdrawals().getInterestPenalty();
    if (interestPenalty == null) {
      return Optional.empty();
    }

    final WithdrawalInterestPenalty withdrawalInterestPenalty =
        accountService.getWithdrawalInterestPenalty(
            debtorAccount.getAccountNumber(), paymentRequest.getAmount(), metadata);

    return Optional.of(
        PaymentWarning.builder()
            .code(WarningCategory.DEBTOR_WITHDRAWAL_INTEREST_PENALTY)
            .parameters(
                PaymentWarning.Parameters.builder()
                    .days(interestPenalty.getDays())
                    .amount(withdrawalInterestPenalty.getValue())
                    .build())
            .build());
  }

  private Optional<PaymentWarning> getWithdrawalDaysWarning(
      final ValidatedPaymentRequest paymentRequest) {
    return Optional.ofNullable(paymentRequest.getDebtorAccount().getWithdrawals().getLimit())
        .map(
            limits ->
                Optional.ofNullable(limits.getPeriodEnd())
                    .map(
                        periodEnd ->
                            String.format(
                                "You have %s withdrawal days remaining until %s",
                                limits.getAvailable(),
                                UK_DATE_FORMATTER.format(limits.getPeriodEnd())))
                    .orElseGet(
                        () ->
                            String.format(
                                "You have %s withdrawal days remaining", limits.getAvailable())))
        .map(
            message ->
                PaymentWarning.builder()
                    .code(WarningCategory.DEBTOR_WITHDRAWAL_DAYS)
                    .displayMessage(message)
                    .build());
  }
}
