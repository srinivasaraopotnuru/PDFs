package uk.co.ybs.digital.payment.service.sca;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@Component
public class ScaCredentialsExtractor {

  private static final String HEADER_SCA_CHALLENGE = "x-ybs-sca-challenge";
  private static final String HEADER_SCA_CHALLENGE_RESPONSE = "x-ybs-sca-challenge-response";
  private static final String HEADER_SCA_KEY = "x-ybs-sca-key";
  private static final List<String> REQUIRED_HEADERS =
      Collections.unmodifiableList(
          Arrays.asList(HEADER_SCA_CHALLENGE, HEADER_SCA_CHALLENGE_RESPONSE, HEADER_SCA_KEY));

  public Optional<ScaCredentials> extract(final HttpHeaders headers)
      throws InvalidScaHeadersException {
    if (!headers.containsKey(HEADER_SCA_CHALLENGE)
        && !headers.containsKey(HEADER_SCA_CHALLENGE_RESPONSE)) {
      return Optional.empty();
    }

    final List<String> missingHeaders =
        Stream.of(HEADER_SCA_CHALLENGE, HEADER_SCA_CHALLENGE_RESPONSE, HEADER_SCA_KEY)
            .filter(header -> !headers.containsKey(header))
            .collect(Collectors.toList());

    if (!missingHeaders.isEmpty()) {
      throw new InvalidScaHeadersException(
          String.format("Missing headers: %s", missingHeaders), missingHeaders, REQUIRED_HEADERS);
    }

    //noinspection ConstantConditions
    return Optional.of(
        new ScaCredentials(
            headers.getFirst(HEADER_SCA_CHALLENGE),
            headers.getFirst(HEADER_SCA_CHALLENGE_RESPONSE),
            headers.getFirst(HEADER_SCA_KEY)));
  }
}
