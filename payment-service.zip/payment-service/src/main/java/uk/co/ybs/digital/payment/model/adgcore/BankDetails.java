package uk.co.ybs.digital.payment.model.adgcore;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@NamedStoredProcedureQueries({
  @NamedStoredProcedureQuery(
      name = "SOA_VALIDATEBANKACCIDENTITY.PR_GET_BANK_DETAILS",
      procedureName = "SOA_VALIDATEBANKACCIDENTITY.PR_GET_BANK_DETAILS",
      resultClasses = {BankDetails.class},
      parameters = {
        @StoredProcedureParameter(
            name = "PN_SORT_CODE",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_BANK_NAME",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_BRANCH_TITLE",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_BANK_ADD_LINE1",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_BANK_ADD_LINE2",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_BANK_ADD_LINE3",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_BANK_ADD_LINE4",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_BANK_ADD_LINE5",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_BANK_POSTCODE",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_BANK_TEL_NUM",
            type = String.class,
            mode = ParameterMode.OUT)
      })
})
public class BankDetails implements Serializable {

  /** Serial Version number. */
  private static final long serialVersionUID = 1L;

  @Id private String name;
  private String branchTitle;
  private String addressLine1;
  private String addressLine2;
  private String addressLine3;
  private String addressLine4;
  private String addressLine5;
  private String postCode;
  private String telephoneNumber;
}
