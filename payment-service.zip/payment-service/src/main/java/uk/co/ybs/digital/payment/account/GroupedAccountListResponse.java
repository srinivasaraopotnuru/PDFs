package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class GroupedAccountListResponse {
  AccountGroup owned;

  @Value
  @Builder(toBuilder = true)
  @Jacksonized
  public static class AccountGroup {
    @JsonProperty(value = "account")
    @Schema(required = true)
    List<AccountSummary> accounts;
  }
}
