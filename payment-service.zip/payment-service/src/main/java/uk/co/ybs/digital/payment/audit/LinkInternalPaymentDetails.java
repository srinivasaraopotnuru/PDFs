package uk.co.ybs.digital.payment.audit;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.math.BigDecimal;
import java.util.UUID;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;
import uk.co.ybs.digital.payment.audit.sca.Sca;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@JsonDeserialize(builder = LinkInternalPaymentDetails.LinkInternalPaymentDetailsBuilder.class)
public class LinkInternalPaymentDetails extends LinkPaymentDetails {
  @NonNull private final InternalPaymentAccountDetails debtor;
  @NonNull private final InternalPaymentAccountDetails creditorDetails;

  @Builder
  public LinkInternalPaymentDetails(
      final UUID uniqueReference,
      final String transactionId,
      final Sca sca,
      final BigDecimal amount,
      final InternalPaymentAccountDetails debtor,
      final InternalPaymentAccountDetails creditorDetails) {
    super(uniqueReference, transactionId, amount, sca);
    this.debtor = debtor;
    this.creditorDetails = creditorDetails;
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class LinkInternalPaymentDetailsBuilder {}

  @Value
  @Builder
  @JsonDeserialize(
      builder = InternalPaymentAccountDetails.InternalPaymentAccountDetailsBuilder.class)
  public static class InternalPaymentAccountDetails {
    @NonNull private final String accountNumber;

    @JsonPOJOBuilder(withPrefix = "")
    public static class InternalPaymentAccountDetailsBuilder {}
  }
}
