package uk.co.ybs.digital.payment.account;

import lombok.extern.slf4j.Slf4j;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedPaymentRequestVisitor;

@Slf4j
public class IsOwnAccountVisitor implements ValidatedPaymentRequestVisitor<Boolean> {
  private final transient AccountService accountService;
  private final transient RequestMetadata requestMetadata;

  public IsOwnAccountVisitor(
      final RequestMetadata requestMetadata, final AccountService accountService) {
    this.requestMetadata = requestMetadata;
    this.accountService = accountService;
  }

  @Override
  public Boolean visit(final ValidatedExternalPaymentRequest request) {
    return false;
  }

  @Override
  public Boolean visit(final ValidatedInternalPaymentRequest request) {
    try {
      GroupedAccountListResponse groupedAccountListResponse =
          accountService.getAccountGroup(requestMetadata);
      return (groupedAccountListResponse.getOwned().getAccounts().stream()
          .anyMatch(
              accountSummary ->
                  accountSummary
                      .getAccountNumber()
                      .equals(request.getCreditorAccount().getAccountNumber())));

    } catch (Exception e) {
      return false;
    }
  }
}
