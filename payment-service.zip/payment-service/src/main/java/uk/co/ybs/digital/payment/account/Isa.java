package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;
import org.springframework.lang.Nullable;

@Value
@Builder
@JsonDeserialize(builder = Isa.IsaBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Isa {
  boolean flexible;

  @Nullable boolean helpToBuy;

  @JsonPOJOBuilder(withPrefix = "")
  public static class IsaBuilder {}
}
