package uk.co.ybs.digital.payment.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@Import({AdgCoreConfiguration.class, FrontOfficeConfiguration.class, AatConfiguration.class})
public class PersistenceConfiguration {
  public static final String DATASOURCE_PROPERTY_PREFIX = "spring.datasource.";
  public static final String JPA_PROPERTIES_PREFIX = "spring.jpa.";

  public static final String MODEL_PACKAGE_PREFIX = "uk.co.ybs.digital.payment.model.";
  public static final String REPOSITORY_PACKAGE_PREFIX = "uk.co.ybs.digital.payment.repository.";

  @Bean
  public PlatformTransactionManager transactionManager(
      final PlatformTransactionManager adgCoreTransactionManager,
      final PlatformTransactionManager frontOfficeTransactionManager,
      final PlatformTransactionManager aatTransactionManager) {
    return new ChainedTransactionManager(
        adgCoreTransactionManager, frontOfficeTransactionManager, aatTransactionManager);
  }
}
