package uk.co.ybs.digital.payment.service;

import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class UserRequestMetadata {
  @NonNull String channel;
  @NonNull UUID sessionId;
  @NonNull String partyId;
  String title;
  String email;
  String surname;
}
