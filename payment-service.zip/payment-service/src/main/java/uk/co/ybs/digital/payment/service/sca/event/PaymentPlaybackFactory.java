package uk.co.ybs.digital.payment.service.sca.event;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.util.regex.Pattern;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;

@Component
@AllArgsConstructor
public class PaymentPlaybackFactory {
  private static final int PLAYMENT_PAYBACK_MAX_REFERENCE_CHARACTERS = 18;

  private static final Pattern NON_ALPHANUMERIC_CHARACTER = Pattern.compile("[^A-Za-z0-9]");

  @NonNull private final Clock clock;

  public PaymentPlayback createPaymentPlayback(final ValidatedExternalPaymentRequest request) {
    final PaymentPlayback.Payee payee = mapPayee(request.getCreditorDetails());

    final Account debtorAccount = request.getDebtorAccount();

    final PaymentPlayback.Source source =
        PaymentPlayback.Source.builder()
            .accountNumber(debtorAccount.getAccountNumber())
            .sortCode(debtorAccount.getAccountSortCode())
            .build();

    return paymentPlaybackBuilder(request, source, payee)
        .reference(mapReference(request.getReference()))
        .build();
  }

  public PaymentPlayback createPaymentPlayback(final ValidatedInternalPaymentRequest request) {
    final PaymentPlayback.Payee payee = mapPayee(request.getCreditorAccount());

    final PaymentPlayback.Source source =
        PaymentPlayback.Source.builder()
            .accountNumber(request.getDebtorAccount().getAccountNumber())
            .build();

    return paymentPlaybackBuilder(request, source, payee).build();
  }

  private PaymentPlayback.PaymentPlaybackBuilder paymentPlaybackBuilder(
      final ValidatedPaymentRequest request,
      final PaymentPlayback.Source source,
      final PaymentPlayback.Payee payee) {
    // There is a risk that the batch job could use a different date with which to verify this auth
    // code.
    // This is already a risk with the existing ecomm implementation
    final LocalDate instructionDate = LocalDate.now(clock);

    final PaymentPlayback.Amount amount = mapAmount(request);

    return PaymentPlayback.builder()
        .amount(amount)
        .instructionDate(instructionDate)
        .source(source)
        .payee(payee);
  }

  private String mapReference(final String reference) {
    if (reference == null || reference.isEmpty()) {
      return null;
    }

    final String sizeRestricted =
        reference.length() > PLAYMENT_PAYBACK_MAX_REFERENCE_CHARACTERS
            ? reference.substring(0, PLAYMENT_PAYBACK_MAX_REFERENCE_CHARACTERS)
            : reference;

    // Apparently, under some circumstances the payment reference is fed back directly from
    // Authentic which will have stripped all non-alphnumric characters.
    // This means we need to strip non-alphanumerics from the reference before using it.
    final String alphaNumericOnly =
        NON_ALPHANUMERIC_CHARACTER.matcher(sizeRestricted).replaceAll("");

    return alphaNumericOnly;
  }

  private PaymentPlayback.Payee mapPayee(final ExternalCreditorDetails creditorDetails) {
    return PaymentPlayback.Payee.builder()
        .accountNumber(creditorDetails.getExternalAccountNumber())
        .sortCode(creditorDetails.getSortCode())
        .build();
  }

  private PaymentPlayback.Payee mapPayee(final Account creditorDetails) {
    return PaymentPlayback.Payee.builder()
        .accountNumber(creditorDetails.getAccountNumber())
        .build();
  }

  private PaymentPlayback.Amount mapAmount(final ValidatedPaymentRequest request) {
    return PaymentPlayback.Amount.builder()
        .amount(mapAmount(request.getAmountWithExactly2DecimalPlaces()))
        .currency(request.getCurrency())
        .build();
  }

  private String mapAmount(final BigDecimal amount) {
    // This reproduces the logic that the batch process uses to validate the tracking code.
    // The effect is to coerce the amount into a string that has at least one decimal place
    // and only has two decimal places if the value is not a multiple of 0.1
    return String.valueOf(Double.parseDouble(amount.toString()));
  }
}
