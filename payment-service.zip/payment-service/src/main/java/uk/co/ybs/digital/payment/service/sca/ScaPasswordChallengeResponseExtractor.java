package uk.co.ybs.digital.payment.service.sca;

import java.util.Optional;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

@Component
public class ScaPasswordChallengeResponseExtractor {

  private static final String HEADER_SCA_CHALLENGE_RESPONSE = "x-ybs-sca-challenge-response";

  public Optional<String> extractScaPasswordChallengeResponse(final HttpHeaders headers) {
    return Optional.ofNullable(headers.getFirst(HEADER_SCA_CHALLENGE_RESPONSE));
  }
}
