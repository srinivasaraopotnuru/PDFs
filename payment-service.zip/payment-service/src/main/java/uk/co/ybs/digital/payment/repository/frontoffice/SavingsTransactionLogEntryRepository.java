package uk.co.ybs.digital.payment.repository.frontoffice;

import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.payment.model.frontoffice.SavingsTransactionLogEntry;

public interface SavingsTransactionLogEntryRepository
    extends JpaRepository<SavingsTransactionLogEntry, Long> {}
