package uk.co.ybs.digital.payment.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class ScaRequiredException extends RuntimeException {
  private static final long serialVersionUID = -6769180400816844867L;
  private final String challenge;
  private final String message;
}
