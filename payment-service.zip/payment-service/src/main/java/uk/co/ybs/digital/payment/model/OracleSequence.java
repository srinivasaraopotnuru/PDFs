package uk.co.ybs.digital.payment.model;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import org.hibernate.annotations.GenerationTime;
import org.hibernate.annotations.ValueGenerationType;
import uk.co.ybs.digital.payment.repository.OracleSequenceGeneration;

@ValueGenerationType(generatedBy = OracleSequenceGeneration.class)
@Retention(RetentionPolicy.RUNTIME)
public @interface OracleSequence {
  String sequenceName();

  GenerationTime generationTime() default GenerationTime.INSERT;
}
