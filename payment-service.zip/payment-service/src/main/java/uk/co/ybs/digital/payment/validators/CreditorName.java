package uk.co.ybs.digital.payment.validators;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.Size;

@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {})
@NotAllWhitespace
@Size(max = 30)
@ReportAsSingleViolation
public @interface CreditorName {
  String message() default "Creditor name must be 30 characters or less and not all whitespace.";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
