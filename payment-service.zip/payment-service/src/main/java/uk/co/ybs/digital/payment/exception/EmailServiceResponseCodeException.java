package uk.co.ybs.digital.payment.exception;

public class EmailServiceResponseCodeException extends EmailServiceException {
  private static final long serialVersionUID = -2415958822537152454L;

  public EmailServiceResponseCodeException(final String message, final Throwable cause) {
    super(message, cause);
  }

  public EmailServiceResponseCodeException(final String message) {
    super(message);
  }
}
