package uk.co.ybs.digital.payment.service.sca.event;

import java.util.UUID;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.ExemptReasonCode;
import uk.co.ybs.digital.payment.audit.sca.Sca;

@Component
@AllArgsConstructor
public class EventContextFactory {

  public EventContext createSinglePaymentScaEventContext(
      final UUID transactionReferenceId,
      final String channel,
      final DecisionStatus decisionStatus,
      final ExemptReasonCode exemptReasonCode) {
    // When implementing exemptions, exemption reason should be discarded if it is an empty string.
    return EventContext.builder()
        .eventType(EventContext.Type.PAYMENT_TRANSACTION)
        .subEventType(EventContext.SubType.SINGLE)
        .channel(channel)
        .transactionReferenceId(transactionReferenceId)
        .sca(
            Sca.builder()
                .decisionStatus(decisionStatus != null ? decisionStatus : DecisionStatus.APPLIED)
                .exemptReasonCode(exemptReasonCode)
                .build())
        .build();
  }
}
