package uk.co.ybs.digital.payment.service;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.Sca;
import uk.co.ybs.digital.payment.service.authentic.AuthenticServiceException;
import uk.co.ybs.digital.payment.service.sca.ScaExemption;
import uk.co.ybs.digital.payment.service.sca.ScaManager;
import uk.co.ybs.digital.payment.service.sca.tracking.TrackingCode;
import uk.co.ybs.digital.payment.web.dto.Creditor;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequestVisitor;
import uk.co.ybs.digital.payment.web.dto.PaymentWarning;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@Service
@Slf4j
@RequiredArgsConstructor
public class PaymentService {

  @NonNull private final Clock clock;
  @NonNull private final ScaManager scaManager;
  @NonNull private final AccountValidator accountValidator;
  @NonNull private final PaymentValidator paymentValidator;
  @NonNull private final PaymentWarningGenerator paymentWarningGenerator;
  @NonNull private final PaymentInitiator paymentInitiator;
  @NonNull private final TransactionLogCreator transactionLogCreator;
  @NonNull private final InternalAccountValidator internalAccountValidator;

  public void reportPaymentFailure(
      final PaymentFailureRequest paymentFailureRequest, final RequestMetadata metadata) {
    log.info("Validating accountNumber belongs to the party, before reporting failure");
    accountValidator.validateDebtorAccount(paymentFailureRequest.getDebtor(), metadata);

    log.info("Making audit entry");
    scaManager.auditPaymentAuthFailure(paymentFailureRequest, metadata);
  }

  public List<PaymentWarning> validate(
      final PaymentRequest paymentRequest, final RequestMetadata metadata) {
    final ValidatedPaymentRequest validatedPaymentRequest =
        paymentRequest.accept(new ValidatePaymentVisitor(metadata));
    return paymentWarningGenerator.generate(validatedPaymentRequest, metadata);
  }

  public void validateCreditor(final Creditor creditor, final RequestMetadata metadata) {
    creditor.accept(new CreditorValidator(metadata, paymentValidator, internalAccountValidator));
  }

  @Transactional("aatTransactionManager")
  public void doPaymentWithoutSca(
      final PaymentRequest paymentRequest, final RequestMetadata metadata, final Jwt user) {
    log.info("Attempting to make payment without SCA credentials");
    final LocalDateTime transactionStartDateTime = LocalDateTime.now(clock);

    final ValidatedPaymentRequest validatedPaymentRequest =
        paymentRequest.accept(new ValidatePaymentVisitor(metadata));

    final ScaExemption exemption =
        scaManager
            .getExemption(validatedPaymentRequest, metadata, paymentRequest)
            .orElseThrow(
                () -> scaManager.generateScaRequiredException(paymentRequest, metadata, user));

    makePayment(
        metadata,
        transactionStartDateTime,
        validatedPaymentRequest,
        exemption.getTrackingCode(),
        Sca.builder()
            .decisionStatus(DecisionStatus.EXEMPTED)
            .exemptReasonCode(exemption.getExemptReasonCode())
            .build());
  }

  @Transactional("frontOfficeTransactionManager")
  public void doPaymentWithScaApp(
      final PaymentRequest paymentRequest,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    log.info("Attempting to make payment with SCA credentials");

    scaManager.validatePaymentSca(paymentRequest, metadata, scaCredentials);

    doPaymentWithSca(paymentRequest, metadata);
  }

  @Transactional("frontOfficeTransactionManager")
  public void doPaymentWithScaWeb(
      final PaymentRequest paymentRequest,
      final RequestMetadata metadata,
      final String passwordCharsScaChallengeResponse,
      final Jwt user) {
    log.info("Attempting to make payment with SCA password characters");

    scaManager.validatePaymentPasswordCharsSca(
        paymentRequest, metadata, passwordCharsScaChallengeResponse, user);

    doPaymentWithSca(paymentRequest, metadata);
  }

  private void doPaymentWithSca(
      final PaymentRequest paymentRequest, final RequestMetadata metadata) {
    final LocalDateTime transactionStartDateTime = LocalDateTime.now(clock);

    log.info("SCA credentials are good.  Validating that payment is allowed");
    final ValidatedPaymentRequest validatedPaymentRequest =
        paymentRequest.accept(new ValidatePaymentVisitor(metadata));

    log.info("Generating tracking code");
    final TrackingCode trackingCodeNumber =
        validatedPaymentRequest.accept(new GenerateAuthCodeRequestVisitor(metadata));

    makePayment(
        metadata,
        transactionStartDateTime,
        validatedPaymentRequest,
        trackingCodeNumber,
        Sca.builder().decisionStatus(DecisionStatus.APPLIED).build());
  }

  private void makePayment(
      final RequestMetadata metadata,
      final LocalDateTime transactionStartTime,
      final ValidatedPaymentRequest validatedPaymentRequest,
      final TrackingCode trackingCode,
      final Sca sca) {
    log.info("Making payment");
    final String transactionIdString;
    try {
      transactionIdString = validatedPaymentRequest.accept(new InitiatePaymentVisitor(metadata));
    } catch (AuthenticServiceException authenticServiceException) {
      scaManager.auditPaymentFailure(validatedPaymentRequest, trackingCode, metadata, sca);
      throw authenticServiceException;
    }

    log.info("Linking payment");
    validatedPaymentRequest.accept(
        new LinkPaymentVisitor(transactionIdString, trackingCode, metadata, sca));

    log.info("Writing frontoffice transaction log");
    final LocalDateTime transactionEndDateTime = LocalDateTime.now(clock);
    validatedPaymentRequest.accept(
        new TransactionLogCreationVisitor(metadata, transactionStartTime, transactionEndDateTime));
  }

  @AllArgsConstructor
  private class ValidatePaymentVisitor implements PaymentRequestVisitor<ValidatedPaymentRequest> {
    @NonNull private final RequestMetadata requestMetadata;

    @Override
    public ValidatedPaymentRequest visit(final ExternalPaymentRequest paymentRequest) {
      return paymentValidator.validatePayment(paymentRequest, requestMetadata);
    }

    @Override
    public ValidatedPaymentRequest visit(final InternalPaymentRequest paymentRequest) {
      return paymentValidator.validatePayment(paymentRequest, requestMetadata);
    }
  }

  @AllArgsConstructor
  private class InitiatePaymentVisitor implements ValidatedPaymentRequestVisitor<String> {
    @NonNull private final RequestMetadata requestMetadata;

    @Override
    public String visit(final ValidatedExternalPaymentRequest request) {
      return paymentInitiator.initiatePayment(request, requestMetadata);
    }

    @Override
    public String visit(final ValidatedInternalPaymentRequest request) {
      return paymentInitiator.initiatePayment(request, requestMetadata);
    }
  }

  @AllArgsConstructor
  private class GenerateAuthCodeRequestVisitor
      implements ValidatedPaymentRequestVisitor<TrackingCode> {
    @NonNull private final RequestMetadata requestMetadata;

    @Override
    public TrackingCode visit(final ValidatedExternalPaymentRequest request) {
      return scaManager.generateAuthenticationCode(request, requestMetadata);
    }

    @Override
    public TrackingCode visit(final ValidatedInternalPaymentRequest request) {
      return scaManager.generateAuthenticationCode(request, requestMetadata);
    }
  }

  @AllArgsConstructor
  private class LinkPaymentVisitor implements ValidatedPaymentRequestVisitor<Void> {
    @NonNull private final String transactionId;
    @NonNull private final TrackingCode trackingCode;
    @NonNull private final RequestMetadata requestMetadata;
    private final Sca sca;

    @Override
    public Void visit(final ValidatedExternalPaymentRequest request) {
      scaManager.linkPayment(transactionId, request, trackingCode, requestMetadata, sca);
      return null;
    }

    @Override
    public Void visit(final ValidatedInternalPaymentRequest request) {
      scaManager.linkPayment(transactionId, request, trackingCode, requestMetadata, sca);
      return null;
    }
  }

  @AllArgsConstructor
  private class TransactionLogCreationVisitor implements ValidatedPaymentRequestVisitor<Void> {
    @NonNull private final RequestMetadata requestMetadata;
    @NonNull private final LocalDateTime transactionStartTime;
    @NonNull private final LocalDateTime transactionEndTime;

    @Override
    public Void visit(final ValidatedExternalPaymentRequest request) {
      transactionLogCreator.create(
          request, transactionStartTime, transactionEndTime, requestMetadata);
      return null;
    }

    @Override
    public Void visit(final ValidatedInternalPaymentRequest request) {
      transactionLogCreator.create(
          request, transactionStartTime, transactionEndTime, requestMetadata);
      return null;
    }
  }
}
