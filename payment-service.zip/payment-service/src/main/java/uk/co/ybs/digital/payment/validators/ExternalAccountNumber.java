package uk.co.ybs.digital.payment.validators;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.Pattern;

@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {})
@ReportAsSingleViolation
@Pattern(regexp = "\\d{8}")
public @interface ExternalAccountNumber {
  String message() default
      "${validatedValue} is not an acceptable external account number; value must be 8 digits";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
