package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = InterestPenalty.InterestPenaltyBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class InterestPenalty {
  Integer days;

  @JsonPOJOBuilder(withPrefix = "")
  public static class InterestPenaltyBuilder {}
}
