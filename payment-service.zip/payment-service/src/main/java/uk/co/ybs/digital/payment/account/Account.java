package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import org.springframework.lang.Nullable;

@Value
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Account {
  String accountNumber;
  String accountSortCode;

  @Schema(name = "balance")
  @JsonProperty(value = "balance")
  List<Balance> balances;

  Deposits deposits;
  Withdrawals withdrawals;
  @Nullable Isa isa;
}
