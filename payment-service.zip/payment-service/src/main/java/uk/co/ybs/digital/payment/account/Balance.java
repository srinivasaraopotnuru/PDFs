package uk.co.ybs.digital.payment.account;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Balance {
  @Schema(required = true, example = "InterimAvailable")
  String type;

  @Schema(required = true, example = "999999999.99")
  BigDecimal amount;
}
