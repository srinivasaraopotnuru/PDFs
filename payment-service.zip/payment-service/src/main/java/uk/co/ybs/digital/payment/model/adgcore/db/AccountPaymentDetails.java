package uk.co.ybs.digital.payment.model.adgcore.db;

import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountPaymentDetails {

  BigDecimal minimumBalance;
  Boolean validPaymentAccountStatus;
  Boolean validPaymentAccountHolderRole;
  Boolean validWithdrawalCode;
  Boolean webEnabled;
  Boolean customerWarnings;

  List<PaymentAccountWarning> paymentAccountWarnings;

  @Value
  @Builder
  public static class PaymentAccountWarning {

    String warningCode;
    String rule;
    String message;
  }
}
