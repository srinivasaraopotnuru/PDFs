package uk.co.ybs.digital.payment.config;

import java.time.Clock;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import uk.co.ybs.digital.payment.service.BrandSortCodeMappings;
import uk.co.ybs.digital.payment.service.PaymentServiceProperties;

@Slf4j
@Configuration
@EnableConfigurationProperties(PaymentServiceProperties.class)
@RequiredArgsConstructor
public class PaymentServiceConfig {
  private final PaymentServiceProperties paymentServiceProperties;

  @Bean
  public Clock clock() {
    // The application should be run in UK timezone for consistency with other
    // YBS timezone handling.
    final Clock systemClock = Clock.systemDefaultZone();
    log.info("System clock is: {}", systemClock);
    return systemClock;
  }

  @Bean
  public BrandSortCodeMappings brandSortCodeMappings() {
    return new BrandSortCodeMappings(paymentServiceProperties.getInternalSortCodes());
  }
}
