package uk.co.ybs.digital.payment.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.payment.account.AccountServiceProperties;
import uk.co.ybs.digital.payment.audit.AuditServiceProperties;
import uk.co.ybs.digital.payment.beneficiary.BeneficiaryServiceProperties;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnectorFactory;

@EnableConfigurationProperties({
  AuditServiceProperties.class,
  AccountServiceProperties.class,
  BeneficiaryServiceProperties.class
})
@Configuration
@RequiredArgsConstructor
public class ServiceToServiceConfig {

  private final AuditServiceProperties auditServiceProperties;
  private final AccountServiceProperties accountServiceProperties;
  private final BeneficiaryServiceProperties beneficiaryServiceProperties;

  @Bean
  public WebClient accountServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return buildWebClient(
        accountServiceProperties.getUrl().toString(),
        builder,
        requestSigningClientHttpConnectorFactory);
  }

  @Bean
  public WebClient auditServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return buildWebClient(
        auditServiceProperties.getUrl().toString(),
        builder,
        requestSigningClientHttpConnectorFactory);
  }

  @Bean
  public WebClient beneficiaryServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return buildWebClient(
        beneficiaryServiceProperties.getUrl().toString(),
        builder,
        requestSigningClientHttpConnectorFactory);
  }

  private WebClient buildWebClient(
      final String url,
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(url)
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }
}
