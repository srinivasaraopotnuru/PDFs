package uk.co.ybs.digital.payment.exception;

public class UnexpectedReferenceException extends RuntimeException {
  private static final long serialVersionUID = 336913348806239848L;

  public UnexpectedReferenceException(final String message) {
    super(message);
  }
}
