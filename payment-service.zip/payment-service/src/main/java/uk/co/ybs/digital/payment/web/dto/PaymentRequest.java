package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
import uk.co.ybs.digital.payment.validators.PaymentAmount;

@AllArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
  @JsonSubTypes.Type(name = "EXTERNAL", value = ExternalPaymentRequest.class),
  @JsonSubTypes.Type(name = "INTERNAL", value = InternalPaymentRequest.class)
})
public abstract class PaymentRequest {
  @Schema(
      description = "A UUID to identify this payment across multiple requests",
      required = true,
      example = "abcd1234-ab65-4f3e-a3d3-abcdef123456")
  @NotNull(message = "You must specify a UUID idempotency key")
  protected final UUID idempotencyKey;

  @Schema(description = "The payment currency", required = true, example = "GBP")
  @NotNull(message = "You must specify a currency code")
  @Pattern(
      regexp = "GBP",
      message = "${validatedValue} is not a valid payment currency; value must be GBP")
  protected final String currency;

  @Schema(
      description = "The payment amount between 1.00 and 250000.00",
      required = true,
      example = "123.45")
  @NotNull(message = "You must specify an amount to transfer")
  @PaymentAmount
  protected final BigDecimal amount;

  @Schema(required = true)
  @Valid
  @NotNull(message = "You must specify the debtor")
  protected final Debtor debtor;

  public abstract <T> T accept(PaymentRequestVisitor<T> visitor);

  @JsonIgnore
  public BigDecimal getAmountWithExactly2DecimalPlaces() {
    return getAmount().setScale(2, RoundingMode.UNNECESSARY);
  }
}
