package uk.co.ybs.digital.payment.audit;

import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditPaymentAuthFailureRequest {
  @NonNull String ipAddress;

  @NonNull PaymentFailureDetails paymentDetails;

  @Value
  @Builder
  @Jacksonized
  public static class PaymentFailureDetails {
    @NonNull UUID uniqueReference;

    @NonNull String failureType;

    @NonNull String debtorAccountNumber;
  }
}
