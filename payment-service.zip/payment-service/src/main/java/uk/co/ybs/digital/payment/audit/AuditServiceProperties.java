package uk.co.ybs.digital.payment.audit;

import java.net.URL;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Getter
@Setter
@ConfigurationProperties(prefix = "uk.co.ybs.digital.audit")
public class AuditServiceProperties {
  private URL url;
}
