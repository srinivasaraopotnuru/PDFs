package uk.co.ybs.digital.payment.model.adgcore.db;

import java.sql.SQLException;
import java.sql.Struct;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PaymentAccountWarningMapper
    implements StructMapper<AccountPaymentDetails.PaymentAccountWarning> {

  public AccountPaymentDetails.PaymentAccountWarning fromStruct(final Struct struct)
      throws SQLException {

    AccountPaymentDetails.PaymentAccountWarning.PaymentAccountWarningBuilder paymentAccountWarning =
        AccountPaymentDetails.PaymentAccountWarning.builder();

    Object[] attributes = struct.getAttributes();

    paymentAccountWarning.warningCode((String) attributes[0]);
    paymentAccountWarning.rule((String) attributes[1]);
    paymentAccountWarning.message((String) attributes[2]);

    return paymentAccountWarning.build();
  }
}
