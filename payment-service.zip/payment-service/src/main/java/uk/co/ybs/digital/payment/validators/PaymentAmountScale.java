package uk.co.ybs.digital.payment.validators;

import java.math.BigDecimal;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PaymentAmountScale implements ConstraintValidator<PaymentAmount, BigDecimal> {

  @Override
  public boolean isValid(final BigDecimal value, final ConstraintValidatorContext context) {
    return value == null || value.scale() == 2;
  }
}
