package uk.co.ybs.digital.payment.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.util.Assert;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.logging.filters.session.SessionIdFilter;
import uk.co.ybs.digital.payment.beneficiary.BeneficiaryService;
import uk.co.ybs.digital.payment.config.SwaggerConfig;
import uk.co.ybs.digital.payment.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.payment.service.PaymentService;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.service.SystemRequestMetadata;
import uk.co.ybs.digital.payment.service.UserRequestMetadata;
import uk.co.ybs.digital.payment.service.sca.ScaCredentialsExtractor;
import uk.co.ybs.digital.payment.service.sca.ScaManager;
import uk.co.ybs.digital.payment.service.sca.ScaPasswordChallengeResponseExtractor;
import uk.co.ybs.digital.payment.web.dto.Creditor;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentWarning;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@Data
@RestController
@RequiredArgsConstructor
public class PaymentController {

  private static final String BRAND_CODE_CLAIM = "brand_code";
  private static final String CHANNEL_CLAIM = "channel";
  private static final String REQUIRE_PAYMENT_AND_ACCOUNT_READ_SCOPE =
      "hasAuthority('SCOPE_PAYMENT') and hasAuthority('SCOPE_ACCOUNT_READ')";
  private static final String REQUIRE_ACCOUNT_READ_OR_PAYMENT_READ_SCOPE =
      "hasAuthority('SCOPE_ACCOUNT_READ') or hasAuthority('SCOPE_PAYMENT_READ')";
  private static final String EMAIL_CLAIM = "customer_email";
  private static final String TITLE_CLAIM = "customer_title";
  private static final String LAST_NAME_CLAIM = "customer_last_name";
  private static final String PARTY_ID_CLAIM = "party_id";
  private static final String SUB_TYPE = "sub_type";
  private static final String CUSTOMER_SUB_TYPE = "customer";

  private static final String OK_RESPONSE_CODE = "200";
  private static final String NO_CONTENT_RESPONSE_CODE = "204";
  private static final String NO_CONTENT_MESSAGE = "No Content";
  private static final String BAD_REQUEST_RESPONSE_CODE = "400";
  private static final String BAD_REQUEST_MESSAGE = "Bad Request";
  private static final String UNAUTHORISED_RESPONSE_CODE = "401";
  private static final String UNAUTHORISED_MESSAGE = "Unauthorised";
  private static final String FORBIDDEN_RESPONSE_CODE = "403";
  private static final String FORBIDDEN_MESSAGE = "Forbidden";
  private static final String CONFLICT_RESPONSE_CODE = "409";
  private static final String CONFLICT_MESSAGE = "Conflict";
  private static final String UNSUPPORTED_MEDIA_TYPE_RESPONSE_CODE = "415";
  private static final String UNSUPPORTED_MEDIA_TYPE_MESSAGE = "Unsupported Media Type";
  private static final String INTERNAL_SERVER_ERROR_RESPONSE_CODE = "500";
  private static final String INTERNAL_SERVER_ERROR_MESSAGE = "Internal Sderver Error";
  private static final String ACCOUNT_NUMBER = "accountNumber";
  private static final String ACCOUNT_NUMBER_DESCRIPTION = "10 digit account number";
  private static final String SCOPE_ACCOUNT_READ = "hasAuthority('SCOPE_ACCOUNT_READ')";
  private final PaymentService paymentService;
  private final BeneficiaryService beneficiaryService;
  private final ScaCredentialsExtractor scaCredentialsExtractor;
  private final ScaPasswordChallengeResponseExtractor scaPasswordChallengeResponseExtractor;

  @PostMapping(
      value = "/payment",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @Operation(
      description = "Make a payment from one account to another",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(
            responseCode = NO_CONTENT_RESPONSE_CODE,
            description = "Payment made (and beneficiary saved if requested)"),
        @ApiResponse(
            responseCode = OK_RESPONSE_CODE,
            description = "Payment made, but unable to save to save beneficiary",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CONFLICT_RESPONSE_CODE,
            description = CONFLICT_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNSUPPORTED_MEDIA_TYPE_RESPONSE_CODE,
            description = UNSUPPORTED_MEDIA_TYPE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @PreAuthorize(REQUIRE_PAYMENT_AND_ACCOUNT_READ_SCOPE)
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void payment(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @io.swagger.v3.oas.annotations.parameters.RequestBody(
              content =
                  @Content(
                      schema =
                          @Schema(
                              oneOf = {
                                ExternalPaymentRequest.class,
                                InternalPaymentRequest.class
                              })))
          @RequestBody
          @Validated
          final PaymentRequest paymentRequest,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers,
      final HttpServletRequest request)
      throws InvalidScaHeadersException {
    final RequestMetadata metadata =
        extractRequestMetadata(
            extractSystemRequestMetadata(user, requestId, headers, request),
            extractUserRequestMetadata(user, sessionId));

    if (ScaManager.WEB_CHANNEL.equalsIgnoreCase(metadata.getChannel())) {
      makePaymentWeb(user, paymentRequest, headers, metadata);
    } else {
      makePaymentApp(user, paymentRequest, headers, metadata);
    }
  }

  private void makePaymentWeb(
      final Jwt user,
      final PaymentRequest paymentRequest,
      final HttpHeaders headers,
      final RequestMetadata metadata) {
    Optional<String> passwordCharsChallengeResponse =
        scaPasswordChallengeResponseExtractor.extractScaPasswordChallengeResponse(headers);
    if (passwordCharsChallengeResponse.isPresent()) {
      paymentService.doPaymentWithScaWeb(
          paymentRequest, metadata, passwordCharsChallengeResponse.get(), user);
      beneficiaryService.saveBeneficiary(paymentRequest, metadata);
    } else {
      paymentService.doPaymentWithoutSca(paymentRequest, metadata, user);
      if (paymentRequest instanceof ExternalPaymentRequest) {
        ExternalPaymentRequest externalPaymentRequest = (ExternalPaymentRequest) paymentRequest;
        if (externalPaymentRequest.getCreditor() instanceof ExternalCreditorBeneficiary
            && externalPaymentRequest.getReference() != null) {
          beneficiaryService.updateExternalBeneficiary(externalPaymentRequest, metadata);
        }
      }
    }
  }

  private void makePaymentApp(
      final Jwt user,
      final PaymentRequest paymentRequest,
      final HttpHeaders headers,
      final RequestMetadata metadata) {
    final Optional<ScaCredentials> scaCredentials = scaCredentialsExtractor.extract(headers);
    if (scaCredentials.isPresent()) {
      paymentService.doPaymentWithScaApp(paymentRequest, metadata, scaCredentials.get());
      beneficiaryService.saveBeneficiary(paymentRequest, metadata);
    } else {
      paymentService.doPaymentWithoutSca(paymentRequest, metadata, user);
    }
  }

  @PostMapping(
      value = "/failure",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @Operation(
      description = "Send payment failure email",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = NO_CONTENT_RESPONSE_CODE, description = NO_CONTENT_MESSAGE),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CONFLICT_RESPONSE_CODE,
            description = CONFLICT_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNSUPPORTED_MEDIA_TYPE_RESPONSE_CODE,
            description = UNSUPPORTED_MEDIA_TYPE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @PreAuthorize(REQUIRE_PAYMENT_AND_ACCOUNT_READ_SCOPE)
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void paymentFailure(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @RequestBody @Validated final PaymentFailureRequest paymentFailureRequest,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers,
      final HttpServletRequest request) {
    final RequestMetadata metadata =
        extractRequestMetadata(
            extractSystemRequestMetadata(user, requestId, headers, request),
            extractUserRequestMetadata(user, sessionId));

    paymentService.reportPaymentFailure(paymentFailureRequest, metadata);
  }

  @PostMapping(
      value = "/validate",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @Operation(
      description = "Validate payment details and present any warnings",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(
            responseCode = OK_RESPONSE_CODE,
            description = "Payment valid, but may have warnings"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CONFLICT_RESPONSE_CODE,
            description = CONFLICT_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNSUPPORTED_MEDIA_TYPE_RESPONSE_CODE,
            description = UNSUPPORTED_MEDIA_TYPE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @PreAuthorize(REQUIRE_PAYMENT_AND_ACCOUNT_READ_SCOPE)
  @ResponseStatus(value = HttpStatus.OK)
  public List<PaymentWarning> validate(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @io.swagger.v3.oas.annotations.parameters.RequestBody(
              content =
                  @Content(
                      schema =
                          @Schema(
                              oneOf = {
                                ExternalPaymentRequest.class,
                                InternalPaymentRequest.class
                              })))
          @RequestBody
          @Validated
          final PaymentRequest paymentRequest,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers,
      final HttpServletRequest request) {
    final RequestMetadata metadata =
        extractRequestMetadata(
            extractSystemRequestMetadata(user, requestId, headers, request),
            extractUserRequestMetadata(user, sessionId));
    return paymentService.validate(paymentRequest, metadata);
  }

  @PostMapping(value = "/validate/payee", consumes = MediaType.APPLICATION_JSON_VALUE)
  @Operation(
      description =
          "Validate internal payee (account number) or external payee (account number and sort code)",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = NO_CONTENT_RESPONSE_CODE, description = "Payee details valid"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = CONFLICT_RESPONSE_CODE,
            description = CONFLICT_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNSUPPORTED_MEDIA_TYPE_RESPONSE_CODE,
            description = UNSUPPORTED_MEDIA_TYPE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @PreAuthorize(REQUIRE_ACCOUNT_READ_OR_PAYMENT_READ_SCOPE)
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void validatePayeeDetails(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @io.swagger.v3.oas.annotations.parameters.RequestBody(
              content =
                  @Content(
                      schema =
                          @Schema(
                              oneOf = {
                                ExternalCreditorDetails.class,
                                InternalAccountDetails.class
                              })))
          @RequestBody
          @Validated
          final Creditor creditorDetails,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers,
      final HttpServletRequest request) {
    final RequestMetadata metadata =
        extractRequestMetadata(user, requestId, headers, request, sessionId);
    paymentService.validateCreditor(creditorDetails, metadata);
  }

  private RequestMetadata extractRequestMetadata(
      final Jwt user,
      final UUID requestId,
      final HttpHeaders headers,
      final HttpServletRequest request,
      final UUID sessionId) {
    RequestMetadata.RequestMetadataBuilder metadata =
        RequestMetadata.builder()
            .systemRequestMetadata(extractSystemRequestMetadata(user, requestId, headers, request));

    if (user != null
        && user.getClaimAsString(SUB_TYPE) != null
        && user.getClaimAsString(SUB_TYPE).equals(CUSTOMER_SUB_TYPE)) {
      metadata.userRequestMetadata(extractUserRequestMetadata(user, sessionId));
    }
    return metadata.build();
  }

  private SystemRequestMetadata extractSystemRequestMetadata(
      final Jwt user,
      final UUID requestId,
      final HttpHeaders headers,
      final HttpServletRequest request) {
    Assert.notNull(user, "no user!");

    return SystemRequestMetadata.builder()
        .requestId(requestId)
        .host(headers.getHost())
        .brandCode(user.getClaimAsString(BRAND_CODE_CLAIM))
        .forwardingAuth(user.getTokenValue())
        .ipAddress(request.getRemoteAddr())
        .build();
  }

  private UserRequestMetadata extractUserRequestMetadata(final Jwt user, final UUID sessionId) {
    Assert.notNull(user, "no user!");

    return UserRequestMetadata.builder()
        .sessionId(sessionId)
        .partyId(user.getClaimAsString(PARTY_ID_CLAIM))
        .channel(user.getClaimAsString(CHANNEL_CLAIM))
        .email(user.getClaimAsString(EMAIL_CLAIM))
        .title(user.getClaimAsString(TITLE_CLAIM))
        .surname(user.getClaimAsString(LAST_NAME_CLAIM))
        .build();
  }

  private RequestMetadata extractRequestMetadata(
      final SystemRequestMetadata systemRequestMetadata,
      final UserRequestMetadata userRequestMetadata) {

    return RequestMetadata.builder()
        .systemRequestMetadata(systemRequestMetadata)
        .userRequestMetadata(userRequestMetadata)
        .build();
  }
}
