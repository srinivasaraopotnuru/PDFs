package uk.co.ybs.digital.payment.config;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.math.BigDecimal;
import org.springframework.boot.jackson.JsonComponent;

@JsonComponent
public class BigDecimalSerializer extends JsonSerializer<BigDecimal> {
  @Override
  public void serialize(
      final BigDecimal value, final JsonGenerator gen, final SerializerProvider serializers)
      throws IOException {
    // ROUND_UNNECESSARY because the money column on the DB is Number(15,2), and so should never be
    // more than 2 decimal places.
    // BigDecimals are only used for the money column in this service.
    gen.writeString(value.setScale(2, BigDecimal.ROUND_UNNECESSARY).toString());
  }
}
