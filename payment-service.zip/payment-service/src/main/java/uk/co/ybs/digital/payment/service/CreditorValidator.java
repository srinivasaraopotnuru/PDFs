package uk.co.ybs.digital.payment.service;

import lombok.AllArgsConstructor;
import lombok.NonNull;
import uk.co.ybs.digital.payment.web.dto.CreditorVisitor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;

@AllArgsConstructor
public class CreditorValidator implements CreditorVisitor<Void> {
  @NonNull private final RequestMetadata requestMetadata;
  @NonNull private final PaymentValidator paymentValidator;
  @NonNull private final InternalAccountValidator internalAccountValidator;

  @Override
  public Void visit(final ExternalCreditorDetails externalCreditorDetails) {
    paymentValidator.validateExternalCreditor(externalCreditorDetails, requestMetadata);
    return null;
  }

  @Override
  public Void visit(final InternalAccountDetails internalAccountDetails) {
    internalAccountValidator.validateInternalAccount(internalAccountDetails, requestMetadata);
    return null;
  }
}
