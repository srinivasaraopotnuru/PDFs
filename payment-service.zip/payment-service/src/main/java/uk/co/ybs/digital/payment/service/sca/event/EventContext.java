package uk.co.ybs.digital.payment.service.sca.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.payment.audit.sca.Sca;

@Value
@Builder
@JsonPropertyOrder({"eventType", "subEventType", "channel", "transactionReferenceId", "sca"})
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonDeserialize(builder = EventContext.EventContextBuilder.class)
public class EventContext {
  public enum Type {
    @JsonProperty("Payment Transaction")
    PAYMENT_TRANSACTION
  }

  public enum SubType {
    SINGLE
  }

  @JsonProperty(value = "Event Type")
  @NonNull
  private Type eventType;

  @JsonProperty(value = "Sub Event Type")
  @NonNull
  private SubType subEventType;

  @JsonProperty(value = "Channel")
  @NonNull
  private String channel;

  @JsonProperty(value = "Transaction Reference Id")
  @NonNull
  private UUID transactionReferenceId;

  private Sca sca;
}
