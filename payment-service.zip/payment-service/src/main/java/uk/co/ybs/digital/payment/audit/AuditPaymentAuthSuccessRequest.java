package uk.co.ybs.digital.payment.audit;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(
    builder = AuditPaymentAuthSuccessRequest.AuditPaymentAuthSuccessRequestBuilder.class)
public class AuditPaymentAuthSuccessRequest {

  @NonNull private final UUID trackingId;

  @NonNull private final String trackingCode;

  @NonNull private final String ipAddress;

  @NonNull private final SimplePaymentDetails paymentDetails;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditPaymentAuthSuccessRequestBuilder {}
}
