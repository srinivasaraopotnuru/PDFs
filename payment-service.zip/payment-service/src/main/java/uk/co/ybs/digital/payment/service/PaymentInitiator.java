package uk.co.ybs.digital.payment.service;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.service.authentic.AuthenticService;

@Component
@RequiredArgsConstructor
public class PaymentInitiator {
  @NonNull private final AuthenticService authenticService;

  public String initiatePayment(
      final ValidatedExternalPaymentRequest paymentRequest, final RequestMetadata metadata) {
    return authenticService.initiatePayment(paymentRequest, metadata);
  }

  public String initiatePayment(
      final ValidatedInternalPaymentRequest paymentRequest, final RequestMetadata metadata) {
    return authenticService.initiatePayment(paymentRequest, metadata);
  }
}
