package uk.co.ybs.digital.payment.audit.sca;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ExemptReasonCode {
  LOWVAL("Low Value"),
  OACTRN("Own account transaction exempted"),
  TRBENF("Trusted beneficiary exemption");

  private final String description;
}
