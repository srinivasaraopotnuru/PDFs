package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.math.BigDecimal;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = PaymentWarning.PaymentWarningBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PaymentWarning implements Comparable<PaymentWarning> {
  @NonNull WarningCategory code;

  String displayMessage;

  Parameters parameters;

  @Override
  public int compareTo(final PaymentWarning other) {
    return code.getDescription().compareTo(other.code.getDescription());
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class PaymentWarningBuilder {}

  @Value
  @Builder
  @JsonDeserialize(builder = Parameters.ParametersBuilder.class)
  public static class Parameters {
    Integer days;
    BigDecimal amount;

    @JsonPOJOBuilder(withPrefix = "")
    public static class ParametersBuilder {}
  }
}
