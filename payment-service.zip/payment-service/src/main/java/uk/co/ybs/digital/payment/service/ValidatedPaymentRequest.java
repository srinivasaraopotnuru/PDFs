package uk.co.ybs.digital.payment.service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;
import lombok.experimental.FieldDefaults;
import uk.co.ybs.digital.payment.account.Account;

@AllArgsConstructor
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
@Getter
@EqualsAndHashCode
@ToString
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public abstract class ValidatedPaymentRequest {

  @NonNull UUID idempotencyKey;
  @NonNull String currency;
  @NonNull BigDecimal amount;
  @NonNull Account debtorAccount;

  public abstract <R> R accept(ValidatedPaymentRequestVisitor<R> visitor);

  public BigDecimal getAmountWithExactly2DecimalPlaces() {
    return getAmount().setScale(2, RoundingMode.UNNECESSARY);
  }
}
