package uk.co.ybs.digital.payment.audit;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = AuditPaymentDecisionRequest.AuditPaymentDecisionRequestBuilder.class)
public class AuditPaymentDecisionRequest {
  @NonNull private final String ipAddress;

  @NonNull private final SimplePaymentDetails paymentDetails;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditPaymentDecisionRequestBuilder {}
}
