package uk.co.ybs.digital.payment.model.adgcore.db;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.List;
import lombok.NonNull;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.jdbc.core.SqlReturnType;

public class SqlReturnStructArray<T> implements SqlReturnType {

  /** The object that will do the mapping * */
  private final transient StructMapper<T> mapper;

  public SqlReturnStructArray(final StructMapper<T> mapper) {
    this.mapper = mapper;
  }

  /**
   * The implementation for this specific type. This method is called internally by the Spring
   * Framework during the out parameter processing, and it's not accessed by application code
   * directly.
   */
  public @NonNull Object getTypeValue(
      final CallableStatement cs, final int index, final int sqlType, final String typeName)
      throws SQLException {

    java.sql.Array array = (java.sql.Array) cs.getObject(index);

    Object[] structValues = (Object[]) array.getArray();

    List<T> values = new ArrayList<>();

    for (Object struct : structValues) {
      if (struct instanceof Struct) {
        values.add(mapper.fromStruct((Struct) struct));
      } else {
        if (struct == null) {
          throw new InvalidDataAccessApiUsageException("Expected STRUCT but got 'null'");
        } else {
          throw new InvalidDataAccessApiUsageException(
              "Expected STRUCT but got " + struct.getClass().getName());
        }
      }
    }
    return values.toArray();
  }
}
