package uk.co.ybs.digital.payment.service;

import java.math.BigDecimal;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.util.LinkedCaseInsensitiveMap;
import org.springframework.validation.annotation.Validated;
import uk.co.ybs.digital.payment.validators.SortCode;

@Validated
@ConstructorBinding
@ConfigurationProperties(prefix = "uk.co.ybs.digital.payment")
@Getter
@AllArgsConstructor
public class PaymentServiceProperties {
  /**
   * Use a case insensitive map because environment variables bind to lower cased map keys
   * https://github.com/spring-projects/spring-boot/issues/18003
   */
  @NotNull private LinkedCaseInsensitiveMap<List<@SortCode String>> internalSortCodes;

  @NotNull private boolean scaExemptionsEnabled;
  @NotNull private BigDecimal maxLvtAmount;
  @NotNull private int maxLvtCount;
}
