package uk.co.ybs.digital.payment.service.authentic;

public class AuthenticServiceException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public AuthenticServiceException(final String message) {
    super(message);
  }

  public AuthenticServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
