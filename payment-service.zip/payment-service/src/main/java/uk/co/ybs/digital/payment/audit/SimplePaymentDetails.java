package uk.co.ybs.digital.payment.audit;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.payment.audit.sca.Sca;

@Value
@Builder
@JsonDeserialize(builder = SimplePaymentDetails.SimplePaymentDetailsBuilder.class)
public class SimplePaymentDetails {
  @NonNull private final UUID uniqueReference;
  private Sca sca;

  @JsonPOJOBuilder(withPrefix = "")
  public static class SimplePaymentDetailsBuilder {}
}
