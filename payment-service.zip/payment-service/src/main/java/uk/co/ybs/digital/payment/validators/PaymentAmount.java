package uk.co.ybs.digital.payment.validators;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import javax.validation.ReportAsSingleViolation;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;

@Target({ElementType.METHOD, ElementType.FIELD, ElementType.TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {PaymentAmountScale.class})
@Digits(integer = 6, fraction = 2)
@DecimalMin(value = "1.00")
@DecimalMax(value = "250000.00")
@ReportAsSingleViolation
public @interface PaymentAmount {
  String message() default
      "${validatedValue} is not an acceptable currency amount; value must be to two decimal places and between 1.00 and 250000.00";

  Class<?>[] groups() default {};

  Class<? extends Payload>[] payload() default {};
}
