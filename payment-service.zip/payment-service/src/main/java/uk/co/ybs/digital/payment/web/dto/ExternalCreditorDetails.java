package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;
import uk.co.ybs.digital.payment.validators.AlphaNumeric;
import uk.co.ybs.digital.payment.validators.CreditorName;
import uk.co.ybs.digital.payment.validators.CreditorNameSaveBeneficiaryConstraint;
import uk.co.ybs.digital.payment.validators.ExternalAccountNumber;
import uk.co.ybs.digital.payment.validators.NotAllWhitespace;
import uk.co.ybs.digital.payment.validators.SortCode;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails.ExternalCreditorDetailsBuilder;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = ExternalCreditorDetailsBuilder.class)
@CreditorNameSaveBeneficiaryConstraint
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ExternalCreditorDetails implements ExternalCreditor, Creditor {
  @NotNull(message = "You must specify a creditor account number")
  @ExternalAccountNumber(
      message =
          "${validatedValue} is not an acceptable creditor account number; value must be 8 digits")
  @Schema(
      description = "The 8-digit account number of the account to credit",
      required = true,
      example = "01234567")
  String externalAccountNumber;

  @NotNull(message = "You must specify a creditor sort code")
  @SortCode
  @Schema(
      description = "The sort code of the account to credit",
      required = true,
      example = "112233")
  String sortCode;

  @Schema(description = "The name of the credit account holder (not blank)", required = false)
  @CreditorName
  @AlphaNumeric
  String name;

  @Schema(
      description =
          "Indicates that the the service should attempted to save the beneficiary if the payment succeeds")
  Boolean saveBeneficiary;

  @Size(min = 1, max = 20, message = "Memorable name must be between {min} and {max} characters")
  @NotAllWhitespace(message = "Memorable name must not be all whitespace")
  @Schema(
      description = "The memorable name to associate with the saved beneficiary",
      example = "Joint Account",
      maxLength = 20)
  @AlphaNumeric
  String memorableName;

  public boolean shouldSaveBeneficiary() {
    return saveBeneficiary != null && saveBeneficiary;
  }

  @Override
  public <T> T accept(final ExternalCreditorVisitor<T> visitor) {
    return visitor.visit(this);
  }

  @Override
  public <T> T accept(final CreditorVisitor<T> visitor) {
    return visitor.visit(this);
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ExternalCreditorDetailsBuilder {}
}
