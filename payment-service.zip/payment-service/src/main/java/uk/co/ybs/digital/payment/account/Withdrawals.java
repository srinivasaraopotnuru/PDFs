package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;
import org.springframework.lang.Nullable;

@Value
@Builder
@JsonDeserialize(builder = Withdrawals.WithdrawalsBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Withdrawals {
  boolean permittedOverApi;

  @Nullable WithdrawalLimit limit;

  @Nullable InterestPenalty interestPenalty;

  @JsonPOJOBuilder(withPrefix = "")
  public static class WithdrawalsBuilder {}
}
