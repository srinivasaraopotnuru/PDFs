package uk.co.ybs.digital.payment.service;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.payment.repository.frontoffice.SavingsTransactionLogEntryRepository;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;

@Component
@AllArgsConstructor
public class TransactionLogCreator {
  @NonNull private final SavingsTransactionLogEntryRepository savingsTransactionLogEntryRepository;

  public void create(
      final ValidatedExternalPaymentRequest request,
      final LocalDateTime transactionStartTime,
      final LocalDateTime transactionEndTime,
      final RequestMetadata requestMetadata) {
    final ExternalCreditorDetails creditorDetails = request.getCreditorDetails();

    final SavingsTransactionLogEntry logEntry =
        logEntryBuilder(request, transactionStartTime, transactionEndTime, requestMetadata)
            .bankSortCode(Integer.valueOf(creditorDetails.getSortCode()))
            .targetAccountNumber(Long.valueOf(creditorDetails.getExternalAccountNumber()))
            .bankAccountName(creditorDetails.getName())
            .bankReference(request.getReference())
            .transferIndicator(SavingsTransactionLogEntry.TRANSFER_INDICATOR_EXTERNAL)
            .build();

    savingsTransactionLogEntryRepository.save(logEntry);
  }

  public void create(
      final ValidatedInternalPaymentRequest request,
      final LocalDateTime transactionStartTime,
      final LocalDateTime transactionEndTime,
      final RequestMetadata requestMetadata) {
    final SavingsTransactionLogEntry logEntry =
        logEntryBuilder(request, transactionStartTime, transactionEndTime, requestMetadata)
            .targetAccountNumber(Long.valueOf(request.getCreditorAccount().getAccountNumber()))
            .transferIndicator(SavingsTransactionLogEntry.TRANSFER_INDICATOR_INTERNAL)
            .build();

    savingsTransactionLogEntryRepository.save(logEntry);
  }

  private SavingsTransactionLogEntry.SavingsTransactionLogEntryBuilder logEntryBuilder(
      final ValidatedPaymentRequest paymentRequest,
      final LocalDateTime transactionStartTime,
      final LocalDateTime transactionEndTime,
      final RequestMetadata requestMetadata) {
    return SavingsTransactionLogEntry.builder()
        .accountNumber(Long.valueOf(paymentRequest.getDebtorAccount().getAccountNumber()))
        .startTime(transactionStartTime)
        .partySysId(Long.valueOf(requestMetadata.getPartyId()))
        .closure(SavingsTransactionLogEntry.CLOSURE_NO)
        .status(SavingsTransactionLogEntry.STATUS_WITHDRAWAL_END)
        .amount(paymentRequest.getAmount())
        .endTime(transactionEndTime);
  }
}
