package uk.co.ybs.digital.payment.service;

import java.util.Collections;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.account.AccountDetailsFilter;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNoCustomerRelationshipException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.InternalAccountValidatorException;
import uk.co.ybs.digital.payment.web.dto.InternalAccountDetails;

@Component
@RequiredArgsConstructor
public class InternalAccountValidator {
  @NonNull private final AccountService accountService;

  public void validateInternalAccount(
      final InternalAccountDetails internalAccountDetails, final RequestMetadata metadata) {
    final String accountNumber = internalAccountDetails.getAccountNumber();

    validRequestMetadata(metadata);
    try {
      try {
        accountService.getAccount(accountNumber, metadata);
      } catch (AccountServiceEntityNoCustomerRelationshipException e) {
        accountService.getAccount(
            accountNumber, Collections.singletonList(AccountDetailsFilter.OTHER_ACCOUNT), metadata);
      }
    } catch (AccountServiceEntityNotFoundException | AccountServiceEntityAccessDeniedException e) {
      throw new InternalAccountValidatorException(
          String.format("Failed to find internal account: %s", accountNumber),
          InternalAccountValidatorException.Reason.ACCOUNT_NUMBER,
          e);
    }
  }

  private void validRequestMetadata(final RequestMetadata metadata) {
    if (!metadata.hasUserRequestMetadata()) {
      throw new InternalAccountValidatorException(
          "Missing field: party_id", InternalAccountValidatorException.Reason.PARTY_ID);
    }
  }
}
