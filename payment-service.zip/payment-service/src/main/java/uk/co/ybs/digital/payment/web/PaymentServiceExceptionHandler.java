package uk.co.ybs.digital.payment.web;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.payment.beneficiary.SaveBeneficiaryException;
import uk.co.ybs.digital.payment.exception.AccountValidatorException;
import uk.co.ybs.digital.payment.exception.InternalAccountValidatorException;
import uk.co.ybs.digital.payment.exception.InvalidPaymentException;
import uk.co.ybs.digital.payment.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.payment.exception.ScaRequiredException;
import uk.co.ybs.digital.payment.exception.UnexpectedReferenceException;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.sca.exception.InvalidPasswordCharsScaException;
import uk.co.ybs.digital.sca.exception.InvalidPemKeyException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class PaymentServiceExceptionHandler {

  private final ObjectMapper objectMapper;

  private static final ImmutableMap<InvalidPaymentException.Reason, ErrorResponse.ErrorItem>
      INVALID_PAYMENT_REASON_TO_ERROR_ITEM_MAPPER =
          ImmutableMap.<InvalidPaymentException.Reason, ErrorResponse.ErrorItem>builder()
              .put(
                  InvalidPaymentException.Reason.CREDITOR_ACCOUNT,
                  ErrorItem.builder()
                      .errorCode(ErrorResponse.ErrorItem.PAYMENT_REJECTED_CREDITOR_ACCOUNT)
                      .message("Unable to make payment to the creditor account details provided")
                      .build())
              .put(
                  InvalidPaymentException.Reason.CREDITOR_ACCOUNT_DEPOSIT_LIMIT,
                  ErrorItem.builder()
                      .errorCode(
                          ErrorResponse.ErrorItem.PAYMENT_REJECTED_CREDITOR_ACCOUNT_DEPOSIT_LIMIT)
                      .message("Cannot exceed deposit limit on the creditor account")
                      .build())
              .put(
                  InvalidPaymentException.Reason.CREDITOR_ACCOUNT_INTERNAL_SORT_CODE,
                  ErrorItem.builder()
                      .errorCode(
                          ErrorResponse.ErrorItem
                              .PAYMENT_REJECTED_CREDITOR_ACCOUNT_INTERNAL_SORT_CODE)
                      .message(
                          "Payments to internal accounts must be done using the internal account number")
                      .build())
              .put(
                  InvalidPaymentException.Reason.DEBTOR_ACCOUNT,
                  ErrorItem.builder()
                      .errorCode(ErrorResponse.ErrorItem.PAYMENT_REJECTED_DEBTOR_ACCOUNT)
                      .message("Unable to make payment from the debtor account details provided")
                      .build())
              .put(
                  InvalidPaymentException.Reason.DEBTOR_ACCOUNT_INSUFFICIENT_FUNDS,
                  ErrorItem.builder()
                      .errorCode(
                          ErrorResponse.ErrorItem
                              .PAYMENT_REJECTED_DEBTOR_ACCOUNT_INSUFFICIENT_FUNDS)
                      .message("Insufficient funds available to make payment")
                      .build())
              .put(
                  InvalidPaymentException.Reason.DEBTOR_ACCOUNT_MULTIPLE_SIGNATORIES_REQUIRED,
                  ErrorItem.builder()
                      .errorCode(
                          ErrorItem.PAYMENT_REJECTED_DEBTOR_ACCOUNT_MULTIPLE_SIGNATORIES_REQUIRED)
                      .message("Multiple signatories are required for withdrawals")
                      .build())
              .put(
                  InvalidPaymentException.Reason.DEBTOR_AND_CREDITOR_ACCOUNT_SAME,
                  ErrorItem.builder()
                      .errorCode(
                          ErrorResponse.ErrorItem.PAYMENT_REJECTED_DEBTOR_AND_CREDITOR_ACCOUNT_SAME)
                      .message("Cannot make payment from and to the same account")
                      .build())
              .build();

  @ExceptionHandler(RuntimeException.class)
  public ResponseEntity<ErrorResponse> handleUnknownErrors(
      final RuntimeException exception, final WebRequest request) {
    log.error(
        "Unhandled exception thrown. Returning 500 Internal Error. {}",
        exception.getMessage(),
        exception);
    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    ErrorResponse response =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Internal Server Error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorItem.UNEXPECTED_ERROR)
                    .message("Internal Server Error")
                    .build())
            .build();

    return ResponseEntity.status(status).body(response);
  }

  @ExceptionHandler(AccessDeniedException.class)
  public void handleAccessDeniedException(final AccessDeniedException exception) {
    // Let spring security handle it.
    throw exception;
  }

  @ExceptionHandler(InvalidScaHeadersException.class)
  public ResponseEntity<ErrorResponse> handleMissingRequestHeader(
      final InvalidScaHeadersException exception, final WebRequest request) {
    List<ErrorItem> errors =
        exception.getMissingHeaders().stream()
            .map(
                header ->
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("Header.Missing")
                        .message(exception.getMessage())
                        .path(header)
                        .build())
            .collect(Collectors.toList());

    ErrorResponse response =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(RequestIdHelper.getRequestId(request))
            .message("Missing or invalid headers")
            .errors(errors)
            .build();

    return ResponseEntity.badRequest().body(response);
  }

  @ExceptionHandler(ScaRequiredException.class)
  public ResponseEntity<ErrorResponse> scaRequired(
      final ScaRequiredException exception, final WebRequest request) {
    log.info("Forbidden - SCA required");
    String challenge = exception.getChallenge();
    final HttpStatus status = HttpStatus.FORBIDDEN;
    return ResponseEntity.status(status)
        .header("x-ybs-sca-challenge", challenge)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .message("Strong customer authentication required")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.SCA_REQUIRED)
                        .message(exception.getMessage())
                        .build())
                .build());
  }

  @ExceptionHandler(InvalidPemKeyException.class)
  public ResponseEntity<ErrorResponse> readPemKey(
      final InvalidPemKeyException exception, final WebRequest request) {
    log.info("Invalid PEM Key. {}", exception.getMessage(), exception);
    HttpStatus badRequestStatusCode = HttpStatus.BAD_REQUEST;
    return ResponseEntity.status(badRequestStatusCode)
        .body(
            ErrorResponse.builder(badRequestStatusCode)
                .id(RequestIdHelper.getRequestId(request))
                .message("SCA key could not be read")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("Header.Invalid")
                        .message("SCA key must be in PEM format and Base64 encoded")
                        .path("x-ybs-sca-key")
                        .build())
                .build());
  }

  @ExceptionHandler(InvalidScaException.class)
  public ResponseEntity<ErrorResponse> invalidChallengeResponse(
      final InvalidScaException exception, final WebRequest request) {
    log.info("Invalid SCA information. {}", exception.getMessage(), exception);
    final HttpStatus status = HttpStatus.FORBIDDEN;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.ACCESS_DENIED)
                        .message("Access Denied")
                        .build())
                .build());
  }

  @ExceptionHandler(InvalidPasswordCharsScaException.class)
  public ResponseEntity<ErrorResponse> invalidPasswordCharsChallengeResponse(
      final InvalidPasswordCharsScaException exception, final WebRequest request) {
    log.info("Invalid SCA information. {}", exception.getMessage(), exception);
    final HttpStatus status = HttpStatus.FORBIDDEN;
    if (exception.getPasswordAttemptsRemaining() != null) {
      return ResponseEntity.status(status)
          .body(
              ErrorResponse.builder(status)
                  .id(RequestIdHelper.getRequestId(request))
                  .error(
                      ErrorResponse.ErrorItem.builder()
                          .errorCode(ErrorItem.ACCESS_DENIED)
                          .message("Access Denied")
                          .build())
                  .error(
                      ErrorResponse.ErrorItem.builder()
                          .errorCode(ErrorItem.PASSWORD_ATTEMPTS_REMAINING)
                          .message(
                              exception.getPasswordAttemptsRemaining() == 1
                                  ? "1 attempt remaining"
                                  : exception.getPasswordAttemptsRemaining()
                                      + " attempts remaining")
                          .build())
                  .build());
    } else {
      return ResponseEntity.status(status)
          .body(
              ErrorResponse.builder(status)
                  .id(RequestIdHelper.getRequestId(request))
                  .error(
                      ErrorResponse.ErrorItem.builder()
                          .errorCode(ErrorItem.ACCESS_DENIED)
                          .message("Access Denied")
                          .build())
                  .build());
    }
  }

  @ExceptionHandler(InvalidPaymentException.class)
  public ResponseEntity<ErrorResponse> handleInvalidPaymentException(
      final InvalidPaymentException exception, final WebRequest request) {
    log.info(
        "Invalid payment request: {}, reasons: {}", exception.getMessage(), exception.getReasons());
    final HttpStatus status = HttpStatus.CONFLICT;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .errors(
                    exception.getReasons().stream()
                        .map(this::buildErrorResponseItem)
                        .collect(Collectors.toList()))
                .build());
  }

  @ExceptionHandler(AccountValidatorException.class)
  public ResponseEntity<ErrorResponse> handleAccountValidatorException(
      final AccountValidatorException exception, final WebRequest request) {
    log.info("Invalid debtor details. {}", exception.getMessage(), exception);
    final HttpStatus status = HttpStatus.CONFLICT;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.PAYMENT_FAILURE_DEBTOR_ACCOUNT)
                        .message(
                            "Unable to send notification using the debtor account details provided")
                        .build())
                .build());
  }

  @ExceptionHandler(InternalAccountValidatorException.class)
  public ResponseEntity<ErrorResponse> handleInternalAccountValidatorException(
      final InternalAccountValidatorException exception, final WebRequest request) {
    log.info(
        "Invalid internal creditor details. {}, reasons: {}",
        exception.getMessage(),
        exception.getReason(),
        exception);
    final HttpStatus status =
        (exception.getReason() == InternalAccountValidatorException.Reason.ACCOUNT_NUMBER)
            ? HttpStatus.CONFLICT
            : HttpStatus.BAD_REQUEST;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.INTERNAL_PAYEE_INVALID)
                        .message(exception.getMessage())
                        .build())
                .build());
  }

  @ExceptionHandler(UnexpectedReferenceException.class)
  public ResponseEntity<ErrorResponse> unexpectedReference(
      final UnexpectedReferenceException exception, final WebRequest request) {
    log.info("Unexpected reference supplied. {}", exception.getMessage(), exception);
    final HttpStatus status = HttpStatus.BAD_REQUEST;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .message("Invalid request body")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_INVALID)
                        .message("Specifying a reference with a beneficiary is unsupported")
                        .path("reference")
                        .build())
                .build());
  }

  @ExceptionHandler(SaveBeneficiaryException.class)
  public ResponseEntity<ErrorResponse> saveBeneficiaryException(
      final SaveBeneficiaryException exception, final WebRequest request) {
    final String body = exception.getBody();
    final HttpStatus statusCode = exception.getStatusCode();

    if (HttpStatus.CONFLICT.equals(statusCode)) {
      return deserializeErrorResponse(body)
          .map(ResponseEntity::ok)
          .orElseGet(() -> technicalError(request, statusCode, body));
    }

    return technicalError(request, statusCode, body);
  }

  private ResponseEntity<ErrorResponse> technicalError(
      final WebRequest request, final HttpStatus statusCode, final String body) {
    log.error(
        "Unexpected response from account service when saving beneficiary [{}] {}",
        statusCode,
        body);

    return ResponseEntity.ok(
        ErrorResponse.builder(HttpStatus.INTERNAL_SERVER_ERROR)
            .id(RequestIdHelper.getRequestId(request))
            .message("Unable to save beneficiary")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.SAVE_BENEFICIARY_FAILED_TECHNICAL_ERROR)
                    .message("Unexpected error occurred when saving the beneficiary")
                    .build())
            .build());
  }

  private Optional<ErrorResponse> deserializeErrorResponse(final String body) {
    try {
      ErrorResponse response = objectMapper.readValue(body, ErrorResponse.class);
      return Optional.of(response);
    } catch (JsonProcessingException e) {
      return Optional.empty();
    }
  }

  private ErrorResponse.ErrorItem buildErrorResponseItem(
      final InvalidPaymentException.Reason reason) {
    return Optional.ofNullable(INVALID_PAYMENT_REASON_TO_ERROR_ITEM_MAPPER.get(reason))
        .orElseThrow(
            () ->
                new IllegalArgumentException(
                    "Don't know how to map reason to ErrorItem: " + reason));
  }
}
