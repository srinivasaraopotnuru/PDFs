package uk.co.ybs.digital.payment.audit.sca;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Sca.ScaBuilder.class)
public class Sca {

  @Schema(example = "EXEMPTED", required = true)
  private final DecisionStatus decisionStatus;

  @Schema(example = "LOWVAL")
  private final ExemptReasonCode exemptReasonCode;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ScaBuilder {}
}
