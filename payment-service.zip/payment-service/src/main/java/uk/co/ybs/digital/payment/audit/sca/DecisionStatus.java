package uk.co.ybs.digital.payment.audit.sca;

public enum DecisionStatus {
  APPLIED,
  EXEMPTED
}
