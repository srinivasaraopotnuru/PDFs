package uk.co.ybs.digital.payment.account;

public interface BeneficiaryVisitor<T> {
  T visit(ExternalBeneficiary beneficiary);

  T visit(InternalBeneficiary beneficiary);
}
