package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.time.LocalDate;
import lombok.Builder;
import lombok.Value;
import org.springframework.lang.Nullable;

@Value
@Builder
@JsonDeserialize(builder = WithdrawalLimit.WithdrawalLimitBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WithdrawalLimit {
  int permitted;
  int available;

  @Nullable LocalDate periodEnd;

  @JsonPOJOBuilder(withPrefix = "")
  public static class WithdrawalLimitBuilder {}
}
