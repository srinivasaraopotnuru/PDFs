package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.math.BigDecimal;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = DepositLimit.DepositLimitBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class DepositLimit {
  BigDecimal available;
  BigDecimal maxProductBalRemaining;

  @JsonPOJOBuilder(withPrefix = "")
  public static class DepositLimitBuilder {}
}
