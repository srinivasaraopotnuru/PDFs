package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import uk.co.ybs.digital.payment.validators.InternalAccountNumber;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails.InternalCreditorDetailsBuilder;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = InternalCreditorDetailsBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class InternalCreditorDetails {
  @NotNull(message = "You must specify a creditor account number")
  @InternalAccountNumber(
      message =
          "${validatedValue} is not an acceptable creditor account number; "
              + "value must be a 10-digit, YBS internal account number")
  @Schema(
      description = "The 10-digit account number of the account to credit",
      required = true,
      example = "0123456789")
  String accountNumber;

  @Schema(
      description =
          "Indicates that the the service should attempted to save the beneficiary if the payment succeeds")
  Boolean saveBeneficiary;

  public boolean shouldSaveBeneficiary() {
    return saveBeneficiary != null && saveBeneficiary;
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class InternalCreditorDetailsBuilder {}
}
