package uk.co.ybs.digital.payment.service;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.AccountValidatorException;
import uk.co.ybs.digital.payment.web.dto.Debtor;

@Component
@RequiredArgsConstructor
public class AccountValidator {
  @NonNull private final AccountService accountService;

  public Account validateDebtorAccount(final Debtor debtor, final RequestMetadata metadata) {
    final String accountNumber = debtor.getAccountNumber();
    try {
      return accountService.getAccount(accountNumber, metadata);
    } catch (AccountServiceEntityNotFoundException | AccountServiceEntityAccessDeniedException e) {
      throw new AccountValidatorException(
          String.format("Failed to find debtor account: %s", accountNumber), e);
    }
  }
}
