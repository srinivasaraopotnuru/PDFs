package uk.co.ybs.digital.payment.repository.aat;

import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.payment.model.aat.ScaLvtCount;

public interface LowValRepository extends JpaRepository<ScaLvtCount, Long> {}
