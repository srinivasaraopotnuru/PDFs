package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum WarningCategory {
  DEBTOR_WITHDRAWAL_ISA("debtor.withdrawal.isa"),
  DEBTOR_WITHDRAWAL_ISA_FLEXIBLE("debtor.withdrawal.isa.flexible"),
  DEBTOR_WITHDRAWAL_ISA_HELP_TO_BUY("debtor.withdrawal.isa.helptobuy"),
  DEBTOR_WITHDRAWAL_INTEREST_PENALTY("debtor.withdrawal.interest-penalty"),
  DEBTOR_WITHDRAWAL_DAYS("debtor.withdrawal.days");
  // If adding new creditor specific categories consider whether these need to be suppressed when
  // making internal
  // payment to YBS accounts not owned by the customer making the payment.

  @JsonValue private final String description;
}
