package uk.co.ybs.digital.payment.exception;

public class AccountServiceEntityNotFoundException extends AccountServiceException {
  private static final long serialVersionUID = 5504940736243267372L;

  public AccountServiceEntityNotFoundException(final String message) {
    super(message);
  }
}
