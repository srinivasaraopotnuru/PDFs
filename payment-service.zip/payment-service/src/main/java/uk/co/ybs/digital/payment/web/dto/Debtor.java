package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import uk.co.ybs.digital.payment.validators.InternalAccountNumber;

@Value
@Builder
@JsonDeserialize(builder = Debtor.DebtorBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Debtor {
  @NotNull(message = "You must specify a debtor account number")
  @InternalAccountNumber(
      message =
          "${validatedValue} is not an acceptable debtor account number; value must be a 10-digit, YBS internal account number")
  @Schema(
      description = "The 10-digit account number of the account to debit",
      required = true,
      example = "0123456789")
  String accountNumber;

  @JsonPOJOBuilder(withPrefix = "")
  public static class DebtorBuilder {}
}
