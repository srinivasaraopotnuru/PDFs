package uk.co.ybs.digital.payment.beneficiary;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
public class UpdateBeneficiaryException extends RuntimeException {
  private static final long serialVersionUID = 1L;
  private final HttpStatus statusCode;
  private final String body;
}
