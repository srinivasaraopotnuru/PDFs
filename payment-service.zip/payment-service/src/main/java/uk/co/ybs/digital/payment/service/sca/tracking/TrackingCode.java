package uk.co.ybs.digital.payment.service.sca.tracking;

import java.util.UUID;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class TrackingCode {
  private final UUID id;
  private final String code;
}
