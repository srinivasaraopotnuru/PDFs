package uk.co.ybs.digital.payment.exception;

public class BeneficiaryServiceEntityNotFoundException extends BeneficiaryServiceException {
  private static final long serialVersionUID = -4385677759604251722L;

  public BeneficiaryServiceEntityNotFoundException(final String message) {
    super(message);
  }
}
