package uk.co.ybs.digital.payment.service;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.AccountDetailsFilter;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.account.Balance;
import uk.co.ybs.digital.payment.account.Beneficiary;
import uk.co.ybs.digital.payment.account.BeneficiaryVisitor;
import uk.co.ybs.digital.payment.account.DepositLimit;
import uk.co.ybs.digital.payment.account.Deposits;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.account.InternalBeneficiary;
import uk.co.ybs.digital.payment.beneficiary.BeneficiaryService;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNoCustomerRelationshipException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.BeneficiaryServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.InvalidPaymentException;
import uk.co.ybs.digital.payment.exception.UnexpectedReferenceException;
import uk.co.ybs.digital.payment.model.adgcore.db.AccountPaymentDetails;
import uk.co.ybs.digital.payment.service.sca.ScaManager;
import uk.co.ybs.digital.payment.web.dto.Debtor;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorVisitor;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;

@Component
@Slf4j
@RequiredArgsConstructor
public class PaymentValidator {

  @NonNull private final AccountService accountService;
  @NonNull private final BeneficiaryService beneficiaryService;
  @NonNull private final BrandSortCodeMappings brandSortCodeMappings;
  @NonNull private final AccountPaymentDetailsService accountPaymentDetailsService;
  @NonNull private final BankAccountService bankAccountService;

  public ValidatedExternalPaymentRequest validatePayment(
      final ExternalPaymentRequest paymentRequest, final RequestMetadata metadata) {
    final Account debtorAccount = validateDebtorDetails(paymentRequest.getDebtor(), metadata);

    validatePaymentAmount(paymentRequest, debtorAccount);

    // Resolve the creditor after we've validated the debtor; this way, we know that any errors
    // retrieving the
    // beneficiary (if this payment has one) are due to the beneficiary not existing and not to do
    // with the debtor
    // account itself
    final ResolvedExternalCreditor resolvedCreditor =
        paymentRequest
            .getCreditor()
            .accept(new ResolveExternalCreditorVisitor(paymentRequest, metadata));

    final ExternalCreditorDetails externalCreditorDetails = resolvedCreditor.getCreditorDetails();
    validateExternalCreditor(externalCreditorDetails, metadata);

    return ValidatedExternalPaymentRequest.builder()
        .idempotencyKey(paymentRequest.getIdempotencyKey())
        .amount(paymentRequest.getAmount())
        .currency(paymentRequest.getCurrency())
        .debtorAccount(debtorAccount)
        .creditorDetails(externalCreditorDetails)
        .reference(resolvedCreditor.getReference())
        .beneficiary(resolvedCreditor.getBeneficiary())
        .build();
  }

  public void validateExternalCreditor(
      final ExternalCreditorDetails externalCreditor, final RequestMetadata metadata) {

    validateIsExternalSortCode(metadata.getBrandCode(), externalCreditor.getSortCode());

    // CREDITOR_SORTCODE
    if (!bankAccountService.validSortCode(externalCreditor.getSortCode())) {
      throw new InvalidPaymentException(
          "Creditor's Sort Code must be in sort code directory",
          InvalidPaymentException.Reason.CREDITOR_ACCOUNT);
    }
    // CREDITOR_MOD_7
    if (!bankAccountService.validAccount(
        externalCreditor.getSortCode(), externalCreditor.getExternalAccountNumber())) {
      throw new InvalidPaymentException(
          "Creditor's Account Number must be valid",
          InvalidPaymentException.Reason.CREDITOR_ACCOUNT);
    }

    // CREDITOR_FPSCHEME
    if (!bankAccountService.acceptsFasterPayments(externalCreditor.getSortCode())) {
      throw new InvalidPaymentException(
          "Creditor's Account must be an account that can receive an faster payments",
          InvalidPaymentException.Reason.CREDITOR_ACCOUNT);
    }
  }

  public ValidatedInternalPaymentRequest validatePayment(
      final InternalPaymentRequest paymentRequest, final RequestMetadata metadata) {
    // validate creditor / debtor not same.
    if (Objects.equals(
        paymentRequest.getDebtor().getAccountNumber(),
        paymentRequest.getCreditor().getAccountNumber())) {
      throw new InvalidPaymentException(
          String.format(
              "Debtor and creditor account are the same: %s",
              paymentRequest.getDebtor().getAccountNumber()),
          InvalidPaymentException.Reason.DEBTOR_AND_CREDITOR_ACCOUNT_SAME);
    }

    final Account debtorAccount = validateDebtorDetails(paymentRequest.getDebtor(), metadata);

    validatePaymentAmount(paymentRequest, debtorAccount);

    final InternalCreditorAccount internalCreditorDetails =
        validateInternalCreditorDetails(paymentRequest, metadata);

    return ValidatedInternalPaymentRequest.builder()
        .idempotencyKey(paymentRequest.getIdempotencyKey())
        .amount(paymentRequest.getAmount())
        .currency(paymentRequest.getCurrency())
        .debtorAccount(debtorAccount)
        .creditorAccount(internalCreditorDetails.getCreditorAccount())
        .build();
  }

  private Account validateDebtorDetails(final Debtor debtor, final RequestMetadata metadata) {
    final Account debtorAccount = getDebtorAccount(debtor, metadata);
    if (!debtorAccount.getWithdrawals().isPermittedOverApi()) {
      throw new InvalidPaymentException(
          String.format(
              "Debtor account %s withdrawals are not permitted over api",
              debtorAccount.getAccountNumber()),
          InvalidPaymentException.Reason.DEBTOR_ACCOUNT);
    }

    // DEBTOR_SORTCODE
    if (!brandSortCodeMappings.isSortCodeForBrand(
        metadata.getBrandCode(), debtorAccount.getAccountSortCode())) {
      throw new InvalidPaymentException(
          "Customers brand code must match account brand code",
          InvalidPaymentException.Reason.DEBTOR_ACCOUNT);
    }

    AccountPaymentDetails accountPaymentDetails =
        accountPaymentDetailsService.getAccountDetails(
            debtorAccount.getAccountNumber(), metadata.getPartyId());

    // DEBTOR_ACCOUNT_HOLDER_STATUS
    if (!accountPaymentDetails.getValidPaymentAccountHolderRole()) {
      throw new InvalidPaymentException(
          "Invalid Debtor's Account holder status", InvalidPaymentException.Reason.DEBTOR_ACCOUNT);
    }

    // DEBTOR_ACCOUNT_WITCODE
    if (!accountPaymentDetails.getValidWithdrawalCode()) {
      throw new InvalidPaymentException(
          "Invalid Withdrawal Instruction Type for Debtor Account",
          InvalidPaymentException.Reason.DEBTOR_ACCOUNT_MULTIPLE_SIGNATORIES_REQUIRED);
    }

    return debtorAccount;
  }

  public void validatePaymentAmount(
      final PaymentRequest paymentRequest, final Account debtorAccount) {
    final BigDecimal interimAvailableBalance =
        debtorAccount.getBalances().stream()
            .filter(balance -> "InterimAvailable".equals(balance.getType()))
            .findFirst()
            .map(Balance::getAmount)
            .orElseThrow(
                () ->
                    new IllegalArgumentException(
                        String.format(
                            "Failed to find Interim for account %s: %s",
                            debtorAccount, debtorAccount.getBalances())));

    // DEBTOR_AVAILABLE_BALANCE
    if (paymentRequest.getAmount().compareTo(interimAvailableBalance) > 0) {
      throw new InvalidPaymentException(
          "Payment amount must be less than or equal to Debtor's Available Balance",
          InvalidPaymentException.Reason.DEBTOR_ACCOUNT_INSUFFICIENT_FUNDS);
    }
  }

  private void validateIsExternalSortCode(final String brandCode, final String sortCode) {
    if (brandSortCodeMappings.isSortCodeForBrand(brandCode, sortCode)) {
      throw new InvalidPaymentException(
          String.format(
              "Creditor sort code %s is a %s internal sort code, so payment should be made with internal account number",
              sortCode, brandCode),
          InvalidPaymentException.Reason.CREDITOR_ACCOUNT_INTERNAL_SORT_CODE);
    }
  }

  private InternalCreditorAccount validateInternalCreditorDetails(
      final InternalPaymentRequest paymentRequest, final RequestMetadata metadata) {
    final InternalCreditorAccount creditorAccountDetails =
        getCreditorAccount(paymentRequest.getCreditor(), metadata);
    final Deposits deposits = creditorAccountDetails.getCreditorAccount().getDeposits();

    final String accountNumber = creditorAccountDetails.getCreditorAccount().getAccountNumber();
    final DepositLimit depositLimit = deposits.getLimit();
    final String partyId = metadata.getPartyId();

    if (!deposits.isPermittedOverApi()) {
      throw new InvalidPaymentException(
          String.format(
              "Creditor account %s deposits are not permitted over api",
              creditorAccountDetails.getCreditorAccount().getAccountNumber()),
          InvalidPaymentException.Reason.CREDITOR_ACCOUNT);
    }

    try {
      if (depositLimit != null) {

        if (depositLimit.getAvailable() != null
            && depositLimit.getAvailable().compareTo(paymentRequest.getAmount()) < 0) {
          final InvalidPaymentException.Reason reason;

          reason = InvalidPaymentException.Reason.CREDITOR_ACCOUNT_DEPOSIT_LIMIT;

          throw new InvalidPaymentException(
              String.format(
                  "Creditor account %s available deposit limit %s exceeded",
                  creditorAccountDetails.getCreditorAccount().getAccountNumber(),
                  depositLimit.getAvailable()),
              reason);
        }
        if (depositLimit.getMaxProductBalRemaining() != null
            && paymentRequest.getAmount().compareTo(depositLimit.getMaxProductBalRemaining()) > 0) {
          final InvalidPaymentException.Reason reason =
              InvalidPaymentException.Reason.CREDITOR_ACCOUNT_MAX_PRODUCT_BALANCE_EXCEEDED;

          throw new InvalidPaymentException(
              String.format(
                  "Creditor account %s maximum product balance %s exceeded amount being processed %s",
                  creditorAccountDetails.getCreditorAccount().getAccountNumber(),
                  depositLimit.getMaxProductBalRemaining(),
                  paymentRequest.getAmount()),
              reason);
        }
      }
    } catch (InvalidPaymentException invalidPaymentException) {
      if (creditorAccountDetails.isOtherAccount()) {
        // not the users account, stop data leaks
        log.info(
            "Hiding the failure reason as the creditor account: {} doesn't belong to the customer: {}",
            creditorAccountDetails.getCreditorAccount().getAccountNumber(),
            metadata.getPartyId());

        throw new InvalidPaymentException(
            invalidPaymentException.getMessage(), InvalidPaymentException.Reason.CREDITOR_ACCOUNT);
      }

      // report the original message
      throw invalidPaymentException;
    }

    return creditorAccountDetails;
  }

  private Account getDebtorAccount(final Debtor debtor, final RequestMetadata metadata) {
    final String accountNumber = debtor.getAccountNumber();
    try {
      return accountService.getAccount(accountNumber, metadata);
    } catch (AccountServiceEntityNotFoundException | AccountServiceEntityAccessDeniedException e) {
      throw new InvalidPaymentException(
          String.format("Failed to find debtor account: %s", accountNumber),
          InvalidPaymentException.Reason.DEBTOR_ACCOUNT,
          e);
    }
  }

  private InternalCreditorAccount getCreditorAccount(
      final InternalCreditorDetails creditorDetails, final RequestMetadata metadata) {
    final String accountNumber = creditorDetails.getAccountNumber();
    try {
      try {
        final Account account =
            accountService.getAccount(
                accountNumber,
                Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT),
                metadata);
        return new InternalCreditorAccount(account, false);
      } catch (AccountServiceEntityNoCustomerRelationshipException e) {
        log.info(
            "Invoke account details with 'otherAccount' filter for account: {}",
            creditorDetails.getAccountNumber());
        final Account account =
            accountService.getAccount(
                accountNumber,
                Arrays.asList(
                    AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT,
                    AccountDetailsFilter.OTHER_ACCOUNT),
                metadata);
        log.info(
            "Received account details response for creditor account: {} not owned by the customer: {}",
            creditorDetails.getAccountNumber(),
            metadata.getPartyId());
        return new InternalCreditorAccount(account, true);
      }
    } catch (AccountServiceEntityNotFoundException | AccountServiceEntityAccessDeniedException e) {
      throw new InvalidPaymentException(
          String.format("Failed to find creditor account: %s", accountNumber),
          InvalidPaymentException.Reason.CREDITOR_ACCOUNT,
          e);
    }
  }

  private ResolvedExternalCreditor resolveCreditorBeneficiary(
      final ExternalCreditorBeneficiary externalCreditorBeneficiary,
      final ExternalPaymentRequest request,
      final RequestMetadata metadata) {
    if (request.getReference() != null
        && !ScaManager.WEB_CHANNEL.equalsIgnoreCase(metadata.getChannel())) {
      throw new UnexpectedReferenceException(
          String.format("Request contains reference and beneficiary: %s", request));
    }
    final Beneficiary beneficiaryToMap =
        getBeneficiary(request.getDebtor(), externalCreditorBeneficiary, metadata);
    return mapBeneficiary(beneficiaryToMap, request);
  }

  private Beneficiary getBeneficiary(
      final Debtor debtor,
      final ExternalCreditorBeneficiary creditorBeneficiary,
      final RequestMetadata metadata) {
    final String accountNumber = debtor.getAccountNumber();
    final String beneficiaryId = creditorBeneficiary.getBeneficiaryId();
    try {
      return beneficiaryService.getBeneficiary(accountNumber, beneficiaryId, metadata);
    } catch (BeneficiaryServiceEntityNotFoundException e) {
      throw new InvalidPaymentException(
          String.format(
              "Failed to find creditor beneficiary: %s - account number: %s",
              beneficiaryId, accountNumber),
          InvalidPaymentException.Reason.CREDITOR_ACCOUNT,
          e);
    }
  }

  private ResolvedExternalCreditor mapBeneficiary(
      final Beneficiary beneficiary, final ExternalPaymentRequest request) {
    final ExternalBeneficiary externalBeneficiary =
        beneficiary.accept(new ExtractExternalBeneficiaryVisitor());
    final ExternalCreditorDetails creditor =
        ExternalCreditorDetails.builder()
            .externalAccountNumber(externalBeneficiary.getAccountNumber())
            .sortCode(externalBeneficiary.getAccountSortCode())
            .name(externalBeneficiary.getName())
            .build();

    if (request.getReference() != null) {
      return new ResolvedExternalCreditor(creditor, request.getReference(), externalBeneficiary);
    }

    return new ResolvedExternalCreditor(
        creditor, externalBeneficiary.getReference(), externalBeneficiary);
  }

  @AllArgsConstructor
  private class ResolveExternalCreditorVisitor
      implements ExternalCreditorVisitor<ResolvedExternalCreditor> {
    @NonNull private final ExternalPaymentRequest request;
    @NonNull private final RequestMetadata metadata;

    @Override
    public ResolvedExternalCreditor visit(final ExternalCreditorDetails creditorDetails) {
      return new ResolvedExternalCreditor(creditorDetails, request.getReference(), null);
    }

    @Override
    public ResolvedExternalCreditor visit(final ExternalCreditorBeneficiary creditorBeneficiary) {
      return resolveCreditorBeneficiary(creditorBeneficiary, request, metadata);
    }
  }

  private static class ExtractExternalBeneficiaryVisitor
      implements BeneficiaryVisitor<ExternalBeneficiary> {
    @Override
    public ExternalBeneficiary visit(final ExternalBeneficiary beneficiary) {
      return beneficiary;
    }

    @Override
    public ExternalBeneficiary visit(final InternalBeneficiary beneficiary) {
      throw new InvalidPaymentException(
          String.format(
              "External payment references internal beneficiary: %s",
              beneficiary.getBeneficiaryId()),
          InvalidPaymentException.Reason.CREDITOR_ACCOUNT);
    }
  }

  @Value
  private static class ResolvedExternalCreditor {
    @NonNull private final ExternalCreditorDetails creditorDetails;
    private final String reference;
    private final ExternalBeneficiary beneficiary;
  }

  @Value
  private static class InternalCreditorAccount {
    @NonNull private final Account creditorAccount;
    private final boolean otherAccount;
  }
}
