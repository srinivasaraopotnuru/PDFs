package uk.co.ybs.digital.payment.config;

import java.net.URL;
import lombok.AllArgsConstructor;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import uk.co.ybs.digital.payment.service.authentic.AuthenticServiceProperties;

@Configuration
@EnableConfigurationProperties(AuthenticServiceProperties.class)
@AllArgsConstructor
public class AuthenticConfig {

  private final AuthenticServiceProperties authenticServiceProperties;

  @Bean
  public WebClient authenticServiceWebClientWebAuth(final WebClient.Builder builder) {
    return buildWebClient(builder, authenticServiceProperties.getWebAuth().getUrl());
  }

  public WebClient buildWebClient(final WebClient.Builder builder, final URL url) {
    return builder
        .baseUrl(url.toString())
        .clientConnector(new ReactorClientHttpConnector(HttpClient.create().wiretap(true)))
        .build();
  }
}
