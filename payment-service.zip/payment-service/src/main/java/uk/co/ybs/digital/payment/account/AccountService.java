package uk.co.ybs.digital.payment.account;

import io.micrometer.core.annotation.Timed;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.logging.calls.CallLogged;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityAccessDeniedException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNoCustomerRelationshipException;
import uk.co.ybs.digital.payment.exception.AccountServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.AccountServiceException;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;

@Slf4j
@Component
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class AccountService {
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Account service returned error status: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";
  private static final String EMPTY_RESPONSE_ERROR_MESSAGE =
      "Empty response calling account service";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling account service";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private static final Predicate<HttpStatus> SUCCESS = HttpStatus::is2xxSuccessful;
  private static final Predicate<HttpStatus> NOT_SUCCESS = SUCCESS.negate();

  private final WebClient accountServiceWebClient;

  private static final String EMPTY_GET_GROUPED_ACCOUNTS_RESPONSE_ERROR_MESSAGE =
      "Empty response calling account service get grouped";

  private static final String UNEXPECTED_GET_GROUPED_ACCOUNTS_ERROR_MESSAGE =
      "Error calling account service get grouped";

  public Account getAccount(final String accountNumber, final RequestMetadata metadata) {
    return getAccount(accountNumber, Collections.emptyList(), metadata);
  }

  public Account getAccount(
      final String accountNumber,
      final List<AccountDetailsFilter> filters,
      final RequestMetadata metadata) {
    final String queryParameters;

    if (filters.isEmpty()) {
      queryParameters = "";
    } else {
      final List<String> includes =
          filters.stream().map(AccountDetailsFilter::getName).collect(Collectors.toList());
      queryParameters = "?include=" + String.join(",", includes);
    }

    final String uri = "/private/accounts/{accountNumber}" + queryParameters;

    final Supplier<String> entityDescription = () -> String.format("account %s", accountNumber);
    return get(AccountDetails.class, entityDescription, metadata, uri, accountNumber).getAccount();
  }

  public GroupedAccountListResponse getAccountGroup(final RequestMetadata metadata) {

    final String uri = "/private/accounts/grouped";

    final Supplier<String> entityDescription =
        () -> String.format("accounts", metadata.getPartyId());

    return getGrouped(GroupedAccountListResponse.class, entityDescription, metadata, uri);
  }

  public WithdrawalInterestPenalty getWithdrawalInterestPenalty(
      final String accountNumber,
      final BigDecimal withdrawalAmount,
      final RequestMetadata metadata) {
    final Supplier<String> entityDescription =
        () ->
            String.format(
                "withdrawal interest penalty for withdrawal of %s from account %s",
                withdrawalAmount, accountNumber);

    return get(
        WithdrawalInterestPenalty.class,
        entityDescription,
        metadata,
        "/private/accounts/{accountNumber}/withdrawal-interest-penalty?withdrawalAmount={withdrawalAmount}",
        accountNumber,
        withdrawalAmount);
  }

  private <T> T get(
      final Class<T> entityType,
      final Supplier<String> entityDescription,
      final RequestMetadata metadata,
      final String uri,
      final Object... uriVariables) {
    return accountServiceWebClient
        .get()
        .uri(uri, uriVariables)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + metadata.getForwardingAuth())
        .retrieve()
        .onStatus(
            NOT_SUCCESS, response -> handleHttpStatusError(response, metadata, entityDescription))
        .bodyToMono(entityType)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AccountServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new AccountServiceException(EMPTY_RESPONSE_ERROR_MESSAGE));
  }

  private <T> T getGrouped(
      final Class<T> entityType,
      final Supplier<String> entityDescription,
      final RequestMetadata metadata,
      final String uri) {
    return accountServiceWebClient
        .get()
        .uri(uri)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + metadata.getForwardingAuth())
        .retrieve()
        .onStatus(
            NOT_SUCCESS, response -> handleHttpStatusError(response, metadata, entityDescription))
        .bodyToMono(entityType)
        .onErrorMap(
            this::isUnhandledException,
            thrown ->
                new AccountServiceException(UNEXPECTED_GET_GROUPED_ACCOUNTS_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(
            () -> new AccountServiceException(EMPTY_GET_GROUPED_ACCOUNTS_RESPONSE_ERROR_MESSAGE));
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AccountServiceException);
  }

  private Mono<AccountServiceException> handleHttpStatusError(
      final ClientResponse clientResponse,
      final RequestMetadata metadata,
      final Supplier<String> entityDescription) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new AccountServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new AccountServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(errorResponse -> mapErrorResponse(status, errorResponse, metadata, entityDescription));
  }

  private AccountServiceException mapErrorResponse(
      final HttpStatus httpStatus,
      final ErrorResponse errorResponse,
      final RequestMetadata requestMetadata,
      final Supplier<String> entityDescription) {
    if (httpStatus == HttpStatus.FORBIDDEN
        && errorResponse.containsOnlyErrorCode(ErrorResponse.ErrorItem.ACCESS_DENIED)) {
      return new AccountServiceEntityAccessDeniedException(
          String.format(
              "Party %s is not allowed access %s",
              requestMetadata.getPartyId(), entityDescription.get()));
    } else if (httpStatus == HttpStatus.FORBIDDEN
        && errorResponse.containsOnlyErrorCode(ErrorResponse.ErrorItem.NO_CUSTOMER_RELATIONSHIP)) {
      return new AccountServiceEntityNoCustomerRelationshipException(
          String.format(
              "Party %s doesn't have customer relationship to access %s",
              requestMetadata.getPartyId(), entityDescription.get()));
    } else if (httpStatus == HttpStatus.NOT_FOUND
        && errorResponse.containsOnlyErrorCode(ErrorResponse.ErrorItem.RESOURCE_NOT_FOUND)) {
      return new AccountServiceEntityNotFoundException(
          String.format("Failed to find %s", entityDescription.get()));
    } else {
      return new AccountServiceException(
          String.format(
              HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
              httpStatus.value(),
              errorResponse));
    }
  }
}
