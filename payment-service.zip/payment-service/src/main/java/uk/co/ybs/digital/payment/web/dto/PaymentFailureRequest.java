package uk.co.ybs.digital.payment.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class PaymentFailureRequest {
  @Schema(
      description = "A UUID to identify this payment across multiple requests",
      required = true,
      example = "abcd1234-ab65-4f3e-a3d3-abcdef123456")
  @NotNull(message = "You must specify a UUID idempotency key")
  private final UUID idempotencyKey;

  @Schema(required = true)
  @Valid
  @NotNull(message = "You must specify the debtor details")
  private final Debtor debtor;
}
