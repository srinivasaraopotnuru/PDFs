package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.swagger.v3.oas.annotations.media.DiscriminatorMapping;
import io.swagger.v3.oas.annotations.media.Schema;

@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    property = "type",
    defaultImpl = ExternalCreditorDetails.class)
@JsonSubTypes({
  @JsonSubTypes.Type(name = "DETAILS", value = ExternalCreditorDetails.class),
  @JsonSubTypes.Type(name = "BENEFICIARY", value = ExternalCreditorBeneficiary.class)
})
@Schema(
    oneOf = {ExternalCreditorDetails.class, ExternalCreditorBeneficiary.class},
    discriminatorProperty = "type",
    discriminatorMapping = {
      @DiscriminatorMapping(value = "DETAILS", schema = ExternalCreditorDetails.class),
      @DiscriminatorMapping(value = "BENEFICIARY", schema = ExternalCreditorBeneficiary.class)
    })
public interface ExternalCreditor {
  <T> T accept(ExternalCreditorVisitor<T> visitor);
}
