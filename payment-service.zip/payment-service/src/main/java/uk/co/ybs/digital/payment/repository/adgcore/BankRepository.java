package uk.co.ybs.digital.payment.repository.adgcore;

import java.util.Map;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.payment.model.adgcore.BankDetails;

public interface BankRepository extends JpaRepository<BankDetails, String> {

  @Procedure(name = "SOA_VALIDATEBANKACCIDENTITY.PR_GET_BANK_DETAILS")
  Map<String, Object> getBankDetails(@Param("PN_SORT_CODE") Long sortCode);

  @Query(
      nativeQuery = true,
      value =
          "SELECT SOA_VALIDATEBANKACCIDENTITY.FN_VALIDATEBANKACCOUNTNUMBER(:sortCode, :accountNumber) FROM dual")
  String validateBankAccount(
      @Param("sortCode") Long sortCode, @Param("accountNumber") Long accountNumber);

  @Procedure(
      procedureName = "SOA_SAVINGACCPAYMENT_DATA.PR_ACCEPTS_FP",
      outputParameterName = "PS_ACCEPTS_FP")
  String acceptsFasterPayments(@Param("PS_SORT_CODE") String sortCode);
}
