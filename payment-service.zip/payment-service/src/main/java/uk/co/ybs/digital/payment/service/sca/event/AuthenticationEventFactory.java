package uk.co.ybs.digital.payment.service.sca.event;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.ExemptReasonCode;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;

@Component
@AllArgsConstructor
public class AuthenticationEventFactory {
  @NonNull private final ObjectMapper objectMapper;
  @NonNull private final EventContextFactory eventContextFactory;
  @NonNull private final PaymentPlaybackFactory paymentPlaybackFactory;

  public AuthenticationEvent createAuthenticationEvent(
      final ValidatedExternalPaymentRequest paymentRequest, final String channel) {
    final PaymentPlayback paymentPlayback =
        paymentPlaybackFactory.createPaymentPlayback(paymentRequest);
    return createAuthenticationEvent(paymentPlayback, paymentRequest.getIdempotencyKey(), channel);
  }

  public AuthenticationEvent createAuthenticationEvent(
      final ValidatedInternalPaymentRequest paymentRequest, final String channel) {
    final PaymentPlayback paymentPlayback =
        paymentPlaybackFactory.createPaymentPlayback(paymentRequest);
    return createAuthenticationEvent(paymentPlayback, paymentRequest.getIdempotencyKey(), channel);
  }

  public AuthenticationEvent createAuthenticationEvent(
      final ValidatedExternalPaymentRequest paymentRequest,
      final String channel,
      final DecisionStatus status,
      final ExemptReasonCode exemptReasonCode) {
    final PaymentPlayback paymentPlayback =
        paymentPlaybackFactory.createPaymentPlayback(paymentRequest);
    return createAuthenticationEvent(
        paymentPlayback, paymentRequest.getIdempotencyKey(), channel, status, exemptReasonCode);
  }

  public AuthenticationEvent createAuthenticationEvent(
      final ValidatedInternalPaymentRequest paymentRequest,
      final String channel,
      final DecisionStatus status,
      final ExemptReasonCode exemptReasonCode) {
    final PaymentPlayback paymentPlayback =
        paymentPlaybackFactory.createPaymentPlayback(paymentRequest);
    return createAuthenticationEvent(
        paymentPlayback, paymentRequest.getIdempotencyKey(), channel, status, exemptReasonCode);
  }

  private AuthenticationEvent createAuthenticationEvent(
      final PaymentPlayback paymentPlayback, final UUID idempotencyKey, final String channel) {

    return createAuthenticationEvent(paymentPlayback, idempotencyKey, channel, null, null);
  }

  private AuthenticationEvent createAuthenticationEvent(
      final PaymentPlayback paymentPlayback,
      final UUID idempotencyKey,
      final String channel,
      final DecisionStatus status,
      final ExemptReasonCode exemptReasonCode) {
    try {
      final UUID authenticationEventId = UUID.randomUUID();
      final String eventContextPayload =
          objectMapper.writeValueAsString(
              eventContextFactory.createSinglePaymentScaEventContext(
                  idempotencyKey, channel, status, exemptReasonCode));
      final String paymentPlayBackPayload = objectMapper.writeValueAsString(paymentPlayback);

      return AuthenticationEvent.builder()
          .id(authenticationEventId)
          .eventContext(eventContextPayload)
          .paymentPlayback(paymentPlayBackPayload)
          .build();
    } catch (JsonProcessingException e) {
      throw new AuthenticationEventCreationException(
          "Failed to serialize AuthenticationEvent parts", e);
    }
  }
}
