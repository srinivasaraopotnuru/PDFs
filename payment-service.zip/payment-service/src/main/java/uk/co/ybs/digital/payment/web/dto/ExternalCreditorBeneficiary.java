package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import uk.co.ybs.digital.payment.validators.NotAllWhitespace;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary.ExternalCreditorBeneficiaryBuilder;

@Value
@Builder
@JsonDeserialize(builder = ExternalCreditorBeneficiaryBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ExternalCreditorBeneficiary implements ExternalCreditor {
  @NotNull(message = "You must specify a beneficiaryId")
  @NotAllWhitespace(message = "BeneficiaryId must contain at least one non-whitespace character")
  @Schema(
      description = "The unique identifier of the beneficiary",
      required = true,
      example = "41fa68858a2429a9abb6c6f05fe02a3d217c66f7f0114aeeed035e42cd5996ca")
  String beneficiaryId;

  @Override
  public <T> T accept(final ExternalCreditorVisitor<T> visitor) {
    return visitor.visit(this);
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ExternalCreditorBeneficiaryBuilder {}
}
