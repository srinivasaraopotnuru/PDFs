package uk.co.ybs.digital.payment.exception;

public class EmailServiceException extends RuntimeException {
  private static final long serialVersionUID = -2689755010969656497L;

  public EmailServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }

  public EmailServiceException(final String message) {
    super(message);
  }
}
