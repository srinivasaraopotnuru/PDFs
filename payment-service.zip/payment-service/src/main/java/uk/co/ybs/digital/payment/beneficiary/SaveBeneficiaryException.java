package uk.co.ybs.digital.payment.beneficiary;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
public class SaveBeneficiaryException extends RuntimeException {
  private static final long serialVersionUID = 6982921735414111233L;
  private final HttpStatus statusCode;
  private final String body;
}
