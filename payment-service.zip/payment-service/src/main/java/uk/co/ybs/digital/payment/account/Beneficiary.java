package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@FieldDefaults(makeFinal = true, level = AccessLevel.PRIVATE)
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonSubTypes({
  @JsonSubTypes.Type(name = "EXTERNAL", value = ExternalBeneficiary.class),
  @JsonSubTypes.Type(name = "INTERNAL", value = InternalBeneficiary.class)
})
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public abstract class Beneficiary {
  String beneficiaryId;
  @NonNull String accountNumber;

  public abstract <T> T accept(BeneficiaryVisitor<T> visitor);
}
