package uk.co.ybs.digital.payment.web.dto;

public interface PaymentRequestVisitor<T> {
  T visit(ExternalPaymentRequest paymentRequest);

  T visit(InternalPaymentRequest paymentRequest);
}
