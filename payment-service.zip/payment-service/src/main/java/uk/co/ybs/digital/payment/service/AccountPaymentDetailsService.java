package uk.co.ybs.digital.payment.service;

import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PN_MIN_BAL;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_CUST_WARNINGS;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_PAYMENT_ACCHLDR_ROLE;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_PAYMENT_ACC_STATUS;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_VALID_WITCD;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.PS_WEB_ENABLED;
import static uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository.SOA_PAYACC_WARNINGS;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.payment.model.adgcore.db.AccountPaymentDetails;
import uk.co.ybs.digital.payment.model.adgcore.db.AccountPaymentDetails.PaymentAccountWarning;
import uk.co.ybs.digital.payment.repository.adgcore.AccountPaymentDetailsRepository;

@Service
@RequiredArgsConstructor
@Transactional(
    readOnly = true,
    propagation = Propagation.NEVER,
    transactionManager = "adgCoreTransactionManager")
public class AccountPaymentDetailsService {

  private final AccountPaymentDetailsRepository accountPaymentDetailsRepository;

  public AccountPaymentDetails getAccountDetails(
      final String accountNumber, final String partySysId) {

    Map<String, Object> outputParametersMap =
        accountPaymentDetailsRepository.getAccountDetails(
            Long.parseLong(accountNumber), Long.parseLong(partySysId));

    BigDecimal minimumBalance = (BigDecimal) outputParametersMap.get(PN_MIN_BAL);
    String paymentAccountStatus = (String) outputParametersMap.get(PS_PAYMENT_ACC_STATUS);
    String paymentAccountHolderRole = (String) outputParametersMap.get(PS_PAYMENT_ACCHLDR_ROLE);
    String validWithdrawalCode = (String) outputParametersMap.get(PS_VALID_WITCD);
    String webEnabled = (String) outputParametersMap.get(PS_WEB_ENABLED);
    String customerWarnings = (String) outputParametersMap.get(PS_CUST_WARNINGS);

    Object[] paymentAccountWarnings = (Object[]) outputParametersMap.get(SOA_PAYACC_WARNINGS);

    List<PaymentAccountWarning> paymentAccountWarningList =
        Stream.of(paymentAccountWarnings)
            .map(o -> (PaymentAccountWarning) o)
            .collect(Collectors.toList());

    return AccountPaymentDetails.builder()
        .minimumBalance(minimumBalance)
        .validPaymentAccountStatus("Valid".equalsIgnoreCase(paymentAccountStatus))
        .validPaymentAccountHolderRole("Valid".equalsIgnoreCase(paymentAccountHolderRole))
        .validWithdrawalCode("Valid".equalsIgnoreCase(validWithdrawalCode))
        .webEnabled("Yes".equalsIgnoreCase(webEnabled))
        .customerWarnings("Yes".equalsIgnoreCase(customerWarnings))
        .paymentAccountWarnings(paymentAccountWarningList)
        .build();
  }
}
