package uk.co.ybs.digital.payment.beneficiary;

import java.util.List;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import uk.co.ybs.digital.payment.account.Beneficiary;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorVisitor;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequestVisitor;

@Slf4j
public class IsTrustedBeneficiaryVisitor implements PaymentRequestVisitor<Boolean> {

  private final transient RequestMetadata requestMetadata;
  private final transient BeneficiaryService beneficiaryService;

  public IsTrustedBeneficiaryVisitor(
      final RequestMetadata requestMetadata, final BeneficiaryService beneficiaryService) {
    this.requestMetadata = requestMetadata;
    this.beneficiaryService = beneficiaryService;
  }

  @Override
  public Boolean visit(final ExternalPaymentRequest paymentRequest) {
    Optional<ExternalCreditorBeneficiary> externalBeneficiary =
        paymentRequest.getCreditor().accept(new ExternalBeneficiaryExtractor());
    return externalBeneficiary.isPresent();
  }

  @Override
  public Boolean visit(final InternalPaymentRequest paymentRequest) {
    final String debtorAccountNumber = paymentRequest.getDebtor().getAccountNumber();
    final String creditorAccountNumber = paymentRequest.getCreditor().getAccountNumber();
    List<Beneficiary> beneficiaries =
        beneficiaryService.getBeneficiariesByAccountNumber(debtorAccountNumber, requestMetadata);
    return beneficiaries.stream().anyMatch(b -> b.getAccountNumber().equals(creditorAccountNumber));
  }

  private static class ExternalBeneficiaryExtractor
      implements ExternalCreditorVisitor<Optional<ExternalCreditorBeneficiary>> {
    @Override
    public Optional<ExternalCreditorBeneficiary> visit(
        final ExternalCreditorDetails externalCreditorDetails) {
      return Optional.empty();
    }

    @Override
    public Optional<ExternalCreditorBeneficiary> visit(
        final ExternalCreditorBeneficiary externalCreditorBeneficiary) {
      return Optional.of(externalCreditorBeneficiary);
    }
  }
}
