package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = AccountDetails.AccountDetailsBuilder.class)
public class AccountDetails {
  private final Account account;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AccountDetailsBuilder {}
}
