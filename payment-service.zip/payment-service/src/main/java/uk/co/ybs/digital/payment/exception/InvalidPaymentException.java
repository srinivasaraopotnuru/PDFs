package uk.co.ybs.digital.payment.exception;

import java.util.Collections;
import java.util.SortedSet;
import java.util.TreeSet;
import lombok.Getter;
import lombok.NonNull;

@Getter
public class InvalidPaymentException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public enum Reason {
    DEBTOR_ACCOUNT,
    DEBTOR_ACCOUNT_INSUFFICIENT_FUNDS,
    DEBTOR_ACCOUNT_MULTIPLE_SIGNATORIES_REQUIRED,
    CREDITOR_ACCOUNT,
    CREDITOR_ACCOUNT_INTERNAL_SORT_CODE,
    CREDITOR_ACCOUNT_DEPOSIT_LIMIT,
    DEBTOR_AND_CREDITOR_ACCOUNT_SAME,
    CREDITOR_ACCOUNT_MAX_PRODUCT_BALANCE_EXCEEDED,

    // If adding new creditor specific reasons consider whether these need to be suppressed when
    // making internal
    // payment to YBS accounts not owned by the customer making the payment.
  }

  private final SortedSet<Reason> reasons;

  public InvalidPaymentException(@NonNull final String message, @NonNull final Reason reason) {
    this(message, reason, null);
  }

  public InvalidPaymentException(
      @NonNull final String message, @NonNull final Reason reason, final Throwable cause) {
    this(message, new TreeSet<>(Collections.singleton(reason)), cause);
  }

  public InvalidPaymentException(
      @NonNull final String message,
      @NonNull final SortedSet<Reason> reasons,
      final Throwable cause) {
    super(message, cause);
    this.reasons = reasons;
  }
}
