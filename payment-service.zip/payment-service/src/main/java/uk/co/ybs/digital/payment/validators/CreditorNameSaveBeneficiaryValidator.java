package uk.co.ybs.digital.payment.validators;

import java.util.Objects;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;

public class CreditorNameSaveBeneficiaryValidator
    implements ConstraintValidator<CreditorNameSaveBeneficiaryConstraint, ExternalCreditorDetails> {

  @Override
  public boolean isValid(
      final ExternalCreditorDetails externalCreditorDetails,
      final ConstraintValidatorContext context) {
    return !Objects.isNull(externalCreditorDetails.getName())
        || !externalCreditorDetails.shouldSaveBeneficiary();
  }
}
