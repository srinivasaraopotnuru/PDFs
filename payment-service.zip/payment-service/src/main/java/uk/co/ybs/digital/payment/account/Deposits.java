package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;
import org.springframework.lang.Nullable;

@Value
@Builder
@JsonDeserialize(builder = Deposits.DepositsBuilder.class)
public class Deposits {
  private final boolean permittedOverApi;

  @Nullable private final DepositLimit limit;

  @JsonPOJOBuilder(withPrefix = "")
  public static class DepositsBuilder {}
}
