package uk.co.ybs.digital.payment.exception;

public class AccountValidatorException extends RuntimeException {
  private static final long serialVersionUID = 1996180362411365544L;

  public AccountValidatorException(final String message) {
    super(message);
  }

  public AccountValidatorException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
