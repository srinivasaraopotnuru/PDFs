package uk.co.ybs.digital.payment.web.dto;

public interface CreditorVisitor<T> {
  T visit(ExternalCreditorDetails externalCreditorDetails);

  T visit(InternalAccountDetails internalAccountDetails);
}
