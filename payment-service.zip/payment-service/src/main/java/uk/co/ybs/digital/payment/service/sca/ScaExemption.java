package uk.co.ybs.digital.payment.service.sca;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.payment.audit.sca.ExemptReasonCode;
import uk.co.ybs.digital.payment.service.sca.tracking.TrackingCode;

@Value
@Builder
public class ScaExemption {
  @NonNull private final TrackingCode trackingCode;
  @NonNull private final ExemptReasonCode exemptReasonCode;
}
