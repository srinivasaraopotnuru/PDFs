package uk.co.ybs.digital.payment.exception;

import lombok.Getter;

@Getter
public class InternalAccountValidatorException extends RuntimeException {

  private static final long serialVersionUID = 6838671035539648491L;

  public enum Reason {
    ACCOUNT_NUMBER,
    PARTY_ID
  }

  private final Reason reason;

  public InternalAccountValidatorException(final String message, final Reason reason) {
    super(message);
    this.reason = reason;
  }

  public InternalAccountValidatorException(
      final String message, final Reason reason, final Throwable cause) {
    super(message, cause);
    this.reason = reason;
  }
}
