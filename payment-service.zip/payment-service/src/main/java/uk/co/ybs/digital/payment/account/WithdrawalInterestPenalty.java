package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.math.BigDecimal;
import lombok.Value;

@Value
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WithdrawalInterestPenalty {

  @JsonFormat(shape = JsonFormat.Shape.STRING)
  BigDecimal value;

  @JsonCreator
  public WithdrawalInterestPenalty(final BigDecimal value) {
    this.value = value;
  }
}
