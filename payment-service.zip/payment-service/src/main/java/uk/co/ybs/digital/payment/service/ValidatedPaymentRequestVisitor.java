package uk.co.ybs.digital.payment.service;

public interface ValidatedPaymentRequestVisitor<T> {
  T visit(ValidatedExternalPaymentRequest paymentRequest);

  T visit(ValidatedInternalPaymentRequest paymentRequest);
}
