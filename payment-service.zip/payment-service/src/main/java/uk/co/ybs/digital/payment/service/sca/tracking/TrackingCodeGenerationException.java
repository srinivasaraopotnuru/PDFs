package uk.co.ybs.digital.payment.service.sca.tracking;

public class TrackingCodeGenerationException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public TrackingCodeGenerationException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
