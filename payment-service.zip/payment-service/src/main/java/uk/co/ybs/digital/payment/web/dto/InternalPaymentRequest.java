package uk.co.ybs.digital.payment.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Jacksonized
public class InternalPaymentRequest extends PaymentRequest {

  @Valid
  @Schema(required = true)
  @NotNull(message = "You must specify the creditor")
  private final InternalCreditorDetails creditor;

  @Builder(toBuilder = true)
  public InternalPaymentRequest(
      final UUID idempotencyKey,
      final String currency,
      final BigDecimal amount,
      final Debtor debtor,
      final InternalCreditorDetails creditor) {
    super(idempotencyKey, currency, amount, debtor);
    this.creditor = creditor;
  }

  @Override
  public <T> T accept(final PaymentRequestVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
