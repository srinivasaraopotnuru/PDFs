package uk.co.ybs.digital.payment.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.payment.validators.InternalAccountNumber;

@Value
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class InternalAccountDetails implements Creditor {
  @NotNull(message = "You must specify an account number")
  @InternalAccountNumber(
      message =
          "${validatedValue} is not an acceptable internal account number;"
              + " value must be a 10-digit, YBS internal account number")
  @Schema(
      description = "The 10-digit account number of the account to validate",
      required = true,
      example = "0001234567")
  String accountNumber;

  @Override
  public <T> T accept(final CreditorVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
