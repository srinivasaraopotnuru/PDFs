package uk.co.ybs.digital.payment.exception;

import uk.co.ybs.digital.payment.service.authentic.AuthenticServiceException;

public class InitiatePaymentServiceException extends AuthenticServiceException {

  private static final long serialVersionUID = -8891361961013118219L;

  public InitiatePaymentServiceException(final String message) {
    super(message);
  }
}
