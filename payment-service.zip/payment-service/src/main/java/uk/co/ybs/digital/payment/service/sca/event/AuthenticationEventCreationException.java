package uk.co.ybs.digital.payment.service.sca.event;

public class AuthenticationEventCreationException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public AuthenticationEventCreationException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
