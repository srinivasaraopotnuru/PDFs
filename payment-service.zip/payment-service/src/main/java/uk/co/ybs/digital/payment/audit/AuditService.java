package uk.co.ybs.digital.payment.audit;

import io.micrometer.core.annotation.Timed;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.logging.calls.CallLogged;
import uk.co.ybs.digital.payment.exception.AuditServiceException;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;

@Component
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged
public class AuditService {
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling audit service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Audit service returned error status: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private final WebClient auditServiceWebClient;

  public void auditPaymentDecision(
      final AuditPaymentDecisionRequest request, final RequestMetadata metadata) {
    postAudit("/payment/decision", request, metadata);
  }

  public void auditPaymentAuthenticationSuccess(
      final AuditPaymentAuthSuccessRequest request, final RequestMetadata metadata) {
    postAudit("/payment/authentication/success", request, metadata);
  }

  public void auditPaymentAuthenticationFailure(
      final AuditPaymentAuthFailureRequest request, final RequestMetadata metadata) {
    postAudit("/payment/authentication/failure", request, metadata);
  }

  public void auditPaymentWithScaAccountLockedFailure(
      final AuditPaymentAccountLockedRequest request, final RequestMetadata metadata) {
    postAudit("/payment/authentication/account-locked", request, metadata);
  }

  public void linkPayment(final LinkPaymentRequest request, final RequestMetadata metadata) {
    postAudit("/payment/link", request, metadata);
  }

  public void auditPaymentFailure(
      final AuditPaymentFailureRequest request, final RequestMetadata metadata) {
    postAudit("/payment/failure", request, metadata);
  }

  private void postAudit(
      final String uri, final Object requestPayload, final RequestMetadata metadata) {
    auditServiceWebClient
        .post()
        .uri(uri)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + metadata.getForwardingAuth())
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(requestPayload)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .toBodilessEntity()
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AuditServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .block();
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AuditServiceException);
  }

  private Mono<AuditServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new AuditServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
