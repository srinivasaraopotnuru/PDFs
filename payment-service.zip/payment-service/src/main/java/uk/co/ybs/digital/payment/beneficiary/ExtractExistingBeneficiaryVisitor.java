package uk.co.ybs.digital.payment.beneficiary;

import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.account.Beneficiary;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.account.InternalBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorVisitor;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.InternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequestVisitor;

@Slf4j
@Component
public class ExtractExistingBeneficiaryVisitor
    implements PaymentRequestVisitor<Optional<Beneficiary>> {

  @Override
  public Optional<Beneficiary> visit(final ExternalPaymentRequest paymentRequest) {
    return paymentRequest
        .getCreditor()
        .accept(new ExternalCreditorExtractor())
        .map(
            details ->
                ExternalBeneficiary.builder()
                    .accountNumber(details.getExternalAccountNumber())
                    .accountSortCode(details.getSortCode())
                    .memorableName(details.getMemorableName())
                    .name(details.getName())
                    .reference(paymentRequest.getReference())
                    .build());
  }

  @Override
  public Optional<Beneficiary> visit(final InternalPaymentRequest paymentRequest) {

    return Optional.of(
        InternalBeneficiary.builder()
            .accountNumber(paymentRequest.getCreditor().getAccountNumber())
            .build());
  }

  private static class ExternalCreditorExtractor
      implements ExternalCreditorVisitor<Optional<ExternalCreditorDetails>> {
    @Override
    public Optional<ExternalCreditorDetails> visit(
        final ExternalCreditorDetails externalCreditorDetails) {
      return Optional.of(externalCreditorDetails);
    }

    @Override
    public Optional<ExternalCreditorDetails> visit(
        final ExternalCreditorBeneficiary externalCreditorBeneficiary) {
      return Optional.empty();
    }
  }
}
