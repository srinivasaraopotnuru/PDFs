package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.Value;
import uk.co.ybs.digital.payment.account.InternalBeneficiary.InternalBeneficiaryBuilder;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@JsonDeserialize(builder = InternalBeneficiaryBuilder.class)
public class InternalBeneficiary extends Beneficiary {

  @Builder
  public InternalBeneficiary(final String beneficiaryId, final String accountNumber) {
    super(beneficiaryId, accountNumber);
  }

  @Override
  public <T> T accept(final BeneficiaryVisitor<T> visitor) {
    return visitor.visit(this);
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class InternalBeneficiaryBuilder {}
}
