package uk.co.ybs.digital.payment.service;

import java.math.BigDecimal;
import java.util.UUID;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ValidatedExternalPaymentRequest extends ValidatedPaymentRequest {

  @NonNull ExternalCreditorDetails creditorDetails;

  String reference;

  ExternalBeneficiary beneficiary;

  @Builder
  @SuppressWarnings("PMD.ExcessiveParameterList")
  public ValidatedExternalPaymentRequest(
      final UUID idempotencyKey,
      final String currency,
      final BigDecimal amount,
      final Account debtorAccount,
      final ExternalCreditorDetails creditorDetails,
      final String reference,
      final ExternalBeneficiary beneficiary) {
    super(idempotencyKey, currency, amount, debtorAccount);
    this.creditorDetails = creditorDetails;
    this.reference = reference;
    this.beneficiary = beneficiary;
  }

  @Override
  public <T> T accept(final ValidatedPaymentRequestVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
