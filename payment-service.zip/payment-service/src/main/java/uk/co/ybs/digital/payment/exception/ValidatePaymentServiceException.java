package uk.co.ybs.digital.payment.exception;

public class ValidatePaymentServiceException extends RuntimeException {

  private static final long serialVersionUID = -7938804661467377948L;

  public ValidatePaymentServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
