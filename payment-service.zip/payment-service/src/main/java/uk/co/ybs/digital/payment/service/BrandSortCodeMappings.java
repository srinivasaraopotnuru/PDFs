package uk.co.ybs.digital.payment.service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.util.LinkedCaseInsensitiveMap;

@AllArgsConstructor
public class BrandSortCodeMappings {
  @NonNull private final LinkedCaseInsensitiveMap<List<String>> internalSortCodesByBrand;

  public boolean isSortCodeForBrand(final String brandCode, final String sortCode) {
    return Optional.ofNullable(internalSortCodesByBrand.get(brandCode))
        .orElseGet(Collections::emptyList)
        .contains(sortCode);
  }
}
