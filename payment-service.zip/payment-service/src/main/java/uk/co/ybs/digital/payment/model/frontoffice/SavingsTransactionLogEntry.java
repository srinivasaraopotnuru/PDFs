package uk.co.ybs.digital.payment.model.frontoffice;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenerationTime;
import uk.co.ybs.digital.payment.model.OracleSequence;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "E_SAVINGS_TRANSACTION_LOGS")
public class SavingsTransactionLogEntry {

  public static final String STATUS_WITHDRAWAL_START = "WITHDRAWAL_COMMENCE";
  public static final String STATUS_WITHDRAWAL_END = "WITHDRAWAL_COMPLETE";
  public static final String STATUS_WITHDRAWAL_FAILED = "WITHDRAWAL_FAILED";

  public static final String CLOSURE_NO = "N";

  public static final String TRANSFER_INDICATOR_INTERNAL = "I";
  public static final String TRANSFER_INDICATOR_EXTERNAL = "E";

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ESTL_SYSID_SEQ")
  @SequenceGenerator(sequenceName = "ESTL_SYSID_SEQ", allocationSize = 1, name = "ESTL_SYSID_SEQ")
  @EqualsAndHashCode.Include // Generated ids's are bad for equality in JPA, but nothing else unique
  private Long sysId;

  @Column(name = "ACCOUNT_NUMBER", nullable = false)
  private Long accountNumber;

  @Column(name = "TRANS_START_DATE", nullable = false)
  private LocalDateTime startTime;

  @Column(name = "TRANS_END_DATE")
  private LocalDateTime endTime;

  @Column(name = "TRANSFER_IND", nullable = false)
  private String transferIndicator;

  @Column(name = "TARGET_ACCOUNT_NUMBER", nullable = false)
  private Long targetAccountNumber;

  @Column(name = "BANK_SORT_CODE")
  private Integer bankSortCode;

  @Column(name = "BANK_ACC_NAME")
  private String bankAccountName;

  @Column(name = "BANK_REFERENCE")
  private String bankReference;

  @Column(name = "CLOSURE", nullable = false)
  private String closure;

  @Column(name = "AMOUNT", nullable = false)
  private BigDecimal amount;

  // Some nasty hibernate specific generator stuff because JPA doesn't support @GeneratedValue
  // on non 'Id' columns
  @OracleSequence(sequenceName = "ESTL_DAILY_SEQ_NUM", generationTime = GenerationTime.INSERT)
  @Column(name = "DAILY_SEQ_NUM", nullable = false, updatable = false)
  private Long dailySequenceNumber;

  @Column(name = "PARTY_SYSID", nullable = false)
  private Long partySysId;

  @Column(name = "STATUS")
  private String status;
}
