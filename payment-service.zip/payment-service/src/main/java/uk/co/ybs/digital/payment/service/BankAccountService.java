package uk.co.ybs.digital.payment.service;

import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.payment.exception.BankDetailsNotFoundException;
import uk.co.ybs.digital.payment.model.adgcore.BankDetails;
import uk.co.ybs.digital.payment.repository.adgcore.BankRepository;

@Service
@RequiredArgsConstructor
@Transactional(
    readOnly = true,
    propagation = Propagation.NEVER,
    transactionManager = "adgCoreTransactionManager")
public class BankAccountService {

  public static final String PACKAGE_ERROR_BANK_DETAILS_NOT_FOUND = "YBS-26779";

  private final BankRepository bankRepository;

  public boolean validSortCode(final String sortCode) {

    try {
      getBankDetails(sortCode);
    } catch (BankDetailsNotFoundException ex) {
      return false;
    }

    return true;
  }

  public boolean validAccount(final String sortCode, final String accountNumber) {

    String result =
        bankRepository.validateBankAccount(Long.parseLong(sortCode), Long.parseLong(accountNumber));

    return ("Y".equalsIgnoreCase(result));
  }

  public boolean acceptsFasterPayments(final String sortCode) {

    String result = bankRepository.acceptsFasterPayments(sortCode);

    return ("Y".equalsIgnoreCase(result));
  }

  @SuppressWarnings("UnusedReturnValue")
  public BankDetails getBankDetails(final String sortCode) {

    Map<String, Object> outputParametersMap;

    try {
      outputParametersMap = bankRepository.getBankDetails(Long.parseLong(sortCode));
    } catch (JpaSystemException ex) {
      if (ex.getCause().getCause().getMessage().contains(PACKAGE_ERROR_BANK_DETAILS_NOT_FOUND)) {
        throw new BankDetailsNotFoundException(
            String.format("Bank details not found for sortcode: %s", sortCode), ex);
      }
      throw ex;
    }

    final String name = (String) outputParametersMap.get("PS_BANK_NAME");
    final String branchTitle = (String) outputParametersMap.get("PS_BRANCH_TITLE");
    final String addressLine1 = (String) outputParametersMap.get("PS_BANK_ADD_LINE1");
    final String addressLine2 = (String) outputParametersMap.get("PS_BANK_ADD_LINE2");
    final String addressLine3 = (String) outputParametersMap.get("PS_BANK_ADD_LINE3");
    final String addressLine4 = (String) outputParametersMap.get("PS_BANK_ADD_LINE4");
    final String addressLine5 = (String) outputParametersMap.get("PS_BANK_ADD_LINE5");
    final String postcode = (String) outputParametersMap.get("PS_BANK_POSTCODE");
    final String telephoneNumber = (String) outputParametersMap.get("PS_BANK_TEL_NUM");

    return BankDetails.builder()
        .name(name)
        .branchTitle(branchTitle)
        .addressLine1(addressLine1)
        .addressLine2(addressLine2)
        .addressLine3(addressLine3)
        .addressLine4(addressLine4)
        .addressLine5(addressLine5)
        .postCode(postcode)
        .telephoneNumber(telephoneNumber)
        .build();
  }
}
