package uk.co.ybs.digital.payment.service;

import java.net.InetSocketAddress;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class SystemRequestMetadata {

  @NonNull UUID requestId;
  @NonNull InetSocketAddress host;
  @NonNull String brandCode;
  @ToString.Exclude @NonNull String forwardingAuth;
  @NonNull String ipAddress;
}
