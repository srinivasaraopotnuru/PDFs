package uk.co.ybs.digital.payment.service.authentic;

import com.authentic.OneOffPaymentReq;
import com.authentic.OneOffPaymentRequest;
import com.authentic.OneOffPaymentRes;
import com.authentic.OneOffTransferReq;
import com.authentic.OneOffTransferRequest;
import com.authentic.OneOffTransferRes;
import io.micrometer.core.annotation.Timed;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Clock;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.logging.calls.CallLogged;
import uk.co.ybs.digital.payment.exception.InitiatePaymentServiceException;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2e"})
@CallLogged(logParameters = true)
public class AuthenticService {

  private static final Locale LOCALE = Locale.ROOT;

  private static final String EMPTY_RESPONSE_MESSAGE = "Authentic service returned empty response";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling authentic service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Error calling authentic service: %s";

  private static final String ONE_OFF_PAYMENT_URI = "/oneoffpayment";
  private static final String ONE_OFF_TRANSFER_URI = "/oneofftransfer";

  private final Clock clock;
  private final WebClient authenticServiceWebClientWebAuth;

  public String initiatePayment(
      final ValidatedExternalPaymentRequest paymentRequest, final RequestMetadata metadata) {

    DateTimeFormatter requestIdFormatter =
        DateTimeFormatter.ofPattern("dHHmmssSSS").withZone(clock.getZone());

    DateTimeFormatter timestampFormatter =
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss").withZone(clock.getZone());

    Instant now = clock.instant();

    OneOffPaymentRequest.OneOffPaymentRequestBuilder payReq =
        OneOffPaymentRequest.builder()
            .functionid("7")
            .requestid(requestIdFormatter.format(now))
            .timestamp(timestampFormatter.format(now))
            .accnbr(paymentRequest.getDebtorAccount().getAccountNumber())
            .acctype("")
            .bin(setBin(metadata.getBrandCode()))
            .destacc(paymentRequest.getCreditorDetails().getExternalAccountNumber())
            .sortcode(paymentRequest.getCreditorDetails().getSortCode())
            .oneoffpaymentpayee(paymentRequest.getCreditorDetails().getName())
            .txnamt(formatCurrency(paymentRequest.getAmountWithExactly2DecimalPlaces()))
            .urn(
                String.format(
                    "%s-%s",
                    metadata.getChannel().toLowerCase(LOCALE), paymentRequest.getIdempotencyKey()))
            .ftrsource(setChannel(metadata.getChannel()));

    if (paymentRequest.getReference() != null && !paymentRequest.getReference().isEmpty()) {
      payReq.reference(paymentRequest.getReference());
    }

    OneOffPaymentReq request =
        OneOffPaymentReq.builder().oneoffpaymentrequest(payReq.build()).build();

    OneOffPaymentRes response =
        post(
            ONE_OFF_PAYMENT_URI, request, OneOffPaymentRes.class, authenticServiceWebClientWebAuth);

    if (!Optional.of(response).map(OneOffPaymentRes::getOneoffpaymentresponse).isPresent()) {
      throw new AuthenticServiceException(EMPTY_RESPONSE_MESSAGE);
    }

    if (!"0".equals(response.getOneoffpaymentresponse().getRespcode())) { // NOPMD
      throw new InitiatePaymentServiceException(
          "Initiate payment error: " + response.getOneoffpaymentresponse().getRespcode());
    }

    return response.getOneoffpaymentresponse().getAuthuid();
  }

  public String initiatePayment(
      final ValidatedInternalPaymentRequest paymentRequest, final RequestMetadata metadata) {

    DateTimeFormatter requestIdFormatter =
        DateTimeFormatter.ofPattern("dHHmmssSSS").withZone(clock.getZone());

    DateTimeFormatter timestampFormatter =
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss").withZone(clock.getZone());

    Instant now = clock.instant();

    OneOffTransferReq request =
        OneOffTransferReq.builder()
            .oneofftransferrequest(
                OneOffTransferRequest.builder()
                    .functionid("7")
                    .requestid(requestIdFormatter.format(now))
                    .timestamp(timestampFormatter.format(now))
                    .accnbr(paymentRequest.getDebtorAccount().getAccountNumber())
                    .acctype("")
                    .bin(setBin(metadata.getBrandCode()))
                    .destacc(paymentRequest.getCreditorAccount().getAccountNumber())
                    .txnamt(formatCurrency(paymentRequest.getAmountWithExactly2DecimalPlaces()))
                    .urn(
                        String.format(
                            "%s-%s",
                            metadata.getChannel().toLowerCase(LOCALE),
                            paymentRequest.getIdempotencyKey()))
                    .ftrsource(setChannel(metadata.getChannel()))
                    .build())
            .build();

    OneOffTransferRes response =
        post(
            ONE_OFF_TRANSFER_URI,
            request,
            OneOffTransferRes.class,
            authenticServiceWebClientWebAuth);

    if (!Optional.of(response).map(OneOffTransferRes::getOneofftransferresponse).isPresent()) {
      throw new AuthenticServiceException(EMPTY_RESPONSE_MESSAGE);
    }

    if (!"0".equals(response.getOneofftransferresponse().getRespcode())) { // NOPMD
      throw new InitiatePaymentServiceException(
          "Initiate payment error: " + response.getOneofftransferresponse().getRespcode());
    }

    return response.getOneofftransferresponse().getAuthuid();
  }

  public String formatCurrency(final BigDecimal amount) {
    return amount.multiply(new BigDecimal(100)).setScale(0, RoundingMode.HALF_DOWN).toString();
  }

  private String setBin(final String brandCode) {
    if ("YBS".equals(brandCode)) {
      return "564131";
    }
    if ("CHE".equals(brandCode)) {
      return "564137";
    }
    if ("AML".equals(brandCode)) {
      return "822222";
    }
    return null;
  }

  private String setChannel(final String channel) {
    if ("WEB".equals(channel)) {
      return "0790";
    }
    if ("API".equals(channel)) {
      return "0794";
    }
    if ("SAPP".equals(channel)) {
      return "0795";
    }
    return null;
  }

  @SuppressWarnings("SameParameterValue")
  private <T> T post(
      final String uri,
      final Object requestPayload,
      final Class<T> responseType,
      final WebClient webClient) {
    return webClient
        .post()
        .uri(uri)
        .accept(MediaType.APPLICATION_XML)
        .contentType(MediaType.APPLICATION_XML)
        .bodyValue(requestPayload)
        .exchangeToMono(
            response -> {
              if (response.statusCode() == HttpStatus.OK) {
                return response.bodyToMono(responseType);
              } else {
                throw new AuthenticServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, response.statusCode()));
              }
            })
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AuthenticServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new AuthenticServiceException(EMPTY_RESPONSE_MESSAGE));
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AuthenticServiceException);
  }
}
