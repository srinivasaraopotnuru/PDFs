package uk.co.ybs.digital.payment.web.dto;

public interface ExternalCreditorVisitor<T> {
  T visit(ExternalCreditorDetails externalCreditorDetails);

  T visit(ExternalCreditorBeneficiary externalCreditorBeneficiary);
}
