package uk.co.ybs.digital.payment.exception;

public class AuditServiceException extends RuntimeException {
  private static final long serialVersionUID = -4236723851684668459L;

  public AuditServiceException(final String message) {
    super(message);
  }

  public AuditServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
