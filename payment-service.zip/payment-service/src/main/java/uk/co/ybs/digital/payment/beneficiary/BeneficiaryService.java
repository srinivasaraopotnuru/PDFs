package uk.co.ybs.digital.payment.beneficiary;

import io.micrometer.core.annotation.Timed;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.logging.calls.CallLogged;
import uk.co.ybs.digital.payment.account.Beneficiary;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.exception.BeneficiaryServiceEntityNotFoundException;
import uk.co.ybs.digital.payment.exception.BeneficiaryServiceException;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.web.dto.ErrorResponse;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorBeneficiary;
import uk.co.ybs.digital.payment.web.dto.ExternalPaymentRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;

@Slf4j
@Component
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class BeneficiaryService {
  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling beneficiary service";
  private static final String EMPTY_RESPONSE_ERROR_MESSAGE =
      "Empty response calling beneficiary service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Beneficiary service returned error status: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private static final Predicate<HttpStatus> SUCCESS = HttpStatus::is2xxSuccessful;
  private static final Predicate<HttpStatus> NOT_SUCCESS = SUCCESS.negate();

  private final ExtractNewBeneficiaryVisitor extractNewBeneficiaryVisitor;
  private final WebClient beneficiaryServiceWebClient;
  private static final String BEARER_HEADER_VALUE = "Bearer ";
  private static final String EMPTY_GET_BENEFICIARIES_RESPONSE_ERROR_MESSAGE =
      "Empty response calling beneficiary service get beneficiaries by account number";

  private static final String UNEXPECTED_GET_BENEFICIARIES_ERROR_MESSAGE =
      "Error calling beneficiary service get beneficiaries by account number";

  public void saveBeneficiary(final PaymentRequest paymentRequest, final RequestMetadata metadata) {
    paymentRequest
        .accept(extractNewBeneficiaryVisitor)
        .ifPresent(
            beneficiary ->
                saveBeneficiary(
                    metadata, beneficiary, paymentRequest.getDebtor().getAccountNumber()));
  }

  private void saveBeneficiary(
      final RequestMetadata metadata, final Beneficiary beneficiary, final String accountNumber) {
    log.info("Saving beneficiary");
    beneficiaryServiceWebClient
        .post()
        .uri("/private/accounts/{accountNumber}/beneficiaries", accountNumber)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, BEARER_HEADER_VALUE + metadata.getForwardingAuth())
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(beneficiary)
        .exchange()
        .flatMap(this::handleSaveBeneficiaryResponse)
        .block();
  }

  private Mono<ErrorResponse> handleSaveBeneficiaryResponse(final ClientResponse response) {
    if (response.statusCode().is2xxSuccessful()) {
      return Mono.empty();
    }

    return response
        .bodyToMono(String.class)
        .switchIfEmpty(Mono.just(""))
        .flatMap(body -> Mono.error(new SaveBeneficiaryException(response.statusCode(), body)));
  }

  public void updateExternalBeneficiary(
      final ExternalPaymentRequest externalPaymentRequest, final RequestMetadata metadata) {
    ExternalCreditorBeneficiary externalCreditorBeneficiary =
        (ExternalCreditorBeneficiary) externalPaymentRequest.getCreditor();

    Beneficiary beneficiary =
        getBeneficiary(
            externalPaymentRequest.getDebtor().getAccountNumber(),
            externalCreditorBeneficiary.getBeneficiaryId(),
            metadata);

    ExternalBeneficiary externalBeneficiary = (ExternalBeneficiary) beneficiary;
    ExternalBeneficiary updatedExternalBeneficiary =
        updateExternalBeneficiaryReference(
            externalBeneficiary, externalPaymentRequest.getReference());

    updateExternalBeneficiary(
        metadata,
        updatedExternalBeneficiary,
        externalPaymentRequest.getDebtor().getAccountNumber());
  }

  private ExternalBeneficiary updateExternalBeneficiaryReference(
      final ExternalBeneficiary externalBeneficiary, final String reference) {
    return ExternalBeneficiary.builder()
        .beneficiaryId(externalBeneficiary.getBeneficiaryId())
        .accountNumber(externalBeneficiary.getAccountNumber())
        .accountSortCode(externalBeneficiary.getAccountSortCode())
        .name(externalBeneficiary.getName())
        .reference(reference)
        .memorableName(externalBeneficiary.getMemorableName())
        .build();
  }

  private void updateExternalBeneficiary(
      final RequestMetadata metadata,
      final ExternalBeneficiary externalBeneficiary,
      final String accountNumber) {
    log.info("Updating external beneficiary");
    beneficiaryServiceWebClient
        .put()
        .uri("/private/accounts/{accountNumber}/beneficiaries", accountNumber)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, BEARER_HEADER_VALUE + metadata.getForwardingAuth())
        .contentType(MediaType.APPLICATION_JSON)
        .bodyValue(externalBeneficiary)
        .exchange()
        .flatMap(this::handleUpdateExternalBeneficiaryResponse)
        .block();
  }

  private Mono<ErrorResponse> handleUpdateExternalBeneficiaryResponse(
      final ClientResponse response) {
    if (response.statusCode().is2xxSuccessful()) {
      return Mono.empty();
    }

    return response
        .bodyToMono(String.class)
        .switchIfEmpty(Mono.just(""))
        .flatMap(body -> Mono.error(new UpdateBeneficiaryException(response.statusCode(), body)));
  }

  public Beneficiary getBeneficiary(
      final String accountNumber, final String beneficiaryId, final RequestMetadata metadata) {
    final Supplier<String> entityDescription =
        () -> String.format("beneficiary %s for account %s", beneficiaryId, accountNumber);
    return get(
        Beneficiary.class,
        entityDescription,
        metadata,
        "/private/accounts/{accountNumber}/beneficiaries/{beneficiaryId}",
        accountNumber,
        beneficiaryId);
  }

  public List<Beneficiary> getBeneficiariesByAccountNumber(
      final String accountNumber, final RequestMetadata metadata) {

    Supplier<String> entityDescription =
        () -> String.format("beneficiaries for account %s", accountNumber);
    return getBeneficiaryList(
        entityDescription, metadata, "/accounts/{accountNumber}/beneficiaries", accountNumber);
  }

  private <T> T get(
      final Class<T> entityType,
      final Supplier<String> entityDescription,
      final RequestMetadata metadata,
      final String uri,
      final Object... uriVariables) {
    return beneficiaryServiceWebClient
        .get()
        .uri(uri, uriVariables)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, BEARER_HEADER_VALUE + metadata.getForwardingAuth())
        .retrieve()
        .onStatus(
            NOT_SUCCESS, response -> handleHttpStatusError(response, metadata, entityDescription))
        .bodyToMono(entityType)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new BeneficiaryServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new BeneficiaryServiceException(EMPTY_RESPONSE_ERROR_MESSAGE));
  }

  private List<Beneficiary> getBeneficiaryList(
      final Supplier<String> entityDescription,
      final RequestMetadata metadata,
      final String uri,
      final Object... uriVariables) {
    return beneficiaryServiceWebClient
        .get()
        .uri(uri, uriVariables)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, BEARER_HEADER_VALUE + metadata.getForwardingAuth())
        .retrieve()
        .onStatus(
            NOT_SUCCESS, response -> handleHttpStatusError(response, metadata, entityDescription))
        .bodyToMono(new ParameterizedTypeReference<List<Beneficiary>>() {})
        .onErrorMap(
            this::isUnhandledException,
            thrown ->
                new BeneficiaryServiceException(UNEXPECTED_GET_BENEFICIARIES_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(
            () -> new BeneficiaryServiceException(EMPTY_GET_BENEFICIARIES_RESPONSE_ERROR_MESSAGE));
  }

  private Mono<BeneficiaryServiceException> handleHttpStatusError(
      final ClientResponse clientResponse,
      final RequestMetadata metadata,
      final Supplier<String> entityDescription) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new BeneficiaryServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new BeneficiaryServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(errorResponse -> mapErrorResponse(status, errorResponse, metadata, entityDescription));
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof BeneficiaryServiceException);
  }

  private BeneficiaryServiceException mapErrorResponse(
      final HttpStatus httpStatus,
      final ErrorResponse errorResponse,
      final RequestMetadata requestMetadata,
      final Supplier<String> entityDescription) {
    if (httpStatus == HttpStatus.FORBIDDEN
        && errorResponse.containsOnlyErrorCode(ErrorResponse.ErrorItem.ACCESS_DENIED)) {
      return new BeneficiaryServiceException(
          String.format(
              "Party %s is not allowed access %s",
              requestMetadata.getPartyId(), entityDescription.get()));
    } else if (httpStatus == HttpStatus.NOT_FOUND
        && errorResponse.containsOnlyErrorCode(ErrorResponse.ErrorItem.RESOURCE_NOT_FOUND)) {
      return new BeneficiaryServiceEntityNotFoundException(
          String.format("Failed to find %s", entityDescription.get()));
    } else {

      return new BeneficiaryServiceException(
          String.format(
              HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
              httpStatus.value(),
              errorResponse));
    }
  }
}
