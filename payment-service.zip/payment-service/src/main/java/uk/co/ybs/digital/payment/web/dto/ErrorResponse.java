package uk.co.ybs.digital.payment.web.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import java.util.UUID;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Singular;
import lombok.Value;
import org.springframework.http.HttpStatus;

@Value
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonDeserialize(builder = ErrorResponse.ErrorResponseBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ErrorResponse {
  @NonNull UUID id;
  @NonNull String code;
  @NonNull String message;

  @Singular List<ErrorItem> errors;

  public boolean containsOnlyErrorCode(final String errorCode) {
    if (errors.size() == 1) {
      return errors.get(0).getErrorCode().equals(errorCode);
    }
    return false;
  }

  public static ErrorResponseBuilder builder() {
    return new ErrorResponseBuilder();
  }

  public static ErrorResponseBuilder builder(final HttpStatus status) {
    return builder()
        .code(String.format("%s %s", status.value(), status.getReasonPhrase()))
        .message(status.getReasonPhrase());
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ErrorResponseBuilder {}

  @Value
  @Builder
  @AllArgsConstructor(access = AccessLevel.PRIVATE)
  @JsonDeserialize(builder = ErrorItem.ErrorItemBuilder.class)
  @SuppressWarnings("PMD.CommentDefaultAccessModifier")
  public static class ErrorItem {
    public static final String ACCESS_DENIED = "AccessDenied";
    public static final String INVALID_REQUEST_SIGNATURE = "AccessDenied.InvalidRequestSignature";
    public static final String FIELD_INVALID = "Field.Invalid";
    public static final String TYPE_INVALID = "Type.Invalid";
    public static final String FIELD_MISSING = "Field.Missing";
    public static final String HEADER_INVALID = "Header.Invalid";
    public static final String HEADER_MISSING = "Header.Missing";
    public static final String RESOURCE_INVALID_FORMAT = "Resource.InvalidFormat";
    public static final String RESOURCE_NOT_FOUND = "Resource.NotFound";
    public static final String SCA_REQUIRED = "SCA.Required";
    public static final String UNAUTHORIZED = "Unauthorized";
    public static final String UNEXPECTED_ERROR = "UnexpectedError";
    public static final String UNSUPPORTED_METHOD = "Unsupported.Method";
    public static final String PAYMENT_REJECTED_CREDITOR_ACCOUNT =
        "PaymentRejected.CreditorAccount";
    public static final String PAYMENT_REJECTED_CREDITOR_ACCOUNT_DEPOSIT_LIMIT =
        "PaymentRejected.CreditorAccount.DepositLimit";
    public static final String PAYMENT_REJECTED_CREDITOR_ACCOUNT_INTERNAL_SORT_CODE =
        "PaymentRejected.CreditorAccount.InternalSortCode";
    public static final String PAYMENT_REJECTED_DEBTOR_ACCOUNT = "PaymentRejected.DebtorAccount";
    public static final String PAYMENT_REJECTED_DEBTOR_ACCOUNT_INSUFFICIENT_FUNDS =
        "PaymentRejected.DebtorAccount.InsufficientFunds";
    public static final String PAYMENT_REJECTED_DEBTOR_ACCOUNT_MULTIPLE_SIGNATORIES_REQUIRED =
        "PaymentRejected.DebtorAccount.MultipleSignatoriesRequired";
    public static final String PAYMENT_FAILURE_DEBTOR_ACCOUNT =
        "PaymentFailureNotification.DebtorAccount";
    public static final String PAYMENT_REJECTED_DEBTOR_AND_CREDITOR_ACCOUNT_SAME =
        "PaymentRejected.DebtorAndCreditorAccountSame";
    public static final String SAVE_BENEFICIARY_FAILED_TECHNICAL_ERROR =
        "Beneficiary.TechnicalError";
    public static final String NO_CUSTOMER_RELATIONSHIP = "AccessDenied.NoCustomerRelationship";
    public static final String INTERNAL_PAYEE_INVALID = "InternalPayee.Invalid";
    public static final String PASSWORD_ATTEMPTS_REMAINING = "AccessDenied.PwdAttemptsRemaining";

    @NonNull String errorCode;
    @NonNull String message;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    String path;

    @JsonPOJOBuilder(withPrefix = "")
    public static class ErrorItemBuilder {}
  }
}
