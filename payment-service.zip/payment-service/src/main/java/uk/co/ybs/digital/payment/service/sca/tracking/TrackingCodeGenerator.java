package uk.co.ybs.digital.payment.service.sca.tracking;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.MACSigner;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.service.sca.event.AuthenticationEvent;

@Component
@AllArgsConstructor
public class TrackingCodeGenerator {

  @NonNull private ObjectMapper objectMapper;

  public TrackingCode generateTrackingCode(final AuthenticationEvent event) {
    try {
      final UUID trackingId = event.getId();

      final JWSObject jwsObject =
          new JWSObject(
              new JWSHeader(JWSAlgorithm.HS256),
              new Payload(objectMapper.writeValueAsString(event)));

      // Apply the HMAC signing
      final JWSSigner signer = new MACSigner(trackingId.toString());
      jwsObject.sign(signer);

      return TrackingCode.builder().code(jwsObject.serialize(true)).id(trackingId).build();

    } catch (JsonProcessingException e) {
      throw new TrackingCodeGenerationException(
          "Failed to serialize AuthenticationEvent payload", e);
    } catch (JOSEException e) {
      // This should not be possible, but checked exception so needs handling
      throw new TrackingCodeGenerationException("Failed to sign JWS Object", e);
    }
  }
}
