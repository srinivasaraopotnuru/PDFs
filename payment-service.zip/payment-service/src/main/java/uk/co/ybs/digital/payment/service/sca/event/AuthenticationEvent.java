package uk.co.ybs.digital.payment.service.sca.event;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonPropertyOrder({"id", "eventContext", "paymentPlayback"})
@JsonInclude(JsonInclude.Include.NON_NULL)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuthenticationEvent {
  @JsonProperty(value = "Authentication Event Id")
  @NonNull
  private UUID id;

  @JsonProperty(value = "Event Context")
  @NonNull
  private String eventContext;

  @JsonProperty(value = "Payment Playback")
  @NonNull
  private String paymentPlayback;
}
