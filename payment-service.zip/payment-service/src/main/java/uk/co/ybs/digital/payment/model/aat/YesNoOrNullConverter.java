package uk.co.ybs.digital.payment.model.aat;

import javax.persistence.AttributeConverter;

public class YesNoOrNullConverter implements AttributeConverter<Boolean, String> {
  @Override
  public String convertToDatabaseColumn(final Boolean bool) {
    if (bool == null) {
      return null;
    }

    return bool ? "Y" : "N";
  }

  @Override
  public Boolean convertToEntityAttribute(final String value) {

    if (value == null) {
      return null;
    }

    return "Y".equalsIgnoreCase(value) ? true : false;
  }
}
