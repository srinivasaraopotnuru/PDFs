package uk.co.ybs.digital.payment.exception;

public class AccountServiceEntityAccessDeniedException extends AccountServiceException {
  private static final long serialVersionUID = -8874075807878666621L;

  public AccountServiceEntityAccessDeniedException(final String message) {
    super(message);
  }
}
