package uk.co.ybs.digital.payment.config.persistence.builder;

import com.zaxxer.hikari.HikariDataSource;
import java.util.Objects;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.With;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.util.StringUtils;

@With
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class HikariDataSourceBuilder {
  private DataSourceProperties dataSourceProperties;

  public HikariDataSource build() {
    Objects.requireNonNull(dataSourceProperties, "dataSourceProperties required");

    final HikariDataSource dataSource =
        dataSourceProperties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
    if (StringUtils.hasText(dataSourceProperties.getName())) {
      dataSource.setPoolName(dataSourceProperties.getName());
    }
    return dataSource;
  }
}
