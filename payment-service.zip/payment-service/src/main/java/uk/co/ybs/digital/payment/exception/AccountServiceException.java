package uk.co.ybs.digital.payment.exception;

public class AccountServiceException extends RuntimeException {
  private static final long serialVersionUID = 806903590743365338L;

  public AccountServiceException() {
    super();
  }

  public AccountServiceException(final String message) {
    super(message);
  }

  public AccountServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
