package uk.co.ybs.digital.payment.exception;

public class BeneficiaryServiceException extends RuntimeException {
  private static final long serialVersionUID = 5012258033642966229L;

  public BeneficiaryServiceException() {
    super();
  }

  public BeneficiaryServiceException(final String message) {
    super(message);
  }

  public BeneficiaryServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
