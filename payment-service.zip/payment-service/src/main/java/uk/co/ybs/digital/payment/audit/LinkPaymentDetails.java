package uk.co.ybs.digital.payment.audit;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import java.math.BigDecimal;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.payment.audit.sca.Sca;

@AllArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
@JsonTypeInfo(use = Id.NAME, property = "type")
@JsonSubTypes({
  @JsonSubTypes.Type(name = "EXTERNAL", value = LinkExternalPaymentDetails.class),
  @JsonSubTypes.Type(name = "INTERNAL", value = LinkInternalPaymentDetails.class)
})
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public abstract class LinkPaymentDetails {
  @NonNull private final UUID uniqueReference;

  @NonNull private final String transactionId;

  @NonNull private final BigDecimal amount;

  private final Sca sca;
}
