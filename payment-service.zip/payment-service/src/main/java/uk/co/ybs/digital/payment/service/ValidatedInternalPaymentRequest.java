package uk.co.ybs.digital.payment.service;

import java.math.BigDecimal;
import java.util.UUID;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;
import uk.co.ybs.digital.payment.account.Account;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ValidatedInternalPaymentRequest extends ValidatedPaymentRequest {
  @NonNull Account creditorAccount;

  @Builder
  public ValidatedInternalPaymentRequest(
      final UUID idempotencyKey,
      final String currency,
      final BigDecimal amount,
      final Account debtorAccount,
      final Account creditorAccount) {
    super(idempotencyKey, currency, amount, debtorAccount);
    this.creditorAccount = creditorAccount;
  }

  @Override
  public <T> T accept(final ValidatedPaymentRequestVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
