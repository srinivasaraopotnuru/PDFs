package uk.co.ybs.digital.payment.audit;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.math.BigDecimal;
import java.util.UUID;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;
import uk.co.ybs.digital.payment.audit.sca.Sca;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@JsonDeserialize(builder = LinkExternalPaymentDetails.LinkExternalPaymentDetailsBuilder.class)
public class LinkExternalPaymentDetails extends LinkPaymentDetails {
  @NonNull private final LinkExternalPaymentDetails.ExternalPaymentDebtor debtor;
  @NonNull private final ExternalPaymentCreditorDetails creditorDetails;

  private final String reference;

  @Builder
  @SuppressWarnings("PMD.ExcessiveParameterList")
  public LinkExternalPaymentDetails(
      final UUID uniqueReference,
      final String transactionId,
      final BigDecimal amount,
      final Sca sca,
      final ExternalPaymentDebtor debtor,
      final ExternalPaymentCreditorDetails creditorDetails,
      final String reference) {
    super(uniqueReference, transactionId, amount, sca);
    this.debtor = debtor;
    this.creditorDetails = creditorDetails;
    this.reference = reference;
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class LinkExternalPaymentDetailsBuilder {}

  @Value
  @Builder
  @JsonDeserialize(builder = ExternalPaymentDebtor.ExternalPaymentDebtorBuilder.class)
  public static class ExternalPaymentDebtor {
    @NonNull private final String accountNumber;

    @NonNull private final String sortCode;

    @JsonPOJOBuilder(withPrefix = "")
    public static class ExternalPaymentDebtorBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(
      builder = ExternalPaymentCreditorDetails.ExternalPaymentCreditorDetailsBuilder.class)
  public static class ExternalPaymentCreditorDetails {
    @NonNull private final String externalAccountNumber;

    @NonNull private final String sortCode;

    private final String name;

    private final ExternalCreditorBeneficiaryDetails beneficiary;

    @JsonPOJOBuilder(withPrefix = "")
    public static class ExternalPaymentCreditorDetailsBuilder {}

    @Value
    @Builder
    @JsonDeserialize(
        builder =
            ExternalCreditorBeneficiaryDetails.ExternalCreditorBeneficiaryDetailsBuilder.class)
    public static class ExternalCreditorBeneficiaryDetails {
      private final String memorableName;

      @JsonPOJOBuilder(withPrefix = "")
      public static class ExternalCreditorBeneficiaryDetailsBuilder {}
    }
  }
}
