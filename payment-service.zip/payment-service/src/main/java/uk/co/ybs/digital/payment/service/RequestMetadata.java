package uk.co.ybs.digital.payment.service;

import java.net.InetSocketAddress;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class RequestMetadata {
  @NonNull private SystemRequestMetadata systemRequestMetadata;
  private UserRequestMetadata userRequestMetadata;

  public UUID getRequestId() {
    return systemRequestMetadata.getRequestId();
  }

  public InetSocketAddress getHost() {
    return systemRequestMetadata.getHost();
  }

  public String getBrandCode() {
    return systemRequestMetadata.getBrandCode();
  }

  public String getForwardingAuth() {
    return systemRequestMetadata.getForwardingAuth();
  }

  public String getIpAddress() {
    return systemRequestMetadata.getIpAddress();
  }

  public String getChannel() {
    return userRequestMetadata.getChannel();
  }

  public UUID getSessionId() {
    return userRequestMetadata.getSessionId();
  }

  public String getPartyId() {
    return userRequestMetadata.getPartyId();
  }

  public String getTitle() {
    return userRequestMetadata.getTitle();
  }

  public String getEmail() {
    return userRequestMetadata.getEmail();
  }

  public String getSurname() {
    return userRequestMetadata.getSurname();
  }

  public boolean hasUserRequestMetadata() {
    return userRequestMetadata != null;
  }
}
