package uk.co.ybs.digital.payment.account;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary.ExternalBeneficiaryBuilder;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@JsonDeserialize(builder = ExternalBeneficiaryBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ExternalBeneficiary extends Beneficiary {

  @Builder
  public ExternalBeneficiary(
      final String beneficiaryId,
      final String accountNumber,
      final String accountSortCode,
      final String name,
      final String reference,
      final String memorableName) {
    super(beneficiaryId, accountNumber);
    this.accountSortCode = accountSortCode;
    this.name = name;
    this.reference = reference;
    this.memorableName = memorableName;
  }

  @NonNull String accountSortCode;
  @NonNull String name;
  String reference;
  String memorableName;

  @Override
  public <T> T accept(final BeneficiaryVisitor<T> visitor) {
    return visitor.visit(this);
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ExternalBeneficiaryBuilder {}
}
