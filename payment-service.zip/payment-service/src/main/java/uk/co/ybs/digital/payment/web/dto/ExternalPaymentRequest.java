package uk.co.ybs.digital.payment.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.payment.validators.AlphaNumeric;
import uk.co.ybs.digital.payment.validators.NotAllWhitespace;

@Value
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@Jacksonized
public class ExternalPaymentRequest extends PaymentRequest {

  @Schema(required = true)
  @Valid
  @NotNull(message = "You must specify the creditor")
  private final ExternalCreditor creditor;

  @Schema(description = "The payment reference (not blank)")
  @Size(max = 18, message = "Reference must not be more than 18 characters")
  @NotAllWhitespace(message = "Reference must contain at least one non-whitespace character.")
  @AlphaNumeric
  private final String reference;

  @Builder(toBuilder = true)
  public ExternalPaymentRequest(
      final UUID idempotencyKey,
      final String currency,
      final BigDecimal amount,
      final Debtor debtor,
      final ExternalCreditor creditor,
      final String reference) {
    super(idempotencyKey, currency, amount, debtor);
    this.creditor = creditor;
    this.reference = reference;
  }

  @Override
  public <T> T accept(final PaymentRequestVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
