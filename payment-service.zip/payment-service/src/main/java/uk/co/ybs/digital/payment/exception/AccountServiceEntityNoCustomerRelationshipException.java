package uk.co.ybs.digital.payment.exception;

public class AccountServiceEntityNoCustomerRelationshipException
    extends AccountServiceEntityAccessDeniedException {
  private static final long serialVersionUID = 3026289059964680421L;

  public AccountServiceEntityNoCustomerRelationshipException(final String message) {
    super(message);
  }
}
