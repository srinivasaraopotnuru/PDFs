package uk.co.ybs.digital.payment.account;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountSummary {

  @Schema(example = "Holiday")
  String accountName;

  @Schema(required = true, example = "1234567890")
  String accountNumber;

  @Schema(required = true, example = "123456")
  String accountSortCode;
}
