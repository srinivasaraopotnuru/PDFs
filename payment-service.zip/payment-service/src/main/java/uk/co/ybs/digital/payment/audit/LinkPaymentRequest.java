package uk.co.ybs.digital.payment.audit;

import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class LinkPaymentRequest {
  @NonNull UUID trackingId;

  @NonNull String trackingCode;

  @NonNull String ipAddress;

  @NonNull LinkPaymentDetails paymentDetails;
}
