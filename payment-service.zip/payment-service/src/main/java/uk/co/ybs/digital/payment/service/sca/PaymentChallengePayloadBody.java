package uk.co.ybs.digital.payment.service.sca;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PaymentChallengePayloadBody {

  // This class is used as a wrapper as if the PaymentRequest is used directly the object is not
  // serialized correctly due to the use of json subtypes. The idea of using a wrapper is taken
  // from the beneficiary services although that does have an extra property in the class of work
  // log type.
  @NonNull PaymentRequest paymentRequest;
}
