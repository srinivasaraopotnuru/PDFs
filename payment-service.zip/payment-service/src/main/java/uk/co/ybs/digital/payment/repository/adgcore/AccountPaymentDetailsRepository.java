package uk.co.ybs.digital.payment.repository.adgcore;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.logging.calls.CallLogged;
import uk.co.ybs.digital.payment.model.adgcore.db.PaymentAccountWarningMapper;
import uk.co.ybs.digital.payment.model.adgcore.db.SqlReturnStructArray;

@Slf4j
@Repository
@CallLogged(logParameters = true)
public class AccountPaymentDetailsRepository {

  public static final String PN_DEBTOR_ACC = "pn_debetor_acc";
  public static final String PN_PARTY_SYSID = "pn_party_sysid";
  public static final String PN_MIN_BAL = "pn_min_bal";
  public static final String PS_PAYMENT_ACC_STATUS = "ps_payment_acc_status";
  public static final String PS_PAYMENT_ACCHLDR_ROLE = "ps_payment_acchldr_role";
  public static final String SOA_PAYACC_WARNINGS = "soa_payacc_warnings";
  public static final String PS_VALID_WITCD = "ps_valid_witcd";
  public static final String PS_WEB_ENABLED = "ps_web_enabled";
  public static final String PS_CUST_WARNINGS = "ps_cust_warnings";
  public static final String PACKAGE_NAME = "SOA_SAVINGACCPAYMENT_DATA.PR_GET_ACC_PAY_DTLS";

  /*
   * The in memory H2 database used for tests does not support stored procedures with custom data types, so it is not
   * possible to easily test this repository. This will just be covered by E2E tests.
   */

  private final transient SimpleJdbcCall getAccountPaymentDetails;

  public AccountPaymentDetailsRepository(final DataSource adgCoreDataSource) {

    getAccountPaymentDetails =
        new SimpleJdbcCall(adgCoreDataSource)
            .withProcedureName(PACKAGE_NAME)
            .withoutProcedureColumnMetaDataAccess()
            .declareParameters(new SqlParameter(PN_DEBTOR_ACC, Types.NUMERIC))
            .declareParameters(new SqlParameter(PN_PARTY_SYSID, Types.NUMERIC))
            .declareParameters(new SqlOutParameter(PN_MIN_BAL, Types.NUMERIC))
            .declareParameters(new SqlOutParameter(PS_PAYMENT_ACC_STATUS, Types.VARCHAR))
            .declareParameters(new SqlOutParameter(PS_PAYMENT_ACCHLDR_ROLE, Types.VARCHAR))
            .declareParameters(
                new SqlOutParameter(
                    SOA_PAYACC_WARNINGS,
                    Types.ARRAY,
                    "SOA_TBL_PAYACC_WARNINGS",
                    new SqlReturnStructArray<>(new PaymentAccountWarningMapper())))
            .declareParameters(new SqlOutParameter(PS_VALID_WITCD, Types.VARCHAR))
            .declareParameters(new SqlOutParameter(PS_WEB_ENABLED, Types.VARCHAR))
            .declareParameters(new SqlOutParameter(PS_CUST_WARNINGS, Types.VARCHAR));
  }

  public Map<String, Object> getAccountDetails(final Long accountNumber, final Long partySysId) {

    Map<String, Object> in = new HashMap<>();
    in.put(PN_DEBTOR_ACC, accountNumber);
    in.put(PN_PARTY_SYSID, partySysId);

    try {

      return getAccountPaymentDetails.execute(in);

    } catch (UncategorizedSQLException e) {
      throw new AccountPaymentDetailsException(e.getSQLException().getMessage(), e);
    } catch (Exception e) {
      throw new AccountPaymentDetailsException(
          String.format(
              "An error occurred calling %s, AccountNumber: %s Party: %s",
              PACKAGE_NAME, accountNumber, partySysId),
          e);
    }
  }
}
