package uk.co.ybs.digital.payment.service.sca;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.payment.account.Account;
import uk.co.ybs.digital.payment.account.AccountService;
import uk.co.ybs.digital.payment.account.ExternalBeneficiary;
import uk.co.ybs.digital.payment.account.IsOwnAccountVisitor;
import uk.co.ybs.digital.payment.audit.AuditPaymentAccountLockedRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentAuthFailureRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentAuthSuccessRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentDecisionRequest;
import uk.co.ybs.digital.payment.audit.AuditPaymentFailureRequest;
import uk.co.ybs.digital.payment.audit.AuditService;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails.ExternalPaymentCreditorDetails;
import uk.co.ybs.digital.payment.audit.LinkExternalPaymentDetails.ExternalPaymentDebtor;
import uk.co.ybs.digital.payment.audit.LinkInternalPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkInternalPaymentDetails.InternalPaymentAccountDetails;
import uk.co.ybs.digital.payment.audit.LinkPaymentDetails;
import uk.co.ybs.digital.payment.audit.LinkPaymentRequest;
import uk.co.ybs.digital.payment.audit.SimplePaymentDetails;
import uk.co.ybs.digital.payment.audit.sca.DecisionStatus;
import uk.co.ybs.digital.payment.audit.sca.ExemptReasonCode;
import uk.co.ybs.digital.payment.audit.sca.Sca;
import uk.co.ybs.digital.payment.beneficiary.BeneficiaryService;
import uk.co.ybs.digital.payment.beneficiary.ExtractNewBeneficiaryVisitor;
import uk.co.ybs.digital.payment.beneficiary.IsTrustedBeneficiaryVisitor;
import uk.co.ybs.digital.payment.exception.AuditServiceException;
import uk.co.ybs.digital.payment.exception.ScaRequiredException;
import uk.co.ybs.digital.payment.model.aat.ScaLvtCount;
import uk.co.ybs.digital.payment.repository.aat.LowValRepository;
import uk.co.ybs.digital.payment.service.PaymentServiceProperties;
import uk.co.ybs.digital.payment.service.RequestMetadata;
import uk.co.ybs.digital.payment.service.ValidatedExternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedInternalPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedPaymentRequest;
import uk.co.ybs.digital.payment.service.ValidatedPaymentRequestVisitor;
import uk.co.ybs.digital.payment.service.sca.event.AuthenticationEvent;
import uk.co.ybs.digital.payment.service.sca.event.AuthenticationEventFactory;
import uk.co.ybs.digital.payment.service.sca.tracking.TrackingCode;
import uk.co.ybs.digital.payment.service.sca.tracking.TrackingCodeGenerator;
import uk.co.ybs.digital.payment.web.dto.ExternalCreditorDetails;
import uk.co.ybs.digital.payment.web.dto.PaymentFailureRequest;
import uk.co.ybs.digital.payment.web.dto.PaymentRequest;
import uk.co.ybs.digital.sca.exception.InvalidPasswordCharsScaException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;
import uk.co.ybs.digital.sca.service.ScaCredentials;
import uk.co.ybs.digital.sca.service.ScaPasswordCharsChallengeService;

@Component
@AllArgsConstructor
@Slf4j
public class ScaManager {
  private static final String CHALLENGE_FAILURE_TYPE = "CHALLENGE";
  private static final String CLIENT_FAILURE_TYPE = "CLIENT";

  private static final String PERMITTED_SCA_EXEMPTION_CHANNEL = "WEB";
  public static final String WEB_CHANNEL = "WEB";
  @NonNull private final AuditService auditService;
  @NonNull private AuthenticationEventFactory authenticationEventFactory;
  @NonNull private TrackingCodeGenerator trackingCodeGenerator;
  @NonNull private PaymentServiceProperties paymentServiceProperties;

  @NonNull private final ScaChallengeService scaChallengeService;
  @NonNull private final ScaPasswordCharsChallengeService scaPasswordCharsChallengeService;
  @NonNull private final LowValRepository lowValRepository;

  @NonNull private final AccountService accountService;

  @NonNull private final ExtractNewBeneficiaryVisitor extractNewBeneficiaryVisitor;

  @NonNull private final BeneficiaryService beneficiaryService;

  public Optional<ScaExemption> getExemption(
      final ValidatedPaymentRequest validatedPaymentRequest,
      final RequestMetadata requestMetadata,
      final PaymentRequest scaPaymentRequest) {
    BigDecimal lvtMaxAmount = paymentServiceProperties.getMaxLvtAmount();
    int lvtMaxCount = paymentServiceProperties.getMaxLvtCount();

    if (!PERMITTED_SCA_EXEMPTION_CHANNEL.equalsIgnoreCase(requestMetadata.getChannel())) {
      log.info(
          "SCA Exemptions not supported for channel {} - SCA required",
          requestMetadata.getChannel());
      callAuditWhenApplied(validatedPaymentRequest, requestMetadata);
    } else if (!paymentServiceProperties.isScaExemptionsEnabled()) {
      log.info("SCA Exemptions not enabled - SCA required");
      callAuditWhenApplied(validatedPaymentRequest, requestMetadata);
    } else if (isNewBeneficiary(scaPaymentRequest)) {
      log.info(
          "Payment for {} is not SCA exempt - SCA required. New Beneficiary",
          requestMetadata.getChannel());
      callAuditWhenApplied(validatedPaymentRequest, requestMetadata);
    } else if ((trustedBeneficiary(scaPaymentRequest, requestMetadata))) {
      ScaExemption scaExemption =
          getScaExemption(validatedPaymentRequest, requestMetadata, ExemptReasonCode.TRBENF);
      callAuditWhenExempt(validatedPaymentRequest, requestMetadata, scaExemption);
      return Optional.of(scaExemption);

    } else if (isOwnedAccount(validatedPaymentRequest, requestMetadata)) {
      ScaExemption scaExemption =
          getScaExemption(validatedPaymentRequest, requestMetadata, ExemptReasonCode.OACTRN);
      callAuditWhenExempt(validatedPaymentRequest, requestMetadata, scaExemption);
      return Optional.of(scaExemption);
    } else if ((validatedPaymentRequest.getAmount().compareTo(lvtMaxAmount) <= 0
        && scaLvtCountBelowThreshold(requestMetadata, lvtMaxCount))) {
      ScaExemption scaExemption =
          getScaExemption(validatedPaymentRequest, requestMetadata, ExemptReasonCode.LOWVAL);
      callAuditWhenExempt(validatedPaymentRequest, requestMetadata, scaExemption);
      return Optional.of(scaExemption);
    } else {
      log.info(
          "Payment for {} is not SCA exempt - SCA required", validatedPaymentRequest.getAmount());
      callAuditWhenApplied(validatedPaymentRequest, requestMetadata);
    }
    return Optional.empty();
  }

  private Boolean isOwnedAccount(
      final ValidatedPaymentRequest paymentRequest, final RequestMetadata requestMetadata) {
    IsOwnAccountVisitor isOwnAccountVisitor =
        new IsOwnAccountVisitor(requestMetadata, accountService);
    return paymentRequest.accept(isOwnAccountVisitor);
  }

  private Boolean isNewBeneficiary(final PaymentRequest paymentRequest) {
    return paymentRequest.accept(extractNewBeneficiaryVisitor).isPresent();
  }

  private boolean trustedBeneficiary(
      final PaymentRequest paymentRequest, final RequestMetadata requestMetadata) {

    IsTrustedBeneficiaryVisitor trustedBeneficiaryVisitor =
        new IsTrustedBeneficiaryVisitor(requestMetadata, beneficiaryService);
    return paymentRequest.accept(trustedBeneficiaryVisitor);
  }

  private boolean scaLvtCountBelowThreshold(
      final RequestMetadata requestMetadata, final int lvtMaxCount) {
    Long partyId = Long.parseLong(requestMetadata.getPartyId());
    Optional<ScaLvtCount> scaLvtCount = lowValRepository.findById(partyId);

    if (scaLvtCount.isPresent()) {
      if (scaLvtCount.get().getAccessedFlag()) {
        return scaLvtCount.filter(lvtCount -> lvtCount.getLvtCount() + 1 < lvtMaxCount).isPresent();
      }
      scaLvtCount.get().setAccessedFlag(true);
      lowValRepository.saveAndFlush(scaLvtCount.get());
      return scaLvtCount.filter(lvtCount -> lvtCount.getLvtCount() < lvtMaxCount).isPresent();
    } else {
      return true;
    }
  }

  private void callAuditWhenExempt(
      final ValidatedPaymentRequest paymentRequest,
      final RequestMetadata requestMetadata,
      final ScaExemption scaExemption) {
    final AuditPaymentDecisionRequest auditRequest =
        AuditPaymentDecisionRequest.builder()
            .paymentDetails(
                SimplePaymentDetails.builder()
                    .uniqueReference(paymentRequest.getIdempotencyKey())
                    .sca(
                        Sca.builder()
                            .decisionStatus(DecisionStatus.EXEMPTED)
                            .exemptReasonCode(scaExemption.getExemptReasonCode())
                            .build())
                    .build())
            .ipAddress(requestMetadata.getIpAddress())
            .build();
    auditService.auditPaymentDecision(auditRequest, requestMetadata);
  }

  private void callAuditWhenApplied(
      final ValidatedPaymentRequest paymentRequest, final RequestMetadata requestMetadata) {

    final AuditPaymentDecisionRequest auditRequest =
        AuditPaymentDecisionRequest.builder()
            .paymentDetails(
                SimplePaymentDetails.builder()
                    .uniqueReference(paymentRequest.getIdempotencyKey())
                    .sca(Sca.builder().decisionStatus(DecisionStatus.APPLIED).build())
                    .build())
            .ipAddress(requestMetadata.getIpAddress())
            .build();
    auditService.auditPaymentDecision(auditRequest, requestMetadata);
  }

  private ScaExemption getScaExemption(
      final ValidatedPaymentRequest paymentRequest,
      final RequestMetadata requestMetadata,
      final ExemptReasonCode exemptReasonCode) {
    log.info("Generating tracking code");
    final TrackingCode trackingCode =
        paymentRequest.accept(
            new GenerateAuthCodeRequestVisitor(
                requestMetadata, DecisionStatus.EXEMPTED, exemptReasonCode));

    return ScaExemption.builder()
        .exemptReasonCode(exemptReasonCode)
        .trackingCode(trackingCode)
        .build();
  }

  public TrackingCode generateAuthenticationCode(
      final ValidatedExternalPaymentRequest paymentRequest,
      final RequestMetadata requestMetadata,
      final DecisionStatus status,
      final ExemptReasonCode exemptReasonCode) {
    final AuthenticationEvent authenticationEvent =
        authenticationEventFactory.createAuthenticationEvent(
            paymentRequest, requestMetadata.getChannel(), status, exemptReasonCode);
    return generateAuthenticationCode(paymentRequest, authenticationEvent, requestMetadata, status);
  }

  public TrackingCode generateAuthenticationCode(
      final ValidatedInternalPaymentRequest paymentRequest,
      final RequestMetadata requestMetadata,
      final DecisionStatus status,
      final ExemptReasonCode exemptReasonCode) {
    final AuthenticationEvent authenticationEvent =
        authenticationEventFactory.createAuthenticationEvent(
            paymentRequest, requestMetadata.getChannel(), status, exemptReasonCode);
    return generateAuthenticationCode(paymentRequest, authenticationEvent, requestMetadata, status);
  }

  public TrackingCode generateAuthenticationCode(
      final ValidatedExternalPaymentRequest paymentRequest, final RequestMetadata requestMetadata) {
    final AuthenticationEvent authenticationEvent =
        authenticationEventFactory.createAuthenticationEvent(
            paymentRequest, requestMetadata.getChannel());
    return generateAuthenticationCode(
        paymentRequest, authenticationEvent, requestMetadata, DecisionStatus.APPLIED);
  }

  public TrackingCode generateAuthenticationCode(
      final ValidatedInternalPaymentRequest paymentRequest, final RequestMetadata requestMetadata) {
    final AuthenticationEvent authenticationEvent =
        authenticationEventFactory.createAuthenticationEvent(
            paymentRequest, requestMetadata.getChannel());
    return generateAuthenticationCode(
        paymentRequest, authenticationEvent, requestMetadata, DecisionStatus.APPLIED);
  }

  private TrackingCode generateAuthenticationCode(
      final ValidatedPaymentRequest paymentRequest,
      final AuthenticationEvent authenticationEvent,
      final RequestMetadata requestMetadata,
      final DecisionStatus status) {
    final TrackingCode trackingCode =
        trackingCodeGenerator.generateTrackingCode(authenticationEvent);

    if (!status.equals(DecisionStatus.EXEMPTED)) {

      final AuditPaymentAuthSuccessRequest auditRequest =
          AuditPaymentAuthSuccessRequest.builder()
              .paymentDetails(
                  SimplePaymentDetails.builder()
                      .uniqueReference(paymentRequest.getIdempotencyKey())
                      .build())
              .ipAddress(requestMetadata.getIpAddress())
              .trackingCode(trackingCode.getCode())
              .trackingId(trackingCode.getId())
              .build();
      auditService.auditPaymentAuthenticationSuccess(auditRequest, requestMetadata);
    }
    return trackingCode;
  }

  public void linkPayment(
      final String transactionId,
      final ValidatedExternalPaymentRequest paymentRequest,
      final TrackingCode trackingCode,
      final RequestMetadata requestMetadata,
      final Sca sca) {
    final Account debtorAccount = paymentRequest.getDebtorAccount();
    final ExternalCreditorDetails creditorDetails = paymentRequest.getCreditorDetails();

    final ExternalBeneficiary beneficiary = paymentRequest.getBeneficiary();
    final ExternalPaymentCreditorDetails.ExternalCreditorBeneficiaryDetails beneficiaryDetails =
        beneficiary != null
            ? ExternalPaymentCreditorDetails.ExternalCreditorBeneficiaryDetails.builder()
                .memorableName(beneficiary.getMemorableName())
                .build()
            : null;

    final LinkExternalPaymentDetails paymentDetails =
        LinkExternalPaymentDetails.builder()
            .amount(paymentRequest.getAmountWithExactly2DecimalPlaces())
            .creditorDetails(
                ExternalPaymentCreditorDetails.builder()
                    .externalAccountNumber(creditorDetails.getExternalAccountNumber())
                    .name(creditorDetails.getName())
                    .sortCode(creditorDetails.getSortCode())
                    .beneficiary(beneficiaryDetails)
                    .build())
            .sca(sca)
            .debtor(
                ExternalPaymentDebtor.builder()
                    .accountNumber(debtorAccount.getAccountNumber())
                    .sortCode(debtorAccount.getAccountSortCode())
                    .build())
            .reference(paymentRequest.getReference())
            .transactionId(transactionId)
            .uniqueReference(paymentRequest.getIdempotencyKey())
            .build();

    linkPayment(paymentDetails, trackingCode, requestMetadata);
  }

  public void linkPayment(
      final String transactionId,
      final ValidatedInternalPaymentRequest paymentRequest,
      final TrackingCode trackingCode,
      final RequestMetadata requestMetadata,
      final Sca sca) {
    final Account debtorAccount = paymentRequest.getDebtorAccount();
    final Account creditorAccount = paymentRequest.getCreditorAccount();

    final LinkInternalPaymentDetails paymentDetails =
        LinkInternalPaymentDetails.builder()
            .amount(paymentRequest.getAmountWithExactly2DecimalPlaces())
            .creditorDetails(
                InternalPaymentAccountDetails.builder()
                    .accountNumber(creditorAccount.getAccountNumber())
                    .build())
            .sca(sca)
            .debtor(
                InternalPaymentAccountDetails.builder()
                    .accountNumber(debtorAccount.getAccountNumber())
                    .build())
            .transactionId(transactionId)
            .uniqueReference(paymentRequest.getIdempotencyKey())
            .build();

    linkPayment(paymentDetails, trackingCode, requestMetadata);
  }

  private void linkPayment(
      final LinkPaymentDetails paymentDetails,
      final TrackingCode trackingCode,
      final RequestMetadata requestMetadata) {
    final LinkPaymentRequest request =
        LinkPaymentRequest.builder()
            .trackingId(trackingCode.getId())
            .trackingCode(trackingCode.getCode())
            .ipAddress(requestMetadata.getIpAddress())
            .paymentDetails(paymentDetails)
            .build();
    try {
      auditService.linkPayment(request, requestMetadata);
    } catch (final AuditServiceException e) {
      log.warn("Failed to link payment.  request: {}", request, e);
    }
  }

  public void handleInvalidPasswordCharsSca(
      final PaymentChallengePayloadBody request,
      final RequestMetadata metadata,
      final Integer passwordAttemptsRemaining) {
    handleInvalidSca(request, metadata);

    if (passwordAttemptsRemaining != null && passwordAttemptsRemaining == 0) {
      final AuditPaymentAccountLockedRequest auditPaymentAccountLockedRequest =
          AuditPaymentAccountLockedRequest.builder()
              .ipAddress(metadata.getIpAddress())
              .paymentDetails(
                  AuditPaymentAccountLockedRequest.PaymentFailureDetails.builder()
                      .uniqueReference(request.getPaymentRequest().getIdempotencyKey())
                      .debtorAccountNumber(
                          request.getPaymentRequest().getDebtor().getAccountNumber())
                      .build())
              .build();
      auditService.auditPaymentWithScaAccountLockedFailure(
          auditPaymentAccountLockedRequest, metadata);
    }
  }

  public void handleInvalidSca(
      final PaymentChallengePayloadBody request, final RequestMetadata metadata) {
    final AuditPaymentAuthFailureRequest auditPaymentAuthFailureRequest =
        AuditPaymentAuthFailureRequest.builder()
            .ipAddress(metadata.getIpAddress())
            .paymentDetails(
                AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                    .failureType(CHALLENGE_FAILURE_TYPE)
                    .uniqueReference(request.getPaymentRequest().getIdempotencyKey())
                    .debtorAccountNumber(request.getPaymentRequest().getDebtor().getAccountNumber())
                    .build())
            .build();
    auditService.auditPaymentAuthenticationFailure(auditPaymentAuthFailureRequest, metadata);
  }

  public void auditPaymentAuthFailure(
      final PaymentFailureRequest request, final RequestMetadata metadata) {
    final AuditPaymentAuthFailureRequest auditPaymentAuthFailureRequest =
        AuditPaymentAuthFailureRequest.builder()
            .ipAddress(metadata.getIpAddress())
            .paymentDetails(
                AuditPaymentAuthFailureRequest.PaymentFailureDetails.builder()
                    .failureType(CLIENT_FAILURE_TYPE)
                    .uniqueReference(request.getIdempotencyKey())
                    .debtorAccountNumber(request.getDebtor().getAccountNumber())
                    .build())
            .build();
    auditService.auditPaymentAuthenticationFailure(auditPaymentAuthFailureRequest, metadata);
  }

  public void auditPaymentFailure(
      final ValidatedPaymentRequest request,
      final TrackingCode trackingCode,
      final RequestMetadata metadata,
      final Sca sca) {
    final AuditPaymentFailureRequest auditPaymentFailureRequest =
        AuditPaymentFailureRequest.builder()
            .ipAddress(metadata.getIpAddress())
            .trackingCode(trackingCode.getCode())
            .trackingId(trackingCode.getId())
            .paymentDetails(
                SimplePaymentDetails.builder()
                    .uniqueReference(request.getIdempotencyKey())
                    .sca(sca)
                    .build())
            .build();

    auditService.auditPaymentFailure(auditPaymentFailureRequest, metadata);
  }

  @AllArgsConstructor
  private class GenerateAuthCodeRequestVisitor
      implements ValidatedPaymentRequestVisitor<TrackingCode> {
    @NonNull private final RequestMetadata requestMetadata;
    @NonNull private final DecisionStatus status;
    @NonNull private final ExemptReasonCode exemptReasonCode;

    @Override
    public TrackingCode visit(final ValidatedExternalPaymentRequest request) {
      return generateAuthenticationCode(request, requestMetadata, status, exemptReasonCode);
    }

    @Override
    public TrackingCode visit(final ValidatedInternalPaymentRequest request) {
      return generateAuthenticationCode(request, requestMetadata, status, exemptReasonCode);
    }
  }

  public void validatePaymentSca(
      final PaymentRequest paymentRequest,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {

    PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();

    try {
      validateSca(
          paymentChallengePayloadBody, PaymentChallengePayloadBody.class, metadata, scaCredentials);
    } catch (InvalidScaException exception) {
      handleInvalidSca(paymentChallengePayloadBody, metadata);
      throw exception;
    }
  }

  public void validatePaymentPasswordCharsSca(
      final PaymentRequest paymentRequest,
      final RequestMetadata metadata,
      final String passwordCharsChallengeResponse,
      final Jwt user) {

    PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();
    try {
      validatePasswordCharsSca(
          metadata.getRequestId().toString(),
          metadata.getBrandCode(),
          user,
          passwordCharsChallengeResponse);
    } catch (InvalidPasswordCharsScaException exception) {
      handleInvalidPasswordCharsSca(
          paymentChallengePayloadBody, metadata, exception.getPasswordAttemptsRemaining());
      throw exception;
    }
  }

  public ScaRequiredException generateScaRequiredException(
      final PaymentRequest paymentRequest, final RequestMetadata metadata, final Jwt user) {

    PaymentChallengePayloadBody paymentChallengePayloadBody =
        PaymentChallengePayloadBody.builder().paymentRequest(paymentRequest).build();
    if (WEB_CHANNEL.equalsIgnoreCase(metadata.getChannel())) {
      return new ScaRequiredException(
          scaPasswordCharsChallengeService.generateChallenge(
              metadata.getRequestId().toString(), metadata.getBrandCode(), user),
          "Please send the encrypted password characters in the x-ybs-sca-challenge-response header");
    } else {
      return new ScaRequiredException(
          scaChallengeService.generateChallenge(
              paymentChallengePayloadBody, metadata.getSessionId(), Duration.ofSeconds(60)),
          "Please sign the value in x-ybs-sca-challenge header with the request");
    }
  }

  private <T> void validateSca(
      final T challengePayloadBody,
      final Class<T> payloadBodyClass,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {

    scaChallengeService.validateChallenge(
        scaCredentials, challengePayloadBody, payloadBodyClass, metadata.getSessionId());
  }

  private void validatePasswordCharsSca(
      final String requestId,
      final String brandCode,
      final Jwt user,
      final String challengeResponse) {
    scaPasswordCharsChallengeService.validateChallenge(
        requestId, brandCode, user, challengeResponse);
  }
}
