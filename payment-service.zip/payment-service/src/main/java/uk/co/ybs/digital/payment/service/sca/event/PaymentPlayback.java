package uk.co.ybs.digital.payment.service.sca.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.time.LocalDate;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonPropertyOrder({"source", "payee", "amount", "reference", "instructionDate"})
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentPlayback {

  @JsonProperty(value = "Source")
  @NonNull
  private Source source;

  @JsonProperty(value = "Payee")
  @NonNull
  private Payee payee;

  @JsonProperty(value = "Payment Amount")
  @NonNull
  private Amount amount;

  @JsonProperty(value = "Reference")
  private String reference;

  @JsonProperty(value = "Instruction Date")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")
  @NonNull
  private LocalDate instructionDate;

  @Value
  @Builder
  @JsonPropertyOrder({"accountNumber", "sortCode"})
  @JsonInclude(JsonInclude.Include.NON_NULL)
  @SuppressWarnings("PMD.AvoidFieldNameMatchingTypeName")
  public static class Source {
    @JsonProperty(value = "Account Number")
    @NonNull
    private String accountNumber;

    @JsonProperty(value = "Sort Code")
    private String sortCode;
  }

  @Value
  @Builder
  @JsonPropertyOrder({"accountNumber", "sortCode", "name"})
  @JsonInclude(JsonInclude.Include.NON_NULL)
  @SuppressWarnings("PMD.AvoidFieldNameMatchingTypeName")
  public static class Payee {
    @JsonProperty(value = "Account Number")
    @NonNull
    private String accountNumber;

    @JsonProperty(value = "Sort Code")
    private String sortCode;
  }

  @Value
  @Builder
  @JsonPropertyOrder({"currency", "amount"})
  @JsonInclude(JsonInclude.Include.NON_NULL)
  @SuppressWarnings("PMD.AvoidFieldNameMatchingTypeName")
  public static class Amount {
    @JsonProperty(value = "Currency")
    @NonNull
    private String currency;

    /*
     * Use a String for the amount because of the crazy handling required for compatibility
     * with the batch process
     * (see PaymentPlaybackFactory)
     */
    @JsonProperty(value = "Amount")
    @NonNull
    private String amount;
  }
}
