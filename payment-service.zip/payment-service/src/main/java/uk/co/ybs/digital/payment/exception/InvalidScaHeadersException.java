package uk.co.ybs.digital.payment.exception;

import java.util.List;
import lombok.Getter;
import lombok.NonNull;

@Getter
public class InvalidScaHeadersException extends RuntimeException {
  private static final long serialVersionUID = 587493576717826087L;
  @NonNull private final List<String> missingHeaders;
  @NonNull private final List<String> requiredHeaders;

  public InvalidScaHeadersException(
      final String message,
      final @NonNull List<String> missingHeaders,
      final @NonNull List<String> requiredHeaders) {
    super(message);
    this.missingHeaders = missingHeaders;
    this.requiredHeaders = requiredHeaders;
  }
}
