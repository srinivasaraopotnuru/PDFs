#!/usr/bin/env bash
#echo `readlink /proc/$$/exe`
#On GitLab, this is: /bin/busybox i.e; not a full bash.

find_metadata() {
	grep -qE \
		-e "<APIProxy.*revision\s*=\s*\"\d+\"" \
		-e "<SharedFlowBundle.*revision\s*=\s*\"\d+\"" \
		-e "<CreatedBy>" \
		-e "<CreatedAt>" \
		-e "<LastModifiedAt>" \
		-e "<LastModifiedBy>" \
		-e "<ManifestVersion>" \
		-e "<HostedManifestVersion>" $@
}

ALL_FILES=$(echo apiproxies/*/*/*/*.xml sharedflows/*/*/*/*.xml)

exCode=1
parCmd=`xargs -0 < /proc/$PPID/cmdline`
if [[ "$0" == ".git/hooks/pre-commit" || "$parCmd" == *.git/hooks/pre-commit || "$1" == "fast" ]]; then
	if find_metadata $ALL_FILES; then
		echo found Apigee metadata in one or more bundles
		echo run sboot-tools/assurance/detect_apigee_metadata.bash for more information
	else
		exCode=0
	fi
else
	error=0
	for file in $ALL_FILES; do
		if find_metadata $file; then
			echo found Apigee metadata in $file
			error=1
		fi
	done

	if [[ $error -eq 0 ]]; then
		exCode=0
	fi
fi

if [[ $exCode -ne 0 ]]; then
	echo run sboot-tools/assurance/clean_apigee_metadata.bash to try and clean the metadata automatically
fi
exit $exCode