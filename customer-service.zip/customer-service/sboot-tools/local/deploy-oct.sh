#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd

if [ "" == "$AD_USERNAME" ]; then
  echo "INFO: Run: \`. ./sboot-tools/set-env.sh\` to persist env vars in this shell"
  . $gwd/sboot-tools/set-env.sh
fi

export DOCKER_IMG_VERSION=`cat $gwd/build/version.txt`
echo DOCKER_IMG_VERSION=$DOCKER_IMG_VERSION

$gwd/sboot-tools/pipeline/deploy-oc.sh
