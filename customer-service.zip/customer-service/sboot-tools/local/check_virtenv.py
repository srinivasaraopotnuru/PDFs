try:
    import requests
    import os

    if 'APIGEE_DEPLOY_ORG' not in os.environ:
        print('APIGEE_DEPLOY_ORG')

    elif 'APIGEE_DEPLOY_USER' not in os.environ:
        print('APIGEE_DEPLOY_USER')

    elif 'APIGEE_DEPLOY_PASSWORD_B64' not in os.environ:
        print('APIGEE_DEPLOY_PASSWORD')
    else:
        print('True')

except ImportError:
    print ('NoDependancies')