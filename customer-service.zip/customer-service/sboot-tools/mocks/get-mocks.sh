mkdir -p target
curl -X PUT "https://ds-mocks-dev.apps.ostest.ybs.com/mockserver/retrieve?format=json&type=active_expectations" > target/expectations.txt
