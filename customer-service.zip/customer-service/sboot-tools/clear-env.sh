##############################
#This should be called from the parent shell using source (.) e.g:
#'. clear-env.sh'
##############################
#This clears values set by the set-env script, so that set-env can be run again.

export AD_USERNAME=
export AD_PASSWORD=
export AD_PASSWORD_B64=

if ls *.code-workspace 1> /dev/null 2>&1; then
  #Reverse ignore updates to the VSCode workspace file
  git update-index --no-skip-worktree *.code-workspace
fi