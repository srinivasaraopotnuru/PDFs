class MockLoader:

  def __init__(self):
    pass

  def load_mock(self, mock_name):
    with open('mocks/' + mock_name) as f:
      file_data = f.read()
    return file_data
