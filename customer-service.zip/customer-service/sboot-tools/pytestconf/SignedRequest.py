import requests

import importlib
globconf = importlib.import_module("sboot-tools.pytestconf.globconf")
Signer = getattr(importlib.import_module("sboot-tools.pytestconf.signer"), "Signer")

import ecdsa
import hashlib
from urllib.parse import urlparse

class SignedRequest:

    def __init__(self, url, app_name, app_type="default", verb="GET", headers=None, data=None, signed=False, proxies=None):
      uri_dict = urlparse(url)
      host = uri_dict.hostname
      if uri_dict.port is not None:
         host += ":" + str(uri_dict.port)
      self.sig_key_id = globconf.get_client_credentials(app_name, app_type)['sig_key_id']
      self.sig_prv_key = globconf.get_client_credentials(app_name, app_type)['sig_prv_key']
      headers['x-ybs-request-signature-key-id'] = self.sig_key_id
      headers['Host'] = host
      #Prepare request
      self.req = requests.Request(
        verb,
        url,
        data=data,
        headers=headers).prepare()
      print("req.URL: ", self.req.url)

    def send(self, signed : bool, proxies=None, ref_client_cert=None):

      if signed:
        signer = Signer({self.sig_key_id: ecdsa.SigningKey.from_pem(self.sig_prv_key, hashlib.sha256)})
        signer.sign_request(self.req)
      resp = requests.session().send(
        self.req,
        proxies=proxies,
        allow_redirects=False,
        verify=False)
      return resp
