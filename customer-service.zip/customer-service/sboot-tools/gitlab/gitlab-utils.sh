#!/usr/bin/env bash

# Function to get all GitLab groups and store as GROUP_IDS
GetAllGroups() {
  # Inside docs
  PAGE_COUNT=1
  HTTP_CODE=200
  RESPONSE_JSON=""
  while [ "$HTTP_CODE" = "200" ] && [ "$RESPONSE_JSON" != "[]" ]
  do
    HTTP_RESP=$(curl -ks --write-out ''%{http_code}'' --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/groups?page=$PAGE_COUNT&per_page=80&statistics=true&all_available=true")
    HTTP_CODE="${HTTP_RESP:${#HTTP_RESP}-3}"
    RESPONSE_JSON="${HTTP_RESP:0:${#HTTP_RESP}-3}"
    echo "$RESPONSE_JSON" > "target/groups$PAGE_COUNT.json"
    PAGE_COUNT=$((PAGE_COUNT +1))
  done
  GROUP_IDS=$(jq -s 'add' target/groups*.json | jq '.[] | .id')
}

# Function to get all GitLab projects and store as PROJ_IDS
GetAllProjects() {
  # $1 = Extra query params
  QUERY_PARAMS="$1"
  PAGE_COUNT=1
  HTTP_CODE=200
  RESPONSE_JSON=""
  while [ "$HTTP_CODE" = "200" ] && [ "$RESPONSE_JSON" != "[]" ]
  do
    HTTP_RESP=$(curl -ks --write-out ''%{http_code}'' --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects?page=$PAGE_COUNT&per_page=80$QUERY_PARAMS")
    HTTP_CODE="${HTTP_RESP:${#HTTP_RESP}-3}"
    RESPONSE_JSON="${HTTP_RESP:0:${#HTTP_RESP}-3}"
    echo "$RESPONSE_JSON" > "target/projs$PAGE_COUNT.json"
    PAGE_COUNT=$((PAGE_COUNT +1))
  done
  PROJ_IDS=$(jq -s 'add' target/projs*.json | jq '.[] | .id')
}

# Function to get all GitLab projects (filtered to YBS domain projects) and store as PROJ_IDS
GetAllDomainProjects() {
  GetAllProjects "$@"
  #Filter projects to just business domains
  PROJ_IDS=$(jq -s 'add' target/projs*.json | jq '.[]
   | select(.namespace.path == "enterprise"
       or .namespace.path == "calculators"
       or .namespace.path == "config"
       or .namespace.path == "customer"
       or .namespace.path == "digital-apis"
       or .namespace.path == "idam"
       or .namespace.path == "mortgages"
       or .namespace.path == "operations"
       or .namespace.path == "savings"
       or .namespace.path == "savings-app"
       or .namespace.path == "security"
       or .namespace.path == "utilities")
   | .id')
}

# Function to get all GitLab users and store as USER_IDS
GetAllUsers() {
  PAGE_COUNT=1
  HTTP_CODE=200
  RESPONSE_JSON=""
  while [ "$HTTP_CODE" = "200" ] && [ "$RESPONSE_JSON" != "[]" ]
  do
    HTTP_RESP=$(curl -ks --write-out ''%{http_code}'' --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/users?page=$PAGE_COUNT&per_page=80&statistics=true")
    HTTP_CODE="${HTTP_RESP:${#HTTP_RESP}-3}"
    RESPONSE_JSON="${HTTP_RESP:0:${#HTTP_RESP}-3}"
    echo "$RESPONSE_JSON" > "target/users$PAGE_COUNT.json"
    PAGE_COUNT=$((PAGE_COUNT +1))
  done
  USER_IDS=$(jq -s 'add' target/users*.json | jq '.[] | .id')
}
