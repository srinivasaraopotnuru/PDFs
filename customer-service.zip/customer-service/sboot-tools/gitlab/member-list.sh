#!/usr/bin/env bash
set -e

# Get a GITLAB_TOKEN token and export to GITLAB_TOKEN before running this script
if [ "$GITLAB_TOKEN" = "" ]; then
  echo "Please export your GitLab API token as GITLAB_TOKEN" >&2
  exit
fi
mkdir -p target

# Source the gitlab utils
. $(dirname "$0")/gitlab-utils.sh
GetAllGroups
GetAllProjects

echo "Group Memberships:"
for GROUP_ID in $GROUP_IDS
do
  MEMBERS=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/groups/$GROUP_ID/members")
  if [ "$MEMBERS" != "[]" ]; then
    GROUP_NAME=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/groups/$GROUP_ID" | jq -r '"\(.name) : \(.full_path)"')
    echo "$GROUP_NAME"
    echo "$MEMBERS" | jq '.[].name'
  fi
done

echo ""
echo "Project Memberships:"
for PROJ_ID in $PROJ_IDS
do
  MEMBERS=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/members")
  if [ "$MEMBERS" != "[]" ]; then
    PROJECT_NAME=$(curl -s --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID" | jq -r '"\(.name) : \(.path_with_namespace)"')
    echo "$PROJECT_NAME"
    echo "$MEMBERS" | jq '.[].name'
  fi
done
