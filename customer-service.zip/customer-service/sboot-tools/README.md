# sboot-tools

Set of shared tools (deploy scripts, shared build config etc)