package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CombinedIdentificationResult {

  @ApiModelProperty(value = "Combined Decision for all applicants on the account")
  private Decision decision;

  @ApiModelProperty(value = "Are deposits allowed on the account")
  private boolean depositAllowed;
}
