package uk.co.ybs.digital.customer.repository.core;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.Optional;
import java.util.Set;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.Party;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public interface PartyCoreRepository extends JpaRepository<Party, Long> {

  default Optional<Party> findGoldenPartyInformation(final Long partyId, final LocalDateTime now) {
    return findPartyInformationWithAddressTypesAndFunctions(
        partyId,
        EnumSet.allOf(AddressType.class),
        EnumSet.allOf(AddressUsage.AddressFunction.class),
        now);
  }

  @Query(
      "SELECT party FROM Party party "
          + "JOIN party.person person ON person.endedDate IS NULL "
          + "JOIN party.partyType partyType ON "
          + "   (partyType.endDate IS NULL OR partyType.endDate > :now) "
          + "   AND partyType.startDate <= :now "
          + "LEFT JOIN party.addresses addressUsage"
          + "   ON addressUsage.endDate IS NULL "
          + "   AND (addressUsage.nonPostalAddress.type IN :addressTypes "
          + "        OR addressUsage.postalAddress.type IN :addressTypes) "
          + "   AND (addressUsage.function IN :addressFunctions) "
          + "WHERE partyType.type = 'PERSON' "
          + "  AND party.sysId = :partyId "
          + "  AND party.endedDate IS NULL "
          + "ORDER BY addressUsage.preferredContactMethod DESC,"
          + "         addressUsage.createdDate DESC,"
          + "         addressUsage.sysId DESC")
  @EntityGraph(
      attributePaths = {
        "person",
        "addresses",
        "addresses.functions",
        "addresses.nonPostalAddress",
        "addresses.postalAddress",
        "addresses.postalAddress.country",
        "person.party.partyType"
      },
      type = EntityGraph.EntityGraphType.LOAD)
  Optional<Party> findPartyInformationWithAddressTypesAndFunctions(
      Long partyId,
      Set<AddressType> addressTypes,
      Set<AddressUsage.AddressFunction> addressFunctions,
      LocalDateTime now);

  @Query(name = LinkedParty.FIND_CANONICAL_PARTY_ID_QUERY)
  Optional<LinkedParty> findCanonicalPartyId(Long partyId);
}
