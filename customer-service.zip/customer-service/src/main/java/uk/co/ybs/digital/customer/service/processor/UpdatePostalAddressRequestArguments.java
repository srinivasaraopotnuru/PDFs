package uk.co.ybs.digital.customer.service.processor;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.customer.model.digitalcustomer.AddressFunction;
import uk.co.ybs.digital.customer.model.digitalcustomer.PostalAddressType;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class UpdatePostalAddressRequestArguments {
  long partyId;
  @NonNull RequestMetadata requestMetadata;
  @NonNull LocalDateTime processTime;

  @NonNull PostalAddressType addressType;
  @NonNull AddressFunction function;
  @NonNull String addressLine1;
  String addressLine2;
  String addressLine3;
  String addressLine4;
  String addressLine5;
  @NonNull String country;
  @NonNull String areaCode;
  @NonNull String districtCode;
  @NonNull String sectorCode;
  @NonNull String unitCode;
  Integer pafAddressKey;
  String pafDeliveryPointSuffix;
}
