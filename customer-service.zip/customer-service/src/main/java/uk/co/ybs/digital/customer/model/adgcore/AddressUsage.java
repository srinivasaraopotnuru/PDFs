package uk.co.ybs.digital.customer.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import uk.co.ybs.digital.customer.model.YesOrNullConverter;

@Entity
@Table(name = "ADDRESS_USAGES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class AddressUsage {

  @Id
  @Column(name = "SYSID")
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "START_DATE")
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @ManyToOne
  @JoinColumn(name = "PARTY_SYSID")
  @ToString.Exclude
  private Party party;

  @ManyToOne
  @JoinColumn(name = "NPADDR_SYSID")
  private NonPostalAddress nonPostalAddress;

  @ManyToOne
  @JoinColumn(name = "PSTADD_SYSID")
  private PostalAddress postalAddress;

  @Column(name = "ADDFUN_CODE")
  @Enumerated(EnumType.STRING)
  private AddressFunction function;

  @Column(name = "PREF_CONTACT_METH")
  @Convert(converter = YesOrNullConverter.class)
  private boolean preferredContactMethod;

  @Column(name = "CREATED_DATE")
  private LocalDateTime createdDate;

  public enum AddressFunction {
    DIRCOM,
    CORR,
    FORRES
  }
}
