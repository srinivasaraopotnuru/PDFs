package uk.co.ybs.digital.customer.service.account;

public class AccountServiceException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public AccountServiceException(final String message) {
    super(message);
  }

  public AccountServiceException(final String message, final Throwable exception) {
    super(message, exception);
  }
}
