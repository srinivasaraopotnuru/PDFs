package uk.co.ybs.digital.customer.service.apply.dto;

import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class ApplicationResponsePrivate extends ApplicationResponseBase {

  private List<CustomerDetailsResponsePrivate> applicants;

  /**
   * Construct the private ApplicationResponsePrivate from the existing ApplicationResponse.
   *
   * @param applicationResponse
   */
  public ApplicationResponsePrivate(final ApplicationResponsePublic applicationResponse) {
    super(applicationResponse.toBuilder());
    applicants = new ArrayList<>();

    for (CustomerDetailsResponse customerDetailsResponse : applicationResponse.getApplicants()) {
      applicants.add(new CustomerDetailsResponsePrivate(customerDetailsResponse));
    }
  }
}
