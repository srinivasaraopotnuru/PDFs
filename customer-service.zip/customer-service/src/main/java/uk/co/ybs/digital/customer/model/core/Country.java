package uk.co.ybs.digital.customer.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "COUNTRIES")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Country {

  @Id
  @Column(name = "CODE")
  private String code;

  @Column(name = "ISO_CODE")
  private String isoCode;
}
