package uk.co.ybs.digital.customer.repository.adgcore;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.adgcore.AreaDiallingCode;
import uk.co.ybs.digital.customer.model.adgcore.AreaDiallingCodePK;

public interface AreaDiallingCodesRepository
    extends JpaRepository<AreaDiallingCode, AreaDiallingCodePK> {

  @Query(
      value =
          "SELECT * FROM ("
              + "SELECT adc.code "
              + "FROM area_dialling_codes adc "
              + " WHERE :phoneNumber LIKE adc.code || '%' "
              + "   AND adc.end_date is null "
              + "   AND cntry_code = :countryCode "
              + "   AND length(substr(:phoneNumber, length(adc.code) + 1)) = "
              + "       coalesce(length_of_local_no, 10 - length(adc.code)) "
              + "   ORDER BY length_of_local_no NULLS LAST) "
              + " WHERE ROWNUM = 1",
      nativeQuery = true)
  Optional<Integer> findAreaDiallingCodeForPhoneNumber(String countryCode, String phoneNumber);
}
