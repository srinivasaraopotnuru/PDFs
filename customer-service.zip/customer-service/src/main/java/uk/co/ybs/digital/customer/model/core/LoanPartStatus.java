package uk.co.ybs.digital.customer.model.core;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(LoanPartStatus.LoanPartStatusPk.class)
@Table(name = "LOAN_PART_STATUSES")
public class LoanPartStatus {
  @Id
  @Column(name = "LOANPT_ACCGRP_NUM", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private Long loanPartAccountNumber;

  @Column(name = "LOANPT_LATYPE_CODE", nullable = false, updatable = false)
  private Integer loanPartAccountTypeCode;

  @Column(name = "LOANPT_PART_NUM", nullable = false, updatable = false)
  private Integer loanPartNumber;

  @Column(name = "LPST_CODE", nullable = false, updatable = false)
  private String statusCode;

  @Column(name = "START_DATE", nullable = false, updatable = false)
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @ManyToOne
  @JoinColumns({
    @JoinColumn(
        name = "LOANPT_ACCGRP_NUM",
        referencedColumnName = "LOANAC_ACCGRP_NUM",
        insertable = false,
        updatable = false),
    @JoinColumn(
        name = "LOANPT_LATYPE_CODE",
        referencedColumnName = "LOANAC_LATYPE_CODE",
        insertable = false,
        updatable = false),
    @JoinColumn(
        name = "LOANPT_PART_NUM",
        referencedColumnName = "PART_NUM",
        insertable = false,
        updatable = false)
  })
  private LoanPart parts;

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class LoanPartStatusPk implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "LOANPT_ACCGRP_NUM", nullable = false, updatable = false)
    private Long loanPartAccountNumber;

    @Column(name = "LOANPT_LATYPE_CODE", nullable = false, updatable = false)
    private Integer loanPartAccountTypeCode;

    @Column(name = "LOANPT_PART_NUM", nullable = false, updatable = false)
    private Integer loanPartNumber;

    @Column(name = "LPST_CODE", nullable = false, updatable = false)
    private String statusCode;

    @Column(name = "START_DATE", nullable = false, updatable = false)
    private LocalDateTime startDate;
  }
}
