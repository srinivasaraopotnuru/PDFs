package uk.co.ybs.digital.customer.model.digitalcustomer;

import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.Value;
import lombok.experimental.SuperBuilder;
import lombok.extern.jackson.Jacksonized;

@Value
@EqualsAndHashCode(callSuper = false)
@SuperBuilder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class DeletePhoneRequest extends WorkLogPayload {

  @NonNull PhoneNumberRequestType requestType;

  @Override
  public <T> T accept(final WorkLogPayloadVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
