package uk.co.ybs.digital.customer.web.dto.products;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Fact {
  @ApiModelProperty(required = true)
  @NonNull
  String text;
}
