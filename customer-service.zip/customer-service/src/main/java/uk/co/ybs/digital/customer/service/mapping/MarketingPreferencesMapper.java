package uk.co.ybs.digital.customer.service.mapping;

import java.util.List;
import org.mapstruct.Mapper;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.web.dto.MarketingPreferences;

@Mapper(componentModel = "spring")
@SuppressWarnings("PMD.SwitchStmtsShouldHaveDefault")
public class MarketingPreferencesMapper {

  public MarketingPreferences marketingPreferences(final List<MarketingOptIn> marketingOptIns) {

    Boolean post = null;
    Boolean phone = null;
    Boolean email = null;
    Boolean eagm = null;

    for (MarketingOptIn marketingOptIn : marketingOptIns) {
      switch (marketingOptIn.getCode()) {
        case ADDR:
          post = marketingOptIn.getStatus();
          break;
        case TEL:
          phone = marketingOptIn.getStatus();
          break;
        case EMAIL:
          email = marketingOptIn.getStatus();
          break;
        case AGMEML:
          eagm = marketingOptIn.getStatus();
          break;
      }
    }

    return MarketingPreferences.builder().post(post).phone(phone).email(email).eagm(eagm).build();
  }
}
