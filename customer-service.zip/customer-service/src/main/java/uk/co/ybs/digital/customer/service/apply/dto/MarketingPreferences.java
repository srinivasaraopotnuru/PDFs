package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MarketingPreferences {

  @NotNull(message = "Please specify email")
  @ApiModelProperty(required = true, value = "Customers email preference.")
  private Boolean email;

  @NotNull(message = "Please specify phone")
  @ApiModelProperty(required = true, value = "Customers phone preference.")
  private Boolean phone;

  @NotNull(message = "Please specify post")
  @ApiModelProperty(required = true, value = "Customers post preference..")
  private Boolean post;
}
