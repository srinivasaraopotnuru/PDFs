package uk.co.ybs.digital.customer.service.apply;

import java.net.URL;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

@ConfigurationProperties(prefix = "uk.co.ybs.digital.apply")
@ConstructorBinding
@AllArgsConstructor
@Getter
public class ApplyServiceProperties {
  @NonNull private final URL url;
}
