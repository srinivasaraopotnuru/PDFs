package uk.co.ybs.digital.customer.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Entity
@Table(name = "FATCA_PROFILES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FatcaProfile {

  @Id
  @Column(name = "SYSID")
  private Long sysId;

  @NonNull
  @Column(name = "FATCA_PARTIES_SYSID")
  private Long fatcaPartySysId;

  @NonNull
  @Column(name = "CNTRY_REL_CODE")
  private String countryRelationCode;

  @NonNull
  @Column(name = "CNTRY_CODE")
  private String countryCode;

  @NonNull
  @Column(name = "NONUK_TAX_REF")
  private String nonUKTaxReferenceCode;

  @NonNull
  @Column(name = "START_DATE")
  private LocalDateTime startDate;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;
}
