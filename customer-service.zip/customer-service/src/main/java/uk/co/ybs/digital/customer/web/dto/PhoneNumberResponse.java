package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PhoneNumberResponse {
  @ApiModelProperty(required = true)
  boolean pendingUpdate;

  @ApiModelProperty(required = true, example = "HOME")
  String type;

  @ApiModelProperty(required = true, example = "Landline")
  PhoneNumberSubType subType;

  @ApiModelProperty(example = "91")
  String countryCode;

  @ApiModelProperty(required = true, example = "012744207138")
  String number;
}
