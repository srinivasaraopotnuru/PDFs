package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.customer.web.NonEmptyString;
import uk.co.ybs.digital.customer.web.validators.MobileNumber;
import uk.co.ybs.digital.customer.web.validators.PostCode;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class CustomerDelayedRequest {

  private static final int FIELD_MAX = 70;
  private static final int FIELD_MIN = 2;

  private static final String ALPHABET_REGEX = "^[a-zA-Z-' ]+$";

  @NotNull(message = "You must specify forename")
  @NonEmptyString(message = "Forename must contain at least one non-whitespace character")
  @Pattern(regexp = ALPHABET_REGEX, message = "Please specify valid forename")
  @Size(
      max = FIELD_MAX,
      min = FIELD_MIN,
      message = "Forenames must be between {min} and {max} characters in length")
  @ApiModelProperty(required = true, example = "Joe")
  String forename;

  @NotNull(message = "You must specify post code")
  @PostCode
  @ApiModelProperty(required = true, example = "LS1 8EQ")
  String postCode;

  @NotNull(message = "You must specify mobile number")
  @MobileNumber
  @ApiModelProperty(required = true, example = "07123456789")
  String mobileNumber;

  @NotNull(message = "You must specify date of birth")
  @NonEmptyString(message = "Date Of Birth must contain at least one non-whitespace character")
  @ApiModelProperty(required = true, example = "1980-12-12")
  String dateOfBirth;
}
