package uk.co.ybs.digital.customer.service.apply.dto;

public enum Decision {
  AUTHENTICATED,
  ID_REQUIRED,
  SANPEP;
}
