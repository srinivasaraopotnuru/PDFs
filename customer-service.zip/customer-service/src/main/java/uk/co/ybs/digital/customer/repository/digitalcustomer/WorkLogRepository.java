package uk.co.ybs.digital.customer.repository.digitalcustomer;

import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;

public interface WorkLogRepository extends JpaRepository<WorkLog, Long> {

  @Query(
      "SELECT wl FROM WorkLog wl WHERE wl.partyId = :partyId"
          + " AND wl.status = 'PENDING'"
          + " AND wl.operation IN  ('UPDATE_PHONE_NUMBER', 'DELETE_PHONE_NUMBER')"
          + " ORDER BY wl.createdDate DESC")
  List<WorkLog> findPendingWorkLogByPartyIdAndUpdateDeletePhoneNumber(long partyId);

  @Query(
      "SELECT wl " + "FROM WorkLog wl " + "WHERE wl.status = :status " + "ORDER BY wl.createdDate")
  List<WorkLog> findRequestsInState(@Param("status") WorkLog.Status status);

  @Query(
      "SELECT new org.apache.commons.lang3.tuple.ImmutablePair(wl.status, COUNT(wl.sysId)) "
          + "FROM WorkLog wl "
          + "GROUP BY wl.status")
  List<ImmutablePair<WorkLog.Status, Long>> findCountOfRequestsInState();

  @Query(
      "SELECT wl FROM WorkLog wl WHERE wl.partyId = :partyId"
          + " AND wl.status = 'PENDING'"
          + " AND wl.operation = :operation"
          + " AND rownum = 1"
          + " ORDER BY wl.createdDate DESC")
  Optional<WorkLog> findPendingWorkLogByPartyIdAndOperation(long partyId, Operation operation);
}
