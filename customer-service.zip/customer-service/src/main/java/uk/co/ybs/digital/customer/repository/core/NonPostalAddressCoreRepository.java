package uk.co.ybs.digital.customer.repository.core;

import java.util.Optional;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public interface NonPostalAddressCoreRepository extends JpaRepository<NonPostalAddress, Long> {
  @Query(
      "SELECT npa FROM NonPostalAddress npa"
          + " WHERE npa.address = :address"
          + " AND npa.type = :addressTypeCode"
          + " AND COALESCE(npa.sourceType,'X') = :npaSourceType"
          + " AND (npa.adcCode = :areaDiallingCode OR (npa.adcCode IS NULL AND :areaDiallingCode IS NULL))"
          + " AND (npa.country = :country OR (npa.country IS NULL AND :country IS NULL))"
          + " AND rownum = 1"
          + " ORDER BY npa.sysId DESC")
  Optional<NonPostalAddress> findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
      String address,
      AddressType addressTypeCode,
      Integer areaDiallingCode,
      NPASourceType npaSourceType,
      Country country);
}
