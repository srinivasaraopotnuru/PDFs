package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings({"PMD.CommentDefaultAccessModifier", "PMD.AvoidDuplicateLiterals"})
public class Preferences {

  Marketing marketing;

  @Value
  @Builder
  @Jacksonized
  public static class Marketing {

    @ApiModelProperty(required = true)
    Email email;

    @ApiModelProperty(required = true)
    Phone phone;

    @ApiModelProperty(required = true)
    Post post;

    @ApiModelProperty(required = true)
    Eagm eagm;

    @Value
    @Builder
    @Jacksonized
    public static class Email {
      @ApiModelProperty(required = true, example = "true")
      Boolean status;
    }

    @Value
    @Builder
    @Jacksonized
    public static class Phone {
      @ApiModelProperty(required = true, example = "true")
      Boolean status;
    }

    @Value
    @Builder
    @Jacksonized
    public static class Post {
      @ApiModelProperty(required = true, example = "true")
      Boolean status;
    }

    @Value
    @Builder
    @Jacksonized
    public static class Eagm {
      @ApiModelProperty(required = true, example = "true")
      Boolean status;

      @ApiModelProperty(
          required = true,
          example = "true",
          notes = "customer has opted in but notification email failed when status is false")
      Boolean deemedConsent;
    }
  }
}
