package uk.co.ybs.digital.customer.model.adgcore;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@SqlResultSetMapping(
    name = CustomerWebLogOnDetails.CUSTOMER_WEB_LOGON_DETAILS_RESULT_SET_MAPPING,
    entities =
        @EntityResult(
            entityClass = CustomerWebLogOnDetails.class,
            fields = {
              @FieldResult(name = "partyId", column = "PARTY_SYSID"),
              @FieldResult(name = "webCustomerNumber", column = "WEB_CUSTOMER_NO"),
              @FieldResult(name = "webUsername", column = "WEB_USERNAME")
            }))
@NamedNativeQuery(
    name = CustomerWebLogOnDetails.CUSTOMER_WEB_LOGON_DETAILS_QUERY,
    resultSetMapping = CustomerWebLogOnDetails.CUSTOMER_WEB_LOGON_DETAILS_RESULT_SET_MAPPING,
    query =
        "SELECT WLD.PARTY_SYSID, WLD.WEB_CUSTOMER_NO, WLD.WEB_USERNAME "
            + " FROM PACK_WEB_LOGON.FN_GET_MAIN_WEB_LOGON(?1, 'YBS') WLD "
            + " WHERE WLD.PARTY_SYSID IS NOT NULL AND WLD.WEB_CUSTOMER_NO IS NOT NULL")
public class CustomerWebLogOnDetails {
  public static final String CUSTOMER_WEB_LOGON_DETAILS_QUERY = "findCustomerNumberAndUsername";
  public static final String CUSTOMER_WEB_LOGON_DETAILS_RESULT_SET_MAPPING =
      "CustomerWebLogOnDetails";

  @Id private Long partyId;
  private Long webCustomerNumber;
  private String webUsername;
}
