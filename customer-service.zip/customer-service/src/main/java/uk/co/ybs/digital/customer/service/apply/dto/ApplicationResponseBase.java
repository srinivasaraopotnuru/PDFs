package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.validation.annotation.Validated;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
public class ApplicationResponseBase implements ApplicationResponse {

  @ApiModelProperty(
      example = "3b94b7e7-2799-4f78-916f-6a472c5f5e6c",
      required = true,
      value = "Unique identifier for the application.")
  private UUID uuid;

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class Account {
    @ApiModelProperty(value = "The account number")
    private String number;

    @ApiModelProperty(value = "The funded by status for application")
    private FundedBy fundedBy;

    @ApiModelProperty(value = "The last date possible to deposit initial funding for the account")
    private LocalDate lastFundDate;

    @ApiModelProperty(value = "If the account is set up for charitable excess donations")
    private Boolean charitableExcess;

    @ApiModelProperty(value = "The sort code")
    private String sortCode;
  }

  @ApiModelProperty(value = "The account associated with the application")
  private Account account;

  @Valid
  @ApiModelProperty(required = true, value = "The product being applied for")
  private Product product;

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  @Validated
  public static class Product {

    @SuppressWarnings("checkstyle:MagicNumber")
    @Size(min = 1, max = 10)
    @ApiModelProperty(
        example = "123456789",
        required = true,
        value = "A unique string that describes a product.")
    private String productIdentifier;

    @ApiModelProperty(value = "A description of the product.")
    private String customerDescription;
  }

  @ApiModelProperty(value = "A combined identification result of all applicants.")
  private CombinedIdentificationResult combinedIdentificationResult;

  @NotNull private ApplicationStatus status;

  @ApiModelProperty(value = "Flag indicating ISA declaration has been generated.")
  private boolean isaDeclaration;
}
