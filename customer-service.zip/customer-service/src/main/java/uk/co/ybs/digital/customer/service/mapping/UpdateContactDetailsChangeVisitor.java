package uk.co.ybs.digital.customer.service.mapping;

import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdateEmailRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayloadVisitor;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;

@RequiredArgsConstructor
public class UpdateContactDetailsChangeVisitor implements WorkLogPayloadVisitor<Boolean> {

  private final ContactDetailsChange contact;
  private final LocalDateTime processTime;

  @Override
  public Boolean visit(final UpdateEmailRequest updateEmailAddress) {

    if (!StringUtils.equals(contact.getEmailAddress(), updateEmailAddress.getEmail())) {
      contact.setEmailAddress(updateEmailAddress.getEmail());
      contact.setAmendDate(processTime);
      return true;
    }

    return false;
  }

  @Override
  public Boolean visit(final UpdatePhoneRequest updatePhoneRequest) {

    String formattedNumber = formattedNumber(updatePhoneRequest);

    switch (updatePhoneRequest.getRequestType()) {
      case HOME:
        if (!StringUtils.equals(contact.getHomeTelephoneNumber(), formattedNumber)) {
          contact.setHomeTelephoneNumber(formattedNumber);
          contact.setAmendDate(processTime);
          return true;
        }
        break;
      case MOBILE:
        if (!StringUtils.equals(contact.getMobileTelephoneNumber(), formattedNumber)) {
          contact.setMobileTelephoneNumber(formattedNumber);
          contact.setAmendDate(processTime);
          return true;
        }
        break;
      case WORK:
        if (!StringUtils.equals(contact.getWorkTelephoneNumber(), formattedNumber)) {
          contact.setWorkTelephoneNumber(formattedNumber);
          contact.setAmendDate(processTime);
          return true;
        }
        break;
    }

    return false;
  }

  @Override
  public Boolean visit(final DeletePhoneRequest deletePhoneRequest) {

    switch (deletePhoneRequest.getRequestType()) {
      case HOME:
        if (!(contact.getHomeTelephoneNumber() == null)) {
          contact.setHomeTelephoneNumber(null);
          contact.setAmendDate(processTime);
          return true;
        }
        break;
      case MOBILE:
        if (!(contact.getMobileTelephoneNumber() == null)) {
          contact.setMobileTelephoneNumber(null);
          contact.setAmendDate(processTime);
          return true;
        }
        break;
      case WORK:
        if (!(contact.getWorkTelephoneNumber() == null)) {
          contact.setWorkTelephoneNumber(null);
          contact.setAmendDate(processTime);
          return true;
        }
        break;
    }

    return false;
  }

  @Override
  public Boolean visit(final UpdatePostalAddressRequest workLog) {
    throw new CustomerServiceException("Error processing UpdatePostalAddressRequest");
  }

  private String formattedNumber(final UpdatePhoneRequest phoneNumber) {
    if (phoneNumber.getNumber() == null) {
      return null;
    }

    if (phoneNumber.getAreaDiallingCode() == null) {
      return phoneNumber.getNumber();
    }

    return "0" + phoneNumber.getAreaDiallingCode() + phoneNumber.getNumber();
  }
}
