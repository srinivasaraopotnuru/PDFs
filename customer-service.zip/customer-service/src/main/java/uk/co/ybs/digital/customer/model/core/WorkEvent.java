package uk.co.ybs.digital.customer.model.core;

public class WorkEvent {

  public enum WorkEventContextTableName {
    LOANAC,
    SAVACC
  }

  public enum ModuleLabelAssociationType {
    CREEVT,
    GENERL
  }

  public enum WorkEventStatus {
    TODO,
    COMPLT,
    INPROG,
    DELETE,
    CANCLD,
    REFER
  }
}
