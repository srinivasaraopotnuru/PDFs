package uk.co.ybs.digital.customer.model.digitalcustomer;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AllArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@AllArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
  @JsonSubTypes.Type(name = "UpdateEmailRequest", value = UpdateEmailRequest.class),
  @JsonSubTypes.Type(name = "UpdatePhoneRequest", value = UpdatePhoneRequest.class),
  @JsonSubTypes.Type(name = "DeletePhoneRequest", value = DeletePhoneRequest.class),
  @JsonSubTypes.Type(name = "UpdatePostalAddressRequest", value = UpdatePostalAddressRequest.class)
})
public abstract class WorkLogPayload {

  public abstract <T> T accept(WorkLogPayloadVisitor<T> visitor);
}
