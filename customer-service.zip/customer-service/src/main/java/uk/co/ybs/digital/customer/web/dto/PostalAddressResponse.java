package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PostalAddressResponse {
  @ApiModelProperty(required = true)
  boolean pendingUpdate;

  @ApiModelProperty(required = true, example = "CORR")
  String type;

  @JsonProperty(value = "addressLine")
  @ApiModelProperty(required = true)
  List<String> addressLines;

  @ApiModelProperty(required = true, example = "CV5 7EE")
  String postCode;

  @ApiModelProperty(required = true, example = "GB")
  String country;
}
