package uk.co.ybs.digital.customer.model.digitalcustomer;

import javax.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.Value;
import lombok.experimental.SuperBuilder;
import lombok.extern.jackson.Jacksonized;

@Value
@EqualsAndHashCode(callSuper = false)
@SuperBuilder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class UpdatePhoneRequest extends WorkLogPayload {

  @NonNull PhoneNumberRequestType requestType;

  Integer areaDiallingCode;

  @NotNull String number;

  @Override
  public <T> T accept(final WorkLogPayloadVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
