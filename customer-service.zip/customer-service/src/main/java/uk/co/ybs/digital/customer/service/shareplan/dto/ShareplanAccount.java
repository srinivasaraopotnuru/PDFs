package uk.co.ybs.digital.customer.service.shareplan.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@JsonDeserialize(builder = ShareplanAccount.ShareplanAccountBuilder.class)
public class ShareplanAccount {

  @JsonProperty(value = "account")
  private List<Account> accounts;

  @Data
  @Builder(toBuilder = true)
  @JsonDeserialize(builder = Account.AccountBuilder.class)
  public static class Account {

    private String accountNumber;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AccountBuilder {}
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ShareplanAccountBuilder {}
}
