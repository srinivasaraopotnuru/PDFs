package uk.co.ybs.digital.customer.model.digitalcustomer;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;

@Value
@EqualsAndHashCode(callSuper = false)
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class UpdatePostalAddressRequest extends WorkLogPayload {
  @NonNull PostalAddress.PostalAddressSubType addressType;
  @NonNull PostalAddress.PostalAddressType function;
  @NonNull String addressLine1;
  String addressLine2;
  String addressLine3;
  String addressLine4;
  String addressLine5;
  @NonNull String country;
  @NonNull String areaCode;
  @NonNull String districtCode;
  @NonNull String sectorCode;
  @NonNull String unitCode;
  Integer pafAddressKey;
  String pafDeliveryPointSuffix;

  @Override
  public <T> T accept(final WorkLogPayloadVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
