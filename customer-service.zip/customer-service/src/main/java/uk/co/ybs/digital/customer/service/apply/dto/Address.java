package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import java.math.BigDecimal;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.annotation.Validated;
import uk.co.ybs.digital.customer.service.apply.validation.TrimmedSize;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Address {

  /** The Constant FIELD_MAX. */
  private static final int FIELD_MAX = 35;

  /** The Constant FIELD_MIN. */
  private static final int FIELD_MIN = 1;

  /** The Constant DPS_MAX. */
  private static final int DPS_MAX = 3;

  /** The Constant DPS_MIN. */
  private static final int DPS_MIN = 1;

  /** The Constant ALPHANUM_REGEX. */
  private static final String ALPHANUM_REGEX = "^[a-zA-Z0-9-' ]*$";

  /** The Constant PRINTABLE_REGEX. */
  private static final String PRINTABLE_REGEX = "^[\\p{Print}]*$";

  /** The line 1. */
  @NotNull(message = "Please specify the first line of address")
  @TrimmedSize(
      max = FIELD_MAX,
      min = FIELD_MIN,
      message = "The first line of address must be between {min} and {max} characters in length")
  @Pattern(
      regexp = PRINTABLE_REGEX,
      message = "Please specify valid line 1 of address matching pattern:{regexp}.")
  @ApiModelProperty(
      required = true,
      value =
          "The first line of address must be between 1 and 35 characters in length, must match regex "
              + PRINTABLE_REGEX)
  private String line1;

  /** The line 2. */
  @TrimmedSize(
      max = FIELD_MAX,
      min = FIELD_MIN,
      message = "The second line of address must be between {min} and {max} characters in length")
  @Pattern(
      regexp = PRINTABLE_REGEX,
      message = "Please specify valid line 2 of address matching pattern:{regexp}.")
  @ApiModelProperty(
      required = false,
      value =
          "The second line of address must be between 1 and 35 characters in length, must match regex "
              + PRINTABLE_REGEX)
  private String line2;

  /** The line 3. */
  @TrimmedSize(
      max = FIELD_MAX,
      min = FIELD_MIN,
      message = "The third line of address must be between {min} and {max} characters in length")
  @Pattern(
      regexp = PRINTABLE_REGEX,
      message = "Please specify valid line 3 of address matching pattern:{regexp}.")
  @ApiModelProperty(
      required = false,
      value =
          "The third line of address must be between 1 and 35 characters in length, must match regex "
              + PRINTABLE_REGEX)
  private String line3;

  /** The town. */
  @TrimmedSize(
      max = FIELD_MAX,
      min = FIELD_MIN,
      message = "Town name must be between {min} and {max} characters in length")
  @Pattern(
      regexp = PRINTABLE_REGEX,
      message = "Please specify valid town matching pattern:{regexp}.")
  @ApiModelProperty(
      required = false,
      value =
          "Town name must be between 1 and 35 characters in length, must match regex "
              + PRINTABLE_REGEX)
  private String town;

  /** The county. */
  @TrimmedSize(
      max = FIELD_MAX,
      min = FIELD_MIN,
      message = "County name must be between {min} and {max} characters in length")
  @Pattern(
      regexp = PRINTABLE_REGEX,
      message = "Please specify valid county matching pattern:{regexp}.")
  @ApiModelProperty(
      required = false,
      value =
          "County name must be between 1 and 35 characters in length, must match regex "
              + PRINTABLE_REGEX)
  private String county;

  /** The paf data. */
  @Valid
  @ApiModelProperty(dataType = "PafData", value = "Paf Data")
  private PafData pafData;

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  @Validated
  public static class PafData {

    /** The address key. */
    @NotNull(message = "Please specify addressKey")
    @ApiModelProperty(dataType = "BigDecimal", required = true, value = "Paf address key")
    private BigDecimal addressKey;

    /** The delivery point suffix. */
    @NotNull(message = "Please specify deliveryPointSuffix")
    @Pattern(
        regexp = ALPHANUM_REGEX,
        message = "Please specify valid deliveryPointSuffix matching pattern:{regexp}.")
    @TrimmedSize(
        max = DPS_MAX,
        min = DPS_MIN,
        message = "The deliveryPointSuffix must be between {min} and {max} characters in length")
    @ApiModelProperty(
        dataType = "String",
        required = true,
        value =
            "Paf delivery point suffix must be between 1 and 3 characters in length, "
                + "must match regex "
                + ALPHANUM_REGEX)
    private String deliveryPointSuffix;
  }

  /**
   * Gets the line 1.
   *
   * @return the line 1
   */
  public String getLine1() {
    return StringUtils.normalizeSpace(line1);
  }

  /**
   * Gets the line 2.
   *
   * @return the line 2
   */
  public String getLine2() {
    return StringUtils.normalizeSpace(line2);
  }

  /**
   * Gets the line 3.
   *
   * @return the line 3
   */
  public String getLine3() {
    return StringUtils.normalizeSpace(line3);
  }

  /**
   * Gets the town.
   *
   * @return the town
   */
  public String getTown() {
    return StringUtils.normalizeSpace(town);
  }

  /**
   * Gets the county.
   *
   * @return the county
   */
  public String getCounty() {
    return StringUtils.normalizeSpace(county);
  }
}
