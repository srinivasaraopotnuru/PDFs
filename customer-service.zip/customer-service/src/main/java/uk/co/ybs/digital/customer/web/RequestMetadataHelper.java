package uk.co.ybs.digital.customer.web;

import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import lombok.experimental.UtilityClass;
import org.springframework.http.HttpHeaders;
import org.springframework.security.oauth2.jwt.Jwt;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@UtilityClass
public class RequestMetadataHelper {
  private static final String BRAND_CODE_CLAIM = "brand_code";
  private static final String PARTY_ID_CLAIM = "party_id";
  private static final String WEB_CUSTOMER_NO_CLAIM = "sub";

  public static RequestMetadata buildRequestMetadata(
      final Jwt user,
      final UUID sessionId,
      final UUID requestId,
      final HttpServletRequest request,
      final HttpHeaders headers) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .sessionId(sessionId)
        .host(headers.getHost())
        .partyId(user.getClaimAsString(PARTY_ID_CLAIM))
        .forwardingAuth(user.getTokenValue())
        .brandCode(user.getClaimAsString(BRAND_CODE_CLAIM))
        .ipAddress(request.getRemoteAddr())
        .webCustomerNumber(user.getClaimAsString(WEB_CUSTOMER_NO_CLAIM))
        .build();
  }
}
