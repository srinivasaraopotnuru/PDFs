package uk.co.ybs.digital.customer.web.dto.products;

public enum ProductType {
  ISA,
  BOND,
  EASY_ACCESS,
  CHILDRENS,
  SAVER,
  DEFERRED
}
