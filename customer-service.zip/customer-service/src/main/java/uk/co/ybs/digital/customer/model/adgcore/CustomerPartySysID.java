package uk.co.ybs.digital.customer.model.adgcore;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@SqlResultSetMapping(
    name = CustomerPartySysID.CUSTOMER_PARTY_SYSID_RESULT_SET_MAPPING,
    entities =
        @EntityResult(
            entityClass = CustomerPartySysID.class,
            fields = {
              @FieldResult(name = "partyId", column = "PARTY_SYSID"),
              @FieldResult(name = "surname", column = "SURNAME"),
              @FieldResult(name = "title", column = "TITLE_ABBR")
            }))
@NamedNativeQuery(
    name = CustomerPartySysID.CUSTOMER_PARTY_SYSID_QUERY,
    resultSetMapping = CustomerPartySysID.CUSTOMER_PARTY_SYSID_RESULT_SET_MAPPING,
    query =
        " SELECT DISTINCT PE.PARTY_SYSID, SURNAME, TITLE_ABBR FROM PEOPLE PE "
            + " INNER JOIN ADDRESS_USAGES AU "
            + " ON PE.PARTY_SYSID = AU.PARTY_SYSID "
            + " AND (AU.END_DATE IS NULL OR (AU.END_DATE > ?5 OR (TRUNC(AU.END_DATE)= AU.END_DATE AND AU.END_DATE = TRUNC(?5)))) "
            + " AND AU.CREATED_DATE <= ?5 "
            + " AND AU.START_DATE <= ?5 "
            + " AND (AU.ADDFUN_CODE IN ('DIRCOM', 'CORR', 'FORRES')) "
            + " INNER JOIN POSTAL_ADDRESSES PA "
            + " ON PA.SYSID = AU.PSTADD_SYSID "
            + " WHERE PE.ENDED_DATE IS NULL "
            + " AND CASE  WHEN INSTR(TRIM(PE.FORENAMES), ' ')>0 "
            + " THEN UPPER(SUBSTR(TRIM(PE.FORENAMES), 0, INSTR(TRIM(PE.FORENAMES), ' ')-1)) "
            + " ELSE UPPER(TRIM(PE.FORENAMES)) END = ?1 "
            + " AND PE.DATE_OF_BIRTH = TO_DATE(?2 , 'YYYY-MM-DD')"
            + " AND UPPER(LTRIM(RTRIM(PA.AREA_CODE)) || LTRIM(RTRIM(PA.DISTRICT_CODE))"
            + " || LTRIM(RTRIM(PA.SECTOR_CODE)) || LTRIM(RTRIM(PA.UNIT_CODE))) = ?3 "
            + " AND PE.PARTY_SYSID IN  "
            + " (SELECT DISTINCT AU.PARTY_SYSID FROM ADDRESS_USAGES AU "
            + " INNER JOIN  NON_POSTAL_ADDRESSES NPA "
            + " ON AU.NPADDR_SYSID = NPA.SYSID "
            + " AND (AU.END_DATE IS NULL OR (AU.END_DATE > ?5 OR (TRUNC(AU.END_DATE)= AU.END_DATE  AND AU.END_DATE = TRUNC(?5)))) "
            + " AND AU.CREATED_DATE <= ?5 "
            + " AND AU.START_DATE <= ?5 "
            + " AND (AU.ADDFUN_CODE IN ('DIRCOM', 'CORR', 'FORRES')) "
            + " WHERE REPLACE(DECODE(TO_CHAR(ADC_CODE),NULL,NULL,'0'||TO_CHAR(ADC_CODE))||ADDR,' ') = ?4 "
            + " AND NPA.ADTYP_CODE='TEL' "
            + " AND NPA.NPASRC_CODE = 'MOBILE')")
public class CustomerPartySysID {
  public static final String CUSTOMER_PARTY_SYSID_QUERY = "findCustomerPartySysID";
  public static final String CUSTOMER_PARTY_SYSID_RESULT_SET_MAPPING = "CustomerPartySysID";

  @Id private Long partyId;
  private String surname;
  private String title;
}
