package uk.co.ybs.digital.customer.model.digitalcustomer;

public interface WorkLogPayloadVisitor<T> {
  T visit(UpdateEmailRequest workLog);

  T visit(UpdatePhoneRequest workLog);

  T visit(DeletePhoneRequest workLog);

  T visit(UpdatePostalAddressRequest workLog);
}
