package uk.co.ybs.digital.customer.service;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.customer.exception.AddressNotPermittedException;
import uk.co.ybs.digital.customer.exception.AmendmentRestrictionException;
import uk.co.ybs.digital.customer.exception.BadFailureRequestChallengeException;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerValidationException;
import uk.co.ybs.digital.customer.exception.CustomerValidationExceptionReason;
import uk.co.ybs.digital.customer.exception.MultipleRecordsFoundException;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.CustomerPartySysID;
import uk.co.ybs.digital.customer.model.adgcore.CustomerWebLogOnDetails;
import uk.co.ybs.digital.customer.model.adgcore.FatcaParty;
import uk.co.ybs.digital.customer.model.adgcore.FatcaProfile;
import uk.co.ybs.digital.customer.model.adgcore.LinkedParty;
import uk.co.ybs.digital.customer.model.adgcore.LinkedPartyDetails;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdateEmailRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogRequest;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;
import uk.co.ybs.digital.customer.repository.adgcore.FatcaPartyRepository;
import uk.co.ybs.digital.customer.repository.adgcore.FatcaProfileRepository;
import uk.co.ybs.digital.customer.repository.adgcore.MarketingOptInRepository;
import uk.co.ybs.digital.customer.repository.adgcore.PartyRepository;
import uk.co.ybs.digital.customer.repository.adgcore.PostalAddressExceptionRepository;
import uk.co.ybs.digital.customer.repository.digitalcustomer.WorkLogRepository;
import uk.co.ybs.digital.customer.repository.frontoffice.AddressChangeRepository;
import uk.co.ybs.digital.customer.repository.frontoffice.ContactDetailsChangeRepository;
import uk.co.ybs.digital.customer.service.account.AccountService;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditCustomerDetailsViewRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;
import uk.co.ybs.digital.customer.service.mapping.AddressChangeMapper;
import uk.co.ybs.digital.customer.service.mapping.AmendmentRestrictionMapper;
import uk.co.ybs.digital.customer.service.mapping.ContactDetailsChangeMapper;
import uk.co.ybs.digital.customer.service.mapping.CustomerBasicMapper;
import uk.co.ybs.digital.customer.service.mapping.GoldenCustomerRecordMapper;
import uk.co.ybs.digital.customer.service.mapping.IsaSubscriptionMapper;
import uk.co.ybs.digital.customer.service.mapping.UpdateContactDetailsChangeVisitor;
import uk.co.ybs.digital.customer.service.mapping.WorkLogPayloadMapper;
import uk.co.ybs.digital.customer.service.product.ProductFilterService;
import uk.co.ybs.digital.customer.service.shareplan.ShareplanService;
import uk.co.ybs.digital.customer.service.shareplan.ShareplanServiceProperties;
import uk.co.ybs.digital.customer.service.shareplan.dto.ShareplanAccount.Account;
import uk.co.ybs.digital.customer.web.dto.CustomerBasic;
import uk.co.ybs.digital.customer.web.dto.CustomerDelayedRequest;
import uk.co.ybs.digital.customer.web.dto.EmailAddress;
import uk.co.ybs.digital.customer.web.dto.FailureRequest;
import uk.co.ybs.digital.customer.web.dto.FailureType;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerService {

  private static final String SAPP_CHANNEL = "SAPP";
  private static final String PO_BOX = "PO BOX";
  private static final String LOG_LEVEL_INFO = "INFO";
  private static final String LOG_LEVEL_ERROR = "ERROR";
  private static final String AMENDMENT_RESTRICTION_ON_ACCOUNT =
      "Amendment restriction found on account";
  private static final String ADDRESS_LINE1_NOT_PERMITTED = "Address Line 1 is not permitted";
  private static final Locale LOCALE = Locale.ROOT;
  private static final String YES = "Y";

  private final AuditService auditService;
  private final AccountService accountService;
  private final ShareplanService shareplanService;
  private final ShareplanServiceProperties shareplanServiceProperties;
  private final ProductFilterService productFilterService;
  private final PartyRepository partyRepository;
  private final PostalAddressExceptionRepository postalAddressExceptionRepository;
  private final MarketingOptInRepository marketingOptInRepository;
  private final CustomerBasicMapper customerBasicMapper;
  private final GoldenCustomerRecordMapper goldenCustomerRecordMapper;
  private final AmendmentRestrictionMapper amendmentRestrictionMapper;
  private final IsaSubscriptionMapper isaSubscriptionMapper;
  private final Country defaultCountry;
  private final Clock clock;
  private final WorkLogRepository workLogRepository;
  private final ScaManager scaManager;
  private final ContactDetailsChangeRepository contactDetailsChangeRepository;
  private final AddressChangeRepository addressChangeRepository;
  private final ContactDetailsChangeMapper contactDetailsChangeMapper;
  private final AddressChangeMapper addressChangeMapper;
  private final WorkLogPayloadMapper workLogPayloadMapper;
  private final CustomerServiceProperties customerServiceProperties;
  private final ScaChallengeService challengeService;
  private final FatcaProfileRepository fatcaProfileRepository;
  private final FatcaPartyRepository fatcaPartyRepository;

  public CustomerBasic getCustomer(final long partyId, final LocalDateTime dateTime) {
    final LinkedParty linkedParty = getCanonicalPartyId(partyId);

    final Party party =
        getParty(linkedParty.getCanonicalPartyId(), dateTime)
            .orElseThrow(() -> customerNotFound(linkedParty.getCanonicalPartyId()));

    if (party.getAddresses().isEmpty()) {
      log.info(
          "No email address found for party {}. Field will be left blank",
          linkedParty.getCanonicalPartyId());
    }

    return customerBasicMapper.map(party);
  }

  private Optional<Party> getParty(final Long partyId, final LocalDateTime dateTime) {
    if (dateTime.toLocalDate().isBefore(LocalDate.now(clock))) {
      return partyRepository.findBasicPartyInformationHistoric(partyId, dateTime);
    }
    return partyRepository.findBasicPartyInformation(partyId, dateTime);
  }

  @SuppressWarnings("PMD.NullAssignment")
  public <T extends GoldenCustomerRecord> T getCustomerDetails(
      final RequestMetadata requestMetadata, final Class<T> returnType) {
    final long partyId = Long.parseLong(requestMetadata.getPartyId());

    final LocalDateTime now = LocalDateTime.now(clock);

    Party party =
        partyRepository
            .findGoldenPartyInformation(partyId, now)
            .orElseThrow(() -> customerNotFound(partyId));
    party.getAddresses().stream()
        .map(AddressUsage::getPostalAddress)
        .filter(addr -> addr != null && addr.getCountry() == null)
        .forEach(
            addr -> {
              log.info("Found PostalAddress record with no Country Code, using default: {}", addr);
              addr.setCountry(defaultCountry);
            });

    final AccountGroupedInfo accountGroupedInfo = getAccountGroups(requestMetadata);

    final boolean amendmentRestriction = isAmendmentRestriction(partyId, accountGroupedInfo);

    final boolean hasSharePlanAccount = checkSharePlanAccount(requestMetadata);

    final boolean hasIsaSubscription = checkIsaSubscription(partyId, accountGroupedInfo);

    final String webCustomerNumber = requestMetadata.getWebCustomerNumber();

    AuditCustomerDetailsViewRequest request =
        AuditCustomerDetailsViewRequest.builder().ipAddress(requestMetadata.getIpAddress()).build();
    auditService.auditCustomerDetailsView(request, requestMetadata);

    final List<MarketingOptIn> marketingOptIns =
        marketingOptInRepository.findMarketingOptInByParty(partyId, now);

    final Optional<FatcaParty> fatcaParty =
        fatcaPartyRepository.findByPartyIdAndNotEnded(partyId, now);

    List<FatcaProfile> fatcaProfiles = Collections.emptyList();
    if (fatcaParty.isPresent()) {
      fatcaProfiles =
          (List<FatcaProfile>)
              fatcaProfileRepository.findByPartyIdAndNotEnded(fatcaParty.get().getSysId(), now);
    }

    // We are using toString() as instanceof does not work when caller is using spy (mockito) for
    // partial mocking
    if (returnType.toString().equals(GoldenCustomerRecord.class.toString())) {
      return returnType.cast(
          goldenCustomerRecordMapper.map(
              party,
              amendmentRestriction,
              hasSharePlanAccount,
              hasIsaSubscription,
              webCustomerNumber,
              marketingOptIns,
              !fatcaProfiles.isEmpty() ? fatcaProfiles : null,
              fatcaParty.orElse(null)));
    }

    return returnType.cast(
        goldenCustomerRecordMapper.mapExtended(
            party,
            amendmentRestriction,
            hasSharePlanAccount,
            hasIsaSubscription,
            webCustomerNumber,
            marketingOptIns,
            !fatcaProfiles.isEmpty() ? fatcaProfiles : null,
            fatcaParty.orElse(null)));
  }

  private boolean isAmendmentRestriction(
      final long partyId, final AccountGroupedInfo accountGroupedInfo) {

    boolean amendmentRestriction = amendmentRestrictionMapper.isRestricted(accountGroupedInfo);
    if (amendmentRestriction) {
      log.info("Amendment Restriction found for party id {}", partyId);
    }
    return amendmentRestriction;
  }

  private boolean checkIsaSubscription(
      final long partyId, final AccountGroupedInfo accountGroupedInfo) {

    boolean subscribed = isaSubscriptionMapper.isSubscribed(accountGroupedInfo);
    if (subscribed) {
      log.info("ISA Subscription found for party id {}", partyId);
    }
    return subscribed;
  }

  private boolean checkSharePlanAccount(final RequestMetadata requestMetadata) {
    if (shareplanServiceProperties.isEnabled()) {
      List<Account> shareplanAccounts = shareplanService.getShareplanAccount(requestMetadata);
      return Optional.ofNullable(shareplanAccounts).isPresent() && shareplanAccounts.size() > 0;
    }
    return false;
  }

  private CustomerNotFoundException customerNotFound(final long partyId) {
    return new CustomerNotFoundException(
        String.format("No record found in party database for party id %s", partyId));
  }

  private CustomerNotFoundException customerNotFound(
      final CustomerDelayedRequest customerDelayedRequest) {
    return new CustomerNotFoundException(
        String.format(
            "No record found in ADG Core for the inputs forename:%s - postCode:%s - mobileNumber:%s",
            customerDelayedRequest.getForename(),
            customerDelayedRequest.getPostCode(),
            maskPhoneNumber(customerDelayedRequest.getMobileNumber())));
  }

  private MultipleRecordsFoundException multipleRecordsFound(
      final CustomerDelayedRequest customerDelayedRequest) {
    return new MultipleRecordsFoundException(
        String.format(
            "Multiple records found in ADG Core for the inputs forename:%s - postCode:%s - mobileNumber:%s",
            customerDelayedRequest.getForename(),
            customerDelayedRequest.getPostCode(),
            maskPhoneNumber(customerDelayedRequest.getMobileNumber())));
  }

  private LinkedParty getCanonicalPartyId(final long partyId) {
    final LinkedParty linkedParty =
        partyRepository.findCanonicalPartyId(partyId).orElseThrow(() -> customerNotFound(partyId));

    if (linkedParty.getLinkCount() != 0) {
      log.info("Requested customer details for non-canonical party id {}", linkedParty);
    }

    return linkedParty;
  }

  public void updatePostalAddress(
      final PostalAddressRequest postalAddressRequest,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {

    final LocalDateTime processTime = LocalDateTime.now(clock);

    scaManager.validateUpdatePostalAddressSca(
        Operation.POSTAL_ADDRESS, postalAddressRequest, metadata, scaCredentials);

    final GoldenCustomerRecord customer;
    try {
      customer = getCustomerDetails(metadata, GoldenCustomerRecord.class);
    } catch (CustomerNotFoundException e) {
      auditPostalAddressFailure(metadata, "Customer Not Found", postalAddressRequest);
      throw e;
    }

    if (customer.isAmendmentRestriction()) {
      auditPostalAddressFailure(metadata, AMENDMENT_RESTRICTION_ON_ACCOUNT, postalAddressRequest);
      throw new AmendmentRestrictionException(AMENDMENT_RESTRICTION_ON_ACCOUNT);
    }

    final AddressChange address = addressChangeMapper.map(postalAddressRequest);

    final WorkLogPayload request = workLogPayloadMapper.map(postalAddressRequest);

    if (postalAddressRequest.getPaf() == null) {
      postalAddressExceptionRepository
          .findExceptionForAddressLine(address.getAddressLine1())
          .ifPresent(
              audit -> {
                auditPostalAddressFailure(
                    metadata, ADDRESS_LINE1_NOT_PERMITTED, postalAddressRequest);
                throw new AddressNotPermittedException(ADDRESS_LINE1_NOT_PERMITTED);
              });
    } else {
      if (address.getAddressLine1().toUpperCase(LOCALE).contains(PO_BOX)) {
        auditPostalAddressFailure(metadata, ADDRESS_LINE1_NOT_PERMITTED, postalAddressRequest);
        throw new AddressNotPermittedException(ADDRESS_LINE1_NOT_PERMITTED);
      }
    }

    final String formattedNewPostalAddress = formattedPostalAddress(postalAddressRequest);
    final String formattedCurrentPostalAddress = formattedPostalAddress(customer);

    if (!StringUtils.equals(formattedNewPostalAddress, formattedCurrentPostalAddress)) {

      address.setPartySysId(customer.getPartyId());
      address.setAmendDate(processTime);

      // If this is a party that is used in smoke tests we do not want to save any records
      if (!shouldInsertRecords(metadata.getPartyId())) {
        log.info(
            "Party {} is found on the blacklist, not inserting a WorkLog or AddressChange entry",
            metadata.getPartyId());
        return;
      }

      addressChangeRepository.save(address);

      insertWorkLogRecord(metadata.getPartyId(), Operation.POSTAL_ADDRESS, request, metadata);
    } else {
      log.info(
          "Current Customer Address {} matches New Customer Address {} for Party {}",
          formattedCurrentPostalAddress,
          formattedNewPostalAddress,
          metadata.getPartyId());

      throw new CustomerValidationException(
          "No changes have been detected", CustomerValidationExceptionReason.NO_CHANGES_DETECTED);
    }
  }

  public List<ProductCategory> getAvailableProducts(final RequestMetadata metadata) {

    final long partyId = Long.parseLong(metadata.getPartyId());

    final LinkedParty linkedParty = getCanonicalPartyId(partyId);

    final LocalDateTime now = LocalDateTime.now(clock);

    final Party party =
        partyRepository
            .findPartyInformationWithAddressTypesAndFunctions(
                linkedParty.getCanonicalPartyId(),
                EnumSet.of(AddressType.UKPOST),
                EnumSet.of(AddressUsage.AddressFunction.CORR),
                LocalDateTime.now(clock))
            .orElseThrow(() -> customerNotFound(linkedParty.getCanonicalPartyId()));

    return productFilterService.filterProducts(party, metadata, now);
  }

  public void updateEmailAddress(
      final EmailAddress emailAddressRequest,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {

    final LocalDateTime processTime = LocalDateTime.now(clock);

    scaManager.validateUpdateEmailSca(
        Operation.EMAIL_ADDRESS, emailAddressRequest, metadata, scaCredentials);

    final GoldenCustomerRecord customer;
    try {
      customer = getCustomerDetails(metadata, GoldenCustomerRecord.class);
    } catch (CustomerNotFoundException e) {
      auditEmailAddressFailure(metadata, "Customer Not Found", emailAddressRequest.getEmail());
      throw e;
    }

    if (customer.isAmendmentRestriction()) {
      auditEmailAddressFailure(
          metadata, AMENDMENT_RESTRICTION_ON_ACCOUNT, emailAddressRequest.getEmail());
      throw new AmendmentRestrictionException(AMENDMENT_RESTRICTION_ON_ACCOUNT);
    }

    final ContactDetailsChange contact = getContactDetailsChange(customer);

    final UpdateEmailRequest request =
        UpdateEmailRequest.builder()
            .requestType(emailAddressRequest.getType())
            .email(emailAddressRequest.getEmail())
            .build();

    if (request.accept(new UpdateContactDetailsChangeVisitor(contact, processTime))) {

      // If this is a party that is used in smoke tests we do not want to save any
      // records
      if (!shouldInsertRecords(metadata.getPartyId())) {
        log.info(
            "Party {} is found on the blacklist, not inserting a WorkLog or ContactDetailsChange entry",
            metadata.getPartyId());
        return;
      }

      contactDetailsChangeRepository.save(contact);

      insertWorkLogRecord(metadata.getPartyId(), Operation.EMAIL_ADDRESS, request, metadata);
    } else {
      throw new CustomerValidationException(
          "No changes have been detected", CustomerValidationExceptionReason.NO_CHANGES_DETECTED);
    }
  }

  public void updatePhoneNumber(
      final PhoneNumberRequest phoneNumberRequest,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {

    final LocalDateTime processTime = LocalDateTime.now(clock);

    scaManager.validateUpdatePhoneNumberSca(
        Operation.PHONE_NUMBER, phoneNumberRequest, metadata, scaCredentials);

    final GoldenCustomerRecord customer;
    try {
      customer = getCustomerDetails(metadata, GoldenCustomerRecord.class);
    } catch (CustomerNotFoundException e) {
      auditPhoneNumberFailure(metadata, "Customer Not Found", phoneNumberRequest);
      throw e;
    }

    if (customer.isAmendmentRestriction()) {
      auditPhoneNumberFailure(metadata, AMENDMENT_RESTRICTION_ON_ACCOUNT, phoneNumberRequest);
      throw new AmendmentRestrictionException(AMENDMENT_RESTRICTION_ON_ACCOUNT);
    }

    final ContactDetailsChange contact = getContactDetailsChange(customer);

    List<WorkLogPayload> requests =
        phoneNumberRequest.getPhoneNumbers().stream()
            .map(workLogPayloadMapper::map)
            .filter(f -> f.accept(new UpdateContactDetailsChangeVisitor(contact, processTime)))
            .collect(Collectors.toList());

    if (requests.isEmpty()) {
      throw new CustomerValidationException(
          "No changes have been detected", CustomerValidationExceptionReason.NO_CHANGES_DETECTED);
    }

    if (contact.getHomeTelephoneNumber() == null
        && contact.getMobileTelephoneNumber() == null
        && contact.getWorkTelephoneNumber() == null) {
      throw new CustomerValidationException(
          "Customer must have at least one phone number",
          CustomerValidationExceptionReason.MIN_PHONE_NUMBERS);
    }

    // If this is a party that is used in smoke tests we do not want to save any
    // records
    if (!shouldInsertRecords(metadata.getPartyId())) {
      log.info(
          "Party {} is found on the blacklist, not inserting a WorkLog or ContactDetailsChange entry",
          metadata.getPartyId());
      return;
    }

    contactDetailsChangeRepository.saveAndFlush(contact);

    insertWorkLogRecords(metadata.getPartyId(), requests, metadata);
  }

  public void reportFailure(final FailureRequest request, final RequestMetadata requestMetadata) {
    try {
      challengeService.decodeChallenge(
          request.getChallenge(), Object.class); // If invalid throw 403 sca exception

      auditCustomerChallengeFailure(
          request, requestMetadata, "Client-side authentication error reported");
    } catch (InvalidScaException ex) {
      log.info("Unable to validate challenge is genuine: {}", ex.getMessage());
      throw new BadFailureRequestChallengeException("Authentication Failure Recorded");
    }
  }

  /**
   * Gets customer delayed record with or without web logon details from ADG Core if single record
   * found. throws resource not found if there is no match. throws multiple records found if
   * multiple records match (after matching with surname and Title and executing the dedupe
   * eligibility check)
   *
   * <p>Approach : fetches the list of party sys id's using the four input fields then checks the
   * party sys id's are linked or not if not linked throw multiple records found exception(Surname
   * and title matched if not equal or more than one record found using
   * soa_party_data.fn_eligible_for_party_hub) else calls pack_web_logon.fn_get_main_web_logon
   * function to fetch web logon details then fetches party information maps the both responses
   * return customer delayed record
   *
   * @param customerDelayedRequest request payload
   * @param yesterday yesterday's date used to fetch the record
   * @return customer delayed record
   */
  public CustomerBasic getCustomerDelayed(
      final CustomerDelayedRequest customerDelayedRequest, final LocalDateTime yesterday) {

    // get the matched party sys id's for the inputs
    final List<CustomerPartySysID> customerPartySysIDsList =
        getMatchedPartySysIds(customerDelayedRequest, yesterday);
    Long customerPartySysID = customerPartySysIDsList.get(0).getPartyId();

    // fetch linked parties for the specified party id
    final Set<Long> linkedParties = getPartiesLink(customerPartySysID, customerDelayedRequest);
    final Set<Long> matchedParties =
        customerPartySysIDsList.stream()
            .map(CustomerPartySysID::getPartyId)
            .collect(Collectors.toSet());

    // checks matched and linked parties if not matched throw multiple records found exception
    if (!linkedParties.containsAll(matchedParties)) {
      // checks if surname and title are same for the matched parties
      Set<String> fieldsMatch =
          customerPartySysIDsList.stream()
              .map(party -> party.getSurname() + party.getTitle())
              .collect(Collectors.toSet());
      if (fieldsMatch.size() != 1) {
        log(
            "Multiple records of size "
                + fieldsMatch.size()
                + " found in ADG Core post surname/title match for the inputs forename:",
            customerDelayedRequest,
            LOG_LEVEL_ERROR);
        throw multipleRecordsFound(customerDelayedRequest);
      }
      Set<Long> eligibleParties = getDeDupeEligibleParties(matchedParties, customerDelayedRequest);
      if (eligibleParties.size() != 1) {
        Set<Long> eligibleLinkedParties =
            getPartiesLink(eligibleParties.stream().findFirst().get(), customerDelayedRequest);
        if (!eligibleLinkedParties.containsAll(eligibleParties)) {
          log(
              "Multiple records of size "
                  + eligibleParties.size()
                  + " found in ADG Core post dedupe for the inputs forename:",
              customerDelayedRequest,
              LOG_LEVEL_ERROR);
          throw multipleRecordsFound(customerDelayedRequest);
        }
      }
      customerPartySysID = eligibleParties.stream().findFirst().get();
    }
    log(
        "Customer record found in ADG for the inputs forename:",
        customerDelayedRequest,
        LOG_LEVEL_INFO);

    final CustomerWebLogOnDetails customerWebLogOnDetails =
        getWebLogonDetails(customerPartySysID, customerDelayedRequest);
    log(
        "Customer web log details found in ADG Core for the inputs forename:",
        customerDelayedRequest,
        LOG_LEVEL_INFO);

    // get canonical party sys id
    final LinkedParty linkedParty = getCanonicalPartyId(customerPartySysID);
    // get party information
    final Optional<Party> party = getParty(linkedParty.getCanonicalPartyId(), yesterday);
    if (!party.isPresent()) {
      customerNotFound(customerPartySysID);
    }
    return customerBasicMapper.map(party.get(), customerWebLogOnDetails);
  }

  private Set<Long> getPartiesLink(
      final Long customerPartySysID, final CustomerDelayedRequest customerDelayedRequest) {
    List<LinkedPartyDetails> linkedPartyList =
        getLinkedParties(customerPartySysID, customerDelayedRequest);

    final Set<Long> linkedParties =
        linkedPartyList.stream().map(LinkedPartyDetails::getPartyId).collect(Collectors.toSet());
    return linkedParties;
  }

  private List<CustomerPartySysID> getMatchedPartySysIds(
      final CustomerDelayedRequest customerDelayedRequest, final LocalDateTime yesterday) {
    // get the first word from web input forename -- reference from ecom non login retrieval
    // forename check
    final String forename =
        customerDelayedRequest.getForename().trim().split("\\s")[0].toUpperCase(LOCALE);
    // removing spaces from web input post code
    final String postCode = formattedPostalAddress(customerDelayedRequest.getPostCode());

    final List<CustomerPartySysID> customerPartySysIDsList =
        partyRepository
            .findPartySysIds(
                forename,
                customerDelayedRequest.getDateOfBirth(),
                postCode,
                customerDelayedRequest.getMobileNumber(),
                yesterday)
            .orElseThrow(() -> customerNotFound(customerDelayedRequest));

    // throw no record found exception if no match in ADG Core for the inputs
    if (customerPartySysIDsList.isEmpty()) {
      log(
          "No record found in ADG Core for the inputs forename:",
          customerDelayedRequest,
          LOG_LEVEL_ERROR);
      throw customerNotFound(customerDelayedRequest);
    }
    log(
        "Found matched party sys id's in ADG Core for the inputs forename:",
        customerDelayedRequest,
        LOG_LEVEL_INFO);
    return customerPartySysIDsList;
  }

  private List<LinkedPartyDetails> getLinkedParties(
      final Long customerPartySysID, final CustomerDelayedRequest customerDelayedRequest) {
    final List<LinkedPartyDetails> linkedPartyList =
        partyRepository
            .findLinkedParties(customerPartySysID)
            .orElseThrow(() -> customerNotFound(customerDelayedRequest));

    // throw no record found exception if linked party not found in ADG Core
    if (linkedPartyList.isEmpty()) {
      log(
          "No linked party sys id's found in ADG Core for the inputs forename:",
          customerDelayedRequest,
          LOG_LEVEL_ERROR);
      throw customerNotFound(customerDelayedRequest);
    }
    log(
        "Found linked party sys id's found in ADG Core for the inputs forename:",
        customerDelayedRequest,
        LOG_LEVEL_INFO);
    return linkedPartyList;
  }

  private Set<Long> getDeDupeEligibleParties(
      final Set<Long> matchedParties, final CustomerDelayedRequest customerDelayedRequest) {
    final Set<Long> eligibleParties =
        matchedParties.stream()
            .filter(Objects::nonNull)
            .filter(
                partySysId ->
                    YES.equalsIgnoreCase(
                        partyRepository.findDeDupeEligiblePartyId(partySysId).getEligibility()))
            .collect(Collectors.toSet());
    if (eligibleParties.isEmpty()) {
      log(
          "No Eligible party sys id's found in ADG Core for the inputs forename:",
          customerDelayedRequest,
          LOG_LEVEL_ERROR);
      throw customerNotFound(customerDelayedRequest);
    }
    log(
        "Found eligible party sys id's post DeDupe function for the inputs forename:",
        customerDelayedRequest,
        LOG_LEVEL_INFO);

    return eligibleParties;
  }

  private CustomerWebLogOnDetails getWebLogonDetails(
      final Long customerPartySysID, final CustomerDelayedRequest customerDelayedRequest) {
    return partyRepository
        .findWebLogonDetails(customerPartySysID)
        // empty web log on details to handle non web user business rule in digital user
        // service
        .orElseGet(() -> getEmptyWebLogOnDetails(customerDelayedRequest));
  }

  private void log(
      final String message,
      final CustomerDelayedRequest customerDelayedRequest,
      final String logLevel) {
    if (LOG_LEVEL_INFO.equalsIgnoreCase(logLevel)) {
      log.info(
          message
              + customerDelayedRequest.getForename()
              + " - postCode:"
              + customerDelayedRequest.getPostCode()
              + " - mobileNumber:"
              + maskPhoneNumber(customerDelayedRequest.getMobileNumber()));
    } else if (LOG_LEVEL_ERROR.equalsIgnoreCase(logLevel)) {
      log.error(
          message
              + customerDelayedRequest.getForename()
              + " - postCode:"
              + customerDelayedRequest.getPostCode()
              + " - mobileNumber:"
              + maskPhoneNumber(customerDelayedRequest.getMobileNumber()));
    }
  }

  private CustomerWebLogOnDetails getEmptyWebLogOnDetails(
      final CustomerDelayedRequest customerDelayedRequest) {
    log.info(
        "Customer web log on record not found in ADG for the inputs forename:"
            + customerDelayedRequest.getForename()
            + " - postCode:"
            + customerDelayedRequest.getPostCode()
            + " - mobileNumber:"
            + maskPhoneNumber(customerDelayedRequest.getMobileNumber()));
    return CustomerWebLogOnDetails.builder().build();
  }

  private void auditCustomerChallengeFailure(
      final FailureRequest request,
      final RequestMetadata requestMetadata,
      @SuppressWarnings("SameParameterValue") final String message) {

    final AuditAuthenticationFailureRequest auditRequest =
        AuditAuthenticationFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(message)
            .build();

    if (FailureType.POSTAL_ADDRESS.equals(request.getFailureType())) {
      auditService.auditCustomerPostalAddressChallengeFailure(auditRequest, requestMetadata);
    } else {
      auditService.auditCustomerNonPostalAddressChallengeFailure(auditRequest, requestMetadata);
    }
  }

  private ContactDetailsChange getContactDetailsChange(final GoldenCustomerRecord customer) {
    // we will look for any changes in the last hour on front office as this is the max amount adg
    // can be out of date with core.
    final LocalDateTime earliestDate = LocalDateTime.now(clock).minusHours(1);

    return contactDetailsChangeRepository
        .findLatestChangeForPartiesAfterEarliestTime(
            Collections.singletonList(customer.getPartyId()), earliestDate)
        .orElse(contactDetailsChangeMapper.map(customer));
  }

  private void insertWorkLogRecords(
      final String partyId,
      final List<? extends WorkLogPayload> requests,
      final RequestMetadata metadata) {

    for (WorkLogPayload request : requests) {

      final Operation operation;

      if (request instanceof UpdatePhoneRequest) {
        operation = Operation.UPDATE_PHONE_NUMBER;
      } else {
        operation = Operation.DELETE_PHONE_NUMBER;
      }

      insertWorkLogRecord(partyId, operation, request, metadata);
    }
  }

  private void insertWorkLogRecord(
      final String partyId,
      final Operation operation,
      final WorkLogPayload request,
      final RequestMetadata metadata) {
    log.info("Creating {} work log for customer {}: {}", operation.toString(), partyId, request);

    workLogRepository.save(
        WorkLog.builder()
            .partyId(Long.valueOf(partyId))
            .message(WorkLogRequest.builder().workLogPayload(request).metadata(metadata).build())
            .status(WorkLog.Status.PENDING)
            .operation(operation)
            .createdBy(SAPP_CHANNEL)
            .build());
  }

  private AccountGroupedInfo getAccountGroups(final RequestMetadata requestMetadata) {
    return accountService.getGroupedAccountInfo(requestMetadata, false);
  }

  private void auditEmailAddressFailure(
      final RequestMetadata requestMetadata, final String message, final String emailAddress) {
    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        AuditNonPostalAddressUpdateFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .operation(NonPostalOperation.EMAIL_ADDRESS)
            .message(message)
            .address(emailAddress)
            .type(NonPostalType.EMAIL)
            .build();
    auditService.auditNonPostalAddressUpdateFailure(auditRequest, requestMetadata);
  }

  private void auditPhoneNumberFailure(
      final RequestMetadata requestMetadata,
      final String message,
      final PhoneNumberRequest phoneNumberRequest) {

    for (PhoneNumberBasic phoneNumber : phoneNumberRequest.getPhoneNumbers()) {

      final AuditNonPostalAddressUpdateFailureRequest auditRequest =
          AuditNonPostalAddressUpdateFailureRequest.builder()
              .ipAddress(requestMetadata.getIpAddress())
              .operation(NonPostalOperation.PHONE_NUMBER)
              .message(message)
              .type(NonPostalType.valueOf(phoneNumber.getType().toString()))
              .address(phoneNumber.getNumber())
              .build();

      auditService.auditNonPostalAddressUpdateFailure(auditRequest, requestMetadata);
    }
  }

  private void auditPostalAddressFailure(
      final RequestMetadata requestMetadata,
      final String message,
      final PostalAddressRequest postalAddressRequest) {

    final AuditPostalAddressUpdateFailureRequest auditRequest =
        AuditPostalAddressUpdateFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(message)
            .postalAddressRequest(postalAddressRequest)
            .build();
    auditService.auditPostalAddressUpdateFailure(auditRequest, requestMetadata);
  }

  private String formattedPostalAddress(final GoldenCustomerRecord customer) {
    final StringBuilder postalAddress = new StringBuilder();

    customer.getAddresses().get(0).getAddressLines().forEach(postalAddress::append);

    postalAddress
        .append(customer.getAddresses().get(0).getCountry())
        .append(customer.getAddresses().get(0).getPostCode());

    return formattedPostalAddress(postalAddress.toString());
  }

  private String formattedPostalAddress(final PostalAddressRequest address) {
    final StringBuilder postalAddress = new StringBuilder();

    address.getAddress().getAddressLines().forEach(postalAddress::append);

    postalAddress
        .append(address.getAddress().getCountry().getIsoCode())
        .append(address.getAddress().getPostCode());

    return formattedPostalAddress(postalAddress.toString());
  }

  private String formattedPostalAddress(final String postalAddress) {
    return postalAddress.replaceAll("\\s", "").toUpperCase(LOCALE);
  }

  private Boolean shouldInsertRecords(final String partyId) {
    return Optional.ofNullable(customerServiceProperties.getPartyBlacklist())
        .map(
            blacklist ->
                blacklist.stream().noneMatch(blacklisted -> blacklisted.equalsIgnoreCase(partyId)))
        .orElse(true);
  }

  /**
   * Mask mobile number.
   *
   * @param mobileNumber the phone number
   * @return the string
   */
  public String maskPhoneNumber(final String mobileNumber) {

    final int unmaskedDigitsLength = 3;
    if (mobileNumber == null || StringUtils.isEmpty(mobileNumber)) {
      return "";
    }
    String phoneNo = mobileNumber.replaceAll("\\s", "");
    int maskedDigits = phoneNo.length() - unmaskedDigitsLength;

    return StringUtils.repeat("*", maskedDigits)
        + phoneNo.substring(phoneNo.length() - unmaskedDigitsLength);
  }
}
