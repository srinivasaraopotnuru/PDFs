package uk.co.ybs.digital.customer.repository.core;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.customer.model.core.Metadata;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public interface MetadataRepository extends JpaRepository<Metadata, Long> {}
