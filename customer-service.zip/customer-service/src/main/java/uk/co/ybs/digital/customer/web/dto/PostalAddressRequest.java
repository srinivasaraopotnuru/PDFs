package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PostalAddressRequest {

  @JsonProperty(value = "address")
  @NotNull(message = "You must specify an address")
  @ApiModelProperty(required = true)
  @Valid
  private final PostalAddress address;

  @JsonProperty(value = "pafData")
  @ApiModelProperty()
  @Valid
  private final PafData paf;
}
