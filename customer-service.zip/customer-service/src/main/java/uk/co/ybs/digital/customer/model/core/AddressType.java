package uk.co.ybs.digital.customer.model.core;

public enum AddressType {
  EMAIL,
  TEL,
  UKPOST,
  BFPO,
  FPOST,
  EGGT,
  EGGM,
  FAX
}
