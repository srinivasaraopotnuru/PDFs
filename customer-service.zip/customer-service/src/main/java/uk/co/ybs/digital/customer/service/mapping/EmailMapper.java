package uk.co.ybs.digital.customer.service.mapping;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.service.PendingDetailsService;
import uk.co.ybs.digital.customer.web.dto.EmailAddressResponse;

@Mapper(componentModel = "spring")
public class EmailMapper {

  protected transient PendingDetailsService pendingDetailsService;

  @Autowired
  public void setService(final PendingDetailsService service) {
    this.pendingDetailsService = service;
  }

  public String email(final List<AddressUsage> addresses) {
    return addresses.stream()
        .map(AddressUsage::getNonPostalAddress)
        .filter(npa -> npa.getType() == AddressType.EMAIL)
        .findFirst()
        .map(NonPostalAddress::getAddress)
        .orElse(null);
  }

  public List<EmailAddressResponse> emailAddresses(final Party party) {
    final List<AddressUsage> addresses = party.getAddresses();

    return addresses.stream()
        .filter(
            addr ->
                addr.getNonPostalAddress() != null
                    && AddressType.EMAIL == addr.getNonPostalAddress().getType())
        .filter(matchOnlyLatestEmailEntry(addresses))
        .map(AddressUsage::getNonPostalAddress)
        .map(addr -> pendingDetailsService.buildEmailAddressResponse(party, addr))
        .collect(Collectors.toList());
  }

  private static Predicate<AddressUsage> matchOnlyLatestEmailEntry(
      final List<AddressUsage> addresses) {
    return currentEntry ->
        addresses.stream()
                .filter(
                    address ->
                        address.getNonPostalAddress() != null
                            && address.getNonPostalAddress().getType() == AddressType.EMAIL)
                .filter(address -> address.getCreatedDate().isAfter(currentEntry.getCreatedDate()))
                .count()
            == 0;
  }
}
