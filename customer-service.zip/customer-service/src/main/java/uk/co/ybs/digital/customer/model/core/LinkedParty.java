package uk.co.ybs.digital.customer.model.core;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@SqlResultSetMapping(
    name = LinkedParty.LINKED_PARTY_RESULT_SET_MAPPING,
    entities =
        @EntityResult(
            entityClass = LinkedParty.class,
            fields = {
              @FieldResult(name = "originalPartyId", column = "ORIGINAL_SYSID"),
              @FieldResult(name = "canonicalPartyId", column = "CANONICAL_SYSID"),
              @FieldResult(name = "linkCount", column = "LINKS"),
            }))
@NamedNativeQuery(
    name = LinkedParty.FIND_CANONICAL_PARTY_ID_QUERY,
    resultSetMapping = LinkedParty.LINKED_PARTY_RESULT_SET_MAPPING,
    //       LINKED_PARTIES is a temporary table that stores the cumulative state as we traverse the
    // graph of linked party IDs
    query =
        "WITH LINKED_PARTIES(STARTING_SYSID, CURR_SYSID, NEXT_SYSID, LINKS) AS ("
            + "  ( "
            +
            //     Find the record associated with the original SYSID. The SYSID is also stored in
            // the STARTING_SYSID
            //     column of the temporary LINKED_PARTIES table. We also store an initial links
            // value of 0.
            "    SELECT SYSID, SYSID, PARTY_LINK_SYSID, 0 "
            + "    FROM PARTIES "
            + "    WHERE SYSID = ?1 "
            + "  ) "
            +
            // Continue storing records into the temporary table until we can no longer join from
            // the temporary
            // table back to the PARTIES table i.e. when there is no longer a PARTY_LINK_SYSID and
            // therefore we are
            // at at a canonical party Id
            "  UNION ALL "
            + "  ( "
            +
            //     For each parent link we store it's SYSID and parent SYSID along with the
            // STARTING_SYSID that is
            //     copied from the previous LINKED_PARTIES entry. We also bump the LINKS value by
            // one to
            "    SELECT STARTING_SYSID, PARENT.SYSID, PARENT.PARTY_LINK_SYSID, LINKS + 1 "
            + "    FROM LINKED_PARTIES CHILD "
            + "    INNER JOIN PARTIES PARENT ON CHILD.NEXT_SYSID = PARENT.SYSID "
            + "  )"
            + ")"
            +
            // Rename the columns so they make more sense for the final result.
            "SELECT STARTING_SYSID AS ORIGINAL_SYSID, CURR_SYSID AS CANONICAL_SYSID, LINKS FROM LINKED_PARTIES "
            +
            // The highest LINKS number is final record and therefore the one with the canonical
            // party Id.
            "ORDER BY LINKS DESC "
            + "FETCH NEXT ROW ONLY")
public class LinkedParty {
  public static final String FIND_CANONICAL_PARTY_ID_QUERY = "findCanonicalPartyId";
  public static final String LINKED_PARTY_RESULT_SET_MAPPING = "LinkedParty";

  @Id private Long originalPartyId;
  private Long canonicalPartyId;
  private Long linkCount;
}
