package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;
import uk.co.ybs.digital.customer.service.apply.validation.TrimmedSize;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TaxDetails {

  private static final String TAX_IDENTIFICATION_NUMBER_REGEX =
      "^((\\d{3})([\\-])(\\d{2})([\\-])(\\d{4}))|((\\d{2})([\\-])(\\d{7}))|(\\d{9})$";

  @NotNull(message = "Please specify US Citizen")
  @ApiModelProperty(required = true, value = "US Citizen")
  private Boolean usCitizen;

  @Pattern(
      regexp = TAX_IDENTIFICATION_NUMBER_REGEX,
      message = "Please specify valid Tax Identification number matching pattern: {regexp}.")
  @ApiModelProperty(
      required = true,
      value = "Tax Identification number must match " + TAX_IDENTIFICATION_NUMBER_REGEX + " regex")
  private String taxIdentificationNumber;

  @NotNull(message = "Please specify UK Taxpayer")
  @ApiModelProperty(required = true, value = "UK Taxpayer")
  private Boolean ukTaxPayer;

  @Valid
  @Size(max = 2, message = "Maximum {max} non Uk details are allowed")
  @ApiModelProperty(required = true, value = "Valid NON-UK tax details.")
  @Singular("nonUkTaxDetails")
  private List<NonUkTaxDetail> nonUkTaxDetails;

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class NonUkTaxDetail {
    private static final int TAX_REFERENCE_NUMBER_MAX_LENGTH = 20;

    /** Restrict special characters and printable Regex. */
    private static final String RESTRICT_SPECIAL_CHAR_AND_PRINTABLE_REGEX =
        "^(?!.*/\\*)^(?!.*--)[\\p{Print}&&[^&<>'\"]]*$";

    @NotNull(message = "Please specify tax reference number")
    @NotEmpty(message = "Tax reference number must not be empty")
    @TrimmedSize(
        min = 1,
        max = TAX_REFERENCE_NUMBER_MAX_LENGTH,
        message = "Tax Reference number must be between {min} and {max} " + "characters in length")
    @Pattern(
        regexp = RESTRICT_SPECIAL_CHAR_AND_PRINTABLE_REGEX,
        message = "Please specify valid tax reference number" + " matching pattern: {regexp}.")
    @ApiModelProperty(required = true, value = "Tax Reference number of maximum size 20")
    private String taxReferenceNumber;

    @NotNull(message = "Please specify countryCode")
    @NotEmpty(message = "CountryCode must not be empty")
    @ApiModelProperty(required = true, value = "countryCode")
    private String countryCode;
  }
}
