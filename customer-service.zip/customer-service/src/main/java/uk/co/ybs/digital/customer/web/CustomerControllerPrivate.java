package uk.co.ybs.digital.customer.web;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uk.co.ybs.digital.customer.config.SwaggerConfig;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.exception.MultipleRecordsFoundException;
import uk.co.ybs.digital.customer.service.CustomerService;
import uk.co.ybs.digital.customer.web.dto.CustomerBasicResponse;
import uk.co.ybs.digital.customer.web.dto.CustomerDelayedRequest;
import uk.co.ybs.digital.customer.web.dto.CustomerDetailsExtendedResponse;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerExtendedRecord;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.logging.filters.session.SessionIdFilter;

@RestController
@RequestMapping("/private")
@RequiredArgsConstructor
@Validated
public class CustomerControllerPrivate {

  private final CustomerService customerService;
  private final Clock clock;
  private static final String BAD_REQUEST = "Bad request";
  private static final String UNAUTHORISED = "Unauthorised";
  private static final String FORBIDDEN = "Forbidden";
  private static final String RESOURCE_NOT_FOUND = "Resource not found";

  @GetMapping(value = "/customer/{partyId}", produces = MediaType.APPLICATION_JSON_VALUE)
  @ApiOperation(value = "Get details for a customer")
  public CustomerBasicResponse getCustomerBasic(
      @PathVariable @ApiParam(value = "Customer number for the request", required = true)
          final long partyId) {

    final LocalDateTime now = LocalDateTime.now(clock);

    return CustomerBasicResponse.builder()
        .customer(customerService.getCustomer(partyId, now))
        .build();
  }

  @GetMapping(value = "/customer/delayed/{partyId}", produces = MediaType.APPLICATION_JSON_VALUE)
  @ApiOperation(value = "Get details for a customer with yesterdays contact details")
  public CustomerBasicResponse getCustomerBasicDelayed(
      @PathVariable @ApiParam(value = "Customer number for the request", required = true)
          final long partyId) {

    final LocalDateTime yesterday = LocalDate.now(clock).minusDays(1).atTime(23, 59, 59);

    return CustomerBasicResponse.builder()
        .customer(customerService.getCustomer(partyId, yesterday))
        .build();
  }

  @GetMapping(value = "/customer", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('SCOPE_ACCOUNT_READ')")
  @ApiOperation(
      value = "Get details for an authenticated customer",
      authorizations = {@Authorization(value = SwaggerConfig.SECURITY_SCHEME)})
  public CustomerDetailsExtendedResponse getCustomerDetails(
      @ApiParam(hidden = true) @AuthenticationPrincipal final Jwt user,
      @ApiParam(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @ApiParam(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      final HttpServletRequest request,
      @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetadataHelper.buildRequestMetadata(user, sessionId, requestId, request, headers);
    try {
      CustomerDetailsExtendedResponse result =
          CustomerDetailsExtendedResponse.builder()
              .goldenCustomerExtendedRecord(
                  customerService.getCustomerDetails(metadata, GoldenCustomerExtendedRecord.class))
              .build();

      return result;
    } catch (CustomerNotFoundException ex) {
      throw new CustomerServiceException("Customer not found for party Id in JWT", ex);
    }
  }

  @GetMapping(value = "/customer/available-products", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize("hasAuthority('SCOPE_ACCOUNT_READ')")
  @ApiOperation(
      value = "Get available products for an authenticated customer",
      authorizations = {@Authorization(value = SwaggerConfig.SECURITY_SCHEME)})
  public List<ProductCategory> getAvailableProducts(
      @ApiParam(hidden = true) @AuthenticationPrincipal final Jwt user,
      @ApiParam(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @ApiParam(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      final HttpServletRequest request,
      @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetadataHelper.buildRequestMetadata(user, sessionId, requestId, request, headers);

    return customerService.getAvailableProducts(metadata);
  }

  /**
   * Get customer delayed record from ADG Core using forename, dateOfBirth, postCode, mobileNumber
   *
   * @param customerDelayedRequest request payload
   * @return customer delayed record
   * @throws CustomerNotFoundException custom exception for no record
   * @throws MultipleRecordsFoundException custom exception for multiple records
   */
  @PostMapping(
      value = "/customer/delayed",
      consumes = MediaType.APPLICATION_JSON_VALUE,
      produces = MediaType.APPLICATION_JSON_VALUE)
  @ApiResponses(
      value = {
        @ApiResponse(code = 400, message = BAD_REQUEST, response = ErrorResponse.class),
        @ApiResponse(code = 401, message = UNAUTHORISED, response = ErrorResponse.class),
        @ApiResponse(code = 403, message = FORBIDDEN, response = ErrorResponse.class),
        @ApiResponse(code = 404, message = RESOURCE_NOT_FOUND, response = ErrorResponse.class),
        @ApiResponse(
            code = 409,
            message = "Multiple records found",
            response = ErrorResponse.class),
        @ApiResponse(
            code = 415,
            message = "Unsupported Media Type",
            response = ErrorResponse.class),
        @ApiResponse(code = 500, message = "Internal Server Error", response = ErrorResponse.class)
      })
  @ApiOperation(
      value =
          "Get a customer delayed record from ADG Core for the inputs forename, date of birth, postal code and mobile number")
  public CustomerBasicResponse getCustomerDelayed(
      @RequestBody @Validated final CustomerDelayedRequest customerDelayedRequest) {
    final LocalDateTime yesterday = LocalDate.now(clock).minusDays(1).atTime(23, 59, 59);
    return CustomerBasicResponse.builder()
        .customer(customerService.getCustomerDelayed(customerDelayedRequest, yesterday))
        .build();
  }
}
