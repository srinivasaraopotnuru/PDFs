package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings({"PMD.CommentDefaultAccessModifier", "PMD.AvoidDuplicateLiterals"})
public class MarketingPreferences {

  @ApiModelProperty(example = "true")
  Boolean email;

  @ApiModelProperty(example = "true")
  Boolean phone;

  @ApiModelProperty(example = "true")
  Boolean post;

  @ApiModelProperty(example = "true")
  Boolean eagm;
}
