package uk.co.ybs.digital.customer.web.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum PermittedCountries {
  UNITED_KINGDOM("UK", "UNITED KINGDOM", "GB"),
  GUERNSEY("UKGG", "UK (GUERNSEY)", "GG"),
  ISLE_OF_MAN("UKIM", "UK (ISLE OF MAN)", "IM"),
  JERSEY("UKJE", "UK (JERSEY)", "JE");

  private final String code;
  private final String description;
  private final String isoCode;
}
