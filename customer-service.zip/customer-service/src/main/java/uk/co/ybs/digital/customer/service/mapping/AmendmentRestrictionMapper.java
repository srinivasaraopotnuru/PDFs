package uk.co.ybs.digital.customer.service.mapping;

import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountGroup;

@Component
public class AmendmentRestrictionMapper {
  public boolean isRestricted(final AccountGroupedInfo accountGroups) {
    return Stream.of(
            Optional.ofNullable(accountGroups.getOwned()),
            Optional.ofNullable(accountGroups.getOther()))
        .filter(Optional::isPresent)
        .map(Optional::get)
        .map(AccountGroup::getAccounts)
        .flatMap(Collection::stream)
        .anyMatch(AccountGroupedInfo.AccountSummary::isAmendmentRestriction);
  }
}
