package uk.co.ybs.digital.customer.model.digitalcustomer;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@EqualsAndHashCode(callSuper = false)
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class UpdateEmailRequest extends WorkLogPayload {
  @NonNull String requestType;
  @NonNull String email;

  @Override
  public <T> T accept(final WorkLogPayloadVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
