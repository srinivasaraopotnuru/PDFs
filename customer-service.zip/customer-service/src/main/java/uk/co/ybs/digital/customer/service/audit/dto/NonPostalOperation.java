package uk.co.ybs.digital.customer.service.audit.dto;

public enum NonPostalOperation {
  EMAIL_ADDRESS,
  PHONE_NUMBER
}
