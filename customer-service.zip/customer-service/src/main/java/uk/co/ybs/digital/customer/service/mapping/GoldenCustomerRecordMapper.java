package uk.co.ybs.digital.customer.service.mapping;

import java.util.List;
import org.mapstruct.InheritConfiguration;
import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.Named;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.springframework.beans.factory.annotation.Autowired;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.adgcore.FatcaParty;
import uk.co.ybs.digital.customer.model.adgcore.FatcaProfile;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.web.dto.EncryptedData;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerExtendedRecord;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.services.crypto.asymmetric.Crypto;
import uk.co.ybs.services.crypto.asymmetric.CryptoException;

@Mapper(
    componentModel = "spring",
    uses = {
      PhoneNumberMapper.class,
      EmailMapper.class,
      PostalAddressMapper.class,
      MarketingPreferencesMapper.class,
      PreferencesMapper.class
    },
    injectionStrategy = InjectionStrategy.CONSTRUCTOR)
@SuppressWarnings("PMD.ExcessiveParameterList")
public abstract class GoldenCustomerRecordMapper {

  @Autowired private Crypto crypto;

  @Mappings(
      value = {
        @Mapping(source = "party.sysId", target = "partyId"),
        @Mapping(source = "party.person.title", target = "title"),
        @Mapping(source = "party.person.forenames", target = "forename"),
        @Mapping(source = "party.person.surname", target = "surname"),
        @Mapping(
            source = "party.person.nationalInsuranceNumber",
            target = "nationalInsuranceNumber"),
        @Mapping(source = "party.person.dateOfBirth", target = "dateOfBirth"),
        @Mapping(source = "party", target = "addresses"),
        @Mapping(source = "party", target = "emailAddresses"),
        @Mapping(source = "party", target = "phoneNumbers"),
        @Mapping(source = "amendmentRestriction", target = "amendmentRestriction"),
        @Mapping(source = "hasSharePlanAccount", target = "hasSharePlanAccount"),
        @Mapping(source = "hasIsaSubscription", target = "hasIsaSubscription"),
        @Mapping(source = "webCustomerNumber", target = "webCustomerNumber"),
        @Mapping(source = "party.person.nationality.name", target = "nationality"),
        @Mapping(source = "marketingOptIns", target = "marketingPreferences"),
        @Mapping(source = "marketingOptIns", target = "preferences"),
        @Mapping(
            nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
            source = "fatcaProfiles",
            target = "fatcaProfiles"),
        @Mapping(
            nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE,
            source = "fatcaParty",
            target = "fatcaParty")
      })
  public abstract GoldenCustomerRecord map(
      Party party,
      boolean amendmentRestriction,
      boolean hasSharePlanAccount,
      boolean hasIsaSubscription,
      String webCustomerNumber,
      List<MarketingOptIn> marketingOptIns,
      List<FatcaProfile> fatcaProfiles,
      FatcaParty fatcaParty);

  @InheritConfiguration(name = "map")
  @Mapping(target = "placeOfBirth", source = "party.placeOfBirth", qualifiedByName = "encrypt")
  public abstract GoldenCustomerExtendedRecord mapExtended(
      Party party,
      boolean amendmentRestriction,
      boolean hasSharePlanAccount,
      boolean hasIsaSubscription,
      String webCustomerNumber,
      List<MarketingOptIn> marketingOptIns,
      List<FatcaProfile> fatcaProfiles,
      FatcaParty fatcaParty);

  @Named("encrypt")
  public EncryptedData encryptValue(final String value) {

    if (value != null) {
      try {

        String defaultKey = crypto.getCryptoProperties().getKeys().get(0).getId();

        uk.co.ybs.services.model.EncryptedData encData =
            crypto.encrypt(defaultKey, value.toCharArray());

        return EncryptedData.builder().keyId(encData.getKeyId()).data(encData.getData()).build();
      } catch (CryptoException ex) {
        throw new CustomerServiceException("Failed to encrypt value", ex);
      }
    }

    return null;
  }
}
