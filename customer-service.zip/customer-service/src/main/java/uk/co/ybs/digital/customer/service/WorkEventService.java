package uk.co.ybs.digital.customer.service;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.customer.model.core.WorkEvent.ModuleLabelAssociationType;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventContextTableName;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventStatus;
import uk.co.ybs.digital.customer.model.core.WorkEventOutput;
import uk.co.ybs.digital.customer.repository.core.WorkEventCoreRepository;

@Service
@Slf4j
@AllArgsConstructor
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public class WorkEventService {

  @Autowired private final WorkEventCoreRepository workEventCoreRepository;

  public WorkEventOutput createAdacusWorkEvent(final Long partyId, final Long accountNumber) {
    log.info("Creating work event ADACUS for party: {}, account: {}", partyId, accountNumber);
    return workEventCoreRepository.createAdacusWorkEvent(partyId, accountNumber);
  }

  public Optional<WorkEventOutput> createChcamoWorkEvent(
      final Long partyId,
      final Long accountNumber,
      final Long accountType,
      final LocalDateTime processTime) {

    List<Long> results =
        workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            accountNumber,
            accountType,
            EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER),
            ModuleLabelAssociationType.CREEVT,
            "CUS0503U",
            "CHCAMO",
            processTime);

    if (results.isEmpty()) {
      log.info(
          "Creating work event CHCAMO for party: {}, account: {}{}",
          partyId,
          accountNumber,
          accountType);
      return Optional.of(workEventCoreRepository.createChcamoWorkEvent(accountNumber, accountType));
    }

    log.info(
        "Found existing work event CHCAMO for party: {}, account: {}{}, skipping creation",
        partyId,
        accountNumber,
        accountType);
    return Optional.empty();
  }
}
