package uk.co.ybs.digital.customer.service.utilities;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import uk.co.ybs.digital.customer.model.PostCode;

public final class PostCodeHelper {

  private static final List<String> ONLINE_RETAILERS = Arrays.asList("BX", "XX");

  private static final String GIBRALTAR = "GX111AA";

  private static final String POSTCODE_REGEX =
      "(?:(?:(?:(?<a2>[A-Z])(?<d2>[0-9]{1,2}))"
          + "|(?:(?:(?<a3>[A-Z][A-HJ-Y])(?<d3>[0-9]{1,2}))"
          + "|(?:(?:(?<a4>[A-Z])(?<d4>[0-9][A-Z]))"
          + "|(?:(?<a5>[A-Z][A-HJ-Y])(?<d5>[0-9]?[A-Z])))))"
          + "(?<sector>[0-9])(?<unit>[A-Z]{2}))";

  private static final Pattern POSTCODE_PATTERN = Pattern.compile(POSTCODE_REGEX);

  private PostCodeHelper() {}

  public static boolean isValidPostCode(final String postcode) {

    if (Optional.ofNullable(postcode).isPresent()) {
      String formattedPC = formatPostCode(postcode);
      return POSTCODE_PATTERN.matcher(formattedPC).matches()
          && !ONLINE_RETAILERS.contains(formattedPC.substring(0, 2))
          && !GIBRALTAR.equals(formattedPC);
    }

    return false;
  }

  public static Optional<PostCode> splitPostCode(final String postcode) {

    Optional<PostCode> optionalPostCode = Optional.empty();

    if (Optional.ofNullable(postcode).isPresent()) {
      String formattedPC = formatPostCode(postcode);

      Matcher matcher = POSTCODE_PATTERN.matcher(formattedPC);

      if (matcher.find()) {

        String area =
            Optional.ofNullable(matcher.group("a2"))
                .orElse(
                    Optional.ofNullable(matcher.group("a3"))
                        .orElse(
                            Optional.ofNullable(matcher.group("a4"))
                                .orElse(Optional.ofNullable(matcher.group("a5")).orElse(""))));

        String district =
            Optional.ofNullable(matcher.group("d2"))
                .orElse(
                    Optional.ofNullable(matcher.group("d3"))
                        .orElse(
                            Optional.ofNullable(matcher.group("d4"))
                                .orElse(Optional.ofNullable(matcher.group("d5")).orElse(""))));

        PostCode pc =
            PostCode.builder()
                .areaCode(area)
                .districtCode(district)
                .sectorCode(matcher.group("sector"))
                .unitCode(matcher.group("unit"))
                .build();
        optionalPostCode = Optional.of(pc);
      }
    }
    return optionalPostCode;
  }

  private static String formatPostCode(final String postcode) {
    return postcode.replaceAll("\\s", "").toUpperCase(Locale.ROOT);
  }

  public static String formatPostcode(
      final String areaCode,
      final String districtCode,
      final String sectorCode,
      final String unitCode) {
    return areaCode + districtCode + " " + sectorCode + unitCode;
  }
}
