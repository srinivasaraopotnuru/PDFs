package uk.co.ybs.digital.customer.service.mapping;

import java.util.Collection;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountGroup;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.Isa;

@Component
@Slf4j
public class IsaSubscriptionMapper {
  public boolean isSubscribed(final AccountGroupedInfo accountGroups) {
    return Stream.of(Optional.ofNullable(accountGroups.getOwned()))
        .filter(Optional::isPresent)
        .map(Optional::get)
        .map(AccountGroup::getAccounts)
        .flatMap(Collection::stream)
        .map(AccountGroupedInfo.AccountSummary::getIsa)
        .filter(Objects::nonNull)
        .anyMatch(Isa::isSubscribed);
  }
}
