package uk.co.ybs.digital.customer.service.shareplan;

import java.net.URL;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

@ConfigurationProperties(prefix = "uk.co.ybs.digital.shareplan")
@ConstructorBinding
@AllArgsConstructor
@Getter
public class ShareplanServiceProperties {
  @NonNull private final URL url;

  private final boolean enabled;
}
