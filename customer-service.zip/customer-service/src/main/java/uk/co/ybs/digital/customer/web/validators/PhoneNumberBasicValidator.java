package uk.co.ybs.digital.customer.web.validators;

import com.google.common.base.Strings;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import lombok.RequiredArgsConstructor;
import uk.co.ybs.digital.customer.service.AreaDiallingCodesService;
import uk.co.ybs.digital.customer.service.utilities.PhoneNumberUtilities;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;

@RequiredArgsConstructor
public class PhoneNumberBasicValidator
    implements ConstraintValidator<ValidPhoneNumberBasic, PhoneNumberBasic> {

  private final AreaDiallingCodesService areaDiallingCodesService;

  // "Character 1 = 0, Min Length of 7,  Max length of 11
  private static final String PHONE_NUMBER_REGEX = "^0\\d{6,10}$";
  private static final Pattern LANDLINE_PATTERN = Pattern.compile(PHONE_NUMBER_REGEX);

  // "Character 1&2 = 07, Min/Max length of 11
  private static final String MOBILE_NUMBER_REGEX = "^07([1-57-9]\\d{2}|624)\\d{6}$";
  private static final Pattern MOBILE_PATTERN = Pattern.compile(MOBILE_NUMBER_REGEX);

  @Override
  public void initialize(final ValidPhoneNumberBasic constraintAnnotation) {}

  @Override
  public boolean isValid(
      final PhoneNumberBasic phoneNumber, final ConstraintValidatorContext context) {
    String message = null;

    // null type on PhoneNumberBasic will be reported by field level constraints within the dto
    if (phoneNumber.getType() == null) {
      return true;
    }

    if (Strings.isNullOrEmpty(phoneNumber.getNumber())) {
      return true;
    }

    String number = PhoneNumberUtilities.formatPhoneNumber(phoneNumber.getNumber());

    if (PhoneNumberUtilities.isHomeOrWorkNumber(phoneNumber.getType(), phoneNumber.getNumber())) {

      final Matcher landlineMatcher = LANDLINE_PATTERN.matcher(number);

      if (landlineMatcher.find()) {
        if (!areaDiallingCodesService.determineAreaDiallingCode(number).isPresent()) {
          message = "Area dialling code not recognised";
        }
      } else if (phoneNumber.getType().equals(PhoneNumberBasicType.WORK)) {
        final Matcher workMobileMatcher = MOBILE_PATTERN.matcher(number);

        if (workMobileMatcher.find()) {
          if (!areaDiallingCodesService.determineAreaDiallingCode(number).isPresent()) {
            message = "Area dialling code not recognised";
          }
        } else {
          message = "Phone Number not a valid landline or mobile number";
        }
      } else {
        message = "Phone Number not a valid landline number";
      }
    } else {

      final Matcher mobileMatcher = MOBILE_PATTERN.matcher(number);

      if (!mobileMatcher.find()) {
        message = "Phone Number not a valid mobile number";
      }
    }

    if (message != null) {

      context.disableDefaultConstraintViolation();
      context
          .buildConstraintViolationWithTemplate(message)
          .addPropertyNode("number")
          .addConstraintViolation();

      return false;
    }
    return true;
  }
}
