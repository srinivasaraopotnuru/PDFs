package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Singular;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.customer.web.validators.PostCode;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PostalAddress {
  @ApiModelProperty(required = true, example = "CORR")
  PostalAddressType type;

  @ApiModelProperty(required = true, example = "UKPOST")
  PostalAddressSubType subType;

  @ApiModelProperty(value = "List of Address Lines")
  @Singular
  @NotEmpty(message = "You must have at least 1 address line")
  @Size(max = 5, message = "A maximum of 5 address lines is permitted")
  List<String> addressLines;

  @NotNull(message = "You must specify a country")
  @Valid
  @ApiModelProperty(required = true, example = "UNITED_KINGDOM")
  PermittedCountries country;

  @NotNull(message = "You must specify a post code")
  @PostCode
  @ApiModelProperty(required = true, example = "LS1 8EQ")
  String postCode;

  public enum PostalAddressType {
    CORR
  }

  public enum PostalAddressSubType {
    UKPOST
  }
}
