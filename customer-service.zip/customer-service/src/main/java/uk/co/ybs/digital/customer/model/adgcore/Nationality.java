package uk.co.ybs.digital.customer.model.adgcore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "NATIONALITIES")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Nationality {
  @Id
  @Column(name = "CODE")
  private String code;

  @Column(name = "NAME")
  private String name;
}
