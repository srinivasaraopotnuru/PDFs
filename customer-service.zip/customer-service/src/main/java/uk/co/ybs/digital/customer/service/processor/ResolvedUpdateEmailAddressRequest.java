package uk.co.ybs.digital.customer.service.processor;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.customer.model.core.Party;

@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ResolvedUpdateEmailAddressRequest implements ResolvedCustomerRequest {

  @NonNull private final UpdateEmailAddressRequestArguments arguments;
  @NonNull private final UpdateEmailAddressProcessor processor;
  @NonNull private final Party party;

  @Override
  public void execute() {
    processor.execute(arguments, party);
  }

  @Override
  public void auditSuccess() {
    processor.auditSuccess(arguments);
  }

  @Override
  public void auditFailure(final String message) {
    processor.auditFailure(arguments, message);
  }
}
