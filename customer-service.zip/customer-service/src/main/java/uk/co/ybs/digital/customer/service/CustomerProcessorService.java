package uk.co.ybs.digital.customer.service;

import io.micrometer.core.annotation.Timed;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.repository.core.MetadataRepository;
import uk.co.ybs.digital.customer.repository.digitalcustomer.WorkLogRepository;
import uk.co.ybs.digital.customer.service.processor.CustomerRequest;
import uk.co.ybs.digital.customer.service.processor.CustomerRequestFactory;
import uk.co.ybs.digital.customer.service.processor.ResolvedCustomerRequest;
import uk.co.ybs.digital.customer.service.utilities.WorkLogMetrics;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@AllArgsConstructor
@Slf4j
@Timed(extraTags = {"type", "customerProcessor"})
@Service
@EnableScheduling
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public class CustomerProcessorService {

  private final WorkLogRepository workLogRepository;
  private final MetadataRepository metadataRepository;
  private final CustomerRequestFactory customerRequestFactory;
  private final WorkLogMetrics workLogMetrics;
  private final Clock clock;

  private static final String TECHNICAL_FAILURE_MESSAGE = "Technical Failure";

  @Scheduled(fixedDelayString = "${uk.co.ybs.digital.customer.processor.frequency}")
  public void process() {
    try {
      workLogMetrics.setValues(getWorkLogStatuses());
      final List<WorkLog> pendingWorkLogs =
          workLogRepository.findRequestsInState(WorkLog.Status.PENDING);
      log.info("Found {} pending customer requests to process", pendingWorkLogs.size());
      pendingWorkLogs.forEach(this::processWorkLog);
    } catch (final DataAccessResourceFailureException e) {
      log.warn("Error occurred connecting to the database", e);
    } catch (final Exception e) {
      log.error("Unexpected error occurred", e);
    }
  }

  private void processWorkLog(final WorkLog workLog) {
    final LocalDateTime processTime = LocalDateTime.now(clock);
    final long partyId = workLog.getPartyId();
    final WorkLog.Operation operation = workLog.getOperation();
    final RequestMetadata requestMetadata = workLog.getMessage().getMetadata();

    log.info(
        "Processing WorkLog - Party: {}, Operation: {}, RequestId: {}, WorkLog SysId: {}",
        partyId,
        operation,
        requestMetadata.getRequestId(),
        workLog.getSysId());

    // Liveness query.
    // Check that Core is available and accepting connections before processing
    metadataRepository.count();

    final CustomerRequest request = customerRequestFactory.build(workLog, processTime);
    final ResolvedCustomerRequest resolvedRequest;
    try {
      resolvedRequest = request.resolve();
    } catch (final CustomerNotFoundException e) {
      log.warn(
          "Customer not found failure when resolving request - Party: {}, Operation: {}, RequestId: {}, "
              + "WorkLog SysId: {}",
          partyId,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e);

      updateStatus(workLog, WorkLog.Status.FAILED);
      request.auditFailure(e.getMessage());
      return;
    } catch (final Exception e) {
      log.error(
          "Error resolving request - Party: {}, Operation: {}, RequestId: {}, WorkLog SysId: {}",
          partyId,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e);

      updateStatus(workLog, WorkLog.Status.FAILED);
      request.auditFailure(TECHNICAL_FAILURE_MESSAGE);
      return;
    }

    try {
      resolvedRequest.execute();
      updateStatus(workLog, WorkLog.Status.COMPLETE);
      try {
        resolvedRequest.auditSuccess();
      } catch (Exception e) {
        log.error(
            "Failed to create success audit message - Party: {}, Operation: {}, RequestId: {}, WorkLog SysId: {}",
            partyId,
            operation,
            requestMetadata.getRequestId(),
            workLog.getSysId(),
            e);
      }
    } catch (final CustomerServiceException e) {
      log.warn(
          "Service failure processing request - Party: {}, Operation: {}, RequestId: {}, "
              + "WorkLog SysId: {}",
          partyId,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e);

      updateStatus(workLog, WorkLog.Status.FAILED);
      resolvedRequest.auditFailure(e.getMessage());
    } catch (final Exception e) {
      log.error(
          "Error processing request - Party: {}, Operation: {}, RequestId: {}, WorkLog SysId: {}",
          partyId,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e);

      updateStatus(workLog, WorkLog.Status.FAILED);
      resolvedRequest.auditFailure(TECHNICAL_FAILURE_MESSAGE);
    }
  }

  private void updateStatus(final WorkLog request, final WorkLog.Status status) {
    workLogRepository.save(request.toBuilder().status(status).build());
  }

  private Map<WorkLog.Status, Long> getWorkLogStatuses() {
    return workLogRepository.findCountOfRequestsInState().stream()
        .collect(Collectors.toMap(s -> s.left, o -> o.right));
  }
}
