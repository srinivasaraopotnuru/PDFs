package uk.co.ybs.digital.customer.service.utilities;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.experimental.UtilityClass;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;

@UtilityClass
public class PhoneNumberUtilities {

  public static boolean isHomeOrWorkNumber(final PhoneNumberBasicType type, final String number) {
    switch (type) {
      case HOME:
        return true;
      case MOBILE:
        return false;
      default:
        // Work Phone
        return true;
    }
  }

  public static String formatPhoneNumber(final String phoneNumber) {
    String cleansedPhoneNumber = phoneNumber.replaceAll("\\s", "");

    final String regex = "^\\+44";
    final String subst = "0";

    final Pattern pattern = Pattern.compile(regex, Pattern.MULTILINE);

    final Matcher matcher = pattern.matcher(cleansedPhoneNumber);

    return matcher.replaceAll(subst);
  }
}
