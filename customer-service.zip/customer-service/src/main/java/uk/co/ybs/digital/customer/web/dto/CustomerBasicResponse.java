package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = CustomerBasicResponse.CustomerBasicResponseBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class CustomerBasicResponse {

  @JsonProperty(value = "party")
  @ApiModelProperty(required = true)
  private final CustomerBasic customer;

  @JsonPOJOBuilder(withPrefix = "")
  public static class CustomerBasicResponseBuilder {}
}
