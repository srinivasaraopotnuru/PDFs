package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Address.AddressBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Address {
  @ApiModelProperty(required = true, example = "CORR")
  private final String type;

  @JsonProperty(value = "addressLine")
  @ApiModelProperty(required = true)
  private final List<String> addressLines;

  @ApiModelProperty(required = true, example = "CV5 7EE")
  private final String postCode;

  @ApiModelProperty(required = true, example = "GB")
  private final String country;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AddressBuilder {}
}
