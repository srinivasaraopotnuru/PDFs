package uk.co.ybs.digital.customer.config;

import java.time.Clock;
import javax.persistence.EntityManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.service.CustomerServiceProperties;

@Configuration
@Slf4j
@EnableConfigurationProperties(CustomerServiceProperties.class)
public class CustomerServiceConfig {

  @Bean
  public Clock clock() {
    // The application should be run in UK timezone for consistency with other
    // YBS timezone handling.
    final Clock systemClock = Clock.systemDefaultZone();
    log.info("System clock is: {}", systemClock);
    return systemClock;
  }

  @Bean
  public Country defaultCountry(
      @Qualifier("adgCoreEntityManagerFactory") final EntityManager entityManager) {
    Country country = entityManager.find(Country.class, "UK");

    if (country == null) {
      throw new IllegalStateException("Unable to find default Country Record with id \"UK\"");
    }

    log.info("Default Country for PostalAddresses is {}", country);

    return country;
  }
}
