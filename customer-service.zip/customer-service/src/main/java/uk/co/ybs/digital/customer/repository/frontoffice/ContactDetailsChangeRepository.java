package uk.co.ybs.digital.customer.repository.frontoffice;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;

public interface ContactDetailsChangeRepository
    extends JpaRepository<ContactDetailsChange, ContactDetailsChange.ContactDetailsChangePk> {

  @Query(
      "SELECT distinct(cdc.partySysId) "
          + "FROM ContactDetailsChange cdc "
          + "WHERE cdc.partySysId IN :parties "
          + "AND cdc.amendDate >= :earliest ")
  Set<String> findAllChangesForPartiesAfterEarliestTime(
      @Param("parties") Collection<String> parties, @Param("earliest") LocalDateTime earliest);

  @Query(
      value =
          "SELECT cdc.* "
              + "FROM CONTACT_DETAILS_CHANGE cdc "
              + "WHERE cdc.PARTY_SYSID IN :parties "
              + "AND cdc.AMEND_DATE >= :earliest "
              + "ORDER BY cdc.AMEND_DATE DESC "
              + "FETCH NEXT ROW ONLY",
      nativeQuery = true)
  Optional<ContactDetailsChange> findLatestChangeForPartiesAfterEarliestTime(
      @Param("parties") Collection<String> parties, @Param("earliest") LocalDateTime earliest);
}
