package uk.co.ybs.digital.customer.service.processor;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.customer.model.core.Party;

@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ResolvedUpdatePhoneNumberRequest implements ResolvedCustomerRequest {
  @NonNull private final UpdatePhoneNumberRequestArguments arguments;
  @NonNull private final UpdatePhoneNumberProcessor processor;
  @NonNull private final Party party;

  @Override
  public void execute() {
    processor.execute(arguments, party);
  }

  @Override
  public void auditSuccess() {
    processor.auditSuccess(arguments);
  }

  @Override
  public void auditFailure(final String message) {
    processor.auditFailure(arguments, message);
  }
}
