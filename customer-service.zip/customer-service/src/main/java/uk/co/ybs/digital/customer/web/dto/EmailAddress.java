package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.customer.web.NonEmptyString;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class EmailAddress {
  @NotNull(message = "You must specify an email type")
  @NonEmptyString(message = "Email Type must contain at least one non-whitespace character")
  @ApiModelProperty(required = true, example = "PERSONAL")
  String type;

  @NotNull(message = "You must specify an email address")
  @NonEmptyString(message = "Email must contain at least one non-whitespace character")
  @Email(
      regexp =
          "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$",
      message = "You must supply a valid email address")
  @Size(max = 70, message = "Email address must be no longer than 70 characters")
  @ApiModelProperty(required = true, example = "john.smith@gmail.com")
  String email;
}
