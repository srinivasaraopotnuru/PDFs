package uk.co.ybs.digital.customer.web.dto.products;

public enum WarningCode {
  NON_UK_ADDRESS,
  MAX_NO_OF_ACCOUNTS,
  APPLICANT_AGE
}
