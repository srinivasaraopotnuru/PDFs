package uk.co.ybs.digital.customer.service.processor;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.EnumSet;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.repository.core.PartyCoreRepository;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;

@Component
@RequiredArgsConstructor
@Slf4j
@Transactional("customerProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public class DeletePhoneNumberProcessor {

  private final AuditService auditService;
  private final PartyCoreRepository partyCoreRepository;

  public Party resolve(final DeletePhoneNumberRequestArguments arguments) {

    final long partyId = arguments.getPartyId();
    final LinkedParty linkedParty = getCanonicalPartyId(partyId);

    return partyCoreRepository
        .findPartyInformationWithAddressTypesAndFunctions(
            linkedParty.getCanonicalPartyId(),
            Collections.singleton(AddressType.TEL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            arguments.getProcessTime())
        .orElseThrow(
            () ->
                new CustomerNotFoundException(
                    String.format("No record found in party database for party id %d", partyId)));
  }

  public void execute(final DeletePhoneNumberRequestArguments arguments, final Party party) {
    final LocalDateTime processTime = arguments.getProcessTime();
    log.info("Processing party: {}", arguments.getPartyId());
    endCurrentPhoneNumber(
        party, processTime, NPASourceType.valueOf(arguments.getRequestType().toString()));
    log.info("Processing party: {} - completed", arguments.getPartyId());
  }

  private void endCurrentPhoneNumber(
      final Party party, final LocalDateTime processTime, final NPASourceType sourceType) {
    party.getAddresses().stream()
        .filter(
            address ->
                address.getNonPostalAddress() != null
                    && address.getNonPostalAddress().getType().equals(AddressType.TEL)
                    && address.getNonPostalAddress().getSourceType().equals(sourceType))
        .forEach(
            address -> {
              address.setEndDate(processTime);
              address.setEndedDate(processTime);
              address.setEndedAt(CustomerProcessorConstants.AUDIT_AT);
              address.setEndedBy(CustomerProcessorConstants.AUDIT_BY);
              log.info(
                  "Ending address usage: {} for party: {}", address.getSysId(), party.getSysId());
              address.getFunctions().forEach(func -> func.setEndDate(processTime));
            });

    partyCoreRepository.saveAndFlush(party);
  }

  public void auditSuccess(final DeletePhoneNumberRequestArguments arguments) {

    final AuditNonPostalAddressUpdateSuccessRequest auditRequest =
        AuditNonPostalAddressUpdateSuccessRequest.builder()
            .ipAddress(arguments.getRequestMetadata().getIpAddress())
            .address(null)
            .operation(NonPostalOperation.PHONE_NUMBER)
            .type(NonPostalType.valueOf(String.valueOf(arguments.getRequestType())))
            .build();

    auditService.auditNonPostalAddressUpdateSuccess(auditRequest, arguments.getRequestMetadata());
  }

  public void auditFailure(
      final DeletePhoneNumberRequestArguments arguments, final String message) {

    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        AuditNonPostalAddressUpdateFailureRequest.builder()
            .ipAddress(arguments.getRequestMetadata().getIpAddress())
            .message(message)
            .address(null)
            .operation(NonPostalOperation.PHONE_NUMBER)
            .type(NonPostalType.valueOf(String.valueOf(arguments.getRequestType())))
            .build();

    auditService.auditNonPostalAddressUpdateFailure(auditRequest, arguments.getRequestMetadata());
  }

  private LinkedParty getCanonicalPartyId(final long partyId) {

    return partyCoreRepository
        .findCanonicalPartyId(partyId)
        .orElseThrow(
            () ->
                (new CustomerNotFoundException(
                    String.format("No record found in party database for party id %d", partyId))));
  }
}
