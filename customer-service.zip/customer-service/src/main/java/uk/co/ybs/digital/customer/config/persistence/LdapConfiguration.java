package uk.co.ybs.digital.customer.config.persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.ldap.repository.config.EnableLdapRepositories;
import org.springframework.ldap.core.ContextSource;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.ldap.transaction.compensating.manager.ContextSourceTransactionManager;
import org.springframework.ldap.transaction.compensating.manager.TransactionAwareContextSourceProxy;
import org.springframework.ldap.transaction.compensating.support.DefaultTempEntryRenamingStrategy;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableLdapRepositories("uk.co.ybs.digital.customer.repository")
public class LdapConfiguration {

  @Bean
  public ContextSource contextSource(final LdapContextSource contextSourceTarget) {

    return new TransactionAwareContextSourceProxy(contextSourceTarget);
  }

  @Bean
  public LdapTemplate ldapTemplate(final ContextSource contextSource) {
    return new LdapTemplate(contextSource);
  }

  @Bean
  public PlatformTransactionManager ldapTransactionManager(final ContextSource contextSource) {

    ContextSourceTransactionManager contextSourceTransactionManager =
        new ContextSourceTransactionManager();
    contextSourceTransactionManager.setContextSource(contextSource);
    contextSourceTransactionManager.setRenamingStrategy(new DefaultTempEntryRenamingStrategy());

    return contextSourceTransactionManager;
  }
}
