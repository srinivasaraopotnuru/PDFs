package uk.co.ybs.digital.customer.model.core;

import java.time.LocalDateTime;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.Singular;
import lombok.ToString;
import uk.co.ybs.digital.customer.model.YesOrNullConverter;

@Entity
@Table(name = "ADDRESS_USAGES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class AddressUsage {

  @Id
  @Column(name = "SYSID")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ADDUSE_SYSID_SEQ")
  @SequenceGenerator(
      sequenceName = "ADDUSE_SYSID_SEQ",
      allocationSize = 1,
      name = "ADDUSE_SYSID_SEQ")
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "START_DATE")
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "POD_CODE")
  private String podCode;

  @ManyToOne
  @JoinColumn(name = "PARTY_SYSID")
  @ToString.Exclude
  private Party party;

  @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @JoinColumn(name = "NPADDR_SYSID")
  private NonPostalAddress nonPostalAddress;

  @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @JoinColumn(name = "PSTADD_SYSID")
  private PostalAddress postalAddress;

  @Column(name = "ADDFUN_CODE")
  @Enumerated(EnumType.STRING)
  private AddressFunction function;

  @Column(name = "PREF_CONTACT_METH")
  @Convert(converter = YesOrNullConverter.class)
  private boolean preferredContactMethod;

  @Column(name = "CREATED_AT", nullable = false)
  private String createdAt;

  @Column(name = "CREATED_BY", nullable = false)
  private String createdBy;

  @Column(name = "CREATED_DATE", nullable = false)
  private LocalDateTime createdDate;

  @Column(name = "ENDED_AT")
  private String endedAt;

  @Column(name = "ENDED_BY")
  private String endedBy;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Singular
  @OneToMany(
      targetEntity = AddressUsageFunction.class,
      mappedBy = "addressUsage",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE},
      orphanRemoval = true)
  @ToString.Exclude
  private Set<AddressUsageFunction> functions;

  public enum AddressFunction {
    DIRCOM,
    CORR,
    FORRES
  }
}
