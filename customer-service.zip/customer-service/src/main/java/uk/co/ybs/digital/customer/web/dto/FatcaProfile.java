package uk.co.ybs.digital.customer.web.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class FatcaProfile {

  String countryRelationCode;

  String countryCode;

  String nonUKTaxReferenceCode;
}
