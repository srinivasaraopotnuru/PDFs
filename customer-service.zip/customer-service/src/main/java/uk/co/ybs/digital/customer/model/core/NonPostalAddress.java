package uk.co.ybs.digital.customer.model.core;

import java.util.Optional;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Singular;
import lombok.ToString;

@Entity
@Table(name = "NON_POSTAL_ADDRESSES")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class NonPostalAddress {

  @Id
  @Column(name = "SYSID")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "NPADDR_SYSID_SEQ")
  @SequenceGenerator(
      sequenceName = "NPADDR_SYSID_SEQ",
      allocationSize = 1,
      name = "NPADDR_SYSID_SEQ")
  @EqualsAndHashCode.Include
  private Long sysId;

  @NonNull
  @Column(name = "ADDR")
  private String address;

  @Column(name = "ADC_CODE")
  private Integer adcCode;

  // This isn't the exact data model.
  // This table actually links to countries via the area dialling code join table
  // As the country code and adc code are optional (which makes sense as, for example,
  // these don't apply to emails) the YBS data base has a lot of data quality issues
  // where either the adc_code or ADC_CNTRY_CODE are not specified for a phone number.
  // This means that the join table doesn't return any results as it has a composite primary key
  // ADC_CNTRY_CODE has a transitive relationship to countries via the link table
  // (area_dialling_codes)
  // thus ensuring that any value entered in this column has to be a valid country code.
  @ManyToOne
  @JoinColumn(name = "ADC_CNTRY_CODE")
  private Country country;

  @Column(name = "ADTYP_CODE")
  @Enumerated(EnumType.STRING)
  private AddressType type;

  @Enumerated(EnumType.STRING)
  @Column(name = "NPASRC_CODE")
  private NPASourceType sourceType;

  @Singular
  @OneToMany(
      mappedBy = "nonPostalAddress",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @ToString.Exclude
  private Set<AddressUsage> usages;

  public NPASourceType getSourceTypeOrDefault() {
    return Optional.ofNullable(sourceType).orElse(NPASourceType.DEFAULT);
  }
}
