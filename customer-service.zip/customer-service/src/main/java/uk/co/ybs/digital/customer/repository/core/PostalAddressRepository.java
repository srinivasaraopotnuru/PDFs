package uk.co.ybs.digital.customer.repository.core;

import java.util.Optional;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.PostalAddress;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
@SuppressWarnings("PMD.ExcessiveParameterList")
public interface PostalAddressRepository extends JpaRepository<PostalAddress, Long> {

  @Query(
      value =
          "SELECT pa "
              + "FROM PostalAddress pa "
              + " WHERE :pafAddressKey = pa.pafAddressKey "
              + "   AND :pafDps = pa.pafDps "
              + "   AND :pafKeyPart3 = pa.pafKeyPart3")
  Optional<PostalAddress> findPostalAddressByPafData(
      Integer pafAddressKey, String pafDps, String pafKeyPart3);

  @Query(
      value =
          "SELECT pa "
              + "FROM PostalAddress pa "
              + " WHERE pa.line1 = :line1"
              + "   AND (pa.line2 = :line2 or (pa.line2 is null and :line2 is null))"
              + "   AND (pa.line3 = :line3 or (pa.line3 is null and :line3 is null))"
              + "   AND (pa.line4 = :line4 or (pa.line4 is null and :line4 is null))"
              + "   AND (pa.line5 = :line5 or (pa.line5 is null and :line5 is null))"
              + "   AND (pa.country = :country or (pa.country is null and :country is null))"
              + "   AND :type = pa.type"
              + "   AND postCode.unitCode = :unitCode"
              + "   AND postCode.sectorCode = :sectorCode"
              + "   AND postCode.districtCode = :districtCode"
              + "   AND postCode.areaCode = :areaCode"
              + "   AND rownum = 1")
  Optional<PostalAddress> findPostalAddressByAddressData(
      String line1,
      String line2,
      String line3,
      String line4,
      String line5,
      Country country,
      AddressType type,
      String areaCode,
      String districtCode,
      String sectorCode,
      String unitCode);
}
