package uk.co.ybs.digital.customer.model.digitalcustomer;

public enum PhoneNumberRequestType {
  HOME,
  MOBILE,
  WORK
}
