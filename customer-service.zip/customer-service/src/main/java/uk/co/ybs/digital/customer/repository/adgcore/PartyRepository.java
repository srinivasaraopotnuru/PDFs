package uk.co.ybs.digital.customer.repository.adgcore;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.CustomerPartySysID;
import uk.co.ybs.digital.customer.model.adgcore.CustomerWebLogOnDetails;
import uk.co.ybs.digital.customer.model.adgcore.DeDupeEligibleParty;
import uk.co.ybs.digital.customer.model.adgcore.LinkedParty;
import uk.co.ybs.digital.customer.model.adgcore.LinkedPartyDetails;
import uk.co.ybs.digital.customer.model.adgcore.Party;

public interface PartyRepository extends JpaRepository<Party, Long> {

  default Optional<Party> findBasicPartyInformation(final Long partyId, final LocalDateTime now) {
    return findPartyInformationWithAddressTypesAndFunctions(
        partyId,
        EnumSet.of(AddressType.EMAIL, AddressType.TEL),
        EnumSet.allOf(AddressUsage.AddressFunction.class),
        now);
  }

  // This method should be used for any queries with a date of yesterday or before
  default Optional<Party> findBasicPartyInformationHistoric(
      final Long partyId, final LocalDateTime dateTime) {
    return findPartyInformationWithAddressTypesAndFunctionsHistoric(
        partyId,
        EnumSet.of(AddressType.EMAIL, AddressType.TEL),
        EnumSet.allOf(AddressUsage.AddressFunction.class),
        dateTime);
  }

  default Optional<Party> findGoldenPartyInformation(final Long partyId, final LocalDateTime now) {
    return findPartyInformationWithAddressTypesAndFunctions(
        partyId,
        EnumSet.allOf(AddressType.class),
        EnumSet.allOf(AddressUsage.AddressFunction.class),
        now);
  }

  @Query(
      "SELECT party FROM Party party "
          + "JOIN party.person person ON person.endedDate IS NULL "
          + "LEFT JOIN party.addresses addressUsage"
          + "   ON (addressUsage.endDate IS NULL OR addressUsage.endDate > :now) "
          + "   AND addressUsage.startDate <= :now "
          + "   AND (addressUsage.nonPostalAddress.type IN :addressTypes "
          + "        OR addressUsage.postalAddress.type IN :addressTypes) "
          + "   AND (addressUsage.function IN :addressFunctions) "
          + "WHERE party.partyType.type = 'PERSON' "
          + "  AND party.sysId = :partyId "
          + "  AND party.endedDate IS NULL "
          + "ORDER BY addressUsage.preferredContactMethod DESC,"
          + "         addressUsage.startDate DESC,"
          + "         addressUsage.sysId DESC")
  @EntityGraph(
      attributePaths = {
        "person",
        "addresses",
        "addresses.nonPostalAddress",
        "addresses.nonPostalAddress.country",
        "addresses.postalAddress",
        "addresses.postalAddress.country",
        "person.party.partyType"
      },
      type = EntityGraph.EntityGraphType.LOAD)
  Optional<Party> findPartyInformationWithAddressTypesAndFunctions(
      Long partyId,
      Set<AddressType> addressTypes,
      Set<AddressUsage.AddressFunction> addressFunctions,
      LocalDateTime now);

  // This query takes into account that when core sets the start date and end date it does not
  // explicitly set the time and the time defaults to 00:00:00
  @Query(
      "SELECT party FROM Party party "
          + "JOIN party.person person ON person.endedDate IS NULL "
          + "LEFT JOIN party.addresses addressUsage"
          + "   ON (addressUsage.endDate IS NULL OR "
          + "         (addressUsage.endDate > :now or "
          + "            (trunc(addressUsage.endDate) = addressUsage.endDate and addressUsage.endDate = trunc(:now))) "
          + "      ) "
          + "   AND addressUsage.createdDate <= :now "
          + "   AND addressUsage.startDate <= :now "
          + "   AND (addressUsage.nonPostalAddress.type IN :addressTypes "
          + "        OR addressUsage.postalAddress.type IN :addressTypes) "
          + "   AND (addressUsage.function IN :addressFunctions) "
          + "   AND (addressUsage.function IN :addressFunctions) "
          + "WHERE party.partyType.type = 'PERSON' "
          + "  AND party.sysId = :partyId "
          + "  AND party.endedDate IS NULL "
          + "ORDER BY addressUsage.preferredContactMethod DESC,"
          + "         addressUsage.startDate DESC,"
          + "         addressUsage.sysId DESC")
  @EntityGraph(
      attributePaths = {
        "person",
        "addresses",
        "addresses.nonPostalAddress",
        "addresses.nonPostalAddress.country",
        "addresses.postalAddress",
        "addresses.postalAddress.country",
        "person.party.partyType"
      },
      type = EntityGraph.EntityGraphType.LOAD)
  Optional<Party> findPartyInformationWithAddressTypesAndFunctionsHistoric(
      Long partyId,
      Set<AddressType> addressTypes,
      Set<AddressUsage.AddressFunction> addressFunctions,
      LocalDateTime now);

  @Query(name = LinkedParty.FIND_CANONICAL_PARTY_ID_QUERY)
  Optional<LinkedParty> findCanonicalPartyId(Long partyId);

  @Query(name = CustomerPartySysID.CUSTOMER_PARTY_SYSID_QUERY)
  Optional<List<CustomerPartySysID>> findPartySysIds(
      String forename,
      String dateOfBirth,
      String postCode,
      String mobileNumber,
      LocalDateTime date);

  @Query(name = LinkedPartyDetails.LINKED_PARTY_DETAILS_QUERY)
  Optional<List<LinkedPartyDetails>> findLinkedParties(Long partyId);

  @Query(name = CustomerWebLogOnDetails.CUSTOMER_WEB_LOGON_DETAILS_QUERY)
  Optional<CustomerWebLogOnDetails> findWebLogonDetails(Long partyId);

  @Query(name = DeDupeEligibleParty.DEDUPE_ELIGIBLE_QUERY)
  DeDupeEligibleParty findDeDupeEligiblePartyId(Long partyId);
}
