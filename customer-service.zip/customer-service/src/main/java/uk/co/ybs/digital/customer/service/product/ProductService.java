package uk.co.ybs.digital.customer.service.product;

import io.micrometer.core.annotation.Timed;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.ResolvableType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@Slf4j
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class ProductService {

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String EMPTY_RESPONSE_ERROR_MESSAGE =
      "Empty response calling product service";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling product service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Error calling product service: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";
  public static final String BEARER_TOKEN = "Bearer ";

  private final WebClient productServiceWebClient;

  @Cacheable(value = "on-sale-products", key = "#root.methodName")
  public List<ProductCategory> getOnSaleProducts(final RequestMetadata metadata) {

    log.info("Populating on-sale-products cache");

    return getList(metadata, ProductCategory.class, "/private/on-sale-products");
  }

  @Scheduled(
      fixedRateString = "${uk.co.ybs.digital.customer.cache.on.sale.products.clear.frequency}")
  @CacheEvict(value = "on-sale-products", allEntries = true)
  public void clearCache() {
    log.info("Clearing on-sale-products cache");
  }

  private <T> List<T> getList(
      final RequestMetadata metadata,
      @SuppressWarnings("SameParameterValue") final Class<T> responseType,
      @SuppressWarnings("SameParameterValue") final String uri) {

    final ResolvableType resolvableType =
        ResolvableType.forClassWithGenerics(List.class, responseType);
    final ParameterizedTypeReference<List<T>> responseTypeRef =
        ParameterizedTypeReference.forType(resolvableType.getType());

    return productServiceWebClient
        .get()
        .uri(uri)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, BEARER_TOKEN + metadata.getForwardingAuth())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .bodyToMono(responseTypeRef)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new ProductServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new ProductServiceException(EMPTY_RESPONSE_ERROR_MESSAGE));
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof ProductServiceException);
  }

  private Mono<ProductServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new ProductServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new ProductServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new ProductServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
