package uk.co.ybs.digital.customer.service.mapping;

import java.util.List;
import org.mapstruct.Mapper;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.web.dto.Preferences;
import uk.co.ybs.digital.customer.web.dto.Preferences.Marketing;
import uk.co.ybs.digital.customer.web.dto.Preferences.Marketing.Eagm;
import uk.co.ybs.digital.customer.web.dto.Preferences.Marketing.Email;
import uk.co.ybs.digital.customer.web.dto.Preferences.Marketing.Phone;
import uk.co.ybs.digital.customer.web.dto.Preferences.Marketing.Post;

@Mapper(componentModel = "spring")
@SuppressWarnings("PMD.SwitchStmtsShouldHaveDefault")
public class PreferencesMapper {

  private static final String EAGM_EMAIL_DEEMED_BOUNCED = "DEEMEDBOUNCE";

  public Preferences preferences(final List<MarketingOptIn> marketingOptIns) {

    boolean post = false;
    boolean phone = false;
    boolean email = false;
    boolean eagm = false;
    boolean eagmDeemedConsent = false;

    for (MarketingOptIn marketingOptIn : marketingOptIns) {
      switch (marketingOptIn.getCode()) {
        case ADDR:
          post = defaultToFalse(marketingOptIn.getStatus());
          break;
        case TEL:
          phone = defaultToFalse(marketingOptIn.getStatus());
          break;
        case EMAIL:
          email = defaultToFalse(marketingOptIn.getStatus());
          break;
        case AGMEML:
          eagm = defaultToFalse(marketingOptIn.getStatus());

          if (eagm) {
            eagmDeemedConsent = true;
          } else {
            if (EAGM_EMAIL_DEEMED_BOUNCED.equals(marketingOptIn.getCreatedBy())) {
              eagmDeemedConsent = true;
            }
          }
          break;
      }
    }

    return Preferences.builder()
        .marketing(
            Marketing.builder()
                .post(Post.builder().status(post).build())
                .phone(Phone.builder().status(phone).build())
                .email(Email.builder().status(email).build())
                .eagm(Eagm.builder().status(eagm).deemedConsent(eagmDeemedConsent).build())
                .build())
        .build();
  }

  private boolean defaultToFalse(final Boolean value) {
    return value == null ? false : value;
  }
}
