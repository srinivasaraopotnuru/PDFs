package uk.co.ybs.digital.customer.model.core;

public enum NPASourceType {
  HOME,
  MOBILE,
  WORK,
  DEFAULT
}
