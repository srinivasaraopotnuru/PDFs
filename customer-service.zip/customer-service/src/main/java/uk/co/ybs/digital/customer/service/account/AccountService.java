package uk.co.ybs.digital.customer.service.account;

import io.micrometer.core.annotation.Timed;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.ResolvableType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountGroup;
import uk.co.ybs.digital.customer.service.account.dto.Warning;
import uk.co.ybs.digital.customer.service.account.dto.WarningCode;
import uk.co.ybs.digital.customer.service.audit.AuditServiceException;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class AccountService {

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String EMPTY_RESPONSE_ERROR_MESSAGE =
      "Empty response calling account service";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling account service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Error calling account service: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";
  public static final String BEARER_TOKEN = "Bearer ";

  private final WebClient accountServiceWebClient;

  public AccountGroupedInfo getGroupedAccountInfo(
      final RequestMetadata metadata, final boolean includeClosedAccounts) {
    AccountGroupedInfo results =
        get(
            metadata,
            AccountGroupedInfo.class,
            "/private/accounts/grouped?showClosedAccounts=" + includeClosedAccounts);

    if (results.getOwned() == null) {
      return results.toBuilder().owned(AccountGroup.builder().build()).build();
    }

    return results;
  }

  public List<Warning> getAccountWarnings(
      final String accountNumber, final RequestMetadata metadata) {

    return getList(
        metadata, Warning.class, String.format("/private/accounts/%s/warnings", accountNumber));
  }

  public void postAccountWarning(
      final String accountNumber,
      final WarningCode requestPayload,
      final RequestMetadata metadata) {
    post(String.format("/private/accounts/%s/warnings", accountNumber), requestPayload, metadata);
  }

  private <T> T get(final RequestMetadata metadata, final Class<T> responseType, final String uri) {
    return accountServiceWebClient
        .get()
        .uri(uri)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, BEARER_TOKEN + metadata.getForwardingAuth())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .bodyToMono(responseType)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AccountServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new AccountServiceException(EMPTY_RESPONSE_ERROR_MESSAGE));
  }

  private <T> List<T> getList(
      final RequestMetadata metadata, final Class<T> responseType, final String uri) {

    final ResolvableType resolvableType =
        ResolvableType.forClassWithGenerics(List.class, responseType);
    final ParameterizedTypeReference<List<T>> responseTypeRef =
        ParameterizedTypeReference.forType(resolvableType.getType());

    return accountServiceWebClient
        .get()
        .uri(uri)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, BEARER_TOKEN + metadata.getForwardingAuth())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .bodyToMono(responseTypeRef)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AccountServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new AccountServiceException(EMPTY_RESPONSE_ERROR_MESSAGE));
  }

  private void post(
      final String uri, final Object requestPayload, final RequestMetadata requestMetadata) {
    accountServiceWebClient
        .post()
        .uri(uri)
        .header(HttpHeaders.AUTHORIZATION, BEARER_TOKEN + requestMetadata.getForwardingAuth())
        .header(REQUEST_ID_HEADER, requestMetadata.getRequestId().toString())
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(requestPayload)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .toBodilessEntity()
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AuditServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .block();
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AccountServiceException);
  }

  private Mono<AccountServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new AccountServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new AccountServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new AccountServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
