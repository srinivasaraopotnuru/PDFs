package uk.co.ybs.digital.customer.exception;

public class AmendmentRestrictionException extends RuntimeException {

  private static final long serialVersionUID = 3598662684547318816L;

  public AmendmentRestrictionException(final String message) {
    super(message);
  }

  public AmendmentRestrictionException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
