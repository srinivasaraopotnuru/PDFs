package uk.co.ybs.digital.customer.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(
    builder = AuditAuthenticationSuccessRequest.AuditAuthenticationSuccessRequestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditAuthenticationSuccessRequest {
  @NotNull(message = "You must specify an ip address")
  String ipAddress;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditAuthenticationSuccessRequestBuilder {}
}
