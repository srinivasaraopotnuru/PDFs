package uk.co.ybs.digital.customer.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import uk.co.ybs.digital.customer.model.YesNoOrNullConverter;

@Entity
@Table(name = "MARKETING_OPT_INS")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class MarketingOptIn {

  @Id
  @Column(name = "SYSID")
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "PARTY_SYSID")
  private Long partyId;

  @Column(name = "CODE")
  @Enumerated(EnumType.STRING)
  private MarketingOptInCode code;

  @Column(name = "STATUS")
  @Convert(converter = YesNoOrNullConverter.class)
  private Boolean status;

  @Column(name = "START_DATE")
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "CREATED_BY")
  private String createdBy;

  public enum MarketingOptInCode {
    THRDPY,
    EMAIL,
    TEL,
    FAX,
    ADDR,
    AGMEML,
    ANSTMT
  }
}
