package uk.co.ybs.digital.customer.service.processor;

import com.google.common.base.Strings;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.ldap.NamingException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.ldap.LdapPerson;
import uk.co.ybs.digital.customer.repository.core.PartyCoreRepository;
import uk.co.ybs.digital.customer.repository.ldap.LdapPersonRepository;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;

@Component
@RequiredArgsConstructor
@Slf4j
@Transactional("customerProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public class UpdateEmailAddressProcessor {

  private final AuditService auditService;
  private final PartyCoreRepository partyCoreRepository;
  private final LdapPersonRepository ldapPersonRepository;

  public Party resolve(final UpdateEmailAddressRequestArguments arguments) {

    final long partyId = arguments.getPartyId();

    final LinkedParty linkedParty = getCanonicalPartyId(partyId);

    return partyCoreRepository
        .findPartyInformationWithAddressTypesAndFunctions(
            linkedParty.getCanonicalPartyId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            arguments.getProcessTime())
        .orElseThrow(
            () ->
                new CustomerNotFoundException(
                    String.format("No record found in party database for party id %d", partyId)));
  }

  public void execute(final UpdateEmailAddressRequestArguments arguments, final Party party) {

    final LocalDateTime processTime = arguments.getProcessTime();
    final Long partyId = arguments.getPartyId();
    final String emailAddress = arguments.getEmailAddress();

    log.info("Processing party: {}", arguments.getPartyId());

    updateLdapEmailAddress(partyId, emailAddress);

    updateEmailAddress(party, emailAddress, processTime);

    log.info("Processing party: {} - completed", arguments.getPartyId());
  }

  public void auditSuccess(final UpdateEmailAddressRequestArguments arguments) {

    final AuditNonPostalAddressUpdateSuccessRequest auditRequest =
        AuditNonPostalAddressUpdateSuccessRequest.builder()
            .ipAddress(arguments.getRequestMetadata().getIpAddress())
            .address(arguments.getEmailAddress())
            .operation(NonPostalOperation.EMAIL_ADDRESS)
            .type(NonPostalType.EMAIL)
            .build();
    auditService.auditNonPostalAddressUpdateSuccess(auditRequest, arguments.getRequestMetadata());
  }

  public void auditFailure(
      final UpdateEmailAddressRequestArguments arguments, final String message) {

    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        AuditNonPostalAddressUpdateFailureRequest.builder()
            .ipAddress(arguments.getRequestMetadata().getIpAddress())
            .message(message)
            .address(arguments.getEmailAddress())
            .operation(NonPostalOperation.EMAIL_ADDRESS)
            .type(NonPostalType.EMAIL)
            .build();
    auditService.auditNonPostalAddressUpdateFailure(auditRequest, arguments.getRequestMetadata());
  }

  private void updateLdapEmailAddress(final Long partyId, final String emailAddress) {
    final String uid = Strings.padStart(String.valueOf(partyId), 10, '0');

    final LdapPerson ldapPerson =
        getLdapPerson(uid)
            .orElseThrow(
                () -> new CustomerServiceException(String.format("LdapPerson %s not found", uid)));

    log.info("Updating email address on LDAP for party: {}", partyId);

    final LdapPerson ldapPersonUpdated = ldapPerson.toBuilder().emailAddress(emailAddress).build();

    ldapPersonRepository.save(ldapPersonUpdated);
  }

  private Optional<LdapPerson> getLdapPerson(final String uid) {
    try {
      return ldapPersonRepository.findByUid(uid);
    } catch (NamingException ex) {
      throw new CustomerServiceException(
          String.format("Error calling LDAP for LdapPerson %s", uid), ex);
    }
  }

  private void updateEmailAddress(
      final Party party, final String emailAddress, final LocalDateTime processTime) {

    endCurrentEmailAddress(party, processTime);

    // Get the current setting for preferred contact method from the current email address if
    // available
    final boolean preferredContactMethod =
        party.getAddresses().stream()
            .filter(
                address ->
                    address.getNonPostalAddress() != null
                        && address.getNonPostalAddress().getType() == AddressType.EMAIL)
            .findFirst()
            .map(AddressUsage::isPreferredContactMethod)
            .orElse(false);

    // Add new email address plus associated entries
    final AddressUsage addressUsage =
        AddressUsage.builder()
            .function(AddressUsage.AddressFunction.DIRCOM)
            .startDate(processTime)
            .createdDate(processTime)
            .createdAt(CustomerProcessorConstants.AUDIT_AT)
            .createdBy(CustomerProcessorConstants.AUDIT_BY)
            .preferredContactMethod(preferredContactMethod)
            .party(party)
            .build();

    party.getAddresses().add(addressUsage);

    NonPostalAddress nonPostalAddress =
        NonPostalAddress.builder()
            .type(AddressType.EMAIL)
            .address(emailAddress)
            .usage(addressUsage)
            .build();

    nonPostalAddress.setUsages(Collections.singleton(addressUsage));

    addressUsage.setNonPostalAddress(nonPostalAddress);

    AddressUsageFunction addressUsageFunction =
        AddressUsageFunction.builder()
            .id(
                AddressUsageFunction.AddressUsageFunctionPK.builder()
                    .function(AddressUsage.AddressFunction.DIRCOM)
                    .startDate(processTime)
                    .build())
            .addressUsage(addressUsage)
            .build();

    addressUsage.setFunctions(Collections.singleton(addressUsageFunction));

    log.info("Creating new entries for updated email address for party: {}", party.getSysId());

    partyCoreRepository.saveAndFlush(party);
  }

  private void endCurrentEmailAddress(final Party party, final LocalDateTime processTime) {
    party.getAddresses().stream()
        .filter(
            address ->
                address.getNonPostalAddress() != null
                    && address.getNonPostalAddress().getType() == AddressType.EMAIL)
        .forEach(
            address -> {
              address.setEndDate(processTime);
              address.setEndedDate(processTime);
              address.setEndedAt(CustomerProcessorConstants.AUDIT_AT);
              address.setEndedBy(CustomerProcessorConstants.AUDIT_BY);
              log.info(
                  "Ending address usage: {} for party: {}", address.getSysId(), party.getSysId());
              address.getFunctions().forEach(func -> func.setEndDate(processTime));
            });
  }

  private LinkedParty getCanonicalPartyId(final long partyId) {

    return partyCoreRepository
        .findCanonicalPartyId(partyId)
        .orElseThrow(
            () ->
                (new CustomerNotFoundException(
                    String.format("No record found in party database for party id %d", partyId))));
  }
}
