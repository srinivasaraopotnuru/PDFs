package uk.co.ybs.digital.customer.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddress;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdateEmailRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.repository.adgcore.CountryRepository;
import uk.co.ybs.digital.customer.repository.digitalcustomer.WorkLogRepository;
import uk.co.ybs.digital.customer.web.dto.EmailAddressResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PostalAddressResponse;

@Slf4j
@Service
public class PendingDetailsService {

  @Autowired private WorkLogRepository workLogRepository;
  @Autowired private CountryRepository countryRepository;

  public EmailAddressResponse buildEmailAddressResponse(
      final Party party, final NonPostalAddress address) {
    Optional<WorkLog> pendingWorkLog = findPendingWorkLog(party, Operation.EMAIL_ADDRESS);
    if (!pendingWorkLog.isPresent()) {

      return EmailAddressResponse.builder()
          .email(address.getAddress())
          .pendingUpdate(false)
          .type(String.valueOf(address.getSourceTypeOrDefault()))
          .build();
    }

    UpdateEmailRequest payload =
        (UpdateEmailRequest) pendingWorkLog.get().getMessage().getWorkLogPayload();

    String pendingEmail = payload.getEmail();
    String pendingType = payload.getRequestType();
    log.info(
        "Updating email address response to use pending address: {}, type: {}",
        pendingEmail,
        pendingType);
    return EmailAddressResponse.builder()
        .email(pendingEmail)
        .pendingUpdate(true)
        .type(pendingType)
        .build();
  }

  public PostalAddressResponse buildPostalAddressResponse(
      final Party party, final PostalAddress address, final String addressType) {
    Optional<WorkLog> pendingWorkLog = findPendingWorkLog(party, Operation.POSTAL_ADDRESS);

    if (!pendingWorkLog.isPresent()) {

      return PostalAddressResponse.builder()
          .addressLines(address.getLines())
          .postCode(String.valueOf(address.getPostCode()))
          .country(address.getCountry().getIsoCode())
          .pendingUpdate(false)
          .type(addressType)
          .build();
    }

    UpdatePostalAddressRequest payload =
        (UpdatePostalAddressRequest) pendingWorkLog.get().getMessage().getWorkLogPayload();

    Country country = countryRepository.getById(payload.getCountry());
    String pendingType = String.valueOf(payload.getFunction());

    log.info(
        "Updating postal address response to use pending address: {} {}, type: {}, pafKey: ",
        getAddressLinesNonNull(payload),
        PostCode.builder()
            .areaCode(payload.getAreaCode())
            .districtCode(payload.getDistrictCode())
            .sectorCode(payload.getSectorCode())
            .unitCode(payload.getUnitCode())
            .build()
            .toString(),
        pendingType,
        payload.getPafAddressKey());

    return PostalAddressResponse.builder()
        .addressLines(getAddressLinesNonNull(payload))
        .postCode(
            String.valueOf(
                PostCode.builder()
                    .areaCode(payload.getAreaCode())
                    .districtCode(payload.getDistrictCode())
                    .sectorCode(payload.getSectorCode())
                    .unitCode(payload.getUnitCode())
                    .build()))
        .country(country.getIsoCode())
        .type(pendingType)
        .pendingUpdate(true)
        .build();
  }

  private Optional<WorkLog> findPendingWorkLog(final Party party, final Operation operation) {
    return workLogRepository
        .findPendingWorkLogByPartyIdAndOperation(party.getSysId(), operation)
        .map(
            workLog -> {
              log.info("Found pending worklog {} for party {}", operation, party.getSysId());
              return workLog;
            });
  }

  public PhoneNumberResponse buildPhoneNumberResponse(
      final Party party, final PhoneNumberResponse address) {
    List<WorkLog> pendingWorkLog = findPendingWorkLogsForPhoneNumbers(party);

    Optional<Optional<PhoneNumberBasic>> pendingPhoneNumber =
        pendingWorkLog.stream()
            .map(this::buildPendingPhoneNumber)
            .filter(p -> p.get().getType().equals(PhoneNumberBasicType.valueOf(address.getType())))
            .findFirst();

    if (pendingPhoneNumber.isPresent() && pendingPhoneNumber.get().isPresent()) {
      PhoneNumberBasic num = pendingPhoneNumber.get().get();

      return PhoneNumberResponse.builder()
          .number(num.getNumber())
          .pendingUpdate(true)
          .type(address.getType())
          .subType(address.getSubType())
          .countryCode(address.getCountryCode())
          .build();
    }

    return PhoneNumberResponse.builder()
        .number(address.getNumber())
        .type(address.getType())
        .subType(address.getSubType())
        .countryCode(address.getCountryCode())
        .build();
  }

  private Optional<PhoneNumberBasic> buildPendingPhoneNumber(final WorkLog worklog) {

    if (isUpdatePhoneNumber(worklog)) {
      return Optional.of(
          PhoneNumberBasic.builder()
              .type(
                  PhoneNumberBasicType.valueOf(
                      String.valueOf(getPendingUpdatePhoneNumberTypeFromWorkLog(worklog))))
              .number(getPendingUpdatePhoneNumberFromWorkLog(worklog))
              .build());
    }

    if (isDeletePhoneNumber(worklog)) {
      return Optional.of(
          PhoneNumberBasic.builder()
              .type(
                  PhoneNumberBasicType.valueOf(
                      String.valueOf(getPendingDeletePhoneNumberTypeFromWorkLog(worklog))))
              .build());
    }

    return Optional.empty();
  }

  private List<WorkLog> findPendingWorkLogsForPhoneNumbers(final Party party) {

    return workLogRepository.findPendingWorkLogByPartyIdAndUpdateDeletePhoneNumber(party.getSysId())
        .stream()
        .map(
            workLog -> {
              log.info(
                  "Found pending worklog for party {} and operation {} Phone Number",
                  party.getSysId(),
                  workLog.getOperation());
              return workLog;
            })
        .collect(Collectors.toList());
  }

  private PhoneNumberRequestType getPendingUpdatePhoneNumberTypeFromWorkLog(final WorkLog worklog) {
    UpdatePhoneRequest payload = (UpdatePhoneRequest) worklog.getMessage().getWorkLogPayload();
    return payload.getRequestType();
  }

  private String getPendingUpdatePhoneNumberFromWorkLog(final WorkLog worklog) {
    UpdatePhoneRequest payload = (UpdatePhoneRequest) worklog.getMessage().getWorkLogPayload();
    return resolvePendingPhoneNumberCode(payload);
  }

  private String resolvePendingPhoneNumberCode(final UpdatePhoneRequest payload) {
    Integer adcCode = Optional.ofNullable(payload.getAreaDiallingCode()).orElse(0);
    String phoneNumber = payload.getNumber();

    if (!adcCode.equals(0)) {
      return "0" + adcCode + phoneNumber;
    }
    return phoneNumber;
  }

  private PhoneNumberRequestType getPendingDeletePhoneNumberTypeFromWorkLog(final WorkLog worklog) {
    DeletePhoneRequest payload = (DeletePhoneRequest) worklog.getMessage().getWorkLogPayload();
    return payload.getRequestType();
  }

  private boolean isDeletePhoneNumber(final WorkLog workLog) {

    return workLog.getMessage().getWorkLogPayload() instanceof DeletePhoneRequest;
  }

  private boolean isUpdatePhoneNumber(final WorkLog workLog) {

    return workLog.getMessage().getWorkLogPayload() instanceof UpdatePhoneRequest;
  }

  private List<String> getAddressLinesNonNull(
      final UpdatePostalAddressRequest postalAddressRequest) {
    return Stream.of(
            postalAddressRequest.getAddressLine1(),
            postalAddressRequest.getAddressLine2(),
            postalAddressRequest.getAddressLine3(),
            postalAddressRequest.getAddressLine4(),
            postalAddressRequest.getAddressLine5())
        .filter(pa -> pa != null && !pa.trim().isEmpty())
        .collect(Collectors.toList());
  }
}
