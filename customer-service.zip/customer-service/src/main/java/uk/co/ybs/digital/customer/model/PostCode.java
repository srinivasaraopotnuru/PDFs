package uk.co.ybs.digital.customer.model;

import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PostCode {

  private String areaCode;

  private String districtCode;

  private String sectorCode;

  private String unitCode;

  @Override
  public String toString() {
    return areaCode + districtCode + ' ' + sectorCode + unitCode;
  }
}
