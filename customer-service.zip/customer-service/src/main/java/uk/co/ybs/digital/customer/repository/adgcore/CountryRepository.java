package uk.co.ybs.digital.customer.repository.adgcore;

import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.customer.model.adgcore.Country;

public interface CountryRepository extends JpaRepository<Country, String> {}
