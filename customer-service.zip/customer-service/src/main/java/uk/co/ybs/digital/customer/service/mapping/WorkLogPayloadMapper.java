package uk.co.ybs.digital.customer.service.mapping;

import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.service.AreaDiallingCodesService;
import uk.co.ybs.digital.customer.service.utilities.PhoneNumberUtilities;
import uk.co.ybs.digital.customer.service.utilities.PostCodeHelper;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;

@Mapper(componentModel = "spring")
@AllArgsConstructor
@NoArgsConstructor
public class WorkLogPayloadMapper {

  @Autowired private AreaDiallingCodesService areaDiallingCodesService;
  private static final Locale LOCALE = Locale.ROOT;

  public WorkLogPayload map(final PostalAddressRequest request) {

    final UpdatePostalAddressRequest.UpdatePostalAddressRequestBuilder builder =
        UpdatePostalAddressRequest.builder();

    AtomicReference<Integer> addressLineCount = new AtomicReference<>(0);
    request
        .getAddress()
        .getAddressLines()
        .forEach(
            addressLine -> {
              addressLineCount.getAndSet(addressLineCount.get() + 1);
              if ("1".equals(String.valueOf(addressLineCount))) {
                builder.addressLine1(addressLine.toUpperCase(LOCALE));
              } else if ("2".equals(String.valueOf(addressLineCount))) {
                builder.addressLine2(addressLine.toUpperCase(LOCALE));
              } else if ("3".equals(String.valueOf(addressLineCount))) {
                builder.addressLine3(addressLine.toUpperCase(LOCALE));
              } else if ("4".equals(String.valueOf(addressLineCount))) {
                builder.addressLine4(addressLine.toUpperCase(LOCALE));
              } else if ("5".equals(String.valueOf(addressLineCount))) {
                builder.addressLine5(addressLine.toUpperCase(LOCALE));
              }
            });

    if (request.getPaf() != null) {
      builder
          .pafAddressKey(request.getPaf().getAddressKey())
          .pafDeliveryPointSuffix(StringUtils.left(request.getPaf().getDeliveryPointSuffix(), 2));
    }

    final Optional<PostCode> splitPostCode =
        PostCodeHelper.splitPostCode(request.getAddress().getPostCode().toUpperCase(LOCALE));

    return builder
        .addressType(PostalAddress.PostalAddressSubType.UKPOST)
        .function(PostalAddress.PostalAddressType.CORR)
        .country(request.getAddress().getCountry().getCode())
        .areaCode(splitPostCode.get().getAreaCode())
        .districtCode(splitPostCode.get().getDistrictCode())
        .sectorCode(splitPostCode.get().getSectorCode())
        .unitCode(splitPostCode.get().getUnitCode())
        .build();
  }

  public WorkLogPayload map(final PhoneNumberBasic phoneNumber) {

    Integer areaDiallingCode = null;

    if (phoneNumber.getNumber() == null) {
      return DeletePhoneRequest.builder()
          .requestType(PhoneNumberRequestType.valueOf(phoneNumber.getType().toString()))
          .build();
    }

    String formattedNumber = PhoneNumberUtilities.formatPhoneNumber(phoneNumber.getNumber());

    if (PhoneNumberUtilities.isHomeOrWorkNumber(phoneNumber.getType(), phoneNumber.getNumber())) {
      areaDiallingCode =
          areaDiallingCodesService.determineAreaDiallingCode(formattedNumber).orElse(null);

      if (areaDiallingCode != null) {
        formattedNumber = formattedNumber.substring(areaDiallingCode.toString().length() + 1);
      }
    }

    return UpdatePhoneRequest.builder()
        .areaDiallingCode(areaDiallingCode)
        .requestType(PhoneNumberRequestType.valueOf(phoneNumber.getType().toString()))
        .number(formattedNumber)
        .build();
  }
}
