package uk.co.ybs.digital.customer.model;

import javax.persistence.AttributeConverter;

public class YesOrNullConverter implements AttributeConverter<Boolean, String> {
  @Override
  public String convertToDatabaseColumn(final Boolean bool) {
    boolean yes = bool != null && bool;
    return yes ? "Y" : null;
  }

  @Override
  public Boolean convertToEntityAttribute(final String yesOrNo) {
    return "Y".equalsIgnoreCase(yesOrNo);
  }
}
