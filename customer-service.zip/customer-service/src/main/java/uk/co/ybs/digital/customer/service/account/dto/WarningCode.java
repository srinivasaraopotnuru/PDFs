package uk.co.ybs.digital.customer.service.account.dto;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WarningCode {

  String code;
}
