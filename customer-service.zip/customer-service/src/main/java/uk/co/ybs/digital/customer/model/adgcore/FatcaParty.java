package uk.co.ybs.digital.customer.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "FATCA_PARTIES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FatcaParty {

  @Id
  @Column(name = "SYSID")
  private Long sysId;

  @NonNull
  @Column(name = "PARTY_SYSID")
  private Long partyId;

  @NonNull
  @Column(name = "FATCA_RESPONSE_US")
  @Type(type = "yes_no")
  private Boolean fatcaResponseUS;

  @NonNull
  @Column(name = "FATCA_RESPONSE_UK")
  @Type(type = "yes_no")
  private Boolean fatcaResponseUK;

  @NonNull
  @Column(name = "START_DATE")
  private LocalDateTime startDate;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;
}
