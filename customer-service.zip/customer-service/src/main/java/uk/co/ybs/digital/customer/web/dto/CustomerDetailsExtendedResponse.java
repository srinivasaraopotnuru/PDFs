package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public final class CustomerDetailsExtendedResponse {
  @JsonProperty(value = "party")
  @ApiModelProperty(required = true)
  private final GoldenCustomerExtendedRecord goldenCustomerExtendedRecord;
}
