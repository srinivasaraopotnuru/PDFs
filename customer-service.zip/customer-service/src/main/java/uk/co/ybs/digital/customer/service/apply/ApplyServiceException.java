package uk.co.ybs.digital.customer.service.apply;

public class ApplyServiceException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public ApplyServiceException(final String message) {
    super(message);
  }

  public ApplyServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
