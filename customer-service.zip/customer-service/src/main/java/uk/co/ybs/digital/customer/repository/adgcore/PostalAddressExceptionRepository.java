package uk.co.ybs.digital.customer.repository.adgcore;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddressException;

public interface PostalAddressExceptionRepository
    extends JpaRepository<PostalAddressException, String> {

  @Query(
      value =
          "SELECT pae.code "
              + "FROM PostalAddressException pae "
              + " WHERE UPPER(:addressLine) LIKE '%' || pae.invalidText || '%' "
              + "   AND pae.endDate is null")
  Optional<String> findExceptionForAddressLine(String addressLine);
}
