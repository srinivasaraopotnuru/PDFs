package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = FatcaParty.FatcaPartyBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class FatcaParty {

  private Boolean fatcaResponseUS;

  private Boolean fatcaResponseUK;

  @JsonPOJOBuilder(withPrefix = "")
  public static class FatcaPartyBuilder {}
}
