package uk.co.ybs.digital.customer.service.shareplan;

import io.micrometer.core.annotation.Timed;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.customer.service.shareplan.dto.ShareplanAccount;
import uk.co.ybs.digital.customer.service.shareplan.dto.ShareplanAccount.Account;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class ShareplanService {
  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String BRAND_CODE_HEADER = "x-ybs-brand-code";
  private static final String EMPTY_RESPONSE_ERROR_MESSAGE =
      "Empty response calling shareplan service";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling shareplan service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Error calling shareplan service: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private final WebClient sharePlanServiceWebClient;

  /**
   * Returns a list of shareplan accounts for a party Sys Id.
   *
   * @param metadata
   * @return
   */
  public List<Account> getShareplanAccount(final RequestMetadata metadata) {
    return get(metadata, ShareplanAccount.class, "/").getAccounts();
  }

  private <T> T get(final RequestMetadata metadata, final Class<T> responseType, final String uri) {

    return sharePlanServiceWebClient
        .get()
        .uri(uri)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(BRAND_CODE_HEADER, metadata.getBrandCode())
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + metadata.getForwardingAuth())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .bodyToMono(responseType)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new ShareplanServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new ShareplanServiceException(EMPTY_RESPONSE_ERROR_MESSAGE));
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof ShareplanServiceException);
  }

  private Mono<ShareplanServiceException> handleHttpStatusError(
      final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new ShareplanServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new ShareplanServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new ShareplanServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
