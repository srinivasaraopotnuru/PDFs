package uk.co.ybs.digital.customer.model.adgcore;

public enum NPASourceType {
  HOME,
  MOBILE,
  WORK,
  DEFAULT
}
