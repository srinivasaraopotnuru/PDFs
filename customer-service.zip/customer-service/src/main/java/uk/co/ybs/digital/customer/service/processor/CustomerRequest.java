package uk.co.ybs.digital.customer.service.processor;

public interface CustomerRequest {
  ResolvedCustomerRequest resolve();

  void auditFailure(String message);
}
