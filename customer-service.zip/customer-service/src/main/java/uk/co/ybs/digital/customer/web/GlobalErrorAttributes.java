package uk.co.ybs.digital.customer.web;

import static uk.co.ybs.digital.customer.web.dto.ErrorResponse.ErrorItem;
import static uk.co.ybs.digital.customer.web.dto.ErrorResponse.builder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.util.WebUtils;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;

/** ErrorAttributes used by the whitelabel error page (see BasicErrorController). */
@Component
@AllArgsConstructor
@Slf4j
public class GlobalErrorAttributes implements ErrorAttributes {
  @NonNull private final ObjectMapper objectMapper;

  @Override
  public Map<String, Object> getErrorAttributes(
      final WebRequest webRequest, final ErrorAttributeOptions options) {
    log.error("Unexpected error handled by whitelabel error page!", getError(webRequest));

    final UUID requestId = RequestIdHelper.getRequestId(webRequest);
    final HttpStatus status = getStatus(webRequest);

    final ErrorResponse errorResponse =
        builder(status)
            .id(requestId)
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNEXPECTED_ERROR)
                    .message("Unexpected error")
                    .build())
            .build();
    final TypeReference<Map<String, Object>> errorAttributesType =
        new TypeReference<Map<String, Object>>() {};

    return objectMapper.convertValue(errorResponse, errorAttributesType);
  }

  @Override
  public Throwable getError(final WebRequest webRequest) {
    return getAttribute(webRequest, WebUtils.ERROR_EXCEPTION_ATTRIBUTE);
  }

  @SuppressWarnings("unchecked")
  private <T> T getAttribute(final RequestAttributes requestAttributes, final String name) {
    return (T) requestAttributes.getAttribute(name, RequestAttributes.SCOPE_REQUEST);
  }

  private HttpStatus getStatus(final WebRequest request) {
    Integer statusCode = getAttribute(request, WebUtils.ERROR_STATUS_CODE_ATTRIBUTE);
    try {
      return HttpStatus.valueOf(statusCode);
    } catch (Exception ex) {
      return HttpStatus.INTERNAL_SERVER_ERROR;
    }
  }
}
