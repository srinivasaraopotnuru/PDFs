package uk.co.ybs.digital.customer.exception;

public class BadFailureRequestChallengeException extends CustomerServiceException {

  private static final long serialVersionUID = -3128350491781011581L;

  public BadFailureRequestChallengeException(final String message) {
    super(message, null);
  }

  public BadFailureRequestChallengeException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
