package uk.co.ybs.digital.customer.service.apply.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

public class TrimmedSizeValidator implements ConstraintValidator<TrimmedSize, String> {

  /** The min. */
  private transient int min;

  /** The max. */
  private transient int max;

  /**
   * Initialize.
   *
   * @param constraintAnnotation the constraint annotation
   */
  public void initialize(final TrimmedSize constraintAnnotation) {

    this.min = constraintAnnotation.min();
    this.max = constraintAnnotation.max();
  }

  /**
   * Checks if is valid.
   *
   * @param value the value
   * @param constraintContext the constraint context
   * @return true, if is valid
   */
  public boolean isValid(final String value, final ConstraintValidatorContext constraintContext) {

    String str = StringUtils.normalizeSpace(value);
    if (str == null) {
      return true;
    }
    return (str.length() >= min && str.length() <= max);
  }
}
