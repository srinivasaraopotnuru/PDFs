package uk.co.ybs.digital.customer.repository.adgcore;

import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.adgcore.FatcaParty;

public interface FatcaPartyRepository extends JpaRepository<FatcaParty, Long> {

  @Query(
      "FROM FatcaParty "
          + "WHERE partyId = :partyId "
          + "AND :now > startDate "
          + "AND (endedDate is null OR endedDate > :now)")
  Optional<FatcaParty> findByPartyIdAndNotEnded(Long partyId, LocalDateTime now);
}
