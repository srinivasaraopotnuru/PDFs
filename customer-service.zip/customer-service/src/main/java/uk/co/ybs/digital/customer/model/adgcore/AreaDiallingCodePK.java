package uk.co.ybs.digital.customer.model.adgcore;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Embeddable
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AreaDiallingCodePK implements Serializable {
  private static final long serialVersionUID = 1L;

  @Column(name = "CNTRY_CODE")
  private String cntryCode;

  @Column(name = "CODE")
  private int code;
}
