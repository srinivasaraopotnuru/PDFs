package uk.co.ybs.digital.customer.config;

import java.time.Clock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.auditing.DateTimeProvider;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import uk.co.ybs.digital.customer.model.digitalcustomer.ClockDateTimeProvider;
import uk.co.ybs.digital.customer.model.digitalcustomer.EntityAuditor;

@Configuration
@EnableJpaAuditing(dateTimeProviderRef = "auditorDateTimeProvider")
public class JpaAuditingConfig {

  @Value("${spring.datasource.digitalcustomer.username:DIGITAL_CUSTOMER}")
  private String databaseUser;

  @Bean
  public AuditorAware<String> auditorAware() {
    return new EntityAuditor(databaseUser);
  }

  @Bean
  public DateTimeProvider auditorDateTimeProvider(final Clock clock) {
    return new ClockDateTimeProvider(clock);
  }
}
