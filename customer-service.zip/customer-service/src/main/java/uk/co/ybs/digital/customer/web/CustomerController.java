package uk.co.ybs.digital.customer.web;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import uk.co.ybs.digital.customer.config.SwaggerConfig;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.service.CustomerService;
import uk.co.ybs.digital.customer.service.ScaCredentialsExtractor;
import uk.co.ybs.digital.customer.web.dto.CustomerBasicResponse;
import uk.co.ybs.digital.customer.web.dto.CustomerDetailsResponse;
import uk.co.ybs.digital.customer.web.dto.EmailAddress;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.FailureRequest;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.logging.filters.session.SessionIdFilter;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@RestController
@RequiredArgsConstructor
@Validated
public class CustomerController {

  private final CustomerService customerService;
  private final ScaCredentialsExtractor scaCredentialsExtractor;
  private final Clock clock;
  private static final String BAD_REQUEST = "Bad request";
  private static final String UNAUTHORISED = "Unauthorised";
  private static final String FORBIDDEN = "Forbidden";
  private static final String CONFLICT = "Conflict";
  private static final String INTERNAL_SERVER_ERROR = "Internal Server Error";
  private static final String UNSUPPORTED_MEDIA_TYPE = "Unsupported Media Type";
  private static final String ACCOUNT_SCOPE_AUTHORITY = "hasAuthority('SCOPE_ACCOUNT_READ')";

  @GetMapping(value = "/customer/{partyId}", produces = MediaType.APPLICATION_JSON_VALUE)
  @ApiOperation(value = "Get details for a customer")
  public CustomerBasicResponse getCustomerBasic(
      @PathVariable @ApiParam(value = "Customer number for the request", required = true)
          final long partyId) {

    final LocalDateTime now = LocalDateTime.now(clock);

    return CustomerBasicResponse.builder()
        .customer(customerService.getCustomer(partyId, now))
        .build();
  }

  @GetMapping(value = "/customer/delayed/{partyId}", produces = MediaType.APPLICATION_JSON_VALUE)
  @ApiOperation(value = "Get details for a customer with yesterdays contact details")
  public CustomerBasicResponse getCustomerBasicDelayed(
      @PathVariable @ApiParam(value = "Customer number for the request", required = true)
          final long partyId) {

    final LocalDateTime yesterday = LocalDate.now(clock).minusDays(1).atTime(23, 59, 59);

    return CustomerBasicResponse.builder()
        .customer(customerService.getCustomer(partyId, yesterday))
        .build();
  }

  @GetMapping(value = "/customer", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(ACCOUNT_SCOPE_AUTHORITY)
  @ApiOperation(
      value = "Get details for an authenticated customer",
      authorizations = {@Authorization(value = SwaggerConfig.SECURITY_SCHEME)})
  public CustomerDetailsResponse getCustomerDetails(
      @ApiParam(hidden = true) @AuthenticationPrincipal final Jwt user,
      @ApiParam(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @ApiParam(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      final HttpServletRequest request,
      @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetadataHelper.buildRequestMetadata(user, sessionId, requestId, request, headers);
    try {
      return CustomerDetailsResponse.builder()
          .goldenCustomerRecord(
              customerService.getCustomerDetails(metadata, GoldenCustomerRecord.class))
          .build();
    } catch (CustomerNotFoundException ex) {
      throw new CustomerServiceException("Customer not found for party Id in JWT", ex);
    }
  }

  @PostMapping(value = "/customer/email-address", consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(ACCOUNT_SCOPE_AUTHORITY)
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  @ApiResponses(
      value = {
        @ApiResponse(code = 202, message = "Email address updated"),
        @ApiResponse(code = 400, message = BAD_REQUEST, response = ErrorResponse.class),
        @ApiResponse(code = 401, message = UNAUTHORISED, response = ErrorResponse.class),
        @ApiResponse(code = 403, message = FORBIDDEN, response = ErrorResponse.class),
        @ApiResponse(code = 409, message = CONFLICT, response = ErrorResponse.class),
        @ApiResponse(code = 415, message = UNSUPPORTED_MEDIA_TYPE, response = ErrorResponse.class),
        @ApiResponse(code = 500, message = INTERNAL_SERVER_ERROR, response = ErrorResponse.class)
      })
  @ApiOperation(
      value = "Update email address for a customer",
      authorizations = {@Authorization(value = SwaggerConfig.SECURITY_SCHEME)})
  public void updateCustomerEmail(
      @ApiParam(hidden = true) @AuthenticationPrincipal final Jwt user,
      @ApiParam(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @ApiParam(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      final HttpServletRequest request,
      @RequestBody @Validated final EmailAddress requestBody,
      @RequestHeader final HttpHeaders headers) {

    final RequestMetadata metadata =
        RequestMetadataHelper.buildRequestMetadata(user, sessionId, requestId, request, headers);

    final Optional<ScaCredentials> scaCredentials = scaCredentialsExtractor.extract(headers);

    customerService.updateEmailAddress(requestBody, metadata, scaCredentials.orElse(null));
  }

  @PostMapping(value = "/customer/phone-number", consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(ACCOUNT_SCOPE_AUTHORITY)
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  @ApiResponses(
      value = {
        @ApiResponse(code = 202, message = "Phone number updated"),
        @ApiResponse(code = 400, message = BAD_REQUEST, response = ErrorResponse.class),
        @ApiResponse(code = 401, message = UNAUTHORISED, response = ErrorResponse.class),
        @ApiResponse(code = 403, message = FORBIDDEN, response = ErrorResponse.class),
        @ApiResponse(code = 409, message = CONFLICT, response = ErrorResponse.class),
        @ApiResponse(code = 415, message = UNSUPPORTED_MEDIA_TYPE, response = ErrorResponse.class),
        @ApiResponse(code = 500, message = INTERNAL_SERVER_ERROR, response = ErrorResponse.class)
      })
  @ApiOperation(
      value = "Update phone number(s) for a customer",
      authorizations = {@Authorization(value = SwaggerConfig.SECURITY_SCHEME)})
  public void updateCustomerPhoneNumber(
      @ApiParam(hidden = true) @AuthenticationPrincipal final Jwt user,
      @ApiParam(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @ApiParam(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      final HttpServletRequest request,
      @RequestBody @Validated final PhoneNumberRequest requestBody,
      @RequestHeader final HttpHeaders headers) {

    final RequestMetadata metadata =
        RequestMetadataHelper.buildRequestMetadata(user, sessionId, requestId, request, headers);

    final Optional<ScaCredentials> scaCredentials = scaCredentialsExtractor.extract(headers);

    customerService.updatePhoneNumber(requestBody, metadata, scaCredentials.orElse(null));
  }

  @PostMapping(value = "/customer/postal-address", consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(ACCOUNT_SCOPE_AUTHORITY)
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  @ApiResponses(
      value = {
        @ApiResponse(code = 202, message = "Postal address updated"),
        @ApiResponse(code = 400, message = BAD_REQUEST, response = ErrorResponse.class),
        @ApiResponse(code = 401, message = UNAUTHORISED, response = ErrorResponse.class),
        @ApiResponse(code = 403, message = FORBIDDEN, response = ErrorResponse.class),
        @ApiResponse(code = 409, message = CONFLICT, response = ErrorResponse.class),
        @ApiResponse(code = 415, message = UNSUPPORTED_MEDIA_TYPE, response = ErrorResponse.class),
        @ApiResponse(code = 500, message = INTERNAL_SERVER_ERROR, response = ErrorResponse.class)
      })
  @ApiOperation(
      value = "Update postal address for a customer",
      authorizations = {@Authorization(value = SwaggerConfig.SECURITY_SCHEME)})
  public void updateCustomerPostalAddress(
      @ApiParam(hidden = true) @AuthenticationPrincipal final Jwt user,
      @ApiParam(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @ApiParam(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      final HttpServletRequest request,
      @RequestBody @Validated final PostalAddressRequest requestBody,
      @RequestHeader final HttpHeaders headers) {

    final RequestMetadata metadata =
        RequestMetadataHelper.buildRequestMetadata(user, sessionId, requestId, request, headers);

    final Optional<ScaCredentials> scaCredentials = scaCredentialsExtractor.extract(headers);

    customerService.updatePostalAddress(requestBody, metadata, scaCredentials.orElse(null));
  }

  @PostMapping(value = "/failure", consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(ACCOUNT_SCOPE_AUTHORITY)
  @ApiResponses(
      value = {
        @ApiResponse(code = 204, message = "Authentication failure recorded"),
        @ApiResponse(code = 400, message = BAD_REQUEST, response = ErrorResponse.class),
        @ApiResponse(code = 401, message = UNAUTHORISED, response = ErrorResponse.class),
        @ApiResponse(code = 403, message = FORBIDDEN, response = ErrorResponse.class),
        @ApiResponse(code = 415, message = UNSUPPORTED_MEDIA_TYPE, response = ErrorResponse.class),
        @ApiResponse(code = 500, message = INTERNAL_SERVER_ERROR, response = ErrorResponse.class)
      })
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void reportFailure(
      @ApiParam(hidden = true) @AuthenticationPrincipal final Jwt user,
      @ApiParam(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @ApiParam(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      @ApiParam(hidden = true) @RequestHeader final HttpHeaders headers,
      @RequestBody final FailureRequest request,
      final HttpServletRequest servletRequest) {
    final RequestMetadata metadata =
        RequestMetadataHelper.buildRequestMetadata(
            user, sessionId, requestId, servletRequest, headers);
    customerService.reportFailure(request, metadata);
  }

  @GetMapping(value = "/customer/available-products", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(ACCOUNT_SCOPE_AUTHORITY)
  @ApiOperation(
      value = "Get available products for an authenticated customer",
      authorizations = {@Authorization(value = SwaggerConfig.SECURITY_SCHEME)})
  public List<ProductCategory> getAvailableProducts(
      @ApiParam(hidden = true) @AuthenticationPrincipal final Jwt user,
      @ApiParam(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @ApiParam(hidden = true)
          @RequestAttribute(value = SessionIdFilter.SESSION_ID_ATTRIBUTE_NAME, required = false)
          final UUID sessionId,
      final HttpServletRequest request,
      @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetadataHelper.buildRequestMetadata(user, sessionId, requestId, request, headers);

    return customerService.getAvailableProducts(metadata);
  }
}
