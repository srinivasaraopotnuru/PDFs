package uk.co.ybs.digital.customer.web;

import static uk.co.ybs.digital.customer.web.dto.ErrorResponse.ErrorItem;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.TypeMismatchException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.util.CollectionUtils;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;

@Slf4j
@ControllerAdvice
@Order(
    Ordered.HIGHEST_PRECEDENCE) // Consult this ControllerAdvice first, before any service specific
// advice
public class GlobalMvcResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

  @Override
  protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
      final HttpRequestMethodNotSupportedException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    pageNotFoundLogger.warn(ex.getMessage());

    Set<HttpMethod> supportedMethods = ex.getSupportedHttpMethods();
    if (!CollectionUtils.isEmpty(supportedMethods)) {
      headers.setAllow(supportedMethods);
    }

    final ErrorResponse body =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNSUPPORTED_METHOD)
                    .message("Unsupported method")
                    .build())
            .build();

    return handleExceptionInternal(ex, body, headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(
      final HttpMessageNotReadableException exception,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    ErrorResponse.ErrorResponseBuilder response =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Unable to parse request body");

    if (exception.getMostSpecificCause() instanceof InvalidFormatException) {
      InvalidFormatException invalidFormatException =
          (InvalidFormatException) exception.getMostSpecificCause();
      Object value = invalidFormatException.getValue();
      Class<?> type = invalidFormatException.getTargetType();
      String path =
          invalidFormatException.getPath().stream()
              .map(
                  ref -> {
                    if (ref.getFieldName() == null) {
                      return String.valueOf(ref.getIndex());
                    }
                    return ref.getFieldName();
                  })
              .collect(Collectors.joining("."));

      response.error(
          ErrorItem.builder()
              .errorCode(ErrorItem.FIELD_INVALID)
              .message(String.format("`%s` is not a valid %s", value, type.getSimpleName()))
              .path(path)
              .build());
    } else {
      log.warn("Unable to parse body", exception);
      response.error(
          ErrorItem.builder()
              .errorCode(ErrorItem.RESOURCE_INVALID_FORMAT)
              .message("An unexpected error occurred when attempting to parse the request body")
              .build());
    }

    return handleExceptionInternal(exception, response.build(), headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleServletRequestBindingException(
      final ServletRequestBindingException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    if (ex instanceof MissingRequestHeaderException) {
      final MissingRequestHeaderException missingRequestHeaderException =
          (MissingRequestHeaderException) ex;
      final ErrorResponse errorResponse =
          ErrorResponse.builder(status)
              .id(RequestIdHelper.getRequestId(request))
              .message("Header missing")
              .error(
                  ErrorItem.builder()
                      .errorCode(ErrorItem.HEADER_MISSING)
                      .message(
                          String.format(
                              "Header missing: %s", missingRequestHeaderException.getHeaderName()))
                      .build())
              .build();
      return handleExceptionInternal(ex, errorResponse, headers, status, request);
    } else {
      return super.handleServletRequestBindingException(ex, headers, status, request);
    }
  }

  @Override
  protected ResponseEntity<Object> handleTypeMismatch(
      final TypeMismatchException ex,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    if (ex instanceof MethodArgumentTypeMismatchException) {
      final MethodArgumentTypeMismatchException methodArgumentTypeMismatchException =
          (MethodArgumentTypeMismatchException) ex;
      final ErrorResponse errorResponse =
          ErrorResponse.builder(status)
              .id(RequestIdHelper.getRequestId(request))
              .message("Invalid value")
              .error(
                  ErrorItem.builder()
                      .errorCode(ErrorItem.FIELD_INVALID)
                      .message(
                          String.format(
                              "Invalid field: %s", methodArgumentTypeMismatchException.getName()))
                      .build())
              .build();
      return handleExceptionInternal(ex, errorResponse, headers, status, request);
    } else {
      return super.handleTypeMismatch(ex, headers, status, request);
    }
  }

  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      final MethodArgumentNotValidException exception,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    log.info("Handling MethodArgumentNotValidException: {}", exception.toString());

    List<ErrorItem> errors =
        exception.getBindingResult().getFieldErrors().stream()
            .map(
                error -> {
                  if (Objects.isNull(error.getRejectedValue())) {
                    return ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_MISSING)
                        .message(error.getDefaultMessage())
                        .path(error.getField())
                        .build();
                  } else {
                    return ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_INVALID)
                        .message(error.getDefaultMessage())
                        .path(error.getField())
                        .build();
                  }
                })
            .collect(Collectors.toList());

    ErrorResponse response =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Invalid request body")
            .errors(errors)
            .build();

    return handleExceptionInternal(exception, response, headers, status, request);
  }

  @Override
  protected ResponseEntity<Object> handleExceptionInternal(
      final Exception ex,
      Object body,
      final HttpHeaders headers,
      final HttpStatus status,
      final WebRequest request) {
    if (body == null && !HttpStatus.NOT_ACCEPTABLE.equals(status)) {
      // Put a generic error response body in with the right status
      body =
          ErrorResponse.builder(status)
              .id(RequestIdHelper.getRequestId(request))
              .error(
                  ErrorItem.builder()
                      .errorCode(ErrorItem.UNEXPECTED_ERROR)
                      .message("Unexpected Error")
                      .build())
              .build();
    }

    return super.handleExceptionInternal(ex, body, headers, status, request);
  }
}
