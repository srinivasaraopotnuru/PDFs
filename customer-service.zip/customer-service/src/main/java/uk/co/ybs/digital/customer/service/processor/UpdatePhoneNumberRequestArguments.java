package uk.co.ybs.digital.customer.service.processor;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class UpdatePhoneNumberRequestArguments {
  long partyId;
  @NonNull RequestMetadata requestMetadata;
  @NonNull LocalDateTime processTime;
  @NonNull PhoneNumberRequestType phoneNumberRequestType;
  Integer adcCode;
  @NonNull String number;
}
