package uk.co.ybs.digital.customer.service.apply.dto;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum FundedBy {
  DEPOSIT_BY_CARD("deposit-by-card"),
  ISA_TRANSFER("isa-transfer"),
  NONE("none");

  @JsonValue private String value;
}
