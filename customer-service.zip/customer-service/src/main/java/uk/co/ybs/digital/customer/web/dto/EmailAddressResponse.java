package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class EmailAddressResponse {
  @ApiModelProperty(required = true)
  boolean pendingUpdate;

  @ApiModelProperty(required = true)
  String email;

  @ApiModelProperty(required = true)
  String type;
}
