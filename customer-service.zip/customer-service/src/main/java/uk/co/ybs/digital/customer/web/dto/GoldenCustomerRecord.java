package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import java.util.List;
import lombok.Value;
import lombok.experimental.NonFinal;
import lombok.experimental.SuperBuilder;
import lombok.extern.jackson.Jacksonized;

@Value
@NonFinal
@SuperBuilder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class GoldenCustomerRecord {
  @ApiModelProperty(required = true, example = "1234567890")
  private final String partyId;

  @ApiModelProperty(example = "Mr")
  private final String title;

  @ApiModelProperty(required = true, example = "John")
  private final String forename;

  @ApiModelProperty(required = true, example = "Smith")
  private final String surname;

  @ApiModelProperty(example = "NI12345")
  private final String nationalInsuranceNumber;

  @ApiModelProperty(example = "1980-12-12")
  private final LocalDate dateOfBirth;

  @JsonProperty(value = "emailAddress")
  private final List<EmailAddressResponse> emailAddresses;

  @JsonProperty(value = "phoneNumber")
  private final List<PhoneNumberResponse> phoneNumbers;

  @JsonProperty(value = "address")
  private final List<PostalAddressResponse> addresses;

  @ApiModelProperty(required = true)
  private final boolean amendmentRestriction;

  @ApiModelProperty(required = true)
  private final boolean hasSharePlanAccount;

  @ApiModelProperty(required = true)
  private final boolean hasIsaSubscription;

  @ApiModelProperty(required = true, example = "0001234567")
  private final String webCustomerNumber;

  @ApiModelProperty(example = "BRITISH")
  private final String nationality;

  @ApiModelProperty(required = true)
  @Deprecated
  private final MarketingPreferences marketingPreferences;

  @ApiModelProperty(required = true)
  private final Preferences preferences;

  @JsonProperty(value = "fatcaParty")
  private final FatcaParty fatcaParty;

  @JsonProperty(value = "fatcaProfile")
  private final List<FatcaProfile> fatcaProfiles;
}
