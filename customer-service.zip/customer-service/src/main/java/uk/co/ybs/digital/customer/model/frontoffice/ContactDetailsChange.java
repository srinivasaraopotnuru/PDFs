package uk.co.ybs.digital.customer.model.frontoffice;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder(toBuilder = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(ContactDetailsChange.ContactDetailsChangePk.class)
@Table(name = "CONTACT_DETAILS_CHANGE")
public class ContactDetailsChange implements Serializable {

  private static final long serialVersionUID = -3810226270768568660L;

  @Id
  @Column(name = "PARTY_SYSID", nullable = false)
  private String partySysId;

  @Id
  @Column(name = "AMEND_DATE", nullable = false)
  private LocalDateTime amendDate;

  @Column(name = "EMAIL_ADDRESS")
  private String emailAddress;

  @Column(name = "HOME_TELEPHONE_NUMBER")
  private String homeTelephoneNumber;

  @Column(name = "WORK_TELEPHONE_NUMBER")
  private String workTelephoneNumber;

  @Column(name = "MOBILE_TELEPHONE_NUMBER")
  private String mobileTelephoneNumber;

  @Column(name = "PREFERRED_CONTACT_TIME")
  private String preferredContactTime;

  @Column(name = "PREFERRED_CONTACT_METHOD")
  private String preferredContactMethod;

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class ContactDetailsChangePk implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "PARTY_SYSID", nullable = false)
    private String partySysId;

    @Column(name = "AMEND_DATE", nullable = false)
    private LocalDateTime amendDate;
  }
}
