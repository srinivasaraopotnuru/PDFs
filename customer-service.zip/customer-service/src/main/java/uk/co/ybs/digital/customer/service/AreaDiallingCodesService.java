package uk.co.ybs.digital.customer.service;

import java.util.Optional;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.customer.repository.adgcore.AreaDiallingCodesRepository;

@Service
@AllArgsConstructor
public class AreaDiallingCodesService {

  @Autowired private final AreaDiallingCodesRepository areaDiallingCodesRepository;

  public Optional<Integer> determineAreaDiallingCode(final String phoneNumber) {
    String number = phoneNumber.startsWith("0") ? phoneNumber.substring(1) : phoneNumber;

    return areaDiallingCodesRepository.findAreaDiallingCodeForPhoneNumber("UK", number);
  }
}
