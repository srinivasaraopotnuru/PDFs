package uk.co.ybs.digital.customer.service.mapping;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;

@Component
@Slf4j
@RequiredArgsConstructor
public class ContactDetailsChangeMapper {

  public ContactDetailsChange map(final GoldenCustomerRecord goldenCustomerRecord) {

    List<PhoneNumberResponse> phoneNumbers = goldenCustomerRecord.getPhoneNumbers();

    ContactDetailsChange contactDetailsChange =
        ContactDetailsChange.builder().partySysId(goldenCustomerRecord.getPartyId()).build();

    phoneNumbers.forEach(
        p -> {
          switch (p.getType()) {
            case "HOME":
              contactDetailsChange.setHomeTelephoneNumber(p.getNumber());
              break;
            case "WORK":
              contactDetailsChange.setWorkTelephoneNumber(p.getNumber());
              break;
            case "MOBILE":
              contactDetailsChange.setMobileTelephoneNumber(p.getNumber());
              break;
            default:
              log.warn("Illegal Phone Number Type");
              break;
          }
        });

    if (!goldenCustomerRecord.getEmailAddresses().isEmpty()) {
      contactDetailsChange.setEmailAddress(
          goldenCustomerRecord.getEmailAddresses().get(0).getEmail());
    }

    return contactDetailsChange;
  }
}
