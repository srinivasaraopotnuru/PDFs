package uk.co.ybs.digital.customer.web.dto;

import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.Value;
import lombok.experimental.SuperBuilder;
import lombok.extern.jackson.Jacksonized;

@EqualsAndHashCode(callSuper = true)
@Value
@SuperBuilder
@Jacksonized
@ToString(callSuper = true)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class GoldenCustomerExtendedRecord extends GoldenCustomerRecord {

  EncryptedData placeOfBirth;
}
