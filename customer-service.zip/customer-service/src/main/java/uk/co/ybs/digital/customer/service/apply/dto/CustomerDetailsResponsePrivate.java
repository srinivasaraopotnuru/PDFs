package uk.co.ybs.digital.customer.service.apply.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class CustomerDetailsResponsePrivate extends CustomerDetailsResponse {

  /**
   * Constructor for Private Customer Details from base CustomerDetailsResponse.
   *
   * @param customerDetails The base class to construct from.
   */
  public CustomerDetailsResponsePrivate(final CustomerDetailsResponse customerDetails) {
    super(customerDetails.toBuilder());
  }

  private String partySysId;
}
