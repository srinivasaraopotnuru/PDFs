package uk.co.ybs.digital.customer.service.processor;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.customer.model.digitalcustomer.AddressFunction;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PostalAddressType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdateEmailRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayloadVisitor;

@Component
@RequiredArgsConstructor
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public class CustomerRequestFactory {

  private final UpdateEmailAddressProcessor updateEmailAddressProcessor;
  private final DeletePhoneNumberProcessor deletePhoneNumberProcessor;
  private final UpdatePhoneNumberProcessor updatePhoneNumberProcessor;
  private final UpdatePostalAddressProcessor updatePostalAddressProcessor;

  public CustomerRequest build(final WorkLog workLog, final LocalDateTime processTime) {

    final WorkLogPayload workLogPayload = workLog.getMessage().getWorkLogPayload();

    return workLogPayload.accept(new BuildWorkLogPayloadVisitor(workLog, processTime));
  }

  @AllArgsConstructor
  public class BuildWorkLogPayloadVisitor implements WorkLogPayloadVisitor<CustomerRequest> {

    private final WorkLog workLog;
    private final LocalDateTime processTime;

    @Override
    public CustomerRequest visit(final UpdateEmailRequest updateEmailAddress) {

      return UpdateEmailAddressRequest.builder()
          .arguments(
              UpdateEmailAddressRequestArguments.builder()
                  .partyId(workLog.getPartyId())
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .processTime(processTime)
                  .emailAddress(updateEmailAddress.getEmail())
                  .build())
          .processor(updateEmailAddressProcessor)
          .build();
    }

    @Override
    public CustomerRequest visit(final UpdatePhoneRequest updatePhoneRequest) {
      return UpdatePhoneNumberRequest.builder()
          .arguments(
              UpdatePhoneNumberRequestArguments.builder()
                  .partyId(workLog.getPartyId())
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .processTime(processTime)
                  .phoneNumberRequestType(updatePhoneRequest.getRequestType())
                  .adcCode(updatePhoneRequest.getAreaDiallingCode())
                  .number(updatePhoneRequest.getNumber())
                  .build())
          .processor(updatePhoneNumberProcessor)
          .build();
    }

    @Override
    public CustomerRequest visit(final DeletePhoneRequest deletePhoneNumberRequest) {
      return DeletePhoneNumberRequest.builder()
          .arguments(
              DeletePhoneNumberRequestArguments.builder()
                  .partyId(workLog.getPartyId())
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .processTime(processTime)
                  .requestType(deletePhoneNumberRequest.getRequestType())
                  .build())
          .processor(deletePhoneNumberProcessor)
          .build();
    }

    @Override
    public CustomerRequest visit(final UpdatePostalAddressRequest updatePostalAddressRequest) {
      return uk.co.ybs.digital.customer.service.processor.UpdatePostalAddressRequest.builder()
          .arguments(
              UpdatePostalAddressRequestArguments.builder()
                  .partyId(workLog.getPartyId())
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .processTime(processTime)
                  .addressType(
                      PostalAddressType.valueOf(
                          updatePostalAddressRequest.getAddressType().toString()))
                  .function(
                      AddressFunction.valueOf(updatePostalAddressRequest.getFunction().toString()))
                  .addressLine1(updatePostalAddressRequest.getAddressLine1())
                  .addressLine2(updatePostalAddressRequest.getAddressLine2())
                  .addressLine3(updatePostalAddressRequest.getAddressLine3())
                  .addressLine4(updatePostalAddressRequest.getAddressLine4())
                  .addressLine5(updatePostalAddressRequest.getAddressLine5())
                  .country(updatePostalAddressRequest.getCountry())
                  .areaCode(updatePostalAddressRequest.getAreaCode())
                  .districtCode(updatePostalAddressRequest.getDistrictCode())
                  .sectorCode(updatePostalAddressRequest.getSectorCode())
                  .unitCode(updatePostalAddressRequest.getUnitCode())
                  .pafAddressKey(updatePostalAddressRequest.getPafAddressKey())
                  .pafDeliveryPointSuffix(updatePostalAddressRequest.getPafDeliveryPointSuffix())
                  .build())
          .processor(updatePostalAddressProcessor)
          .build();
    }
  }
}
