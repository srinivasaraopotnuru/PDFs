package uk.co.ybs.digital.customer.repository.core;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.core.ActivityPlayer;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public interface ActivityPlayerRepository extends JpaRepository<ActivityPlayer, Long> {
  @Query(
      "SELECT ap FROM ActivityPlayer ap,"
          + " LoanAccount la, "
          + " LoanPart lp, "
          + " LoanPartStatus lps "
          + " WHERE ap.tableSysId = la.accountNumber"
          + " AND la.loanAccountTypeCode = COALESCE(ap.loanAccountTypeCode, 80) "
          + " AND la.accountNumber = lp.loanAccountNumber "
          + " AND la.loanAccountTypeCode = lp.loanAccountTypeCode "
          + " AND lp.loanAccountNumber = lps.loanPartAccountNumber "
          + " AND lp.loanAccountTypeCode = lps.loanPartAccountTypeCode "
          + " AND lp.partNumber = lps.loanPartNumber "
          + " AND la.brandCode = 'YBS'"
          + " AND ap.tableId = 'ACCGRP'"
          + " AND ap.activityType IN ('MHLDRM','OHLDRM')"
          + " AND lp.loanPartTypeCode = 'MAIN'"
          + " AND lps.statusCode = 'OPEN'"
          + " AND lp.endDate IS NULL"
          + " AND lps.endDate IS NULL"
          + " AND ap.startDate <= :now AND (ap.endDate IS NULL OR ap.endDate > :now) "
          + " AND ap.partySysId = :partyId")
  List<ActivityPlayer> findLendingAccountsForParty(Long partyId, LocalDateTime now);
}
