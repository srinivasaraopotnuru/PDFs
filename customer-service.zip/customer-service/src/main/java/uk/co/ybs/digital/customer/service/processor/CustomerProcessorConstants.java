package uk.co.ybs.digital.customer.service.processor;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
final class CustomerProcessorConstants {
  public static final String AUDIT_AT = "0795";
  public static final String AUDIT_BY = "SAPP";
}
