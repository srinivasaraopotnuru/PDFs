package uk.co.ybs.digital.customer.service.utilities;

import io.micrometer.core.instrument.MeterRegistry;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import lombok.NonNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;

@Component
public class WorkLogMetrics {

  private static final String METRIC_BASE_NAME = "uk.co.ybs.digital.customer.processor";

  @NonNull private final transient AtomicLong pendingGauge;
  @NonNull private final transient AtomicLong failedGauge;
  @NonNull private final transient AtomicLong completedGauge;

  public WorkLogMetrics(@Autowired final MeterRegistry registry) {
    pendingGauge =
        registry.gauge(String.format("%s.pending", METRIC_BASE_NAME), new AtomicLong(0L));
    failedGauge = registry.gauge(String.format("%s.failed", METRIC_BASE_NAME), new AtomicLong(0L));
    completedGauge =
        registry.gauge(String.format("%s.completed", METRIC_BASE_NAME), new AtomicLong(0L));
  }

  public void setValues(final Map<WorkLog.Status, Long> states) {
    pendingGauge.set(states.getOrDefault(WorkLog.Status.PENDING, 0L));
    failedGauge.set(states.getOrDefault(WorkLog.Status.FAILED, 0L));
    completedGauge.set(states.getOrDefault(WorkLog.Status.COMPLETE, 0L));
  }
}
