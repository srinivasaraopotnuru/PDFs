package uk.co.ybs.digital.customer.model.core;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQueries;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@NamedStoredProcedureQueries({
  @NamedStoredProcedureQuery(
      name = "wrk0480k.wrk0010d",
      procedureName = "wrk0480k.wrk0010d",
      resultClasses = {WorkEventOutput.class},
      parameters = {
        @StoredProcedureParameter(
            name = "PS_CNTXT_TABLE_ID",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_CNTXT_SYSID_N1",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_CNTXT_SYSID_N2",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_CNTXT_SYSID_V1",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_CNTXT_SYSID_V2",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PD_CNTXT_SYSID_D1",
            type = Date.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PD_CNTXT_SYSID_D2",
            type = Date.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_CALL_MDD_SHORT_NAME",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_CALL_MODLAB_NAME",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_ORACLE_USERID",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WET_NAME",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_WET_INTORG_PARTY_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_TRG_WRK_GRP_ID",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_TRG_WRK_GRP_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PD_WRKEV_DIARY_DATE",
            type = LocalDateTime.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WRKEV_NOTES",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_WSAC_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_WSA_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_COMM_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_TSTOUT_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_AUTCON_AMT",
            type = Double.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WRKEV_STATUS",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PS_CHAR1", type = String.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PS_CHAR2", type = String.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PS_CHAR3", type = String.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PD_DATE1", type = Date.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PD_DATE2", type = Date.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PD_DATE3", type = Date.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_MONEY1", type = Double.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_MONEY2", type = Double.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_MONEY3", type = Double.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_NUMBER1", type = Long.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_NUMBER2", type = Long.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_NUMBER3", type = Long.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_OUTPUT_STATUS",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_MESSAGE_CODE",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_PARAM1_CODE",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_PARAM2_CODE",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PN_WRKEV_SYSID",
            type = Long.class,
            mode = ParameterMode.OUT)
      }),
  @NamedStoredProcedureQuery(
      name = "wrk0896k.wrk0121d",
      procedureName = "wrk0896k.wrk0121d",
      resultClasses = {WorkEventOutput.class},
      parameters = {
        @StoredProcedureParameter(
            name = "PS_CNTXT_TABLE_ID",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_CNTXT_SYSID_N1",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_CNTXT_SYSID_N2",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_CNTXT_SYSID_V1",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_CNTXT_SYSID_V2",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PD_CNTXT_SYSID_D1",
            type = Date.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PD_CNTXT_SYSID_D2",
            type = Date.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_CALL_MDD_SHORT_NAME",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_CALL_MODLAB_NAME",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_ORACLE_USERID",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WET_NAME",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_WET_INTORG_PARTY_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_TRG_WRK_GRP_ID",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_TRG_WRK_GRP_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PD_WRKEV_DIARY_DATE",
            type = LocalDateTime.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WRKEV_NOTES",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_WSAC_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_WSA_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_COMM_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_TSTOUT_SYSID",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_AUTCON_AMT",
            type = Double.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WRKEV_STATUS",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PS_CHAR1", type = String.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PS_CHAR2", type = String.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PS_CHAR3", type = String.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PD_DATE1", type = Date.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PD_DATE2", type = Date.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PD_DATE3", type = Date.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_MONEY1", type = Double.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_MONEY2", type = Double.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_MONEY3", type = Double.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_NUMBER1", type = Long.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_NUMBER2", type = Long.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(name = "PN_NUMBER3", type = Long.class, mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_PRIORITY",
            type = Integer.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_SUPP_LET",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WSCH_CODE1",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_WST_RANK",
            type = Integer.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PD_WSA_ACT_DATE",
            type = Date.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WSCH_CODE2",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WSS_STATUS",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_WSS_REASON",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_STAND_CODE",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PD_COMM_PROC_DATE",
            type = Date.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_COMM_STATUS",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_BTCH_PRD",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_PRNTID_NAME",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_DATA_COLL",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_STAND_NOTES",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PN_COMM_SYSID1",
            type = Long.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_POPULATE",
            type = String.class,
            mode = ParameterMode.IN),
        @StoredProcedureParameter(
            name = "PS_OUTPUT_STATUS",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_MESSAGE_CODE",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_PARAM1",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PS_PARAM2",
            type = String.class,
            mode = ParameterMode.OUT),
        @StoredProcedureParameter(
            name = "PN_WSCHAS_SYSID",
            type = Long.class,
            mode = ParameterMode.OUT)
      })
})
public class WorkEventOutput implements Serializable {

  /** Serial Version number. */
  private static final long serialVersionUID = 1L;

  @Id private String outputStatus;
  private String messageCode;
  private String param1Code;
  private String param2Code;
  private Long workEventSysId;
}
