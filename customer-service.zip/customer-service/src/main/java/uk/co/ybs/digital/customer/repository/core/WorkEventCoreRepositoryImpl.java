package uk.co.ybs.digital.customer.repository.core;

import java.time.LocalDateTime;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import uk.co.ybs.digital.customer.config.persistence.CoreConfiguration;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventContextTableName;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventStatus;
import uk.co.ybs.digital.customer.model.core.WorkEventOutput;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public class WorkEventCoreRepositoryImpl implements WorkEventCoreRepositoryCustom {

  private static final long BLUE_TEAM_INTERNAL_ORGANISATION = 620523L;

  private static final String ADACUS_WORK_EVENT = "ADACUS";
  private static final String ADACUS_WORK_EVENT_NOTES = "CUS800";

  private static final String CHCAMO_WORK_EVENT = "CHCAMO";
  private static final String CHCAMO_MODULE_SHORT_NAME = "CUS0503U";
  private static final String CHCAMO_WORK_EVENT_NOTES = "Amended by customer on the App";

  // Qualifier won't work, so use PersistenceContext
  @PersistenceContext(unitName = CoreConfiguration.PERSISTENCE_UNIT)
  private transient EntityManager coreEntityManager;

  @Override
  public WorkEventOutput createAdacusWorkEvent(final Long partyId, final Long accountNumber) {

    StoredProcedureQuery proc =
        coreEntityManager.createNamedStoredProcedureQuery("wrk0480k.wrk0010d");

    proc.setParameter("PS_CNTXT_TABLE_ID", WorkEventContextTableName.SAVACC.toString());
    proc.setParameter("PN_CNTXT_SYSID_N1", accountNumber);
    proc.setParameter("PN_CNTXT_SYSID_N2", partyId);
    proc.setParameter("PS_WET_NAME", ADACUS_WORK_EVENT);
    proc.setParameter("PN_WET_INTORG_PARTY_SYSID", BLUE_TEAM_INTERNAL_ORGANISATION);
    proc.setParameter("PD_WRKEV_DIARY_DATE", LocalDateTime.now());
    proc.setParameter("PS_WRKEV_NOTES", ADACUS_WORK_EVENT_NOTES);
    proc.setParameter("PS_WRKEV_STATUS", WorkEventStatus.TODO.toString());

    final String outputStatus = (String) proc.getOutputParameterValue("PS_OUTPUT_STATUS");
    final String messageCode = (String) proc.getOutputParameterValue("PS_MESSAGE_CODE");
    final String param1Code = (String) proc.getOutputParameterValue("PS_PARAM1_CODE");
    final String param2Code = (String) proc.getOutputParameterValue("PS_PARAM2_CODE");
    final Long workEventSysId = (Long) proc.getOutputParameterValue("PN_WRKEV_SYSID");

    final WorkEventOutput workEvent =
        WorkEventOutput.builder()
            .outputStatus(outputStatus)
            .messageCode(messageCode)
            .param1Code(param1Code)
            .param2Code(param2Code)
            .workEventSysId(workEventSysId)
            .build();

    if ("F".equals(workEvent.getOutputStatus())) {
      throw new CustomerServiceException("Error creating ADACUS WorkEvent:" + workEvent);
    }

    return workEvent;
  }

  @Override
  public WorkEventOutput createChcamoWorkEvent(final Long accountNumber, final Long accountType) {

    StoredProcedureQuery proc =
        coreEntityManager.createNamedStoredProcedureQuery("wrk0896k.wrk0121d");

    proc.setParameter("PS_CNTXT_TABLE_ID", WorkEventContextTableName.LOANAC.toString());
    proc.setParameter("PN_CNTXT_SYSID_N1", accountNumber);
    proc.setParameter("PN_CNTXT_SYSID_N2", accountType);
    proc.setParameter("PS_CALL_MDD_SHORT_NAME", CHCAMO_MODULE_SHORT_NAME);
    proc.setParameter("PS_CALL_MODLAB_NAME", CHCAMO_WORK_EVENT);
    proc.setParameter("PS_WRKEV_NOTES", CHCAMO_WORK_EVENT_NOTES);

    // PN_WSCHAS_SYSID is not passed back from the procedure, so no need to set it
    final String outputStatus = (String) proc.getOutputParameterValue("PS_OUTPUT_STATUS");
    final String messageCode = (String) proc.getOutputParameterValue("PS_MESSAGE_CODE");
    final String param1Code = (String) proc.getOutputParameterValue("PS_PARAM1");
    final String param2Code = (String) proc.getOutputParameterValue("PS_PARAM2");

    final WorkEventOutput workEvent =
        WorkEventOutput.builder()
            .outputStatus(outputStatus)
            .messageCode(messageCode)
            .param1Code(param1Code)
            .param2Code(param2Code)
            .build();

    if ("F".equals(workEvent.getOutputStatus())) {
      throw new CustomerServiceException("Error creating CHCAMO WorkEvent:" + workEvent);
    }

    return workEvent;
  }
}
