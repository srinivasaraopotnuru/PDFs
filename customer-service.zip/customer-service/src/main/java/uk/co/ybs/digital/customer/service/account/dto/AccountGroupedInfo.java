package uk.co.ybs.digital.customer.service.account.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;
import lombok.Singular;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = AccountGroupedInfo.AccountGroupedInfoBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountGroupedInfo {

  AccountGroup owned;
  AccountGroup other;
  AccountGroup closed;

  @Value
  @Builder
  @JsonDeserialize(builder = AccountGroupedInfo.AccountGroup.AccountGroupBuilder.class)
  public static class AccountGroup {
    @Singular
    @JsonProperty(value = "account")
    List<AccountSummary> accounts;

    @JsonProperty(value = "balance")
    List<Balance> balances;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AccountGroupBuilder {}
  }

  @Value
  @Builder(toBuilder = true)
  @JsonDeserialize(builder = AccountGroupedInfo.AccountSummary.AccountSummaryBuilder.class)
  public static class AccountSummary {
    String accountNumber;
    String accountName;
    boolean amendmentRestriction;
    String accountSortCode;
    String accountType;
    String externalAccountNumber;
    String productIdentifier;
    String productDescription;
    String currency;

    @JsonProperty(value = "balance")
    List<Balance> balances;

    DepositsSummary deposits;
    WithdrawalsSummary withdrawals;
    Isa isa;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AccountSummaryBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = AccountGroupedInfo.Balance.BalanceBuilder.class)
  public static class Balance {
    String type;
    BigDecimal amount;

    @JsonPOJOBuilder(withPrefix = "")
    public static class BalanceBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = AccountGroupedInfo.DepositsSummary.DepositsSummaryBuilder.class)
  public static class DepositsSummary {
    boolean permittedOverApi;

    @JsonPOJOBuilder(withPrefix = "")
    public static class DepositsSummaryBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = AccountGroupedInfo.WithdrawalsSummary.WithdrawalsSummaryBuilder.class)
  public static class WithdrawalsSummary {
    boolean permittedOverApi;

    @JsonPOJOBuilder(withPrefix = "")
    public static class WithdrawalsSummaryBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = AccountGroupedInfo.Isa.IsaBuilder.class)
  public static class Isa {
    boolean flexible;
    boolean helpToBuy;
    boolean subscribed;

    @JsonPOJOBuilder(withPrefix = "")
    public static class IsaBuilder {}
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class AccountGroupedInfoBuilder {}
}
