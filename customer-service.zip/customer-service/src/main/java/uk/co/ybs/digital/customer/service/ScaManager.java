package uk.co.ybs.digital.customer.service;

import java.time.Duration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.customer.exception.ScaRequiredException;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationCheckRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationSuccessRequest;
import uk.co.ybs.digital.customer.web.dto.EmailAddress;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@Component
@RequiredArgsConstructor
@Slf4j
public class ScaManager {

  private static final Duration SCA_CHALLENGE_TIMEOUT = Duration.ofMinutes(1);

  private final ScaChallengeService scaChallengeService;
  private final AuditService auditService;

  public void validateUpdateEmailSca(
      final WorkLog.Operation operation,
      final EmailAddress emailRequest,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    validateSca(operation, emailRequest, EmailAddress.class, metadata, scaCredentials);
  }

  public void validateUpdatePhoneNumberSca(
      final WorkLog.Operation operation,
      final PhoneNumberRequest phoneNumberRequest,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    validateSca(operation, phoneNumberRequest, PhoneNumberRequest.class, metadata, scaCredentials);
  }

  public void validateUpdatePostalAddressSca(
      final WorkLog.Operation operation,
      final PostalAddressRequest postalAddressRequest,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    validateSca(
        operation, postalAddressRequest, PostalAddressRequest.class, metadata, scaCredentials);
  }

  private <T> void validateSca(
      final WorkLog.Operation operation,
      final T challengePayloadBody,
      final Class<T> payloadBodyClass,
      final RequestMetadata metadata,
      final ScaCredentials scaCredentials) {
    if (scaCredentials == null) {
      log.info("SCA required {}", operation);
      final String generatedChallenge =
          scaChallengeService.generateChallenge(
              challengePayloadBody, metadata.getSessionId(), SCA_CHALLENGE_TIMEOUT);

      AuditAuthenticationCheckRequest request =
          AuditAuthenticationCheckRequest.builder().ipAddress(metadata.getIpAddress()).build();
      if (operation.equals(WorkLog.Operation.POSTAL_ADDRESS)) {
        auditService.auditCustomerPostalAddressChallenge(request, metadata);
      } else {
        auditService.auditCustomerNonPostalAddressChallenge(request, metadata);
      }

      throw new ScaRequiredException(generatedChallenge);
    }

    log.info("Validating SCA  {}", operation);
    try {
      scaChallengeService.validateChallenge(
          scaCredentials, challengePayloadBody, payloadBodyClass, metadata.getSessionId());
      AuditAuthenticationSuccessRequest request =
          AuditAuthenticationSuccessRequest.builder().ipAddress(metadata.getIpAddress()).build();
      if (operation.equals(WorkLog.Operation.POSTAL_ADDRESS)) {
        auditService.auditCustomerPostalAddressChallengeSuccess(request, metadata);
      } else {
        auditService.auditCustomerNonPostalAddressChallengeSuccess(request, metadata);
      }

    } catch (final InvalidScaException exception) {

      AuditAuthenticationFailureRequest request =
          AuditAuthenticationFailureRequest.builder()
              .ipAddress(metadata.getIpAddress())
              .message("Invalid Challenge Response")
              .build();
      if (operation.equals(WorkLog.Operation.POSTAL_ADDRESS)) {
        auditService.auditCustomerPostalAddressChallengeFailure(request, metadata);
      } else {
        auditService.auditCustomerNonPostalAddressChallengeFailure(request, metadata);
      }
      throw exception;
    }
  }
}
