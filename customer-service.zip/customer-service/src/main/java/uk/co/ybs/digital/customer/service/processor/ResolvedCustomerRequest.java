package uk.co.ybs.digital.customer.service.processor;

public interface ResolvedCustomerRequest {
  void execute();

  void auditSuccess();

  void auditFailure(String message);
}
