package uk.co.ybs.digital.customer.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(
    builder = AuditCustomerDetailsViewRequest.AuditCustomerDetailsViewRequestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditCustomerDetailsViewRequest {
  @NonNull String ipAddress;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditCustomerDetailsViewRequestBuilder {}
}
