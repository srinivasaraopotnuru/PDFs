package uk.co.ybs.digital.customer.service.apply;

import io.micrometer.core.annotation.Timed;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.customer.service.account.AccountServiceException;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationsResponsePrivate;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class ApplyService {

  private final WebClient applyServiceWebClient;

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling apply service";
  private static final String EMPTY_RESPONSE_ERROR_MESSAGE = "Empty response calling apply service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Apply service returned error status: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  public ApplicationsResponsePrivate getApplicationsPrivate(final RequestMetadata requestMetadata) {
    return get(requestMetadata, ApplicationsResponsePrivate.class, "/private/");
  }

  private <T> T get(final RequestMetadata metadata, final Class<T> responseType, final String uri) {
    return applyServiceWebClient
        .get()
        .uri(uri)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + metadata.getForwardingAuth())
        .header(HttpHeaders.ACCEPT, "application/json")
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HEADER_BRAND_CODE, metadata.getBrandCode())
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .bodyToMono(responseType)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new ApplyServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new ApplyServiceException(EMPTY_RESPONSE_ERROR_MESSAGE));
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AccountServiceException);
  }

  private Mono<ApplyServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new ApplyServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new ApplyServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new ApplyServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
