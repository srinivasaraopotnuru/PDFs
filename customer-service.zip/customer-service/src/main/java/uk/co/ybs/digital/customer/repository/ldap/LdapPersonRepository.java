package uk.co.ybs.digital.customer.repository.ldap;

import java.util.Optional;
import org.springframework.data.ldap.repository.LdapRepository;
import uk.co.ybs.digital.customer.model.ldap.LdapPerson;

public interface LdapPersonRepository extends LdapRepository<LdapPerson> {
  Optional<LdapPerson> findByUid(String uid);
}
