package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class ApplicationsResponsePrivate {

  @ApiModelProperty(value = "The user's applications", required = true)
  private List<ApplicationResponsePrivate> applications;

  @ApiModelProperty(
      value =
          "The total number of applications for this user. This may be greater than the limited number returned in the"
              + " applications field.",
      required = true)
  private int totalApplications;
}
