package uk.co.ybs.digital.customer.service.audit.dto;

public enum NonPostalType {
  HOME,
  WORK,
  MOBILE,
  EMAIL
}
