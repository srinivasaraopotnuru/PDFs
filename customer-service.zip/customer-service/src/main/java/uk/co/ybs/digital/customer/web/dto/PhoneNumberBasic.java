package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.customer.web.NonEmptyString;
import uk.co.ybs.digital.customer.web.validators.ValidPhoneNumberBasic;

@Value
@Builder
@Jacksonized
@ValidPhoneNumberBasic
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PhoneNumberBasic {

  @ApiModelProperty(required = true, example = "HOME")
  @NotNull(message = "You must specify a phone number type")
  @EqualsAndHashCode.Include
  PhoneNumberBasicType type;

  @ApiModelProperty(example = "012744207138")
  @NonEmptyString(
      message = "Phone number if present must contain at least one non-whitespace character")
  String number;

  public enum PhoneNumberBasicType {
    HOME,
    MOBILE,
    WORK
  }
}
