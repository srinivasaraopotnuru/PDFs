package uk.co.ybs.digital.customer.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum CustomerValidationExceptionReason {
  MIN_PHONE_NUMBERS("Customer must have at least one telephone number"),
  NO_CHANGES_DETECTED("No changes detected");

  private final String description;
}
