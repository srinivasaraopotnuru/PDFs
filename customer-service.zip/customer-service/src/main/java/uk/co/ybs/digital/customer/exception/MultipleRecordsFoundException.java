package uk.co.ybs.digital.customer.exception;

public class MultipleRecordsFoundException extends CustomerServiceException {

  private static final long serialVersionUID = -4041446587879507461L;

  public MultipleRecordsFoundException(final String message) {
    super(message, null);
  }

  public MultipleRecordsFoundException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
