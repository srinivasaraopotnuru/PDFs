package uk.co.ybs.digital.customer.service.audit;

import io.micrometer.core.annotation.Timed;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationCheckRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditCustomerDetailsViewRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class AuditService {

  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling audit service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Audit service returned error status: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private final WebClient auditServiceWebClient;

  public void auditCustomerDetailsView(
      final AuditCustomerDetailsViewRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/view", request, requestMetadata);
  }

  public void auditNonPostalAddressUpdateSuccess(
      final AuditNonPostalAddressUpdateSuccessRequest request,
      final RequestMetadata requestMetadata) {
    postAudit("/customer/non-postal/update/success", request, requestMetadata);
  }

  public void auditNonPostalAddressUpdateFailure(
      final AuditNonPostalAddressUpdateFailureRequest request,
      final RequestMetadata requestMetadata) {
    postAudit("/customer/non-postal/update/failure", request, requestMetadata);
  }

  public void auditCustomerNonPostalAddressChallenge(
      final AuditAuthenticationCheckRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/non-postal/authentication/check", request, requestMetadata);
  }

  public void auditCustomerNonPostalAddressChallengeSuccess(
      final AuditAuthenticationSuccessRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/non-postal/authentication/success", request, requestMetadata);
  }

  public void auditCustomerNonPostalAddressChallengeFailure(
      final AuditAuthenticationFailureRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/non-postal/authentication/failure", request, requestMetadata);
  }

  public void auditPostalAddressUpdateSuccess(
      final AuditPostalAddressUpdateSuccessRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/postal-address/update/success", request, requestMetadata);
  }

  public void auditPostalAddressUpdateFailure(
      final AuditPostalAddressUpdateFailureRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/postal-address/update/failure", request, requestMetadata);
  }

  public void auditCustomerPostalAddressChallenge(
      final AuditAuthenticationCheckRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/postal-address/authentication/check", request, requestMetadata);
  }

  public void auditCustomerPostalAddressChallengeSuccess(
      final AuditAuthenticationSuccessRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/postal-address/authentication/success", request, requestMetadata);
  }

  public void auditCustomerPostalAddressChallengeFailure(
      final AuditAuthenticationFailureRequest request, final RequestMetadata requestMetadata) {
    postAudit("/customer/postal-address/authentication/failure", request, requestMetadata);
  }

  private void postAudit(
      final String uri, final Object requestPayload, final RequestMetadata requestMetadata) {
    auditServiceWebClient
        .post()
        .uri(uri)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + requestMetadata.getForwardingAuth())
        .header(REQUEST_ID_HEADER, requestMetadata.getRequestId().toString())
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(requestPayload)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .toBodilessEntity()
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AuditServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .block();
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AuditServiceException);
  }

  private Mono<AuditServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new AuditServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
