package uk.co.ybs.digital.customer.exception;

public class CustomerNotFoundException extends CustomerServiceException {

  private static final long serialVersionUID = 3476667965007935960L;

  public CustomerNotFoundException(final String message) {
    super(message, null);
  }

  public CustomerNotFoundException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
