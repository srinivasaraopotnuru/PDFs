package uk.co.ybs.digital.customer.service.mapping;

import java.util.concurrent.atomic.AtomicReference;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;

@Component
@Slf4j
@RequiredArgsConstructor
public class AddressChangeMapper {

  public AddressChange map(final PostalAddressRequest postalAddressRequest) {

    AddressChange.AddressChangeBuilder addressChangeBuilder = AddressChange.builder();

    AtomicReference<Integer> addressLineCount = new AtomicReference<>(0);
    postalAddressRequest
        .getAddress()
        .getAddressLines()
        .forEach(
            addressLine -> {
              addressLineCount.getAndSet(addressLineCount.get() + 1);
              if ("1".equals(String.valueOf(addressLineCount))) {
                addressChangeBuilder.addressLine1(addressLine);
              } else if ("2".equals(String.valueOf(addressLineCount))) {
                addressChangeBuilder.addressLine2(addressLine);
              } else if ("3".equals(String.valueOf(addressLineCount))) {
                addressChangeBuilder.addressLine3(addressLine);
              } else if ("4".equals(String.valueOf(addressLineCount))) {
                addressChangeBuilder.addressLine4(addressLine);
              }
            });

    addressChangeBuilder.country(postalAddressRequest.getAddress().getCountry().getCode());
    addressChangeBuilder.postCode(postalAddressRequest.getAddress().getPostCode());

    if (postalAddressRequest.getPaf() != null) {
      addressChangeBuilder.pafKey(postalAddressRequest.getPaf().getAddressKey().toString());
      addressChangeBuilder.pafDeliveryPrefix(
          StringUtils.left(postalAddressRequest.getPaf().getDeliveryPointSuffix(), 2));
    }

    return addressChangeBuilder.build();
  }
}
