package uk.co.ybs.digital.customer.service.audit;

import java.net.URL;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

@ConfigurationProperties(prefix = "uk.co.ybs.digital.audit")
@ConstructorBinding
@AllArgsConstructor
@Getter
public class AuditServiceProperties {
  @NonNull private final URL url;
}
