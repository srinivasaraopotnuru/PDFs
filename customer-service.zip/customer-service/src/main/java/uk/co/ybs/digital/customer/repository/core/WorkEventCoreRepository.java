package uk.co.ybs.digital.customer.repository.core;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.core.WorkEvent.ModuleLabelAssociationType;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventContextTableName;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventStatus;
import uk.co.ybs.digital.customer.model.core.WorkEventOutput;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
@SuppressWarnings("PMD.ExcessiveParameterList")
public interface WorkEventCoreRepository
    extends JpaRepository<WorkEventOutput, Long>, WorkEventCoreRepositoryCustom {

  @Query(
      value =
          "SELECT wrkev.sysid"
              + "  FROM work_events wrkev"
              + " WHERE wrkev.cntxt_table_id = :#{#contextTableName.name()}"
              + "   AND cntxt_sysid1 = :contextId1"
              + "   AND wrkev.cntxt_sysid2 = :contextId2"
              + "   AND wrkev.status in :#{#status.![name()]}" // SpEL expression required
              + "   AND EXISTS"
              + "       (SELECT 1"
              + "          FROM module_label_associations mla"
              + "         WHERE :now BETWEEN TRUNC(mla.start_date) AND"
              + "               COALESCE(TRUNC(mla.end_date), :now)"
              + "           AND mla.mla_type = :#{#moduleLabelAssociationType.name()}"
              + "           AND mla.modlab_name = :moduleLabelName"
              + "           AND mla.modlab_mdd_sysid IN"
              + "               (SELECT mdd.sysid"
              + "                  FROM module_details mdd"
              + "                 WHERE mdd.short_name = :moduleDetailsShortname)"
              + "                   AND mla.wet_intorg_party_sysid = wrkev.wet_intorg_party_sysid"
              + "                   AND mla.wet_name = wrkev.wet_name)",
      nativeQuery = true)
  List<Long> findWorkEvents(
      WorkEventContextTableName contextTableName,
      Long contextId1,
      Long contextId2,
      Set<WorkEventStatus> status,
      ModuleLabelAssociationType moduleLabelAssociationType,
      String moduleLabelName,
      String moduleDetailsShortname,
      LocalDateTime now);
}
