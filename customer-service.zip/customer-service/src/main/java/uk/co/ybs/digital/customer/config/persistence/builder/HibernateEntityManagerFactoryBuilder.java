package uk.co.ybs.digital.customer.config.persistence.builder;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.sql.DataSource;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.With;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateProperties;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateSettings;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

@With
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class HibernateEntityManagerFactoryBuilder {
  private String persistenceUnitName;
  private String[] packagesToScan;
  private DataSource dataSource;
  private JpaProperties jpaProperties;
  private HibernateProperties hibernateProperties;

  public LocalContainerEntityManagerFactoryBean build() {
    Objects.requireNonNull(persistenceUnitName, "persistenceUnitName required");
    Objects.requireNonNull(packagesToScan, "packagesToScan required");
    Objects.requireNonNull(dataSource, "dataSource required");
    Objects.requireNonNull(jpaProperties, "jpaProperties required");
    Objects.requireNonNull(hibernateProperties, "hibernateProperties required");

    final JpaVendorAdapter jpaVendorAdapter = getJpaVendorAdapter(jpaProperties);
    final Map<String, Object> vendorProperties =
        getVendorProperties(jpaProperties, hibernateProperties);

    return new EntityManagerFactoryBuilder(jpaVendorAdapter, jpaProperties.getProperties(), null)
        .dataSource(dataSource)
        .persistenceUnit(persistenceUnitName)
        .packages(packagesToScan)
        .properties(vendorProperties)
        .mappingResources(getMappingResources(jpaProperties))
        .build();
  }

  private JpaVendorAdapter getJpaVendorAdapter(final JpaProperties jpaProperties) {
    final HibernateJpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
    Optional.ofNullable(jpaProperties.getDatabase()).ifPresent(jpaVendorAdapter::setDatabase);
    Optional.ofNullable(jpaProperties.getDatabasePlatform())
        .ifPresent(jpaVendorAdapter::setDatabasePlatform);
    Optional.ofNullable(jpaProperties.getDatabase()).ifPresent(jpaVendorAdapter::setDatabase);
    jpaVendorAdapter.setGenerateDdl(jpaProperties.isGenerateDdl());
    jpaVendorAdapter.setShowSql(jpaProperties.isShowSql());

    return jpaVendorAdapter;
  }

  private Map<String, Object> getVendorProperties(
      final JpaProperties jpaProperties, final HibernateProperties hibernateProperties) {
    return new LinkedHashMap<>(
        hibernateProperties.determineHibernateProperties(
            jpaProperties.getProperties(), new HibernateSettings()));
  }

  @SuppressWarnings("PMD.NullAssignment")
  private String[] getMappingResources(final JpaProperties jpaProperties) {
    List<String> mappingResources = jpaProperties.getMappingResources();
    return (!ObjectUtils.isEmpty(mappingResources)
        ? StringUtils.toStringArray(mappingResources)
        : null);
  }
}
