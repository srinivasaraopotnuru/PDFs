package uk.co.ybs.digital.customer.service.product;

import java.net.URL;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

@ConfigurationProperties(prefix = "uk.co.ybs.digital.product")
@ConstructorBinding
@AllArgsConstructor
@Getter
public class ProductServiceProperties {
  @NonNull private final URL url;
}
