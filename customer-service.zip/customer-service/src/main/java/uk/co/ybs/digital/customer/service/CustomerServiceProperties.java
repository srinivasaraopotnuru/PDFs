package uk.co.ybs.digital.customer.service;

import java.util.List;
import lombok.Value;
import lombok.experimental.NonFinal;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.validation.annotation.Validated;

@Value
@NonFinal
@ConstructorBinding
@ConfigurationProperties(prefix = "uk.co.ybs.digital.customer")
@Validated
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class CustomerServiceProperties {

  // Represents a list of parties to not create phone number requests for.
  // Used by smoke/e2e tests
  List<String> partyBlacklist;
}
