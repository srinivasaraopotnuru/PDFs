package uk.co.ybs.digital.customer.web;

import static uk.co.ybs.digital.customer.web.dto.ErrorResponse.ErrorItem;

import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.customer.exception.AddressNotPermittedException;
import uk.co.ybs.digital.customer.exception.AmendmentRestrictionException;
import uk.co.ybs.digital.customer.exception.BadFailureRequestChallengeException;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerValidationException;
import uk.co.ybs.digital.customer.exception.CustomerValidationExceptionReason;
import uk.co.ybs.digital.customer.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.customer.exception.MultipleRecordsFoundException;
import uk.co.ybs.digital.customer.exception.ScaRequiredException;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.sca.exception.InvalidPemKeyException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;

@ControllerAdvice
@Slf4j
public class CustomerServiceExceptionHandler {

  @ExceptionHandler(RuntimeException.class)
  public ResponseEntity<ErrorResponse> handleUnexpectedException(
      final RuntimeException exception, final WebRequest request) {
    log.error(
        "Unhandled unexpected exception, returning 500 Internal Server Error: {}",
        exception.toString(),
        exception);

    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Internal Server Error")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.UNEXPECTED_ERROR)
                    .message("Internal Server Error")
                    .build())
            .build();
    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(AccessDeniedException.class)
  public void handleInvalidJwtScope(final AccessDeniedException exception) {
    // Let spring security handle it.
    throw exception;
  }

  @ExceptionHandler(CustomerNotFoundException.class)
  public ResponseEntity<ErrorResponse> handleCustomerNotFoundException(
      final CustomerNotFoundException exception, final WebRequest webRequest) {
    log.info(
        "Handled CustomerNotFoundException, returning 404 Not Found: {}", exception.toString());

    final HttpStatus status = HttpStatus.NOT_FOUND;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(webRequest))
            .message("Resource not found")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.RESOURCE_NOT_FOUND)
                    .message("Resource not found")
                    .build())
            .build();
    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(MultipleRecordsFoundException.class)
  public ResponseEntity<ErrorResponse> handleMultipleCustomersFoundException(
      final MultipleRecordsFoundException exception, final WebRequest webRequest) {
    log.info(
        "Handled MultipleCustomersFoundException, returning 409 Conflict Request: {}",
        exception.toString());

    final HttpStatus status = HttpStatus.CONFLICT;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(webRequest))
            .message("Multiple records found")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.MULTIPLE_RECORDS_NOT_FOUND)
                    .message("Multiple records found")
                    .build())
            .build();
    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(InvalidScaHeadersException.class)
  public ResponseEntity<ErrorResponse> handleInvalidScaHeadersException(
      final InvalidScaHeadersException exception, final WebRequest request) {
    log.info(
        "Handling InvalidScaHeadersException, returning 400 Bad Request: {}", exception.toString());

    final List<ErrorItem> errors =
        exception.getMissingHeaders().stream()
            .map(
                header ->
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.HEADER_MISSING)
                        .message(String.format("Required SCA header missing: %s", header))
                        .path(header)
                        .build())
            .collect(Collectors.toList());

    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(RequestIdHelper.getRequestId(request))
            .message(
                String.format(
                    "Required SCA header missing - Required SCA headers: %s",
                    exception.getRequiredHeaders()))
            .errors(errors)
            .build();

    return ResponseEntity.badRequest().body(response);
  }

  @ExceptionHandler(InvalidPemKeyException.class)
  public ResponseEntity<ErrorResponse> handleInvalidPemKeyException(
      final InvalidPemKeyException exception, final WebRequest request) {
    log.info(
        "Handling InvalidPemKeyException, returning 400 Bad Request: {}", exception.toString());

    final HttpStatus badRequestStatusCode = HttpStatus.BAD_REQUEST;
    return ResponseEntity.status(badRequestStatusCode)
        .body(
            ErrorResponse.builder(badRequestStatusCode)
                .id(RequestIdHelper.getRequestId(request))
                .message("SCA key could not be read")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.HEADER_INVALID)
                        .message("SCA key must be in PEM format and Base64 encoded")
                        .path("x-ybs-sca-key")
                        .build())
                .build());
  }

  @ExceptionHandler(ScaRequiredException.class)
  public ResponseEntity<ErrorResponse> handleScaRequiredException(
      final ScaRequiredException exception, final WebRequest request) {
    log.info("Handling ScaRequiredException, returning 403 Forbidden: {}", exception.toString());

    final String challenge = exception.getChallenge();
    final HttpStatus status = HttpStatus.FORBIDDEN;
    return ResponseEntity.status(status)
        .header("x-ybs-sca-challenge", challenge)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .message("Strong customer authentication required")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.SCA_REQUIRED)
                        .message(
                            "Please sign the value in x-ybs-sca-challenge header with the request")
                        .build())
                .build());
  }

  @ExceptionHandler(InvalidScaException.class)
  public ResponseEntity<ErrorResponse> handleInvalidScaException(
      final InvalidScaException exception, final WebRequest request) {
    log.info("Handling InvalidScaException, returning 403 Forbidden: {}", exception.toString());

    final HttpStatus status = HttpStatus.FORBIDDEN;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.ACCESS_DENIED)
                        .message("Access Denied")
                        .build())
                .build());
  }

  @ExceptionHandler(AmendmentRestrictionException.class)
  public ResponseEntity<ErrorResponse> handleAmendmentRestrictionException(
      final AmendmentRestrictionException exception, final WebRequest request) {
    log.info(
        "Handling AmendmentRestrictionException, returning 403 Forbidden: {}",
        exception.toString());

    final HttpStatus status = HttpStatus.FORBIDDEN;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .message("Contact details amendments are not allowed for this account")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.FORBIDDEN)
                        .message("Forbidden")
                        .build())
                .build());
  }

  @ExceptionHandler(AddressNotPermittedException.class)
  public ResponseEntity<ErrorResponse> handleAddressNotPermittedException(
      final AddressNotPermittedException exception, final WebRequest request) {
    log.info(
        "Handling AddressNotPermittedException, returning 400 Bad Request: {}",
        exception.toString());

    final HttpStatus status = HttpStatus.BAD_REQUEST;
    return ResponseEntity.status(status)
        .body(
            ErrorResponse.builder(status)
                .id(RequestIdHelper.getRequestId(request))
                .message("Invalid request body")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorItem.FIELD_INVALID)
                        .message("PO BOX, Care of & company addresses are not valid")
                        .path("address.addressLines[0]")
                        .build())
                .build());
  }

  @ExceptionHandler(CustomerValidationException.class)
  public ResponseEntity<ErrorResponse> handleCustomerValidationException(
      final CustomerValidationException exception, final WebRequest request) {

    final HttpStatus status =
        exception.getReason() == CustomerValidationExceptionReason.NO_CHANGES_DETECTED
            ? HttpStatus.CONFLICT
            : HttpStatus.BAD_REQUEST;
    log.info("Handling CustomerValidationException, returning {} {}", status, exception.toString());

    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Customer validation error")
            .error(
                Optional.ofNullable(
                        INVALID_CUSTOMER_REASON_TO_ERROR_ITEM_MAPPER.get(exception.getReason()))
                    .orElseThrow(
                        () ->
                            new IllegalArgumentException(
                                "Don't know how to map reason to ErrorItem: "
                                    + exception.getReason())))
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(BadFailureRequestChallengeException.class)
  public ResponseEntity<ErrorResponse> handleBadFailureRequestChallenge(
      final BadFailureRequestChallengeException exception, final WebRequest request) {
    log.info("Handling BadFailureRequestChallenge, returning 403 Forbidden");
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.FIELD_INVALID)
                    .message("Authenticity of the challenge could not be validated")
                    .build())
            .build();

    return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
  }

  private static final ImmutableMap<CustomerValidationExceptionReason, ErrorItem>
      INVALID_CUSTOMER_REASON_TO_ERROR_ITEM_MAPPER =
          ImmutableMap.<CustomerValidationExceptionReason, ErrorItem>builder()
              .put(
                  CustomerValidationExceptionReason.NO_CHANGES_DETECTED,
                  ErrorItem.builder()
                      .errorCode(ErrorItem.NO_CHANGES_DETECTED)
                      .message("No changes to the contact details have been detected")
                      .build())
              .put(
                  CustomerValidationExceptionReason.MIN_PHONE_NUMBERS,
                  ErrorItem.builder()
                      .errorCode(ErrorItem.MIN_PHONE_NUMBER)
                      .message("Unable to remove phone number as customer must have at least one")
                      .build())
              .build();
}
