package uk.co.ybs.digital.customer.model.core;

import java.time.LocalDateTime;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.Singular;

@Entity
@Table(name = "PARTIES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Party {

  @Id
  @Column(name = "SYSID")
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Singular
  @OneToMany(
      targetEntity = AddressUsage.class,
      mappedBy = "party",
      cascade = {CascadeType.PERSIST, CascadeType.MERGE})
  @NonNull
  private List<AddressUsage> addresses;

  @ManyToOne
  @JoinColumn(name = "PTYTYP_CODE")
  private PartyType partyType;

  @OneToOne(mappedBy = "party")
  private Person person;
}
