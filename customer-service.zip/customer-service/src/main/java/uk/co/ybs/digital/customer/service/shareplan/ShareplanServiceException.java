package uk.co.ybs.digital.customer.service.shareplan;

public class ShareplanServiceException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public ShareplanServiceException(final String message) {
    super(message);
  }

  public ShareplanServiceException(final String message, final Throwable exception) {
    super(message, exception);
  }
}
