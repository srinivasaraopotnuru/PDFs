package uk.co.ybs.digital.customer.repository.frontoffice;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange.AddressChangePk;

public interface AddressChangeRepository extends JpaRepository<AddressChange, AddressChangePk> {

  @Query(
      "SELECT distinct(ac.partySysId) "
          + "FROM AddressChange ac "
          + "WHERE ac.partySysId IN :parties "
          + "AND ac.amendDate >= :earliest ")
  Set<String> findAllChangesForPartiesAfterEarliestTime(
      @Param("parties") Collection<String> parties, @Param("earliest") LocalDateTime earliest);

  @Query(
      value =
          "SELECT ac "
              + "FROM AddressChange ac "
              + "WHERE ac.partySysId = :party "
              + "AND ac.amendDate >= :earliest "
              + "AND ac.amendDate = (SELECT MAX(ac2.amendDate) FROM AddressChange ac2 "
              + "WHERE ac2.partySysId = ac.partySysId)")
  Optional<AddressChange> findLatestChangeForPartyAfterEarliestTime(
      String party, LocalDateTime earliest);
}
