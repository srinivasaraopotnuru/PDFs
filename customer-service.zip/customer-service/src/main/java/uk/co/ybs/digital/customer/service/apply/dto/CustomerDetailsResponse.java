package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import java.util.List;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;
import lombok.experimental.SuperBuilder;
import org.springframework.format.annotation.DateTimeFormat;
import uk.co.ybs.digital.customer.service.apply.dto.PhoneNumber.HomePhoneNumber;
import uk.co.ybs.digital.customer.service.apply.dto.PhoneNumber.MobilePhoneNumber;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
public class CustomerDetailsResponse {

  @NotNull
  @ApiModelProperty(example = "true", required = true, value = "Indicator for primary applicant.")
  private Boolean primary;

  @NotNull
  @ApiModelProperty(example = "1974-12-20", required = true, value = "Customers date of birth.")
  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
  private LocalDate dob;

  @NotNull
  @ApiModelProperty(example = "MR", required = true, value = "Customers title.")
  private String title;

  @NotNull
  @ApiModelProperty(example = "John", required = true, value = "Customers first name.")
  private String firstNames;

  @NotNull
  @ApiModelProperty(example = "Smith", required = true, value = "Customers last name.")
  private String lastName;

  @NotNull
  @ApiModelProperty(example = "BRIT", required = true, value = "Customers nationality code.")
  private String nationalityCode;

  @NotNull
  @Email
  @ApiModelProperty(example = "johnsmith@email.com", required = true, value = "Customers email.")
  private String email;

  @ApiModelProperty(example = "01234567890", required = false, value = "Home phone number.")
  private HomePhoneNumber homePhone;

  @ApiModelProperty(example = "07890123456", required = false, value = "Mobile number.")
  private MobilePhoneNumber mobilePhone;

  @NotNull(message = "Please specify marketing preferences")
  @ApiModelProperty(required = true, value = "Customers marketing preferences.")
  private MarketingPreferences marketingPreferences;

  @ApiModelProperty(value = "Is Customer web enabled.")
  private boolean webEnabled;

  @NotNull
  @ApiModelProperty(required = true, value = "Customers current address.")
  private CurrentAddress currentAddress;

  @ApiModelProperty(value = "Customers previous address.")
  @Singular
  private List<PreviousAddress> previousAddresses;

  @ApiModelProperty(
      required = false,
      value = "Tax Details, required if fatcaoperatable product is supplied")
  private TaxDetails taxDetails;

  @ApiModelProperty(required = false, value = "Identification overall result")
  private Identification identification;
}
