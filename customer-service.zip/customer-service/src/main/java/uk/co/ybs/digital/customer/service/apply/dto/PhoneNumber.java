package uk.co.ybs.digital.customer.service.apply.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

@Data
@Builder
@Validated
@AllArgsConstructor
public class PhoneNumber {

  /**
   * Create new phone number.
   *
   * @param type The type of number.
   */
  public PhoneNumber(final PhoneType type) {
    this.type = type;
  }

  public enum PhoneType {
    HOME,
    MOBILE;
  }

  @JsonIgnore private PhoneType type;
  private String areaCode;
  private String localNumber;

  /**
   * Gets the full phone number.
   *
   * @return Phone Number.
   */
  @JsonIgnore
  public String getNumber() {
    return areaCode + localNumber;
  }

  public static class HomePhoneNumber extends PhoneNumber {

    /** Create a PhoneNumber of type: PhoneType.HOME. */
    public HomePhoneNumber() {
      super(PhoneType.HOME);
    }

    /**
     * Create a PhoneNumber of type: PhoneType.HOME with all params.
     *
     * @param areaCode The area code.
     * @param localNumber The local number.
     */
    @Builder(builderMethodName = "homePhoneBuilder")
    public HomePhoneNumber(final String areaCode, final String localNumber) {
      super(PhoneType.HOME, areaCode, localNumber);
    }
  }

  public static class MobilePhoneNumber extends PhoneNumber {

    /** Create a PhoneNumber of type: PhoneType.MOBILE. */
    public MobilePhoneNumber() {
      super(PhoneType.MOBILE);
    }

    /**
     * Create a PhoneNumber of type: PhoneType.MOBILE.
     *
     * @param areaCode The area code.
     * @param localNumber The local number.
     */
    @Builder(builderMethodName = "mobilePhoneBuilder")
    public MobilePhoneNumber(final String areaCode, final String localNumber) {
      super(PhoneType.MOBILE, areaCode, localNumber);
    }
  }
}
