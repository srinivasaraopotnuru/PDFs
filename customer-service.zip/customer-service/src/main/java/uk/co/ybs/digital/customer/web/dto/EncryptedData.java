package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class EncryptedData {

  @NotNull(message = "Please specify a keyId")
  @ApiModelProperty(
      example = "clientx-key-1",
      required = true,
      value = "The id of the key-pair used to encrypt the data.")
  private String keyId;

  @NotNull(message = "Please specify a data")
  @ApiModelProperty(
      example = "TMxSSH2YjTnE43lPg7Tq1WuDu1nVQ==",
      required = true,
      value = "Customers encrypted data.")
  private String data;
}
