package uk.co.ybs.digital.customer.config;

import lombok.AllArgsConstructor;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.customer.service.account.AccountServiceProperties;
import uk.co.ybs.digital.customer.service.apply.ApplyServiceProperties;
import uk.co.ybs.digital.customer.service.audit.AuditServiceProperties;
import uk.co.ybs.digital.customer.service.product.ProductServiceProperties;
import uk.co.ybs.digital.customer.service.shareplan.ShareplanServiceProperties;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnectorFactory;

@Configuration
@EnableConfigurationProperties({
  AuditServiceProperties.class,
  AccountServiceProperties.class,
  ProductServiceProperties.class,
  ShareplanServiceProperties.class,
  ApplyServiceProperties.class
})
@AllArgsConstructor
public class ServiceToServiceConfig {

  private final AuditServiceProperties auditServiceProperties;
  private final AccountServiceProperties accountServiceProperties;
  private final ShareplanServiceProperties spServiceProperties;
  private final ProductServiceProperties productServiceProperties;
  private final ApplyServiceProperties applyServiceProperties;

  @Bean
  public WebClient auditServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(auditServiceProperties.getUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }

  @Bean
  public WebClient accountServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(accountServiceProperties.getUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }

  @Bean
  public WebClient sharePlanServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(spServiceProperties.getUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }

  @Bean
  public WebClient productServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(productServiceProperties.getUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }

  @Bean
  public WebClient applyServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(applyServiceProperties.getUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }
}
