package uk.co.ybs.digital.customer.repository.adgcore;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn.MarketingOptInCode;

public interface MarketingOptInRepository extends JpaRepository<MarketingOptIn, Long> {

  default List<MarketingOptIn> findMarketingOptInByParty(
      final Long partyId, final LocalDateTime now) {
    return findMarketingOptInByPartyAndCodes(
        partyId,
        EnumSet.of(
            MarketingOptInCode.ADDR,
            MarketingOptInCode.EMAIL,
            MarketingOptInCode.TEL,
            MarketingOptInCode.AGMEML),
        now);
  }

  @Query(
      "FROM MarketingOptIn "
          + "WHERE partyId = :partyId "
          + "  AND startDate <= :now "
          + "  AND (endDate is null OR endDate > :now) "
          + "  AND code in :codes")
  List<MarketingOptIn> findMarketingOptInByPartyAndCodes(
      Long partyId, Set<MarketingOptInCode> codes, LocalDateTime now);
}
