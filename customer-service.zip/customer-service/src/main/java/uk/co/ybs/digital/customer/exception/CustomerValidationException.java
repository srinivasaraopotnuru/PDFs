package uk.co.ybs.digital.customer.exception;

import lombok.Getter;
import lombok.NonNull;

@Getter
public class CustomerValidationException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  private final CustomerValidationExceptionReason reason;

  public CustomerValidationException(
      @NonNull final String message, @NonNull final CustomerValidationExceptionReason reason) {
    this(message, reason, null);
  }

  public CustomerValidationException(
      @NonNull final String message,
      @NonNull final CustomerValidationExceptionReason reason,
      final Throwable cause) {
    super(message, cause);
    this.reason = reason;
  }
}
