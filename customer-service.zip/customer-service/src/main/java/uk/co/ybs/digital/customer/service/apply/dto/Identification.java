package uk.co.ybs.digital.customer.service.apply.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Data Model for Identification Response. */
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class Identification {

  public enum IdentityDecision {
    AUTHENTICATED,
    NOT_AUTHENTICATED,
    REFERRED;
  }

  private OverallResult overallResult;

  @ApiModelProperty(value = "Overall Reference")
  @ApiParam(hidden = true)
  private String reference;

  @ApiModelProperty(value = "Overall Score")
  @ApiParam(hidden = true)
  private String score;

  @ApiModelProperty(value = "Identity Check result (Experian)")
  @ApiParam(hidden = true)
  private IdentityResult identity;

  @ApiModelProperty(value = "Fraud Check result (CIFAS)")
  @ApiParam(hidden = true)
  private Result fraud;

  @ApiModelProperty(value = "SANPEP Check result (NICE Actimize)")
  @ApiParam(hidden = true)
  private Result sanpep;

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  public static class OverallResult {
    @ApiModelProperty(value = "Overall Decision for the Customer")
    private Decision decision;

    @ApiModelProperty(value = "Is the customer allowed to make deposits")
    private boolean depositAllowed;

    @ApiModelProperty(value = "Identitiy required before account can be opened")
    private RequiredId requiredId;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  public static class RequiredId {
    @ApiModelProperty(value = "Identitiy proving the cusotmer's name")
    private int name;

    @ApiModelProperty(value = "Identitiy proving the cusotmer's address")
    private int address;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  public static class Result {
    @ApiModelProperty(value = "If the service responded and didn't return a fault")
    private boolean responded;

    @ApiModelProperty(value = "If the check found a match")
    private Boolean matched;

    @ApiModelProperty(value = "The reference number for this check")
    private String reference;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Builder
  public static class IdentityResult {
    @ApiModelProperty(value = "If the service responded and didn't return a fault")
    private boolean responded;

    private IdentityDecision decision;

    @ApiModelProperty(value = "The reference number for this check")
    private String reference;

    @JsonIgnore private Integer score;
  }
}
