package uk.co.ybs.digital.customer.service.apply.dto;

public enum ApplicationStatus {

  /** New application submitted. Proceed with initial processing steps. */
  SUBMITTED,
  @Deprecated
  NEW, // historical should be deleted when existing db values of new have been removed.
  /** ID & fraud checks complete. */
  @Deprecated
  POST_FRAUD, // historical should be deleted when existing db values of new have been removed.
  ID_CHECKED,
  /** Deposit submitted. */
  @Deprecated
  FUNDED,
  /** Customer account preferences have been submitted. Application ready to be created on YBSL. */
  @Deprecated
  PREFS_SUBMITTED,
  /** digital user has been created on ldap. */
  @Deprecated
  DIGUSER_CREATED,
  /** customer and Account has been created on YBSL. */
  ACCOUNT_CREATED,
  /** customer account preferences has been updated on YBSL. */
  ACCOUNT_UPDATED,
  /** customer communications have been sent. */
  EMAIL_SENT,
  /** application completed. */
  COMPLETE;
}
