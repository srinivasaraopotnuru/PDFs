package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = FailureRequest.FailureRequestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class FailureRequest {
  @NotNull(message = "You must specify the original challenge")
  @ApiModelProperty(required = true)
  String challenge;

  @ApiModelProperty(value = "Will default to non postal address if not supplied")
  FailureType failureType;

  @JsonPOJOBuilder(withPrefix = "")
  public static class FailureRequestBuilder {}
}
