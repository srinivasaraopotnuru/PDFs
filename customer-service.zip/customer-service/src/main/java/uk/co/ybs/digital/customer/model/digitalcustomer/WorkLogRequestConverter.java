package uk.co.ybs.digital.customer.model.digitalcustomer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class WorkLogRequestConverter implements AttributeConverter<WorkLogRequest, String> {

  private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

  @Override
  public String convertToDatabaseColumn(final WorkLogRequest entityValue) {
    try {
      return OBJECT_MAPPER.writeValueAsString(entityValue);
    } catch (JsonProcessingException e) {
      throw new DataConversionException("Unable to serialise request", e);
    }
  }

  @Override
  public WorkLogRequest convertToEntityAttribute(final String databaseValue) {
    try {
      return OBJECT_MAPPER.readValue(databaseValue, WorkLogRequest.class);
    } catch (JsonProcessingException e) {
      throw new DataConversionException("Unable to deserialise request", e);
    }
  }

  public static class DataConversionException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public DataConversionException(final String message, final Throwable exception) {
      super(message, exception);
    }
  }
}
