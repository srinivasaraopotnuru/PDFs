package uk.co.ybs.digital.customer.model.adgcore;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "AREA_DIALLING_CODES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AreaDiallingCode implements Serializable {
  private static final long serialVersionUID = 1L;

  @EmbeddedId private AreaDiallingCodePK id;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @Column(name = "LENGTH_OF_LOCAL_NO")
  private Integer lengthOfLocalNo;

  private String name;

  @Column(name = "START_DATE")
  private LocalDateTime startDate;

  @Column(name = "UPDATE_ID")
  private String updateId;

  @Column(name = "UPDATE_TIME")
  private LocalDateTime updateTime;
}
