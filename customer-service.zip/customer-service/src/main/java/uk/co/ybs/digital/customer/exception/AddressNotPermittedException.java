package uk.co.ybs.digital.customer.exception;

public class AddressNotPermittedException extends RuntimeException {

  private static final long serialVersionUID = 7399428828584480305L;

  public AddressNotPermittedException(final String message) {
    super(message);
  }

  public AddressNotPermittedException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
