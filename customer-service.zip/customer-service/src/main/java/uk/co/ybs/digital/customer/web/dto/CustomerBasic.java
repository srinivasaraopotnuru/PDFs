package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = CustomerBasic.CustomerBasicBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class CustomerBasic {
  @JsonProperty(value = "partyId")
  @ApiModelProperty(required = true, example = "1234567890")
  String partyId;

  @ApiModelProperty(example = "Mr")
  String title;

  @ApiModelProperty(example = "John")
  String forename;

  @ApiModelProperty(required = true, example = "Smith")
  String surname;

  @ApiModelProperty(example = "2019-12-04")
  LocalDate deceasedDate;

  @ApiModelProperty(example = "1980-12-12")
  LocalDate dateOfBirth;

  @ApiModelProperty(example = "john.smith@ybs.co.uk")
  String email;

  @ApiModelProperty(value = "List of Phone Numbers")
  @JsonProperty(value = "phoneNumber")
  List<PhoneNumberResponse> phoneNumbers;

  @ApiModelProperty(value = "9876543210")
  String webCustomerNumber;

  @ApiModelProperty(value = "John123")
  String webUsername;

  @JsonPOJOBuilder(withPrefix = "")
  public static class CustomerBasicBuilder {}
}
