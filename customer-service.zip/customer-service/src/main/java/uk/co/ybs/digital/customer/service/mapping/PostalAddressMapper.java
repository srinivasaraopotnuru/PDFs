package uk.co.ybs.digital.customer.service.mapping;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.service.PendingDetailsService;
import uk.co.ybs.digital.customer.web.dto.PostalAddressResponse;

@Mapper(componentModel = "spring")
public class PostalAddressMapper {

  protected transient PendingDetailsService pendingDetailsService;

  @Autowired
  public void setService(final PendingDetailsService service) {
    this.pendingDetailsService = service;
  }

  public List<PostalAddressResponse> postalAddresses(final Party party) {
    final List<AddressUsage> addresses = party.getAddresses();

    return addresses.stream()
        .filter(
            address ->
                address.getPostalAddress() != null
                    && address.getFunction() == AddressUsage.AddressFunction.CORR
                    && address.getPostalAddress().getType() == AddressType.UKPOST)
        .filter(matchOnlyLatestPostalAddressEntry(addresses))
        .map(
            address ->
                pendingDetailsService.buildPostalAddressResponse(
                    party, address.getPostalAddress(), address.getFunction().toString()))
        .collect(Collectors.toList());
  }

  private static Predicate<AddressUsage> matchOnlyLatestPostalAddressEntry(
      final List<AddressUsage> addresses) {
    return currentEntry ->
        addresses.stream()
                .filter(address -> address.getPostalAddress() != null)
                .filter(address -> address.getCreatedDate().isAfter(currentEntry.getCreatedDate()))
                .count()
            == 0;
  }
}
