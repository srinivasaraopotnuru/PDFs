package uk.co.ybs.digital.customer.model.adgcore;

public enum AddressType {
  EMAIL,
  TEL,
  UKPOST,
  BFPO,
  FPOST,
  EGGT,
  EGGM,
  FAX
}
