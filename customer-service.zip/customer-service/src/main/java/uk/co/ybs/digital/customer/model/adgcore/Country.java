package uk.co.ybs.digital.customer.model.adgcore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Proxy;

@Entity
@Table(name = "COUNTRIES")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Proxy(lazy = false)
public class Country {

  @Id
  @Column(name = "CODE")
  private String code;

  @Column(name = "ISO_CODE")
  private String isoCode;

  @Column(name = "TELEPHONE_CODE")
  private String telephoneCode;
}
