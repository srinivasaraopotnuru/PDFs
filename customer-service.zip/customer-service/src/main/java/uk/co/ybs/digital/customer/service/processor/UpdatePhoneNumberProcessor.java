package uk.co.ybs.digital.customer.service.processor;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.repository.core.NonPostalAddressCoreRepository;
import uk.co.ybs.digital.customer.repository.core.PartyCoreRepository;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;

@Component
@RequiredArgsConstructor
@Slf4j
@Transactional("customerProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public class UpdatePhoneNumberProcessor {
  private final AuditService auditService;
  private final PartyCoreRepository partyCoreRepository;
  private final NonPostalAddressCoreRepository nonPostalAddressCoreRepository;

  public Party resolve(final UpdatePhoneNumberRequestArguments arguments) {

    final long partyId = arguments.getPartyId();

    final LinkedParty linkedParty = getCanonicalPartyId(partyId);

    return partyCoreRepository
        .findPartyInformationWithAddressTypesAndFunctions(
            linkedParty.getCanonicalPartyId(),
            Collections.singleton(AddressType.TEL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            arguments.getProcessTime())
        .orElseThrow(
            () ->
                new CustomerNotFoundException(
                    String.format("No record found in party database for party id %d", partyId)));
  }

  public void execute(final UpdatePhoneNumberRequestArguments arguments, final Party party) {

    final LocalDateTime processTime = arguments.getProcessTime();

    log.info("Processing party: {}", arguments.getPartyId());

    updatePhoneNumber(
        party,
        arguments.getAdcCode(),
        arguments.getNumber(),
        arguments.getPhoneNumberRequestType(),
        processTime);

    log.info("Processing party: {} - completed", arguments.getPartyId());
  }

  private void updatePhoneNumber(
      final Party party,
      final Integer adcCode,
      final String number,
      final PhoneNumberRequestType phoneNumberRequestType,
      final LocalDateTime processTime) {

    final Country country =
        adcCode == null ? null : Country.builder().code("UK").isoCode("GB").build();
    final NPASourceType sourceType = NPASourceType.valueOf(phoneNumberRequestType.toString());

    endCurrentPhoneNumber(party, processTime, sourceType);

    // Check for existing NPA record to see if it can be re-used
    final Optional<AddressUsage> existingAu =
        party.getAddresses().stream()
            .filter(
                address ->
                    address.getNonPostalAddress() != null
                        && address.getNonPostalAddress().getType() == AddressType.TEL
                        && address.getNonPostalAddress().getSourceType() == sourceType)
            .findFirst();

    // Add new phone number plus associated entries
    final AddressUsage addressUsage =
        AddressUsage.builder()
            .function(AddressUsage.AddressFunction.DIRCOM)
            .startDate(processTime)
            .createdDate(processTime)
            .createdAt(CustomerProcessorConstants.AUDIT_AT)
            .createdBy(CustomerProcessorConstants.AUDIT_BY)
            .party(party)
            .build();

    // Get the current setting for preferred contact method from the current phone number if
    // available
    existingAu.ifPresent(
        au -> {
          addressUsage.setPreferredContactMethod(au.isPreferredContactMethod());
          addressUsage.setPodCode(au.getPodCode());
        });

    party.getAddresses().add(addressUsage);

    final Optional<NonPostalAddress> existingNpa =
        nonPostalAddressCoreRepository
            .findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
                number, AddressType.TEL, adcCode, sourceType, country);

    NonPostalAddress nonPostalAddress =
        existingNpa.orElse(
            NonPostalAddress.builder()
                .address(number)
                .adcCode(adcCode)
                .country(country)
                .type(AddressType.TEL)
                .sourceType(sourceType)
                .usage(addressUsage)
                .build());

    nonPostalAddress.setUsages(
        Stream.of(addressUsage).collect(Collectors.toCollection(HashSet::new)));

    addressUsage.setNonPostalAddress(nonPostalAddress);

    AddressUsageFunction addressUsageFunction =
        AddressUsageFunction.builder()
            .id(
                AddressUsageFunction.AddressUsageFunctionPK.builder()
                    .function(AddressUsage.AddressFunction.DIRCOM)
                    .startDate(processTime)
                    .build())
            .addressUsage(addressUsage)
            .build();

    addressUsage.setFunctions(Collections.singleton(addressUsageFunction));

    log.info("Creating new entries for updated phone for party: {}", party.getSysId());

    partyCoreRepository.saveAndFlush(party);
  }

  private void endCurrentPhoneNumber(
      final Party party, final LocalDateTime processTime, final NPASourceType sourceType) {
    party.getAddresses().stream()
        .filter(
            address ->
                address.getNonPostalAddress() != null
                    && address.getNonPostalAddress().getType().equals(AddressType.TEL)
                    && address.getNonPostalAddress().getSourceType().equals(sourceType))
        .forEach(
            address -> {
              address.setEndDate(processTime);
              address.setEndedDate(processTime);
              address.setEndedAt(CustomerProcessorConstants.AUDIT_AT);
              address.setEndedBy(CustomerProcessorConstants.AUDIT_BY);
              log.info(
                  "Ending address usage: {} for party: {}", address.getSysId(), party.getSysId());
              address.getFunctions().forEach(func -> func.setEndDate(processTime));
            });
  }

  public void auditSuccess(final UpdatePhoneNumberRequestArguments arguments) {

    final String address =
        arguments.getAdcCode() == null
            ? arguments.getNumber()
            : "0" + arguments.getAdcCode() + arguments.getNumber();

    final AuditNonPostalAddressUpdateSuccessRequest auditRequest =
        AuditNonPostalAddressUpdateSuccessRequest.builder()
            .ipAddress(arguments.getRequestMetadata().getIpAddress())
            .address(address)
            .operation(NonPostalOperation.PHONE_NUMBER)
            .type(NonPostalType.valueOf(arguments.getPhoneNumberRequestType().toString()))
            .build();
    auditService.auditNonPostalAddressUpdateSuccess(auditRequest, arguments.getRequestMetadata());
  }

  public void auditFailure(
      final UpdatePhoneNumberRequestArguments arguments, final String message) {

    final String address =
        arguments.getAdcCode() == null
            ? arguments.getNumber()
            : "0" + arguments.getAdcCode() + arguments.getNumber();

    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        AuditNonPostalAddressUpdateFailureRequest.builder()
            .ipAddress(arguments.getRequestMetadata().getIpAddress())
            .message(message)
            .address(address)
            .operation(NonPostalOperation.PHONE_NUMBER)
            .type(NonPostalType.valueOf(arguments.getPhoneNumberRequestType().toString()))
            .build();
    auditService.auditNonPostalAddressUpdateFailure(auditRequest, arguments.getRequestMetadata());
  }

  private LinkedParty getCanonicalPartyId(final long partyId) {

    return partyCoreRepository
        .findCanonicalPartyId(partyId)
        .orElseThrow(
            () ->
                (new CustomerNotFoundException(
                    String.format("No record found in party database for party id %d", partyId))));
  }
}
