package uk.co.ybs.digital.customer.model.core;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "ADDRESS_USAGE_FUNCTIONS")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AddressUsageFunction implements Serializable {
  private static final long serialVersionUID = 1L;

  @EmbeddedId private AddressUsageFunctionPK id;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  // bi-directional many-to-one association to AddressUsage
  @ManyToOne
  @MapsId("addressUsageSysid")
  @JoinColumn(name = "ADDUSE_SYSID")
  @ToString.Exclude
  private AddressUsage addressUsage;

  @Embeddable
  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class AddressUsageFunctionPK implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "ADDUSE_SYSID", nullable = false, updatable = false)
    private Long addressUsageSysid;

    @Enumerated(EnumType.STRING)
    @Column(name = "ADDFUN_CODE", nullable = false, updatable = false)
    private AddressUsage.AddressFunction function;

    @Column(name = "START_DATE", nullable = false, updatable = false)
    private LocalDateTime startDate;
  }
}
