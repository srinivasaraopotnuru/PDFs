package uk.co.ybs.digital.customer.repository.core;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import uk.co.ybs.digital.customer.model.core.WorkEventOutput;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
public interface WorkEventCoreRepositoryCustom {
  /*
   * The in memory H2 database used for tests does not support stored procedures with IN OUT parameters, so it is not
   * possible to easily test this repository. This will just be covered by E2E tests.
   */

  WorkEventOutput createAdacusWorkEvent(Long partyId, Long accountNumber);

  WorkEventOutput createChcamoWorkEvent(Long accountNumber, Long accountType);
}
