package uk.co.ybs.digital.customer.exception;

import java.util.List;
import lombok.Getter;
import lombok.NonNull;

@Getter
public class InvalidScaHeadersException extends RuntimeException {

  private static final long serialVersionUID = 7119916284471851236L;
  @NonNull private final List<String> missingHeaders;
  @NonNull private final List<String> requiredHeaders;

  public InvalidScaHeadersException(
      final String message, final List<String> missingHeaders, final List<String> requiredHeaders) {
    super(message);
    this.missingHeaders = missingHeaders;
    this.requiredHeaders = requiredHeaders;
  }
}
