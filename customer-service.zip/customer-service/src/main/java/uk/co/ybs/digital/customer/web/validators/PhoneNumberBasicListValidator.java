package uk.co.ybs.digital.customer.web.validators;

import static java.util.stream.Collectors.groupingBy;

import java.util.List;
import java.util.Map.Entry;
import java.util.Optional;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;

public class PhoneNumberBasicListValidator
    implements ConstraintValidator<ValidPhoneNumberBasicList, List<PhoneNumberBasic>> {

  @Override
  public void initialize(final ValidPhoneNumberBasicList constraintAnnotation) {}

  @Override
  public boolean isValid(
      final List<PhoneNumberBasic> phoneNumbers, final ConstraintValidatorContext context) {

    Optional<Entry<PhoneNumberBasicType, List<PhoneNumberBasic>>> duplicatedPhoneNumber =
        phoneNumbers.stream()
            .filter(e -> e.getType() != null)
            .collect(groupingBy(PhoneNumberBasic::getType))
            .entrySet()
            .stream()
            .filter(e -> e.getValue().size() > 1)
            .findFirst();

    if (duplicatedPhoneNumber.isPresent()) {

      // Get the duplicated item so we can retrieve its index in the request array
      PhoneNumberBasic duplicateEntry = duplicatedPhoneNumber.get().getValue().get(1);
      int index = phoneNumbers.indexOf(duplicateEntry);

      context.disableDefaultConstraintViolation();
      context
          .buildConstraintViolationWithTemplate("Duplicate phone number type in request")
          .addPropertyNode("type")
          .inIterable()
          .atIndex(index)
          .addConstraintViolation();
      return false;
    }
    return true;
  }
}
