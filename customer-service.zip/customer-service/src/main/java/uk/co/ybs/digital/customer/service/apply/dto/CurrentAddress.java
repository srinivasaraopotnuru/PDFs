package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@EqualsAndHashCode(callSuper = false)
public class CurrentAddress extends Address {

  private static final String ALPHANUM_REGEX = "^[a-zA-Z0-9-' ]*$";

  @NotNull(message = "Please specify postcode")
  @NotEmpty(message = "Postcode must not be empty")
  @Pattern(
      regexp = ALPHANUM_REGEX,
      message = "Please specify valid postcode matching pattern:{regexp}.")
  @ApiModelProperty(required = true, value = "Postcode must match ^[a-zA-Z0-9-' ]*$ regex")
  private String postcode;

  @NotNull(message = "Please specify countryCode")
  @NotEmpty(message = "CountryCode must not be empty")
  @ApiModelProperty(required = true, value = "countryCode")
  private String countryCode;
}
