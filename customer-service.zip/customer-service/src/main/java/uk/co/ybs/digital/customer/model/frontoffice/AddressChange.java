package uk.co.ybs.digital.customer.model.frontoffice;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder(toBuilder = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@IdClass(AddressChange.AddressChangePk.class)
@Table(name = "ADDRESS_CHANGE")
public class AddressChange {
  @Id
  @Column(name = "PARTY_SYSID", nullable = false)
  private String partySysId;

  @Id
  @Column(name = "AMEND_DATE", nullable = false)
  private LocalDateTime amendDate;

  @Column(name = "ADDRESS1")
  private String addressLine1;

  @Column(name = "ADDRESS2")
  private String addressLine2;

  @Column(name = "ADDRESS3")
  private String addressLine3;

  @Column(name = "ADDRESS4")
  private String addressLine4;

  @Column(name = "POSTCODE")
  private String postCode;

  @Column(name = "COUNTRY")
  private String country;

  @Column(name = "PAFKEY")
  private String pafKey;

  @Column(name = "PAFDELIVERYPREFIX")
  private String pafDeliveryPrefix;

  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class AddressChangePk implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "PARTY_SYSID", nullable = false)
    private String partySysId;

    @Column(name = "AMEND_DATE", nullable = false)
    private LocalDateTime amendDate;
  }
}
