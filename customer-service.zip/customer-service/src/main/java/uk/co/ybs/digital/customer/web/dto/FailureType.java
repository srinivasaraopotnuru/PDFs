package uk.co.ybs.digital.customer.web.dto;

public enum FailureType {
  NON_POSTAL_ADDRESS,
  POSTAL_ADDRESS
}
