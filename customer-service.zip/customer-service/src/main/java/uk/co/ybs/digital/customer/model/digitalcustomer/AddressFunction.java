package uk.co.ybs.digital.customer.model.digitalcustomer;

public enum AddressFunction {
  CORR
}
