package uk.co.ybs.digital.customer.web.dto.products;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Product {
  @ApiModelProperty(required = true)
  @NonNull
  String name;

  @ApiModelProperty(required = true)
  @NonNull
  ProductType type;

  @ApiModelProperty(required = true)
  @NonNull
  String url;

  @ApiModelProperty(example = "16")
  Integer minimumAge;

  @ApiModelProperty(example = "75")
  Integer maximumAge;

  @ApiModelProperty(example = "1")
  Integer maximumNumberOfAccounts;

  @ApiModelProperty(required = true)
  @NonNull
  Boolean loyalty;

  @ApiModelProperty(required = true)
  @NonNull
  List<InterestTier> interestTiers;

  @ApiModelProperty(required = true)
  @NonNull
  List<Fact> facts;

  List<Warning> warnings;

  @ApiModelProperty(required = true)
  @NonNull
  InterestFrequency interestFrequency;
}
