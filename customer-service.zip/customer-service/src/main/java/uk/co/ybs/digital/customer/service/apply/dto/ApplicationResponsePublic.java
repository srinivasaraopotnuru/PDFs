package uk.co.ybs.digital.customer.service.apply.dto;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(callSuper = true)
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
public class ApplicationResponsePublic extends ApplicationResponseBase {

  @Valid
  @NotNull
  @ApiModelProperty(required = true, value = "The applicants for this application")
  private List<CustomerDetailsResponse> applicants;
}
