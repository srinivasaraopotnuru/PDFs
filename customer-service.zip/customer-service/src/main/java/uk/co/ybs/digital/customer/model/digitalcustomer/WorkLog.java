package uk.co.ybs.digital.customer.model.digitalcustomer;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "WORK_LOG")
@EntityListeners(AuditingEntityListener.class)
public class WorkLog {
  public enum Status {
    PENDING,
    COMPLETE,
    FAILED
  }

  public enum Operation {
    EMAIL_ADDRESS,
    PHONE_NUMBER,
    UPDATE_PHONE_NUMBER,
    DELETE_PHONE_NUMBER,
    POSTAL_ADDRESS
  }

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "WORK_LOG_ID_SEQ")
  @SequenceGenerator(sequenceName = "WORK_LOG_ID_SEQ", allocationSize = 1, name = "WORK_LOG_ID_SEQ")
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "PARTY_ID", nullable = false)
  private Long partyId;

  @Enumerated(EnumType.STRING)
  @Column(name = "STATUS", nullable = false)
  private Status status;

  @Enumerated(EnumType.STRING)
  @Column(name = "OPERATION", nullable = false)
  private Operation operation;

  @Convert(converter = WorkLogRequestConverter.class)
  @Column(name = "MESSAGE", nullable = false, updatable = false)
  private WorkLogRequest message;

  @CreatedBy
  @Column(name = "CREATED_BY", nullable = false, updatable = false)
  private String createdBy;

  @CreatedDate
  @Column(name = "CREATED_DATE", nullable = false, updatable = false)
  private LocalDateTime createdDate;

  @LastModifiedBy
  @Column(name = "UPDATED_BY")
  private String updatedBy;

  @LastModifiedDate
  @Column(name = "UPDATED_DATE")
  private LocalDateTime updatedDate;
}
