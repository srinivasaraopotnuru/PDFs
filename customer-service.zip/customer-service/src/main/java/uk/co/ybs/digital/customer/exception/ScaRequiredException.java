package uk.co.ybs.digital.customer.exception;

import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public class ScaRequiredException extends RuntimeException {

  private static final long serialVersionUID = 6933097333253991632L;
  @NonNull private final String challenge;
}
