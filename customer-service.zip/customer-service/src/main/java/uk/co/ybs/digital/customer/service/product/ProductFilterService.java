package uk.co.ybs.digital.customer.service.product;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.service.account.AccountService;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountSummary;
import uk.co.ybs.digital.customer.service.apply.ApplyService;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationResponsePrivate;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationStatus;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationsResponsePrivate;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.InterestFrequency;
import uk.co.ybs.digital.customer.web.dto.products.Product;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.customer.web.dto.products.Warning;
import uk.co.ybs.digital.customer.web.dto.products.WarningCode;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProductFilterService {

  private final AccountService accountService;
  private final ProductService productService;
  private final ApplyService applyService;

  private static final String REGEX_PRODUCT_ID_FROM_URL = "id=(.+$)";

  private static final Pattern PATTERN_PRODUCT_ID_FROM_URL =
      Pattern.compile(REGEX_PRODUCT_ID_FROM_URL);

  private static final String PRODUCT_SUFFIX_WEB = "W";
  private static final String PRODUCT_SUFFIX_ANNUAL_INTEREST = "A";
  private static final String PRODUCT_SUFFIX_MONTHLY_INTEREST = "M";

  public List<ProductCategory> filterProducts(
      final Party customer, final RequestMetadata metadata, final LocalDateTime now) {

    final boolean eligibleAddress =
        customer.getAddresses().stream()
            .anyMatch(
                addressUsage ->
                    addressUsage.getFunction() == AddressFunction.CORR
                        && addressUsage.getPostalAddress().getType() == AddressType.UKPOST
                        && (addressUsage.getPostalAddress().getCountry() == null
                            || addressUsage
                                .getPostalAddress()
                                .getCountry()
                                .getCode()
                                .equals("UK")));

    if (customer.getPerson().getDateOfBirth() == null) {
      throw new CustomerServiceException(
          String.format(
              "DOB cannot be null for web enabled parties: Party %s", customer.getSysId()));
    }

    final int age = calculateAge(customer.getPerson().getDateOfBirth(), now.toLocalDate());

    final AccountGroupedInfo accountGroupedInfo =
        accountService.getGroupedAccountInfo(metadata, false);

    final ApplicationsResponsePrivate applications = applyService.getApplicationsPrivate(metadata);

    final List<ApplicationResponsePrivate> applicationsInProgress =
        applications.getApplications().stream()
            .filter(
                ap ->
                    ap.getStatus() == ApplicationStatus.SUBMITTED
                        || ap.getStatus() == ApplicationStatus.ID_CHECKED)
            .collect(Collectors.toList());

    final List<ProductCategory> onSaleProducts = productService.getOnSaleProducts(metadata);

    final List<ProductCategory> filteredProductCategories = new ArrayList<>();

    onSaleProducts.forEach(
        productCategory -> {
          final List<Product> availableProducts = new ArrayList<>();
          final List<Product> unavailableProducts = new ArrayList<>();
          productCategory
              .getProducts()
              .forEach(
                  product -> {
                    List<Warning> warnings = new ArrayList<>();
                    checkEligibleAddress(eligibleAddress, warnings);
                    checkAgeConstraints(age, product, warnings);
                    checkMaxNumberOfAccountsConstraints(
                        accountGroupedInfo.getOwned().getAccounts(),
                        applicationsInProgress,
                        product,
                        warnings);
                    if (warnings.isEmpty()) {
                      availableProducts.add(product);
                    } else {
                      unavailableProducts.add(product.toBuilder().warnings(warnings).build());
                    }
                  });
          filteredProductCategories.add(
              productCategory
                  .toBuilder()
                  .products(availableProducts)
                  .unavailableProducts(unavailableProducts)
                  .build());
        });

    return filteredProductCategories;
  }

  private void checkEligibleAddress(final boolean eligibleAddress, final List<Warning> warnings) {
    if (!eligibleAddress) {
      warnings.add(
          Warning.builder()
              .code(WarningCode.NON_UK_ADDRESS)
              .message("Customer has Non UK Address.")
              .build());
    }
  }

  private void checkAgeConstraints(
      final int age, final Product product, final List<Warning> warnings) {
    if ((product.getMinimumAge() != null && age < product.getMinimumAge())
        || (product.getMaximumAge() != null && age > product.getMaximumAge())) {
      warnings.add(
          Warning.builder()
              .code(WarningCode.APPLICANT_AGE)
              .message("Product age Constraints not met")
              .build());
    }
  }

  private void checkMaxNumberOfAccountsConstraints(
      final List<AccountSummary> accounts,
      final List<ApplicationResponsePrivate> applicationsInProgress,
      final Product product,
      final List<Warning> warnings) {
    if (Optional.ofNullable(product.getMaximumNumberOfAccounts()).isPresent()) {
      long numOfAccounts =
          accounts.stream()
              .filter(
                  account ->
                      account.getProductIdentifier().equals(extractProductIdentifier(product)))
              .count();
      long numOfApplicationsInProgress =
          applicationsInProgress.stream()
              .filter(
                  application ->
                      application
                          .getProduct()
                          .getProductIdentifier()
                          .equals(extractProductIdentifier(product)))
              .count();
      if (numOfAccounts + numOfApplicationsInProgress >= product.getMaximumNumberOfAccounts()) {
        warnings.add(
            Warning.builder()
                .code(WarningCode.MAX_NO_OF_ACCOUNTS)
                .message(
                    "Exceeded maximum number of Accounts. "
                        + numOfAccounts
                        + " open accounts, "
                        + numOfApplicationsInProgress
                        + " applications in progress")
                .build());
      }
    }
  }

  private static String extractProductIdentifier(final Product product) {

    final Matcher matcher = PATTERN_PRODUCT_ID_FROM_URL.matcher(product.getUrl());

    if (matcher.find()) {

      final String productIdentifier = matcher.group(1);

      if (productIdentifier.endsWith(PRODUCT_SUFFIX_WEB)) {
        if (product.getInterestFrequency().equals(InterestFrequency.ANNUAL)) {
          return productIdentifier + PRODUCT_SUFFIX_ANNUAL_INTEREST;
        } else if (product.getInterestFrequency().equals(InterestFrequency.MONTHLY)) {
          return productIdentifier + PRODUCT_SUFFIX_MONTHLY_INTEREST;
        }
      }
      return productIdentifier;
    }

    log.warn("Cannot extract product identifier from url {}", product.getUrl());

    return null;
  }

  private int calculateAge(final LocalDate birthDate, final LocalDate currentDate) {
    return Period.between(birthDate, currentDate).getYears();
  }
}
