package uk.co.ybs.digital.customer.service.audit.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.customer.web.NonEmptyString;

@Value
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditNonPostalAddressUpdateFailureRequest {
  @NotNull(message = "You must specify an ip address")
  String ipAddress;

  @NotNull(message = "You must specify a failure message")
  @NonEmptyString
  String message;

  @Valid
  @NonEmptyString(message = "You must specify a valid address")
  String address;

  @Valid
  @NotNull(message = "You must specify an operation")
  NonPostalOperation operation;

  @Valid
  @NotNull(message = "You must specify a type")
  NonPostalType type;
}
