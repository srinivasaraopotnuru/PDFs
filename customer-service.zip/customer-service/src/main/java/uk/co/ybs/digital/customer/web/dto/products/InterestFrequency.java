package uk.co.ybs.digital.customer.web.dto.products;

public enum InterestFrequency {
  ANNUAL,
  MONTHLY,
  BIANNUAL
}
