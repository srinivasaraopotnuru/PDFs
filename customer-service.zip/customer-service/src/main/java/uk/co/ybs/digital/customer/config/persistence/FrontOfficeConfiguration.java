package uk.co.ybs.digital.customer.config.persistence;

import com.zaxxer.hikari.HikariDataSource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateProperties;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.PlatformTransactionManager;
import uk.co.ybs.digital.customer.config.persistence.builder.HibernateEntityManagerFactoryBuilder;
import uk.co.ybs.digital.customer.config.persistence.builder.HikariDataSourceBuilder;
import uk.co.ybs.digital.customer.config.persistence.builder.JpaTransactionManagerBuilder;

@Configuration
@EnableJpaRepositories(
    basePackages = FrontOfficeConfiguration.REPOSITORY_PACKAGE,
    entityManagerFactoryRef = "frontOfficeEntityManagerFactory")
public class FrontOfficeConfiguration {

  private static final String PERSISTENCE_UNIT = "frontoffice";

  private static final String DATASOURCE_PROPERTIES =
      PersistenceConfiguration.DATASOURCE_PROPERTY_PREFIX + PERSISTENCE_UNIT;
  private static final String HIKARI_PROPERTIES = DATASOURCE_PROPERTIES + ".hikari";

  private static final String JPA_PROPERTIES =
      PersistenceConfiguration.JPA_PROPERTIES_PREFIX + PERSISTENCE_UNIT;
  private static final String HIBERNATE_PROPERTIES = JPA_PROPERTIES + ".hibernate";

  private static final String MODEL_PACKAGE =
      PersistenceConfiguration.MODEL_PACKAGE_PREFIX + PERSISTENCE_UNIT;
  public static final String REPOSITORY_PACKAGE =
      PersistenceConfiguration.REPOSITORY_PACKAGE_PREFIX + PERSISTENCE_UNIT;

  @Bean
  @ConfigurationProperties(prefix = DATASOURCE_PROPERTIES)
  public DataSourceProperties frontOfficeDataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = HIKARI_PROPERTIES)
  public HikariDataSource frontOfficeDataSource(
      final DataSourceProperties frontOfficeDataSourceProperties) {
    return new HikariDataSourceBuilder()
        .withDataSourceProperties(frontOfficeDataSourceProperties)
        .build();
  }

  @Bean
  @ConfigurationProperties(prefix = JPA_PROPERTIES)
  public JpaProperties frontOfficeJpaProperties() {
    return new JpaProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = HIBERNATE_PROPERTIES)
  public HibernateProperties frontOfficeHibernateProperties() {
    return new HibernateProperties();
  }

  @Bean
  public FactoryBean<EntityManagerFactory> frontOfficeEntityManagerFactory(
      final DataSource frontOfficeDataSource,
      final JpaProperties frontOfficeJpaProperties,
      final HibernateProperties frontOfficeHibernateProperties) {
    return new HibernateEntityManagerFactoryBuilder()
        .withDataSource(frontOfficeDataSource)
        .withHibernateProperties(frontOfficeHibernateProperties)
        .withJpaProperties(frontOfficeJpaProperties)
        .withPackagesToScan(new String[] {MODEL_PACKAGE})
        .withPersistenceUnitName(PERSISTENCE_UNIT)
        .build();
  }

  @Bean
  public PlatformTransactionManager frontOfficeTransactionManager(
      final EntityManagerFactory frontOfficeEntityManagerFactory,
      final ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
    return new JpaTransactionManagerBuilder()
        .withEntityManagerFactory(frontOfficeEntityManagerFactory)
        .withTransactionManagerCustomizers(transactionManagerCustomizers)
        .build();
  }
}
