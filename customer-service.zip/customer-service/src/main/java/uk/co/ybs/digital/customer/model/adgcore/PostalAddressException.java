package uk.co.ybs.digital.customer.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "POSTAL_ADDRESS_EXCEPTIONS")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PostalAddressException {
  @Id
  @Column(name = "CODE")
  private String code;

  @Column(name = "INVALID_TEXT")
  private String invalidText;

  @Column(name = "TEXT_MATCHING_TYPE")
  private String matchingType;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;
}
