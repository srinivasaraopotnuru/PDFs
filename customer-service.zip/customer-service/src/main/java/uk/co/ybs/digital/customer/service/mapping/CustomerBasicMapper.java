package uk.co.ybs.digital.customer.service.mapping;

import org.mapstruct.InjectionStrategy;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import uk.co.ybs.digital.customer.model.adgcore.CustomerWebLogOnDetails;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.web.dto.CustomerBasic;

@Mapper(
    componentModel = "spring",
    uses = {PhoneNumberMapper.class, EmailMapper.class},
    injectionStrategy = InjectionStrategy.CONSTRUCTOR)
public interface CustomerBasicMapper {
  @Mappings(
      value = {
        @Mapping(source = "sysId", target = "partyId"),
        @Mapping(source = "person.title", target = "title"),
        @Mapping(source = "person.forenames", target = "forename"),
        @Mapping(source = "person.surname", target = "surname"),
        @Mapping(source = "person.dateOfDeath", target = "deceasedDate"),
        @Mapping(source = "addresses", target = "email"),
        @Mapping(source = "addresses", target = "phoneNumbers"),
        @Mapping(target = "webCustomerNumber", ignore = true),
        @Mapping(target = "webUsername", ignore = true),
        @Mapping(target = "dateOfBirth", ignore = true)
      })
  CustomerBasic map(Party party);

  @Mappings(
      value = {
        @Mapping(source = "party.sysId", target = "partyId"),
        @Mapping(source = "party.person.title", target = "title"),
        @Mapping(source = "party.person.forenames", target = "forename"),
        @Mapping(source = "party.person.surname", target = "surname"),
        @Mapping(source = "party.person.dateOfBirth", target = "dateOfBirth"),
        @Mapping(source = "party.person.dateOfDeath", target = "deceasedDate"),
        @Mapping(source = "party.addresses", target = "email"),
        @Mapping(source = "party.addresses", target = "phoneNumbers"),
        @Mapping(
            source = "customerWebLogOnDetails.webCustomerNumber",
            target = "webCustomerNumber"),
        @Mapping(source = "customerWebLogOnDetails.webUsername", target = "webUsername")
      })
  CustomerBasic map(Party party, CustomerWebLogOnDetails customerWebLogOnDetails);
}
