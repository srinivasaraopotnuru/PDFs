package uk.co.ybs.digital.customer.model.adgcore;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@SqlResultSetMapping(
    name = DeDupeEligibleParty.DEDUPE_ELIGIBLE_QUERY_RESULT_SET_MAPPING,
    entities =
        @EntityResult(
            entityClass = DeDupeEligibleParty.class,
            fields = {@FieldResult(name = "eligibility", column = "ELIGIBILITY")}))
@NamedNativeQuery(
    name = DeDupeEligibleParty.DEDUPE_ELIGIBLE_QUERY,
    resultSetMapping = DeDupeEligibleParty.DEDUPE_ELIGIBLE_QUERY_RESULT_SET_MAPPING,
    query = "SELECT SOA_PARTY_DATA.FN_ELIGIBLE_FOR_PARTY_HUB(?1) AS ELIGIBILITY FROM DUAL")
public class DeDupeEligibleParty {
  public static final String DEDUPE_ELIGIBLE_QUERY = "dedupeEligibleQuery";
  public static final String DEDUPE_ELIGIBLE_QUERY_RESULT_SET_MAPPING = "DeDupeEligibleDetails";

  @Id private String eligibility;
}
