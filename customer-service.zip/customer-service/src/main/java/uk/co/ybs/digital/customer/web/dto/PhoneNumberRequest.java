package uk.co.ybs.digital.customer.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import lombok.Builder;
import lombok.Singular;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.customer.web.validators.ValidPhoneNumberBasicList;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PhoneNumberRequest {

  @ApiModelProperty(value = "List of Phone Numbers")
  @JsonProperty(value = "phoneNumber")
  @Singular
  @NotEmpty(message = "At least one phone number must be specified")
  @Valid
  @ValidPhoneNumberBasicList
  List<PhoneNumberBasic> phoneNumbers;
}
