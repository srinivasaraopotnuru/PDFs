package uk.co.ybs.digital.customer.model.adgcore;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.persistence.AttributeOverride;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.customer.model.PostCode;

@Entity
@Table(name = "POSTAL_ADDRESSES")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class PostalAddress {

  public static final String PAF_STATUS_PAFSUC = "PAFSUC";
  public static final String PAF_STATUS_PAFNUS = "PAFNUS";

  @Id
  @Column(name = "SYSID")
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "LINE1")
  private String line1;

  @Column(name = "LINE2")
  private String line2;

  @Column(name = "LINE3")
  private String line3;

  @Column(name = "LINE4")
  private String line4;

  @Column(name = "LINE5")
  private String line5;

  @ManyToOne
  @JoinColumn(name = "CNTRY_CODE")
  private Country country;

  @Embedded
  @AttributeOverride(name = "areaCode", column = @Column(name = "AREA_CODE"))
  @AttributeOverride(name = "districtCode", column = @Column(name = "DISTRICT_CODE"))
  @AttributeOverride(name = "sectorCode", column = @Column(name = "SECTOR_CODE"))
  @AttributeOverride(name = "unitCode", column = @Column(name = "UNIT_CODE"))
  private PostCode postCode;

  @NonNull
  @Column(name = "ADTYP_CODE")
  @Enumerated(EnumType.STRING)
  private AddressType type;

  @OneToMany(mappedBy = "postalAddress")
  @ToString.Exclude
  private Set<AddressUsage> usages;

  public List<String> getLines() {
    return Stream.of(line1, line2, line3, line4, line5)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }
}
