package uk.co.ybs.digital.customer.web.dto.products;

import io.swagger.annotations.ApiModelProperty;
import java.util.List;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ProductCategory {
  @ApiModelProperty(required = true)
  @NonNull
  String title;

  @ApiModelProperty(required = true)
  @NonNull
  String subTitle;

  @ApiModelProperty(required = true)
  @NonNull
  String description;

  @ApiModelProperty(required = true)
  @NonNull
  List<Product> products;

  List<Product> unavailableProducts;

  @ApiModelProperty(required = true)
  @NonNull
  Boolean offlineOnlyProductsAvailable;

  @ApiModelProperty(required = true)
  @NonNull
  String url;
}
