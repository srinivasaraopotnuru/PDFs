package uk.co.ybs.digital.customer.service.apply.dto;

public interface ApplicationResponse {}
