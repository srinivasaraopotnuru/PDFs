package uk.co.ybs.digital.customer.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import uk.co.ybs.digital.customer.web.NonEmptyString;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(
    builder = AuditAuthenticationFailureRequest.AuditAuthenticationFailureRequestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuditAuthenticationFailureRequest {
  @NotNull(message = "You must specify an ip address")
  String ipAddress;

  @NotNull(message = "You must specify a failure message")
  @NonEmptyString
  String message;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditAuthenticationFailureRequestBuilder {}
}
