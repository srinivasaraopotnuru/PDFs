package uk.co.ybs.digital.customer.service.mapping;

import com.google.common.collect.ImmutableSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.service.PendingDetailsService;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberSubType;

@Mapper(componentModel = "spring")
public class PhoneNumberMapper {

  private static final String UK = "UK";
  private static final Set<String> MOBILE_PREFIXES =
      ImmutableSet.of("071", "072", "073", "074", "075", "07624", "077", "078", "079");

  protected transient PendingDetailsService pendingDetailsService;

  private static Predicate<AddressUsage> matchOnlyLatestEntryForSourceType(
      final List<AddressUsage> addresses) {
    return currentEntry ->
        addresses.stream()
                .filter(
                    address ->
                        address.getNonPostalAddress() != null
                            && address.getNonPostalAddress().getType() == AddressType.TEL)
                .filter(
                    address ->
                        currentEntry.getNonPostalAddress().getSourceType()
                                == address.getNonPostalAddress().getSourceType()
                            && address.getCreatedDate().isAfter(currentEntry.getCreatedDate()))
                .count()
            == 0;
  }

  @Autowired
  public void setService(final PendingDetailsService service) {
    this.pendingDetailsService = service;
  }

  public List<PhoneNumberResponse> phoneNumbers(final List<AddressUsage> addresses) {

    return addresses.stream()
        .filter(
            address ->
                address.getNonPostalAddress() != null
                    && address.getNonPostalAddress().getType() == AddressType.TEL)
        .filter(matchOnlyLatestEntryForSourceType(addresses))
        .map(AddressUsage::getNonPostalAddress)
        .map(
            address ->
                PhoneNumberResponse.builder()
                    .number(mapPhoneNumberADCCode(address))
                    .type(address.getSourceTypeOrDefault().toString())
                    .subType(mapPhoneNumberSubType(address))
                    .countryCode(mapPhoneNumberCountryCode(address))
                    .build())
        .collect(Collectors.toList());
  }

  public List<PhoneNumberResponse> phoneNumberAddresses(final Party party) {
    final List<AddressUsage> addresses = party.getAddresses();

    List<PhoneNumberResponse> numbers =
        addresses.stream()
            .filter(
                addr ->
                    addr.getNonPostalAddress() != null
                        && AddressType.TEL == addr.getNonPostalAddress().getType())
            .map(AddressUsage::getNonPostalAddress)
            .map(
                address ->
                    PhoneNumberResponse.builder()
                        .number(mapPhoneNumberADCCode(address))
                        .type(address.getSourceTypeOrDefault().toString())
                        .subType(mapPhoneNumberSubType(address))
                        .countryCode(mapPhoneNumberCountryCode(address))
                        .build())
            .collect(Collectors.toList());

    return numbers.stream()
        .map(addr -> pendingDetailsService.buildPhoneNumberResponse(party, addr))
        .collect(Collectors.toList());
  }

  private String mapPhoneNumberADCCode(final NonPostalAddress nonPostalAddress) {
    String phoneNumber = nonPostalAddress.getAddress();

    if (nonPostalAddress.getCountry() != null
        && Objects.equals(nonPostalAddress.getCountry().getCode(), UK)) {

      if (nonPostalAddress.getAdcCode() != null
          && (Objects.equals(nonPostalAddress.getSourceType(), NPASourceType.HOME)
              || Objects.equals(nonPostalAddress.getSourceType(), NPASourceType.WORK))) {
        return "0" + nonPostalAddress.getAdcCode() + phoneNumber;
      }

      if (Objects.equals(nonPostalAddress.getSourceType(), NPASourceType.MOBILE)
          && !phoneNumber.startsWith("0")) {
        return "0" + phoneNumber;
      }
    }

    return phoneNumber;
  }

  private PhoneNumberSubType mapPhoneNumberSubType(final NonPostalAddress address) {
    // Assume that a null country code is a UK based number
    if (address.getCountry() == null || Objects.equals(address.getCountry().getCode(), UK)) {
      final String phoneNumber = mapPhoneNumberADCCode(address);

      if (MOBILE_PREFIXES.stream().anyMatch(phoneNumber::startsWith)) {
        return PhoneNumberSubType.MOBILE;
      }
      return PhoneNumberSubType.LANDLINE;
    }

    return PhoneNumberSubType.INTERNATIONAL;
  }

  private String mapPhoneNumberCountryCode(final NonPostalAddress address) {
    // Don't return a country code for null/UK countries
    if (address.getCountry() == null || Objects.equals(address.getCountry().getCode(), UK)) {
      return null;
    }
    return address.getCountry().getTelephoneCode();
  }
}
