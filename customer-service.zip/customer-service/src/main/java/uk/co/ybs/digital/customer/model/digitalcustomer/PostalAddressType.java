package uk.co.ybs.digital.customer.model.digitalcustomer;

public enum PostalAddressType {
  UKPOST,
  BFPO,
  FPOST
}
