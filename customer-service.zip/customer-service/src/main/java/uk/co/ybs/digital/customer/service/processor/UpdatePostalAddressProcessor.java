package uk.co.ybs.digital.customer.service.processor;

import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFNUS;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFSUC;
import static uk.co.ybs.digital.customer.service.utilities.PostCodeHelper.formatPostcode;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.core.ActivityPlayer;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.core.PostalAddress;
import uk.co.ybs.digital.customer.model.core.WorkEvent.ModuleLabelAssociationType;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventContextTableName;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventStatus;
import uk.co.ybs.digital.customer.model.digitalcustomer.AddressFunction;
import uk.co.ybs.digital.customer.model.digitalcustomer.PostalAddressType;
import uk.co.ybs.digital.customer.repository.core.ActivityPlayerRepository;
import uk.co.ybs.digital.customer.repository.core.PartyCoreRepository;
import uk.co.ybs.digital.customer.repository.core.PostalAddressRepository;
import uk.co.ybs.digital.customer.repository.core.WorkEventCoreRepository;
import uk.co.ybs.digital.customer.service.WorkEventService;
import uk.co.ybs.digital.customer.service.account.AccountService;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountSummary;
import uk.co.ybs.digital.customer.service.account.dto.Warning;
import uk.co.ybs.digital.customer.service.account.dto.WarningCode;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@Component
@RequiredArgsConstructor
@Slf4j
@Transactional("customerProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.customer.processor",
    name = "enabled",
    havingValue = "true")
@SuppressWarnings("PMD.ExcessiveParameterList")
public class UpdatePostalAddressProcessor {

  private static final String POSTAL_SAVINGS_ACCOUNT = "POSTALSAVE";
  private static final String POSTAL_SAVINGS_ACCOUNT_MONTHLY_INTEREST = "POSTSAVMIA";
  private static final String UK = "UK";
  private final AuditService auditService;
  private final AccountService accountService;
  private final WorkEventService workEventService;
  private final PartyCoreRepository partyCoreRepository;

  private final PostalAddressRepository postalAddressRepository;
  private final ActivityPlayerRepository activityPlayerRepository;
  private final WorkEventCoreRepository workEventCoreRepository;

  public Party resolve(final UpdatePostalAddressRequestArguments arguments) {

    final long partyId = arguments.getPartyId();

    final LinkedParty linkedParty = getCanonicalPartyId(partyId);

    return partyCoreRepository
        .findPartyInformationWithAddressTypesAndFunctions(
            linkedParty.getCanonicalPartyId(),
            Collections.singleton(AddressType.valueOf(arguments.getAddressType().toString())),
            Collections.singleton(
                AddressUsage.AddressFunction.valueOf(arguments.getFunction().toString())),
            arguments.getProcessTime())
        .orElseThrow(
            () ->
                new CustomerNotFoundException(
                    String.format("No record found in party database for party id %d", partyId)));
  }

  public void execute(final UpdatePostalAddressRequestArguments arguments, final Party party) {

    final LocalDateTime processTime = arguments.getProcessTime();

    log.info("Processing party: {}", arguments.getPartyId());

    updatePostalAddress(
        party,
        arguments.getAddressType(),
        arguments.getFunction(),
        arguments.getAddressLine1(),
        arguments.getAddressLine2(),
        arguments.getAddressLine3(),
        arguments.getAddressLine4(),
        arguments.getAddressLine5(),
        arguments.getCountry(),
        arguments.getAreaCode(),
        arguments.getDistrictCode(),
        arguments.getSectorCode(),
        arguments.getUnitCode(),
        arguments.getPafAddressKey(),
        arguments.getPafDeliveryPointSuffix(),
        processTime,
        arguments.getRequestMetadata());

    log.info("Processing party: {} - completed", arguments.getPartyId());
  }

  private void updatePostalAddress(
      final Party party,
      final PostalAddressType addressType,
      final AddressFunction function,
      final String addressLine1,
      final String addressLine2,
      final String addressLine3,
      final String addressLine4,
      final String addressLine5,
      final String country,
      final String areaCode,
      final String districtCode,
      final String sectorCode,
      final String unitCode,
      final Integer pafAddressKey,
      final String pafDeliveryPointSuffix,
      final LocalDateTime processTime,
      final RequestMetadata requestMetadata) {

    endCurrentPostalAddress(party, processTime);

    createNewPostalAddressEntries(
        party,
        AddressType.valueOf(addressType.toString()),
        AddressUsage.AddressFunction.valueOf(function.toString()),
        addressLine1,
        addressLine2,
        addressLine3,
        addressLine4,
        addressLine5,
        country,
        areaCode,
        districtCode,
        sectorCode,
        unitCode,
        pafAddressKey,
        pafDeliveryPointSuffix,
        processTime);

    partyCoreRepository.saveAndFlush(party);

    final AccountGroupedInfo accountGroupedInfo =
        accountService.getGroupedAccountInfo(requestMetadata, true);

    if (UK.equals(country) && pafAddressKey == null) {
      createAmendAddressSoThatItsPAFCompliantWorkEvent(party, accountGroupedInfo);
    }

    createCorrespondenceAddressHasBeenAmendedWorkEvent(party, processTime);

    createCheckPassbookAddressLabelToComputerWarningOnPostalAccounts(
        party, accountGroupedInfo, requestMetadata);
  }

  private void endCurrentPostalAddress(final Party party, final LocalDateTime processTime) {
    party
        .getAddresses()
        .forEach(
            address -> {
              address.setEndDate(processTime);
              address.setEndedDate(processTime);
              address.setEndedAt(CustomerProcessorConstants.AUDIT_AT);
              address.setEndedBy(CustomerProcessorConstants.AUDIT_BY);
              log.info(
                  "Ending address usage: {} for party: {}", address.getSysId(), party.getSysId());
              address.getFunctions().forEach(func -> func.setEndDate(processTime));
            });
  }

  private void createNewPostalAddressEntries(
      final Party party,
      final AddressType addressType,
      final AddressUsage.AddressFunction function,
      final String addressLine1,
      final String addressLine2,
      final String addressLine3,
      final String addressLine4,
      final String addressLine5,
      final String country,
      final String areaCode,
      final String districtCode,
      final String sectorCode,
      final String unitCode,
      final Integer pafAddressKey,
      final String pafDeliveryPointSuffix,
      final LocalDateTime processTime) {

    final Optional<PostalAddress> existingPostalAddress =
        findExistingPostalAddress(
            AddressType.valueOf(addressType.toString()),
            addressLine1,
            addressLine2,
            addressLine3,
            addressLine4,
            addressLine5,
            country,
            areaCode,
            districtCode,
            sectorCode,
            unitCode,
            pafAddressKey,
            pafDeliveryPointSuffix);

    if (existingPostalAddress.isPresent()) {
      final boolean existingMatchesCurrentPostalAddress =
          party.getAddresses().stream()
              .anyMatch(
                  address ->
                      address.getPostalAddress() != null
                          && address.getPostalAddress().equals(existingPostalAddress.get()));

      if (existingMatchesCurrentPostalAddress) {
        throw new CustomerServiceException("Address not changed");
      }
    }

    // Check for existing NPA record so we can copy preferred contact method to replacement record
    final Optional<AddressUsage> existingAu =
        party.getAddresses().stream()
            .filter(
                address ->
                    address.getPostalAddress() != null
                        && address.getPostalAddress().getType() == addressType)
            .findFirst();

    // Add new postal address plus associated entries
    final AddressUsage addressUsage =
        AddressUsage.builder()
            .function(function)
            .startDate(processTime)
            .createdDate(processTime)
            .createdAt(CustomerProcessorConstants.AUDIT_AT)
            .createdBy(CustomerProcessorConstants.AUDIT_BY)
            .party(party)
            .build();

    // Get the current setting for preferred contact method from the current postal address if
    // available
    existingAu.ifPresent(
        au -> addressUsage.setPreferredContactMethod(au.isPreferredContactMethod()));

    party.getAddresses().add(addressUsage);

    final PostalAddress postalAddress =
        existingPostalAddress.orElse(
            PostalAddress.builder()
                .line1(addressLine1)
                .line2(addressLine2)
                .line3(addressLine3)
                .line4(addressLine4)
                .line5(addressLine5)
                .country(Country.builder().code(country).build())
                .postCode(
                    PostCode.builder()
                        .areaCode(areaCode)
                        .districtCode(districtCode)
                        .sectorCode(sectorCode)
                        .unitCode(unitCode)
                        .build())
                .type(AddressType.valueOf(addressType.toString()))
                .pafAddressKey(pafAddressKey)
                .pafDps(pafDeliveryPointSuffix)
                .pafKeyPart3(pafAddressKey == null ? null : addressLine1.substring(0, 10).trim())
                .pafStatus(pafAddressKey == null ? PAF_STATUS_PAFNUS : PAF_STATUS_PAFSUC)
                .build());

    postalAddress.setUsages(Stream.of(addressUsage).collect(Collectors.toCollection(HashSet::new)));

    addressUsage.setPostalAddress(postalAddress);

    AddressUsageFunction addressUsageFunction =
        AddressUsageFunction.builder()
            .id(
                AddressUsageFunction.AddressUsageFunctionPK.builder()
                    .function(AddressUsage.AddressFunction.CORR)
                    .startDate(processTime)
                    .build())
            .addressUsage(addressUsage)
            .build();

    addressUsage.setFunctions(Collections.singleton(addressUsageFunction));
  }

  private Optional<PostalAddress> findExistingPostalAddress(
      final AddressType addressType,
      final String addressLine1,
      final String addressLine2,
      final String addressLine3,
      final String addressLine4,
      final String addressLine5,
      final String country,
      final String areaCode,
      final String districtCode,
      final String sectorCode,
      final String unitCode,
      final Integer pafAddressKey,
      final String pafDeliveryPointSuffix) {

    if (pafAddressKey == null) {
      return postalAddressRepository.findPostalAddressByAddressData(
          addressLine1,
          addressLine2,
          addressLine3,
          addressLine4,
          addressLine5,
          Country.builder().code(country).build(),
          addressType,
          areaCode,
          districtCode,
          sectorCode,
          unitCode);

    } else {
      final String pafKeyPart3 = addressLine1.substring(0, 10).trim();
      return postalAddressRepository.findPostalAddressByPafData(
          pafAddressKey, pafDeliveryPointSuffix, pafKeyPart3);
    }
  }

  private void createCheckPassbookAddressLabelToComputerWarningOnPostalAccounts(
      final Party party,
      final AccountGroupedInfo accountGroupedInfo,
      final RequestMetadata requestMetadata) {

    final List<AccountSummary> postalAccounts =
        accountGroupedInfo.getOwned() == null
            ? Collections.emptyList()
            : accountGroupedInfo.getOwned().getAccounts().stream()
                .filter(
                    acc ->
                        POSTAL_SAVINGS_ACCOUNT.equals(acc.getProductIdentifier())
                            || POSTAL_SAVINGS_ACCOUNT_MONTHLY_INTEREST.equals(
                                acc.getProductIdentifier()))
                .collect(Collectors.toList());

    for (AccountSummary account : postalAccounts) {

      log.info(
          "Found postal account for party: {}, account: {}",
          party.getSysId(),
          account.getAccountNumber());

      final List<Warning> warnings =
          accountService.getAccountWarnings(account.getAccountNumber(), requestMetadata);

      if (warnings.stream().noneMatch(w -> "CA".equals(w.getCode()))) {

        log.info(
            "Adding 'CA' restriction to postal savings account for party: {}, account: {}",
            party.getSysId(),
            account.getAccountNumber());
        accountService.postAccountWarning(
            account.getAccountNumber(), WarningCode.builder().code("CA").build(), requestMetadata);
      }
    }
  }

  private void createAmendAddressSoThatItsPAFCompliantWorkEvent(
      final Party party, final AccountGroupedInfo accountGroupedInfo) {

    // We need an account to pin the work event against
    final AccountSummary account =
        Stream.concat(
                accountGroupedInfo.getOwned() == null
                    ? Stream.empty()
                    : accountGroupedInfo.getOwned().getAccounts().stream(),
                accountGroupedInfo.getClosed() == null
                    ? Stream.empty()
                    : accountGroupedInfo.getClosed().getAccounts().stream())
            .findFirst()
            .orElseThrow(
                () ->
                    new CustomerServiceException(
                        "Cannot locate an account for party " + party.getSysId()));

    workEventService.createAdacusWorkEvent(
        party.getSysId(), Long.valueOf(account.getAccountNumber()));
  }

  private void createCorrespondenceAddressHasBeenAmendedWorkEvent(
      final Party party, final LocalDateTime processTime) {

    final EnumSet<WorkEventStatus> statuses =
        EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER);

    final List<ActivityPlayer> loanAccounts =
        activityPlayerRepository.findLendingAccountsForParty(party.getSysId(), processTime);

    loanAccounts.forEach(
        account -> {
          final Long accountTypeCode =
              account.getLoanAccountTypeCode() == null ? 80L : account.getLoanAccountTypeCode();

          log.info(
              "Found open lending account for party: {}, lending account: {}",
              party.getSysId(),
              account.getTableSysId() + accountTypeCode);

          final List<Long> existingWorkEvents =
              workEventCoreRepository.findWorkEvents(
                  WorkEventContextTableName.LOANAC,
                  account.getTableSysId(),
                  accountTypeCode,
                  statuses,
                  ModuleLabelAssociationType.CREEVT,
                  "CHCAMO",
                  "CUS0503U",
                  processTime);

          if (existingWorkEvents.isEmpty()) {

            workEventService.createChcamoWorkEvent(
                party.getSysId(), account.getTableSysId(), accountTypeCode, processTime);
          }
        });
  }

  public void auditSuccess(final UpdatePostalAddressRequestArguments arguments) {

    final AuditPostalAddressUpdateSuccessRequest auditRequest =
        AuditPostalAddressUpdateSuccessRequest.builder()
            .ipAddress(arguments.getRequestMetadata().getIpAddress())
            .postalAddressRequest(buildPostalAddressRequest(arguments))
            .build();

    auditService.auditPostalAddressUpdateSuccess(auditRequest, arguments.getRequestMetadata());
  }

  private PermittedCountries getPermittedCountriesEnum(final String country) {

    return Arrays.stream(PermittedCountries.values())
        .filter(e -> e.getCode().equals(country))
        .findFirst()
        .orElseThrow(
            () -> new IllegalStateException(String.format("Unsupported type %s.", country)));
  }

  public void auditFailure(
      final UpdatePostalAddressRequestArguments arguments, final String message) {

    final AuditPostalAddressUpdateFailureRequest auditRequest =
        AuditPostalAddressUpdateFailureRequest.builder()
            .ipAddress(arguments.getRequestMetadata().getIpAddress())
            .message(message)
            .postalAddressRequest(buildPostalAddressRequest(arguments))
            .build();

    auditService.auditPostalAddressUpdateFailure(auditRequest, arguments.getRequestMetadata());
  }

  private PostalAddressRequest buildPostalAddressRequest(
      final UpdatePostalAddressRequestArguments arguments) {
    return PostalAddressRequest.builder()
        .address(
            uk.co.ybs.digital.customer.web.dto.PostalAddress.builder()
                .type(
                    uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressType.valueOf(
                        arguments.getFunction().toString()))
                .subType(
                    uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressSubType.valueOf(
                        arguments.getAddressType().toString()))
                .addressLines(
                    Stream.of(
                            arguments.getAddressLine1(),
                            arguments.getAddressLine2(),
                            arguments.getAddressLine3(),
                            arguments.getAddressLine4(),
                            arguments.getAddressLine5())
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList()))
                .postCode(
                    formatPostcode(
                        arguments.getAreaCode(),
                        arguments.getDistrictCode(),
                        arguments.getSectorCode(),
                        arguments.getUnitCode()))
                .country(getPermittedCountriesEnum(arguments.getCountry()))
                .build())
        .paf(
            uk.co.ybs.digital.customer.web.dto.PafData.builder()
                .addressKey(
                    arguments.getPafAddressKey() == null ? null : arguments.getPafAddressKey())
                .deliveryPointSuffix(arguments.getPafDeliveryPointSuffix())
                .build())
        .build();
  }

  private LinkedParty getCanonicalPartyId(final long partyId) {

    return partyCoreRepository
        .findCanonicalPartyId(partyId)
        .orElseThrow(
            () ->
                (new CustomerNotFoundException(
                    String.format("No record found in party database for party id %d", partyId))));
  }
}
