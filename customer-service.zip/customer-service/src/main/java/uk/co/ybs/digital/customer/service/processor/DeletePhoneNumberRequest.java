package uk.co.ybs.digital.customer.service.processor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.customer.model.core.Party;

@AllArgsConstructor
@EqualsAndHashCode
@Builder
@ToString
public class DeletePhoneNumberRequest implements CustomerRequest {

  @NonNull private final DeletePhoneNumberRequestArguments arguments;
  @NonNull private final DeletePhoneNumberProcessor processor;

  @Override
  public ResolvedCustomerRequest resolve() {

    final Party party = processor.resolve(arguments);

    return new ResolvedDeletePhoneNumberRequest(arguments, processor, party);
  }

  @Override
  public void auditFailure(final String message) {
    processor.auditFailure(arguments, message);
  }
}
