package uk.co.ybs.digital.customer.model.core;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.ToString;

@Entity
@Table(name = "PEOPLE")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Person {

  @Id
  @Column(name = "PARTY_SYSID")
  private Long partyId;

  @Column(name = "TITLE_ABBR")
  private String title;

  @NonNull
  @Column(name = "FORENAMES")
  private String forenames;

  @NonNull
  @Column(name = "SURNAME")
  private String surname;

  @Column(name = "DATE_OF_DEATH")
  private LocalDate dateOfDeath;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Column(name = "NATIONAL_INS_NUM")
  private String nationalInsuranceNumber;

  @Column(name = "DATE_OF_BIRTH")
  private LocalDate dateOfBirth;

  @MapsId @OneToOne @ToString.Exclude private Party party;
}
