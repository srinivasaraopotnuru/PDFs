package uk.co.ybs.digital.customer.config;

import java.util.Arrays;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.security.oauth2.jwt.Jwt;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiKey;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import uk.co.ybs.digital.security.HttpHeaderNames;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
  public static final String SECURITY_SCHEME = "digital-oauth2";
  public static final String HEADER = "header";

  @Bean
  public Docket api() {
    return new Docket(DocumentationType.SWAGGER_2)
        .select()
        .apis(RequestHandlerSelectors.basePackage("uk.co.ybs.digital"))
        .paths(PathSelectors.any())
        .build()
        .pathMapping("/customer")
        .globalOperationParameters(
            Arrays.asList(
                new ParameterBuilder()
                    .name("x-ybs-request-id")
                    .description("Unique identifier for the request")
                    .modelRef(new ModelRef("uuid"))
                    .parameterType(HEADER)
                    .required(false)
                    .build(),
                new ParameterBuilder()
                    .name(HttpHeaderNames.REQUEST_SIGNATURE)
                    .description("Base64 encoded request signature")
                    .modelRef(new ModelRef("string"))
                    .parameterType(HEADER)
                    .required(true)
                    .build(),
                new ParameterBuilder()
                    .name(HttpHeaderNames.REQUEST_SIGNATURE_KEY_ID)
                    .description("Identifier for the key used to sign the request")
                    .modelRef(new ModelRef("string"))
                    .parameterType(HEADER)
                    .required(true)
                    .build()))
        .ignoredParameterTypes(Jwt.class)
        .securitySchemes(
            Arrays.asList(new ApiKey(SECURITY_SCHEME, HttpHeaders.AUTHORIZATION, "header")));
  }
}
