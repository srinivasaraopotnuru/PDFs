package uk.co.ybs.digital.customer.web.dto;

import io.swagger.annotations.ApiModelProperty;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.customer.web.NonEmptyString;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PafData {
  @NotNull(message = "You must specify an address key")
  @ApiModelProperty(required = true, example = "35564761")
  Integer addressKey;

  @NotNull(message = "You must specify a delivery point suffix")
  @NonEmptyString(
      message = "Delivery Point Suffix must contain at least one non-whitespace character")
  @ApiModelProperty(required = true, example = "2TA")
  String deliveryPointSuffix;
}
