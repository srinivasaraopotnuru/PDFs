package uk.co.ybs.digital.customer.exception;

public class CustomerServiceException extends RuntimeException {

  private static final long serialVersionUID = -6700858473639755100L;

  public CustomerServiceException(final String message) {
    super(message);
  }

  public CustomerServiceException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
