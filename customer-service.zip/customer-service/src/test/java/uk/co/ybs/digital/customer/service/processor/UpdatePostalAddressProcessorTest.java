package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFNUS;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFSUC;
import static uk.co.ybs.digital.customer.service.utilities.PostCodeHelper.formatPostcode;
import static uk.co.ybs.digital.customer.utils.TestHelper.addressUsageMatcher;
import static uk.co.ybs.digital.customer.utils.TestHelper.postalAddressMatcher;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.core.ActivityPlayer;
import uk.co.ybs.digital.customer.model.core.ActivityType;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.core.PostalAddress;
import uk.co.ybs.digital.customer.model.core.WorkEvent.ModuleLabelAssociationType;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventContextTableName;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventStatus;
import uk.co.ybs.digital.customer.model.digitalcustomer.AddressFunction;
import uk.co.ybs.digital.customer.model.digitalcustomer.PostalAddressType;
import uk.co.ybs.digital.customer.repository.core.ActivityPlayerRepository;
import uk.co.ybs.digital.customer.repository.core.PartyCoreRepository;
import uk.co.ybs.digital.customer.repository.core.PostalAddressRepository;
import uk.co.ybs.digital.customer.repository.core.WorkEventCoreRepository;
import uk.co.ybs.digital.customer.service.WorkEventService;
import uk.co.ybs.digital.customer.service.account.AccountService;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountGroup;
import uk.co.ybs.digital.customer.service.account.dto.Warning;
import uk.co.ybs.digital.customer.service.account.dto.WarningCode;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class UpdatePostalAddressProcessorTest {

  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final long LINKED_PARTY_ID = 100000L;
  private static final long PARTY_ID = 123456L;
  private static final Long LOAN_ACCOUNT_NUMBER = 12345678L;
  private static final Integer LOAN_ACCOUNT_TYPE_CODE = 80;

  public static final String POSTAL_SAVINGS_ACCOUNT_PRODUCT = "POSTALSAVE";
  public static final String POSTAL_SAVINGS_ACCOUNT_MONTHLY_INTEREST_PRODUCT = "POSTSAVMIA";

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-09-01T00:00:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);

  public static final LocalDateTime YESTERDAY = NOW.minusDays(1);
  public static final String POSTAL_SAVINGS_ACCOUNT_NUMBER = "1000000001";
  public static final String POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER = "1000000002";
  public static final String OPEN_ACCOUNT_NUMBER = "10000000";
  public static final String CLOSED_ACCOUNT_NUMBER = "20000000";

  @Mock private AuditService auditService;

  @Mock private AccountService accountService;

  @Mock private WorkEventService workEventService;

  @Mock private PartyCoreRepository partyCoreRepository;

  @Mock private PostalAddressRepository postalAddressRepository;

  @Mock private ActivityPlayerRepository activityPlayerRepository;

  @Mock private WorkEventCoreRepository workEventCoreRepository;

  @InjectMocks private UpdatePostalAddressProcessor testSubject;

  @Captor private ArgumentCaptor<Party> savedParty;

  private static Stream<Arguments> postalAddressArguments() {
    return Stream.of(
        Arguments.of(TestHelper.buildPostalAddressRequest(), AddressUsage.AddressFunction.CORR),
        Arguments.of(
            TestHelper.buildPostalAddressWithPafRequest(), AddressUsage.AddressFunction.CORR));
  }

  private static UpdatePostalAddressRequestArguments buildPostalAddressRequestArguments(
      final RequestMetadata requestMetadata,
      final PostalAddress postalAddress,
      final AddressUsage.AddressFunction addressFunction) {
    return UpdatePostalAddressRequestArguments.builder()
        .partyId(PARTY_ID)
        .requestMetadata(requestMetadata)
        .processTime(PROCESS_TIME)
        .addressType(PostalAddressType.valueOf(postalAddress.getType().toString()))
        .function(AddressFunction.valueOf(addressFunction.toString()))
        .addressLine1(postalAddress.getLine1())
        .addressLine2(postalAddress.getLine2())
        .addressLine3(postalAddress.getLine3())
        .addressLine4(postalAddress.getLine4())
        .addressLine5(postalAddress.getLine5())
        .country(postalAddress.getCountry().getCode())
        .areaCode(postalAddress.getPostCode().getAreaCode())
        .districtCode(postalAddress.getPostCode().getDistrictCode())
        .sectorCode(postalAddress.getPostCode().getSectorCode())
        .unitCode(postalAddress.getPostCode().getUnitCode())
        .pafAddressKey(postalAddress.getPafAddressKey())
        .pafDeliveryPointSuffix(postalAddress.getPafDps())
        .build();
  }

  private static AccountGroupedInfo.AccountSummary buildAccount() {
    return buildAccount("1234567890");
  }

  private static AccountGroupedInfo.AccountSummary buildAccount(final String accountNumber) {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber(accountNumber)
        .accountName("Test")
        .amendmentRestriction(true)
        .accountSortCode("123456")
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .deposits(AccountGroupedInfo.DepositsSummary.builder().permittedOverApi(true).build())
        .withdrawals(AccountGroupedInfo.WithdrawalsSummary.builder().permittedOverApi(true).build())
        .currency("GBP")
        .productIdentifier("test")
        .productDescription("Monthly Regular Saver: Issue 2")
        .isa(AccountGroupedInfo.Isa.builder().flexible(true).helpToBuy(false).build())
        .balances(
            Collections.singletonList(
                AccountGroupedInfo.Balance.builder()
                    .type("InterimAvailable")
                    .amount(new BigDecimal("100.00"))
                    .build()))
        .build();
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void resolveShouldReturnParty(
      final PostalAddress postalAddress, final AddressUsage.AddressFunction addressFunction) {

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), postalAddress, addressFunction);

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress), Collections.singletonList(addressFunction));

    final LinkedParty linkedParty = stubLinkedParty(PARTY_ID, LINKED_PARTY_ID);

    when(partyCoreRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(linkedParty.getCanonicalPartyId()),
            eq(Collections.singleton(postalAddress.getType())),
            eq(Collections.singleton(addressFunction)),
            eq(PROCESS_TIME)))
        .thenReturn(Optional.of(party));

    final Party resolvedParty = testSubject.resolve(arguments);

    assertThat(resolvedParty, is(party));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void resolveShouldCustomerNotFoundExceptionWhenNoCanonicalParty(
      final PostalAddress postalAddress, final AddressUsage.AddressFunction addressFunction) {
    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), postalAddress, addressFunction);

    when(partyCoreRepository.findCanonicalPartyId(PARTY_ID)).thenReturn(Optional.empty());

    final CustomerNotFoundException exception =
        assertThrows(CustomerNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("No record found in party database for party id 123456"));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void resolveShouldCustomerNotFoundExceptionWhenCoreRepositoryReturnsEmpty(
      final PostalAddress postalAddress, final AddressUsage.AddressFunction addressFunction) {
    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), postalAddress, addressFunction);

    final LinkedParty linkedParty = stubLinkedParty(PARTY_ID, LINKED_PARTY_ID);

    when(partyCoreRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(linkedParty.getCanonicalPartyId()),
            eq(Collections.singleton(postalAddress.getType())),
            eq(Collections.singleton(addressFunction)),
            eq(PROCESS_TIME)))
        .thenReturn(Optional.empty());

    final CustomerNotFoundException exception =
        assertThrows(CustomerNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("No record found in party database for party id 123456"));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void executeShouldEndOldPostalAddressAndCreateNewPostalAddress(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress), Collections.singletonList(addressFunction));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    setExistingPostalAddressExpectation(updatedPostalAddress, true);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(AccountGroup.builder().account(buildAccount()).build())
            .build();

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            buildOriginalAddressEndedMatcher(addressFunction, postalAddress),
            buildUpdatedAddressEndedMatcher(addressFunction, updatedPostalAddress, true)));
  }

  @ParameterizedTest
  @MethodSource("postalAddressADACUSArguments")
  void executeShouldCreateAdacusWorkEventWhenCustomerHasOpenAndClosedAccounts(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction,
      final boolean onlyClosedAccounts) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress), Collections.singletonList(addressFunction));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    setExistingPostalAddressExpectation(updatedPostalAddress, true);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(
                onlyClosedAccounts
                    ? null
                    : AccountGroup.builder().account(buildAccount(OPEN_ACCOUNT_NUMBER)).build())
            .closed(AccountGroup.builder().account(buildAccount(CLOSED_ACCOUNT_NUMBER)).build())
            .build();

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    verify(workEventService)
        .createAdacusWorkEvent(
            eq(party.getSysId()),
            eq(Long.valueOf(onlyClosedAccounts ? CLOSED_ACCOUNT_NUMBER : OPEN_ACCOUNT_NUMBER)));

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            buildOriginalAddressEndedMatcher(addressFunction, postalAddress),
            buildUpdatedAddressEndedMatcher(addressFunction, updatedPostalAddress, true)));
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void executeShouldEndMultipleOldPostalAddressAndCreateNewPostalAddress(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction) {
    // Although an account should only ever have a single correspondence we have a data
    // quality issue where multiple can exist.  In this case both should be ended and the
    // new phone number created.
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Arrays.asList(postalAddress, postalAddress),
            Arrays.asList(addressFunction, addressFunction));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(AccountGroup.builder().account(buildAccount()).build())
            .build();

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            buildOriginalAddressEndedMatcher(addressFunction, postalAddress),
            addressUsageMatcher(
                addressFunction,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                null,
                anyOf(nullValue()),
                postalAddressMatcher(
                    anyOf(nullValue()),
                    postalAddress.getType(),
                    postalAddress.getLine1(),
                    postalAddress.getLine2(),
                    postalAddress.getLine3(),
                    postalAddress.getLine4(),
                    postalAddress.getLine5(),
                    postalAddress.getPostCode(),
                    postalAddress.getCountry(),
                    null,
                    null,
                    null,
                    null,
                    null)),
            buildUpdatedAddressEndedMatcher(addressFunction, updatedPostalAddress, true)));
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void executeShouldCreateNewPostalAddressWhenNoCurrentAddressExists(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.emptyList(), Collections.emptyList());

    party.getAddresses().clear(); // Remove any postal addresses

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(AccountGroup.builder().account(buildAccount()).build())
            .build();

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(buildUpdatedAddressEndedMatcher(addressFunction, updatedPostalAddress, false)));
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void auditSuccessShouldCallAuditService(
      final PostalAddress postalAddress, final AddressUsage.AddressFunction addressFunction) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(requestMetadata, postalAddress, addressFunction);

    testSubject.auditSuccess(arguments);

    final AuditPostalAddressUpdateSuccessRequest auditRequest =
        AuditPostalAddressUpdateSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .postalAddressRequest(
                PostalAddressRequest.builder()
                    .address(
                        uk.co.ybs.digital.customer.web.dto.PostalAddress.builder()
                            .type(
                                uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressType
                                    .CORR)
                            .subType(
                                uk.co.ybs.digital.customer.web.dto.PostalAddress
                                    .PostalAddressSubType.UKPOST)
                            .addressLines(
                                Stream.of(
                                        arguments.getAddressLine1(),
                                        arguments.getAddressLine2(),
                                        arguments.getAddressLine3(),
                                        arguments.getAddressLine4(),
                                        arguments.getAddressLine5())
                                    .filter(Objects::nonNull)
                                    .collect(Collectors.toList()))
                            .postCode(
                                formatPostcode(
                                    arguments.getAreaCode(),
                                    arguments.getDistrictCode(),
                                    arguments.getSectorCode(),
                                    arguments.getUnitCode()))
                            .country(
                                uk.co.ybs.digital.customer.web.dto.PermittedCountries
                                    .UNITED_KINGDOM)
                            .build())
                    .paf(
                        uk.co.ybs.digital.customer.web.dto.PafData.builder()
                            .addressKey(
                                arguments.getPafAddressKey() == null
                                    ? null
                                    : arguments.getPafAddressKey())
                            .deliveryPointSuffix(arguments.getPafDeliveryPointSuffix())
                            .build())
                    .build())
            .build();

    verify(auditService).auditPostalAddressUpdateSuccess(auditRequest, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void auditFailureShouldCallAuditService(
      final PostalAddress postalAddress, final AddressUsage.AddressFunction addressFunction) {

    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(requestMetadata, postalAddress, addressFunction);

    testSubject.auditFailure(arguments, TestHelper.TECHNICAL_FAILURE_MESSAGE);

    final AuditPostalAddressUpdateFailureRequest auditRequest =
        AuditPostalAddressUpdateFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(TestHelper.TECHNICAL_FAILURE_MESSAGE)
            .postalAddressRequest(
                PostalAddressRequest.builder()
                    .address(
                        uk.co.ybs.digital.customer.web.dto.PostalAddress.builder()
                            .type(
                                uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressType
                                    .CORR)
                            .subType(
                                uk.co.ybs.digital.customer.web.dto.PostalAddress
                                    .PostalAddressSubType.UKPOST)
                            .addressLines(
                                Stream.of(
                                        arguments.getAddressLine1(),
                                        arguments.getAddressLine2(),
                                        arguments.getAddressLine3(),
                                        arguments.getAddressLine4(),
                                        arguments.getAddressLine5())
                                    .filter(Objects::nonNull)
                                    .collect(Collectors.toList()))
                            .postCode(
                                formatPostcode(
                                    arguments.getAreaCode(),
                                    arguments.getDistrictCode(),
                                    arguments.getSectorCode(),
                                    arguments.getUnitCode()))
                            .country(
                                uk.co.ybs.digital.customer.web.dto.PermittedCountries
                                    .UNITED_KINGDOM)
                            .build())
                    .paf(
                        uk.co.ybs.digital.customer.web.dto.PafData.builder()
                            .addressKey(
                                arguments.getPafAddressKey() == null
                                    ? null
                                    : arguments.getPafAddressKey())
                            .deliveryPointSuffix(arguments.getPafDeliveryPointSuffix())
                            .build())
                    .build())
            .build();

    verify(auditService).auditPostalAddressUpdateFailure(auditRequest, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void executeShouldCreateNewAddressUsageWithExistingPostalAddress(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress), Collections.singletonList(addressFunction));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    setExistingPostalAddressExpectation(
        updatedPostalAddress.toBuilder().sysId(123L).build(), false);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(AccountGroup.builder().account(buildAccount()).build())
            .build();

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            buildOriginalAddressEndedMatcher(addressFunction, postalAddress),
            addressUsageMatcher(
                addressFunction,
                PROCESS_TIME,
                null,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                null,
                anyOf(nullValue()),
                postalAddressMatcher(
                    anyOf(is(123L)),
                    updatedPostalAddress.getType(),
                    updatedPostalAddress.getLine1(),
                    updatedPostalAddress.getLine2(),
                    updatedPostalAddress.getLine3(),
                    updatedPostalAddress.getLine4(),
                    updatedPostalAddress.getLine5(),
                    updatedPostalAddress.getPostCode(),
                    updatedPostalAddress.getCountry(),
                    updatedPostalAddress.getPafAddressKey() == null
                        ? PAF_STATUS_PAFNUS
                        : PAF_STATUS_PAFSUC,
                    updatedPostalAddress.getPafAddressKey(),
                    updatedPostalAddress.getPafDps(),
                    updatedPostalAddress.getPafAddressKey() == null
                        ? null
                        : updatedPostalAddress.getLine1().substring(0, 10).trim(),
                    null))));
  }

  @Test
  void executeShouldFailWithAddressNotChangedWhenNewAddressMatchesExisting() {

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress),
            Collections.singletonList(AddressUsage.AddressFunction.CORR));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), postalAddress, AddressUsage.AddressFunction.CORR);

    setExistingPostalAddressExpectation(postalAddress, false);

    final CustomerServiceException exception =
        assertThrows(CustomerServiceException.class, () -> testSubject.execute(arguments, party));

    assertThat(exception.getMessage(), is("Address not changed"));
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void executeShouldEndOldPostalAddressAndCreateNewPostalAddressWithChcamoWorkEvent(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress), Collections.singletonList(addressFunction));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    setExistingPostalAddressExpectation(updatedPostalAddress, true);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(AccountGroup.builder().account(buildAccount()).build())
            .build();

    final ActivityType type = ActivityType.builder().code("MHLDRM").build();
    final ActivityPlayer activityPlayer =
        ActivityPlayer.builder()
            .sysId(1L)
            .tableId("ACCGRP")
            .activityType(type)
            .tableSysId(12345678L)
            .partySysId(PARTY_ID)
            .startDate(PROCESS_TIME)
            .build();

    final EnumSet<WorkEventStatus> statuses =
        EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER);

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    when(activityPlayerRepository.findLendingAccountsForParty(PARTY_ID, PROCESS_TIME))
        .thenReturn(Collections.singletonList(activityPlayer));

    when(workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            LOAN_ACCOUNT_NUMBER,
            LOAN_ACCOUNT_TYPE_CODE.longValue(),
            statuses,
            ModuleLabelAssociationType.CREEVT,
            "CHCAMO",
            "CUS0503U",
            PROCESS_TIME))
        .thenReturn(Collections.emptyList());

    testSubject.execute(arguments, party);

    verify(workEventService)
        .createChcamoWorkEvent(
            PARTY_ID, LOAN_ACCOUNT_NUMBER, LOAN_ACCOUNT_TYPE_CODE.longValue(), PROCESS_TIME);
    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            buildOriginalAddressEndedMatcher(addressFunction, postalAddress),
            buildUpdatedAddressEndedMatcher(addressFunction, updatedPostalAddress, true)));
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void executeShouldEndOldAndCreateNewPostalAddressNoChcamoWorkEventAsAlreadyExists(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress), Collections.singletonList(addressFunction));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    setExistingPostalAddressExpectation(updatedPostalAddress, true);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(AccountGroup.builder().account(buildAccount()).build())
            .build();

    final ActivityType type = ActivityType.builder().code("MHLDRM").build();
    final ActivityPlayer activityPlayer =
        ActivityPlayer.builder()
            .sysId(1L)
            .tableId("ACCGRP")
            .activityType(type)
            .tableSysId(12345678L)
            .partySysId(PARTY_ID)
            .startDate(PROCESS_TIME)
            .build();

    final EnumSet<WorkEventStatus> statuses =
        EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER);

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    when(activityPlayerRepository.findLendingAccountsForParty(PARTY_ID, PROCESS_TIME))
        .thenReturn(Collections.singletonList(activityPlayer));

    when(workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            LOAN_ACCOUNT_NUMBER,
            LOAN_ACCOUNT_TYPE_CODE.longValue(),
            statuses,
            ModuleLabelAssociationType.CREEVT,
            "CHCAMO",
            "CUS0503U",
            PROCESS_TIME))
        .thenReturn(Collections.singletonList(1L));

    testSubject.execute(arguments, party);

    verify(workEventService, never()).createChcamoWorkEvent(any(), any(), any(), any());
    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            buildOriginalAddressEndedMatcher(addressFunction, postalAddress),
            buildUpdatedAddressEndedMatcher(addressFunction, updatedPostalAddress, true)));
  }

  @ParameterizedTest
  @MethodSource("postalAddressArguments") // NOPMD
  void executeShouldEndOldAndCreateNewPostalAddressNoChcamoWorkEventAsNoLoanAccounts(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress), Collections.singletonList(addressFunction));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    setExistingPostalAddressExpectation(updatedPostalAddress, true);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(AccountGroup.builder().account(buildAccount()).build())
            .build();

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    when(activityPlayerRepository.findLendingAccountsForParty(PARTY_ID, PROCESS_TIME))
        .thenReturn(Collections.emptyList());

    testSubject.execute(arguments, party);

    verifyNoInteractions(workEventCoreRepository);
    verify(workEventService, never()).createChcamoWorkEvent(any(), any(), any(), any());
    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            buildOriginalAddressEndedMatcher(addressFunction, postalAddress),
            buildUpdatedAddressEndedMatcher(addressFunction, updatedPostalAddress, true)));
  }

  @ParameterizedTest
  @MethodSource("postalAddressArgumentsWithAccountWarnings")
  void executeShouldProcessPostalAccountsWithWarnings(
      final PostalAddress updatedPostalAddress,
      final AddressUsage.AddressFunction addressFunction,
      final List<Warning> accountWarnings) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.emptyList(), Collections.emptyList());

    party.getAddresses().clear(); // Remove any postal addresses

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(), updatedPostalAddress, addressFunction);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(
                AccountGroup.builder()
                    .account(
                        TestHelper.buildAccount(
                            POSTAL_SAVINGS_ACCOUNT_NUMBER, POSTAL_SAVINGS_ACCOUNT_PRODUCT))
                    .account(
                        TestHelper.buildAccount(
                            POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER,
                            POSTAL_SAVINGS_ACCOUNT_MONTHLY_INTEREST_PRODUCT))
                    .build())
            .build();

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    when(accountService.getAccountWarnings(POSTAL_SAVINGS_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(accountWarnings);

    when(accountService.getAccountWarnings(
            POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER, requestMetadata))
        .thenReturn(accountWarnings);

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    if (accountWarnings.stream().noneMatch(x -> "CA".equals(x.getCode()))) {
      WarningCode warningCode = WarningCode.builder().code("CA").build();
      verify(accountService)
          .postAccountWarning(POSTAL_SAVINGS_ACCOUNT_NUMBER, warningCode, requestMetadata);
      verify(accountService)
          .postAccountWarning(
              POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER, warningCode, requestMetadata);
    }

    Party actualSavedParty = savedParty.getValue();

    verifyNoMoreInteractions(accountService);

    assertThat(
        actualSavedParty.getAddresses(),
        contains(buildUpdatedAddressEndedMatcher(addressFunction, updatedPostalAddress, false)));
  }

  @Test
  void executeShouldFailWhenAddressNotPafdAndNoAccountFound() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    PostalAddress updatedPostalAddress = TestHelper.buildPostalAddressRequest();

    PostalAddress postalAddress = TestHelper.buildBasePostalAddressRequest();

    final Party party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(postalAddress),
            Collections.singletonList(AddressUsage.AddressFunction.CORR));

    final UpdatePostalAddressRequestArguments arguments =
        buildPostalAddressRequestArguments(
            TestHelper.createRequestMetadata(),
            updatedPostalAddress,
            AddressUsage.AddressFunction.CORR);

    setExistingPostalAddressExpectation(updatedPostalAddress, true);

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder().owned(AccountGroup.builder().build()).build();

    when(accountService.getGroupedAccountInfo(requestMetadata, true))
        .thenReturn(accountGroupedInfo);

    final CustomerServiceException exception =
        assertThrows(CustomerServiceException.class, () -> testSubject.execute(arguments, party));

    assertThat(exception.getMessage(), is("Cannot locate an account for party 123456"));
  }

  private LinkedParty stubLinkedParty(final Long originalPartyId, final Long canonicalPartyId) {

    final LinkedParty linkedParty =
        LinkedParty.builder()
            .originalPartyId(originalPartyId)
            .canonicalPartyId(canonicalPartyId)
            .linkCount(1L)
            .build();

    when(partyCoreRepository.findCanonicalPartyId(originalPartyId))
        .thenReturn(Optional.of(linkedParty));

    return linkedParty;
  }

  private void setExistingPostalAddressExpectation(
      final PostalAddress updatedPostalAddress, final boolean returnEmpty) {

    if (updatedPostalAddress.getPafAddressKey() == null) {

      when(postalAddressRepository.findPostalAddressByAddressData(
              updatedPostalAddress.getLine1(),
              updatedPostalAddress.getLine2(),
              updatedPostalAddress.getLine3(),
              updatedPostalAddress.getLine4(),
              updatedPostalAddress.getLine5(),
              updatedPostalAddress.getCountry(),
              updatedPostalAddress.getType(),
              updatedPostalAddress.getPostCode().getAreaCode(),
              updatedPostalAddress.getPostCode().getDistrictCode(),
              updatedPostalAddress.getPostCode().getSectorCode(),
              updatedPostalAddress.getPostCode().getUnitCode()))
          .thenReturn(returnEmpty ? Optional.empty() : Optional.of(updatedPostalAddress));
    } else {
      when(postalAddressRepository.findPostalAddressByPafData(
              updatedPostalAddress.getPafAddressKey(),
              updatedPostalAddress.getPafDps(),
              updatedPostalAddress.getLine1().substring(0, 10).trim()))
          .thenReturn(returnEmpty ? Optional.empty() : Optional.of(updatedPostalAddress));
    }
  }

  private Matcher<AddressUsage> buildOriginalAddressEndedMatcher(
      final AddressUsage.AddressFunction addressFunction, final PostalAddress postalAddress) {
    return addressUsageMatcher(
        addressFunction,
        YESTERDAY,
        PROCESS_TIME,
        YESTERDAY,
        TestHelper.AUDIT_AT,
        TestHelper.AUDIT_BY,
        PROCESS_TIME,
        TestHelper.AUDIT_AT,
        TestHelper.AUDIT_BY,
        true,
        null,
        anyOf(nullValue()),
        postalAddressMatcher(
            anyOf(nullValue()),
            AddressType.UKPOST,
            postalAddress.getLine1(),
            postalAddress.getLine2(),
            postalAddress.getLine3(),
            postalAddress.getLine4(),
            postalAddress.getLine5(),
            postalAddress.getPostCode(),
            postalAddress.getCountry(),
            null,
            null,
            null,
            null,
            null));
  }

  private Matcher<AddressUsage> buildUpdatedAddressEndedMatcher(
      final AddressUsage.AddressFunction addressFunction,
      final PostalAddress updatedPostalAddress,
      final boolean preferredContactMethod) {
    return addressUsageMatcher(
        addressFunction,
        PROCESS_TIME,
        null,
        PROCESS_TIME,
        TestHelper.AUDIT_AT,
        TestHelper.AUDIT_BY,
        null,
        null,
        null,
        preferredContactMethod,
        null,
        anyOf(nullValue()),
        postalAddressMatcher(
            anyOf(nullValue()),
            updatedPostalAddress.getType(),
            updatedPostalAddress.getLine1(),
            updatedPostalAddress.getLine2(),
            updatedPostalAddress.getLine3(),
            updatedPostalAddress.getLine4(),
            updatedPostalAddress.getLine5(),
            updatedPostalAddress.getPostCode(),
            updatedPostalAddress.getCountry(),
            updatedPostalAddress.getPafStatus(),
            updatedPostalAddress.getPafAddressKey(),
            updatedPostalAddress.getPafDps(),
            updatedPostalAddress.getPafKeyPart3(),
            updatedPostalAddress.getPafReturnCode()));
  }

  private static Stream<Arguments> postalAddressArgumentsWithAccountWarnings() {

    List<Warning> warnings = Collections.singletonList(Warning.builder().code("ZX").build());

    List<Warning> warningsIncludingCA =
        Arrays.asList(Warning.builder().code("ZX").build(), Warning.builder().code("CA").build());

    return Stream.of(
        Arguments.of(
            TestHelper.buildPostalAddressRequest(), AddressUsage.AddressFunction.CORR, warnings),
        Arguments.of(
            TestHelper.buildPostalAddressRequest(),
            AddressUsage.AddressFunction.CORR,
            warningsIncludingCA));
  }

  private static Stream<Arguments> postalAddressADACUSArguments() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildPostalAddressRequest(), AddressUsage.AddressFunction.CORR, true),
        Arguments.of(
            TestHelper.buildPostalAddressRequest(), AddressUsage.AddressFunction.CORR, false));
  }
}
