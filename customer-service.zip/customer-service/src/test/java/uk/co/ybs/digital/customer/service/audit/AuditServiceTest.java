package uk.co.ybs.digital.customer.service.audit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.customer.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.json.JSONException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationCheckRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditCustomerDetailsViewRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@JsonTest
class AuditServiceTest {

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Audit service returned error status: ";
  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String EMAIL_ADDRESS = "customer@provider.com";
  private static final String BEARER = "Bearer ";

  private AuditService auditService;
  private MockWebServer mockWebServer;

  @Autowired private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();

    final WebClient webClient =
        WebClient.builder()
            .baseUrl("http://localhost:" + mockWebServer.getPort())
            .codecs(
                configurer -> {
                  configurer
                      .defaultCodecs()
                      .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                  configurer
                      .defaultCodecs()
                      .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                })
            .build();
    auditService = new AuditService(webClient);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void shouldAuditCustomerDetailsView() throws Exception {
    final AuditCustomerDetailsViewRequest request = buildAuditCustomerDetailsViewRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditCustomerDetailsView(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/customer/view"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody = readClassPathResource("api/auditService/request/request.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("auditMethods")
  void shouldThrowAuditServiceExceptionForConnectionError(
      final Function<AuditService, Executable> auditMethod) throws IOException {
    mockWebServer.shutdown();

    final AuditServiceException exception =
        assertThrows(AuditServiceException.class, auditMethod.apply(auditService));
    assertThat(exception.getMessage(), is(equalTo("Error calling audit service")));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  private static Stream<Function<AuditService, Executable>> auditMethods() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    return Stream.of(
        service ->
            () ->
                service.auditCustomerDetailsView(
                    buildAuditCustomerDetailsViewRequest(), requestMetadata));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses")
  void auditAccountListShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuditCustomerDetailsViewRequest auditRequest = buildAuditCustomerDetailsViewRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditCustomerDetailsView(auditRequest, requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> auditServiceErrorResponses() {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/errorResponseInvalidSignature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/errorResponseBadRequest.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400"),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/unexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/emptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "400")));
  }

  private static AuditCustomerDetailsViewRequest buildAuditCustomerDetailsViewRequest() {
    return AuditCustomerDetailsViewRequest.builder().ipAddress(IP_ADDRESS).build();
  }

  @Test
  void shouldAuditNonPostalAddressUpdateFailure() throws Exception {
    final AuditNonPostalAddressUpdateFailureRequest request =
        buildAuditEmailAddressUpdateFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditNonPostalAddressUpdateFailure(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/customer/non-postal/update/failure"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditUpdateEmailAddress/failureRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditNonPostalAddressUpdateSuccess() throws Exception {
    final AuditNonPostalAddressUpdateSuccessRequest request =
        buildAuditEmailAddressUpdateSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditNonPostalAddressUpdateSuccess(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/customer/non-postal/update/success"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditUpdateEmailAddress/successRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditNonPostalAddressChallenge() throws Exception {
    final AuditAuthenticationCheckRequest request = buildAuditAuthenticationCheckRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditCustomerNonPostalAddressChallenge(request, requestMetadata);

    verifyRequest(
        "/customer/non-postal/authentication/check",
        "api/auditService/request/auditNonPostalAddress/Challenge/challenge.json");
  }

  @Test
  void shouldAuditNonPostalAddressChallengeSuccess() throws Exception {
    final AuditAuthenticationSuccessRequest request = buildAuditAuthenticationSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditCustomerNonPostalAddressChallengeSuccess(request, requestMetadata);

    verifyRequest(
        "/customer/non-postal/authentication/success",
        "api/auditService/request/auditNonPostalAddress/Challenge/challengeSuccess.json");
  }

  @Test
  void shouldAuditNonPostalAddressChallengeFailure() throws Exception {
    final AuditAuthenticationFailureRequest request = buildAuditAuthenticationFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditCustomerNonPostalAddressChallengeFailure(request, requestMetadata);

    verifyRequest(
        "/customer/non-postal/authentication/failure",
        "api/auditService/request/auditNonPostalAddress/Challenge/challengeFailure.json");
  }

  @Test
  void shouldAuditPostalAddressUpdateFailure() throws Exception {
    final AuditPostalAddressUpdateFailureRequest request =
        buildAuditPostalAddressUpdateFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditPostalAddressUpdateFailure(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/customer/postal-address/update/failure"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditUpdatePostalAddress/failureRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditPostalAddressUpdateSuccess() throws Exception {
    final AuditPostalAddressUpdateSuccessRequest request =
        buildAuditPostalAddressUpdateSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditPostalAddressUpdateSuccess(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/customer/postal-address/update/success"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditUpdatePostalAddress/successRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditPostalAddressChallenge() throws Exception {
    final AuditAuthenticationCheckRequest request = buildAuditAuthenticationCheckRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditCustomerPostalAddressChallenge(request, requestMetadata);

    verifyRequest(
        "/customer/postal-address/authentication/check",
        "api/auditService/request/auditPostalAddress/Challenge/challenge.json");
  }

  @Test
  void shouldAuditPostalAddressChallengeSuccess() throws Exception {
    final AuditAuthenticationSuccessRequest request = buildAuditAuthenticationSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditCustomerPostalAddressChallengeSuccess(request, requestMetadata);

    verifyRequest(
        "/customer/postal-address/authentication/success",
        "api/auditService/request/auditPostalAddress/Challenge/challengeSuccess.json");
  }

  @Test
  void shouldAuditPostalAddressChallengeFailure() throws Exception {
    final AuditAuthenticationFailureRequest request = buildAuditAuthenticationFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditCustomerPostalAddressChallengeFailure(request, requestMetadata);

    verifyRequest(
        "/customer/postal-address/authentication/failure",
        "api/auditService/request/auditPostalAddress/Challenge/challengeFailure.json");
  }

  private void verifyRequest(final String expectedPath, final String expectedResponseBodyResource)
      throws InterruptedException, JSONException {
    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is(expectedPath));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody = readClassPathResource(expectedResponseBodyResource);
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  private static AuditNonPostalAddressUpdateSuccessRequest
      buildAuditEmailAddressUpdateSuccessRequest() {
    return AuditNonPostalAddressUpdateSuccessRequest.builder()
        .ipAddress(IP_ADDRESS)
        .address(EMAIL_ADDRESS)
        .type(NonPostalType.EMAIL)
        .build();
  }

  private static AuditNonPostalAddressUpdateFailureRequest
      buildAuditEmailAddressUpdateFailureRequest() {
    return AuditNonPostalAddressUpdateFailureRequest.builder()
        .ipAddress(IP_ADDRESS)
        .message("audit message")
        .address(EMAIL_ADDRESS)
        .type(NonPostalType.EMAIL)
        .build();
  }

  private static AuditPostalAddressUpdateSuccessRequest
      buildAuditPostalAddressUpdateSuccessRequest() {
    return AuditPostalAddressUpdateSuccessRequest.builder()
        .ipAddress(IP_ADDRESS)
        .postalAddressRequest(buildPostalAddressRequestPayload())
        .build();
  }

  private static AuditPostalAddressUpdateFailureRequest
      buildAuditPostalAddressUpdateFailureRequest() {
    return AuditPostalAddressUpdateFailureRequest.builder()
        .ipAddress(IP_ADDRESS)
        .message("Something went wrong...")
        .postalAddressRequest(buildPostalAddressRequestPayload())
        .build();
  }

  private static PostalAddressRequest buildPostalAddressRequestPayload() {
    return PostalAddressRequest.builder().address(buildPostalAddress()).paf(buildPafData()).build();
  }

  private static PostalAddress buildPostalAddress() {
    return PostalAddress.builder()
        .type(PostalAddress.PostalAddressType.CORR)
        .subType(PostalAddress.PostalAddressSubType.UKPOST)
        .addressLine("Broad Gate")
        .addressLine("The Headrow")
        .postCode("LS1 6LR")
        .country(PermittedCountries.UNITED_KINGDOM)
        .build();
  }

  private static uk.co.ybs.digital.customer.web.dto.PafData buildPafData() {
    return uk.co.ybs.digital.customer.web.dto.PafData.builder()
        .addressKey(12345678)
        .deliveryPointSuffix("1TA")
        .build();
  }

  private static RequestMetadata buildRequestMetadata() {

    final UUID sessionId = UUID.randomUUID();

    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .sessionId(sessionId)
        .host(InetSocketAddress.createUnresolved("localhost", 80))
        .partyId("1234567891")
        .brandCode("YBS")
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .webCustomerNumber("1234567891")
        .build();
  }

  private AuditAuthenticationCheckRequest buildAuditAuthenticationCheckRequest() {

    return AuditAuthenticationCheckRequest.builder().ipAddress(IP_ADDRESS).build();
  }

  private AuditAuthenticationSuccessRequest buildAuditAuthenticationSuccessRequest() {

    return AuditAuthenticationSuccessRequest.builder().ipAddress(IP_ADDRESS).build();
  }

  private AuditAuthenticationFailureRequest buildAuditAuthenticationFailureRequest() {
    return AuditAuthenticationFailureRequest.builder()
        .ipAddress(IP_ADDRESS)
        .message("Invalid Credentials")
        .build();
  }
}
