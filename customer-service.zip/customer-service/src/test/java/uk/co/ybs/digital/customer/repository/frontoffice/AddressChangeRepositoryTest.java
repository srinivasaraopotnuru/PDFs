package uk.co.ybs.digital.customer.repository.frontoffice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import uk.co.ybs.digital.customer.config.JpaAuditingConfig;
import uk.co.ybs.digital.customer.config.TestClockConfig;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Import({JpaAuditingConfig.class, TestClockConfig.class})
public class AddressChangeRepositoryTest {

  private static final String PARTY_ID_1 = "123456789";
  private static final String PARTY_ID_2 = "987654321";

  private static final LocalDateTime EARLIEST_DATE = LocalDateTime.parse("2020-04-06T12:34:56");
  private static final LocalDateTime BEFORE_EARLIEST_DATE = EARLIEST_DATE.minusSeconds(1);
  private static final LocalDateTime AFTER_EARLIEST_DATE = EARLIEST_DATE.plusSeconds(1);

  @Autowired private AddressChangeRepository testSubject;

  @Autowired private TestEntityManager frontOfficeTestEntityManager;

  @AfterEach
  public void beforeEach() {

    frontOfficeTestEntityManager.clear();
    testSubject.deleteAll();
  }

  @Test
  void shouldFindById() {

    final AddressChange addressDetails = buildAddressChange(PARTY_ID_1, EARLIEST_DATE);

    frontOfficeTestEntityManager.persistAndFlush(addressDetails);
    frontOfficeTestEntityManager.clear();

    final Optional<AddressChange> found =
        testSubject.findById(
            AddressChange.AddressChangePk.builder()
                .partySysId(addressDetails.getPartySysId())
                .amendDate(addressDetails.getAmendDate())
                .build());

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(addressDetails));
  }

  @Test
  public void shouldFindAllChangesForPartiesAfterEarliestTime() {

    frontOfficeTestEntityManager.persistAndFlush(buildAddressChange(PARTY_ID_1, EARLIEST_DATE));
    frontOfficeTestEntityManager.persistAndFlush(
        buildAddressChange(PARTY_ID_2, AFTER_EARLIEST_DATE));
    frontOfficeTestEntityManager.clear();

    final List<String> parties = Arrays.asList(PARTY_ID_1, PARTY_ID_2);

    final Set<String> found =
        testSubject.findAllChangesForPartiesAfterEarliestTime(parties, EARLIEST_DATE);

    assertThat(found, containsInAnyOrder(PARTY_ID_1, PARTY_ID_2));
  }

  @ParameterizedTest
  @CsvSource({"123456789,true", "987654321,false"})
  public void shouldFindAllChangesForParties(final String partyId, final boolean expectedFound) {

    frontOfficeTestEntityManager.persistAndFlush(buildAddressChange(partyId, EARLIEST_DATE));
    frontOfficeTestEntityManager.clear();

    final Set<String> parties =
        testSubject.findAllChangesForPartiesAfterEarliestTime(
            Collections.singletonList(PARTY_ID_1), EARLIEST_DATE);

    assertThat(parties.isEmpty(), not(expectedFound));
  }

  @Test
  public void shouldNotFindAnyChangesForPartiesBeforeEarliestDate() {

    frontOfficeTestEntityManager.persistAndFlush(
        buildAddressChange(PARTY_ID_1, BEFORE_EARLIEST_DATE));
    frontOfficeTestEntityManager.clear();

    final Set<String> parties =
        testSubject.findAllChangesForPartiesAfterEarliestTime(
            Collections.singletonList(PARTY_ID_1), EARLIEST_DATE);

    assertThat(parties.isEmpty(), not(false));
  }

  @Test
  public void shouldFindLatestChangeForPartyAfterEarliestTime() {

    frontOfficeTestEntityManager.persistAndFlush(buildAddressChange(PARTY_ID_1, EARLIEST_DATE));

    AddressChange latest = buildAddressChange(PARTY_ID_1, AFTER_EARLIEST_DATE);
    frontOfficeTestEntityManager.persistAndFlush(latest);
    frontOfficeTestEntityManager.clear();

    final Optional<AddressChange> found =
        testSubject.findLatestChangeForPartyAfterEarliestTime(PARTY_ID_1, EARLIEST_DATE);

    assertThat(found.isPresent(), is(true));

    assertThat(found.get(), is(samePropertyValuesAs(latest)));
  }

  private AddressChange buildAddressChange(final String partyId, final LocalDateTime amendDate) {

    return AddressChange.builder()
        .partySysId(partyId)
        .amendDate(amendDate)
        .addressLine1("1 Leeds Road")
        .postCode("LS1 1AB")
        .country("UK")
        .build();
  }
}
