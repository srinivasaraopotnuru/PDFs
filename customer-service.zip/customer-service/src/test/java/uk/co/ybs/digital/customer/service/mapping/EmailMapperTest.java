package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyCollectionOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.PartyType;
import uk.co.ybs.digital.customer.service.PendingDetailsService;
import uk.co.ybs.digital.customer.web.dto.EmailAddressResponse;

@ExtendWith(MockitoExtension.class)
public class EmailMapperTest {

  private static final String EMAIL = "abc@def.com";
  private static final String OTHER_EMAIL = "qwe@rty.com";
  private static final String EMAIL_TYPE = "Email";

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");
  private static final LocalDateTime YESTERDAY = NOW.minusDays(1L);

  EmailMapper testSubject;

  @Mock PendingDetailsService pendingDetailsService;

  @BeforeEach
  void setUp() {
    testSubject = Mappers.getMapper(EmailMapper.class);
    testSubject.setService(pendingDetailsService);
  }

  @Test
  void mapsEmail() {
    final List<AddressUsage> addresses = buildAddressUsages();
    final String mapped = testSubject.email(addresses);

    assertThat(mapped, is(EMAIL));
  }

  @ParameterizedTest
  @EmptySource
  @MethodSource("invalidAddresses")
  void emailShouldReturnNullIfNoEmailAddresses(final List<AddressUsage> addresses) {
    final String mapped = testSubject.email(addresses);

    assertThat(mapped, is(nullValue()));
  }

  @Test
  void mapsEmailAddresses() {
    NonPostalAddress firstEmail =
        NonPostalAddress.builder()
            .sysId(1L)
            .type(AddressType.EMAIL)
            .address("test@test.com")
            .build();

    NonPostalAddress secondEmail =
        NonPostalAddress.builder()
            .sysId(2L)
            .type(AddressType.EMAIL)
            .address("test2@test.com")
            .build();

    final Party party =
        buildPartyWithNonPostalAddressUsages(Arrays.asList(firstEmail, secondEmail));

    EmailAddressResponse expectedFirstEmail =
        EmailAddressResponse.builder().email(EMAIL).type(EMAIL_TYPE).pendingUpdate(false).build();

    EmailAddressResponse expectedSecondEmail =
        EmailAddressResponse.builder()
            .email(OTHER_EMAIL)
            .type(EMAIL_TYPE)
            .pendingUpdate(true)
            .build();

    when(pendingDetailsService.buildEmailAddressResponse(party, firstEmail))
        .thenReturn(expectedFirstEmail);

    when(pendingDetailsService.buildEmailAddressResponse(party, secondEmail))
        .thenReturn(expectedSecondEmail);

    final List<EmailAddressResponse> response = testSubject.emailAddresses(party);

    assertThat(response, hasSize(2));
    assertThat(
        response,
        containsInAnyOrder(
            allOf(
                hasProperty("email", is(EMAIL)),
                hasProperty("type", is(EMAIL_TYPE)),
                hasProperty("pendingUpdate", is(false))),
            allOf(
                hasProperty("email", is(OTHER_EMAIL)),
                hasProperty("type", is(EMAIL_TYPE)),
                hasProperty("pendingUpdate", is(true)))));
  }

  @ParameterizedTest
  @MethodSource("partyWithNoEmailAddress")
  void emailAddressShouldReturnEmptyListIfNoEmailAddresses(final Party party) {
    final List<EmailAddressResponse> mapped = testSubject.emailAddresses(party);

    assertThat(mapped, is(emptyCollectionOf(EmailAddressResponse.class)));
  }

  @Test
  void emailAddressWithDuplicateEntriesForSourceTypeReturnLatestBasedOnCreationDate() {

    List<AddressUsage> addresses =
        Arrays.asList(
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("0732")
                        .sourceType(NPASourceType.MOBILE)
                        .build())
                .createdDate(NOW.minusSeconds(1L))
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("0731")
                        .sourceType(NPASourceType.MOBILE)
                        .build())
                .createdDate(NOW)
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.EMAIL)
                        .address("prev.prev@provider.com")
                        .build())
                .createdDate(NOW.minusSeconds(1L))
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.EMAIL)
                        .address("current@provider.com")
                        .build())
                .createdDate(NOW)
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.EMAIL)
                        .address("prev@provider.com")
                        .build())
                .createdDate(NOW.minusSeconds(2L))
                .build());

    Party party = buildParty();
    party.setAddresses(addresses);

    EmailAddressResponse expected =
        EmailAddressResponse.builder()
            .email("current@provider.com")
            .type(EMAIL_TYPE)
            .pendingUpdate(true)
            .build();

    when(pendingDetailsService.buildEmailAddressResponse(
            party, party.getAddresses().get(0).getNonPostalAddress()))
        .thenReturn(expected);

    final List<EmailAddressResponse> mapped = testSubject.emailAddresses(party);

    assertThat(mapped, hasSize(1));
    assertThat(mapped.get(0), samePropertyValuesAs(expected));
  }

  private static Stream<Arguments> invalidAddresses() {
    return Stream.of(Arguments.of(Collections.singletonList(buildPhoneNumber())));
  }

  private static Stream<Arguments> partyWithNoEmailAddress() {
    return Stream.of(
        Arguments.of(
            buildPartyWithNonPostalAddressUsages(
                Collections.singletonList(buildNonPostalAddress(AddressType.TEL, "0750303434"))),
            buildPartyWithNonPostalAddressUsages(
                Collections.singletonList(buildNonPostalAddress(AddressType.FAX, "fax"))),
            buildPartyWithNonPostalAddressUsages(
                Collections.singletonList(buildNonPostalAddress(AddressType.BFPO, "BFPO")))));
  }

  private static List<AddressUsage> buildAddressUsages() {
    return Arrays.asList(
        // Filtered out as not right type
        buildPhoneNumber(),
        AddressUsage.builder()
            .nonPostalAddress(
                NonPostalAddress.builder().type(AddressType.EMAIL).address(EMAIL).build())
            .createdDate(NOW)
            .build(),
        AddressUsage.builder()
            .nonPostalAddress(
                NonPostalAddress.builder().type(AddressType.EMAIL).address(OTHER_EMAIL).build())
            .createdDate(NOW)
            .build());
  }

  private static AddressUsage buildPhoneNumber() {
    return AddressUsage.builder()
        .nonPostalAddress(
            NonPostalAddress.builder().type(AddressType.TEL).address("01234420713").build())
        .build();
  }

  private static PartyType buildPartyType() {
    return PartyType.builder().code("PERSON").type("PERSON").startDate(YESTERDAY).build();
  }

  private static NonPostalAddress buildNonPostalAddress(
      final AddressType type, final String address) {
    return NonPostalAddress.builder().type(type).address(address).build();
  }

  private static Party buildParty() {
    return Party.builder().sysId(1L).partyType(buildPartyType()).build();
  }

  public static Party buildPartyWithNonPostalAddressUsages(
      final List<NonPostalAddress> nonPostalAddresses) {

    Party party = buildParty();
    List<AddressUsage> au = new ArrayList<>();
    nonPostalAddresses.forEach(
        npa -> {
          au.add(
              AddressUsage.builder()
                  .nonPostalAddress(npa)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .startDate(YESTERDAY)
                  .createdDate(YESTERDAY)
                  .preferredContactMethod(true)
                  .build());
        });
    party.setAddresses(au);
    return party;
  }
}
