package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn.MarketingOptInCode;
import uk.co.ybs.digital.customer.web.dto.MarketingPreferences;

public class MarketingPreferencesMapperTest {

  private MarketingPreferencesMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new MarketingPreferencesMapper();
  }

  @ParameterizedTest(name = "mapsMarketingPreferences : post:{0} phone:{1} email:{2} eagm:{3}")
  @MethodSource("generateAllCombinationsOfParameters")
  void mapsMarketingPreferences(
      final Boolean postStatus,
      final Boolean phoneStatus,
      final Boolean emailStatus,
      final Boolean eagmStatus) {
    final List<MarketingOptIn> marketingOptIns =
        Arrays.asList(
            buildMarketingOptIn(MarketingOptInCode.ADDR, postStatus),
            buildMarketingOptIn(MarketingOptInCode.TEL, phoneStatus),
            buildMarketingOptIn(MarketingOptInCode.EMAIL, emailStatus),
            buildMarketingOptIn(MarketingOptInCode.AGMEML, eagmStatus));

    final MarketingPreferences mapped = testSubject.marketingPreferences(marketingOptIns);

    assertThat(
        mapped,
        allOf(
            hasProperty("post", is(postStatus)),
            hasProperty("phone", is(phoneStatus)),
            hasProperty("email", is(emailStatus)),
            hasProperty("eagm", is(eagmStatus))));
  }

  @Test
  void mapsMarketingPreferencesEmpty() {
    final List<MarketingOptIn> marketingOptIns = Collections.emptyList();

    final MarketingPreferences mapped = testSubject.marketingPreferences(marketingOptIns);

    assertThat(
        mapped,
        allOf(
            hasProperty("post", is(nullValue())),
            hasProperty("phone", is(nullValue())),
            hasProperty("email", is(nullValue())),
            hasProperty("eagm", is(nullValue()))));
  }

  @SuppressWarnings("unused")
  private static List<Arguments> generateAllCombinationsOfParameters() {
    final List<Arguments> result = new ArrayList<>();

    Supplier<Stream<Boolean>> statusSupplier = () -> Stream.of(true, false, null);

    statusSupplier
        .get()
        .forEach(
            post ->
                statusSupplier
                    .get()
                    .forEach(
                        phone ->
                            statusSupplier
                                .get()
                                .forEach(
                                    email ->
                                        statusSupplier
                                            .get()
                                            .forEach(
                                                eagm ->
                                                    result.add(
                                                        () ->
                                                            new Object[] {
                                                              post, phone, email, eagm
                                                            })))));

    return result;
  }

  private static MarketingOptIn buildMarketingOptIn(
      final MarketingOptInCode code, final Boolean status) {
    return MarketingOptIn.builder().code(code).status(status).build();
  }
}
