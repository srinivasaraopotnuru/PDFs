package uk.co.ybs.digital.customer.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.PartyType;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddress;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.repository.adgcore.CountryRepository;
import uk.co.ybs.digital.customer.repository.digitalcustomer.WorkLogRepository;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.EmailAddressResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PostalAddressResponse;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class PendingDetailsServiceTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");
  private static final LocalDateTime YESTERDAY = NOW.minusDays(1L);
  private static final Long PARTY_ID = 1L;
  public static final String CORR_TYPE = "CORR";

  private static final String LINE1 = "line1";
  private static final String LINE2 = "line2";
  private static final String LINE3 = "line3";

  @InjectMocks PendingDetailsService testSubject;
  @Mock private WorkLogRepository workLogRepository;
  @Mock private CountryRepository countryRepository;

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void buildEmailAddressResponseReturnsNoChangeInAddressWhenNoPendingWorkLog() {
    NonPostalAddress email = buildNonPostalAddress(AddressType.EMAIL, "test@test.com");

    Party party = buildPartyWithNonPostalAddressUsages(Collections.singletonList(email));

    when(workLogRepository.findPendingWorkLogByPartyIdAndOperation(
            PARTY_ID, Operation.EMAIL_ADDRESS))
        .thenReturn(Optional.empty());

    EmailAddressResponse response = testSubject.buildEmailAddressResponse(party, email);

    assertThat(
        response,
        allOf(
            hasProperty("email", is("test@test.com")),
            hasProperty("type", is("DEFAULT")),
            hasProperty("pendingUpdate", is(false))));
  }

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void buildEmailAddressResponseReturnsUpdatedDetailsFromWorkLog() {
    NonPostalAddress email = buildNonPostalAddress(AddressType.EMAIL, "test@test.com");

    Party party = buildPartyWithNonPostalAddressUsages(Collections.singletonList(email));

    Optional<WorkLog> worklog =
        Optional.of(
            TestHelper.buildWorkLogWithUpdateEmailAddress(1L, TestHelper.createRequestMetadata()));

    when(workLogRepository.findPendingWorkLogByPartyIdAndOperation(
            PARTY_ID, Operation.EMAIL_ADDRESS))
        .thenReturn(worklog);

    EmailAddressResponse response = testSubject.buildEmailAddressResponse(party, email);

    assertThat(
        response,
        allOf(
            hasProperty("email", is("customer@provider.com")),
            hasProperty("type", is("Email")),
            hasProperty("pendingUpdate", is(true))));
  }

  @Test
  void buildPostalAddressResponseReturnsNoChangeInAddressWhenNoPendingWorkLog() {
    PostalAddress address = buildPostalAddress(LINE1, LINE2, LINE3, null, null);

    Party party = buildPartyWithPostalAddressUsages(Collections.singletonList(address));

    when(workLogRepository.findPendingWorkLogByPartyIdAndOperation(
            PARTY_ID, Operation.POSTAL_ADDRESS))
        .thenReturn(Optional.empty());

    PostalAddressResponse response =
        testSubject.buildPostalAddressResponse(party, address, CORR_TYPE);

    PostalAddressResponse expectedResponse =
        PostalAddressResponse.builder()
            .addressLines(Arrays.asList(LINE1, LINE2, LINE3))
            .country("GB")
            .postCode("AA01 0AA")
            .pendingUpdate(false)
            .type(CORR_TYPE)
            .build();

    assertThat(response, equalTo(expectedResponse));
  }

  @ParameterizedTest
  @MethodSource("addressLines")
  void buildPostalAddressResponseReturnsUpdatedDetailsFromWorkLog(
      final String line1,
      final String line2,
      final String line3,
      final String line4,
      final String line5,
      final PostalAddressResponse expectedResponse) {
    final List<String> addressLines = Arrays.asList(line1, line2, line3, line4, line5);
    PostalAddress address = buildPostalAddress("line1", "line2", "line3", null, null);
    Party party = buildPartyWithPostalAddressUsages(Collections.singletonList(address));
    Country country = Country.builder().code("UK").isoCode("GB").build();

    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    Optional<WorkLog> worklog =
        Optional.of(
            TestHelper.buildWorkLogWithUpdatePostalAddressWithSetLines(
                PARTY_ID, requestMetadata, addressLines));

    when(countryRepository.getById(any())).thenReturn(country);

    when(workLogRepository.findPendingWorkLogByPartyIdAndOperation(
            PARTY_ID, Operation.POSTAL_ADDRESS))
        .thenReturn(worklog);

    PostalAddressResponse response =
        testSubject.buildPostalAddressResponse(party, address, CORR_TYPE);

    assertThat(response, equalTo(expectedResponse));
  }

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void
      buildPhoneUpdateResponseReturnsUpdatedDetailsFromWorkLogForMultipleNumbersAndTwoPendingInWorklog() {
    Party party =
        buildPartyWithNonPostalAddressUsages(
            Arrays.asList(
                buildNonPostalAddress(AddressType.TEL, "1234567890", NPASourceType.HOME),
                buildNonPostalAddress(AddressType.TEL, "01274678789", NPASourceType.WORK),
                buildNonPostalAddress(AddressType.TEL, "0781802388", NPASourceType.MOBILE)));

    List<WorkLog> worklog =
        Arrays.asList(
            TestHelper.buildWorkLogWithUpdatePhoneNumber(
                PARTY_ID, TestHelper.createRequestMetadata()),
            TestHelper.buildWorkLogWithUpdateMobilePhoneNumber(
                PARTY_ID, TestHelper.createRequestMetadata()));

    when(workLogRepository.findPendingWorkLogByPartyIdAndUpdateDeletePhoneNumber(PARTY_ID))
        .thenReturn(worklog);

    PhoneNumberResponse response =
        testSubject.buildPhoneNumberResponse(
            party,
            PhoneNumberResponse.builder()
                .number(party.getAddresses().get(0).getNonPostalAddress().getAddress())
                .type(party.getAddresses().get(0).getNonPostalAddress().getSourceType().toString())
                .build());

    PhoneNumberResponse response2 =
        testSubject.buildPhoneNumberResponse(
            party,
            PhoneNumberResponse.builder()
                .number(party.getAddresses().get(1).getNonPostalAddress().getAddress())
                .type(party.getAddresses().get(1).getNonPostalAddress().getSourceType().toString())
                .build());

    PhoneNumberResponse response3 =
        testSubject.buildPhoneNumberResponse(
            party,
            PhoneNumberResponse.builder()
                .number(party.getAddresses().get(2).getNonPostalAddress().getAddress())
                .type(party.getAddresses().get(2).getNonPostalAddress().getSourceType().toString())
                .build());

    assertThat(
        response,
        allOf(
            hasProperty("number", is("01234456789")),
            hasProperty("type", is("HOME")),
            hasProperty("pendingUpdate", is(true))));

    assertThat(
        response2,
        allOf(
            hasProperty("number", is("01274678789")),
            hasProperty("type", is("WORK")),
            hasProperty("pendingUpdate", is(false))));

    assertThat(
        response3,
        allOf(
            hasProperty("number", is("07123456789")),
            hasProperty("type", is("MOBILE")),
            hasProperty("pendingUpdate", is(true))));
  }

  @Test
  void buildPhoneUpdateResponseReturnsDeletedDetailsPendingInWorklog() {
    Party party =
        buildPartyWithNonPostalAddressUsages(
            Arrays.asList(
                buildNonPostalAddress(AddressType.TEL, "0781802388", NPASourceType.MOBILE)));

    List<WorkLog> worklog =
        Arrays.asList(
            TestHelper.buildWorkLogWithDeletePhoneNumber(
                PARTY_ID, TestHelper.createRequestMetadata()));

    when(workLogRepository.findPendingWorkLogByPartyIdAndUpdateDeletePhoneNumber(PARTY_ID))
        .thenReturn(worklog);

    PhoneNumberResponse response =
        testSubject.buildPhoneNumberResponse(
            party,
            PhoneNumberResponse.builder()
                .number(party.getAddresses().get(0).getNonPostalAddress().getAddress())
                .type(party.getAddresses().get(0).getNonPostalAddress().getSourceType().toString())
                .build());

    assertThat(
        response, allOf(hasProperty("type", is("MOBILE")), hasProperty("pendingUpdate", is(true))));
  }

  @Test
  void buildPhoneUpdateResponseReturnsSameDetailsAsNoMatchInWorkLog() {
    Party party =
        buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(
                buildNonPostalAddress(AddressType.TEL, "1234567890", NPASourceType.HOME)));

    PhoneNumberResponse response =
        testSubject.buildPhoneNumberResponse(
            party,
            PhoneNumberResponse.builder()
                .number(party.getAddresses().get(0).getNonPostalAddress().getAddress())
                .type(party.getAddresses().get(0).getNonPostalAddress().getSourceType().toString())
                .build());

    assertThat(
        response,
        allOf(
            hasProperty("number", is("1234567890")),
            hasProperty("type", is("HOME")),
            hasProperty("pendingUpdate", is(false))));
  }

  private static Party buildPartyWithNonPostalAddressUsages(
      final List<NonPostalAddress> nonPostalAddresses) {

    Party party = buildParty();
    List<AddressUsage> au = new ArrayList<>();
    nonPostalAddresses.forEach(
        npa -> {
          au.add(
              AddressUsage.builder()
                  .nonPostalAddress(npa)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .startDate(YESTERDAY)
                  .createdDate(YESTERDAY)
                  .preferredContactMethod(true)
                  .build());
        });
    party.setAddresses(au);
    return party;
  }

  public static Party buildPartyWithPostalAddressUsages(final List<PostalAddress> addresses) {

    Party party = buildParty();
    List<AddressUsage> au = new ArrayList<>();
    addresses.forEach(
        address -> {
          au.add(
              AddressUsage.builder()
                  .postalAddress(address)
                  .function(AddressUsage.AddressFunction.CORR)
                  .startDate(YESTERDAY)
                  .createdDate(YESTERDAY)
                  .preferredContactMethod(true)
                  .build());
        });
    party.setAddresses(au);
    return party;
  }

  private static PartyType buildPartyType() {
    return PartyType.builder().code("PERSON").type("PERSON").startDate(YESTERDAY).build();
  }

  private static NonPostalAddress buildNonPostalAddress(
      final AddressType type, final String address) {
    return NonPostalAddress.builder().type(type).address(address).build();
  }

  private static PostalAddress buildPostalAddress(
      final String line1,
      final String line2,
      final String line3,
      final String line4,
      final String line5) {
    return PostalAddress.builder()
        .line1(line1)
        .line2(line2)
        .line3(line3)
        .line4(line4)
        .line5(line5)
        .postCode(
            PostCode.builder()
                .areaCode("AA")
                .districtCode("01")
                .sectorCode("0")
                .unitCode("AA")
                .build())
        .country(Country.builder().code("UK").isoCode("GB").build())
        .type(AddressType.UKPOST)
        .build();
  }

  private static Party buildParty() {
    return Party.builder().sysId(PARTY_ID).partyType(buildPartyType()).build();
  }

  private static NonPostalAddress buildNonPostalAddress(
      final AddressType type, final String address, final NPASourceType npaSourceType) {
    return NonPostalAddress.builder().type(type).address(address).sourceType(npaSourceType).build();
  }

  private static Stream<Arguments> addressLines() {
    return Stream.of(
        Arguments.of(
            LINE1,
            LINE2,
            LINE3,
            null,
            null,
            buildPostalAddressExpectedResponse(Arrays.asList(LINE1, LINE2, LINE3))),
        Arguments.of(
            LINE1,
            LINE2,
            LINE3,
            " ",
            null,
            buildPostalAddressExpectedResponse(Arrays.asList(LINE1, LINE2, LINE3))),
        Arguments.of(
            LINE1, "", "", "", "", buildPostalAddressExpectedResponse(Arrays.asList(LINE1))));
  }

  private static PostalAddressResponse buildPostalAddressExpectedResponse(
      final List<String> expectedLines) {
    return PostalAddressResponse.builder()
        .addressLines(expectedLines)
        .country("GB")
        .postCode("RM4 1PL")
        .pendingUpdate(true)
        .type(CORR_TYPE)
        .build();
  }
}
