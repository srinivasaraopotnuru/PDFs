package uk.co.ybs.digital.customer.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.net.InetSocketAddress;
import java.time.Duration;
import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.exception.ScaRequiredException;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationCheckRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationSuccessRequest;
import uk.co.ybs.digital.customer.web.dto.EmailAddress;
import uk.co.ybs.digital.customer.web.dto.PafData;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@ExtendWith(MockitoExtension.class)
class ScaManagerTest {

  private static final Duration CHALLENGE_TIMEOUT = Duration.ofMinutes(1);
  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");
  private static final InetSocketAddress HOST = InetSocketAddress.createUnresolved("localhost", 80);
  private static final String PARTY_ID = "12462951";
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String BRAND_CODE = "YBS";
  private static final String EMAIL_ADDRESS = "test@test.com";
  private static final String MOCK_CHALLENGE = "mockChallenge";
  private static final String MOCK_RESPONSE = "mockResponse";
  private static final String PUBLIC_KEY = "mockBase64EncodedPublicKey";

  @InjectMocks private ScaManager testSubject;

  @Mock private ScaChallengeService scaChallengeService;

  @Mock private AuditService auditService;

  @Test
  void validateScaShouldThrowScaRequiredExceptionIfScaCredentialsNotProvided() {
    final RequestMetadata metadata = buildRequestMetadata();
    final EmailAddress payload = buildEmailRequestPayload();
    final String challenge = "the-challenge";

    final AuditAuthenticationCheckRequest checkRequest =
        AuditAuthenticationCheckRequest.builder().ipAddress(metadata.getIpAddress()).build();

    when(scaChallengeService.generateChallenge(payload, SESSION_ID, CHALLENGE_TIMEOUT))
        .thenReturn(challenge);

    final ScaRequiredException exception =
        assertThrows(
            ScaRequiredException.class,
            () ->
                testSubject.validateUpdateEmailSca(
                    WorkLog.Operation.EMAIL_ADDRESS, payload, metadata, null));

    assertThat(exception.getChallenge(), is(challenge));
    verifyNoMoreInteractions(scaChallengeService);
    verify(auditService).auditCustomerNonPostalAddressChallenge(checkRequest, metadata);
  }

  @Test
  void validateScaShouldValidateProvidedScaCredentials() {
    final RequestMetadata metadata = buildRequestMetadata();
    final EmailAddress payload = buildEmailRequestPayload();
    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, PUBLIC_KEY);

    final AuditAuthenticationSuccessRequest successRequest =
        AuditAuthenticationSuccessRequest.builder().ipAddress(metadata.getIpAddress()).build();

    testSubject.validateUpdateEmailSca(
        WorkLog.Operation.EMAIL_ADDRESS, payload, metadata, scaCredentials);

    verify(scaChallengeService)
        .validateChallenge(scaCredentials, payload, EmailAddress.class, SESSION_ID);
    verify(auditService).auditCustomerNonPostalAddressChallengeSuccess(successRequest, metadata);
  }

  @Test
  void validatePhoneNumberScaShouldValidateProvidedScaCredentials() {
    final RequestMetadata metadata = buildRequestMetadata();
    final PhoneNumberRequest payload = buildPhoneNumberRequestPayload();
    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, PUBLIC_KEY);

    final AuditAuthenticationSuccessRequest successRequest =
        AuditAuthenticationSuccessRequest.builder().ipAddress(metadata.getIpAddress()).build();

    testSubject.validateUpdatePhoneNumberSca(
        Operation.PHONE_NUMBER, payload, metadata, scaCredentials);

    verify(scaChallengeService)
        .validateChallenge(scaCredentials, payload, PhoneNumberRequest.class, SESSION_ID);
    verify(auditService).auditCustomerNonPostalAddressChallengeSuccess(successRequest, metadata);
  }

  @Test
  void validatePostalAddressScaShouldValidateProvidedScaCredentials() {
    final RequestMetadata metadata = buildRequestMetadata();
    final PostalAddressRequest payload = buildPostalAddressRequestPayload();
    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, PUBLIC_KEY);

    final AuditAuthenticationSuccessRequest successRequest =
        AuditAuthenticationSuccessRequest.builder().ipAddress(metadata.getIpAddress()).build();

    testSubject.validateUpdatePostalAddressSca(
        Operation.POSTAL_ADDRESS, payload, metadata, scaCredentials);

    verify(scaChallengeService)
        .validateChallenge(scaCredentials, payload, PostalAddressRequest.class, SESSION_ID);
    verify(auditService).auditCustomerPostalAddressChallengeSuccess(successRequest, metadata);
  }

  @Test
  void validateScaShouldHandleAndRethrowInvalidScaExceptions() {
    final RequestMetadata metadata = buildRequestMetadata();
    final EmailAddress payload = buildEmailRequestPayload();
    final ScaCredentials scaCredentials =
        new ScaCredentials(MOCK_CHALLENGE, MOCK_RESPONSE, PUBLIC_KEY);

    final AuditAuthenticationFailureRequest failureRequest =
        AuditAuthenticationFailureRequest.builder()
            .ipAddress(metadata.getIpAddress())
            .message("Invalid Challenge Response")
            .build();

    final InvalidScaException exception = new InvalidScaException("");
    doThrow(exception)
        .when(scaChallengeService)
        .validateChallenge(scaCredentials, payload, EmailAddress.class, SESSION_ID);

    final InvalidScaException thrownException =
        assertThrows(
            InvalidScaException.class,
            () ->
                testSubject.validateUpdateEmailSca(
                    WorkLog.Operation.EMAIL_ADDRESS, payload, metadata, scaCredentials));

    assertThat(thrownException, is(exception));
    verify(auditService).auditCustomerNonPostalAddressChallengeFailure(failureRequest, metadata);
  }

  private RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .sessionId(SESSION_ID)
        .host(HOST)
        .partyId(PARTY_ID)
        .brandCode(BRAND_CODE)
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .webCustomerNumber(PARTY_ID)
        .build();
  }

  private EmailAddress buildEmailRequestPayload() {
    return EmailAddress.builder().type("EMAIL").email(EMAIL_ADDRESS).build();
  }

  private PhoneNumberRequest buildPhoneNumberRequestPayload() {
    return PhoneNumberRequest.builder()
        .phoneNumber(
            PhoneNumberBasic.builder()
                .type(PhoneNumberBasicType.HOME)
                .number("01234 123456")
                .build())
        .build();
  }

  private PostalAddressRequest buildPostalAddressRequestPayload() {
    return PostalAddressRequest.builder().address(buildPostalAddress()).paf(buildPafData()).build();
  }

  private static PostalAddress buildPostalAddress() {
    return PostalAddress.builder()
        .type(PostalAddress.PostalAddressType.CORR)
        .subType(PostalAddress.PostalAddressSubType.UKPOST)
        .addressLines(Collections.singleton("Broad Gate"))
        .addressLines(Collections.singleton("The Headrow"))
        .postCode("LS1 6LR")
        .country(PermittedCountries.UNITED_KINGDOM)
        .build();
  }

  private static PafData buildPafData() {
    return PafData.builder().addressKey(12345678).deliveryPointSuffix("1TA").build();
  }
}
