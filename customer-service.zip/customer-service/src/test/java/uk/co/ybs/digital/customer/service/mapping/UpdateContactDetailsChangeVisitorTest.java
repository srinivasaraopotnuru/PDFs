package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDateTime;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdateEmailRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;
import uk.co.ybs.digital.customer.utils.TestHelper;

@ExtendWith(MockitoExtension.class)
public class UpdateContactDetailsChangeVisitorTest {

  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  private static final String TELEPHONE_NUMBER = "01132286540";
  private static final String MOBILE_NUMBER = "07525286540";

  @ParameterizedTest(
      name = "visitUpdatePhoneNumberRequestShouldUpdateContactDetails: {index} {arguments}")
  @MethodSource("numbersArgs")
  public void visitUpdatePhoneNumberRequestShouldUpdateContactDetails(
      final PhoneNumberRequestType type,
      final String oldNumber,
      final Integer areaDiallingCode,
      final String number,
      final String fullNumber,
      final boolean updated) {

    ContactDetailsChange contact =
        ContactDetailsChange.builder()
            .partySysId("123")
            .amendDate(null)
            .emailAddress("test@test.com")
            .homeTelephoneNumber(type == PhoneNumberRequestType.HOME ? oldNumber : null)
            .workTelephoneNumber(type == PhoneNumberRequestType.WORK ? oldNumber : null)
            .mobileTelephoneNumber(type == PhoneNumberRequestType.MOBILE ? oldNumber : null)
            .build();

    UpdateContactDetailsChangeVisitor testSubject =
        new UpdateContactDetailsChangeVisitor(contact, PROCESS_TIME);

    if (number == null) {
      DeletePhoneRequest request = DeletePhoneRequest.builder().requestType(type).build();
      assertThat(testSubject.visit(request), is(updated));
    } else {
      UpdatePhoneRequest request =
          UpdatePhoneRequest.builder()
              .requestType(type)
              .areaDiallingCode(areaDiallingCode)
              .number(number)
              .build();
      assertThat(testSubject.visit(request), is(updated));
    }

    assertThat(
        contact.getHomeTelephoneNumber(),
        is(type == PhoneNumberRequestType.HOME ? fullNumber : contact.getHomeTelephoneNumber()));
    assertThat(
        contact.getMobileTelephoneNumber(),
        is(
            type == PhoneNumberRequestType.MOBILE
                ? fullNumber
                : contact.getMobileTelephoneNumber()));
    assertThat(
        contact.getWorkTelephoneNumber(),
        is(type == PhoneNumberRequestType.WORK ? fullNumber : contact.getWorkTelephoneNumber()));

    assertThat(contact.getAmendDate() == PROCESS_TIME, is(updated));
  }

  @ParameterizedTest(name = "visitUpdateEmailRequestShouldUpdateContactDetails: {arguments}")
  @MethodSource("emailArgs")
  public void visitUpdateEmailRequestShouldUpdateContactDetails(
      final String oldEmailAddress, final String emailAddress, final boolean updated) {

    ContactDetailsChange contact =
        ContactDetailsChange.builder()
            .partySysId("123")
            .amendDate(null)
            .emailAddress(oldEmailAddress)
            .homeTelephoneNumber(TELEPHONE_NUMBER)
            .workTelephoneNumber(TELEPHONE_NUMBER)
            .mobileTelephoneNumber(MOBILE_NUMBER)
            .build();

    UpdateContactDetailsChangeVisitor testSubject =
        new UpdateContactDetailsChangeVisitor(contact, PROCESS_TIME);

    UpdateEmailRequest request =
        UpdateEmailRequest.builder().requestType("email").email(emailAddress).build();
    testSubject.visit(request);

    assertThat(contact.getEmailAddress(), is(emailAddress));

    assertThat(contact.getAmendDate() == PROCESS_TIME, is(updated));
  }

  @Test
  public void visitUpdatePostalAddressRequestShouldThrowCustomerServiceException() {

    final ContactDetailsChange contact =
        ContactDetailsChange.builder()
            .partySysId("123")
            .amendDate(null)
            .emailAddress("test@test.com")
            .build();

    final UpdateContactDetailsChangeVisitor testSubject =
        new UpdateContactDetailsChangeVisitor(contact, PROCESS_TIME);

    final UpdatePostalAddressRequest request = TestHelper.buildUpdatePostalAddressPayload();

    assertThrows(CustomerServiceException.class, () -> testSubject.visit(request));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> numbersArgs() {
    return Stream.of(
        Arguments.of(PhoneNumberRequestType.HOME, null, "113", "2286543", "01132286543", true),
        Arguments.of(
            PhoneNumberRequestType.HOME, TELEPHONE_NUMBER, "113", "2286543", "01132286543", true),
        Arguments.of(
            PhoneNumberRequestType.HOME,
            TELEPHONE_NUMBER,
            "113",
            "2286540",
            TELEPHONE_NUMBER,
            false),
        Arguments.of(PhoneNumberRequestType.HOME, TELEPHONE_NUMBER, null, null, null, true),
        Arguments.of(PhoneNumberRequestType.HOME, null, null, null, null, false),
        Arguments.of(PhoneNumberRequestType.MOBILE, null, null, "07525286543", "07525286543", true),
        Arguments.of(
            PhoneNumberRequestType.MOBILE, MOBILE_NUMBER, null, "07525286543", "07525286543", true),
        Arguments.of(
            PhoneNumberRequestType.MOBILE,
            MOBILE_NUMBER,
            null,
            MOBILE_NUMBER,
            MOBILE_NUMBER,
            false),
        Arguments.of(PhoneNumberRequestType.MOBILE, MOBILE_NUMBER, null, null, null, true),
        Arguments.of(PhoneNumberRequestType.MOBILE, null, null, null, null, false),
        Arguments.of(PhoneNumberRequestType.WORK, null, "113", "2286543", "01132286543", true),
        Arguments.of(
            PhoneNumberRequestType.WORK, TELEPHONE_NUMBER, "113", "2286543", "01132286543", true),
        Arguments.of(
            PhoneNumberRequestType.WORK,
            TELEPHONE_NUMBER,
            "113",
            "2286540",
            TELEPHONE_NUMBER,
            false),
        Arguments.of(PhoneNumberRequestType.WORK, TELEPHONE_NUMBER, null, null, null, true),
        Arguments.of(PhoneNumberRequestType.WORK, null, null, null, null, false));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> emailArgs() {
    return Stream.of(
        Arguments.of(null, "customer@provider.com", true),
        Arguments.of("old@provider.com", "customer@provider.com", true),
        Arguments.of("customer@provider.com", "customer@provider.com", false));
  }
}
