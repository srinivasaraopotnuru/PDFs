package uk.co.ybs.digital.customer.service.utilities;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.customer.model.PostCode;

public class PostCodeHelperTest {

  @ParameterizedTest(name = "isValidPostcodeTest: {index} {arguments}")
  @MethodSource("postCodes")
  public void isValidPostcodeTest(
      final String label, final String postCode, final boolean isValid) {
    assertThat(PostCodeHelper.isValidPostCode(postCode), is(isValid));
  }

  private static Stream<Arguments> postCodes() {
    return Stream.of(
        Arguments.of("England", "WF10 1BP", true),
        Arguments.of("Northern Ireland", "BT79 0QN", true),
        Arguments.of("Scotland", "EH2 2DY", true),
        Arguments.of("Wales", "LL30 2PD", true),
        Arguments.of("Isle of Man", "IM8 1RT", true),
        Arguments.of("Guernsey", "GY1 1HB", true),
        Arguments.of("Jersey", "JE2 4TU", true),
        Arguments.of("England - Long Postcode", "SW1W 0NY", true),
        Arguments.of("England - Short Postcode", "L1 8JQ", true),
        Arguments.of("England - No Space Postcode", "WF101BP", true),
        Arguments.of("England - Mixed Case Postcode", "Wf10 1bp", true),
        Arguments.of("England - Lower Case Postcode", "wf10 1bp", true),
        Arguments.of("Non-UK (Spain)", "08040", false),
        Arguments.of("Invalid UK", "L1PT", false),
        Arguments.of("Special Character", "LS1 @TR", false),
        Arguments.of("Whitespace Only", " ", false),
        Arguments.of("Null", null, false),
        Arguments.of("Gibraltar", "GX11 1AA", false),
        Arguments.of("Amazon", "XX50 1DD", false),
        Arguments.of("HMRC Vat", "BX5 5AT", false));
  }

  @ParameterizedTest(name = "splitPostCodeTest: {index} {arguments}")
  @MethodSource("validPostCodesToSplit")
  public void splitValidPostCodeTest(
      final String postCode,
      final String areaCode,
      final String districtCode,
      final String sectorCode,
      final String unitCode) {

    final Optional<PostCode> splitPostCode = PostCodeHelper.splitPostCode(postCode);

    assertThat(splitPostCode.isPresent(), is(true));
    assertThat(splitPostCode.get().getAreaCode(), is(areaCode));
    assertThat(splitPostCode.get().getDistrictCode(), is(districtCode));
    assertThat(splitPostCode.get().getSectorCode(), is(sectorCode));
    assertThat(splitPostCode.get().getUnitCode(), is(unitCode));
  }

  private static Stream<Arguments> validPostCodesToSplit() {
    return Stream.of(
        Arguments.of("WF10 1BP", "WF", "10", "1", "BP"),
        Arguments.of("EC1A 1BB", "EC", "1A", "1", "BB"),
        Arguments.of("W1A 0AX", "W", "1A", "0", "AX"),
        Arguments.of(" M1 1AE", "M", "1", "1", "AE"),
        Arguments.of("B33 8th", "B", "33", "8", "TH"),
        Arguments.of("CR2 6xH", "CR", "2", "6", "XH"),
        Arguments.of("IM8 1RT", "IM", "8", "1", "RT"),
        Arguments.of("GY1 1HB", "GY", "1", "1", "HB"),
        Arguments.of("JE2 4TU", "JE", "2", "4", "TU"),
        Arguments.of("BT79 0QN", "BT", "79", "0", "QN"));
  }

  @ParameterizedTest(name = "invalidPostCodesToSplit: {index} {arguments}")
  @MethodSource("invalidPostCodesToSplit")
  public void splitInvalidPostCodeTest(final String postCode) {

    final Optional<PostCode> splitPostCode = PostCodeHelper.splitPostCode(postCode);

    assertThat(splitPostCode.isPresent(), is(false));
  }

  @Test
  public void formatPostCode() {

    String formattedPostCode = PostCodeHelper.formatPostcode("AA", "01", "1", "BB");

    assertThat(formattedPostCode, is("AA01 1BB"));
  }

  private static Stream<Arguments> invalidPostCodesToSplit() {
    return Stream.of(
        Arguments.of("E@@"),
        Arguments.of(""),
        Arguments.of(" "),
        Arguments.of("L11P"),
        Arguments.of("08040"));
  }
}
