package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.emptyCollectionOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.assertj.core.util.Strings;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mapstruct.factory.Mappers;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberSubType;

public class PhoneNumberMapperTest {

  private static final String TELEPHONE_NUMBER = "87654321";
  private static final String MOBILE_NUMBER = "07975732685";
  private static final String ADC_CODE = "1274";
  private static final String UK_COUNTRY = "UK";
  private static final String UK_DIALLING_CODE = "00";
  private static final String US_COUNTRY = "USA";
  private static final String US_DIALLING_CODE = "1";

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");

  private PhoneNumberMapper testSubject;

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> phoneNumbers() {
    return Stream.of(
        Arguments.of(
            "Should include area code for UK work number",
            buildPhoneNumber(TELEPHONE_NUMBER, ADC_CODE, UK_COUNTRY, NPASourceType.WORK),
            allOf(hasProperty("number", is("0127487654321")), hasProperty("type", is("WORK")))),
        Arguments.of(
            "Should include area code for UK home number",
            buildPhoneNumber(TELEPHONE_NUMBER, ADC_CODE, UK_COUNTRY, NPASourceType.HOME),
            allOf(hasProperty("number", is("0127487654321")), hasProperty("type", is("HOME")))),
        Arguments.of(
            "Should return number without area code when no ADC code",
            buildPhoneNumber(TELEPHONE_NUMBER, null, UK_COUNTRY, NPASourceType.WORK),
            allOf(hasProperty("number", is(TELEPHONE_NUMBER)), hasProperty("type", is("WORK")))),
        Arguments.of(
            "Should return number without area code for unspecified number type",
            buildPhoneNumber(TELEPHONE_NUMBER, ADC_CODE, UK_COUNTRY, null),
            allOf(hasProperty("number", is(TELEPHONE_NUMBER)), hasProperty("type", is("DEFAULT")))),
        Arguments.of(
            "Should return number without area code for unknown country",
            buildPhoneNumber(TELEPHONE_NUMBER, ADC_CODE, null, NPASourceType.WORK),
            allOf(hasProperty("number", is(TELEPHONE_NUMBER)), hasProperty("type", is("WORK")))),
        Arguments.of(
            "Should return number without area code for non UK country",
            buildPhoneNumber(TELEPHONE_NUMBER, ADC_CODE, US_COUNTRY, NPASourceType.WORK),
            allOf(hasProperty("number", is(TELEPHONE_NUMBER)), hasProperty("type", is("WORK")))),
        Arguments.of(
            "Should return mobile number with a leading zero",
            buildPhoneNumber("7975732685", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("number", is("07975732685")), hasProperty("type", is("MOBILE")))),
        Arguments.of(
            "Should return mobile number without an area code",
            buildPhoneNumber(MOBILE_NUMBER, ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("number", is("07975732685")), hasProperty("type", is("MOBILE")))));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> phoneNumberSubTypes() {
    return Stream.of(
        Arguments.of(
            "Should return as mobile number 071 prefix",
            buildPhoneNumber("07136989151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number 072 prefix",
            buildPhoneNumber("07237982651", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number 073 prefix",
            buildPhoneNumber("07336982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number 074 prefix",
            buildPhoneNumber("07436982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number 075 prefix",
            buildPhoneNumber("07536982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number 076 prefix",
            buildPhoneNumber("07624982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number 077 prefix",
            buildPhoneNumber("07736982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number 078 prefix",
            buildPhoneNumber("07836982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number 079 prefix",
            buildPhoneNumber("07936982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number with null country code",
            buildPhoneNumber("07336982151", ADC_CODE, null, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as mobile number with number missing leading zero",
            buildPhoneNumber("7336982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as a landline (non mobile prefix)",
            buildPhoneNumber("12345678", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.LANDLINE)))),
        Arguments.of(
            "Should return home number as mobile",
            buildPhoneNumber("147682", "7840", UK_COUNTRY, NPASourceType.HOME),
            allOf(hasProperty("subType", is(PhoneNumberSubType.MOBILE)))),
        Arguments.of(
            "Should return as international",
            buildPhoneNumber("987456321", ADC_CODE, US_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("subType", is(PhoneNumberSubType.INTERNATIONAL)))));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> phoneNumberCountryCodes() {
    return Stream.of(
        Arguments.of(
            "Should return country code",
            buildPhoneNumber(
                TELEPHONE_NUMBER, ADC_CODE, US_COUNTRY, US_DIALLING_CODE, NPASourceType.MOBILE),
            allOf(hasProperty("countryCode", is(US_DIALLING_CODE)))),
        Arguments.of(
            "should not return country code for UK country",
            buildPhoneNumber("07436982151", ADC_CODE, UK_COUNTRY, NPASourceType.MOBILE),
            allOf(hasProperty("countryCode", is(nullValue())))),
        Arguments.of(
            "Should not return country code if not specified",
            buildPhoneNumber("07436982151", ADC_CODE, US_COUNTRY, null, NPASourceType.MOBILE),
            allOf(hasProperty("countryCode", is(nullValue())))),
        Arguments.of(
            "should not return country code when country not specified",
            buildPhoneNumber("07436982151", ADC_CODE, null, UK_DIALLING_CODE, NPASourceType.MOBILE),
            allOf(hasProperty("countryCode", is(nullValue())))));
  }

  private static Stream<Arguments> provideInvalidAddresses() {
    return Stream.of(Arguments.of(Collections.singletonList(buildEmailAddress())));
  }

  private static List<AddressUsage> buildPhoneNumber(
      final String phoneNumber,
      final String adcCode,
      final String countryCode,
      final NPASourceType sourceType) {
    return buildPhoneNumber(phoneNumber, adcCode, countryCode, null, sourceType);
  }

  private static List<AddressUsage> buildPhoneNumber(
      final String phoneNumber,
      final String adcCode,
      final String countryCode,
      final String countryDiallingCode,
      final NPASourceType sourceType) {
    if (!Strings.isNullOrEmpty(countryCode)) {
      final Country country;

      if (!Strings.isNullOrEmpty(countryDiallingCode)) {
        country = Country.builder().code(countryCode).telephoneCode(countryDiallingCode).build();
      } else {
        country = Country.builder().code(countryCode).build();
      }

      return Collections.singletonList(
          AddressUsage.builder()
              .nonPostalAddress(
                  NonPostalAddress.builder()
                      .type(AddressType.TEL)
                      .address(phoneNumber)
                      .adcCode(adcCode)
                      .country(country)
                      .sourceType(sourceType)
                      .build())
              .createdDate(NOW)
              .build());
    } else {
      return Collections.singletonList(
          AddressUsage.builder()
              .nonPostalAddress(
                  NonPostalAddress.builder()
                      .type(AddressType.TEL)
                      .address(phoneNumber)
                      .adcCode(adcCode)
                      .sourceType(sourceType)
                      .build())
              .createdDate(NOW)
              .build());
    }
  }

  private static AddressUsage buildEmailAddress() {
    return AddressUsage.builder()
        .nonPostalAddress(
            NonPostalAddress.builder().type(AddressType.EMAIL).address("abc@def.com").build())
        .build();
  }

  @BeforeEach
  void setUp() {
    testSubject = Mappers.getMapper(PhoneNumberMapper.class);
  }

  @Test
  void mapsPhoneNumberNonDuplicateListOfAddressUsage() {
    List<AddressUsage> addresses =
        Arrays.asList(
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("073366666")
                        .sourceType(NPASourceType.MOBILE)
                        .build())
                .createdDate(NOW.minusSeconds(1L))
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("01274591374")
                        .sourceType(NPASourceType.WORK)
                        .build())
                .createdDate(NOW)
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("01274666666")
                        .sourceType(NPASourceType.HOME)
                        .build())
                .createdDate(NOW.minusSeconds(2L))
                .build());

    List<PhoneNumberResponse> expected =
        Arrays.asList(
            PhoneNumberResponse.builder()
                .number("073366666")
                .subType(PhoneNumberSubType.MOBILE)
                .type("MOBILE")
                .build(),
            PhoneNumberResponse.builder()
                .number("01274591374")
                .subType(PhoneNumberSubType.LANDLINE)
                .type("WORK")
                .build(),
            PhoneNumberResponse.builder()
                .number("01274666666")
                .subType(PhoneNumberSubType.LANDLINE)
                .type("HOME")
                .build());

    final List<PhoneNumberResponse> mapped = testSubject.phoneNumbers(addresses);

    assertThat(mapped, is(expected));
  }

  @ParameterizedTest
  @MethodSource("phoneNumbers")
  void mapsPhoneNumberADCCodes(
      final String label,
      final List<AddressUsage> address,
      final Matcher<PhoneNumberResponse> expectedPhoneNumber) {
    final List<PhoneNumberResponse> mapped = testSubject.phoneNumbers(address);

    assertThat(mapped, contains(expectedPhoneNumber));
  }

  @ParameterizedTest
  @MethodSource("phoneNumberSubTypes")
  void mapsPhoneNumberSubTypes(
      final String label,
      final List<AddressUsage> address,
      final Matcher<PhoneNumberResponse> expectedPhoneNumber) {
    final List<PhoneNumberResponse> mapped = testSubject.phoneNumbers(address);

    assertThat(mapped, contains(expectedPhoneNumber));
  }

  @ParameterizedTest
  @MethodSource("phoneNumberCountryCodes")
  void mapsPhoneNumberCountryCodes(
      final String label,
      final List<AddressUsage> address,
      final Matcher<PhoneNumberResponse> expectedPhoneNumber) {
    final List<PhoneNumberResponse> mapped = testSubject.phoneNumbers(address);

    assertThat(mapped, contains(expectedPhoneNumber));
  }

  @ParameterizedTest
  @EmptySource
  @MethodSource("provideInvalidAddresses")
  void phoneNumbersShouldReturnEmptyListIfNoPhoneNumber(final List<AddressUsage> addresses) {
    final List<PhoneNumberResponse> mapped = testSubject.phoneNumbers(addresses);

    assertThat(mapped, is(emptyCollectionOf(PhoneNumberResponse.class)));
  }

  @Test
  void phoneNumberWithDuplicateEntriesForSourceTypeReturnLatestBasedOnCreationDate() {

    List<AddressUsage> addresses =
        Arrays.asList(
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.EMAIL)
                        .address("customer@provider.com")
                        .build())
                .createdDate(NOW)
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("0732")
                        .sourceType(NPASourceType.MOBILE)
                        .build())
                .createdDate(NOW.minusSeconds(1L))
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("0731")
                        .sourceType(NPASourceType.MOBILE)
                        .build())
                .createdDate(NOW)
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("0733")
                        .sourceType(NPASourceType.MOBILE)
                        .build())
                .createdDate(NOW.minusSeconds(2L))
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("1002")
                        .sourceType(NPASourceType.HOME)
                        .build())
                .createdDate(NOW.minusSeconds(1L))
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("1001")
                        .sourceType(NPASourceType.HOME)
                        .build())
                .createdDate(NOW)
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("1003")
                        .sourceType(NPASourceType.HOME)
                        .build())
                .createdDate(NOW.minusSeconds(2L))
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("2002")
                        .sourceType(NPASourceType.WORK)
                        .build())
                .createdDate(NOW.minusSeconds(1L))
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("2001")
                        .sourceType(NPASourceType.WORK)
                        .build())
                .createdDate(NOW)
                .build(),
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .address("2003")
                        .sourceType(NPASourceType.WORK)
                        .build())
                .createdDate(NOW.minusSeconds(2L))
                .build());

    List<PhoneNumberResponse> expected =
        Arrays.asList(
            PhoneNumberResponse.builder()
                .number("0731")
                .subType(PhoneNumberSubType.MOBILE)
                .type("MOBILE")
                .build(),
            PhoneNumberResponse.builder()
                .number("1001")
                .subType(PhoneNumberSubType.LANDLINE)
                .type("HOME")
                .build(),
            PhoneNumberResponse.builder()
                .number("2001")
                .subType(PhoneNumberSubType.LANDLINE)
                .type("WORK")
                .build());

    final List<PhoneNumberResponse> mapped = testSubject.phoneNumbers(addresses);

    assertThat(mapped, is(expected));
  }
}
