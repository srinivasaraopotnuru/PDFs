package uk.co.ybs.digital.customer.service.processor;

import static org.mockito.Mockito.verify;
import static uk.co.ybs.digital.customer.utils.TestHelper.SERVICE_FAILURE_MESSAGE;
import static uk.co.ybs.digital.customer.utils.TestHelper.TECHNICAL_FAILURE_MESSAGE;

import java.time.LocalDateTime;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class ResolvedDeletePhoneNumberRequestTest {

  private static final long PARTY_ID = 123456L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  private ResolvedDeletePhoneNumberRequest testSubject;
  private DeletePhoneNumberRequestArguments arguments;
  private Party party;
  @Mock private DeletePhoneNumberProcessor deletePhoneNumberProcessor;

  @BeforeEach
  void setUp() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    arguments =
        new DeletePhoneNumberRequestArguments(
            PARTY_ID, requestMetadata, PROCESS_TIME, PhoneNumberRequestType.MOBILE);

    party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(TestHelper.buildMobilePhoneNumberRequest()));

    testSubject =
        new ResolvedDeletePhoneNumberRequest(arguments, deletePhoneNumberProcessor, party);
  }

  @Test
  void executeShouldCallProcessor() {
    testSubject.execute();
    verify(deletePhoneNumberProcessor).execute(arguments, party);
  }

  @Test
  void auditSuccessShouldCallProcessor() {
    testSubject.auditSuccess();
    verify(deletePhoneNumberProcessor).auditSuccess(arguments);
  }

  @ParameterizedTest(name = "auditFailureShouldCallProcessor: message={0}")
  @ValueSource(strings = {TECHNICAL_FAILURE_MESSAGE, SERVICE_FAILURE_MESSAGE})
  void auditFailureShouldCallProcessor(final String message) {
    testSubject.auditFailure(message);
    verify(deletePhoneNumberProcessor).auditFailure(arguments, message);
  }
}
