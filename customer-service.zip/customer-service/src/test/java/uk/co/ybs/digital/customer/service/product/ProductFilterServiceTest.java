package uk.co.ybs.digital.customer.service.product;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildFilteredProducts;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildMockApplicationResponsePrivate;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildOnSaleProductMock;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildOnSaleProducts;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildProductCategoriesUnavailableProductsOnly;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildProductListResponse;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildRequestMetadata;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildUnavailableProductWithWarning;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.getMockApplicationResponsePrivateEmpty;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.Person;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddress;
import uk.co.ybs.digital.customer.service.account.AccountService;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountGroup;
import uk.co.ybs.digital.customer.service.apply.ApplyService;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationStatus;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationsResponsePrivate;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.InterestFrequency;
import uk.co.ybs.digital.customer.web.dto.products.InterestTier;
import uk.co.ybs.digital.customer.web.dto.products.Product;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.customer.web.dto.products.ProductType;
import uk.co.ybs.digital.customer.web.dto.products.Warning;
import uk.co.ybs.digital.customer.web.dto.products.WarningCode;

@ExtendWith(MockitoExtension.class)
class ProductFilterServiceTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2018-11-24T11:56:23");
  private static final String PRODUCT_ID = "YB851266W";
  private static final String PRODUCT_ID_2 = "YBS113131";
  private static final String PRODUCT_ID_ANNUAL = "YB851266WA";
  private static final String PRODUCT_ID_MONTHLY = "YB851266WM";

  private static final UUID REQUEST_ID = UUID.randomUUID();

  @InjectMocks private ProductFilterService productFilterService;

  @Mock private AccountService accountService;
  @Mock private ProductService productService;
  @Mock private ApplyService applyService;

  @Test
  void filterProducts() {

    final Party party = buildCustomer();

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final List<ProductCategory> onSaleProducts = buildOnSaleProducts();

    final List<ProductCategory> availableProducts = buildFilteredProducts();

    when(productService.getOnSaleProducts(requestMetadata)).thenReturn(onSaleProducts);

    when(accountService.getGroupedAccountInfo(requestMetadata, false))
        .thenReturn(buildOwnedAccountMock("ProductId")); // NOPMD

    when(applyService.getApplicationsPrivate(requestMetadata))
        .thenReturn(getMockApplicationResponsePrivateEmpty());

    final List<ProductCategory> result =
        productFilterService.filterProducts(party, requestMetadata, NOW);

    // we don't expect any products to be removed by filtering

    assertThat(result, is(availableProducts));
  }

  @Test
  void filterProductsNoneOnSale() {

    final Party party = buildCustomer();

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final List<ProductCategory> onSaleProducts = Collections.emptyList();

    when(productService.getOnSaleProducts(requestMetadata)).thenReturn(onSaleProducts);

    when(accountService.getGroupedAccountInfo(requestMetadata, false))
        .thenReturn(buildOwnedAccountMock("ProductId")); // NOPMD

    when(applyService.getApplicationsPrivate(requestMetadata))
        .thenReturn(getMockApplicationResponsePrivateEmpty());

    final List<ProductCategory> result =
        productFilterService.filterProducts(party, requestMetadata, NOW);

    assertThat(result, is(Collections.emptyList()));
  }

  @Test
  void filterProductsNoOpenCustomerAccounts() {

    final Party party = buildCustomer();

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final List<ProductCategory> onSaleProducts = buildOnSaleProducts();

    final List<ProductCategory> availableProducts = buildFilteredProducts();

    when(productService.getOnSaleProducts(requestMetadata)).thenReturn(onSaleProducts);

    final AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder().owned(AccountGroup.builder().build()).build();

    when(accountService.getGroupedAccountInfo(requestMetadata, false))
        .thenReturn(accountGroupedInfo);

    when(applyService.getApplicationsPrivate(requestMetadata))
        .thenReturn(getMockApplicationResponsePrivateEmpty());

    final List<ProductCategory> result =
        productFilterService.filterProducts(party, requestMetadata, NOW);

    // we don't expect any products to be removed by filtering
    assertThat(result, is(availableProducts));
  }

  @Test
  void filterProductNonUKAddressShouldReturnOnlyUnavailableProducts() {

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final Party party =
        Party.builder()
            .person(buildPerson(18))
            .address(
                uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                    .postalAddress(
                        PostalAddress.builder()
                            .line1("AddressLine1_1")
                            .country(Country.builder().code("ITA").isoCode("IT").build())
                            .type(AddressType.FPOST)
                            .build())
                    .function(
                        uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.CORR)
                    .build())
            .build();

    final List<ProductCategory> onSaleProducts = buildOnSaleProducts();

    when(productService.getOnSaleProducts(requestMetadata)).thenReturn(onSaleProducts);

    final AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder().owned(AccountGroup.builder().build()).build();

    when(applyService.getApplicationsPrivate(requestMetadata))
        .thenReturn(getMockApplicationResponsePrivateEmpty());

    when(accountService.getGroupedAccountInfo(requestMetadata, false))
        .thenReturn(accountGroupedInfo);

    final List<ProductCategory> result =
        productFilterService.filterProducts(party, requestMetadata, NOW);

    assertThat(result, is(buildProductCategoriesUnavailableProductsOnly()));
  }

  @Test
  void filterProductMissingAddressShouldReturnOnlyUnavailableProducts() {

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final Party party = Party.builder().person(buildPerson(18)).build();

    final List<ProductCategory> onSaleProducts = buildOnSaleProducts();

    when(productService.getOnSaleProducts(requestMetadata)).thenReturn(onSaleProducts);

    final AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder().owned(AccountGroup.builder().build()).build();

    when(accountService.getGroupedAccountInfo(requestMetadata, false))
        .thenReturn(accountGroupedInfo);

    when(applyService.getApplicationsPrivate(requestMetadata))
        .thenReturn(getMockApplicationResponsePrivateEmpty());

    final List<ProductCategory> result =
        productFilterService.filterProducts(party, requestMetadata, NOW);

    assertThat(result, is(buildProductCategoriesUnavailableProductsOnly()));
  }

  @Test
  void filterProductNullCountryCodeShouldReturnProducts() {

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final Party party = buildCustomer();

    final List<ProductCategory> onSaleProducts = buildOnSaleProducts();

    final List<ProductCategory> availableProducts = buildFilteredProducts();

    when(productService.getOnSaleProducts(requestMetadata)).thenReturn(onSaleProducts);

    when(accountService.getGroupedAccountInfo(requestMetadata, false))
        .thenReturn(buildOwnedAccountMock("ProductId")); // NOPMD

    when(applyService.getApplicationsPrivate(requestMetadata))
        .thenReturn(getMockApplicationResponsePrivateEmpty());

    final List<ProductCategory> result =
        productFilterService.filterProducts(party, requestMetadata, NOW);

    assertThat(result, is(availableProducts));
  }

  @Test
  void filterProductShouldThrowExceptionWhenDOBisNull() {

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final Party party = buildCustomer(buildPerson(null));

    final CustomerServiceException exception =
        assertThrows(
            CustomerServiceException.class,
            () -> productFilterService.filterProducts(party, requestMetadata, NOW));

    assertThat(
        exception.getMessage(),
        is(
            String.format(
                "DOB cannot be null for web enabled parties: Party %s", party.getSysId())));
  }

  @Test
  void filterProductShouldIgnoreInvalidProductURL() {

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final Party party = buildCustomer();

    final Product productWithInvalidURL =
        Product.builder()
            .name("Six Access e-Saver ISA Issue 3")
            .type(ProductType.ISA)
            .url("http://localhost:%d/product.html")
            .interestTiers(
                Collections.singletonList(
                    InterestTier.builder()
                        .description("Gross p.a./AER variable on balances of")
                        .rate("0.15%")
                        .range("£1 - £999")
                        .build()))
            .facts(Collections.emptyList())
            .maximumNumberOfAccounts(1)
            .loyalty(false)
            .interestFrequency(InterestFrequency.ANNUAL)
            .build();

    final List<ProductCategory> onSaleProducts =
        Collections.singletonList(
            ProductCategory.builder()
                .title(ProductCategoryTypeHelper.EASY_ACCESS.getTitle())
                .description(ProductCategoryTypeHelper.EASY_ACCESS.getDescription())
                .subTitle(ProductCategoryTypeHelper.EASY_ACCESS.getSubTitle())
                .url("http://localhost:%d/easy-access/index.html?display=allWaysToApply")
                .offlineOnlyProductsAvailable(false)
                .products(Collections.singletonList(productWithInvalidURL))
                .unavailableProducts(Collections.emptyList())
                .build());

    when(productService.getOnSaleProducts(requestMetadata)).thenReturn(onSaleProducts);

    when(accountService.getGroupedAccountInfo(requestMetadata, false))
        .thenReturn(buildOwnedAccountMock("ProductId")); // NOPMD

    when(applyService.getApplicationsPrivate(requestMetadata))
        .thenReturn(getMockApplicationResponsePrivateEmpty());

    List<ProductCategory> result = productFilterService.filterProducts(party, requestMetadata, NOW);

    assertThat(result, is(onSaleProducts));
  }

  @SuppressWarnings("unused")
  private static Stream<Arguments> matchesMaxNumberOfAccounts() {
    return Stream.of(
        Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID,
                InterestFrequency
                    .MONTHLY), // no owned accounts and applications in progress matching so no
            // unavailable products
            buildOwnedAccountMock("222222"),
            getMockApplicationResponsePrivateEmpty(),
            buildProductListResponse(
                Collections.singletonList(
                    buildOnSaleProductMock(1, PRODUCT_ID, InterestFrequency.MONTHLY)),
                Collections.emptyList())),
        Arguments.of(
            buildOnSaleProductMock(
                4,
                PRODUCT_ID,
                InterestFrequency
                    .ANNUAL), // within max number of accounts so product still available
            buildOwnedAccountMock(PRODUCT_ID_ANNUAL),
            buildMockApplicationResponsePrivate(1, PRODUCT_ID_ANNUAL, ApplicationStatus.SUBMITTED),
            buildProductListResponse(
                Collections.singletonList(
                    buildOnSaleProductMock(4, PRODUCT_ID, InterestFrequency.ANNUAL)),
                Collections.emptyList())),
        Arguments.of(
            buildOnSaleProductMock(
                1, PRODUCT_ID, InterestFrequency.ANNUAL), // 1 owned account matching
            buildOwnedAccountMock(PRODUCT_ID_ANNUAL),
            getMockApplicationResponsePrivateEmpty(),
            buildProductListResponse(
                Collections.emptyList(),
                Collections.singletonList(
                    buildUnavailableProductWithWarning(
                        1,
                        PRODUCT_ID,
                        Warning.builder()
                            .code(WarningCode.MAX_NO_OF_ACCOUNTS)
                            .message(
                                "Exceeded maximum number of Accounts. 1 open accounts, 0 applications in progress")
                            .build())))),
        (Arguments.of(
            buildOnSaleProductMock(
                1, PRODUCT_ID, InterestFrequency.ANNUAL), // 1 application in progress matching
            buildOwnedAccountMock("YB111111"),
            buildMockApplicationResponsePrivate(1, PRODUCT_ID_ANNUAL, ApplicationStatus.SUBMITTED),
            buildProductListResponse(
                Collections.emptyList(),
                Collections.singletonList(
                    buildUnavailableProductWithWarning(
                        1,
                        PRODUCT_ID,
                        Warning.builder()
                            .code(WarningCode.MAX_NO_OF_ACCOUNTS)
                            .message(
                                "Exceeded maximum number of Accounts. 0 open accounts, 1 applications in progress")
                            .build()))))),
        (Arguments.of(
            buildOnSaleProductMock(
                1, PRODUCT_ID, InterestFrequency.ANNUAL), // 1 application in progress matching
            buildOwnedAccountMock("YB111111"),
            buildMockApplicationResponsePrivate(1, PRODUCT_ID_ANNUAL, ApplicationStatus.ID_CHECKED),
            buildProductListResponse(
                Collections.emptyList(),
                Collections.singletonList(
                    buildUnavailableProductWithWarning(
                        1,
                        PRODUCT_ID,
                        Warning.builder()
                            .code(WarningCode.MAX_NO_OF_ACCOUNTS)
                            .message(
                                "Exceeded maximum number of Accounts. 0 open accounts, 1 applications in progress")
                            .build()))))),
        (Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID,
                InterestFrequency
                    .MONTHLY), // no filtering because application status is not submitted or id
            // checked
            buildOwnedAccountMock("YB111111"),
            buildMockApplicationResponsePrivate(
                1, PRODUCT_ID_MONTHLY, ApplicationStatus.ACCOUNT_UPDATED),
            buildProductListResponse(
                Collections.singletonList(
                    buildOnSaleProductMock(1, PRODUCT_ID, InterestFrequency.MONTHLY)),
                Collections.emptyList()))),
        (Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID,
                InterestFrequency.ANNUAL), // 1 owned account and 1 application in progress matching
            buildOwnedAccountMock(PRODUCT_ID_ANNUAL),
            buildMockApplicationResponsePrivate(1, PRODUCT_ID_ANNUAL, ApplicationStatus.SUBMITTED),
            buildProductListResponse(
                Collections.emptyList(),
                Collections.singletonList(
                    buildUnavailableProductWithWarning(
                        1,
                        PRODUCT_ID,
                        Warning.builder()
                            .code(WarningCode.MAX_NO_OF_ACCOUNTS)
                            .message(
                                "Exceeded maximum number of Accounts. 1 open accounts, 1 applications in progress")
                            .build()))))),
        Arguments.of(
            buildOnSaleProductMock(
                1,
                PRODUCT_ID_2,
                InterestFrequency
                    .ANNUAL), // test with 1 owned account matching and product ID not ending in W
            buildOwnedAccountMock(PRODUCT_ID_2),
            getMockApplicationResponsePrivateEmpty(),
            buildProductListResponse(
                Collections.emptyList(),
                Collections.singletonList(
                    buildUnavailableProductWithWarning(
                        1,
                        PRODUCT_ID_2,
                        Warning.builder()
                            .code(WarningCode.MAX_NO_OF_ACCOUNTS)
                            .message(
                                "Exceeded maximum number of Accounts. 1 open accounts, 0 applications in progress")
                            .build())))));
  }

  @ParameterizedTest
  @MethodSource("matchesMaxNumberOfAccounts")
  void filterProductShouldRemoveProductWherePartyExceedsMaximum(
      final Product onSaleProducts,
      final AccountGroupedInfo ownedAccounts,
      final ApplicationsResponsePrivate applicationsInProgress,
      final List<ProductCategory> expectedResponse) {

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final Party party = buildCustomer();

    when(productService.getOnSaleProducts(requestMetadata))
        .thenReturn(buildOnSaleProducts(onSaleProducts));

    when(accountService.getGroupedAccountInfo(any(), anyBoolean())).thenReturn(ownedAccounts);

    when(applyService.getApplicationsPrivate(any())).thenReturn(applicationsInProgress);

    List<ProductCategory> result = productFilterService.filterProducts(party, requestMetadata, NOW);

    assertThat(result, is(expectedResponse));
  }

  @ParameterizedTest
  @MethodSource("filterByAge")
  void filterProductBasedOnAge(
      final int age, final Integer minAge, final Integer maxAge, final boolean exists) {

    final RequestMetadata requestMetadata = buildRequestMetadata(REQUEST_ID);

    final Party party = buildCustomer(buildPerson(age));

    final List<ProductCategory> onSaleProducts = buildOnSaleProducts(minAge, maxAge);

    when(productService.getOnSaleProducts(requestMetadata)).thenReturn(onSaleProducts);

    when(accountService.getGroupedAccountInfo(requestMetadata, false))
        .thenReturn(buildOwnedAccountMock("ProductId")); // NOPMD

    when(applyService.getApplicationsPrivate(requestMetadata))
        .thenReturn(getMockApplicationResponsePrivateEmpty());

    final List<ProductCategory> result =
        productFilterService.filterProducts(party, requestMetadata, NOW);

    final List<ProductCategory> expected =
        exists
            ? onSaleProducts
            : buildFilteredProducts(
                minAge,
                maxAge,
                Warning.builder()
                    .code(WarningCode.APPLICANT_AGE)
                    .message("Product age Constraints not met")
                    .build());
    assertThat(result, is(expected));
  }

  @SuppressWarnings("unused")
  private static Stream<Arguments> filterByAge() {
    return Stream.of(
        Arguments.of(16, null, null, true),
        Arguments.of(16, 16, null, true),
        Arguments.of(16, 16, 99, true),
        Arguments.of(99, 16, 99, true),
        Arguments.of(15, 16, null, false),
        Arguments.of(100, null, 99, false),
        Arguments.of(15, 16, 99, false),
        Arguments.of(100, 16, 99, false));
  }

  public Party buildCustomer() {
    return buildCustomer(buildPerson(18));
  }

  private Party buildCustomer(final Person person) {
    return Party.builder()
        .person(person)
        .address(
            uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                .postalAddress(
                    PostalAddress.builder()
                        .line1("AddressLine1_1")
                        .type(AddressType.UKPOST)
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .build())
                .function(
                    uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.CORR)
                .build())
        .build();
  }

  private static AccountGroupedInfo buildOwnedAccountMock(final String productId) {
    return AccountGroupedInfo.builder()
        .owned(
            AccountGroup.builder().account(TestHelper.buildAccount("10000000", productId)).build())
        .build();
  }

  private static Person buildPerson(final Integer age) {
    return Person.builder()
        .title("Mr")
        .forenames("Joe")
        .surname("Bloggs")
        .dateOfBirth(
            Optional.ofNullable(age).map(a -> NOW.toLocalDate().minusYears(a)).orElse(null))
        .dateOfDeath(NOW.toLocalDate())
        .build();
  }
}
