package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn.MarketingOptInCode;
import uk.co.ybs.digital.customer.web.dto.Preferences;

public class PreferencesMapperTest {

  private static final String CREATED_BY_DEFAULT = "DEFAULTDC";
  private static final String CREATED_BY_DEEMED_BOUNCE = "DEEMEDBOUNCE";

  private PreferencesMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new PreferencesMapper();
  }

  @ParameterizedTest(name = "mapsMarketingPreferences : post:{0} phone:{1} email:{2} eagm:{3}")
  @MethodSource("generateAllCombinationsOfParameters")
  void mapsMarketingPreferences(
      final Boolean postStatus,
      final Boolean phoneStatus,
      final Boolean emailStatus,
      final Boolean eagmStatus) {
    final List<MarketingOptIn> marketingOptIns =
        Arrays.asList(
            buildMarketingOptIn(MarketingOptInCode.ADDR, postStatus),
            buildMarketingOptIn(MarketingOptInCode.TEL, phoneStatus),
            buildMarketingOptIn(MarketingOptInCode.EMAIL, emailStatus),
            buildMarketingOptIn(MarketingOptInCode.AGMEML, eagmStatus));

    final Preferences mapped = testSubject.preferences(marketingOptIns);

    assertThat(
        mapped,
        allOf(
            hasProperty(
                "marketing",
                allOf(
                    hasProperty(
                        "email",
                        allOf(hasProperty("status", is(defaultToFalse(emailStatus))))), // NOPMD
                    hasProperty(
                        "phone",
                        allOf(hasProperty("status", is(defaultToFalse(phoneStatus))))), // NOPMD
                    hasProperty(
                        "post",
                        allOf(hasProperty("status", is(defaultToFalse(postStatus))))), // NOPMD
                    hasProperty(
                        "eagm",
                        allOf(
                            hasProperty("status", is(defaultToFalse(eagmStatus))),
                            hasProperty("deemedConsent", is(defaultToFalse(eagmStatus)))))))));
  }

  @Test
  void mapsMarketingPreferencesFalseWhenEmpty() {
    final List<MarketingOptIn> marketingOptIns = Collections.emptyList();

    final Preferences mapped = testSubject.preferences(marketingOptIns);

    assertThat(
        mapped,
        allOf(
            hasProperty(
                "marketing",
                allOf(
                    hasProperty("email", allOf(hasProperty("status", is(false)))), // NOPMD
                    hasProperty("phone", allOf(hasProperty("status", is(false)))), // NOPMD
                    hasProperty("post", allOf(hasProperty("status", is(false)))), // NOPMD
                    hasProperty(
                        "eagm",
                        allOf(
                            hasProperty("status", is(false)),
                            hasProperty("deemedConsent", is(false))))))));
  }

  private static Stream<Arguments> eagmMarketingOptInArgs() {
    // status, createdBy, deemedConsent
    return Stream.of(
        Arguments.of(true, CREATED_BY_DEFAULT, true),
        Arguments.of(false, CREATED_BY_DEFAULT, false),
        Arguments.of(false, CREATED_BY_DEEMED_BOUNCE, true));
  }

  @ParameterizedTest(name = "mapDeemedConsent : post:{0} phone:{1} email:{2} eagm:{3}")
  @MethodSource("eagmMarketingOptInArgs")
  void mapDeemedConsent(final boolean status, final String createdBy, final boolean deemedConsent) {
    final List<MarketingOptIn> marketingOptIns =
        Collections.singletonList(
            buildMarketingOptIn(MarketingOptInCode.AGMEML, status, createdBy));

    final Preferences mapped = testSubject.preferences(marketingOptIns);

    assertThat(
        mapped,
        allOf(
            hasProperty(
                "marketing",
                allOf(
                    hasProperty("email", allOf(hasProperty("status", is(false)))), // NOPMD
                    hasProperty("phone", allOf(hasProperty("status", is(false)))), // NOPMD
                    hasProperty("post", allOf(hasProperty("status", is(false)))), // NOPMD
                    hasProperty(
                        "eagm",
                        allOf(
                            hasProperty("status", is(status)),
                            hasProperty("deemedConsent", is(deemedConsent))))))));
  }

  private boolean defaultToFalse(final Boolean value) {
    return value == null ? false : value;
  }

  @SuppressWarnings("unused")
  private static List<Arguments> generateAllCombinationsOfParameters() {
    final List<Arguments> result = new ArrayList<>();

    Supplier<Stream<Boolean>> statusSupplier = () -> Stream.of(true, false, null);

    statusSupplier
        .get()
        .forEach(
            post ->
                statusSupplier
                    .get()
                    .forEach(
                        phone ->
                            statusSupplier
                                .get()
                                .forEach(
                                    email ->
                                        statusSupplier
                                            .get()
                                            .forEach(
                                                eagm ->
                                                    result.add(
                                                        () ->
                                                            new Object[] {
                                                              post, phone, email, eagm
                                                            })))));

    return result;
  }

  private static MarketingOptIn buildMarketingOptIn(
      final MarketingOptInCode code, final Boolean status) {

    return buildMarketingOptIn(code, status, CREATED_BY_DEFAULT);
  }

  private static MarketingOptIn buildMarketingOptIn(
      final MarketingOptInCode code, final Boolean status, final String createdBy) {

    return MarketingOptIn.builder().code(code).status(status).createdBy(createdBy).build();
  }
}
