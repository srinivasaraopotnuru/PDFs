package uk.co.ybs.digital.customer.utils;

import static org.exparity.hamcrest.date.LocalDateTimeMatchers.within;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFSUC;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.persistence.TypedQuery;
import org.hamcrest.Matcher;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.cache.CacheManager;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.e2e.TestData;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.FatcaParty;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn.MarketingOptInCode;
import uk.co.ybs.digital.customer.model.adgcore.Person;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.core.PartyType;
import uk.co.ybs.digital.customer.model.core.PostalAddress;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.PostalAddressType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdateEmailRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogRequest;
import uk.co.ybs.digital.customer.model.ldap.LdapPerson;
import uk.co.ybs.digital.customer.repository.ldap.LdapPersonRepository;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.Balance;
import uk.co.ybs.digital.customer.service.shareplan.dto.ShareplanAccount;
import uk.co.ybs.digital.customer.service.shareplan.dto.ShareplanAccount.Account;
import uk.co.ybs.digital.customer.web.dto.Address;
import uk.co.ybs.digital.customer.web.dto.CustomerBasic;
import uk.co.ybs.digital.customer.web.dto.CustomerBasicResponse;
import uk.co.ybs.digital.customer.web.dto.CustomerDelayedRequest;
import uk.co.ybs.digital.customer.web.dto.CustomerDetailsExtendedResponse;
import uk.co.ybs.digital.customer.web.dto.CustomerDetailsResponse;
import uk.co.ybs.digital.customer.web.dto.EmailAddressResponse;
import uk.co.ybs.digital.customer.web.dto.EncryptedData;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.customer.web.dto.FailureRequest;
import uk.co.ybs.digital.customer.web.dto.FailureType;
import uk.co.ybs.digital.customer.web.dto.FatcaProfile;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerExtendedRecord;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.MarketingPreferences;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberSubType;
import uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressSubType;
import uk.co.ybs.digital.customer.web.dto.PostalAddressResponse;
import uk.co.ybs.digital.customer.web.dto.Preferences;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.filters.session.SessionIdSourceType;

public final class TestHelper {

  public static final String CANONICAL_PARTY_ID = "12462951";
  public static final String AUDIT_AT = "0795";
  public static final String AUDIT_BY = "SAPP";
  public static final String TECHNICAL_FAILURE_MESSAGE = "Technical Failure";
  public static final String SERVICE_FAILURE_MESSAGE = "Service Failure";
  public static final String USA_COUNTRY_CODE = "USA";
  private static final String EMAIL_ADDRESS = "customer@provider.com";
  public static final String CUSTOMER_EMAIL_ADDRESS = "john.smith@gmail.com";
  public static final String FORENAME = "John";
  public static final String SURNAME = "Smith";
  public static final String CUSTOMER_MOBILE_PHONE_NUMBER = "07515059347";
  public static final String CUSTOMER_WORK_PHONE_NUMBER = "01234421693";
  public static final String CUSTOMER_HOME_PHONE_NUMBER = "01234420713";
  private static final String ACCOUNT_NUMBER = "1234567890";
  private static final String SECOND_ACCOUNT_NUMBER = "9876543210";
  private static final String NON_UK_TAX_REFERENCE_CODE = "223697542";
  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-09-01T00:00:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);
  public static final LocalDateTime YESTERDAY = NOW.minusDays(1);
  private static final int HOME_ADC_CODE = 1234;
  private static final Long PARTY_ID = 123456L;
  private static final String HOME_ADDRESS = "456789";
  private static final String MOBILE_ADDRESS = "07123456789";
  private static final String PHONE_TYPE_HOME = "HOME";
  private static final String PHONE_TYPE_MOBILE = "MOBILE";
  private static final String PHONE_TYPE_WORK = "WORK";
  private static final String DATE_OF_BIRTH =
      LocalDate.now().minusYears(18).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
  private static final String POST_CODE = "PO57 0DE";
  private static long nextId;

  private TestHelper() {}

  public static CustomerBasicResponse buildCustomerBasicResponse() {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId(CANONICAL_PARTY_ID)
                .title("Mr")
                .forename(FORENAME)
                .surname(SURNAME)
                .deceasedDate(LocalDate.of(2019, 12, 4))
                .email(CUSTOMER_EMAIL_ADDRESS)
                .phoneNumbers(
                    Collections.singletonList(
                        PhoneNumberResponse.builder()
                            .number("01234216932")
                            .type(PHONE_TYPE_HOME)
                            .pendingUpdate(false)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build()))
                .build())
        .build();
  }

  public static CustomerBasicResponse buildCustomerBasicDelayedResponse() {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId(CANONICAL_PARTY_ID)
                .title("Mr")
                .forename(FORENAME)
                .surname(SURNAME)
                .deceasedDate(LocalDate.of(2019, 12, 4))
                .email("prev.email@gmail.com")
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number("0123420000")
                            .type(PHONE_TYPE_WORK)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number("07525100000")
                            .type(PHONE_TYPE_MOBILE)
                            .subType(PhoneNumberSubType.MOBILE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number("0123410000")
                            .type(PHONE_TYPE_HOME)
                            .pendingUpdate(false)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build()))
                .build())
        .build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  public static CustomerDetailsResponse buildCustomerDetailsResponse(
      final boolean amendmentRestriction,
      final boolean hasSharePlanAccount,
      final boolean hasIsaSubscription,
      final String webCustomerNumber) {
    return CustomerDetailsResponse.builder()
        .goldenCustomerRecord(
            GoldenCustomerRecord.builder()
                .addresses(
                    Collections.singletonList(
                        PostalAddressResponse.builder()
                            .type("CORR")
                            .postCode("PO57 0DE")
                            .country("GB")
                            .addressLines(
                                Arrays.asList(
                                    "AddressLine1_1",
                                    "AddressLine2_1",
                                    "AddressLine3_1",
                                    "AddressLine4_1"))
                            .build()))
                .partyId(CANONICAL_PARTY_ID)
                .dateOfBirth(LocalDate.of(1980, 12, 12))
                .nationalInsuranceNumber("NI12345")
                .emailAddresses(
                    Collections.singletonList(
                        EmailAddressResponse.builder()
                            .email(CUSTOMER_EMAIL_ADDRESS)
                            .pendingUpdate(false)
                            .type("DEFAULT")
                            .build()))
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_WORK_PHONE_NUMBER)
                            .type(PHONE_TYPE_WORK)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_MOBILE_PHONE_NUMBER)
                            .type(PHONE_TYPE_MOBILE)
                            .subType(PhoneNumberSubType.MOBILE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_HOME_PHONE_NUMBER)
                            .type(PHONE_TYPE_HOME)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build()))
                .forename(FORENAME)
                .surname(SURNAME)
                .title("Mr")
                .amendmentRestriction(amendmentRestriction)
                .hasSharePlanAccount(hasSharePlanAccount)
                .webCustomerNumber(webCustomerNumber)
                .hasIsaSubscription(hasIsaSubscription)
                .nationality("BRITISH")
                .marketingPreferences(
                    MarketingPreferences.builder()
                        .post(true)
                        .phone(true)
                        .email(true)
                        .eagm(true)
                        .build())
                .preferences(
                    Preferences.builder()
                        .marketing(
                            Preferences.Marketing.builder()
                                .eagm(
                                    Preferences.Marketing.Eagm.builder()
                                        .status(true)
                                        .deemedConsent(true)
                                        .build())
                                .email(Preferences.Marketing.Email.builder().status(true).build())
                                .phone(Preferences.Marketing.Phone.builder().status(true).build())
                                .post(Preferences.Marketing.Post.builder().status(true).build())
                                .build())
                        .build())
                .fatcaParty(
                    uk.co.ybs.digital.customer.web.dto.FatcaParty.builder()
                        .fatcaResponseUK(false)
                        .fatcaResponseUS(true)
                        .build())
                .fatcaProfiles(
                    Arrays.asList(
                        FatcaProfile.builder()
                            .countryCode(USA_COUNTRY_CODE)
                            .nonUKTaxReferenceCode(NON_UK_TAX_REFERENCE_CODE)
                            .countryRelationCode("CITZEN")
                            .build(),
                        FatcaProfile.builder()
                            .countryCode(USA_COUNTRY_CODE)
                            .nonUKTaxReferenceCode(NON_UK_TAX_REFERENCE_CODE)
                            .countryRelationCode("TAXRES")
                            .build()))
                .build())
        .build();
  }

  public static CustomerDetailsExtendedResponse buildCustomerDetailsExtendedResponse(
      final boolean amendmentRestriction,
      final boolean hasSharePlanAccount,
      final boolean hasIsaSubscription,
      final String webCustomerNumber) {

    return CustomerDetailsExtendedResponse.builder()
        .goldenCustomerExtendedRecord(
            GoldenCustomerExtendedRecord.builder()
                .addresses(
                    Collections.singletonList(
                        PostalAddressResponse.builder()
                            .type("CORR")
                            .postCode("PO57 0DE")
                            .country("GB")
                            .addressLines(
                                Arrays.asList(
                                    "AddressLine1_1",
                                    "AddressLine2_1",
                                    "AddressLine3_1",
                                    "AddressLine4_1"))
                            .build()))
                .partyId(CANONICAL_PARTY_ID)
                .dateOfBirth(LocalDate.of(1980, 12, 12))
                .placeOfBirth(
                    EncryptedData.builder()
                        .keyId("encryption-build-client-nonprod-1")
                        .data(
                            "Rqa9Qp1CWsb1Mnddeo1keCAsA9RdgyAEFGAV1sXyw/VVcKedACrpKAcXVMUSESFLqOxpWZv53LG3DVAxqnCe3ghK8uRdHUUxY6rjRdOUv1gqhcJ3ZEAPkl81NZI+23BGlcM7exM8gKmL2O9IOk4fdJ4LK/gHb/051hRv7mWetUtfc5QHsftOcQ+QZzO433NjRLgePmPa9MO/4xUTemIhkfUXcvqOJAiD/V0+GWVxVqMy/LxeFi1nucqfT+wtYLnOX3OhZHZWtQLcZBIC1R1ZdBEBuhREU4BYvzg6YF1ZCHrSm84I2EhSILSHvucPO/o7L9vkRanoWVdmcK6xdlKzjw==")
                        .build())
                .nationalInsuranceNumber("NI12345")
                .emailAddresses(
                    Collections.singletonList(
                        EmailAddressResponse.builder()
                            .email(CUSTOMER_EMAIL_ADDRESS)
                            .pendingUpdate(false)
                            .type("DEFAULT")
                            .build()))
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_WORK_PHONE_NUMBER)
                            .type(PHONE_TYPE_WORK)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_MOBILE_PHONE_NUMBER)
                            .type(PHONE_TYPE_MOBILE)
                            .subType(PhoneNumberSubType.MOBILE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_HOME_PHONE_NUMBER)
                            .type(PHONE_TYPE_HOME)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build()))
                .forename(FORENAME)
                .surname(SURNAME)
                .title("Mr")
                .amendmentRestriction(amendmentRestriction)
                .hasSharePlanAccount(hasSharePlanAccount)
                .webCustomerNumber(webCustomerNumber)
                .hasIsaSubscription(hasIsaSubscription)
                .nationality("BRITISH")
                .marketingPreferences(
                    MarketingPreferences.builder()
                        .post(true)
                        .phone(true)
                        .email(true)
                        .eagm(true)
                        .build())
                .preferences(
                    Preferences.builder()
                        .marketing(
                            Preferences.Marketing.builder()
                                .eagm(
                                    Preferences.Marketing.Eagm.builder()
                                        .status(true)
                                        .deemedConsent(true)
                                        .build())
                                .email(Preferences.Marketing.Email.builder().status(true).build())
                                .phone(Preferences.Marketing.Phone.builder().status(true).build())
                                .post(Preferences.Marketing.Post.builder().status(true).build())
                                .build())
                        .build())
                .fatcaParty(
                    uk.co.ybs.digital.customer.web.dto.FatcaParty.builder()
                        .fatcaResponseUK(false)
                        .fatcaResponseUS(true)
                        .build())
                .fatcaProfiles(
                    Arrays.asList(
                        FatcaProfile.builder()
                            .countryCode(USA_COUNTRY_CODE)
                            .nonUKTaxReferenceCode(NON_UK_TAX_REFERENCE_CODE)
                            .countryRelationCode("CITZEN")
                            .build(),
                        FatcaProfile.builder()
                            .countryCode(USA_COUNTRY_CODE)
                            .nonUKTaxReferenceCode(NON_UK_TAX_REFERENCE_CODE)
                            .countryRelationCode("TAXRES")
                            .build()))
                .build())
        .build();
  }

  public static List<MarketingOptIn> buildMarketingOptIns() {
    return Arrays.asList(
        MarketingOptIn.builder().code(MarketingOptInCode.ADDR).status(true).build(),
        MarketingOptIn.builder().code(MarketingOptInCode.TEL).status(true).build(),
        MarketingOptIn.builder().code(MarketingOptInCode.EMAIL).status(true).build(),
        MarketingOptIn.builder().code(MarketingOptInCode.AGMEML).status(true).build());
  }

  public static List<uk.co.ybs.digital.customer.model.adgcore.FatcaProfile> buildFatcaProfiles() {
    return Arrays.asList(
        uk.co.ybs.digital.customer.model.adgcore.FatcaProfile.builder()
            .countryCode(USA_COUNTRY_CODE)
            .countryRelationCode("CITZEN")
            .nonUKTaxReferenceCode(NON_UK_TAX_REFERENCE_CODE)
            .sysId(1L)
            .fatcaPartySysId(PARTY_ID)
            .startDate(NOW.minusDays(1))
            .build(),
        uk.co.ybs.digital.customer.model.adgcore.FatcaProfile.builder()
            .countryCode(USA_COUNTRY_CODE)
            .countryRelationCode("TAXRES")
            .nonUKTaxReferenceCode(NON_UK_TAX_REFERENCE_CODE)
            .sysId(2L)
            .fatcaPartySysId(PARTY_ID)
            .startDate(NOW.minusDays(1))
            .build());
  }

  public static Optional<FatcaParty> buildFatcaParty() {
    return Optional.ofNullable(
        FatcaParty.builder()
            .fatcaResponseUK(false)
            .fatcaResponseUS(true)
            .partyId(PARTY_ID)
            .sysId(1L)
            .startDate(NOW.minusDays(1))
            .build());
  }

  public static CustomerDetailsResponse buildCustomerDetailsResponse(
      final boolean amendmentRestriction,
      final boolean hasSharePlanAccount,
      final Address address) {

    List<String> addressLines = new ArrayList<>();
    addressLines.addAll(address.getAddressLines());

    return CustomerDetailsResponse.builder()
        .goldenCustomerRecord(
            GoldenCustomerRecord.builder()
                .addresses(
                    Collections.singletonList(
                        PostalAddressResponse.builder()
                            .type("CORR")
                            .postCode(address.getPostCode())
                            .country(address.getCountry())
                            .addressLines(addressLines)
                            .build()))
                .partyId(CANONICAL_PARTY_ID)
                .dateOfBirth(LocalDate.of(1980, 12, 12))
                .nationalInsuranceNumber("NI12345")
                .emailAddresses(
                    Collections.singletonList(
                        EmailAddressResponse.builder()
                            .email(CUSTOMER_EMAIL_ADDRESS)
                            .pendingUpdate(false)
                            .type("DEFAULT")
                            .build()))
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_WORK_PHONE_NUMBER)
                            .type(PHONE_TYPE_WORK)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_MOBILE_PHONE_NUMBER)
                            .type(PHONE_TYPE_MOBILE)
                            .subType(PhoneNumberSubType.MOBILE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_HOME_PHONE_NUMBER)
                            .type(PHONE_TYPE_HOME)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build()))
                .forename(FORENAME)
                .surname(SURNAME)
                .title("Mr")
                .amendmentRestriction(amendmentRestriction)
                .hasSharePlanAccount(hasSharePlanAccount)
                .nationality("BRITISH")
                .build())
        .build();
  }

  public static ErrorResponse buildErrorResponseNotFound(final UUID requestId) {
    return ErrorResponse.builder()
        .code("404 Not Found")
        .id(requestId)
        .message("Resource not found")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Resource.NotFound")
                .message("Resource not found")
                .build())
        .build();
  }

  public static ErrorResponse buildErrorResponseMultipleRecordsFound(final UUID requestId) {
    return ErrorResponse.builder()
        .code("409 Conflict")
        .id(requestId)
        .message("Multiple records found")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Resource.MultipleRecordsFound")
                .message("Multiple records found")
                .build())
        .build();
  }

  public static ErrorResponse buildErrorResponseInternalServerError(final UUID requestId) {
    return ErrorResponse.builder()
        .code("500 Internal Server Error")
        .id(requestId)
        .message("Internal Server Error")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("UnexpectedError")
                .message("Internal Server Error")
                .build())
        .build();
  }

  public static ErrorResponse buildErrorResponseMethodNotSupported(final UUID requestId) {
    return ErrorResponse.builder()
        .code("405 Method Not Allowed")
        .id(requestId)
        .message("Method Not Allowed")
        .error(
            ErrorItem.builder()
                .errorCode("Unsupported.Method")
                .message("Unsupported method")
                .build())
        .build();
  }

  public static ErrorResponse buildErrorResponseInvalidField(
      final UUID requestId, final String errorCode, final String errorMessage, final String field) {
    return ErrorResponse.builder(HttpStatus.BAD_REQUEST)
        .id(requestId)
        .message("Invalid request body")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode(errorCode)
                .message(errorMessage)
                .path(field)
                .build())
        .build();
  }

  public static ErrorResponse buildErrorResponseInvalidFieldMultipleErrors(
      final UUID requestId,
      final String errorMessage1,
      final String errorMessage2,
      final String errorMessage3,
      final String field) {
    return ErrorResponse.builder(HttpStatus.BAD_REQUEST)
        .id(requestId)
        .message("Invalid request body")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Field.Invalid")
                .message(errorMessage1)
                .path(field)
                .build())
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Field.Invalid")
                .message(errorMessage2)
                .path(field)
                .build())
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Field.Invalid")
                .message(errorMessage3)
                .path(field)
                .build())
        .build();
  }

  public static ErrorResponse unauthorizedErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("401 Unauthorized")
        .message("Unauthorized")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("Unauthorized")
                .message("Unauthorized")
                .build())
        .build();
  }

  public static ErrorResponse accessDeniedErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .error(
            ErrorResponse.ErrorItem.builder()
                .errorCode("AccessDenied")
                .message("Access Denied")
                .build())
        .build();
  }

  public static ErrorResponse invalidSessionIdErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("400 Bad Request")
        .message("Bad Request")
        .errors(
            Collections.singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("SessionId is not a valid UUID")
                    .path(SessionIdSourceType.HEADER.toString())
                    .build()))
        .build();
  }

  public static String readClassPathResource(final String classPathResource) {
    return readClassPathResource(new ClassPathResource(classPathResource));
  }

  public static String readClassPathResource(final Resource resource) {
    try {
      return new String(Files.readAllBytes(resource.getFile().toPath()), StandardCharsets.UTF_8);
    } catch (IOException e) {
      throw new RuntimeException("Error reading " + resource, e);
    }
  }

  public static RequestMetadata createRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(UUID.fromString("8e112ed4-0374-47d0-aa82-427049d2dab4"))
        .sessionId(UUID.fromString("8e112ed4-0374-47d0-aa82-427049d2dab4"))
        .host(InetSocketAddress.createUnresolved("accountservice.ybs.co.uk", 443))
        .brandCode("YBS")
        .partyId("123456") // NOPMD
        .forwardingAuth("<jwt>")
        .ipAddress("12.66.53.145")
        .webCustomerNumber("123456")
        .build();
  }

  private static WorkLog buildWorkLog(
      final Long partyId,
      final Operation operation,
      final RequestMetadata requestMetadata,
      final WorkLogPayload workLogPayload) {
    return WorkLog.builder()
        .partyId(partyId)
        .status(WorkLog.Status.PENDING)
        .operation(operation)
        .message(
            WorkLogRequest.builder()
                .workLogPayload(workLogPayload)
                .metadata(requestMetadata)
                .build())
        .build();
  }

  public static WorkLog buildWorkLogWithUpdateEmailAddress(
      final Long partyId, final RequestMetadata requestMetadata) {
    return buildWorkLog(
        partyId, Operation.EMAIL_ADDRESS, requestMetadata, buildUpdateEmailPayload(EMAIL_ADDRESS));
  }

  public static WorkLog buildWorkLogWithUpdateMobilePhoneNumber(
      final Long partyId, final RequestMetadata requestMetadata) {

    return buildWorkLog(
        partyId,
        Operation.UPDATE_PHONE_NUMBER,
        requestMetadata,
        buildUpdateMobilePhoneNumberPayload());
  }

  public static WorkLog buildWorkLogWithUpdatePhoneNumber(
      final Long partyId, final RequestMetadata requestMetadata) {

    return buildWorkLog(
        partyId,
        Operation.UPDATE_PHONE_NUMBER,
        requestMetadata,
        buildUpdateHomePhoneNumberPayload());
  }

  public static WorkLog buildWorkLogWithDeletePhoneNumber(
      final Long partyId, final RequestMetadata requestMetadata) {

    return buildWorkLog(
        partyId,
        Operation.DELETE_PHONE_NUMBER,
        requestMetadata,
        buildDeletePhoneNumberPayload(PhoneNumberRequestType.MOBILE));
  }

  public static WorkLog buildWorkLogWithUpdatePostalAddress(
      final Long partyId, final RequestMetadata requestMetadata) {

    return buildWorkLog(
        partyId, Operation.POSTAL_ADDRESS, requestMetadata, buildUpdatePostalAddressPayload());
  }

  public static WorkLog buildWorkLogWithUpdatePostalAddressWithSetLines(
      final Long partyId, final RequestMetadata requestMetadata, final List<String> addressLines) {

    return buildWorkLog(
        partyId,
        Operation.POSTAL_ADDRESS,
        requestMetadata,
        buildUpdatePostalAddressPayloadWithSetLines(addressLines));
  }

  public static void fixBiDirectionalReferences(final Party party) {

    Optional.ofNullable(party.getPerson()).ifPresent(person -> person.setParty(party));

    for (AddressUsage addressUsage : party.getAddresses()) {
      addressUsage.setParty(party);

      if (addressUsage.getNonPostalAddress() != null) {
        addressUsage.getNonPostalAddress().setUsages(Collections.singleton(addressUsage));
      }

      if (addressUsage.getPostalAddress() != null) {
        addressUsage.getPostalAddress().setUsages(Collections.singleton(addressUsage));
      }

      for (AddressUsageFunction add : addressUsage.getFunctions()) {
        add.setAddressUsage(addressUsage);
      }
    }
  }

  public static Party buildPartyWithNonPostalAddressUsages(
      final List<NonPostalAddress> nonPostalAddresses) {

    Party party = Party.builder().sysId(1L).partyType(buildPartyType()).build();

    List<AddressUsage> au = new ArrayList<>();

    nonPostalAddresses.forEach(
        npa -> {
          au.add(
              AddressUsage.builder()
                  .nonPostalAddress(npa)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .startDate(YESTERDAY)
                  .createdDate(YESTERDAY)
                  .createdAt(AUDIT_AT)
                  .createdBy(AUDIT_BY)
                  .preferredContactMethod(true)
                  .podCode("8AM-12PM")
                  .function(
                      AddressUsageFunction.builder()
                          .id(
                              AddressUsageFunction.AddressUsageFunctionPK.builder()
                                  .function(AddressUsage.AddressFunction.DIRCOM)
                                  .startDate(YESTERDAY)
                                  .build())
                          .build())
                  .build());
        });

    party.setAddresses(au);

    return party;
  }

  public static NonPostalAddress buildEmailAddress(final String emailAddress) {
    return NonPostalAddress.builder().type(AddressType.EMAIL).address(emailAddress).build();
  }

  public static uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress buildEmailAddressADG(
      final String emailAddress) {
    return uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress.builder()
        .type(uk.co.ybs.digital.customer.model.adgcore.AddressType.EMAIL)
        .address(emailAddress)
        .sysId(getNextId())
        .build();
  }

  public static Country buildCountry() {
    return buildCountry("UK", "GB");
  }

  public static Country buildCountry(final String countryCode, final String isoCode) {
    return Country.builder().code(countryCode).isoCode(isoCode).build();
  }

  private static NonPostalAddress buildHomePhoneNumberRequest(final NPASourceType sourceType) {
    return NonPostalAddress.builder()
        .address(HOME_ADDRESS)
        .type(AddressType.TEL)
        .adcCode(HOME_ADC_CODE)
        .sourceType(sourceType)
        .country(buildCountry())
        .build();
  }

  private static NonPostalAddress buildMobilePhoneNumberRequest(final NPASourceType sourceType) {
    return NonPostalAddress.builder()
        .address(MOBILE_ADDRESS)
        .type(AddressType.TEL)
        .sourceType(sourceType)
        .build();
  }

  public static NonPostalAddress buildHomePhoneNumberRequest() {
    return buildHomePhoneNumberRequest(NPASourceType.HOME);
  }

  public static NonPostalAddress buildMobilePhoneNumberRequest() {
    return buildMobilePhoneNumberRequest(NPASourceType.MOBILE);
  }

  public static NonPostalAddress buildWorkLandlinePhoneNumberRequest() {
    return buildHomePhoneNumberRequest(NPASourceType.WORK);
  }

  public static NonPostalAddress buildWorkMobilePhoneNumberRequest() {
    return buildMobilePhoneNumberRequest(NPASourceType.WORK);
  }

  public static PartyType buildPartyType() {
    return PartyType.builder().code("PERSON").type("PERSON").startDate(YESTERDAY).build(); // NOPMD
  }

  public static void assertNonPostalAddressUsages(
      final TestEntityManager coreTestEntityManager,
      final TransactionTemplate transactionTemplate,
      final Long partyId,
      final Matcher<Iterable<? extends AddressUsage>> expected,
      final AddressType addressType,
      final NPASourceType sourceType) {

    final Set<AddressType> addressTypes = EnumSet.of(addressType);
    final Set<AddressUsage.AddressFunction> addressFunctions =
        EnumSet.allOf(AddressUsage.AddressFunction.class);

    List<AddressUsage> addressUsages =
        getAddressUsages(
            coreTestEntityManager,
            transactionTemplate,
            partyId,
            addressTypes,
            addressFunctions,
            sourceType);

    assertThat(addressUsages, expected);
  }

  public static void assertPostalAddressUsages(
      final TestEntityManager coreTestEntityManager,
      final TransactionTemplate transactionTemplate,
      final Long partyId,
      final Matcher<Iterable<? extends AddressUsage>> expected,
      final AddressType addressType) {

    final Set<AddressType> addressTypes = EnumSet.of(addressType);
    final Set<AddressUsage.AddressFunction> addressFunctions =
        EnumSet.allOf(AddressUsage.AddressFunction.class);

    List<AddressUsage> addressUsages =
        getAddressUsages(
            coreTestEntityManager,
            transactionTemplate,
            partyId,
            addressTypes,
            addressFunctions,
            null);

    assertThat(addressUsages, expected);
  }

  private static List<AddressUsage> getAddressUsages(
      final TestEntityManager coreTestEntityManager,
      final TransactionTemplate transactionTemplate,
      final Long partyId,
      final Set<AddressType> addressTypes,
      final Set<AddressUsage.AddressFunction> addressFunctions,
      final NPASourceType sourceType) {

    final String sql =
        "SELECT addressUsage FROM AddressUsage addressUsage "
            + "LEFT OUTER JOIN addressUsage.nonPostalAddress "
            + "LEFT OUTER JOIN addressUsage.postalAddress "
            + "JOIN FETCH addressUsage.functions "
            + "WHERE addressUsage.party.sysId = :partyId "
            + " AND (addressUsage.nonPostalAddress.type IN :addressTypes "
            + "        OR addressUsage.postalAddress.type IN :addressTypes) "
            + "   AND (addressUsage.function IN :addressFunctions) "
            + " AND :sourceType IS NULL OR addressUsage.nonPostalAddress.sourceType = :sourceType "
            + "ORDER BY addressUsage.sysId";

    return transactionTemplate.execute(
        transactionStatus -> {
          final TypedQuery<AddressUsage> query =
              coreTestEntityManager.getEntityManager().createQuery(sql, AddressUsage.class);
          query.setParameter("partyId", partyId);
          query.setParameter("addressTypes", addressTypes);
          query.setParameter("addressFunctions", addressFunctions);
          query.setParameter("sourceType", sourceType);

          return query.getResultList();
        });
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public static Matcher<AddressUsage> addressUsageMatcher(
      final AddressUsage.AddressFunction function,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final LocalDateTime createdDate,
      final String createdAt,
      final String createdBy,
      final LocalDateTime endedDate,
      final String endedAt,
      final String endedBy,
      final boolean preferredContactMethod,
      final String podCode,
      final Matcher<NonPostalAddress> nonPostalAddress,
      final Matcher<PostalAddress> postalAddress) {
    Matcher<AddressUsageFunction> addressUsageFunction =
        addressUsageFunctionMatcher(startDate, endDate);
    return allOf(
        hasProperty("function", is(function)),
        hasProperty("startDate", withinTenSecondsOf(startDate)),
        hasProperty("endDate", withinTenSecondsOf(endDate)),
        hasProperty("createdDate", withinTenSecondsOf(createdDate)),
        hasProperty("createdAt", is(createdAt)),
        hasProperty("createdBy", is(createdBy)),
        hasProperty("endedDate", withinTenSecondsOf(endedDate)),
        hasProperty("endedAt", is(endedAt)),
        hasProperty("endedBy", is(endedBy)),
        hasProperty("preferredContactMethod", is(preferredContactMethod)),
        hasProperty("podCode", is(podCode)),
        hasProperty("nonPostalAddress", nonPostalAddress),
        hasProperty("postalAddress", postalAddress),
        hasProperty("functions", contains(addressUsageFunction)));
  }

  public static Matcher<NonPostalAddress> nonPostalAddressMatcher(
      final AddressType type, final String address) {
    return allOf(hasProperty("type", is(type)), hasProperty("address", is(address)));
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public static Matcher<PostalAddress> postalAddressMatcher(
      final Matcher<Long> sysId,
      final AddressType type,
      final String line1,
      final String line2,
      final String line3,
      final String line4,
      final String line5,
      final PostCode postCode,
      final Country country,
      final String pafStatus,
      final Integer pafAddressKey,
      final String pafDps,
      final String pafKeyPart3,
      final String pafReturnCode) {
    return allOf(
        hasProperty("sysId", sysId),
        hasProperty("type", is(type)),
        hasProperty("line1", is(line1)),
        hasProperty("line2", is(line2)),
        hasProperty("line3", is(line3)),
        hasProperty("line4", is(line4)),
        hasProperty("line5", is(line5)),
        hasProperty("postCode", is(postCode)),
        hasProperty("country", is(country)),
        hasProperty("pafStatus", is(pafStatus)),
        hasProperty("pafAddressKey", is(pafAddressKey)),
        hasProperty("pafDps", is(pafDps)),
        hasProperty("pafKeyPart3", is(pafKeyPart3)),
        hasProperty("pafReturnCode", is(pafReturnCode)));
  }

  private static Matcher<AddressUsageFunction> addressUsageFunctionMatcher(
      final LocalDateTime startDate, final LocalDateTime endDate) {

    Matcher<AddressUsageFunction.AddressUsageFunctionPK> addressUsageFunctionPK =
        addressUsageFunctionPKMatcher(startDate);

    return allOf(
        hasProperty("id", is(addressUsageFunctionPK)),
        hasProperty("endDate", withinTenSecondsOf(endDate)));
  }

  private static Matcher<AddressUsageFunction.AddressUsageFunctionPK> addressUsageFunctionPKMatcher(
      final LocalDateTime startDate) {

    return allOf(hasProperty("startDate", withinTenSecondsOf(startDate)));
  }

  private static Matcher<LocalDateTime> withinTenSecondsOf(final LocalDateTime time) {
    if (time == null) {
      return is(time);
    }
    return within(10, ChronoUnit.SECONDS, time);
  }

  public static void assertLdapEmailAddressValue(
      final LdapPersonRepository ldapPersonRepository, final String updatedEmailAddress) {
    final Optional<LdapPerson> ldapPerson =
        ldapPersonRepository.findByUid(TestData.CUSTOMER_LDAP_PERSON_UID_VALID);
    assertThat(ldapPerson.isPresent(), is(true));
    assertThat(ldapPerson.get().getEmailAddress(), is(updatedEmailAddress));
  }

  public static UpdateEmailRequest buildUpdateEmailPayload(final String email) {
    return UpdateEmailRequest.builder().requestType("Email").email(email).build();
  }

  public static UpdatePhoneRequest buildUpdateHomePhoneNumberPayload() {
    return UpdatePhoneRequest.builder()
        .requestType(PhoneNumberRequestType.HOME)
        .areaDiallingCode(HOME_ADC_CODE)
        .number(HOME_ADDRESS)
        .build();
  }

  public static UpdatePhoneRequest buildUpdateMobilePhoneNumberPayload() {
    return UpdatePhoneRequest.builder()
        .requestType(PhoneNumberRequestType.MOBILE)
        .number(MOBILE_ADDRESS)
        .build();
  }

  public static UpdatePhoneRequest buildUpdateWorkLandlinePhoneNumberPayload() {
    return UpdatePhoneRequest.builder()
        .requestType(PhoneNumberRequestType.WORK)
        .areaDiallingCode(HOME_ADC_CODE)
        .number(HOME_ADDRESS)
        .build();
  }

  public static UpdatePhoneRequest buildUpdateWorkMobilePhoneNumberPayload() {
    return UpdatePhoneRequest.builder()
        .requestType(PhoneNumberRequestType.WORK)
        .number(MOBILE_ADDRESS)
        .build();
  }

  public static DeletePhoneRequest buildDeletePhoneNumberPayload(
      final PhoneNumberRequestType phoneNumberRequestType) {
    return DeletePhoneRequest.builder().requestType(phoneNumberRequestType).build();
  }

  public static UpdatePostalAddressRequest buildUpdatePostalAddressPayload() {
    return buildUpdatePostalAddressPayload(PostalAddressType.UKPOST);
  }

  public static UpdatePostalAddressRequest buildUpdatePostalAddressPayload(
      final PostalAddressType postalAddressType) {

    return UpdatePostalAddressRequest.builder()
        .addressType(PostalAddressSubType.UKPOST)
        .function(uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressType.CORR)
        .addressLine1("1 FAKE LANE")
        .country(PermittedCountries.UNITED_KINGDOM.getCode())
        .areaCode("RM")
        .districtCode("4")
        .sectorCode("1")
        .unitCode("PL")
        .build();
  }

  public static UpdatePostalAddressRequest buildUpdatePostalAddressPayloadWithSetLines(
      final List<String> postalAddressLines) {

    return UpdatePostalAddressRequest.builder()
        .addressType(PostalAddressSubType.UKPOST)
        .function(uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressType.CORR)
        .addressLine1(postalAddressLines.get(0))
        .addressLine2(postalAddressLines.get(1))
        .addressLine3(postalAddressLines.get(2))
        .addressLine4(postalAddressLines.get(3))
        .addressLine5(postalAddressLines.get(4))
        .country(PermittedCountries.UNITED_KINGDOM.getCode())
        .areaCode("RM")
        .districtCode("4")
        .sectorCode("1")
        .unitCode("PL")
        .build();
  }

  public static LdapPerson buildLdapPerson() {

    return LdapPerson.builder()
        .id(LdapUtils.newLdapName("uid=0000123456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))
        .accessTime(Instant.parse("2019-04-02T10:21:41.894Z"))
        .uid("0000123456")
        .groups(Arrays.asList("eview", "direct"))
        .passwordState("PWD_OK")
        .customerNumber("000987654")
        .emailAddress(CUSTOMER_EMAIL_ADDRESS)
        .build();
  }

  private static Account buildAccount(final String accountNumber) {
    return Account.builder().accountNumber(accountNumber).build();
  }

  public static ShareplanAccount buildShareplanAccount() {
    List<Account> accounts = new ArrayList<>();
    accounts.add(buildAccount(ACCOUNT_NUMBER));
    accounts.add(buildAccount(SECOND_ACCOUNT_NUMBER));

    return ShareplanAccount.builder().accounts(accounts).build();
  }

  public static ShareplanAccount buildEmptyShareplanAccount() {
    List<Account> accounts = new ArrayList<>();
    return ShareplanAccount.builder().accounts(accounts).build();
  }

  public static PostalAddress buildPostalAddressRequest() {

    return PostalAddress.builder()
        .sysId(1L)
        .type(AddressType.UKPOST)
        .line1("AddressLine1_1")
        .line2("AddressLine2_1")
        .line3("AddressLine3_1")
        .country(Country.builder().code("UK").build())
        .postCode(
            PostCode.builder()
                .areaCode("PO")
                .districtCode("57")
                .sectorCode("0")
                .unitCode("DE")
                .build())
        .type(AddressType.UKPOST)
        .pafStatus("PAFNUS")
        .build();
  }

  public static PostalAddress buildPostalAddressWithPafRequest() {

    return PostalAddress.builder()
        .sysId(1L)
        .line1("AddressLine1_1")
        .line2("AddressLine2_1")
        .line3("AddressLine3_1")
        .country(Country.builder().code("UK").build())
        .postCode(
            PostCode.builder()
                .areaCode("PO")
                .districtCode("57")
                .sectorCode("0")
                .unitCode("DE")
                .build())
        .type(AddressType.UKPOST)
        .pafStatus(PAF_STATUS_PAFSUC)
        .pafAddressKey(282594)
        .pafDps("PAFDPS")
        .pafKeyPart3("AddressLine1_1".substring(0, 10))
        .build();
  }

  public static PostalAddress buildBasePostalAddressRequest() {

    return PostalAddress.builder()
        .line1("line1")
        .line2("line2")
        .line3("line3")
        .line3("line4")
        .line3("line5")
        .country(Country.builder().code("UK").build())
        .postCode(
            PostCode.builder()
                .areaCode("AA")
                .districtCode("01")
                .sectorCode("0")
                .unitCode("AA")
                .build())
        .type(AddressType.UKPOST)
        .build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  public static AccountGroupedInfo.AccountSummary buildAccount(
      final String accountNumber, final String productIdentifier) {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber(accountNumber)
        .accountName("Test")
        .amendmentRestriction(true)
        .accountSortCode("123456") // NOPMD
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .deposits(AccountGroupedInfo.DepositsSummary.builder().permittedOverApi(true).build())
        .withdrawals(AccountGroupedInfo.WithdrawalsSummary.builder().permittedOverApi(true).build())
        .currency("GBP")
        .productIdentifier(productIdentifier)
        .productDescription(productIdentifier + " Description")
        .isa(AccountGroupedInfo.Isa.builder().flexible(true).helpToBuy(false).build())
        .balances(
            Collections.singletonList(
                AccountGroupedInfo.Balance.builder()
                    .type("InterimAvailable")
                    .amount(new BigDecimal("100.00"))
                    .build()))
        .build();
  }

  public static Party buildPartyWithPostalAddressUsages(
      final List<PostalAddress> postalAddresses,
      final List<AddressUsage.AddressFunction> addressFunctions) {

    Party party = Party.builder().sysId(PARTY_ID).partyType(buildPartyType()).build();

    List<AddressUsage> au = new ArrayList<>();

    postalAddresses.forEach(
        pa -> {
          au.add(
              AddressUsage.builder()
                  .postalAddress(pa)
                  .function(addressFunctions.get(postalAddresses.indexOf(pa)))
                  .startDate(YESTERDAY)
                  .createdDate(YESTERDAY)
                  .createdAt(AUDIT_AT)
                  .createdBy(AUDIT_BY)
                  .preferredContactMethod(true)
                  .function(
                      AddressUsageFunction.builder()
                          .id(
                              AddressUsageFunction.AddressUsageFunctionPK.builder()
                                  .function(AddressUsage.AddressFunction.CORR)
                                  .startDate(YESTERDAY)
                                  .build())
                          .build())
                  .build());
        });

    party.setAddresses(au);

    return party;
  }

  public static void clearCacheManager(final CacheManager cacheManager) {
    cacheManager
        .getCacheNames()
        .forEach(name -> Objects.requireNonNull(cacheManager.getCache(name)).invalidate());
  }

  public static CustomerBasicResponse buildCustomerDelayedResponse() {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId(CANONICAL_PARTY_ID)
                .title("Mr")
                .forename(FORENAME)
                .surname(SURNAME)
                .deceasedDate(LocalDate.of(2020, 9, 01))
                .dateOfBirth(LocalDate.now().minusYears(18))
                .email(CUSTOMER_EMAIL_ADDRESS)
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_WORK_PHONE_NUMBER)
                            .type(PHONE_TYPE_WORK)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_MOBILE_PHONE_NUMBER)
                            .type(PHONE_TYPE_MOBILE)
                            .subType(PhoneNumberSubType.MOBILE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_HOME_PHONE_NUMBER)
                            .type(PHONE_TYPE_HOME)
                            .pendingUpdate(false)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build()))
                .webCustomerNumber(CANONICAL_PARTY_ID)
                .webUsername("John123")
                .build())
        .build();
  }

  public static CustomerBasicResponse buildCustomerDelayedNonWebResponse() {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId(CANONICAL_PARTY_ID)
                .title("Mr")
                .forename("Joe")
                .surname("Bloggs")
                .dateOfBirth(LocalDate.now().minusYears(18))
                .email(CUSTOMER_EMAIL_ADDRESS)
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_WORK_PHONE_NUMBER)
                            .type(PHONE_TYPE_WORK)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_MOBILE_PHONE_NUMBER)
                            .type(PHONE_TYPE_MOBILE)
                            .subType(PhoneNumberSubType.MOBILE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_HOME_PHONE_NUMBER)
                            .type(PHONE_TYPE_HOME)
                            .pendingUpdate(false)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build()))
                .build())
        .build();
  }

  public static CustomerDelayedRequest buildCustomerDelayedRequest() {
    return buildCustomForenameCustomerDelayedRequest(FORENAME);
  }

  public static CustomerDelayedRequest buildCustomForenameCustomerDelayedRequest(
      final String forename) {
    return CustomerDelayedRequest.builder()
        .dateOfBirth(DATE_OF_BIRTH)
        .postCode(POST_CODE)
        .forename(forename)
        .mobileNumber(CUSTOMER_MOBILE_PHONE_NUMBER)
        .build();
  }

  public static CustomerDelayedRequest buildCustomPostCodeCustomerDelayedRequest(
      final String postCode) {
    return CustomerDelayedRequest.builder()
        .dateOfBirth(DATE_OF_BIRTH)
        .postCode(postCode)
        .forename(FORENAME)
        .mobileNumber(CUSTOMER_MOBILE_PHONE_NUMBER)
        .build();
  }

  public static CustomerDelayedRequest buildCustomMobileNumberCustomerDelayedRequest(
      final String mobileNumber) {
    return CustomerDelayedRequest.builder()
        .dateOfBirth(DATE_OF_BIRTH)
        .postCode(POST_CODE)
        .forename(FORENAME)
        .mobileNumber(mobileNumber)
        .build();
  }

  public static CustomerDelayedRequest buildCustomDateOfBirthCustomerDelayedRequest(
      final String dateOfBirth) {
    return CustomerDelayedRequest.builder()
        .dateOfBirth(dateOfBirth)
        .postCode(POST_CODE)
        .forename(FORENAME)
        .mobileNumber(CUSTOMER_MOBILE_PHONE_NUMBER)
        .build();
  }

  public static AccountGroupedInfo.AccountSummary buildAccountSummary() {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber("1234567890")
        .accountName("Test")
        .amendmentRestriction(true)
        .accountSortCode("123456") // NOPMD
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .deposits(buildDeposit())
        .withdrawals(buildWithdrawal())
        .currency("GBP")
        .productIdentifier("test")
        .productDescription("Monthly Regular Saver: Issue 2")
        .isa(buildIsa())
        .balances(buildBalanceList())
        .build();
  }

  public static AccountGroupedInfo.AccountSummary buildAccountSummaryWithNoRestriction() {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber("1234567890")
        .accountName("Test")
        .amendmentRestriction(false)
        .accountSortCode("123456") // NOPMD
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .deposits(buildDeposit())
        .withdrawals(buildWithdrawal())
        .currency("GBP")
        .productIdentifier("test")
        .productDescription("Monthly Regular Saver: Issue 2")
        .isa(buildIsa())
        .balances(buildBalanceList())
        .build();
  }

  public static AccountGroupedInfo.DepositsSummary buildDeposit() {
    return AccountGroupedInfo.DepositsSummary.builder().permittedOverApi(true).build();
  }

  public static AccountGroupedInfo.WithdrawalsSummary buildWithdrawal() {
    return AccountGroupedInfo.WithdrawalsSummary.builder().permittedOverApi(true).build();
  }

  public static AccountGroupedInfo.Isa buildIsa() {
    return AccountGroupedInfo.Isa.builder().flexible(true).helpToBuy(false).build();
  }

  public static List<Balance> buildBalanceList() {
    return Collections.singletonList(
        AccountGroupedInfo.Balance.builder()
            .type("InterimAvailable")
            .amount(new BigDecimal("100.00"))
            .build());
  }

  public static AccountGroupedInfo buildAccountGroupedInfo() {
    return AccountGroupedInfo.builder()
        .owned(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccountSummary()))
                .balances(buildBalanceList())
                .build())
        .other(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccountSummary()))
                .balances(buildBalanceList())
                .build())
        .build();
  }

  public static AccountGroupedInfo buildAccountGroupedInfoWithNoRestrictions() {
    return AccountGroupedInfo.builder()
        .owned(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccountSummaryWithNoRestriction()))
                .balances(buildBalanceList())
                .build())
        .other(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccountSummaryWithNoRestriction()))
                .balances(buildBalanceList())
                .build())
        .build();
  }

  public static uk.co.ybs.digital.customer.model.adgcore.Party buildFullCustomerRecordADG() {
    return uk.co.ybs.digital.customer.model.adgcore.Party.builder()
        .sysId(12462951L)
        .partyType(buildPartyTypeADG())
        .person(buildPerson())
        .address(
            uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    uk.co.ybs.digital.customer.model.adgcore.PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("AddressLine1_1")
                        .line2("AddressLine2_1")
                        .line4("AddressLine3_1")
                        .country(
                            uk.co.ybs.digital.customer.model.adgcore.Country.builder()
                                .code("UK")
                                .isoCode("GB")
                                .build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("PO")
                                .districtCode("57")
                                .sectorCode("0")
                                .unitCode("DE")
                                .build())
                        .type(uk.co.ybs.digital.customer.model.adgcore.AddressType.UKPOST)
                        .build())
                .function(
                    uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.CORR)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddressADG(CUSTOMER_EMAIL_ADDRESS))
                .function(
                    uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .preferredContactMethod(true)
                .build())
        .address(
            uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(uk.co.ybs.digital.customer.model.adgcore.AddressType.TEL)
                        .sourceType(uk.co.ybs.digital.customer.model.adgcore.NPASourceType.HOME)
                        .address(CUSTOMER_HOME_PHONE_NUMBER)
                        .build())
                .function(
                    uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(uk.co.ybs.digital.customer.model.adgcore.AddressType.TEL)
                        .sourceType(uk.co.ybs.digital.customer.model.adgcore.NPASourceType.MOBILE)
                        .address(CUSTOMER_MOBILE_PHONE_NUMBER)
                        .build())
                .function(
                    uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(uk.co.ybs.digital.customer.model.adgcore.AddressType.TEL)
                        .sourceType(uk.co.ybs.digital.customer.model.adgcore.NPASourceType.WORK)
                        .address(CUSTOMER_WORK_PHONE_NUMBER)
                        .build())
                .function(
                    uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .build();
  }

  public static uk.co.ybs.digital.customer.model.adgcore.Party
      buildFullCustomerRecordNonUKPostalAddressADG() {
    return uk.co.ybs.digital.customer.model.adgcore.Party.builder()
        .sysId(12462951L)
        .partyType(buildPartyTypeADG())
        .person(buildPerson())
        .address(
            uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    uk.co.ybs.digital.customer.model.adgcore.PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("AddressLine1_1")
                        .line2("AddressLine2_1")
                        .line4("AddressLine3_1")
                        .country(
                            uk.co.ybs.digital.customer.model.adgcore.Country.builder()
                                .code("ITA")
                                .isoCode("IT")
                                .build())
                        .type(uk.co.ybs.digital.customer.model.adgcore.AddressType.FPOST)
                        .build())
                .function(
                    uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.CORR)
                .startDate(YESTERDAY)
                .build())
        .address(
            uk.co.ybs.digital.customer.model.adgcore.AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(uk.co.ybs.digital.customer.model.adgcore.AddressType.TEL)
                        .sourceType(uk.co.ybs.digital.customer.model.adgcore.NPASourceType.HOME)
                        .address(CUSTOMER_HOME_PHONE_NUMBER)
                        .build())
                .function(
                    uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .build())
        .build();
  }

  public static long getNextId() {
    return nextId++;
  }

  public static Person buildPerson() {
    return Person.builder()
        .title("Mr")
        .forenames(FORENAME)
        .surname(SURNAME)
        .dateOfBirth(LocalDate.now().minusYears(18))
        .dateOfDeath(NOW.toLocalDate())
        .build();
  }

  public static uk.co.ybs.digital.customer.model.adgcore.PartyType buildPartyTypeADG() {
    return uk.co.ybs.digital.customer.model.adgcore.PartyType.builder()
        .code("PERSON")
        .type("PERSON")
        .startDate(YESTERDAY)
        .build();
  }

  public static PhoneNumberRequest buildPhoneNumberRequest() {
    return PhoneNumberRequest.builder()
        .phoneNumber(
            PhoneNumberBasic.builder()
                .type(PhoneNumberBasicType.HOME)
                .number("01234 123457")
                .build())
        .phoneNumber(
            PhoneNumberBasic.builder()
                .type(PhoneNumberBasicType.MOBILE)
                .number("07100 123457")
                .build())
        .phoneNumber(
            PhoneNumberBasic.builder()
                .type(PhoneNumberBasicType.WORK)
                .number("01234 333333")
                .build())
        .build();
  }

  public static FailureRequest buildFailureRequestWithFailureType(final FailureType failureType) {
    return FailureRequest.builder().challenge("the-challenge").failureType(failureType).build();
  }
}
