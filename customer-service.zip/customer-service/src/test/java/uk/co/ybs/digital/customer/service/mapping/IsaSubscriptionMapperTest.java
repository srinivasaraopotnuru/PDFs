package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.Isa;

public class IsaSubscriptionMapperTest {

  private IsaSubscriptionMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new IsaSubscriptionMapper();
  }

  @ParameterizedTest(name = "mapIsaSubscription: {index} {arguments}")
  @MethodSource("testCombinations")
  void shouldMapIsaSubscriptionFlag(
      final String label, final AccountGroupedInfo accountInfo, final boolean expected) {
    boolean result = testSubject.isSubscribed(accountInfo);

    assertThat(result, is(expected));
  }

  private static Stream<Arguments> testCombinations() {

    return Stream.of(
        Arguments.of(
            "Multiple accounts without ISA",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Arrays.asList(buildAccount(), buildAccount()), buildBalances()))
                .build(),
            false),
        Arguments.of(
            "Multiple accounts, first account without ISA, second account with ISA subscription",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Arrays.asList(
                            buildAccount(),
                            buildAccount()
                                .toBuilder()
                                .isa(Isa.builder().subscribed(true).build())
                                .build()),
                        buildBalances()))
                .build(),
            true),
        Arguments.of(
            "Multiple accounts, first account with ISA subscription, second account without ISA",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Arrays.asList(
                            buildAccount()
                                .toBuilder()
                                .isa(Isa.builder().subscribed(true).build())
                                .build(),
                            buildAccount()),
                        buildBalances()))
                .build(),
            true),
        Arguments.of(
            "Single account with ISA subscription with only subscribed element populated",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(
                            buildAccount()
                                .toBuilder()
                                .isa(Isa.builder().subscribed(true).build())
                                .build()),
                        buildBalances()))
                .build(),
            true),
        Arguments.of(
            "Single account with ISA subscription with all ISA elements set to true",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(
                            buildAccount()
                                .toBuilder()
                                .isa(
                                    Isa.builder()
                                        .subscribed(true)
                                        .helpToBuy(true)
                                        .flexible(true)
                                        .build())
                                .build()),
                        buildBalances()))
                .build(),
            true),
        Arguments.of(
            "Single account without ISA subscription with only subscribed element populated",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(
                            buildAccount()
                                .toBuilder()
                                .isa(Isa.builder().subscribed(false).build())
                                .build()),
                        buildBalances()))
                .build(),
            false),
        Arguments.of(
            "Single account without ISA subscription with all ISA elements set to false",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(
                            buildAccount()
                                .toBuilder()
                                .isa(
                                    Isa.builder()
                                        .subscribed(false)
                                        .helpToBuy(false)
                                        .flexible(false)
                                        .build())
                                .build()),
                        buildBalances()))
                .build(),
            false),
        Arguments.of(
            "Single account with ISA object but no subscribed element",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(
                            buildAccount()
                                .toBuilder()
                                .isa(Isa.builder().helpToBuy(false).flexible(false).build())
                                .build()),
                        buildBalances()))
                .build(),
            false),
        Arguments.of(
            "Single account without ISA",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(Collections.singletonList(buildAccount()), buildBalances()))
                .build(),
            false),
        Arguments.of(
            "Single account without ISA subscription with all other ISA elements set to true",
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(
                            buildAccount()
                                .toBuilder()
                                .isa(
                                    Isa.builder()
                                        .subscribed(false)
                                        .helpToBuy(true)
                                        .flexible(true)
                                        .build())
                                .build()),
                        buildBalances()))
                .build(),
            false));
  }

  private static AccountGroupedInfo.AccountGroup buildAccountGroup(
      final List<AccountGroupedInfo.AccountSummary> accounts,
      final List<AccountGroupedInfo.Balance> balances) {
    return AccountGroupedInfo.AccountGroup.builder().accounts(accounts).balances(balances).build();
  }

  private static AccountGroupedInfo.AccountSummary buildAccount() {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber("1234567890")
        .accountName("Test")
        .accountSortCode("123456")
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .amendmentRestriction(false)
        .deposits(AccountGroupedInfo.DepositsSummary.builder().permittedOverApi(true).build())
        .withdrawals(AccountGroupedInfo.WithdrawalsSummary.builder().permittedOverApi(true).build())
        .currency("GBP")
        .productIdentifier("test")
        .productDescription("Monthly Regular Saver: Issue 2")
        .balances(buildBalances())
        .build();
  }

  private static List<AccountGroupedInfo.Balance> buildBalances() {
    return Collections.singletonList(
        AccountGroupedInfo.Balance.builder()
            .type("InterimAvailable")
            .amount(new BigDecimal("100.0"))
            .build());
  }
}
