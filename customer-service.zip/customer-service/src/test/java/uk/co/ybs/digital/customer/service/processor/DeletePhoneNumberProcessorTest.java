package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Optional;
import java.util.stream.Stream;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.repository.core.PartyCoreRepository;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class DeletePhoneNumberProcessorTest {

  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final long LINKED_PARTY_ID = 100000L;
  private static final long PARTY_ID = 123456L;

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-09-01T00:00:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);

  public static final LocalDateTime YESTERDAY = NOW.minusDays(1);

  @Mock private AuditService auditService;

  @Mock private PartyCoreRepository partyCoreRepository;

  @InjectMocks private DeletePhoneNumberProcessor testSubject;

  @Captor private ArgumentCaptor<Party> savedParty;

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments")
  void resolveShouldReturnParty(final NonPostalAddress nonPostalAddress) {

    final DeletePhoneNumberRequestArguments arguments =
        new DeletePhoneNumberRequestArguments(
            PARTY_ID,
            TestHelper.createRequestMetadata(),
            PROCESS_TIME,
            PhoneNumberRequestType.valueOf(String.valueOf(nonPostalAddress.getSourceType())));

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(nonPostalAddress));

    final LinkedParty linkedParty = stubLinkedParty(PARTY_ID, LINKED_PARTY_ID);

    when(partyCoreRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(linkedParty.getCanonicalPartyId()),
            eq(Collections.singleton(AddressType.TEL)),
            eq(EnumSet.allOf(AddressUsage.AddressFunction.class)),
            eq(PROCESS_TIME)))
        .thenReturn(Optional.of(party));

    final Party resolvedParty = testSubject.resolve(arguments);

    assertThat(resolvedParty, is(party));

    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @EnumSource(PhoneNumberRequestType.class)
  void resolveShouldCustomerNotFoundExceptionWhenNoCanonicalParty(
      final PhoneNumberRequestType requestType) {
    final DeletePhoneNumberRequestArguments arguments =
        new DeletePhoneNumberRequestArguments(
            PARTY_ID, TestHelper.createRequestMetadata(), PROCESS_TIME, requestType);

    when(partyCoreRepository.findCanonicalPartyId(PARTY_ID)).thenReturn(Optional.empty());

    final CustomerNotFoundException exception =
        assertThrows(CustomerNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("No record found in party database for party id 123456"));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @EnumSource(PhoneNumberRequestType.class)
  void resolveShouldCustomerNotFoundExceptionWhenCoreRepositoryReturnsEmpty(
      final PhoneNumberRequestType requestType) {
    final DeletePhoneNumberRequestArguments arguments =
        new DeletePhoneNumberRequestArguments(
            PARTY_ID, TestHelper.createRequestMetadata(), PROCESS_TIME, requestType);

    stubLinkedParty(PARTY_ID, LINKED_PARTY_ID);

    when(partyCoreRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(LINKED_PARTY_ID),
            eq(Collections.singleton(AddressType.TEL)),
            eq(EnumSet.allOf(AddressUsage.AddressFunction.class)),
            eq(PROCESS_TIME)))
        .thenReturn(Optional.empty());

    final CustomerNotFoundException exception =
        assertThrows(CustomerNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("No record found in party database for party id 123456"));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments")
  void shouldEndPhoneNumber(final NonPostalAddress nonPostalAddress) {
    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(nonPostalAddress));

    testSubject.execute(
        new DeletePhoneNumberRequestArguments(
            PARTY_ID,
            TestHelper.createRequestMetadata(),
            PROCESS_TIME,
            PhoneNumberRequestType.valueOf(String.valueOf(nonPostalAddress.getSourceType()))),
        party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                "8AM-12PM",
                nonPostalAddressMatcher(
                    nonPostalAddress.getType(),
                    nonPostalAddress.getAdcCode(),
                    nonPostalAddress.getAddress(),
                    nonPostalAddress.getSourceType()))));
  }

  @ParameterizedTest
  @MethodSource("multipleNonPostalAddressArguments")
  void shouldOnlyEndCorrectNonPostalAddress(
      final NonPostalAddress addressToKeep, final NonPostalAddress addressToDelete) {
    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Arrays.asList(addressToDelete, addressToKeep));

    testSubject.execute(
        new DeletePhoneNumberRequestArguments(
            PARTY_ID,
            TestHelper.createRequestMetadata(),
            PROCESS_TIME,
            PhoneNumberRequestType.valueOf(addressToDelete.getSourceType().toString())),
        party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    // THIS NEEDS TO BE CHECKED IN ORDER OF ITEMS SAVED TO DB
    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                "8AM-12PM",
                nonPostalAddressMatcher(
                    addressToDelete.getType(),
                    addressToDelete.getAdcCode(),
                    addressToDelete.getAddress(),
                    addressToDelete.getSourceType())),
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                null,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                "8AM-12PM",
                nonPostalAddressMatcher(
                    addressToKeep.getType(),
                    addressToKeep.getAdcCode(),
                    addressToKeep.getAddress(),
                    addressToKeep.getSourceType()))));
  }

  @ParameterizedTest
  @EnumSource(PhoneNumberRequestType.class)
  void auditSuccessShouldCallAuditService(final PhoneNumberRequestType requestType) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    testSubject.auditSuccess(
        new DeletePhoneNumberRequestArguments(
            PARTY_ID, TestHelper.createRequestMetadata(), PROCESS_TIME, requestType));

    final AuditNonPostalAddressUpdateSuccessRequest auditRequest =
        AuditNonPostalAddressUpdateSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .address(null)
            .operation(NonPostalOperation.PHONE_NUMBER)
            .type(NonPostalType.valueOf(String.valueOf(requestType)))
            .build();

    verify(auditService).auditNonPostalAddressUpdateSuccess(auditRequest, requestMetadata);
  }

  @ParameterizedTest
  @EnumSource(PhoneNumberRequestType.class)
  void auditFailureShouldCallAuditService(final PhoneNumberRequestType requestType) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    testSubject.auditFailure(
        new DeletePhoneNumberRequestArguments(
            PARTY_ID, TestHelper.createRequestMetadata(), PROCESS_TIME, requestType),
        TestHelper.TECHNICAL_FAILURE_MESSAGE);

    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        AuditNonPostalAddressUpdateFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(TestHelper.TECHNICAL_FAILURE_MESSAGE)
            .address(null)
            .operation(NonPostalOperation.PHONE_NUMBER)
            .type(NonPostalType.valueOf(String.valueOf(requestType)))
            .build();

    verify(auditService).auditNonPostalAddressUpdateFailure(auditRequest, requestMetadata);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private Matcher<AddressUsage> addressUsageMatcher(
      final AddressUsage.AddressFunction function,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final LocalDateTime createdDate,
      final String createdAt,
      final String createdBy,
      final LocalDateTime endedDate,
      final String endedAt,
      final String endedBy,
      final boolean preferredContactMethod,
      final String podCode,
      final Matcher<NonPostalAddress> nonPostalAddress) {
    Matcher<AddressUsageFunction> addressUsageFunction =
        addressUsageFunctionMatcher(startDate, endDate);
    return allOf(
        hasProperty("function", is(function)),
        hasProperty("startDate", is(startDate)),
        hasProperty("endDate", is(endDate)),
        hasProperty("createdDate", is(createdDate)),
        hasProperty("createdAt", is(createdAt)),
        hasProperty("createdBy", is(createdBy)),
        hasProperty("endedDate", is(endedDate)),
        hasProperty("endedAt", is(endedAt)),
        hasProperty("endedBy", is(endedBy)),
        hasProperty("preferredContactMethod", is(preferredContactMethod)),
        hasProperty("podCode", is(podCode)),
        hasProperty("nonPostalAddress", nonPostalAddress),
        hasProperty("functions", contains(addressUsageFunction)));
  }

  private Matcher<NonPostalAddress> nonPostalAddressMatcher(
      final AddressType type,
      final Integer adcCode,
      final String address,
      final NPASourceType sourceType) {
    return allOf(
        hasProperty("type", is(type)),
        hasProperty("adcCode", is(adcCode)),
        hasProperty("address", is(address)),
        hasProperty("sourceType", is(sourceType)));
  }

  private Matcher<AddressUsageFunction> addressUsageFunctionMatcher(
      final LocalDateTime startDate, final LocalDateTime endDate) {

    Matcher<AddressUsageFunction.AddressUsageFunctionPK> addressUsageFunctionPK =
        addressUsageFunctionPKMatcher(startDate);

    return allOf(
        hasProperty("id", is(addressUsageFunctionPK)), hasProperty("endDate", is(endDate)));
  }

  private Matcher<AddressUsageFunction.AddressUsageFunctionPK> addressUsageFunctionPKMatcher(
      final LocalDateTime startDate) {

    return allOf(hasProperty("startDate", is(startDate)));
  }

  private static Stream<NonPostalAddress> nonPostalAddressArguments() {
    return Stream.of(
        TestHelper.buildHomePhoneNumberRequest(),
        TestHelper.buildMobilePhoneNumberRequest(),
        TestHelper.buildWorkLandlinePhoneNumberRequest(),
        TestHelper.buildWorkMobilePhoneNumberRequest());
  }

  private static Stream<Arguments> multipleNonPostalAddressArguments() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildHomePhoneNumberRequest(), TestHelper.buildMobilePhoneNumberRequest()),
        Arguments.of(
            TestHelper.buildMobilePhoneNumberRequest(),
            TestHelper.buildWorkMobilePhoneNumberRequest()),
        Arguments.of(
            TestHelper.buildHomePhoneNumberRequest(),
            TestHelper.buildWorkLandlinePhoneNumberRequest()));
  }

  private LinkedParty stubLinkedParty(final Long originalPartyId, final Long canonicalPartyId) {

    final LinkedParty linkedParty =
        LinkedParty.builder()
            .originalPartyId(originalPartyId)
            .canonicalPartyId(canonicalPartyId)
            .linkCount(1L)
            .build();

    when(partyCoreRepository.findCanonicalPartyId(originalPartyId))
        .thenReturn(Optional.of(linkedParty));

    return linkedParty;
  }
}
