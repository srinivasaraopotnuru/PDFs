package uk.co.ybs.digital.customer.repository.core;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.nullValue;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFNUS;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Optional;
import java.util.stream.Stream;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.core.PartyType;
import uk.co.ybs.digital.customer.model.core.Person;
import uk.co.ybs.digital.customer.model.core.PostalAddress;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;
import uk.co.ybs.digital.customer.utils.TestHelper;

@YbsDataJpaTest
@TestPropertySource(properties = {"spring.ldap.urls="})
@Transactional("customerProcessorTransactionManager")
class PartyCoreRepositoryTest {

  private static long nextId;
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-09-01T10:15:30");
  public static final LocalDateTime YESTERDAY = NOW.minusDays(1);
  private static final String CREATED_AT = "0795";
  private static final String CREATED_BY = "SAPP";

  @Autowired PartyCoreRepository partyRepository;

  @Autowired TestEntityManager coreTestEntityManager;

  @Autowired TransactionTemplate transactionTemplate;

  @ParameterizedTest
  @MethodSource("linkedParties")
  void findCanonicalPartyIdReturnsCanonicalIdAndNumberOfLinks(
      final Long originalPartyId, final Optional<LinkedParty> expected) {
    transactionTemplate.executeWithoutResult(
        status -> {
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (0, NULL)")
              .executeUpdate();
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (1, 0)")
              .executeUpdate();
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (2, 1)")
              .executeUpdate();
        });

    final Optional<LinkedParty> actual = partyRepository.findCanonicalPartyId(originalPartyId);
    assertThat(actual, equalTo(expected));
  }

  @Test
  void findGoldenPartyRecordReturnsAllAddresses() {
    final Party party = buildFullCustomerRecord();
    insert(party);

    final Optional<Party> maybeActual =
        partyRepository.findGoldenPartyInformation(party.getSysId(), NOW);
    assertThat(maybeActual.isPresent(), equalTo(true));

    final Party actual = maybeActual.get();

    assertThat(
        actual,
        allOf(
            hasProperty("sysId", equalTo(party.getSysId())),
            hasProperty(
                "person",
                allOf(
                    hasProperty("partyId", equalTo(party.getSysId())),
                    hasProperty("dateOfDeath", equalTo(NOW.toLocalDate())),
                    hasProperty("title", equalTo("Mr")),
                    hasProperty("forenames", equalTo("Joe")),
                    hasProperty("surname", equalTo("Bloggs")))),
            hasProperty(
                "addresses",
                contains(
                    matchesAddressUsage(
                        AddressUsage.builder()
                            .startDate(YESTERDAY)
                            .createdDate(YESTERDAY)
                            .createdAt(CREATED_AT)
                            .createdBy(CREATED_BY)
                            .preferredContactMethod(true)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("john.smith@gmail.com")
                                    .type(AddressType.EMAIL)
                                    .build())
                            .build()),
                    matchesAddressUsage(
                        AddressUsage.builder()
                            .startDate(YESTERDAY)
                            .createdDate(YESTERDAY)
                            .createdAt(CREATED_AT)
                            .createdBy(CREATED_BY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("01234421693")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.WORK)
                                    .build())
                            .build()),
                    matchesAddressUsage(
                        AddressUsage.builder()
                            .startDate(YESTERDAY)
                            .createdDate(YESTERDAY)
                            .createdAt(CREATED_AT)
                            .createdBy(CREATED_BY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("07515059347")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.MOBILE)
                                    .build())
                            .build()),
                    matchesAddressUsage(
                        AddressUsage.builder()
                            .startDate(YESTERDAY)
                            .createdDate(YESTERDAY)
                            .createdAt(CREATED_AT)
                            .createdBy(CREATED_BY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("01234420713")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.HOME)
                                    .build())
                            .build()),
                    matchesAddressUsage(
                        AddressUsage.builder()
                            .startDate(YESTERDAY)
                            .createdDate(YESTERDAY)
                            .createdAt(CREATED_AT)
                            .createdBy(CREATED_BY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.CORR)
                            .postalAddress(
                                PostalAddress.builder()
                                    .line1("AddressLine1_1")
                                    .line2("AddressLine2_1")
                                    .line4("AddressLine3_1")
                                    .country(Country.builder().code("UK").isoCode("GB").build())
                                    .postCode(
                                        PostCode.builder()
                                            .areaCode("PO")
                                            .districtCode("57")
                                            .sectorCode("0")
                                            .unitCode("DE")
                                            .build())
                                    .type(AddressType.UKPOST)
                                    .build())
                            .build())))));
  }

  @Test
  void findPartyInformationWithAddressTypesReturnsEmptyOptionalIfPartyIdDoesNotExist() {
    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            9999L, Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(false));
  }

  @Test
  void findPartyInformationWithAddressTypesReturnsEmptyOptionalIfPartyIsEnded() {
    final Party endedParty = buildFullCustomerRecord();
    endedParty.setEndedDate(YESTERDAY);
    insert(endedParty);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            endedParty.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(false));
  }

  @Test
  void
      findPartyInformationWithAddressTypesReturnsEmptyOptionalIfAssociatedPersonRecordDoesNotExist() {
    final Party party = buildFullCustomerRecord();
    party.setPerson(null);
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(false));
  }

  @Test
  void findPartyInformationWithAddressTypesReturnsEmptyOptionalIfPersonIsEnded() {
    final Party party = buildFullCustomerRecord();
    party.getPerson().setEndedDate(YESTERDAY);
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(false));
  }

  @ParameterizedTest
  @CsvSource({
    "PERSON,PERSON,true",
    "INTUSG,PERSON,true",
    "PCKUSG,PERSON,true",
    "YBSBRN,INTORG,false",
    "UKBNK,FINST,false",
    "PACKER,EXTORG,false"
  })
  void findPartyInformationWithAddressTypesShouldOnlyFindPartiesWithAPersonPartyType(
      final String code, final String type, final boolean expectedFind) {
    final Party party = buildFullCustomerRecord();
    party.setPartyType(PartyType.builder().code(code).type(type).startDate(YESTERDAY).build());
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"2020-09-01T10:15:29,true", "2020-09-01T10:15:30,true", "2020-09-01T10:15:31,false"})
  void findPartyInformationWithAddressTypesShouldOnlyFindPartiesWithStartedPersonPartyType(
      final LocalDateTime startDate, final boolean expectedFind) {
    final Party party = buildFullCustomerRecord();
    party.setPartyType(buildPartyType().toBuilder().startDate(startDate).build());
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"2020-09-01T10:15:29,false", "2020-09-01T10:15:30,false", "2020-09-01T10:15:31,true"})
  void findPartyInformationWithAddressTypesShouldOnlyFindPartiesWithNonEndedPersonPartyType(
      final LocalDateTime endDate, final boolean expectedFind) {
    final Party party = buildFullCustomerRecord();
    party.setPartyType(buildPartyType().toBuilder().endDate(endDate).build());
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(expectedFind));
  }

  @Test
  void findPartyInformationWithAddressTypesHasEmptyAddressesIfNoneExist() {
    final Party party = buildFullCustomerRecord();
    party.setAddresses(Collections.emptyList());

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            EnumSet.allOf(AddressType.class),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(actual.get().getAddresses(), empty());
  }

  @Test
  void
      findPartyInformationWithAddressTypesDoesNotReturnNonEmailAddressesIfFilteredOnEmailAddressType() {
    final Party party = buildFullCustomerRecord();
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(
        actual.get().getAddresses(),
        contains(
            allOf(
                hasProperty("startDate", equalTo(YESTERDAY)),
                hasProperty("preferredContactMethod", equalTo(true)),
                hasProperty(
                    "nonPostalAddress",
                    allOf(
                        hasProperty("address", equalTo("john.smith@gmail.com")),
                        hasProperty("type", equalTo(AddressType.EMAIL)),
                        hasProperty("sourceType", nullValue()))))));
  }

  @Test
  void findPartyInformationWithAddressTypesDoesNotReturnEndedAddresses() {
    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(
                AddressUsage.builder()
                    .endDate(YESTERDAY)
                    .nonPostalAddress(buildEmailAddress("ended@email.com"))
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .createdAt(CREATED_AT)
                    .createdBy(CREATED_BY)
                    .function(AddressUsage.AddressFunction.DIRCOM)
                    .build())
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(actual.get().getAddresses(), empty());
  }

  @Test
  void findPartyInformationWithAddressTypesDoesNotReturnAddressWhenAddressFunctionUnknown() {
    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(buildEmailAddress("address@email.com"))
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .createdAt(CREATED_AT)
                    .createdBy(CREATED_BY)
                    .build())
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(actual.get().getAddresses(), empty());
  }

  @Test
  void findPartyInformationWithAddressTypesReturnsPreferredAddressesFirst() {
    final AddressUsage nonPreferredAddress =
        AddressUsage.builder()
            .preferredContactMethod(false)
            .startDate(YESTERDAY)
            .createdDate(YESTERDAY)
            .createdAt(CREATED_AT)
            .createdBy(CREATED_BY)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .type(AddressType.EMAIL)
                    .address("non.preferred.address@gmail.com")
                    .build())
            .function(AddressUsage.AddressFunction.DIRCOM)
            .build();

    final AddressUsage preferredAddress =
        AddressUsage.builder()
            .preferredContactMethod(true)
            .startDate(YESTERDAY)
            .createdDate(YESTERDAY)
            .createdAt(CREATED_AT)
            .createdBy(CREATED_BY)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .type(AddressType.EMAIL)
                    .address("preferred.address@gmail.com")
                    .build())
            .function(AddressUsage.AddressFunction.DIRCOM)
            .build();

    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(preferredAddress)
            .address(nonPreferredAddress)
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(
        actual.get().getAddresses(),
        contains(matchesAddressUsage(preferredAddress), matchesAddressUsage(nonPreferredAddress)));
  }

  @Test
  void
      findPartyInformationWithAddressTypesReturnsReturnsLatestCreatedAddressFirstIfPreferredContactMethodValueIsEqual() {
    final AddressUsage expected =
        AddressUsage.builder()
            .startDate(NOW)
            .createdDate(NOW)
            .createdAt(CREATED_AT)
            .createdBy(CREATED_BY)
            .function(AddressUsage.AddressFunction.DIRCOM)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .type(AddressType.EMAIL)
                    .address("expected.address@gmail.com")
                    .build())
            .build();

    final AddressUsage otherAddress =
        AddressUsage.builder()
            .startDate(YESTERDAY)
            .createdDate(YESTERDAY)
            .createdAt(CREATED_AT)
            .createdBy(CREATED_BY)
            .function(AddressUsage.AddressFunction.CORR)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .type(AddressType.EMAIL)
                    .address("other.address@gmail.com")
                    .build())
            .build();

    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(otherAddress)
            .address(expected)
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(
        actual.get().getAddresses(),
        contains(matchesAddressUsage(expected), matchesAddressUsage(otherAddress)));
  }

  @Test
  void
      findPartyInformationWithAddressTypesReturnsLatestSysIdFirstIfCreatedAddressAndPreferredContactMethodValueIsEqual() {
    final AddressUsage olderAddress =
        AddressUsage.builder()
            .startDate(NOW)
            .createdDate(NOW)
            .createdAt(CREATED_AT)
            .createdBy(CREATED_BY)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .type(AddressType.EMAIL)
                    .address("other.address@gmail.com")
                    .build())
            .function(AddressUsage.AddressFunction.DIRCOM)
            .build();

    final AddressUsage newerAddress =
        AddressUsage.builder()
            .startDate(NOW)
            .createdDate(NOW)
            .createdAt(CREATED_AT)
            .createdBy(CREATED_BY)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    //        .sysId(nextId())
                    .type(AddressType.EMAIL)
                    .address("expected.address@gmail.com")
                    .build())
            .function(AddressUsage.AddressFunction.DIRCOM)
            .build();

    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(olderAddress)
            .address(newerAddress)
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(
        actual.get().getAddresses(),
        contains(matchesAddressUsage(newerAddress), matchesAddressUsage(olderAddress)));
  }

  private Matcher<AddressUsage> matchesAddressUsage(final AddressUsage addressUsage) {
    Matcher<Object> addressMatcher = anything();

    if (addressUsage.getNonPostalAddress() != null) {
      addressMatcher =
          hasProperty(
              "nonPostalAddress",
              allOf(
                  hasProperty("address", equalTo(addressUsage.getNonPostalAddress().getAddress())),
                  hasProperty("type", equalTo(addressUsage.getNonPostalAddress().getType()))));
    } else if (addressUsage.getPostalAddress() != null) {
      addressMatcher =
          hasProperty(
              "postalAddress",
              allOf(
                  hasProperty("line1", equalTo(addressUsage.getPostalAddress().getLine1())),
                  hasProperty("line2", equalTo(addressUsage.getPostalAddress().getLine2())),
                  hasProperty("line3", equalTo(addressUsage.getPostalAddress().getLine3())),
                  hasProperty("line4", equalTo(addressUsage.getPostalAddress().getLine4())),
                  hasProperty("line5", equalTo(addressUsage.getPostalAddress().getLine5())),
                  hasProperty("postCode", equalTo(addressUsage.getPostalAddress().getPostCode())),
                  hasProperty("country", equalTo(addressUsage.getPostalAddress().getCountry())),
                  hasProperty("type", equalTo(addressUsage.getPostalAddress().getType()))));
    }

    return allOf(
        hasProperty("startDate", equalTo(addressUsage.getStartDate())),
        hasProperty("function", equalTo(addressUsage.getFunction())),
        addressMatcher);
  }

  private Person buildPerson() {
    return Person.builder()
        .title("Mr")
        .forenames("Joe")
        .surname("Bloggs")
        .dateOfDeath(NOW.toLocalDate())
        .build();
  }

  private static Stream<Arguments> linkedParties() {
    return Stream.of(
        Arguments.of(
            0L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(0L)
                    .canonicalPartyId(0L)
                    .linkCount((0L))
                    .build())),
        Arguments.of(
            1L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(1L)
                    .canonicalPartyId(0L)
                    .linkCount((1L))
                    .build())),
        Arguments.of(
            2L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(2L)
                    .canonicalPartyId(0L)
                    .linkCount((2L))
                    .build())),
        Arguments.of(3L, Optional.empty()));
  }

  private void insert(final Party party) {
    transactionTemplate.executeWithoutResult(
        status -> {
          TestHelper.fixBiDirectionalReferences(party);

          coreTestEntityManager.persist(party.getPartyType());

          Optional.ofNullable(party.getPerson())
              .ifPresent(
                  person -> {
                    coreTestEntityManager.persist(person);
                  });

          coreTestEntityManager.persist(party);

          coreTestEntityManager.flush();
          coreTestEntityManager.clear();
        });
  }

  private Party buildFullCustomerRecord() {

    return Party.builder()
        .sysId(getNextId())
        .partyType(buildPartyType())
        .person(buildPerson())
        .address(
            AddressUsage.builder()
                .postalAddress(
                    PostalAddress.builder()
                        .line1("AddressLine1_1")
                        .line2("AddressLine2_1")
                        .line4("AddressLine3_1")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .pafStatus(PAF_STATUS_PAFNUS)
                        .postCode(
                            PostCode.builder()
                                .areaCode("PO")
                                .districtCode("57")
                                .sectorCode("0")
                                .unitCode("DE")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressUsage.AddressFunction.CORR)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .createdAt(CREATED_AT)
                .createdBy(CREATED_BY)
                .build())
        .address(
            AddressUsage.builder()
                .nonPostalAddress(buildEmailAddress("john.smith@gmail.com"))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .createdAt(CREATED_AT)
                .createdBy(CREATED_BY)
                .preferredContactMethod(true)
                .function(
                    AddressUsageFunction.builder()
                        .id(
                            AddressUsageFunction.AddressUsageFunctionPK.builder()
                                .function(AddressUsage.AddressFunction.DIRCOM)
                                .startDate(YESTERDAY)
                                .build())
                        .build())
                .build())
        .address(
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address("01234420713")
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .createdAt(CREATED_AT)
                .createdBy(CREATED_BY)
                .build())
        .address(
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address("07515059347")
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .createdAt(CREATED_AT)
                .createdBy(CREATED_BY)
                .build())
        .address(
            AddressUsage.builder()
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address("01234421693")
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .createdAt(CREATED_AT)
                .createdBy(CREATED_BY)
                .build())
        .build();
  }

  private NonPostalAddress buildEmailAddress(final String address) {
    return NonPostalAddress.builder().type(AddressType.EMAIL).address(address).build();
  }

  private static PartyType buildPartyType() {
    return PartyType.builder().code("PERSON").type("PERSON").startDate(YESTERDAY).build();
  }

  private static long getNextId() {
    return nextId++;
  }
}
