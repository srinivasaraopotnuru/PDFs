package uk.co.ybs.digital.customer.service.audit.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.customer.web.dto.PafData;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;

@JsonTest
public class AuditPostalAddressUpdateFailureRequestJsonTest {
  @Autowired private JacksonTester<AuditPostalAddressUpdateFailureRequest> tester;

  @Value("classpath:api/auditService/request/auditUpdatePostalAddress/failureRequest.json")
  private Resource requestFile;

  private AuditPostalAddressUpdateFailureRequest request;

  @BeforeEach
  void setUp() {
    request =
        AuditPostalAddressUpdateFailureRequest.builder()
            .ipAddress("12.66.53.145")
            .postalAddressRequest(buildPostalAddressRequestPayload())
            .message("Something went wrong...")
            .build();
  }

  @Test
  void serializes() throws IOException {
    assertThat(tester.write(request)).isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    assertThat(tester.read(requestFile).getObject()).isEqualTo(request);
  }

  private static PostalAddressRequest buildPostalAddressRequestPayload() {
    return PostalAddressRequest.builder().address(buildPostalAddress()).paf(buildPafData()).build();
  }

  private static PostalAddress buildPostalAddress() {
    return PostalAddress.builder()
        .type(PostalAddress.PostalAddressType.CORR)
        .subType(PostalAddress.PostalAddressSubType.UKPOST)
        .addressLines(Collections.singleton("Broad Gate"))
        .addressLines(Collections.singleton("The Headrow"))
        .postCode("LS1 6LR")
        .country(PermittedCountries.UNITED_KINGDOM)
        .build();
  }

  private static PafData buildPafData() {
    return PafData.builder().addressKey(12345678).deliveryPointSuffix("1TA").build();
  }
}
