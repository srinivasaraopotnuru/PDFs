package uk.co.ybs.digital.customer.model.ldap;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;

import java.time.Instant;
import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.Test;
import org.springframework.ldap.support.LdapUtils;
import uk.co.ybs.digital.customer.utils.TestHelper;

class LdapPersonTest {

  @Test
  void shouldCheckGroupDirect() {
    LdapPerson person = LdapPerson.builder().groups(Arrays.asList("direct", "eview")).build();
    assertThat(person.isInDirectGroup(), is(true));
  }

  @Test
  void shouldCheckGroupOther() {
    LdapPerson person = LdapPerson.builder().groups(Arrays.asList("admin", "eview")).build();
    assertThat(person.isInDirectGroup(), is(false));
  }

  @Test
  void shouldCheckNoGroups() {
    LdapPerson person = LdapPerson.builder().groups(Collections.emptyList()).build();
    assertThat(person.isInDirectGroup(), is(false));
  }

  @Test
  void shouldCheckPasswordStateOk() {
    LdapPerson person = LdapPerson.builder().passwordState("PWD_OK").build();
    assertThat(person.isPasswordStateOk(), is(true));
  }

  @Test
  void shouldCheckPasswordStateOther() {
    LdapPerson person = LdapPerson.builder().passwordState("PWD_MANUALCREATE").build();
    assertThat(person.isPasswordStateOk(), is(false));
  }

  @Test
  void shouldGetAccessTime() {
    LdapPerson person =
        LdapPerson.builder()
            .accessTimeEpochSecond(Instant.parse("2019-04-02T10:21:41.894Z").getEpochSecond())
            .build();
    assertThat(person.getAccessTime(), is(Instant.parse("2019-04-02T10:21:41Z")));
  }

  @Test
  void shouldSetAccessTime() {
    LdapPerson person =
        LdapPerson.builder().accessTime(Instant.parse("2019-04-02T10:21:41.894Z")).build();
    assertThat(
        person.getAccessTimeEpochSecond(),
        is(Instant.parse("2019-04-02T10:21:41Z").getEpochSecond()));
  }

  @Test
  void shouldGetLdapPerson() {
    LdapPerson person = TestHelper.buildLdapPerson();

    assertThat(
        person,
        allOf(
            hasProperty(
                "id",
                equalTo(
                    LdapUtils.newLdapName(
                        "uid=0000123456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))),
            hasProperty("accessTime", equalTo(Instant.parse("2019-04-02T10:21:41Z"))),
            hasProperty("uid", equalTo("0000123456")),
            hasProperty("passwordState", equalTo("PWD_OK")),
            hasProperty("customerNumber", equalTo("000987654")),
            hasProperty("emailAddress", equalTo("john.smith@gmail.com")),
            hasProperty("groups", contains("eview", "direct"))));
  }
}
