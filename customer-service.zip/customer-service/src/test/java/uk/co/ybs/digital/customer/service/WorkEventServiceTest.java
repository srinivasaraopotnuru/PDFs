package uk.co.ybs.digital.customer.service;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.sameInstance;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.core.WorkEvent.ModuleLabelAssociationType;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventContextTableName;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventStatus;
import uk.co.ybs.digital.customer.model.core.WorkEventOutput;
import uk.co.ybs.digital.customer.repository.core.WorkEventCoreRepository;

@ExtendWith(MockitoExtension.class)
public class WorkEventServiceTest {

  private static final long CONTEXT_ID_1 = 12345678L;
  private static final long CONTEXT_ID_2 = 80L;
  private static final long PARTY_ID = 1L;

  WorkEventService workEventService;

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-09-01T00:00:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);

  @Mock WorkEventCoreRepository workEventCoreRepository;

  @BeforeEach
  void setUp() {

    workEventService = new WorkEventService(workEventCoreRepository);
  }

  @Test
  void createAdacusWorkEvent() {
    final WorkEventOutput workEventOutput =
        WorkEventOutput.builder()
            .outputStatus("S")
            .param1Code("10001")
            .workEventSysId(PARTY_ID)
            .build();

    when(workEventCoreRepository.createAdacusWorkEvent(PARTY_ID, 1234567890L))
        .thenReturn(workEventOutput);

    assertThat(
        workEventService.createAdacusWorkEvent(PARTY_ID, 1234567890L),
        sameInstance(workEventOutput));
  }

  @Test
  void createChcamoWorkEvent() {
    final WorkEventOutput workEventOutput =
        WorkEventOutput.builder()
            .outputStatus("S")
            .param1Code("10001")
            .workEventSysId(PARTY_ID)
            .build();

    when(workEventCoreRepository.createChcamoWorkEvent(CONTEXT_ID_1, CONTEXT_ID_2))
        .thenReturn(workEventOutput);

    Optional<WorkEventOutput> result =
        workEventService.createChcamoWorkEvent(PARTY_ID, CONTEXT_ID_1, CONTEXT_ID_2, NOW);

    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), sameInstance(workEventOutput));
  }

  @Test
  void createChcamoWorkEventAlreadyExists() {

    when(workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            CONTEXT_ID_1,
            CONTEXT_ID_2,
            EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER),
            ModuleLabelAssociationType.CREEVT,
            "CUS0503U",
            "CHCAMO",
            NOW))
        .thenReturn(Collections.singletonList(PARTY_ID));

    Optional<WorkEventOutput> result =
        workEventService.createChcamoWorkEvent(PARTY_ID, CONTEXT_ID_1, CONTEXT_ID_2, NOW);

    assertThat(result.isPresent(), is(false));

    verifyNoMoreInteractions(workEventCoreRepository);
  }
}
