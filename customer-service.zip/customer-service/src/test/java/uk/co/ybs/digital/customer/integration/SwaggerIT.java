package uk.co.ybs.digital.customer.integration;

import java.net.URI;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class})
@ActiveProfiles("test")
class SwaggerIT {
  @LocalServerPort private int port;

  @Autowired private WebTestClient nonSigningWebTestClient;

  @ValueSource(strings = {"swagger-resources", "v2/api-docs", "swagger-ui.html"})
  @ParameterizedTest
  void shouldReturnOkForSwaggerEndpointsWithNoSignature(final String path) {
    nonSigningWebTestClient.get().uri(getInfoURI(path)).exchange().expectStatus().isOk();
  }

  @Test
  void apiDocsShouldContainNonEmptyPathsObject() {
    nonSigningWebTestClient
        .get()
        .uri(getInfoURI("v2/api-docs"))
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("paths")
        .isNotEmpty();
  }

  private URI getInfoURI(final String path) {
    return URI.create("http://localhost:" + port + "/customer/" + path);
  }
}
