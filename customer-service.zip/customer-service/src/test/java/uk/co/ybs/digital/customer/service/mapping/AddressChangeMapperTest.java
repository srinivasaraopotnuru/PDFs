package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.core.Is.is;

import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange;
import uk.co.ybs.digital.customer.web.dto.PafData;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;

class AddressChangeMapperTest {

  private AddressChangeMapper testSubject;
  private static final String ADDRESS_LINE_1 = "Broad Gate";
  private static final String ADDRESS_LINE_2 = "The Headrow";
  private static final String ADDRESS_LINE_3 = "Address Line 3";
  private static final String ADDRESS_LINE_4 = "Address Line 4";
  private static final String UK = "UK";
  private static final String POSTCODE = "LS1 6LR";
  private static final String PAF_KEY = "12345678";

  private static PostalAddressRequest buildPostalAddressRequestPayload(
      final boolean includePaf, final boolean maxAddressLines) {
    if (includePaf) {
      return PostalAddressRequest.builder()
          .address(buildPostalAddress(maxAddressLines))
          .paf(buildPafData())
          .build();
    } else {
      return PostalAddressRequest.builder().address(buildPostalAddress(maxAddressLines)).build();
    }
  }

  private static PostalAddress buildPostalAddress(final boolean maxAddressLines) {

    if (maxAddressLines) {
      return PostalAddress.builder()
          .type(PostalAddress.PostalAddressType.CORR)
          .subType(PostalAddress.PostalAddressSubType.UKPOST)
          .addressLines(Collections.singleton(ADDRESS_LINE_1))
          .addressLines(Collections.singleton(ADDRESS_LINE_2))
          .addressLines(Collections.singleton(ADDRESS_LINE_3))
          .addressLines(Collections.singleton(ADDRESS_LINE_4))
          .postCode("LS1 6LR")
          .country(PermittedCountries.UNITED_KINGDOM)
          .build();
    } else {
      return PostalAddress.builder()
          .type(PostalAddress.PostalAddressType.CORR)
          .subType(PostalAddress.PostalAddressSubType.UKPOST)
          .addressLines(Collections.singleton(ADDRESS_LINE_1))
          .addressLines(Collections.singleton(ADDRESS_LINE_2))
          .postCode("LS1 6LR")
          .country(PermittedCountries.UNITED_KINGDOM)
          .build();
    }
  }

  private static PafData buildPafData() {
    return PafData.builder().addressKey(12345678).deliveryPointSuffix("1TA").build();
  }

  @BeforeEach
  void beforeEach() {
    testSubject = new AddressChangeMapper();
  }

  @Test
  void shouldMapPostalAddressRequestWithPafAndLesserAddressLinesToAddressChange() {

    AddressChange addressChange = testSubject.map(buildPostalAddressRequestPayload(true, false));

    assertThat(addressChange.getPartySysId(), is(nullValue()));
    assertThat(addressChange.getAmendDate(), is(nullValue()));
    assertThat(addressChange.getAddressLine1(), is(ADDRESS_LINE_1));
    assertThat(addressChange.getAddressLine2(), is(ADDRESS_LINE_2));
    assertThat(addressChange.getAddressLine3(), is(nullValue()));
    assertThat(addressChange.getAddressLine4(), is(nullValue()));
    assertThat(addressChange.getCountry(), is(UK));
    assertThat(addressChange.getPostCode(), is(POSTCODE));
    assertThat(addressChange.getPafKey(), is(PAF_KEY));
    assertThat(addressChange.getPafDeliveryPrefix(), is("1T"));
  }

  @Test
  void shouldMapPostalAddressRequestWithPafAndAllAddressLinesToAddressChange() {

    AddressChange addressChange = testSubject.map(buildPostalAddressRequestPayload(true, true));

    assertThat(addressChange.getPartySysId(), is(nullValue()));
    assertThat(addressChange.getAmendDate(), is(nullValue()));
    assertThat(addressChange.getAddressLine1(), is(ADDRESS_LINE_1));
    assertThat(addressChange.getAddressLine2(), is(ADDRESS_LINE_2));
    assertThat(addressChange.getAddressLine3(), is(ADDRESS_LINE_3));
    assertThat(addressChange.getAddressLine4(), is(ADDRESS_LINE_4));
    assertThat(addressChange.getCountry(), is(UK));
    assertThat(addressChange.getPostCode(), is(POSTCODE));
    assertThat(addressChange.getPafKey(), is(PAF_KEY));
    assertThat(addressChange.getPafDeliveryPrefix(), is("1T"));
  }

  @Test
  void shouldMapPostalAddressRequestWithoutPafAndLessAddressLinesToAddressChange() {

    AddressChange addressChange = testSubject.map(buildPostalAddressRequestPayload(false, false));

    assertThat(addressChange.getPartySysId(), is(nullValue()));
    assertThat(addressChange.getAmendDate(), is(nullValue()));
    assertThat(addressChange.getAddressLine1(), is(ADDRESS_LINE_1));
    assertThat(addressChange.getAddressLine2(), is(ADDRESS_LINE_2));
    assertThat(addressChange.getAddressLine3(), is(nullValue()));
    assertThat(addressChange.getAddressLine4(), is(nullValue()));
    assertThat(addressChange.getCountry(), is(UK));
    assertThat(addressChange.getPostCode(), is(POSTCODE));
    assertThat(addressChange.getPafKey(), is(nullValue()));
    assertThat(addressChange.getPafDeliveryPrefix(), is(nullValue()));
  }

  @Test
  void shouldMapPostalAddressRequestWithoutPafAndAllAddressLinesToAddressChange() {

    AddressChange addressChange = testSubject.map(buildPostalAddressRequestPayload(false, true));

    assertThat(addressChange.getPartySysId(), is(nullValue()));
    assertThat(addressChange.getAmendDate(), is(nullValue()));
    assertThat(addressChange.getAddressLine1(), is(ADDRESS_LINE_1));
    assertThat(addressChange.getAddressLine2(), is(ADDRESS_LINE_2));
    assertThat(addressChange.getAddressLine3(), is(ADDRESS_LINE_3));
    assertThat(addressChange.getAddressLine4(), is(ADDRESS_LINE_4));
    assertThat(addressChange.getCountry(), is(UK));
    assertThat(addressChange.getPostCode(), is(POSTCODE));
    assertThat(addressChange.getPafKey(), is(nullValue()));
    assertThat(addressChange.getPafDeliveryPrefix(), is(nullValue()));
  }
}
