package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Optional;
import java.util.stream.Stream;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.repository.core.NonPostalAddressCoreRepository;
import uk.co.ybs.digital.customer.repository.core.PartyCoreRepository;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class UpdatePhoneNumberProcessorTest {

  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final long LINKED_PARTY_ID = 100000L;
  private static final long PARTY_ID = 123456L;
  private static final String NEW_ADC_CODE = "4321";
  private static final String NEW_HOME_NUMBER = "987654";
  private static final String NEW_MOBILE_NUMBER = "07987654321";
  private static final String PODCODE = "8AM-12PM";

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-09-01T00:00:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);

  public static final LocalDateTime YESTERDAY = NOW.minusDays(1);

  @Mock private AuditService auditService;

  @Mock private PartyCoreRepository partyCoreRepository;

  @Mock private NonPostalAddressCoreRepository nonPostalAddressCoreRepository;

  @InjectMocks private UpdatePhoneNumberProcessor testSubject;

  @Captor private ArgumentCaptor<Party> savedParty;

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments") // NOPMD
  void resolveShouldReturnParty(final NonPostalAddress nonPostalAddress) {

    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(
            TestHelper.createRequestMetadata(),
            nonPostalAddress,
            nonPostalAddress.getAdcCode(),
            nonPostalAddress.getAddress());

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(nonPostalAddress));

    final LinkedParty linkedParty = stubLinkedParty(PARTY_ID, LINKED_PARTY_ID);

    when(partyCoreRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(linkedParty.getCanonicalPartyId()),
            eq(Collections.singleton(AddressType.TEL)),
            eq(EnumSet.allOf(AddressUsage.AddressFunction.class)),
            eq(PROCESS_TIME)))
        .thenReturn(Optional.of(party));

    final Party resolvedParty = testSubject.resolve(arguments);

    assertThat(resolvedParty, is(party));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments") // NOPMD
  void resolveShouldCustomerNotFoundExceptionWhenNoCanonicalParty(
      final NonPostalAddress nonPostalAddress) {
    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(
            TestHelper.createRequestMetadata(),
            nonPostalAddress,
            nonPostalAddress.getAdcCode(),
            nonPostalAddress.getAddress());

    when(partyCoreRepository.findCanonicalPartyId(PARTY_ID)).thenReturn(Optional.empty());

    final CustomerNotFoundException exception =
        assertThrows(CustomerNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("No record found in party database for party id 123456"));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments") // NOPMD
  void resolveShouldCustomerNotFoundExceptionWhenCoreRepositoryReturnsEmpty(
      final NonPostalAddress nonPostalAddress) {
    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(
            TestHelper.createRequestMetadata(),
            nonPostalAddress,
            nonPostalAddress.getAdcCode(),
            nonPostalAddress.getAddress());

    stubLinkedParty(PARTY_ID, LINKED_PARTY_ID);

    when(partyCoreRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(LINKED_PARTY_ID),
            eq(Collections.singleton(AddressType.TEL)),
            eq(EnumSet.allOf(AddressUsage.AddressFunction.class)),
            eq(PROCESS_TIME)))
        .thenReturn(Optional.empty());

    final CustomerNotFoundException exception =
        assertThrows(CustomerNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("No record found in party database for party id 123456"));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArgumentsForUpdate") // NOPMD
  void executeShouldEndOldPhoneNumberAndCreateNewPhoneNumber(
      final NonPostalAddress nonPostalAddress, final Integer adcCode, final String number) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(nonPostalAddress));

    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(requestMetadata, nonPostalAddress, adcCode, number);

    when(nonPostalAddressCoreRepository
            .findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
                number,
                AddressType.TEL,
                adcCode,
                nonPostalAddress.getSourceType(),
                nonPostalAddress.getCountry()))
        .thenReturn(Optional.empty());

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                PODCODE,
                nonPostalAddressMatcher(
                    AddressType.TEL,
                    nonPostalAddress.getAdcCode(),
                    nonPostalAddress.getAddress(),
                    nonPostalAddress.getSourceType())),
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                PROCESS_TIME,
                null,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                PODCODE,
                nonPostalAddressMatcher(
                    AddressType.TEL, adcCode, number, nonPostalAddress.getSourceType()))));
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArgumentsForUpdate") // NOPMD
  void executeShouldEndMultipleOldPhoneNumbersAndCreateNewPhoneNumber(
      final NonPostalAddress nonPostalAddress, final Integer adcCode, final String number) {
    // Although an account should only ever have a single active phone number we have a data
    // quality issue where multiple can exist.  In this case both should be ended and the
    // new phone number created.
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Arrays.asList(nonPostalAddress, nonPostalAddress));

    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(requestMetadata, nonPostalAddress, adcCode, number);

    when(nonPostalAddressCoreRepository
            .findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
                number,
                AddressType.TEL,
                adcCode,
                nonPostalAddress.getSourceType(),
                nonPostalAddress.getCountry()))
        .thenReturn(Optional.empty());

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                PODCODE,
                nonPostalAddressMatcher(
                    AddressType.TEL,
                    nonPostalAddress.getAdcCode(),
                    nonPostalAddress.getAddress(),
                    nonPostalAddress.getSourceType())),
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                PODCODE,
                nonPostalAddressMatcher(
                    AddressType.TEL,
                    nonPostalAddress.getAdcCode(),
                    nonPostalAddress.getAddress(),
                    nonPostalAddress.getSourceType())),
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                PROCESS_TIME,
                null,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                PODCODE,
                nonPostalAddressMatcher(
                    AddressType.TEL, adcCode, number, nonPostalAddress.getSourceType()))));
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArgumentsForUpdate") // NOPMD
  void executeShouldCreateNewPhoneNumberWhenNotExistsForSourceType(
      final NonPostalAddress nonPostalAddress, final Integer adcCode, final String number) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(nonPostalAddress));
    party.getAddresses().clear(); // Remove any existing phone numbers

    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(requestMetadata, nonPostalAddress, adcCode, number);

    when(nonPostalAddressCoreRepository
            .findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
                number,
                AddressType.TEL,
                adcCode,
                nonPostalAddress.getSourceType(),
                nonPostalAddress.getCountry()))
        .thenReturn(Optional.empty());

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                PROCESS_TIME,
                null,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                false,
                null,
                nonPostalAddressMatcher(
                    AddressType.TEL, adcCode, number, nonPostalAddress.getSourceType()))));
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments") // NOPMD
  void executeShouldCreateNewAddressUsageWithExistingNonPostalAddress(
      final NonPostalAddress nonPostalAddress) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(nonPostalAddress));
    party.getAddresses().clear(); // Remove any existing phone numbers

    final Integer adcCode = nonPostalAddress.getAdcCode();
    final String number = nonPostalAddress.getAddress();

    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(requestMetadata, nonPostalAddress, adcCode, number);

    when(nonPostalAddressCoreRepository
            .findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
                number,
                AddressType.TEL,
                adcCode,
                nonPostalAddress.getSourceType(),
                nonPostalAddress.getCountry()))
        .thenReturn(Optional.of(nonPostalAddress));

    testSubject.execute(arguments, party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                PROCESS_TIME,
                null,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                false,
                null,
                nonPostalAddressMatcher(
                    AddressType.TEL, adcCode, number, nonPostalAddress.getSourceType()))));
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArgumentsForUpdate") // NOPMD
  void auditSuccessShouldCallAuditService(
      final NonPostalAddress nonPostalAddress, final Integer adcCode, final String number) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(requestMetadata, nonPostalAddress, adcCode, number);

    testSubject.auditSuccess(arguments);

    final String address = adcCode == null ? number : "0" + adcCode + number;

    final AuditNonPostalAddressUpdateSuccessRequest auditRequest =
        AuditNonPostalAddressUpdateSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .address(address)
            .operation(NonPostalOperation.PHONE_NUMBER)
            .type(NonPostalType.valueOf(nonPostalAddress.getSourceType().toString()))
            .build();

    verify(auditService).auditNonPostalAddressUpdateSuccess(auditRequest, requestMetadata);
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArgumentsForUpdate") // NOPMD
  void auditFailureShouldCallAuditService(
      final NonPostalAddress nonPostalAddress, final Integer adcCode, final String number) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final UpdatePhoneNumberRequestArguments arguments =
        buildPhoneNumberRequestArguments(requestMetadata, nonPostalAddress, adcCode, number);

    testSubject.auditFailure(arguments, TestHelper.TECHNICAL_FAILURE_MESSAGE);

    final String address = adcCode == null ? number : "0" + adcCode + number;

    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        AuditNonPostalAddressUpdateFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(TestHelper.TECHNICAL_FAILURE_MESSAGE)
            .address(address)
            .operation(NonPostalOperation.PHONE_NUMBER)
            .type(NonPostalType.valueOf(nonPostalAddress.getSourceType().toString()))
            .build();

    verify(auditService).auditNonPostalAddressUpdateFailure(auditRequest, requestMetadata);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private Matcher<AddressUsage> addressUsageMatcher(
      final AddressUsage.AddressFunction function,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final LocalDateTime createdDate,
      final String createdAt,
      final String createdBy,
      final LocalDateTime endedDate,
      final String endedAt,
      final String endedBy,
      final boolean preferredContactMethod,
      final String podCode,
      final Matcher<NonPostalAddress> nonPostalAddress) {
    Matcher<AddressUsageFunction> addressUsageFunction =
        addressUsageFunctionMatcher(startDate, endDate);
    return allOf(
        hasProperty("function", is(function)),
        hasProperty("startDate", is(startDate)),
        hasProperty("endDate", is(endDate)),
        hasProperty("createdDate", is(createdDate)),
        hasProperty("createdAt", is(createdAt)),
        hasProperty("createdBy", is(createdBy)),
        hasProperty("endedDate", is(endedDate)),
        hasProperty("endedAt", is(endedAt)),
        hasProperty("endedBy", is(endedBy)),
        hasProperty("preferredContactMethod", is(preferredContactMethod)),
        hasProperty("podCode", is(podCode)),
        hasProperty("nonPostalAddress", nonPostalAddress),
        hasProperty("functions", contains(addressUsageFunction)));
  }

  private Matcher<NonPostalAddress> nonPostalAddressMatcher(
      final AddressType type,
      final Integer adcCode,
      final String address,
      final NPASourceType sourceType) {
    return allOf(
        hasProperty("type", is(type)),
        hasProperty("adcCode", is(adcCode)),
        hasProperty("address", is(address)),
        hasProperty("sourceType", is(sourceType)));
  }

  private Matcher<AddressUsageFunction> addressUsageFunctionMatcher(
      final LocalDateTime startDate, final LocalDateTime endDate) {

    Matcher<AddressUsageFunction.AddressUsageFunctionPK> addressUsageFunctionPK =
        addressUsageFunctionPKMatcher(startDate);

    return allOf(
        hasProperty("id", is(addressUsageFunctionPK)), hasProperty("endDate", is(endDate)));
  }

  private Matcher<AddressUsageFunction.AddressUsageFunctionPK> addressUsageFunctionPKMatcher(
      final LocalDateTime startDate) {

    return allOf(hasProperty("startDate", is(startDate)));
  }

  private LinkedParty stubLinkedParty(final Long originalPartyId, final Long canonicalPartyId) {

    final LinkedParty linkedParty =
        LinkedParty.builder()
            .originalPartyId(originalPartyId)
            .canonicalPartyId(canonicalPartyId)
            .linkCount(1L)
            .build();

    when(partyCoreRepository.findCanonicalPartyId(originalPartyId))
        .thenReturn(Optional.of(linkedParty));

    return linkedParty;
  }

  private static Stream<Arguments> nonPostalAddressArgumentsForUpdate() {
    return Stream.of(
        Arguments.of(TestHelper.buildHomePhoneNumberRequest(), NEW_ADC_CODE, NEW_HOME_NUMBER),
        Arguments.of(TestHelper.buildMobilePhoneNumberRequest(), null, NEW_MOBILE_NUMBER),
        Arguments.of(
            TestHelper.buildWorkLandlinePhoneNumberRequest(), NEW_ADC_CODE, NEW_HOME_NUMBER),
        Arguments.of(TestHelper.buildWorkMobilePhoneNumberRequest(), null, NEW_MOBILE_NUMBER));
  }

  private static Stream<NonPostalAddress> nonPostalAddressArguments() {
    return Stream.of(
        TestHelper.buildHomePhoneNumberRequest(),
        TestHelper.buildMobilePhoneNumberRequest(),
        TestHelper.buildWorkLandlinePhoneNumberRequest(),
        TestHelper.buildWorkMobilePhoneNumberRequest());
  }

  private static UpdatePhoneNumberRequestArguments buildPhoneNumberRequestArguments(
      final RequestMetadata requestMetadata,
      final NonPostalAddress nonPostalAddress,
      final Integer adcCode,
      final String number) {
    return UpdatePhoneNumberRequestArguments.builder()
        .partyId(PARTY_ID)
        .requestMetadata(requestMetadata)
        .processTime(PROCESS_TIME)
        .phoneNumberRequestType(
            PhoneNumberRequestType.valueOf(nonPostalAddress.getSourceType().toString()))
        .adcCode(adcCode)
        .number(number)
        .build();
  }
}
