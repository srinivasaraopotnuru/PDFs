package uk.co.ybs.digital.customer.service;

import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;

import com.google.common.collect.ImmutableMap;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.transaction.CannotCreateTransactionException;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogRequest;
import uk.co.ybs.digital.customer.repository.core.MetadataRepository;
import uk.co.ybs.digital.customer.repository.digitalcustomer.WorkLogRepository;
import uk.co.ybs.digital.customer.service.audit.AuditServiceException;
import uk.co.ybs.digital.customer.service.processor.CustomerRequest;
import uk.co.ybs.digital.customer.service.processor.CustomerRequestFactory;
import uk.co.ybs.digital.customer.service.processor.ResolvedCustomerRequest;
import uk.co.ybs.digital.customer.service.utilities.WorkLogMetrics;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class CustomerProcessorServiceTest {

  private static final String EMAIL_ADDRESS = "abc@dummy.ybs.co.uk";
  private static final Long PARTY_ID = 123456L;

  private CustomerProcessorService testSubject;

  @Mock private WorkLogRepository workLogRepository;

  @Mock private MetadataRepository metadataRepository;

  @Mock private CustomerRequestFactory customerRequestFactory;

  @Mock private CustomerRequest customerRequest;

  @Mock private ResolvedCustomerRequest resolvedCustomerRequest;

  @Mock private WorkLogMetrics workLogMetrics;

  private LocalDateTime now;

  @BeforeEach
  void setUp() {
    final Clock clock =
        Clock.fixed(Instant.parse("2020-05-26T13:45:01Z"), ZoneId.of("Europe/London"));

    now = LocalDateTime.now(clock);

    testSubject =
        new CustomerProcessorService(
            workLogRepository, metadataRepository, customerRequestFactory, workLogMetrics, clock);
  }

  @Test
  void processShouldDoNothingWhenThereAreNoPendingRequests() {
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(Collections.emptyList());

    final List<WorkLog> pendingRequests = Collections.emptyList();
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    testSubject.process();

    verify(workLogMetrics).setValues(Collections.emptyMap());
    verifyNoInteractions(customerRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void processShouldUpdateMetricsWhenNoPendingRequests() {
    final List<ImmutablePair<WorkLog.Status, Long>> requestStates =
        Arrays.asList(
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 3L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 2L));
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(requestStates);

    final List<WorkLog> pendingRequests = Collections.emptyList();
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    final Map<WorkLog.Status, Long> expectedStatusCounts =
        ImmutableMap.of(WorkLog.Status.COMPLETE, 3L, WorkLog.Status.FAILED, 2L);

    testSubject.process();

    verify(workLogMetrics).setValues(expectedStatusCounts);
    verifyNoInteractions(customerRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void processShouldHandleUnexpectedExceptions() {
    doThrow(RuntimeException.class).when(workLogRepository).findCountOfRequestsInState();

    testSubject.process();

    verifyNoInteractions(customerRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @ParameterizedTest
  @MethodSource("workLogWithExceptionArguments")
  void processShouldHandleFailedLivenessCheckWhenDBUnavailable(
      final WorkLogPayload workLogPayload,
      final WorkLog.Operation operation,
      final Class<Exception> exception) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);

    final List<ImmutablePair<WorkLog.Status, Long>> requestStates =
        Arrays.asList(
            new ImmutablePair<>(WorkLog.Status.PENDING, 1L),
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 3L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 2L));
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(requestStates);

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    doThrow(exception).when(metadataRepository).count();

    final Map<WorkLog.Status, Long> expectedMap =
        ImmutableMap.of(
            WorkLog.Status.PENDING, 1L, WorkLog.Status.COMPLETE, 3L, WorkLog.Status.FAILED, 2L);

    testSubject.process();

    verify(workLogMetrics).setValues(expectedMap);
    verifyNoInteractions(customerRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processWorkLogShouldExecuteRequest(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.COMPLETE).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(customerRequestFactory.build(workLog, now)).thenReturn(customerRequest);

    when(customerRequest.resolve()).thenReturn(resolvedCustomerRequest);

    testSubject.process();

    verify(resolvedCustomerRequest).execute();
    verify(resolvedCustomerRequest).auditSuccess();
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processWorkLogShouldHandleSuccessAuditErrorWhenExecutingRequest(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.COMPLETE).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(customerRequestFactory.build(workLog, now)).thenReturn(customerRequest);
    when(customerRequest.resolve()).thenReturn(resolvedCustomerRequest);

    doThrow(new AuditServiceException("Audit Failure"))
        .when(resolvedCustomerRequest)
        .auditSuccess();

    testSubject.process();

    verify(resolvedCustomerRequest).execute();
    verify(resolvedCustomerRequest).auditSuccess();
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processWorkLogShouldHandleCustomerRequestProcessingExceptions(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(customerRequestFactory.build(workLog, now)).thenReturn(customerRequest);

    when(customerRequest.resolve()).thenReturn(resolvedCustomerRequest);

    doThrow(new CustomerServiceException(TestHelper.SERVICE_FAILURE_MESSAGE))
        .when(resolvedCustomerRequest)
        .execute();

    testSubject.process();

    verify(resolvedCustomerRequest).auditFailure(TestHelper.SERVICE_FAILURE_MESSAGE);
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processWorkLogShouldHandleUnexpectedExceptions(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(customerRequestFactory.build(workLog, now)).thenReturn(customerRequest);

    when(customerRequest.resolve()).thenReturn(resolvedCustomerRequest);

    doThrow(RuntimeException.class).when(resolvedCustomerRequest).execute();

    testSubject.process();

    verify(resolvedCustomerRequest).auditFailure(TestHelper.TECHNICAL_FAILURE_MESSAGE);
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processShouldHandleResolveCustomerNotFoundExceptions(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(customerRequestFactory.build(workLog, now)).thenReturn(customerRequest);

    when(customerRequest.resolve()).thenThrow(new CustomerNotFoundException("Customer Not Found"));

    testSubject.process();

    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));

    verify(customerRequest).auditFailure("Customer Not Found");
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processShouldHandleResolveExceptions(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(customerRequestFactory.build(workLog, now)).thenReturn(customerRequest);

    when(customerRequest.resolve()).thenThrow(new RuntimeException());

    testSubject.process();

    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));

    verify(customerRequest).auditFailure(TestHelper.TECHNICAL_FAILURE_MESSAGE);
  }

  private static WorkLog createWorkLog(
      final WorkLog.Operation operation,
      final RequestMetadata metadata,
      final WorkLogPayload workLogPayload) {

    return WorkLog.builder()
        .partyId(PARTY_ID)
        .status(WorkLog.Status.PENDING)
        .operation(operation)
        .message(WorkLogRequest.builder().workLogPayload(workLogPayload).metadata(metadata).build())
        .build();
  }

  private static Stream<Arguments> workLogArguments() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS), WorkLog.Operation.EMAIL_ADDRESS),
        Arguments.of(
            TestHelper.buildUpdateHomePhoneNumberPayload(), WorkLog.Operation.UPDATE_PHONE_NUMBER),
        Arguments.of(
            TestHelper.buildUpdateMobilePhoneNumberPayload(),
            WorkLog.Operation.UPDATE_PHONE_NUMBER),
        Arguments.of(
            TestHelper.buildUpdateWorkLandlinePhoneNumberPayload(),
            WorkLog.Operation.UPDATE_PHONE_NUMBER),
        Arguments.of(
            TestHelper.buildUpdateWorkMobilePhoneNumberPayload(),
            WorkLog.Operation.UPDATE_PHONE_NUMBER));
  }

  private static Stream<Arguments> workLogWithExceptionArguments() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS),
            WorkLog.Operation.EMAIL_ADDRESS,
            DataAccessResourceFailureException.class),
        Arguments.of(
            TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS),
            WorkLog.Operation.EMAIL_ADDRESS,
            CannotCreateTransactionException.class),
        Arguments.of(
            TestHelper.buildUpdateHomePhoneNumberPayload(),
            WorkLog.Operation.UPDATE_PHONE_NUMBER,
            DataAccessResourceFailureException.class),
        Arguments.of(
            TestHelper.buildUpdateHomePhoneNumberPayload(),
            WorkLog.Operation.UPDATE_PHONE_NUMBER,
            CannotCreateTransactionException.class));
  }
}
