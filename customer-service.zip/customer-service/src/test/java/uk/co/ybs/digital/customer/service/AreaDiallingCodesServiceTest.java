package uk.co.ybs.digital.customer.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.repository.adgcore.AreaDiallingCodesRepository;

@ExtendWith(MockitoExtension.class)
public class AreaDiallingCodesServiceTest {

  private static final String PHONE_NUMBER = "1234123456";

  @InjectMocks AreaDiallingCodesService areaDiallingCodesService;

  @Mock private AreaDiallingCodesRepository areaDiallingCodesRepository;

  @Test
  public void determineAreaDiallingCodeShouldReturnAreaCodeWhenAreaCodeFound() {

    when(areaDiallingCodesRepository.findAreaDiallingCodeForPhoneNumber("UK", PHONE_NUMBER))
        .thenReturn(Optional.of(1234));

    Optional<Integer> result = areaDiallingCodesService.determineAreaDiallingCode(PHONE_NUMBER);

    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), is(1234));
  }

  @Test
  public void determineAreaDiallingCodeShouldReturnNotPresentWhenAreaCodeNoFound() {

    when(areaDiallingCodesRepository.findAreaDiallingCodeForPhoneNumber("UK", PHONE_NUMBER))
        .thenReturn(Optional.empty());

    Optional<Integer> result = areaDiallingCodesService.determineAreaDiallingCode(PHONE_NUMBER);

    assertThat(result.isPresent(), is(false));
  }

  @Test
  public void determineAreaDiallingCodeShouldReturnAreaCodeWhenAreaCodeFoundWithLeadingZero() {

    when(areaDiallingCodesRepository.findAreaDiallingCodeForPhoneNumber("UK", PHONE_NUMBER))
        .thenReturn(Optional.of(1234));

    Optional<Integer> result = areaDiallingCodesService.determineAreaDiallingCode(PHONE_NUMBER);

    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), is(1234));
  }
}
