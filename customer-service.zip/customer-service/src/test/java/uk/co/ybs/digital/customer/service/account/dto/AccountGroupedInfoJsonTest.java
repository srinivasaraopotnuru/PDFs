package uk.co.ybs.digital.customer.service.account.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
public class AccountGroupedInfoJsonTest {

  @Autowired private JacksonTester<AccountGroupedInfo> tester;

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void serializes(final AccountGroupedInfo accountGroupedInfo, final ClassPathResource json)
      throws IOException {
    assertThat(tester.write(accountGroupedInfo)).isEqualToJson(json, JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void deserialize(final AccountGroupedInfo accountGroupedInfo, final ClassPathResource json)
      throws IOException {
    assertThat(tester.read(json)).isEqualTo(accountGroupedInfo);
  }

  private static AccountGroupedInfo buildAccountGroupedInfo(final boolean includeClosedAccounts) {
    return AccountGroupedInfo.builder()
        .owned(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccountSummary()))
                .balances(buildBalanceList())
                .build())
        .other(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccountSummary()))
                .balances(buildBalanceList())
                .build())
        .closed(
            includeClosedAccounts
                ? AccountGroupedInfo.AccountGroup.builder()
                    .accounts(Collections.singletonList(buildAccountSummary()))
                    .balances(buildBalanceList())
                    .build()
                : null) // NOPMD
        .build();
  }

  private static AccountGroupedInfo.AccountSummary buildAccountSummary() {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber("1234567890")
        .accountName("Test")
        .amendmentRestriction(true)
        .accountSortCode("123456")
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .deposits(buildDeposit())
        .withdrawals(buildWithdrawal())
        .currency("GBP")
        .productIdentifier("test")
        .productDescription("Monthly Regular Saver: Issue 2")
        .isa(buildIsa())
        .balances(buildBalanceList())
        .build();
  }

  private static AccountGroupedInfo.DepositsSummary buildDeposit() {
    return AccountGroupedInfo.DepositsSummary.builder().permittedOverApi(true).build();
  }

  private static AccountGroupedInfo.WithdrawalsSummary buildWithdrawal() {
    return AccountGroupedInfo.WithdrawalsSummary.builder().permittedOverApi(true).build();
  }

  private static AccountGroupedInfo.Isa buildIsa() {
    return AccountGroupedInfo.Isa.builder().flexible(true).helpToBuy(false).build();
  }

  private static List<AccountGroupedInfo.Balance> buildBalanceList() {
    return Collections.singletonList(
        AccountGroupedInfo.Balance.builder()
            .type("InterimAvailable")
            .amount(new BigDecimal("100.00"))
            .build());
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(
            buildAccountGroupedInfo(true),
            new ClassPathResource("api/accountService/accountsGroupedClosed.json")),
        Arguments.of(
            buildAccountGroupedInfo(false),
            new ClassPathResource("api/accountService/accountsGrouped.json")));
  }
}
