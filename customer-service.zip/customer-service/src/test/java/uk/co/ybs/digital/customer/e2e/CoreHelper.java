package uk.co.ybs.digital.customer.e2e;

import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFNUS;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFSUC;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildCountry;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.persistence.EntityManager;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.core.PartyType;
import uk.co.ybs.digital.customer.model.core.Person;
import uk.co.ybs.digital.customer.model.core.PostalAddress;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.utils.TestHelper;

@RequiredArgsConstructor
public class CoreHelper {
  private final TransactionTemplate transactionTemplate;
  private final TestEntityManager testEntityManager;

  public void tearDownDb(final TestEntityManager digitalCustomerTestEntityManager) {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager digitalCustomerEntityManager =
              digitalCustomerTestEntityManager.getEntityManager();

          digitalCustomerEntityManager.createQuery("delete from WorkLog").executeUpdate();
        });

    clearDb();
  }

  public Party setupParty(final long partyId, final Set<AddressType> includeAddressTypes) {

    Party party = createParty(partyId, includeAddressTypes);

    return transactionTemplate.execute(
        status -> {
          testEntityManager.persist(party.getPartyType());
          testEntityManager.persist(party.getPerson());
          return testEntityManager.persistAndFlush(party);
        });
  }

  public Party createParty(final long partyId, final Set<AddressType> includeAddressTypes) {
    Party party =
        Party.builder().sysId(partyId).partyType(buildPartyType()).person(buildPerson()).build();

    List<AddressUsage> addressUsages = new ArrayList<>();

    if (includeAddressTypes.contains(AddressType.UKPOST)) {
      addressUsages.add(
          AddressUsage.builder()
              .postalAddress(
                  PostalAddress.builder()
                      .line1("AddressLine1_1")
                      .line2("AddressLine2_1")
                      .line4("AddressLine3_1")
                      .country(Country.builder().code("UK").isoCode("GB").build())
                      .pafStatus(PAF_STATUS_PAFNUS)
                      .postCode(
                          PostCode.builder()
                              .areaCode("PO")
                              .districtCode("57")
                              .sectorCode("0")
                              .unitCode("DE")
                              .build())
                      .type(AddressType.UKPOST)
                      .build())
              .function(AddressUsage.AddressFunction.CORR)
              .function(
                  AddressUsageFunction.builder()
                      .id(
                          AddressUsageFunction.AddressUsageFunctionPK.builder()
                              .function(AddressUsage.AddressFunction.CORR)
                              .startDate(TestData.PARTY_CREATED_DATE)
                              .build())
                      .build())
              .startDate(TestData.PARTY_CREATED_DATE)
              .createdDate(TestData.PARTY_CREATED_DATE)
              .createdAt(TestData.CREATED_AT)
              .createdBy(TestData.CREATED_BY)
              .build());
    }

    if (includeAddressTypes.contains(AddressType.EMAIL)) {
      addressUsages.add(
          AddressUsage.builder()
              .nonPostalAddress(buildEmailAddress(TestData.EMAIL_ADDRESS))
              .function(AddressUsage.AddressFunction.DIRCOM)
              .startDate(TestData.PARTY_CREATED_DATE)
              .createdDate(TestData.PARTY_CREATED_DATE)
              .createdAt(TestData.CREATED_AT)
              .createdBy(TestData.CREATED_BY)
              .preferredContactMethod(true)
              .function(
                  AddressUsageFunction.builder()
                      .id(
                          AddressUsageFunction.AddressUsageFunctionPK.builder()
                              .function(AddressUsage.AddressFunction.DIRCOM)
                              .startDate(TestData.PARTY_CREATED_DATE)
                              .build())
                      .build())
              .build());
    }

    if (includeAddressTypes.contains(AddressType.TEL)) {
      addressUsages.add(
          AddressUsage.builder()
              .nonPostalAddress(
                  NonPostalAddress.builder()
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.HOME)
                      .address(TestData.HOME_ADDRESS)
                      .build())
              .function(AddressUsage.AddressFunction.DIRCOM)
              .startDate(TestData.PARTY_CREATED_DATE)
              .createdDate(TestData.PARTY_CREATED_DATE)
              .createdAt(TestData.CREATED_AT)
              .createdBy(TestData.CREATED_BY)
              .function(
                  AddressUsageFunction.builder()
                      .id(
                          AddressUsageFunction.AddressUsageFunctionPK.builder()
                              .function(AddressUsage.AddressFunction.DIRCOM)
                              .startDate(TestData.PARTY_CREATED_DATE)
                              .build())
                      .build())
              .build());

      addressUsages.add(
          AddressUsage.builder()
              .nonPostalAddress(
                  NonPostalAddress.builder()
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.MOBILE)
                      .address(TestData.MOBILE_ADDRESS)
                      .build())
              .function(AddressUsage.AddressFunction.DIRCOM)
              .startDate(TestData.PARTY_CREATED_DATE)
              .createdDate(TestData.PARTY_CREATED_DATE)
              .createdAt(TestData.CREATED_AT)
              .createdBy(TestData.CREATED_BY)
              .function(
                  AddressUsageFunction.builder()
                      .id(
                          AddressUsageFunction.AddressUsageFunctionPK.builder()
                              .function(AddressUsage.AddressFunction.DIRCOM)
                              .startDate(TestData.PARTY_CREATED_DATE)
                              .build())
                      .build())
              .build());

      addressUsages.add(
          AddressUsage.builder()
              .nonPostalAddress(
                  NonPostalAddress.builder()
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.WORK)
                      .address(TestData.WORK_ADDRESS)
                      .build())
              .function(AddressUsage.AddressFunction.DIRCOM)
              .startDate(TestData.PARTY_CREATED_DATE)
              .createdDate(TestData.PARTY_CREATED_DATE)
              .createdAt(TestData.CREATED_AT)
              .createdBy(TestData.CREATED_BY)
              .function(
                  AddressUsageFunction.builder()
                      .id(
                          AddressUsageFunction.AddressUsageFunctionPK.builder()
                              .function(AddressUsage.AddressFunction.DIRCOM)
                              .startDate(TestData.PARTY_CREATED_DATE)
                              .build())
                      .build())
              .build());
    }
    party.setAddresses(addressUsages);

    TestHelper.fixBiDirectionalReferences(party);

    return party;
  }

  private NonPostalAddress buildEmailAddress(final String emailAddress) {
    return NonPostalAddress.builder().type(AddressType.EMAIL).address(emailAddress).build();
  }

  private static PartyType buildPartyType() {
    return PartyType.builder()
        .code("PERSON")
        .type("PERSON")
        .startDate(TestData.PARTY_CREATED_DATE)
        .build();
  }

  private Person buildPerson() {
    return Person.builder().title("Mr").forenames("Joe").surname("Bloggs").build();
  }

  public void clearDb() {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager entityManager = testEntityManager.getEntityManager();
          entityManager.createQuery("delete from AddressUsageFunction").executeUpdate();
          entityManager.createQuery("delete from AddressUsage").executeUpdate();
          entityManager.createQuery("delete from NonPostalAddress").executeUpdate();
          entityManager.createQuery("delete from PostalAddress").executeUpdate();
          entityManager.createQuery("delete from Person").executeUpdate();
          entityManager.createQuery("delete from Party").executeUpdate();
          entityManager.createQuery("delete from PartyType").executeUpdate();
          entityManager.createQuery("delete from ActivityPlayer").executeUpdate();
          entityManager.createQuery("delete from LoanPartStatus").executeUpdate();
          entityManager.createQuery("delete from LoanPart").executeUpdate();
          entityManager.createQuery("delete from LoanAccount").executeUpdate();
          entityManager.createQuery("delete from ActivityType").executeUpdate();
        });
  }

  public PostalAddress setupPostalAddress(
      final UpdatePostalAddressRequest updatePostalAddressRequest) {

    PostalAddress pa =
        PostalAddress.builder()
            .line1(updatePostalAddressRequest.getAddressLine1())
            .line2(updatePostalAddressRequest.getAddressLine2())
            .line3(updatePostalAddressRequest.getAddressLine3())
            .line4(updatePostalAddressRequest.getAddressLine4())
            .line5(updatePostalAddressRequest.getAddressLine5())
            .type(AddressType.valueOf(updatePostalAddressRequest.getAddressType().toString()))
            .country(Country.builder().code(updatePostalAddressRequest.getCountry()).build())
            .postCode(
                PostCode.builder()
                    .areaCode(updatePostalAddressRequest.getAreaCode())
                    .unitCode(updatePostalAddressRequest.getUnitCode())
                    .districtCode(updatePostalAddressRequest.getDistrictCode())
                    .sectorCode(updatePostalAddressRequest.getSectorCode())
                    .build())
            .pafStatus(
                updatePostalAddressRequest.getPafAddressKey() == null
                    ? PAF_STATUS_PAFNUS
                    : PAF_STATUS_PAFSUC)
            .pafAddressKey(updatePostalAddressRequest.getPafAddressKey())
            .pafDps(updatePostalAddressRequest.getPafDeliveryPointSuffix())
            .pafKeyPart3(
                updatePostalAddressRequest.getPafAddressKey() == null
                    ? null
                    : updatePostalAddressRequest.getAddressLine1().substring(0, 10).trim()) // NOPMD
            .pafReturnCode(null)
            .build();

    return transactionTemplate.execute(status -> testEntityManager.persistAndFlush(pa));
  }

  public void setupNonPostalAddress(final UpdatePhoneRequest updatePhoneRequest) {

    NonPostalAddress npa =
        NonPostalAddress.builder()
            .adcCode(updatePhoneRequest.getAreaDiallingCode())
            .address(updatePhoneRequest.getNumber())
            .country(buildCountry())
            .sourceType(NPASourceType.valueOf(updatePhoneRequest.getRequestType().toString()))
            .type(AddressType.TEL)
            .build();

    transactionTemplate.executeWithoutResult(status -> testEntityManager.persistAndFlush(npa));
  }
}
