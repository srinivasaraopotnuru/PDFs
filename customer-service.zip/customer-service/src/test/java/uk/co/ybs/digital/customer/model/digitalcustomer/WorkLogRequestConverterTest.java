package uk.co.ybs.digital.customer.model.digitalcustomer;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class WorkLogRequestConverterTest {

  private static final String EMAIL_ADDRESS = "abc@dummy.ybs.co.uk";
  private static final String PARTY_ID = "123456";
  private static final String BRAND_YBS = "YBS";
  private static final UUID REQUEST_ID = UUID.fromString("8e112ed4-0374-47d0-aa82-427049d2dab4");
  private static final UUID SESSION_ID = UUID.fromString("8e112ed4-0374-47d0-aa82-427049d2dab4");

  private static final String TEST_RESULT_EMAIL_ADDRESS_STRING =
      "{\"workLogPayload\":{\"type\":\"UpdateEmailRequest\",\"requestType\":\"Email\",\"email\":\"abc@dummy.ybs.co.uk\"},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"customerservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\",\"webCustomerNumber\":\"123456\"}}";

  private static final String TEST_RESULT_HOME_PHONE_NUMBER_STRING =
      "{\"workLogPayload\":{\"type\":\"UpdatePhoneRequest\",\"requestType\":\"HOME\",\"areaDiallingCode\":1234,\"number\":\"456789\"},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"customerservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\",\"webCustomerNumber\":\"123456\"}}";
  private static final String TEST_RESULT_MOBILE_PHONE_NUMBER_STRING =
      "{\"workLogPayload\":{\"type\":\"UpdatePhoneRequest\",\"requestType\":\"MOBILE\",\"areaDiallingCode\":null,\"number\":\"07123456789\"},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"customerservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\",\"webCustomerNumber\":\"123456\"}}";
  private static final String TEST_RESULT_WORK_LANDLINE_PHONE_NUMBER_STRING =
      "{\"workLogPayload\":{\"type\":\"UpdatePhoneRequest\",\"requestType\":\"WORK\",\"areaDiallingCode\":1234,\"number\":\"456789\"},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"customerservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\",\"webCustomerNumber\":\"123456\"}}";
  private static final String TEST_RESULT_WORK_MOBILE_PHONE_NUMBER_STRING =
      "{\"workLogPayload\":{\"type\":\"UpdatePhoneRequest\",\"requestType\":\"WORK\",\"areaDiallingCode\":null,\"number\":\"07123456789\"},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"customerservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\",\"webCustomerNumber\":\"123456\"}}";

  private static final String TEST_RESULT_DELETE_PHONE_NUMBER_STRING =
      "{\"workLogPayload\":{\"type\":\"DeletePhoneRequest\",\"requestType\":\"MOBILE\"},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"customerservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\",\"webCustomerNumber\":\"123456\"}}";

  private static final String TEST_RESULT_UPDATE_POSTAL_ADDRESS_STRING =
      "{\"workLogPayload\":{\"type\":\"UpdatePostalAddressRequest\",\"addressType\":\"UKPOST\",\"function\":\"CORR\",\"addressLine1\":\"1 FAKE LANE\",\"addressLine2\":null,\"addressLine3\":null,\"addressLine4\":null,\"addressLine5\":null,\"country\":\"UK\",\"areaCode\":\"RM\",\"districtCode\":\"4\",\"sectorCode\":\"1\",\"unitCode\":\"PL\",\"pafAddressKey\":null,\"pafDeliveryPointSuffix\":null},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"sessionId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"customerservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\",\"webCustomerNumber\":\"123456\"}}";

  @InjectMocks private WorkLogRequestConverter testSubject;

  @ParameterizedTest
  @MethodSource("requestArguments")
  void shouldCreateJsonStringFromWorkLogRequestWithPayload(
      final WorkLogPayload request, final String testString) {
    final WorkLogRequest input = createWorkLogRequestWithPayload(request);

    final String result = testSubject.convertToDatabaseColumn(input);
    assertThat(result, samePropertyValuesAs(testString));
  }

  @ParameterizedTest
  @MethodSource("requestArguments")
  void shouldReturnValidWorkLogRequestWithPayload(
      final WorkLogPayload request, final String testString) {
    final WorkLogRequest result = testSubject.convertToEntityAttribute(testString);

    final WorkLogRequest expected = createWorkLogRequestWithPayload(request);
    assertThat(result, samePropertyValuesAs(expected));
  }

  @Test
  void shouldThrowErrorIfValueIsNotValidSerializedWorkLogChangeRequest() {
    assertThrows(
        WorkLogRequestConverter.DataConversionException.class,
        () -> testSubject.convertToEntityAttribute("{\"invalid\":\"entity\"}"));
  }

  private static UpdateEmailRequest createUpdateEmailPayload() {
    return UpdateEmailRequest.builder().requestType("Email").email(EMAIL_ADDRESS).build();
  }

  private static Stream<Arguments> requestArguments() {
    return Stream.of(
        Arguments.of(createUpdateEmailPayload(), TEST_RESULT_EMAIL_ADDRESS_STRING),
        Arguments.of(
            TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.MOBILE),
            TEST_RESULT_DELETE_PHONE_NUMBER_STRING),
        Arguments.of(
            TestHelper.buildUpdateHomePhoneNumberPayload(), TEST_RESULT_HOME_PHONE_NUMBER_STRING),
        Arguments.of(
            TestHelper.buildUpdateMobilePhoneNumberPayload(),
            TEST_RESULT_MOBILE_PHONE_NUMBER_STRING),
        Arguments.of(
            TestHelper.buildUpdateWorkLandlinePhoneNumberPayload(),
            TEST_RESULT_WORK_LANDLINE_PHONE_NUMBER_STRING),
        Arguments.of(
            TestHelper.buildUpdateWorkMobilePhoneNumberPayload(),
            TEST_RESULT_WORK_MOBILE_PHONE_NUMBER_STRING),
        Arguments.of(
            TestHelper.buildUpdatePostalAddressPayload(),
            TEST_RESULT_UPDATE_POSTAL_ADDRESS_STRING));
  }

  private static WorkLogRequest createWorkLogRequestWithPayload(final WorkLogPayload payload) {
    return WorkLogRequest.builder()
        .workLogPayload(payload)
        .metadata(createRequestMetadata())
        .build();
  }

  private static RequestMetadata createRequestMetadata() {
    return RequestMetadata.builder()
        .host(InetSocketAddress.createUnresolved("customerservice.ybs.co.uk", 443))
        .requestId(REQUEST_ID)
        .sessionId(SESSION_ID)
        .brandCode(BRAND_YBS)
        .partyId(PARTY_ID)
        .forwardingAuth("<jwt>")
        .ipAddress("12.66.53.145")
        .webCustomerNumber(PARTY_ID)
        .build();
  }
}
