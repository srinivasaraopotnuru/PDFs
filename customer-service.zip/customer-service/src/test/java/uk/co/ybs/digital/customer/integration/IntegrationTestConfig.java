package uk.co.ybs.digital.customer.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.StringReader;
import java.security.PrivateKey;
import java.security.Security;
import java.util.Objects;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.WebTestClientConfigurer;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import uk.co.ybs.digital.security.requestsigning.ClientHttpRequestSigner;
import uk.co.ybs.digital.security.requestsigning.PayloadBuilder;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnector;
import uk.co.ybs.digital.security.requestsigning.RequestSigningKeyRegistry;
import uk.co.ybs.digital.security.requestsigning.SignatureFactory;

@TestConfiguration
public class IntegrationTestConfig {
  @Value("${test.jwt.private.key}")
  String jwtSigningPrivateKeyPem;

  @Value("${test.request.private.key}")
  String requestSigningPrivateKeyPem;

  private static final String REQUEST_SIGNATURE_KEY_ID_PUBLIC = "request-signature-key-id-public";

  @Bean
  @Primary
  public PrivateKey jwtSigningPrivateKey() throws IOException {
    Security.addProvider(new BouncyCastleProvider());
    try (PEMParser pemReader = new PEMParser(new StringReader(jwtSigningPrivateKeyPem))) {
      PEMKeyPair keyPair = (PEMKeyPair) pemReader.readObject();
      return BouncyCastleProvider.getPrivateKey(keyPair.getPrivateKeyInfo());
    }
  }

  @Bean
  public WebTestClient signingWebClientPublic(
      final ClientHttpConnector connector,
      final PrivateKey requestSigningPrivateKeyPublic,
      final WebTestClientConfigurer webTestClientConfigurer) {
    return buildSigningWebClient(
        connector,
        webTestClientConfigurer,
        REQUEST_SIGNATURE_KEY_ID_PUBLIC,
        requestSigningPrivateKeyPublic);
  }

  @Bean("requestSigningPrivateKey")
  @Qualifier("requestSigningPrivateKey")
  public PrivateKey requestSigningPrivateKey() throws IOException {
    Security.addProvider(new BouncyCastleProvider());

    try (PEMParser parser = new PEMParser(new StringReader(requestSigningPrivateKeyPem))) {
      PEMKeyPair pemObject =
          (PEMKeyPair)
              Objects.requireNonNull(
                  parser.readObject(),
                  "Could not construct a PrivateKey from " + requestSigningPrivateKeyPem);
      return BouncyCastleProvider.getPrivateKey(pemObject.getPrivateKeyInfo());
    }
  }

  @Bean
  public WebTestClient signingWebTestClient(
      final ClientHttpConnector connector,
      @Qualifier("requestSigningPrivateKey") final PrivateKey requestSigningPrivateKey,
      final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(
            new RequestSigningClientHttpConnector(
                connector,
                new ClientHttpRequestSigner(
                    new SignatureFactory(),
                    new PayloadBuilder(),
                    new RequestSigningKeyRegistry(
                        "FKbfNeQxsVQL5CwAJKP0q5fWOVe9ukn1K0lw", requestSigningPrivateKey))))
        .apply(webTestClientConfigurer)
        .build();
  }

  @Bean
  public WebTestClient nonSigningWebTestClient(
      final ClientHttpConnector connector, final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(connector).apply(webTestClientConfigurer).build();
  }

  /**
   * WebTestClient doesn't seem to get properly configured with the Spring context ObjectMapper.
   * Manually do this.
   */
  @Bean
  public WebTestClientConfigurer webTestClientConfigurer(final ObjectMapper objectMapper) {
    return (builder, httpHandlerBuilder, connector) ->
        builder.exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(
                    (configurer) -> {
                      configurer
                          .defaultCodecs()
                          .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                      configurer
                          .defaultCodecs()
                          .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                    })
                .build());
  }

  private WebTestClient buildSigningWebClient(
      final ClientHttpConnector connector,
      final WebTestClientConfigurer webTestClientConfigurer,
      final String requestSigningPrivateKeyId,
      final PrivateKey requestSigningPrivateKey) {
    return WebTestClient.bindToServer(
            new RequestSigningClientHttpConnector(
                connector,
                new ClientHttpRequestSigner(
                    new SignatureFactory(),
                    new PayloadBuilder(),
                    new RequestSigningKeyRegistry(
                        requestSigningPrivateKeyId, requestSigningPrivateKey))))
        .apply(webTestClientConfigurer)
        .build();
  }
}
