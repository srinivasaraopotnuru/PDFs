package uk.co.ybs.digital.customer.service.utilities;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;

public class PhoneNumberUtilitiesTest {

  @ParameterizedTest
  @MethodSource("phoneNumbers")
  void shouldDetermineIfHomeOrWorkNumber(
      final PhoneNumberBasicType type, final String number, final boolean isHomeOrWorkNumber) {

    boolean result = PhoneNumberUtilities.isHomeOrWorkNumber(type, number);

    assertThat(result, is(isHomeOrWorkNumber));
  }

  @ParameterizedTest
  @MethodSource("formattedNumbers")
  void shouldDetermineIfFormattedNumberOk(final String number, final String formattedNumber) {

    String result = PhoneNumberUtilities.formatPhoneNumber(number);

    assertThat(result, is(formattedNumber));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> phoneNumbers() {
    return Stream.of(
        Arguments.of(PhoneNumberBasicType.HOME, "01234 123456", true),
        Arguments.of(PhoneNumberBasicType.MOBILE, "07525 123456", false),
        Arguments.of(PhoneNumberBasicType.WORK, "01234 123456", true),
        Arguments.of(PhoneNumberBasicType.MOBILE, "01234 123456", false));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> formattedNumbers() {
    return Stream.of(
        Arguments.of("01234 123456", "01234123456"),
        Arguments.of("+44 1234 123456", "01234123456"),
        Arguments.of("01234123456", "01234123456"),
        Arguments.of("  01234    123 456 ", "01234123456"));
  }
}
