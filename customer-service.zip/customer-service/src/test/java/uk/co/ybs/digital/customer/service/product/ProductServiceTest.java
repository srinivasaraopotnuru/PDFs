package uk.co.ybs.digital.customer.service.product;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.customer.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.cache.CacheManager;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.customer.config.CachingConfiguration;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;

@JsonTest
@ContextConfiguration(classes = {CachingConfiguration.class})
public class ProductServiceTest {
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX = "Error calling product service: ";
  private static final String STATUS_CODE_400 = "400";

  private ProductService testSubject;
  private MockWebServer mockWebServer;

  private static final String REQUEST_BODY =
      readClassPathResource("api/productService/onSaleProducts.json");

  @Autowired private ObjectMapper objectMapper;

  @Autowired private GenericApplicationContext context;

  @Autowired private CacheManager cacheManager;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();

    TestHelper.clearCacheManager(cacheManager);

    final WebClient webClient =
        WebClient.builder()
            .baseUrl("http://localhost:" + mockWebServer.getPort())
            .codecs(
                configurer -> {
                  configurer
                      .defaultCodecs()
                      .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                  configurer
                      .defaultCodecs()
                      .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                })
            .build();
    testSubject = new ProductService(webClient);
  }

  @Test
  void shouldGetOnSaleProducts() throws Exception {

    final RequestMetadata requestMetadata = ProductTestHelper.buildRequestMetadata(REQUEST_ID);

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(REQUEST_BODY));

    final List<ProductCategory> returned = testSubject.getOnSaleProducts(requestMetadata);

    assertThat(returned, is(ProductTestHelper.buildOnSaleProducts()));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.GET.name()));
    assertThat(recordedRequest.getPath(), is("/private/on-sale-products"));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
  }

  @Test
  void getOnSaleProductsCacheShouldWorkAsExpected() throws InterruptedException {

    final List<ProductCategory> expected = ProductTestHelper.buildOnSaleProducts();

    // Wrap testSubject in a spring context to allow spring to intercept the calls and provide
    // caching
    context.registerBean("productService", ProductService.class, () -> testSubject);
    ProductService myService = (ProductService) context.getBean("productService");

    // First call should make a call to on-sale-products endpoint
    doCachedGetAvailableProducts(myService, expected, true);

    // Second call should populate from the cache
    doCachedGetAvailableProducts(myService, expected, false);

    myService.clearCache();

    // Third call should make a call to on-sale-products endpoint
    doCachedGetAvailableProducts(myService, expected, true);
  }

  private void doCachedGetAvailableProducts(
      final ProductService myService,
      final List<ProductCategory> expected,
      final boolean onSaleProductsServiceCalled)
      throws InterruptedException {

    // ensure all calls are different to prove caching
    final RequestMetadata requestMetadata =
        ProductTestHelper.buildRequestMetadata(UUID.randomUUID());

    if (onSaleProductsServiceCalled) {
      mockWebServer.enqueue(
          new MockResponse()
              .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
              .setBody(REQUEST_BODY));
    }

    List<ProductCategory> result = myService.getOnSaleProducts(requestMetadata);

    assertThat(result, is(expected));

    RecordedRequest recordedRequest = mockWebServer.takeRequest(1, TimeUnit.SECONDS);

    if (onSaleProductsServiceCalled) {
      assertThat(recordedRequest, is(notNullValue()));
      assertThat(recordedRequest.getPath(), is("/private/on-sale-products"));
    } else {
      assertThat(recordedRequest, is(nullValue()));
    }
  }

  @Test
  void shouldThrowProductServiceExceptionForConnectionError() throws IOException {
    final RequestMetadata requestMetadata = ProductTestHelper.buildRequestMetadata(REQUEST_ID);
    mockWebServer.shutdown();

    final ProductServiceException exception =
        assertThrows(
            ProductServiceException.class, () -> testSubject.getOnSaleProducts(requestMetadata));
    assertThat(exception.getMessage(), is(equalTo("Error calling product service")));
    assertThat(exception.getCause(), not(instanceOf(ProductServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("productServiceErrorResponses")
  void getOnSaleProductsShouldThrowProductServiceExceptionsForProductServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final RequestMetadata requestMetadata = ProductTestHelper.buildRequestMetadata(REQUEST_ID);

    final ProductServiceException exception =
        assertThrows(
            ProductServiceException.class, () -> testSubject.getOnSaleProducts(requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(ProductServiceException.class)));
  }

  @SuppressWarnings("unused")
  private static Stream<Arguments> productServiceErrorResponses() {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/errorResponseInvalidSignature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/errorResponseBadRequest.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/unexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/emptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/productService/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/productService/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)));
  }
}
