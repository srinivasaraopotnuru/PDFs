package uk.co.ybs.digital.customer.service;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WorkLogMessage {

  String requestType;
  String areaDiallingCode;
  String number;
  String pipedNumber;
}
