package uk.co.ybs.digital.customer.integration;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.security.Key;
import java.time.Duration;
import java.time.Instant;
import java.time.Period;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import lombok.experimental.UtilityClass;
import uk.co.ybs.digital.customer.utils.TestHelper;

@UtilityClass
public class IntegrationTestJwtFactory {

  public static final String CLAIM_SCOPE = "scope";
  public static final String CLAIM_BRAND_CODE = "brand_code";
  public static final String CLAIM_CANONICAL_PARTY_ID = "party_id";
  public static final String CLAIM_AUD = "aud";
  public static final String CLAIM_SUB = "sub";
  public static final String CLAIM_SESSION_ID = "sid";
  public static final String AUDIENCE = "DIGITAL_API";

  public static String createJwtWithScope(
      final String scope, final Key signingKey, final UUID sessionId) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setSubject(TestHelper.CANONICAL_PARTY_ID)
        .setAudience("DIGITAL_API")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .claim("sub_type", "customer")
        .claim("channel", "SAPP")
        .claim("party_id", TestHelper.CANONICAL_PARTY_ID)
        .claim("brand_code", "YBS")
        .claim("scope", scope)
        .claim("registration_id", UUID.randomUUID().toString())
        .claim("sid", sessionId)
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .signWith(SignatureAlgorithm.RS256, signingKey)
        .compact();
  }

  public static String createJwt(final Map<String, Object> claims, final Key signingKey) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .addClaims(claims)
        .signWith(SignatureAlgorithm.RS256, signingKey)
        .compact();
  }

  public static Map<String, Object> claimsMap(
      final String partyId,
      final String canonicalPartyId,
      final UUID sessionId,
      final String scope,
      final String brandCode) {
    return claimsMap(partyId, canonicalPartyId, sessionId.toString(), scope, brandCode);
  }

  public static Map<String, Object> claimsMap(
      final String partyId,
      final String canonicalPartyId,
      final String sessionId,
      final String scope,
      final String brandCode) {
    final Map<String, Object> map = new HashMap<>();
    map.put(CLAIM_SUB, partyId);
    map.put(CLAIM_CANONICAL_PARTY_ID, canonicalPartyId);
    map.put(CLAIM_SESSION_ID, sessionId);
    map.put(CLAIM_SCOPE, scope);
    map.put(CLAIM_BRAND_CODE, brandCode);
    map.put(CLAIM_AUD, AUDIENCE);
    return map;
  }
}
