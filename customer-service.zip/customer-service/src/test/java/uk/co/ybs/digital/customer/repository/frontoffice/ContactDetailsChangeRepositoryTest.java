package uk.co.ybs.digital.customer.repository.frontoffice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import uk.co.ybs.digital.customer.config.JpaAuditingConfig;
import uk.co.ybs.digital.customer.config.TestClockConfig;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Import({JpaAuditingConfig.class, TestClockConfig.class})
class ContactDetailsChangeRepositoryTest {

  private static final String PARTY_ID_1 = "123456789";
  private static final String PARTY_ID_2 = "987654321";

  private static final LocalDateTime EARLIEST_DATE = LocalDateTime.parse("2020-04-06T12:34:56");
  private static final LocalDateTime BEFORE_EARLIEST_DATE = EARLIEST_DATE.minusSeconds(1);
  private static final LocalDateTime AFTER_EARLIEST_DATE = EARLIEST_DATE.plusSeconds(1);

  @Autowired private ContactDetailsChangeRepository testSubject;

  @Autowired private TestEntityManager frontOfficeTestEntityManager;

  @AfterEach
  public void beforeEach() {

    frontOfficeTestEntityManager.clear();
    testSubject.deleteAll();
  }

  @Test
  void shouldFindById() {

    final ContactDetailsChange contactDetails =
        buildContactDetailsChange(PARTY_ID_1, EARLIEST_DATE);

    frontOfficeTestEntityManager.persistAndFlush(contactDetails);
    frontOfficeTestEntityManager.clear();

    final Optional<ContactDetailsChange> found =
        testSubject.findById(
            ContactDetailsChange.ContactDetailsChangePk.builder()
                .partySysId(contactDetails.getPartySysId())
                .amendDate(contactDetails.getAmendDate())
                .build());

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(contactDetails));
  }

  @Test
  public void shouldFindAllChangesForPartiesAfterEarliestTime() {

    frontOfficeTestEntityManager.persistAndFlush(
        buildContactDetailsChange(PARTY_ID_1, EARLIEST_DATE));
    frontOfficeTestEntityManager.persistAndFlush(
        buildContactDetailsChange(PARTY_ID_2, AFTER_EARLIEST_DATE));
    frontOfficeTestEntityManager.clear();

    final List<String> parties = Arrays.asList(PARTY_ID_1, PARTY_ID_2);

    final Set<String> found =
        testSubject.findAllChangesForPartiesAfterEarliestTime(parties, EARLIEST_DATE);

    assertThat(found, containsInAnyOrder(PARTY_ID_1, PARTY_ID_2));
  }

  @ParameterizedTest
  @CsvSource({"123456789,true", "987654321,false"})
  public void shouldFindAllChangesForParties(final String partyId, final boolean expectedFound) {

    frontOfficeTestEntityManager.persistAndFlush(buildContactDetailsChange(partyId, EARLIEST_DATE));
    frontOfficeTestEntityManager.clear();

    final Set<String> parties =
        testSubject.findAllChangesForPartiesAfterEarliestTime(
            Collections.singletonList(PARTY_ID_1), EARLIEST_DATE);

    assertThat(parties.isEmpty(), not(expectedFound));
  }

  @Test
  public void shouldNotFindAnyChangesForPartiesBeforeEarliestDate() {

    frontOfficeTestEntityManager.persistAndFlush(
        buildContactDetailsChange(PARTY_ID_1, BEFORE_EARLIEST_DATE));
    frontOfficeTestEntityManager.clear();

    final Set<String> parties =
        testSubject.findAllChangesForPartiesAfterEarliestTime(
            Collections.singletonList(PARTY_ID_1), EARLIEST_DATE);

    assertThat(parties.isEmpty(), not(false));
  }

  @Test
  public void shouldFindLatestChangeForPartiesAfterEarliestTime() {

    frontOfficeTestEntityManager.persistAndFlush(
        buildContactDetailsChange(PARTY_ID_1, EARLIEST_DATE));

    ContactDetailsChange latest = buildContactDetailsChange(PARTY_ID_2, AFTER_EARLIEST_DATE);
    frontOfficeTestEntityManager.persistAndFlush(latest);
    frontOfficeTestEntityManager.clear();

    final List<String> parties = Arrays.asList(PARTY_ID_1, PARTY_ID_2);

    final Optional<ContactDetailsChange> found =
        testSubject.findLatestChangeForPartiesAfterEarliestTime(parties, EARLIEST_DATE);

    assertThat(found.isPresent(), is(true));

    assertThat(found.get(), is(samePropertyValuesAs(latest)));
  }

  private ContactDetailsChange buildContactDetailsChange(
      final String partyId, final LocalDateTime amendDate) {

    return ContactDetailsChange.builder()
        .partySysId(partyId)
        .amendDate(amendDate)
        .emailAddress("test@test.com")
        .homeTelephoneNumber("0127483838")
        .workTelephoneNumber("0789888891")
        .mobileTelephoneNumber("07890000000")
        .build();
  }
}
