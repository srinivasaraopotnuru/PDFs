package uk.co.ybs.digital.customer.integration.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFNUS;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFSUC;
import static uk.co.ybs.digital.customer.service.utilities.PostCodeHelper.formatPostcode;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildAccount;
import static uk.co.ybs.digital.customer.utils.TestHelper.postalAddressMatcher;
import static uk.co.ybs.digital.customer.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.customer.e2e.CoreHelper;
import uk.co.ybs.digital.customer.e2e.TestData;
import uk.co.ybs.digital.customer.integration.IntegrationTestConfig;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.core.ActivityPlayer;
import uk.co.ybs.digital.customer.model.core.ActivityType;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsage.AddressFunction;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.LoanAccount;
import uk.co.ybs.digital.customer.model.core.LoanPart;
import uk.co.ybs.digital.customer.model.core.LoanPartStatus;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.core.PostalAddress;
import uk.co.ybs.digital.customer.model.core.WorkEventOutput;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogRequest;
import uk.co.ybs.digital.customer.repository.core.WorkEventCoreRepositoryCustom;
import uk.co.ybs.digital.customer.repository.ldap.LdapPersonRepository;
import uk.co.ybs.digital.customer.service.CustomerProcessorService;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountGroup;
import uk.co.ybs.digital.customer.service.account.dto.Warning;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;
import uk.co.ybs.digital.customer.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressSubType;
import uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressType;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@SpringBootTest(classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
@TestPropertySource(properties = {"spring.ldap.urls="})
public class CustomerProcessorServiceIT {

  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String PARTY_ID = "1234567890";
  private static final String BRAND_CODE = "YBS";
  private static final InetSocketAddress HOST = InetSocketAddress.createUnresolved("host", 443);
  private static final UUID REQUEST_ID = UUID.fromString("3cfa397f-ff5d-4252-b8f0-69daac23fba4");

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  public static final String UPDATED_EMAIL_ADDRESS = "updated@provider.com";
  public static final String ORIGINAL_EMAIL_ADDRESS = "john.smith@gmail.com";
  private static final UUID SESSION_ID = UUID.fromString("3cfa397f-ff5d-4252-b8f0-69daac23fba4");

  private static final String ORIGINAL_HOME_ADDRESS = TestData.HOME_ADDRESS;
  private static final String ORIGINAL_WORK_ADDRESS = TestData.WORK_ADDRESS;
  private static final String ORIGINAL_MOBILE_ADDRESS = TestData.MOBILE_ADDRESS;
  public static final String ACCOUNT_WARNINGS_URI = "/account/private/accounts/%s/warnings";

  private static final String NO_RECORDS_FOUND_IN_DB =
      "No record found in party database for party id ";

  @Autowired private CustomerProcessorService customerProcessorService;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  @Value("${uk.co.ybs.digital.account-test-port}")
  private int accountTestPort;

  private MockWebServer mockAuditService;
  private MockWebServer mockAccountService;

  @Autowired private TransactionTemplate transactionTemplate;
  @Autowired private TestEntityManager coreTestEntityManager;
  @Autowired private TestEntityManager digitalCustomerTestEntityManager;
  @Autowired private LdapPersonRepository ldapPersonRepository;
  @Autowired private ObjectMapper objectMapper;
  @Autowired private Clock clock;

  public static final String POSTAL_SAVINGS_ACCOUNT_NUMBER = "1000000001";
  public static final String POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER = "1000000002";
  public static final String POSTAL_SAVINGS_ACCOUNT_PRODUCT = "POSTALSAVE";
  public static final String POSTAL_SAVINGS_ACCOUNT_MONTHLY_INTEREST_PRODUCT = "POSTSAVMIA";

  /*
   * See comment in WorkEventCoreRepositoryCustom on why a mock is being used
   */
  @MockBean private WorkEventCoreRepositoryCustom workEventCoreRepositoryCustom;

  private CoreHelper coreHelper;

  @BeforeEach
  void setup() throws Exception {
    mockAuditService = new MockWebServer();
    mockAuditService.start(auditTestPort);
    mockAccountService = new MockWebServer();
    mockAccountService.start(accountTestPort);
    coreHelper = new CoreHelper(transactionTemplate, coreTestEntityManager);
  }

  @AfterEach
  void cleanup() throws IOException {
    mockAuditService.shutdown();
    mockAccountService.shutdown();
    coreHelper.tearDownDb(digitalCustomerTestEntityManager);
  }

  @Test
  void customerProcessorShouldDoNothingWhenNoRequestsPending() {
    customerProcessorService.process();
  }

  @ParameterizedTest(
      name =
          "customerProcessorShouldRecordFailureWhenUpdateEmailAddressPartyDoesNotExist: AuditFailed={0}")
  @ValueSource(booleans = {true, false})
  void customerProcessorShouldRecordFailureWhenUpdateEmailAddressPartyDoesNotExist(
      final boolean auditFailed) {

    final Long updateEmailAddressRequestId = setupUpdateEmailAddressRequest(TestData.PARTY_ID);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    customerProcessorService.process();

    assertAll(
        () -> assertUpdateWorkLog(updateEmailAddressRequestId, WorkLog.Status.FAILED),
        () -> TestHelper.assertLdapEmailAddressValue(ldapPersonRepository, ORIGINAL_EMAIL_ADDRESS),
        () ->
            assertUpdateNonPostalFailure(
                UPDATED_EMAIL_ADDRESS,
                NO_RECORDS_FOUND_IN_DB + TestData.PARTY_ID,
                NonPostalOperation.EMAIL_ADDRESS,
                NonPostalType.EMAIL));
  }

  @ParameterizedTest(
      name =
          "customerProcessorShouldRecordFailureWhenUpdateEmailAddressLdapPartyDoesNotExist: AuditFailed={0}")
  @ValueSource(booleans = {true, false})
  void customerProcessorShouldRecordFailureWhenUpdateEmailAddressLdapPartyDoesNotExist(
      final boolean auditFailed) {

    final Long updateEmailAddressRequestId =
        setupUpdateEmailAddressRequest(TestData.PARTY_ID_NOT_ON_LDAP);

    final Party party =
        coreHelper.setupParty(TestData.PARTY_ID_NOT_ON_LDAP, EnumSet.allOf(AddressType.class));

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    customerProcessorService.process();

    // Matcher for Original Values
    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            TestHelper.addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                TestData.PARTY_CREATED_DATE,
                null,
                TestData.PARTY_CREATED_DATE,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                null,
                TestHelper.nonPostalAddressMatcher(AddressType.EMAIL, ORIGINAL_EMAIL_ADDRESS),
                anyOf(nullValue())));

    assertAll(
        () -> assertUpdateWorkLog(updateEmailAddressRequestId, WorkLog.Status.FAILED),
        () ->
            TestHelper.assertNonPostalAddressUsages(
                coreTestEntityManager,
                transactionTemplate,
                party.getSysId(),
                addressUsageMatcher,
                AddressType.EMAIL,
                null),
        () ->
            assertUpdateNonPostalFailure(
                UPDATED_EMAIL_ADDRESS,
                String.format(
                    "LdapPerson %s not found", TestData.CUSTOMER_LDAP_PERSON_UID_NOT_ON_LDAP),
                NonPostalOperation.EMAIL_ADDRESS,
                NonPostalType.EMAIL));
  }

  @ParameterizedTest(
      name =
          "customerProcessorShouldSuccessfullyProcessUpdateEmailAddressPendingRequest: AuditFailed={0}")
  @ValueSource(booleans = {true, false})
  void customerProcessorShouldSuccessfullyProcessUpdateEmailAddressPendingRequest(
      final boolean auditFailed) {

    final LocalDateTime now = LocalDateTime.now(clock);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            TestHelper.addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                now,
                null,
                now,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                false,
                null,
                TestHelper.nonPostalAddressMatcher(AddressType.EMAIL, UPDATED_EMAIL_ADDRESS),
                anyOf(nullValue())));

    customerProcessorShouldSuccessfullyProcessUpdateEmailAddressPendingRequest(
        EnumSet.of(AddressType.UKPOST, AddressType.TEL), addressUsageMatcher, auditFailed);
  }

  @ParameterizedTest(
      name =
          "customerProcessorShouldSuccessfullyProcessUpdateEmailAddressPendingRequestExistingEmailAddress: AuditFailed={0}")
  @ValueSource(booleans = {true, false})
  void
      customerProcessorShouldSuccessfullyProcessUpdateEmailAddressPendingRequestExistingEmailAddress(
          final boolean auditFailed) {
    final LocalDateTime now = LocalDateTime.now(clock);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            TestHelper.addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                TestData.PARTY_CREATED_DATE,
                now,
                TestData.PARTY_CREATED_DATE,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                now,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                null,
                TestHelper.nonPostalAddressMatcher(AddressType.EMAIL, ORIGINAL_EMAIL_ADDRESS),
                anyOf(nullValue())),
            TestHelper.addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                now,
                null,
                now,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                null,
                TestHelper.nonPostalAddressMatcher(AddressType.EMAIL, UPDATED_EMAIL_ADDRESS),
                anyOf(nullValue())));

    customerProcessorShouldSuccessfullyProcessUpdateEmailAddressPendingRequest(
        EnumSet.allOf(AddressType.class), addressUsageMatcher, auditFailed);
  }

  @ParameterizedTest
  @MethodSource("updatePhoneRequestArguments")
  void customerProcessorShouldRecordFailureWhenUpdatePhoneNumberPartyDoesNotExist(
      final UpdatePhoneRequest updatePhoneRequest, final boolean auditFailed) {

    final Long updatePhoneNumberRequestId = setupUpdatePhoneNumberRequest(updatePhoneRequest);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    customerProcessorService.process();

    final String address = formatPhoneNumber(updatePhoneRequest);

    assertAll(
        () -> assertUpdateWorkLog(updatePhoneNumberRequestId, WorkLog.Status.FAILED),
        () ->
            assertUpdateNonPostalFailure(
                address,
                NO_RECORDS_FOUND_IN_DB + TestData.PARTY_ID,
                NonPostalOperation.PHONE_NUMBER,
                NonPostalType.valueOf(updatePhoneRequest.getRequestType().toString())));
  }

  @ParameterizedTest
  @MethodSource("updatePhoneRequestArguments")
  void customerProcessorShouldProcessUpdatePhoneNumberPendingRequest(
      final UpdatePhoneRequest updatePhoneRequest, final boolean auditFailed) {

    final LocalDateTime now = LocalDateTime.now(clock);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            TestHelper.addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                now,
                null,
                now,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                false,
                null,
                updatePhoneNonPostalAddressMatcher(
                    AddressType.TEL,
                    updatePhoneRequest.getAreaDiallingCode(),
                    updatePhoneRequest.getNumber(),
                    NPASourceType.valueOf(updatePhoneRequest.getRequestType().toString())),
                anyOf(nullValue())));

    assertSuccessfulUpdatePhoneNumberPendingRequest(
        updatePhoneRequest,
        EnumSet.of(AddressType.UKPOST, AddressType.EMAIL),
        addressUsageMatcher,
        auditFailed,
        false);
  }

  @ParameterizedTest
  @MethodSource("updatePhoneRequestWithOriginalNumberArguments")
  void customerProcessorShouldProcessUpdatePhoneNumberPendingRequestWithExistingPhoneNumber(
      final UpdatePhoneRequest updatePhoneRequest,
      final String oldAddress,
      final boolean auditFailed) {

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        existingPhoneNumberMatcher(updatePhoneRequest, oldAddress);

    assertSuccessfulUpdatePhoneNumberPendingRequest(
        updatePhoneRequest,
        EnumSet.allOf(AddressType.class),
        addressUsageMatcher,
        auditFailed,
        false);
  }

  @ParameterizedTest
  @MethodSource("updatePhoneRequestWithOriginalNumberArguments")
  void
      customerProcessorShouldProcessUpdatePhoneNumberPendingRequestWithExistingPhoneNumberAndMatchingExistingNPA(
          final UpdatePhoneRequest updatePhoneRequest,
          final String oldAddress,
          final boolean auditFailed) {

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        existingPhoneNumberMatcher(updatePhoneRequest, oldAddress);

    assertSuccessfulUpdatePhoneNumberPendingRequest(
        updatePhoneRequest,
        EnumSet.allOf(AddressType.class),
        addressUsageMatcher,
        auditFailed,
        true);
  }

  @ParameterizedTest
  @MethodSource("updatePostalAddressRequestArguments")
  void customerProcessorShouldRecordFailureWhenUpdatePostalAddressPartyDoesNotExist(
      final UpdatePostalAddressRequest updatePostalAddressRequest, final boolean auditFailed) {

    final Long updatePostalAddressRequestId =
        setupUpdatePostalAddressRequest(updatePostalAddressRequest);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    customerProcessorService.process();

    assertAll(
        () -> assertUpdateWorkLog(updatePostalAddressRequestId, WorkLog.Status.FAILED),
        () ->
            assertUpdatePostalFailure(
                updatePostalAddressRequest, NO_RECORDS_FOUND_IN_DB + TestData.PARTY_ID));
  }

  @Test
  void customerProcessorShouldRecordFailureWhenUpdatingToExistingPostalAddress() {

    final Party party = coreHelper.setupParty(TestData.PARTY_ID, EnumSet.allOf(AddressType.class));

    PostalAddress postalAddress = party.getAddresses().get(0).getPostalAddress();

    UpdatePostalAddressRequest updatePostalAddressRequest =
        UpdatePostalAddressRequest.builder()
            .addressLine1(postalAddress.getLine1())
            .addressLine2(postalAddress.getLine2())
            .addressLine3(postalAddress.getLine3())
            .addressLine4(postalAddress.getLine4())
            .addressLine5(postalAddress.getLine5())
            .addressType(PostalAddressSubType.valueOf(postalAddress.getType().toString()))
            .function(PostalAddressType.CORR)
            .country(postalAddress.getCountry().getCode())
            .areaCode(postalAddress.getPostCode().getAreaCode())
            .districtCode(postalAddress.getPostCode().getDistrictCode())
            .sectorCode(postalAddress.getPostCode().getSectorCode())
            .unitCode(postalAddress.getPostCode().getUnitCode())
            .pafAddressKey(postalAddress.getPafAddressKey())
            .pafDeliveryPointSuffix(postalAddress.getPafDps())
            .build();

    final Long updatePostalAddressRequestId =
        setupUpdatePostalAddressRequest(updatePostalAddressRequest);

    mockAuditServiceResponse();

    customerProcessorService.process();

    assertAll(
        () -> assertUpdateWorkLog(updatePostalAddressRequestId, WorkLog.Status.FAILED),
        () -> assertUpdatePostalFailure(updatePostalAddressRequest, "Address not changed"));
  }

  @ParameterizedTest
  @MethodSource("updatePostalAddressRequestArguments")
  void customerProcessorShouldProcessUpdatePostalAddressPendingRequest(
      final UpdatePostalAddressRequest updatePostalAddressRequest, final boolean auditFailed)
      throws JsonProcessingException {

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(buildPostalAddressMatcher(updatePostalAddressRequest, anyOf(notNullValue())));

    stubMockAccountServiceResponseWithoutWarning();

    assertSuccessfulUpdatePostalAddressPendingRequest(
        updatePostalAddressRequest,
        EnumSet.complementOf(EnumSet.of(AddressType.UKPOST)),
        addressUsageMatcher,
        auditFailed);
  }

  @ParameterizedTest
  @MethodSource("updatePostalAddressRequestWithOriginalNumberArguments") // NOPMD
  void customerProcessorShouldProcessUpdatePostalAddressPendingRequestWithExistingPostalAddress(
      final UpdatePostalAddressRequest updatePostalAddressRequest, final boolean auditFailed)
      throws JsonProcessingException {

    stubMockAccountServiceResponseWithoutWarning();

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            buildExistingPartyPostalAddressMatcher(),
            buildPostalAddressMatcher(updatePostalAddressRequest, anyOf(notNullValue())));

    assertSuccessfulUpdatePostalAddressPendingRequest(
        updatePostalAddressRequest,
        EnumSet.allOf(AddressType.class),
        addressUsageMatcher,
        auditFailed);
  }

  @ParameterizedTest
  @MethodSource("updatePostalAddressRequestWithOriginalNumberArguments") // NOPMD
  void
      customerProcessorShouldProcessUpdatePostalAddressPendingRequestWithExistingPostalAddressAndMatchingExistingPostalAddress(
          final UpdatePostalAddressRequest updatePostalAddressRequest, final boolean auditFailed)
          throws JsonProcessingException {

    stubMockAccountServiceResponseWithoutWarning();

    PostalAddress pa = coreHelper.setupPostalAddress(updatePostalAddressRequest);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            buildExistingPartyPostalAddressMatcher(),
            buildPostalAddressMatcher(updatePostalAddressRequest, is(pa.getSysId())));

    assertSuccessfulUpdatePostalAddressPendingRequest(
        updatePostalAddressRequest,
        EnumSet.allOf(AddressType.class),
        addressUsageMatcher,
        auditFailed);
  }

  @ParameterizedTest
  @MethodSource("updatePostalAddressRequestWithOriginalNumberArguments") // NOPMD
  void customerProcessorShouldProcessUpdatePostalAddressPendingRequestWithPostalAccounts(
      final UpdatePostalAddressRequest updatePostalAddressRequest, final boolean auditFailed)
      throws JsonProcessingException, InterruptedException {

    stubMockAccountServiceResponseWithPostalAccounts();

    stubMockAccountServiceResponseWithWarnings(false); // first account - no existing CA restriction
    stubMockAccountServiceResponseWithNoContent(); // Add CA restriction to account
    stubMockAccountServiceResponseWithWarnings(
        false); // second account - no existing CA restriction
    stubMockAccountServiceResponseWithNoContent(); // Add CA restriction to account

    PostalAddress pa = coreHelper.setupPostalAddress(updatePostalAddressRequest);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            buildExistingPartyPostalAddressMatcher(),
            buildPostalAddressMatcher(updatePostalAddressRequest, is(pa.getSysId())));

    assertSuccessfulUpdatePostalAddressPendingRequest(
        updatePostalAddressRequest,
        EnumSet.allOf(AddressType.class),
        addressUsageMatcher,
        auditFailed);

    assertAccountServiceGetAccountsGrouped();

    assertAccountServiceGetWarnings(POSTAL_SAVINGS_ACCOUNT_NUMBER);
    assertAccountServicePostWarning(POSTAL_SAVINGS_ACCOUNT_NUMBER);

    assertAccountServiceGetWarnings(POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER);
    assertAccountServicePostWarning(POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER);
  }

  @ParameterizedTest
  @MethodSource("updatePostalAddressRequestWithOriginalNumberArguments") // NOPMD
  void
      customerProcessorShouldProcessUpdatePostalAddressPendingRequestWithPostalAccountsHavingExistingCAWarning(
          final UpdatePostalAddressRequest updatePostalAddressRequest, final boolean auditFailed)
          throws JsonProcessingException, InterruptedException {

    stubMockAccountServiceResponseWithPostalAccounts();

    stubMockAccountServiceResponseWithWarnings(true); // first account has CA restriction
    stubMockAccountServiceResponseWithWarnings(true); // second account has CA restriction

    PostalAddress pa = coreHelper.setupPostalAddress(updatePostalAddressRequest);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            buildExistingPartyPostalAddressMatcher(),
            buildPostalAddressMatcher(updatePostalAddressRequest, is(pa.getSysId())));

    assertSuccessfulUpdatePostalAddressPendingRequest(
        updatePostalAddressRequest,
        EnumSet.allOf(AddressType.class),
        addressUsageMatcher,
        auditFailed);

    assertAccountServiceGetAccountsGrouped();
    assertAccountServiceGetWarnings(POSTAL_SAVINGS_ACCOUNT_NUMBER);
    assertAccountServiceGetWarnings(POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER);
  }

  @ParameterizedTest
  @MethodSource("updatePostalAddressRequest")
  void customerProcessorShouldProcessUpdatePostalAddressPendingRequestWithLendingAccounts(
      final UpdatePostalAddressRequest updatePostalAddressRequest, final boolean auditFailed)
      throws JsonProcessingException {

    stubMockAccountServiceResponseWithoutWarning();

    PostalAddress pa = coreHelper.setupPostalAddress(updatePostalAddressRequest);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            buildExistingPartyPostalAddressMatcher(),
            buildPostalAddressMatcher(updatePostalAddressRequest, is(pa.getSysId())));

    setupLoanAccounts();

    final WorkEventOutput workEventOutput =
        WorkEventOutput.builder()
            .outputStatus("S")
            .param1Code("10001")
            .workEventSysId(TestData.PARTY_ID)
            .build();

    when(workEventCoreRepositoryCustom.createChcamoWorkEvent(12345678L, 80L))
        .thenReturn(workEventOutput);

    assertSuccessfulUpdatePostalAddressPendingRequest(
        updatePostalAddressRequest,
        EnumSet.allOf(AddressType.class),
        addressUsageMatcher,
        auditFailed);
  }

  @ParameterizedTest
  @MethodSource("updatePostalAddressRequest")
  void
      customerProcessorShouldProcessUpdatePostalAddressPendingRequestWithLendingAccountsWorkEventExists(
          final UpdatePostalAddressRequest updatePostalAddressRequest, final boolean auditFailed)
          throws JsonProcessingException {

    stubMockAccountServiceResponseWithoutWarning();

    PostalAddress pa = coreHelper.setupPostalAddress(updatePostalAddressRequest);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            buildExistingPartyPostalAddressMatcher(),
            buildPostalAddressMatcher(updatePostalAddressRequest, is(pa.getSysId())));

    setupLoanAccounts();

    setupWorkEvent("12345678");

    assertSuccessfulUpdatePostalAddressPendingRequest(
        updatePostalAddressRequest,
        EnumSet.allOf(AddressType.class),
        addressUsageMatcher,
        auditFailed);
  }

  private Matcher<Iterable<? extends AddressUsage>> existingPhoneNumberMatcher(
      final UpdatePhoneRequest updatePhoneRequest, final String oldAddress) {
    final LocalDateTime now = LocalDateTime.now(clock);

    return contains(
        TestHelper.addressUsageMatcher(
            AddressUsage.AddressFunction.DIRCOM,
            TestData.PARTY_CREATED_DATE,
            now,
            TestData.PARTY_CREATED_DATE,
            TestHelper.AUDIT_AT,
            TestHelper.AUDIT_BY,
            now,
            TestHelper.AUDIT_AT,
            TestHelper.AUDIT_BY,
            false,
            null,
            updatePhoneNonPostalAddressMatcher(
                AddressType.TEL,
                null,
                oldAddress,
                NPASourceType.valueOf(updatePhoneRequest.getRequestType().toString())),
            anyOf(nullValue())),
        TestHelper.addressUsageMatcher(
            AddressUsage.AddressFunction.DIRCOM,
            now,
            null,
            now,
            TestHelper.AUDIT_AT,
            TestHelper.AUDIT_BY,
            null,
            null,
            null,
            false,
            null,
            updatePhoneNonPostalAddressMatcher(
                AddressType.TEL,
                updatePhoneRequest.getAreaDiallingCode(),
                updatePhoneRequest.getNumber(),
                NPASourceType.valueOf(updatePhoneRequest.getRequestType().toString())),
            anyOf(nullValue())));
  }

  private Matcher<AddressUsage> buildPostalAddressMatcher(
      final UpdatePostalAddressRequest updatePostalAddressRequest,
      final Matcher<Long> postalAddressSysid) {
    final LocalDateTime now = LocalDateTime.now(clock);

    return TestHelper.addressUsageMatcher(
        AddressFunction.CORR,
        now,
        null,
        now,
        TestHelper.AUDIT_AT,
        TestHelper.AUDIT_BY,
        null,
        null,
        null,
        false,
        null,
        anyOf(nullValue()),
        postalAddressMatcher(
            postalAddressSysid,
            AddressType.valueOf(updatePostalAddressRequest.getAddressType().toString()),
            updatePostalAddressRequest.getAddressLine1(),
            updatePostalAddressRequest.getAddressLine2(),
            updatePostalAddressRequest.getAddressLine3(),
            updatePostalAddressRequest.getAddressLine4(),
            updatePostalAddressRequest.getAddressLine5(),
            PostCode.builder()
                .areaCode(updatePostalAddressRequest.getAreaCode())
                .districtCode(updatePostalAddressRequest.getDistrictCode())
                .unitCode(updatePostalAddressRequest.getUnitCode())
                .sectorCode(updatePostalAddressRequest.getSectorCode())
                .build(),
            Country.builder().code(updatePostalAddressRequest.getCountry()).isoCode("GB").build(),
            updatePostalAddressRequest.getPafAddressKey() == null
                ? PAF_STATUS_PAFNUS
                : PAF_STATUS_PAFSUC,
            updatePostalAddressRequest.getPafAddressKey(),
            updatePostalAddressRequest.getPafDeliveryPointSuffix(),
            updatePostalAddressRequest.getPafAddressKey() == null
                ? null
                : updatePostalAddressRequest.getAddressLine1().substring(0, 10).trim(),
            null));
  }

  private Matcher<AddressUsage> buildExistingPartyPostalAddressMatcher() {
    final LocalDateTime now = LocalDateTime.now(clock);

    return TestHelper.addressUsageMatcher(
        AddressFunction.CORR,
        TestData.PARTY_CREATED_DATE,
        now,
        TestData.PARTY_CREATED_DATE,
        TestHelper.AUDIT_AT,
        TestHelper.AUDIT_BY,
        now,
        TestHelper.AUDIT_AT,
        TestHelper.AUDIT_BY,
        false,
        null,
        anyOf(nullValue()),
        postalAddressMatcher(
            anyOf(notNullValue()),
            AddressType.UKPOST,
            "AddressLine1_1",
            "AddressLine2_1",
            null,
            "AddressLine3_1",
            null,
            PostCode.builder()
                .areaCode("PO")
                .districtCode("57")
                .sectorCode("0")
                .unitCode("DE")
                .build(),
            Country.builder().code("UK").isoCode("GB").build(),
            PAF_STATUS_PAFNUS,
            null,
            null,
            null,
            null));
  }

  private void customerProcessorShouldSuccessfullyProcessUpdateEmailAddressPendingRequest(
      final Set<AddressType> includeAddressTypes,
      final Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher,
      final boolean auditFailed) {

    final Long updateEmailAddressRequestId = setupUpdateEmailAddressRequest(TestData.PARTY_ID);

    final Party party = coreHelper.setupParty(TestData.PARTY_ID, includeAddressTypes);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    customerProcessorService.process();

    assertAll(
        () -> assertUpdateWorkLog(updateEmailAddressRequestId, WorkLog.Status.COMPLETE),
        () ->
            TestHelper.assertNonPostalAddressUsages(
                coreTestEntityManager,
                transactionTemplate,
                party.getSysId(),
                addressUsageMatcher,
                AddressType.EMAIL,
                null),
        () -> TestHelper.assertLdapEmailAddressValue(ldapPersonRepository, UPDATED_EMAIL_ADDRESS),
        () ->
            assertUpdateNonPostalSuccess(
                UPDATED_EMAIL_ADDRESS, NonPostalOperation.EMAIL_ADDRESS, NonPostalType.EMAIL));
  }

  private void assertSuccessfulUpdatePhoneNumberPendingRequest(
      final UpdatePhoneRequest updatePhoneRequest,
      final Set<AddressType> includeAddressTypes,
      final Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher,
      final boolean auditFailed,
      final boolean createMatchingNPA) {

    final Long updatePhoneNumberRequestId = setupUpdatePhoneNumberRequest(updatePhoneRequest);

    final Party party = coreHelper.setupParty(TestData.PARTY_ID, includeAddressTypes);

    if (createMatchingNPA) {
      coreHelper.setupNonPostalAddress(updatePhoneRequest);
    }

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    customerProcessorService.process();

    final String address = formatPhoneNumber(updatePhoneRequest);

    assertAll(
        () -> assertUpdateWorkLog(updatePhoneNumberRequestId, WorkLog.Status.COMPLETE),
        () ->
            TestHelper.assertNonPostalAddressUsages(
                coreTestEntityManager,
                transactionTemplate,
                party.getSysId(),
                addressUsageMatcher,
                AddressType.TEL,
                NPASourceType.valueOf(updatePhoneRequest.getRequestType().toString())),
        () ->
            assertUpdateNonPostalSuccess(
                address,
                NonPostalOperation.PHONE_NUMBER,
                NonPostalType.valueOf(updatePhoneRequest.getRequestType().toString())));
  }

  private void assertSuccessfulUpdatePostalAddressPendingRequest(
      final UpdatePostalAddressRequest updatePostalAddressRequest,
      final Set<AddressType> includeAddressTypes,
      final Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher,
      final boolean auditFailed) {

    final Long updatePostalAddressRequestId =
        setupUpdatePostalAddressRequest(updatePostalAddressRequest);

    final Party party = coreHelper.setupParty(TestData.PARTY_ID, includeAddressTypes);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    final WorkEventOutput workEventOutput =
        WorkEventOutput.builder()
            .outputStatus("S")
            .param1Code("10001")
            .workEventSysId(TestData.PARTY_ID)
            .build();

    if (updatePostalAddressRequest.getPafAddressKey() != null) {
      when(workEventCoreRepositoryCustom.createAdacusWorkEvent(TestData.PARTY_ID, 1234567890L))
          .thenReturn(workEventOutput);
    }

    customerProcessorService.process();

    assertAll(
        () -> assertUpdateWorkLog(updatePostalAddressRequestId, WorkLog.Status.COMPLETE),
        () ->
            TestHelper.assertPostalAddressUsages(
                coreTestEntityManager,
                transactionTemplate,
                party.getSysId(),
                addressUsageMatcher,
                AddressType.UKPOST),
        () -> assertUpdatePostalSuccess(updatePostalAddressRequest));
  }

  @ParameterizedTest
  @MethodSource("deletePhoneArguments")
  void customerProcessorShouldRecordFailureWhenDeletePhoneNumberPartyDoesNotExist(
      final DeletePhoneRequest deletePhoneRequest, final boolean auditFailed) {

    final Long requestId = setupDeletePhoneNumberRequest(deletePhoneRequest);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    customerProcessorService.process();
    assertAll(
        () -> assertUpdateWorkLog(requestId, WorkLog.Status.FAILED),
        () ->
            assertUpdateNonPostalFailure(
                null,
                NO_RECORDS_FOUND_IN_DB + TestData.PARTY_ID,
                NonPostalOperation.PHONE_NUMBER,
                NonPostalType.valueOf(deletePhoneRequest.getRequestType().toString())));
  }

  @ParameterizedTest
  @MethodSource("deletePhoneArguments")
  void customerProcessorShouldProcessDeletePhoneNumberPendingRequest(
      @NotNull final DeletePhoneRequest deletePhoneRequest, final boolean auditFailed) {

    final LocalDateTime now = LocalDateTime.now(clock);

    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            TestHelper.addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                TestData.PARTY_CREATED_DATE,
                now,
                TestData.PARTY_CREATED_DATE,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                now,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                false,
                null,
                deletePhoneNonPostalAddressMatcher(
                    AddressType.TEL,
                    NPASourceType.valueOf(deletePhoneRequest.getRequestType().toString())),
                anyOf(nullValue())));

    assertSuccessfulDeletePhoneNumberPendingRequest(
        deletePhoneRequest, EnumSet.of(AddressType.TEL), addressUsageMatcher, auditFailed);
  }

  private void assertSuccessfulDeletePhoneNumberPendingRequest(
      final DeletePhoneRequest deletePhoneRequest,
      final Set<AddressType> includeAddressTypes,
      final Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher,
      final boolean auditFailed) {

    final Long requestId = setupDeletePhoneNumberRequest(deletePhoneRequest);

    final Party party = coreHelper.setupParty(TestData.PARTY_ID, includeAddressTypes);

    if (auditFailed) {
      mockAuditServiceFailureResponse();
    } else {
      mockAuditServiceResponse();
    }

    customerProcessorService.process();

    assertAll(
        () -> assertUpdateWorkLog(requestId, WorkLog.Status.COMPLETE),
        () ->
            TestHelper.assertNonPostalAddressUsages(
                coreTestEntityManager,
                transactionTemplate,
                party.getSysId(),
                addressUsageMatcher,
                AddressType.TEL,
                NPASourceType.valueOf(deletePhoneRequest.getRequestType().toString())),
        () ->
            assertUpdateNonPostalSuccess(
                null,
                NonPostalOperation.PHONE_NUMBER,
                NonPostalType.valueOf(deletePhoneRequest.getRequestType().toString())));
  }

  private static Stream<Arguments> deletePhoneArguments() {
    return Stream.of(
        Arguments.of(TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.HOME), true),
        Arguments.of(TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.WORK), true),
        Arguments.of(TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.MOBILE), true),
        Arguments.of(TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.HOME), false),
        Arguments.of(TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.WORK), false),
        Arguments.of(
            TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.MOBILE), false));
  }

  private Long setupDeletePhoneNumberRequest(final DeletePhoneRequest deletePhoneRequest) {
    return transactionTemplate.execute(
        status ->
            digitalCustomerTestEntityManager.persistAndGetId(
                createWorkLog(Operation.DELETE_PHONE_NUMBER, TestData.PARTY_ID, deletePhoneRequest),
                Long.class));
  }

  private Long setupUpdateEmailAddressRequest(final Long partyId) {

    final WorkLogPayload workLogPayload = TestHelper.buildUpdateEmailPayload(UPDATED_EMAIL_ADDRESS);

    return transactionTemplate.execute(
        status ->
            digitalCustomerTestEntityManager.persistAndGetId(
                createWorkLog(WorkLog.Operation.EMAIL_ADDRESS, partyId, workLogPayload),
                Long.class));
  }

  private Long setupUpdatePhoneNumberRequest(final UpdatePhoneRequest updatePhoneRequest) {
    return transactionTemplate.execute(
        status ->
            digitalCustomerTestEntityManager.persistAndGetId(
                createWorkLog(
                    WorkLog.Operation.UPDATE_PHONE_NUMBER, TestData.PARTY_ID, updatePhoneRequest),
                Long.class));
  }

  private Long setupUpdatePostalAddressRequest(
      final UpdatePostalAddressRequest updatePostalAddressRequest) {
    return transactionTemplate.execute(
        status ->
            digitalCustomerTestEntityManager.persistAndGetId(
                createWorkLog(
                    Operation.POSTAL_ADDRESS, TestData.PARTY_ID, updatePostalAddressRequest),
                Long.class));
  }

  private static WorkLog createWorkLog(
      final WorkLog.Operation operation, final Long partyId, final WorkLogPayload workLogPayload) {
    return WorkLog.builder()
        .partyId(partyId)
        .status(WorkLog.Status.PENDING)
        .operation(operation)
        .message(
            WorkLogRequest.builder()
                .workLogPayload(workLogPayload)
                .metadata(
                    RequestMetadata.builder()
                        .requestId(REQUEST_ID)
                        .sessionId(SESSION_ID)
                        .ipAddress(IP_ADDRESS)
                        .forwardingAuth(FORWARDING_AUTH)
                        .partyId(PARTY_ID)
                        .brandCode(BRAND_CODE)
                        .host(HOST)
                        .webCustomerNumber(PARTY_ID)
                        .build())
                .build())
        .build();
  }

  private void mockAuditServiceResponse() {
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  private void mockAuditServiceFailureResponse() {
    mockAuditService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.UNAUTHORIZED.value())
            .setBody(readClassPathResource("api/auditService/response/unexpectedResponse.json")));
  }

  private void assertUpdateWorkLog(
      final long customerRequestId, final WorkLog.Status updateLogStatus) {
    final WorkLog workLog =
        transactionTemplate.execute(
            status -> digitalCustomerTestEntityManager.find(WorkLog.class, customerRequestId));
    assertThat(workLog, is(notNullValue()));
    assertThat(workLog.getStatus(), is(updateLogStatus));
  }

  private void assertUpdateNonPostalSuccess(
      final String address, final NonPostalOperation operation, final NonPostalType nonPostalType)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest("/audit/customer/non-postal/update/success");

    assertNonPostalUpdateAuditSuccess(request, address, operation, nonPostalType);
  }

  private void assertAccountServicePostWarning(final String accountNumber)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request =
        assertAccountServicePost(String.format(ACCOUNT_WARNINGS_URI, accountNumber));

    assertAccountServicePostWarning(request);
  }

  private void assertAccountServiceGetWarnings(final String accountNumber)
      throws InterruptedException {
    assertAccountServiceGet(String.format(ACCOUNT_WARNINGS_URI, accountNumber));
  }

  private void assertAccountServiceGetAccountsGrouped() throws InterruptedException {
    assertAccountServiceGet("/account/private/accounts/grouped?showClosedAccounts=true");
  }

  private void assertUpdateNonPostalFailure(
      final String address,
      final String message,
      final NonPostalOperation operation,
      final NonPostalType nonPostalType)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest("/audit/customer/non-postal/update/failure");

    assertNonPostalUpdateAuditFailure(request, address, message, operation, nonPostalType);
  }

  private void assertUpdatePostalFailure(
      final UpdatePostalAddressRequest address, final String message)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request =
        assertAuditRequest("/audit/customer/postal-address/update/failure");

    assertPostalUpdateAuditFailure(request, address, message);
  }

  private void assertUpdatePostalSuccess(final UpdatePostalAddressRequest address)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request =
        assertAuditRequest("/audit/customer/postal-address/update/success");

    assertPostalUpdateAuditSuccess(request, address);
  }

  private void assertNonPostalUpdateAuditSuccess(
      final RecordedRequest request,
      final String address,
      final NonPostalOperation operation,
      final NonPostalType nonPostalType)
      throws JsonProcessingException {
    final AuditNonPostalAddressUpdateSuccessRequest actual =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditNonPostalAddressUpdateSuccessRequest.class);

    assertThat(
        actual,
        is(
            AuditNonPostalAddressUpdateSuccessRequest.builder()
                .ipAddress(IP_ADDRESS)
                .address(address)
                .operation(operation)
                .type(nonPostalType)
                .build()));
  }

  private void assertNonPostalUpdateAuditFailure(
      final RecordedRequest request,
      final String address,
      final String message,
      final NonPostalOperation operation,
      final NonPostalType nonPostalType)
      throws JsonProcessingException {
    final AuditNonPostalAddressUpdateFailureRequest actual =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditNonPostalAddressUpdateFailureRequest.class);

    assertThat(
        actual,
        is(
            AuditNonPostalAddressUpdateFailureRequest.builder()
                .ipAddress(IP_ADDRESS)
                .address(address)
                .message(message)
                .operation(operation)
                .type(nonPostalType)
                .build()));
  }

  private void assertPostalUpdateAuditFailure(
      final RecordedRequest request, final UpdatePostalAddressRequest address, final String message)
      throws JsonProcessingException {

    String requestBody = request.getBody().readUtf8();

    final AuditPostalAddressUpdateFailureRequest actual =
        objectMapper.readValue(requestBody, AuditPostalAddressUpdateFailureRequest.class);

    assertThat(
        actual,
        is(
            AuditPostalAddressUpdateFailureRequest.builder()
                .ipAddress(IP_ADDRESS)
                .message(message)
                .postalAddressRequest(buildPostalAddressRequest(address))
                .build()));
  }

  private void assertPostalUpdateAuditSuccess(
      final RecordedRequest request, final UpdatePostalAddressRequest address)
      throws JsonProcessingException {

    String requestBody = request.getBody().readUtf8();

    final AuditPostalAddressUpdateSuccessRequest actual =
        objectMapper.readValue(requestBody, AuditPostalAddressUpdateSuccessRequest.class);

    assertThat(
        actual,
        is(
            AuditPostalAddressUpdateSuccessRequest.builder()
                .ipAddress(IP_ADDRESS)
                .postalAddressRequest(buildPostalAddressRequest(address))
                .build()));
  }

  private PostalAddressRequest buildPostalAddressRequest(final UpdatePostalAddressRequest address) {
    return PostalAddressRequest.builder()
        .address(
            uk.co.ybs.digital.customer.web.dto.PostalAddress.builder()
                .type(PostalAddressType.CORR)
                .subType(PostalAddressSubType.UKPOST)
                .addressLines(
                    Stream.of(
                            address.getAddressLine1(),
                            address.getAddressLine2(),
                            address.getAddressLine3(),
                            address.getAddressLine4(),
                            address.getAddressLine5())
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList()))
                .postCode(
                    formatPostcode(
                        address.getAreaCode(),
                        address.getDistrictCode(),
                        address.getSectorCode(),
                        address.getUnitCode()))
                .country(uk.co.ybs.digital.customer.web.dto.PermittedCountries.UNITED_KINGDOM)
                .build())
        .paf(
            uk.co.ybs.digital.customer.web.dto.PafData.builder()
                .addressKey(address.getPafAddressKey() == null ? null : address.getPafAddressKey())
                .deliveryPointSuffix(address.getPafDeliveryPointSuffix())
                .build())
        .build();
  }

  private RecordedRequest assertAuditRequest(final String path) throws InterruptedException {
    final RecordedRequest request = mockAuditService.takeRequest(1, TimeUnit.SECONDS);
    assertThat(request, is(notNullValue()));
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());
    return request;
  }

  private RecordedRequest assertAccountServicePost(final String path) throws InterruptedException {
    final RecordedRequest request = mockAccountService.takeRequest(1, TimeUnit.SECONDS);
    assertThat(request, is(notNullValue()));
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());
    return request;
  }

  private void assertAccountServiceGet(final String path) throws InterruptedException {
    final RecordedRequest request = mockAccountService.takeRequest(1, TimeUnit.SECONDS);
    assertThat(request, is(notNullValue()));
    assertThat(request.getMethod(), is("GET"));
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());
  }

  private Matcher<NonPostalAddress> updatePhoneNonPostalAddressMatcher(
      final AddressType type,
      final Integer adcCode,
      final String address,
      final NPASourceType sourceType) {
    return allOf(
        hasProperty("type", is(type)),
        hasProperty("adcCode", is(adcCode)),
        hasProperty("address", is(address)),
        hasProperty("sourceType", is(sourceType)));
  }

  private Matcher<NonPostalAddress> deletePhoneNonPostalAddressMatcher(
      final AddressType type, final NPASourceType sourceType) {
    return allOf(hasProperty("type", is(type)), hasProperty("sourceType", is(sourceType)));
  }

  private static Stream<Arguments> updatePhoneRequestArguments() {
    return Stream.of(
        Arguments.of(TestHelper.buildUpdateHomePhoneNumberPayload(), true),
        Arguments.of(TestHelper.buildUpdateMobilePhoneNumberPayload(), true),
        Arguments.of(TestHelper.buildUpdateWorkLandlinePhoneNumberPayload(), true),
        Arguments.of(TestHelper.buildUpdateWorkMobilePhoneNumberPayload(), true),
        Arguments.of(TestHelper.buildUpdateHomePhoneNumberPayload(), false),
        Arguments.of(TestHelper.buildUpdateMobilePhoneNumberPayload(), false),
        Arguments.of(TestHelper.buildUpdateWorkLandlinePhoneNumberPayload(), false),
        Arguments.of(TestHelper.buildUpdateWorkMobilePhoneNumberPayload(), false));
  }

  private static Stream<Arguments> updatePostalAddressRequestArguments() {
    return Stream.of(
        Arguments.of(TestHelper.buildUpdatePostalAddressPayload(), true),
        Arguments.of(TestHelper.buildUpdatePostalAddressPayload(), false));
  }

  private static Stream<Arguments> updatePostalAddressRequestWithOriginalNumberArguments() {
    return Stream.of(
        Arguments.of(TestHelper.buildUpdatePostalAddressPayload(), true),
        Arguments.of(TestHelper.buildUpdatePostalAddressPayload(), false));
  }

  private static Stream<Arguments> updatePostalAddressRequest() {
    return Stream.of(Arguments.of(TestHelper.buildUpdatePostalAddressPayload(), true));
  }

  private static Stream<Arguments> updatePhoneRequestWithOriginalNumberArguments() {
    return Stream.of(
        Arguments.of(TestHelper.buildUpdateHomePhoneNumberPayload(), ORIGINAL_HOME_ADDRESS, true),
        Arguments.of(
            TestHelper.buildUpdateMobilePhoneNumberPayload(), ORIGINAL_MOBILE_ADDRESS, true),
        Arguments.of(
            TestHelper.buildUpdateWorkLandlinePhoneNumberPayload(), ORIGINAL_WORK_ADDRESS, true),
        Arguments.of(
            TestHelper.buildUpdateWorkMobilePhoneNumberPayload(), ORIGINAL_WORK_ADDRESS, true),
        Arguments.of(TestHelper.buildUpdateHomePhoneNumberPayload(), ORIGINAL_HOME_ADDRESS, false),
        Arguments.of(
            TestHelper.buildUpdateMobilePhoneNumberPayload(), ORIGINAL_MOBILE_ADDRESS, false),
        Arguments.of(
            TestHelper.buildUpdateWorkLandlinePhoneNumberPayload(), ORIGINAL_WORK_ADDRESS, false),
        Arguments.of(
            TestHelper.buildUpdateWorkMobilePhoneNumberPayload(), ORIGINAL_WORK_ADDRESS, false));
  }

  private static String formatPhoneNumber(final UpdatePhoneRequest workLogPayload) {

    return workLogPayload.getAreaDiallingCode() == null
        ? workLogPayload.getNumber()
        : "0" + workLogPayload.getAreaDiallingCode() + workLogPayload.getNumber();
  }

  private void stubMockAccountServiceResponseWithoutWarning() throws JsonProcessingException {

    String groupedInfo = objectMapper.writeValueAsString(buildAccountGroupedInfo());

    mockAccountService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(groupedInfo));
  }

  private void stubMockAccountServiceResponseWithPostalAccounts() throws JsonProcessingException {

    AccountGroupedInfo accountGroupedInfo =
        AccountGroupedInfo.builder()
            .owned(
                AccountGroup.builder()
                    .account(
                        buildAccount(POSTAL_SAVINGS_ACCOUNT_NUMBER, POSTAL_SAVINGS_ACCOUNT_PRODUCT))
                    .account(
                        buildAccount(
                            POSTAL_SAVINGS_MONTHLY_INTEREST_ACCOUNT_NUMBER,
                            POSTAL_SAVINGS_ACCOUNT_MONTHLY_INTEREST_PRODUCT))
                    .build())
            .build();

    String groupedInfo = objectMapper.writeValueAsString(accountGroupedInfo);

    mockAccountService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(groupedInfo));
  }

  private void stubMockAccountServiceResponseWithWarnings(final boolean includeCAWarning)
      throws JsonProcessingException {

    List<Warning> warnings =
        Arrays.asList(
            Warning.builder().code("XX").build(),
            Warning.builder().code(includeCAWarning ? "CA" : "ZZ").build());

    String warningJson = objectMapper.writeValueAsString(warnings);

    mockAccountService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(warningJson));
  }

  private void stubMockAccountServiceResponseWithNoContent() {

    mockAccountService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  private static AccountGroupedInfo buildAccountGroupedInfo() {
    return AccountGroupedInfo.builder()
        .owned(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccountSummary()))
                .build())
        .build();
  }

  private static AccountGroupedInfo.AccountSummary buildAccountSummary() {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber("1234567890")
        .accountName("Test")
        .amendmentRestriction(false)
        .accountSortCode("123456")
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .currency("GBP")
        .productIdentifier("test")
        .productDescription("Monthly Regular Saver: Issue 2")
        .balances(
            Collections.singletonList(
                AccountGroupedInfo.Balance.builder()
                    .type("InterimAvailable")
                    .amount(new BigDecimal("100.00"))
                    .build()))
        .build();
  }

  private void assertAccountServicePostWarning(final RecordedRequest request)
      throws JsonProcessingException {
    final Warning actual = objectMapper.readValue(request.getBody().readUtf8(), Warning.class);

    assertThat(actual, is(Warning.builder().code("CA").build()));
  }

  private void setupLoanAccounts() {

    final Integer loanAccountPartNum = 1;
    final String tableId = "ACCGRP";
    final Long partyId = 123456L;
    final String brandCode = "YBS";
    final String loanPartTypeCode = "MAIN";
    final String openStatusCode = "OPEN";
    final String activityTypeCode = "MHLDRM";
    final LocalDateTime now = LocalDateTime.parse("2020-05-25T10:15:30");
    final Long loanAccountNumber = 12345678L;
    final Integer loanAccountTypeCode = 80;

    transactionTemplate.executeWithoutResult(
        status -> {
          final ActivityType typeOne =
              coreTestEntityManager.persistAndFlush(
                  ActivityType.builder().code(activityTypeCode).startDate(now).build());
          final ActivityPlayer activityPlayerOne =
              ActivityPlayer.builder()
                  .sysId(1L)
                  .tableId(tableId)
                  .activityType(typeOne)
                  .tableSysId(loanAccountNumber)
                  .partySysId(partyId)
                  .startDate(now)
                  .build();

          final LoanAccount loanAccount =
              LoanAccount.builder()
                  .accountNumber(loanAccountNumber)
                  .loanAccountTypeCode(loanAccountTypeCode)
                  .brandCode(brandCode)
                  .build();

          final LoanPart loanPart =
              LoanPart.builder()
                  .loanAccountNumber(loanAccountNumber)
                  .loanAccountTypeCode(loanAccountTypeCode)
                  .partNumber(loanAccountPartNum)
                  .loanPartTypeCode(loanPartTypeCode)
                  .startDate(now)
                  .loanAccount(loanAccount)
                  .build();

          final LoanPartStatus loanPartStatus =
              LoanPartStatus.builder()
                  .loanPartAccountNumber(loanAccountNumber)
                  .loanPartAccountTypeCode(loanAccountTypeCode)
                  .loanPartNumber(loanAccountPartNum)
                  .startDate(now)
                  .statusCode(openStatusCode)
                  .parts(loanPart)
                  .build();

          coreTestEntityManager.persistAndFlush(loanAccount);
          coreTestEntityManager.persistAndFlush(loanPart);
          coreTestEntityManager.persistAndFlush(loanPartStatus);
          coreTestEntityManager.persistAndFlush(activityPlayerOne);

          coreTestEntityManager.clear();
        });
  }

  private void setupWorkEvent(final String accountNumber) {
    transactionTemplate.executeWithoutResult(
        status -> {
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  "insert into module_details (SYSID, SHORT_NAME) values (10872, 'CUS0503U')")
              .executeUpdate();
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  "insert into module_label_associations (SYSID, START_DATE, END_DATE, MODLAB_NAME, MODLAB_MDD_SYSID, WET_NAME, WET_INTORG_PARTY_SYSID, MLA_TYPE) values (25980, to_date('15-04-2008', 'dd-mm-yyyy'), null, 'CHCAMO', 10872, 'CHCAMO', 620491, 'CREEVT')")
              .executeUpdate();

          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  String.format(
                      "insert into work_events (SYSID, STATUS, WET_NAME, WET_INTORG_PARTY_SYSID, CNTXT_TABLE_ID, CNTXT_SYSID1, CNTXT_SYSID2) values (29318192,'TODO', 'CHCAMO', 620491, 'LOANAC', '%s', 80)",
                      accountNumber))
              .executeUpdate();
        });
  }
}
