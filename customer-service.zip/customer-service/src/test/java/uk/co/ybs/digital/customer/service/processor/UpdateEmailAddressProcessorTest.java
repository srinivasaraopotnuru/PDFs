package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ldap.CommunicationException;
import org.springframework.ldap.NamingException;
import uk.co.ybs.digital.customer.e2e.TestData;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.AddressUsageFunction;
import uk.co.ybs.digital.customer.model.core.LinkedParty;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.ldap.LdapPerson;
import uk.co.ybs.digital.customer.repository.core.PartyCoreRepository;
import uk.co.ybs.digital.customer.repository.ldap.LdapPersonRepository;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateSuccessRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class UpdateEmailAddressProcessorTest {

  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final String CUSTOMER_LDAP_PERSON_UID = "0000123456";
  private static final long LINKED_PARTY_ID = 100000L;
  private static final long PARTY_ID = 123456L;
  private static final String UPDATED_EMAIL_ADDRESS = "updated@provider.com";
  private static final String EMAIL_ADDRESS = "john.smith@gmail..com";

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-09-01T00:00:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);

  public static final LocalDateTime YESTERDAY = NOW.minusDays(1);

  @Mock private AuditService auditService;

  @Mock private PartyCoreRepository partyCoreRepository;

  @Mock private LdapPersonRepository ldapPersonRepository;

  @InjectMocks private UpdateEmailAddressProcessor testSubject;

  @Captor private ArgumentCaptor<Party> savedParty;

  @Test
  void resolveShouldReturnParty() {

    final UpdateEmailAddressRequestArguments arguments =
        new UpdateEmailAddressRequestArguments(
            PARTY_ID, TestHelper.createRequestMetadata(), PROCESS_TIME, UPDATED_EMAIL_ADDRESS);

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(TestHelper.buildEmailAddress(EMAIL_ADDRESS)));

    final LinkedParty linkedParty = stubLinkedParty(PARTY_ID, LINKED_PARTY_ID);

    when(partyCoreRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(linkedParty.getCanonicalPartyId()),
            eq(Collections.singleton(AddressType.EMAIL)),
            eq(EnumSet.allOf(AddressUsage.AddressFunction.class)),
            eq(PROCESS_TIME)))
        .thenReturn(Optional.of(party));

    final Party resolvedParty = testSubject.resolve(arguments);

    assertThat(resolvedParty, is(party));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @Test
  void resolveShouldCustomerNotFoundExceptionWhenCoreRepositoryReturnsEmptyLinkParty() {
    final UpdateEmailAddressRequestArguments arguments =
        new UpdateEmailAddressRequestArguments(
            PARTY_ID, TestHelper.createRequestMetadata(), PROCESS_TIME, UPDATED_EMAIL_ADDRESS);

    when(partyCoreRepository.findCanonicalPartyId(PARTY_ID)).thenReturn(Optional.empty());

    final CustomerNotFoundException exception =
        assertThrows(CustomerNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("No record found in party database for party id 123456"));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @Test
  void resolveShouldCustomerNotFoundExceptionWhenCoreRepositoryReturnsEmpty() {
    final UpdateEmailAddressRequestArguments arguments =
        new UpdateEmailAddressRequestArguments(
            PARTY_ID, TestHelper.createRequestMetadata(), PROCESS_TIME, UPDATED_EMAIL_ADDRESS);

    stubLinkedParty(PARTY_ID, LINKED_PARTY_ID);

    when(partyCoreRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(LINKED_PARTY_ID),
            eq(Collections.singleton(AddressType.EMAIL)),
            eq(EnumSet.allOf(AddressUsage.AddressFunction.class)),
            eq(PROCESS_TIME)))
        .thenReturn(Optional.empty());

    final CustomerNotFoundException exception =
        assertThrows(CustomerNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(exception.getMessage(), is("No record found in party database for party id 123456"));
    verifyNoMoreInteractions(partyCoreRepository);
    verifyNoInteractions(auditService);
  }

  @Test
  void executeShouldEndOldEmailAddressAndCreateNewEmailAddress() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(TestHelper.buildEmailAddress(EMAIL_ADDRESS)));

    final LdapPerson ldapPerson = TestHelper.buildLdapPerson();

    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID))
        .thenReturn(Optional.of(ldapPerson));

    testSubject.execute(
        new UpdateEmailAddressRequestArguments(
            PARTY_ID, requestMetadata, PROCESS_TIME, UPDATED_EMAIL_ADDRESS),
        party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                nonPostalAddressMatcher(AddressType.EMAIL, EMAIL_ADDRESS)),
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                PROCESS_TIME,
                null,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                nonPostalAddressMatcher(AddressType.EMAIL, UPDATED_EMAIL_ADDRESS))));

    LdapPerson expectedSavedLdapPerson =
        ldapPerson.toBuilder().emailAddress(UPDATED_EMAIL_ADDRESS).build();

    verify(ldapPersonRepository).save(expectedSavedLdapPerson);
  }

  @Test
  void executeShouldEndMultipleOldEmailAddressAndCreateNewEmailAddress() {
    // Although an account should only ever have a single active email address we have a data
    // quality
    // issue where multiple can exist.  In this case both should be ended and the new email address
    // created.
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party = buildFullCustomerRecordMultipleActiveEmails();

    final LdapPerson ldapPerson = TestHelper.buildLdapPerson();

    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID))
        .thenReturn(Optional.of(ldapPerson));

    testSubject.execute(
        new UpdateEmailAddressRequestArguments(
            PARTY_ID, requestMetadata, PROCESS_TIME, UPDATED_EMAIL_ADDRESS),
        party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                nonPostalAddressMatcher(AddressType.EMAIL, EMAIL_ADDRESS)),
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                YESTERDAY,
                PROCESS_TIME,
                YESTERDAY,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                true,
                nonPostalAddressMatcher(AddressType.EMAIL, "john.smith@hotmail.com")),
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                PROCESS_TIME,
                null,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                nonPostalAddressMatcher(AddressType.EMAIL, UPDATED_EMAIL_ADDRESS))));

    LdapPerson expectedSavedLdapPerson =
        ldapPerson.toBuilder().emailAddress(UPDATED_EMAIL_ADDRESS).build();

    verify(ldapPersonRepository).save(expectedSavedLdapPerson);
  }

  @Test
  void executeShouldThrowCustomerServiceExceptionIfCustomerNotOnLdap() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(TestHelper.buildEmailAddress(EMAIL_ADDRESS)));

    final CustomerServiceException exception =
        assertThrows(
            CustomerServiceException.class,
            () ->
                testSubject.execute(
                    new UpdateEmailAddressRequestArguments(
                        PARTY_ID, requestMetadata, PROCESS_TIME, UPDATED_EMAIL_ADDRESS),
                    party));

    assertThat(
        exception.getMessage(),
        is(String.format("LdapPerson %s not found", CUSTOMER_LDAP_PERSON_UID)));

    verify(ldapPersonRepository, never()).save(any());
  }

  @Test
  void executeShouldThrowCustomerServiceExceptionIfLdapNamingException() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(TestHelper.buildEmailAddress(EMAIL_ADDRESS)));

    NamingException namingException =
        new CommunicationException(new javax.naming.CommunicationException("Error"));

    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID)).thenThrow(namingException);

    final CustomerServiceException exception =
        assertThrows(
            CustomerServiceException.class,
            () ->
                testSubject.execute(
                    new UpdateEmailAddressRequestArguments(
                        PARTY_ID, requestMetadata, PROCESS_TIME, UPDATED_EMAIL_ADDRESS),
                    party));

    assertThat(
        exception.getMessage(),
        is(String.format("Error calling LDAP for LdapPerson %s", CUSTOMER_LDAP_PERSON_UID)));

    verify(ldapPersonRepository, never()).save(any());
  }

  @Test
  void executeShouldCreateNewEmailAddress() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(TestHelper.buildEmailAddress(EMAIL_ADDRESS)));
    party.getAddresses().clear(); // Remove any existing email addresses

    final LdapPerson ldapPerson = TestHelper.buildLdapPerson();

    when(ldapPersonRepository.findByUid(CUSTOMER_LDAP_PERSON_UID))
        .thenReturn(Optional.of(ldapPerson));

    testSubject.execute(
        new UpdateEmailAddressRequestArguments(
            PARTY_ID, requestMetadata, PROCESS_TIME, UPDATED_EMAIL_ADDRESS),
        party);

    verify(partyCoreRepository).saveAndFlush(savedParty.capture());

    Party actualSavedParty = savedParty.getValue();

    assertThat(
        actualSavedParty.getAddresses(),
        contains(
            addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                PROCESS_TIME,
                null,
                PROCESS_TIME,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                false,
                nonPostalAddressMatcher(AddressType.EMAIL, UPDATED_EMAIL_ADDRESS))));

    LdapPerson expectedSavedLdapPerson =
        ldapPerson.toBuilder().emailAddress(UPDATED_EMAIL_ADDRESS).build();

    verify(ldapPersonRepository).save(expectedSavedLdapPerson);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private Matcher<AddressUsage> addressUsageMatcher(
      final AddressUsage.AddressFunction function,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final LocalDateTime createdDate,
      final String createdAt,
      final String createdBy,
      final LocalDateTime endedDate,
      final String endedAt,
      final String endedBy,
      final boolean preferredContactMethod,
      final Matcher<NonPostalAddress> nonPostalAddress) {
    Matcher<AddressUsageFunction> addressUsageFunction =
        addressUsageFunctionMatcher(startDate, endDate);
    return allOf(
        hasProperty("function", is(function)),
        hasProperty("startDate", is(startDate)),
        hasProperty("endDate", is(endDate)),
        hasProperty("createdDate", is(createdDate)),
        hasProperty("createdAt", is(createdAt)),
        hasProperty("createdBy", is(createdBy)),
        hasProperty("endedDate", is(endedDate)),
        hasProperty("endedAt", is(endedAt)),
        hasProperty("endedBy", is(endedBy)),
        hasProperty("preferredContactMethod", is(preferredContactMethod)),
        hasProperty("nonPostalAddress", nonPostalAddress),
        hasProperty("functions", contains(addressUsageFunction)));
  }

  private Matcher<NonPostalAddress> nonPostalAddressMatcher(
      final AddressType type, final String address) {
    return allOf(hasProperty("type", is(type)), hasProperty("address", is(address)));
  }

  private Matcher<AddressUsageFunction> addressUsageFunctionMatcher(
      final LocalDateTime startDate, final LocalDateTime endDate) {

    Matcher<AddressUsageFunction.AddressUsageFunctionPK> addressUsageFunctionPK =
        addressUsageFunctionPKMatcher(startDate);

    return allOf(
        hasProperty("id", is(addressUsageFunctionPK)), hasProperty("endDate", is(endDate)));
  }

  private Matcher<AddressUsageFunction.AddressUsageFunctionPK> addressUsageFunctionPKMatcher(
      final LocalDateTime startDate) {

    return allOf(hasProperty("startDate", is(startDate)));
  }

  @Test
  void auditSuccessShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    testSubject.auditSuccess(
        new UpdateEmailAddressRequestArguments(
            PARTY_ID, requestMetadata, PROCESS_TIME, UPDATED_EMAIL_ADDRESS));

    final AuditNonPostalAddressUpdateSuccessRequest auditRequest =
        AuditNonPostalAddressUpdateSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .address(UPDATED_EMAIL_ADDRESS)
            .operation(NonPostalOperation.EMAIL_ADDRESS)
            .type(NonPostalType.EMAIL)
            .build();

    verify(auditService).auditNonPostalAddressUpdateSuccess(auditRequest, requestMetadata);
  }

  @Test
  void auditFailureShouldCallAuditService() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    testSubject.auditFailure(
        new UpdateEmailAddressRequestArguments(
            PARTY_ID, requestMetadata, PROCESS_TIME, UPDATED_EMAIL_ADDRESS),
        TestHelper.TECHNICAL_FAILURE_MESSAGE);

    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        AuditNonPostalAddressUpdateFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(TestHelper.TECHNICAL_FAILURE_MESSAGE)
            .address(UPDATED_EMAIL_ADDRESS)
            .operation(NonPostalOperation.EMAIL_ADDRESS)
            .type(NonPostalType.EMAIL)
            .build();

    verify(auditService).auditNonPostalAddressUpdateFailure(auditRequest, requestMetadata);
  }

  private Party buildFullCustomerRecordMultipleActiveEmails() {

    List<AddressUsage> au =
        new ArrayList<>(
            Arrays.asList(
                AddressUsage.builder()
                    .nonPostalAddress(TestHelper.buildEmailAddress(EMAIL_ADDRESS))
                    .function(AddressUsage.AddressFunction.DIRCOM)
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .createdAt(TestData.CREATED_AT)
                    .createdBy(TestData.CREATED_BY)
                    .preferredContactMethod(true)
                    .function(
                        AddressUsageFunction.builder()
                            .id(
                                AddressUsageFunction.AddressUsageFunctionPK.builder()
                                    .function(AddressUsage.AddressFunction.DIRCOM)
                                    .startDate(YESTERDAY)
                                    .build())
                            .build())
                    .build(),
                AddressUsage.builder()
                    .nonPostalAddress(TestHelper.buildEmailAddress("john.smith@hotmail.com"))
                    .function(AddressUsage.AddressFunction.DIRCOM)
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .createdAt(TestData.CREATED_AT)
                    .createdBy(TestData.CREATED_BY)
                    .preferredContactMethod(true)
                    .function(
                        AddressUsageFunction.builder()
                            .id(
                                AddressUsageFunction.AddressUsageFunctionPK.builder()
                                    .function(AddressUsage.AddressFunction.DIRCOM)
                                    .startDate(YESTERDAY)
                                    .build())
                            .build())
                    .build()));

    Party party = Party.builder().sysId(1L).partyType(TestHelper.buildPartyType()).build();
    party.setAddresses(au);
    return party;
  }

  private LinkedParty stubLinkedParty(final Long originalPartyId, final Long canonicalPartyId) {

    final LinkedParty linkedParty =
        LinkedParty.builder()
            .originalPartyId(originalPartyId)
            .canonicalPartyId(canonicalPartyId)
            .linkCount(1L)
            .build();

    when(partyCoreRepository.findCanonicalPartyId(originalPartyId))
        .thenReturn(Optional.of(linkedParty));

    return linkedParty;
  }
}
