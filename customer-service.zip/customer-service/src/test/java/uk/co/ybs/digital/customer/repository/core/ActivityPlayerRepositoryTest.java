package uk.co.ybs.digital.customer.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.customer.model.core.ActivityPlayer;
import uk.co.ybs.digital.customer.model.core.ActivityType;
import uk.co.ybs.digital.customer.model.core.LoanAccount;
import uk.co.ybs.digital.customer.model.core.LoanPart;
import uk.co.ybs.digital.customer.model.core.LoanPartStatus;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
@TestPropertySource(properties = {"spring.ldap.urls="})
@Transactional("customerProcessorTransactionManager")
public class ActivityPlayerRepositoryTest {

  @Autowired ActivityPlayerRepository testSubject;

  @Autowired TestEntityManager coreTestEntityManager;

  private static final Long LOAN_ACCOUNT_NUMBER = 12345678L;
  private static final Integer LOAN_ACCOUNT_TYPE_CODE = 80;
  private static final Integer LOAN_ACCOUNT_PART_NUM = 1;
  private static final String TABLE_ID = "ACCGRP";
  private static final Long PARTY_ID = 123456L;
  private static final String BRAND_CODE = "YBS";
  private static final String LOAN_PART_TYPE_CODE = "MAIN";
  private static final String OPEN_STATUS_CODE = "OPEN";
  private static final String MHLDRM_ACTTYP_CODE = "MHLDRM";
  private static final String OHLDRM_ACTTYP_CODE = "OHLDRM";
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");
  private static final LocalDateTime NOW_MINUS_ONE = NOW.minusSeconds(1L);
  private static final LocalDateTime NOW_PLUS_ONE = NOW.plusSeconds(1L);

  @Test
  void shouldFindById() {
    final ActivityType type =
        coreTestEntityManager.persistAndFlush(
            ActivityType.builder().code(MHLDRM_ACTTYP_CODE).build());
    final ActivityPlayer npa =
        ActivityPlayer.builder()
            .sysId(1L)
            .tableId(TABLE_ID)
            .activityType(type)
            .tableSysId(LOAN_ACCOUNT_NUMBER)
            .partySysId(PARTY_ID)
            .startDate(NOW)
            .build();

    final ActivityPlayer apStored = coreTestEntityManager.persistAndFlush(npa);
    coreTestEntityManager.clear();

    final Optional<ActivityPlayer> found = testSubject.findById(apStored.getSysId());

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(apStored));
  }

  @Test
  void shouldNotFindById() {
    final ActivityType type =
        coreTestEntityManager.persistAndFlush(
            ActivityType.builder().code(MHLDRM_ACTTYP_CODE).build());
    final ActivityPlayer npa =
        ActivityPlayer.builder()
            .sysId(1L)
            .tableId(TABLE_ID)
            .activityType(type)
            .tableSysId(LOAN_ACCOUNT_NUMBER)
            .partySysId(PARTY_ID)
            .startDate(NOW)
            .build();

    coreTestEntityManager.persistAndFlush(npa);
    coreTestEntityManager.clear();

    final Optional<ActivityPlayer> found = testSubject.findById(2L);

    assertThat(found.isPresent(), is(false));
  }

  @Test
  void shouldReturnMultipleLoanAccounts() {
    final ActivityType typeOne =
        coreTestEntityManager.persistAndFlush(
            ActivityType.builder().code(MHLDRM_ACTTYP_CODE).startDate(NOW).build());
    final ActivityPlayer activityPlayerOne =
        ActivityPlayer.builder()
            .sysId(1L)
            .tableId(TABLE_ID)
            .activityType(typeOne)
            .tableSysId(LOAN_ACCOUNT_NUMBER)
            .partySysId(PARTY_ID)
            .startDate(NOW)
            .build();

    final LoanAccount loanAccount =
        LoanAccount.builder()
            .accountNumber(LOAN_ACCOUNT_NUMBER)
            .loanAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .brandCode(BRAND_CODE)
            .build();

    final LoanPart loanPart =
        LoanPart.builder()
            .loanAccountNumber(LOAN_ACCOUNT_NUMBER)
            .loanAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .partNumber(LOAN_ACCOUNT_PART_NUM)
            .loanPartTypeCode(LOAN_PART_TYPE_CODE)
            .startDate(NOW)
            .loanAccount(loanAccount)
            .build();

    final LoanPartStatus loanPartStatus =
        LoanPartStatus.builder()
            .loanPartAccountNumber(LOAN_ACCOUNT_NUMBER)
            .loanPartAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .loanPartNumber(LOAN_ACCOUNT_PART_NUM)
            .startDate(NOW)
            .statusCode(OPEN_STATUS_CODE)
            .parts(loanPart)
            .build();

    // Setup second account
    final Long accountNumberTwo = 87654321L;

    final ActivityType typeTwo =
        coreTestEntityManager.persistAndFlush(
            ActivityType.builder().code(OHLDRM_ACTTYP_CODE).startDate(NOW).build());

    final ActivityPlayer activityPlayerTwo =
        ActivityPlayer.builder()
            .sysId(2L)
            .tableId(TABLE_ID)
            .activityType(typeTwo)
            .tableSysId(accountNumberTwo)
            .partySysId(PARTY_ID)
            .startDate(NOW)
            .build();

    final LoanAccount loanAccountTwo =
        LoanAccount.builder()
            .accountNumber(accountNumberTwo)
            .loanAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .brandCode(BRAND_CODE)
            .build();

    final LoanPart loanPartTwo =
        LoanPart.builder()
            .loanAccountNumber(accountNumberTwo)
            .loanAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .partNumber(LOAN_ACCOUNT_PART_NUM)
            .loanPartTypeCode(LOAN_PART_TYPE_CODE)
            .startDate(NOW)
            .loanAccount(loanAccount)
            .build();

    final LoanPartStatus loanPartStatusTwo =
        LoanPartStatus.builder()
            .loanPartAccountNumber(accountNumberTwo)
            .loanPartAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .loanPartNumber(LOAN_ACCOUNT_PART_NUM)
            .startDate(NOW)
            .statusCode(OPEN_STATUS_CODE)
            .parts(loanPart)
            .build();

    coreTestEntityManager.persistAndFlush(loanAccount);
    coreTestEntityManager.persistAndFlush(loanPart);
    coreTestEntityManager.persistAndFlush(loanPartStatus);
    coreTestEntityManager.persistAndFlush(loanAccountTwo);
    coreTestEntityManager.persistAndFlush(loanPartTwo);
    coreTestEntityManager.persistAndFlush(loanPartStatusTwo);

    coreTestEntityManager.persistAndFlush(activityPlayerOne);
    coreTestEntityManager.persistAndFlush(activityPlayerTwo);
    coreTestEntityManager.clear();

    final List<ActivityPlayer> found = testSubject.findLendingAccountsForParty(PARTY_ID, NOW);

    assertThat(found.isEmpty(), is(false));
    assertThat(found.size(), is(2));
    assertThat(found.containsAll(Arrays.asList(activityPlayerOne, activityPlayerTwo)), is(true));
  }

  @ParameterizedTest
  @MethodSource("setupDataArguments")
  void lookForAccountsWithVariousData(
      final String activityTypeCode,
      final String tableId,
      final String loanPartTypeCode,
      final String loanPartStatusCode,
      final boolean expected) {
    final ActivityType type =
        coreTestEntityManager.persistAndFlush(
            ActivityType.builder().code(activityTypeCode).startDate(NOW).build());
    final ActivityPlayer activityPlayer =
        ActivityPlayer.builder()
            .sysId(1L)
            .tableId(tableId)
            .activityType(type)
            .tableSysId(LOAN_ACCOUNT_NUMBER)
            .partySysId(PARTY_ID)
            .startDate(NOW)
            .build();

    final LoanAccount loanAccount =
        LoanAccount.builder()
            .accountNumber(LOAN_ACCOUNT_NUMBER)
            .loanAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .brandCode(BRAND_CODE)
            .build();

    final LoanPart loanPart =
        LoanPart.builder()
            .loanAccountNumber(LOAN_ACCOUNT_NUMBER)
            .loanAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .partNumber(LOAN_ACCOUNT_PART_NUM)
            .loanPartTypeCode(loanPartTypeCode)
            .startDate(NOW)
            .loanAccount(loanAccount)
            .build();

    final LoanPartStatus loanPartStatus =
        LoanPartStatus.builder()
            .loanPartAccountNumber(LOAN_ACCOUNT_NUMBER)
            .loanPartAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .loanPartNumber(LOAN_ACCOUNT_PART_NUM)
            .startDate(NOW)
            .statusCode(loanPartStatusCode)
            .parts(loanPart)
            .build();

    coreTestEntityManager.persistAndFlush(loanAccount);
    coreTestEntityManager.persistAndFlush(loanPart);
    coreTestEntityManager.persistAndFlush(loanPartStatus);

    coreTestEntityManager.persistAndFlush(activityPlayer);
    coreTestEntityManager.clear();

    final List<ActivityPlayer> found = testSubject.findLendingAccountsForParty(PARTY_ID, NOW);

    assertThat(!found.isEmpty(), is(expected));

    if (expected) {
      assertThat(found.get(0), samePropertyValuesAs(activityPlayer));
    }
  }

  @ParameterizedTest
  @MethodSource("partyArguments")
  void lookForAccountsBasedOnRepositoryParams(
      final Long partyId, final LocalDateTime now, final boolean expected) {
    final ActivityType type =
        coreTestEntityManager.persistAndFlush(
            ActivityType.builder().code(MHLDRM_ACTTYP_CODE).startDate(NOW).build());
    final ActivityPlayer activityPlayer =
        ActivityPlayer.builder()
            .sysId(1L)
            .tableId(TABLE_ID)
            .activityType(type)
            .tableSysId(LOAN_ACCOUNT_NUMBER)
            .partySysId(PARTY_ID)
            .startDate(NOW)
            .build();

    final LoanAccount loanAccount =
        LoanAccount.builder()
            .accountNumber(LOAN_ACCOUNT_NUMBER)
            .loanAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .brandCode(BRAND_CODE)
            .build();

    final LoanPart loanPart =
        LoanPart.builder()
            .loanAccountNumber(LOAN_ACCOUNT_NUMBER)
            .loanAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .partNumber(LOAN_ACCOUNT_PART_NUM)
            .loanPartTypeCode(LOAN_PART_TYPE_CODE)
            .startDate(NOW)
            .loanAccount(loanAccount)
            .build();

    final LoanPartStatus loanPartStatus =
        LoanPartStatus.builder()
            .loanPartAccountNumber(LOAN_ACCOUNT_NUMBER)
            .loanPartAccountTypeCode(LOAN_ACCOUNT_TYPE_CODE)
            .loanPartNumber(LOAN_ACCOUNT_PART_NUM)
            .startDate(NOW)
            .statusCode(OPEN_STATUS_CODE)
            .parts(loanPart)
            .build();

    coreTestEntityManager.persistAndFlush(loanAccount);
    coreTestEntityManager.persistAndFlush(loanPart);
    coreTestEntityManager.persistAndFlush(loanPartStatus);

    coreTestEntityManager.persistAndFlush(activityPlayer);
    coreTestEntityManager.clear();

    final List<ActivityPlayer> found = testSubject.findLendingAccountsForParty(partyId, now);

    assertThat(!found.isEmpty(), is(expected));

    if (expected) {
      assertThat(found.get(0), samePropertyValuesAs(activityPlayer));
    }
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> setupDataArguments() {
    return Stream.of(
        Arguments.of(OHLDRM_ACTTYP_CODE, TABLE_ID, LOAN_PART_TYPE_CODE, OPEN_STATUS_CODE, true),
        Arguments.of(OHLDRM_ACTTYP_CODE, TABLE_ID, "OTHER", OPEN_STATUS_CODE, false),
        Arguments.of(OHLDRM_ACTTYP_CODE, TABLE_ID, LOAN_PART_TYPE_CODE, "SHFALL", false),
        Arguments.of("TRUSTE", TABLE_ID, LOAN_PART_TYPE_CODE, OPEN_STATUS_CODE, false),
        Arguments.of(OHLDRM_ACTTYP_CODE, TABLE_ID, "OTHER", "SHFALL", false),
        Arguments.of(OHLDRM_ACTTYP_CODE, "LOANAC", LOAN_PART_TYPE_CODE, OPEN_STATUS_CODE, false),
        Arguments.of(MHLDRM_ACTTYP_CODE, "LOANAC", LOAN_PART_TYPE_CODE, OPEN_STATUS_CODE, false),
        Arguments.of(MHLDRM_ACTTYP_CODE, TABLE_ID, "OTHER", OPEN_STATUS_CODE, false),
        Arguments.of(MHLDRM_ACTTYP_CODE, TABLE_ID, LOAN_PART_TYPE_CODE, "SHFALL", false),
        Arguments.of("TRUSTE", "LOANAC", LOAN_PART_TYPE_CODE, "OPEN", false),
        Arguments.of(MHLDRM_ACTTYP_CODE, "LOANAC", "OTHER", "SHFALL", false));
  }

  private static Stream<Arguments> partyArguments() {
    return Stream.of(
        Arguments.of(PARTY_ID, NOW, true),
        Arguments.of(PARTY_ID, NOW_PLUS_ONE, true),
        Arguments.of(PARTY_ID, NOW_MINUS_ONE, false),
        Arguments.of(654321L, NOW, false),
        Arguments.of(654321L, NOW_PLUS_ONE, false),
        Arguments.of(654321L, NOW_MINUS_ONE, false));
  }
}
