package uk.co.ybs.digital.customer.service.shareplan;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.customer.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.customer.service.shareplan.dto.ShareplanAccount.Account;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@JsonTest
class ShareplanServiceTest {
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  private static final String BRAND_CODE_YBS = "YBS";
  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String STATUS_CODE_400 = "400";
  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Error calling shareplan service: ";
  private static final UUID SESSION_ID = UUID.randomUUID();

  private ShareplanService testSubject;
  private MockWebServer mockWebServer;

  @Autowired private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();

    final WebClient webClient =
        WebClient.builder()
            .baseUrl("http://localhost:" + mockWebServer.getPort())
            .codecs(
                configurer -> {
                  configurer
                      .defaultCodecs()
                      .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                  configurer
                      .defaultCodecs()
                      .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                })
            .build();
    testSubject = new ShareplanService(webClient);
  }

  @Test
  void shouldGetSharePlanAccounts() throws Exception {
    final String body = readClassPathResource("api/shareplanService/shareplanAccounts.json");
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setHeader(HEADER_BRAND_CODE, BRAND_CODE_YBS)
            .setBody(body));

    final List<Account> returned = testSubject.getShareplanAccount(requestMetadata);
    assertThat(returned, is(TestHelper.buildShareplanAccount().getAccounts()));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.GET.name()));
    assertThat(recordedRequest.getPath(), is("/"));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_BRAND_CODE), is(BRAND_CODE_YBS));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
  }

  @Test
  void shouldThrowShareplanServiceExceptionForConnectionError() throws IOException {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.shutdown();
    final ShareplanServiceException exception =
        assertThrows(
            ShareplanServiceException.class,
            () -> testSubject.getShareplanAccount(requestMetadata));
    assertThat(exception.getMessage(), is(equalTo("Error calling shareplan service")));
    assertThat(exception.getCause(), not(instanceOf(ShareplanServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("shareplanServiceErrorResponses")
  void getshareplanShouldThrowShareplanServiceExceptionsForShareplanServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final RequestMetadata requestMetadata = buildRequestMetadata();

    final ShareplanServiceException exception =
        assertThrows(
            ShareplanServiceException.class,
            () -> testSubject.getShareplanAccount(requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(ShareplanServiceException.class)));
  }

  private static Stream<Arguments> shareplanServiceErrorResponses() throws IOException {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/shareplanService/errorResponseInvalidSignature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/shareplanService/errorResponseBadRequest.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/shareplanService/unexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/shareplanService/emptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/shareplanService/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/accountService/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)));
  }

  private static RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .sessionId(SESSION_ID)
        .host(InetSocketAddress.createUnresolved("localhost", 80))
        .partyId("1234567890")
        .brandCode("YBS")
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .webCustomerNumber("1234567890")
        .build();
  }
}
