package uk.co.ybs.digital.customer.web.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
class CustomerBasicResponseTest {

  @Autowired private JacksonTester<CustomerBasicResponse> tester;

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static CustomerBasicResponse buildCustomerBasicResponse() {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId("123456")
                .title("Mr")
                .forename("John")
                .surname("Smith")
                .dateOfBirth(LocalDate.of(1980, 12, 12))
                .deceasedDate(LocalDate.of(2019, 12, 4))
                .email("john.smith@gmail.com")
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number("01234420713")
                            .type("HOME")
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number("07975732685")
                            .type("MOBILE")
                            .subType(PhoneNumberSubType.MOBILE)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number("8756987")
                            .type("WORK")
                            .subType(PhoneNumberSubType.INTERNATIONAL)
                            .countryCode("1")
                            .build()))
                .webCustomerNumber("9876543210")
                .webUsername("John123")
                .build())
        .build();
  }

  private static CustomerBasicResponse buildCustomerBasicResponseWithoutEmailAndTitle() {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId("123456")
                .forename("John")
                .surname("Smith")
                .deceasedDate(LocalDate.of(2019, 12, 4))
                .build())
        .build();
  }

  private static CustomerBasicResponse buildCustomerBasicResponseWithoutWebLogonDetails() {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId("123456")
                .title("Mr")
                .forename("John")
                .surname("Smith")
                .dateOfBirth(LocalDate.of(1980, 12, 12))
                .deceasedDate(LocalDate.of(2019, 12, 4))
                .email("john.smith@gmail.com")
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number("01234420713")
                            .type("HOME")
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number("07975732685")
                            .type("MOBILE")
                            .subType(PhoneNumberSubType.MOBILE)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number("8756987")
                            .type("WORK")
                            .subType(PhoneNumberSubType.INTERNATIONAL)
                            .countryCode("1")
                            .build()))
                .build())
        .build();
  }

  private static CustomerBasicResponse
      buildCustomerBasicResponseWithoutDateOfBirthAndWebLogonDetails() {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId("123456")
                .title("Mr")
                .forename("John")
                .surname("Smith")
                .deceasedDate(LocalDate.of(2019, 12, 4))
                .email("john.smith@gmail.com")
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number("01234420713")
                            .type("HOME")
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number("07975732685")
                            .type("MOBILE")
                            .subType(PhoneNumberSubType.MOBILE)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number("8756987")
                            .type("WORK")
                            .subType(PhoneNumberSubType.INTERNATIONAL)
                            .countryCode("1")
                            .build()))
                .build())
        .build();
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(
            buildCustomerBasicResponse(), new ClassPathResource("api/CustomerBasicResponse.json")),
        Arguments.of(
            buildCustomerBasicResponseWithoutEmailAndTitle(),
            new ClassPathResource("api/CustomerBasicResponseWithoutEmailAndTitle.json")),
        Arguments.of(
            buildCustomerBasicResponseWithoutWebLogonDetails(),
            new ClassPathResource("api/CustomerBasicResponseWithoutWebLogonDetails.json")),
        Arguments.of(
            buildCustomerBasicResponseWithoutDateOfBirthAndWebLogonDetails(),
            new ClassPathResource(
                "api/CustomerBasicResponseWithoutDateOfBirthAndWebLogonDetails.json")));
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void serializes(final CustomerBasicResponse customerBasicResponse, final ClassPathResource json)
      throws IOException {
    assertThat(tester.write(customerBasicResponse)).isEqualToJson(json, JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void deserialize(final CustomerBasicResponse customerBasicResponse, final ClassPathResource json)
      throws IOException {
    assertThat(tester.read(json)).isEqualTo(customerBasicResponse);
  }
}
