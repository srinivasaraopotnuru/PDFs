package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.AddressFunction;
import uk.co.ybs.digital.customer.model.digitalcustomer.PostalAddressType;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class UpdatePostalAddressRequestTest {

  private UpdatePostalAddressRequest testSubject;
  private UpdatePostalAddressRequestArguments arguments;
  private Party party;
  @Mock private UpdatePostalAddressProcessor updatePostalAddressProcessor;

  private static final String ADDRESS_LINE = "Line1";

  @BeforeEach
  void setUp() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    arguments =
        UpdatePostalAddressRequestArguments.builder()
            .partyId(123L)
            .requestMetadata(requestMetadata)
            .processTime(LocalDateTime.parse("2020-05-26T14:45:01"))
            .addressType(PostalAddressType.UKPOST)
            .function(AddressFunction.CORR)
            .addressLine1(ADDRESS_LINE)
            .addressLine2(ADDRESS_LINE)
            .addressLine3(ADDRESS_LINE)
            .addressLine4(ADDRESS_LINE)
            .addressLine5(ADDRESS_LINE)
            .country("UK")
            .areaCode("AA")
            .districtCode("01")
            .sectorCode("1")
            .unitCode("AB")
            .pafAddressKey(1)
            .pafDeliveryPointSuffix("AB")
            .build();

    party =
        TestHelper.buildPartyWithPostalAddressUsages(
            Collections.singletonList(TestHelper.buildPostalAddressRequest()),
            Collections.singletonList(AddressUsage.AddressFunction.CORR));

    testSubject = new UpdatePostalAddressRequest(arguments, updatePostalAddressProcessor);
  }

  @Test
  void resolveShouldReturnResolvedOUpdatePostalAddressRequest() {

    when(updatePostalAddressProcessor.resolve(arguments)).thenReturn(party);

    final ResolvedCustomerRequest resolved = testSubject.resolve();
    assertThat(
        resolved,
        is(new ResolvedUpdatePostalAddressRequest(arguments, updatePostalAddressProcessor, party)));
  }

  @Test
  void auditFailureShouldCallProcessor() {

    testSubject.auditFailure("Failure Message");

    verify(updatePostalAddressProcessor).auditFailure(arguments, "Failure Message");
  }
}
