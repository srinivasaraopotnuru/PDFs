package uk.co.ybs.digital.customer.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class CountryRepositoryTest {

  @Autowired private CountryRepository testSubject;

  @Test
  void shouldFindById() {
    final Country country = Country.builder().code("UK").isoCode("GB").build();
    Country result = testSubject.getById("UK");
    assertThat(result, samePropertyValuesAs(country));
  }
}
