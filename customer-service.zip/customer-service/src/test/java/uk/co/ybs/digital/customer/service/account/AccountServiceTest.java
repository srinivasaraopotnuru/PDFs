package uk.co.ybs.digital.customer.service.account;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.customer.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo.AccountGroup;
import uk.co.ybs.digital.customer.service.account.dto.Warning;
import uk.co.ybs.digital.customer.service.account.dto.WarningCode;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@JsonTest
class AccountServiceTest {
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX = "Error calling account service: ";
  private static final String BEARER = "Bearer ";
  private static final String ACCOUNT_NUMBER = "1234567890";
  private static final UUID SESSION_ID = UUID.randomUUID();
  private static final String STATUS_CODE_400 = "400";
  private static final String ONE_HUNDRED = "100.00";
  private static final String INTERIM_AVAILABLE = "InterimAvailable";

  private AccountService testSubject;
  private MockWebServer mockWebServer;

  @Autowired private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();

    final WebClient webClient =
        WebClient.builder()
            .baseUrl("http://localhost:" + mockWebServer.getPort())
            .codecs(
                configurer -> {
                  configurer
                      .defaultCodecs()
                      .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                  configurer
                      .defaultCodecs()
                      .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                })
            .build();
    testSubject = new AccountService(webClient);
  }

  @Test
  void shouldGetAccountInfo() throws Exception {
    final String body = readClassPathResource("api/accountService/accountsGrouped.json");
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(body));

    final AccountGroupedInfo returned = testSubject.getGroupedAccountInfo(requestMetadata, false);
    assertThat(returned, is(buildAccountInfo(false)));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.GET.name()));
    assertThat(recordedRequest.getPath(), is("/private/accounts/grouped?showClosedAccounts=false"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
  }

  @Test
  void shouldGetAccountInfoIncludingClosedAccounts() throws Exception {
    final String body = readClassPathResource("api/accountService/accountsGroupedClosed.json");
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(body));

    final AccountGroupedInfo returned = testSubject.getGroupedAccountInfo(requestMetadata, true);
    assertThat(returned, is(buildAccountInfo(true)));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.GET.name()));
    assertThat(recordedRequest.getPath(), is("/private/accounts/grouped?showClosedAccounts=true"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
  }

  @Test
  void shouldGetAccountWarnings() throws Exception {
    final String body = readClassPathResource("api/accountService/accountWarnings.json");
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(body));

    final List<Warning> returned = testSubject.getAccountWarnings(ACCOUNT_NUMBER, requestMetadata);

    assertThat(returned, is(buildAccountWarnings()));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.GET.name()));
    assertThat(recordedRequest.getPath(), is("/private/accounts/1234567890/warnings"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
  }

  @Test
  void shouldPostAccountRestriction() throws Exception {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    final WarningCode request = WarningCode.builder().code("CA").build();

    testSubject.postAccountWarning(ACCOUNT_NUMBER, request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/private/accounts/1234567890/warnings"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody = readClassPathResource("api/accountService/warningRequest.json");

    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldThrowAccountServiceExceptionForConnectionError() throws IOException {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    mockWebServer.shutdown();
    final AccountServiceException exception =
        assertThrows(
            AccountServiceException.class,
            () -> testSubject.getGroupedAccountInfo(requestMetadata, false));
    assertThat(exception.getMessage(), is(equalTo("Error calling account service")));
    assertThat(exception.getCause(), not(instanceOf(AccountServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("accountServiceErrorResponses")
  void getGroupedAccountInfoShouldThrowAccountServiceExceptionsForAccountServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AccountServiceException exception =
        assertThrows(
            AccountServiceException.class,
            () -> testSubject.getGroupedAccountInfo(requestMetadata, false));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AccountServiceException.class)));
  }

  @Test
  void shouldGetEmptyOwnedAccountsWhenOwnedIsNull() throws Exception {
    final String body = readClassPathResource("api/accountService/accountsGroupedEmpty.json");
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(body));

    final AccountGroupedInfo returned = testSubject.getGroupedAccountInfo(requestMetadata, false);
    assertThat(
        returned, is(AccountGroupedInfo.builder().owned(AccountGroup.builder().build()).build()));

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.GET.name()));
    assertThat(recordedRequest.getPath(), is("/private/accounts/grouped?showClosedAccounts=false"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
  }

  private static Stream<Arguments> accountServiceErrorResponses() {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/accountService/errorResponseInvalidSignature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/accountService/errorResponseBadRequest.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/accountService/unexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/accountService/emptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/accountService/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/accountService/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + STATUS_CODE_400)));
  }

  private static RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .sessionId(SESSION_ID)
        .host(InetSocketAddress.createUnresolved("localhost", 80))
        .partyId(ACCOUNT_NUMBER)
        .brandCode("YBS")
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .webCustomerNumber(ACCOUNT_NUMBER)
        .build();
  }

  private static AccountGroupedInfo buildAccountInfo(final boolean includeClosedAccounts) {
    return AccountGroupedInfo.builder()
        .owned(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccount()))
                .balances(
                    Collections.singletonList(
                        AccountGroupedInfo.Balance.builder()
                            .type(INTERIM_AVAILABLE)
                            .amount(new BigDecimal(ONE_HUNDRED))
                            .build()))
                .build())
        .other(
            AccountGroupedInfo.AccountGroup.builder()
                .accounts(Collections.singletonList(buildAccount()))
                .balances(
                    Collections.singletonList(
                        AccountGroupedInfo.Balance.builder()
                            .type(INTERIM_AVAILABLE)
                            .amount(new BigDecimal(ONE_HUNDRED))
                            .build()))
                .build())
        .closed(
            includeClosedAccounts
                ? AccountGroupedInfo.AccountGroup.builder()
                    .accounts(Collections.singletonList(buildAccount()))
                    .balances(
                        Collections.singletonList(
                            AccountGroupedInfo.Balance.builder()
                                .type(INTERIM_AVAILABLE)
                                .amount(new BigDecimal(ONE_HUNDRED))
                                .build()))
                    .build()
                : null) // NOPMD
        .build();
  }

  private static AccountGroupedInfo.AccountSummary buildAccount() {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .accountName("Test")
        .amendmentRestriction(true)
        .accountSortCode("123456")
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .deposits(AccountGroupedInfo.DepositsSummary.builder().permittedOverApi(true).build())
        .withdrawals(AccountGroupedInfo.WithdrawalsSummary.builder().permittedOverApi(true).build())
        .currency("GBP")
        .productIdentifier("test")
        .productDescription("Monthly Regular Saver: Issue 2")
        .isa(AccountGroupedInfo.Isa.builder().flexible(true).helpToBuy(false).build())
        .balances(
            Collections.singletonList(
                AccountGroupedInfo.Balance.builder()
                    .type(INTERIM_AVAILABLE)
                    .amount(new BigDecimal(ONE_HUNDRED))
                    .build()))
        .build();
  }

  private static List<Warning> buildAccountWarnings() {

    return Arrays.asList(
        Warning.builder().code("code1").description("description1").build(),
        Warning.builder().code("code2").description("description2").build());
  }
}
