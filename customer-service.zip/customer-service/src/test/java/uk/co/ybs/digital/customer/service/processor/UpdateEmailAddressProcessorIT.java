package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.springframework.ldap.query.LdapQueryBuilder.query;

import com.google.common.base.Strings;
import java.time.LocalDateTime;
import java.util.EnumSet;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.customer.e2e.CoreHelper;
import uk.co.ybs.digital.customer.e2e.TestData;
import uk.co.ybs.digital.customer.integration.IntegrationTestConfig;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.AddressUsage;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.ldap.LdapPerson;
import uk.co.ybs.digital.customer.repository.ldap.LdapPersonRepository;
import uk.co.ybs.digital.customer.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@SpringBootTest(classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
@TestPropertySource(properties = {"spring.ldap.urls="})
public class UpdateEmailAddressProcessorIT {

  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  private static final long PARTY_ID = 123456L;
  public static final String UPDATED_EMAIL_ADDRESS = "updated@provider.com";

  @Autowired private UpdateEmailAddressProcessor testSubject;

  @Autowired private TransactionTemplate transactionTemplate;

  @Autowired private TestEntityManager coreTestEntityManager;

  @Autowired private PlatformTransactionManager customerProcessorTransactionManager;

  @Autowired private LdapPersonRepository ldapPersonRepository;

  @Autowired private LdapTemplate ldapTemplate;

  private CoreHelper coreHelper;

  @BeforeEach
  void setup() {
    coreHelper = new CoreHelper(transactionTemplate, coreTestEntityManager);
  }

  @AfterEach
  void cleanup() {
    coreHelper.clearDb();
  }

  @Test
  void transactionRollbackShouldRestoreOriginalValuesToLdap() {

    final Party party = coreHelper.setupParty(TestData.PARTY_ID, EnumSet.allOf(AddressType.class));

    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    TransactionTemplate customerProcessorTransactionTemplate =
        new TransactionTemplate(customerProcessorTransactionManager);

    // Reset the data in LDAP as it may have been changed by another test
    updateLdapEmailAddress(TestData.PARTY_ID, TestData.EMAIL_ADDRESS);

    // Update the data on LDAP & Core forcing a rollback once completed
    customerProcessorTransactionTemplate.executeWithoutResult(
        status -> {
          testSubject.execute(
              new UpdateEmailAddressRequestArguments(
                  PARTY_ID, requestMetadata, PROCESS_TIME, UPDATED_EMAIL_ADDRESS),
              party);
          status.setRollbackOnly();
        });

    // Assert that all changes have been rolled back
    Matcher<Iterable<? extends AddressUsage>> addressUsageMatcher =
        contains(
            TestHelper.addressUsageMatcher(
                AddressUsage.AddressFunction.DIRCOM,
                TestData.PARTY_CREATED_DATE,
                null,
                TestData.PARTY_CREATED_DATE,
                TestHelper.AUDIT_AT,
                TestHelper.AUDIT_BY,
                null,
                null,
                null,
                true,
                null,
                TestHelper.nonPostalAddressMatcher(AddressType.EMAIL, TestData.EMAIL_ADDRESS),
                anyOf(nullValue())));

    assertAll(
        () ->
            TestHelper.assertNonPostalAddressUsages(
                coreTestEntityManager,
                transactionTemplate,
                party.getSysId(),
                addressUsageMatcher,
                AddressType.EMAIL,
                null),
        () -> TestHelper.assertLdapEmailAddressValue(ldapPersonRepository, TestData.EMAIL_ADDRESS));
  }

  private void updateLdapEmailAddress(final Long partyId, final String emailAddress) {
    final String uid = Strings.padStart(String.valueOf(partyId), 10, '0');

    final LdapPerson ldapPerson =
        ldapTemplate.findOne(query().where("uid").is(uid), LdapPerson.class);

    final LdapPerson ldapPersonUpdated = ldapPerson.toBuilder().emailAddress(emailAddress).build();

    ldapTemplate.update(ldapPersonUpdated);
  }
}
