package uk.co.ybs.digital.customer.repository.core;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.EnumSet;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.model.core.WorkEvent.ModuleLabelAssociationType;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventContextTableName;
import uk.co.ybs.digital.customer.model.core.WorkEvent.WorkEventStatus;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
@TestPropertySource(properties = {"spring.ldap.urls="})
@Transactional("customerProcessorTransactionManager")
class WorkEventCoreRepositoryTest {

  public static final String CHCAMO_WORK_EVENT = "CHCAMO";
  public static final String CUS0503U_MODULE_SHORT_NAME = "CUS0503U";
  public static final long CONTEXT_ID_2 = 80L;
  public static final long CONTEXT_ID_1 = 16936804L;
  public static final long UNKNOWN_CONTEXT_ID_1 = 1L;
  public static final String UNKNOWN_WORK_EVENT = "TEST";

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-09-01T00:00:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);

  @Autowired WorkEventCoreRepository workEventCoreRepository;

  @Autowired TestEntityManager coreTestEntityManager;

  @Autowired TransactionTemplate transactionTemplate;

  @ParameterizedTest
  @EnumSource(
      value = WorkEventStatus.class,
      names = {"TODO", "INPROG", "REFER"})
  void findWorkEventsWithMatchingDetailsShouldReturnDetails(final WorkEventStatus status) {

    createChcamoWorkEvent(status);

    List<Long> results =
        workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            CONTEXT_ID_1,
            CONTEXT_ID_2,
            EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER),
            ModuleLabelAssociationType.CREEVT,
            CHCAMO_WORK_EVENT,
            CUS0503U_MODULE_SHORT_NAME,
            NOW);

    assertThat(results.size(), equalTo(1));
  }

  @Test
  void findWorkEventsWhereAccountDoesNotMatchShouldReturnEmpty() {

    createChcamoWorkEvent(WorkEventStatus.TODO);

    List<Long> results =
        workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            UNKNOWN_CONTEXT_ID_1,
            CONTEXT_ID_2,
            EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER),
            ModuleLabelAssociationType.CREEVT,
            CHCAMO_WORK_EVENT,
            CUS0503U_MODULE_SHORT_NAME,
            NOW);

    assertThat(results.size(), equalTo(0));
  }

  @Test
  void findWorkEventsWhereModuleLabelAssociationDoesNotExistShouldReturnEmpty() {

    createChcamoWorkEvent(WorkEventStatus.TODO);

    List<Long> results =
        workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            CONTEXT_ID_1,
            CONTEXT_ID_2,
            EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER),
            ModuleLabelAssociationType.CREEVT,
            UNKNOWN_WORK_EVENT,
            CUS0503U_MODULE_SHORT_NAME,
            NOW);

    assertThat(results.size(), equalTo(0));
  }

  @Test
  void findWorkEventsWhereStatusIsCompleteShouldReturnEmpty() {

    createChcamoWorkEvent(WorkEventStatus.COMPLT);

    List<Long> results =
        workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            CONTEXT_ID_1,
            CONTEXT_ID_2,
            EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER),
            ModuleLabelAssociationType.CREEVT,
            CHCAMO_WORK_EVENT,
            CUS0503U_MODULE_SHORT_NAME,
            NOW);

    assertThat(results.size(), equalTo(0));
  }

  @Test
  void findWorkEventsWhereExistingAreCompletedShouldReturnEmpty() {

    final Long accountNumber = 12312312L;
    final Long accountNumberType = 80L;

    transactionTemplate.executeWithoutResult(
        status -> {
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  "insert into module_details (SYSID, SHORT_NAME) values (10872, 'CUS0503U')")
              .executeUpdate();
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  "insert into module_label_associations (SYSID, START_DATE, END_DATE, MODLAB_NAME, MODLAB_MDD_SYSID, WET_NAME, WET_INTORG_PARTY_SYSID, MLA_TYPE) values (25980, to_date('15-04-2008', 'dd-mm-yyyy'), null, 'CHCAMO', 10872, 'CHCAMO', 620491, 'CREEVT')")
              .executeUpdate();
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  String.format(
                      "insert into work_events (SYSID, STATUS, WET_NAME, WET_INTORG_PARTY_SYSID, CNTXT_TABLE_ID, CNTXT_SYSID1, CNTXT_SYSID2) values (29318192, 'COMPLT', 'CHCAMO', 620491, 'LOANAC', %s, %s)",
                      accountNumber, accountNumberType))
              .executeUpdate();
        });

    List<Long> results =
        workEventCoreRepository.findWorkEvents(
            WorkEventContextTableName.LOANAC,
            accountNumber,
            accountNumberType,
            EnumSet.of(WorkEventStatus.TODO, WorkEventStatus.INPROG, WorkEventStatus.REFER),
            ModuleLabelAssociationType.CREEVT,
            CHCAMO_WORK_EVENT,
            CUS0503U_MODULE_SHORT_NAME,
            NOW);

    assertThat(results.size(), equalTo(0));
  }

  private void createChcamoWorkEvent(final WorkEventStatus workEventStatus) {

    transactionTemplate.executeWithoutResult(
        status -> {
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  "insert into module_details (SYSID, SHORT_NAME) values (10872, 'CUS0503U')")
              .executeUpdate();
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  "insert into module_label_associations (SYSID, START_DATE, END_DATE, MODLAB_NAME, MODLAB_MDD_SYSID, WET_NAME, WET_INTORG_PARTY_SYSID, MLA_TYPE) values (25980, to_date('15-04-2008', 'dd-mm-yyyy'), null, 'CHCAMO', 10872, 'CHCAMO', 620491, 'CREEVT')")
              .executeUpdate();
          coreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  "insert into work_events (SYSID, STATUS, WET_NAME, WET_INTORG_PARTY_SYSID, CNTXT_TABLE_ID, CNTXT_SYSID1, CNTXT_SYSID2) values (29318192, '"
                      + workEventStatus.toString()
                      + "', 'CHCAMO', 620491, 'LOANAC', 16936804, 80)")
              .executeUpdate();
        });
  }
}
