package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class DeletePhoneNumberRequestTest {

  private static final long PARTY_ID = 123456L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  @Mock private DeletePhoneNumberProcessor deletePhoneNumberProcessor;

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments")
  void resolveShouldReturnResolvedDeletePhoneNumberRequest(
      final NonPostalAddress nonPostalAddress) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final DeletePhoneNumberRequestArguments arguments =
        new DeletePhoneNumberRequestArguments(
            PARTY_ID,
            requestMetadata,
            PROCESS_TIME,
            PhoneNumberRequestType.valueOf(String.valueOf(nonPostalAddress.getSourceType())));

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(nonPostalAddress));

    final DeletePhoneNumberRequest testSubject =
        new DeletePhoneNumberRequest(arguments, deletePhoneNumberProcessor);

    when(deletePhoneNumberProcessor.resolve(arguments)).thenReturn(party);

    final ResolvedCustomerRequest resolved = testSubject.resolve();
    assertThat(
        resolved,
        is(new ResolvedDeletePhoneNumberRequest(arguments, deletePhoneNumberProcessor, party)));
  }

  @ParameterizedTest
  @EnumSource(PhoneNumberRequestType.class)
  void resolveShouldAuditFailure(final PhoneNumberRequestType requestType) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final DeletePhoneNumberRequestArguments arguments =
        new DeletePhoneNumberRequestArguments(PARTY_ID, requestMetadata, PROCESS_TIME, requestType);

    final DeletePhoneNumberRequest testSubject =
        new DeletePhoneNumberRequest(arguments, deletePhoneNumberProcessor);

    testSubject.auditFailure(TestHelper.TECHNICAL_FAILURE_MESSAGE);

    verify(deletePhoneNumberProcessor)
        .auditFailure(arguments, TestHelper.TECHNICAL_FAILURE_MESSAGE);
  }

  private static Stream<NonPostalAddress> nonPostalAddressArguments() {
    return Stream.of(
        TestHelper.buildHomePhoneNumberRequest(),
        TestHelper.buildMobilePhoneNumberRequest(),
        TestHelper.buildWorkLandlinePhoneNumberRequest(),
        TestHelper.buildWorkMobilePhoneNumberRequest());
  }
}
