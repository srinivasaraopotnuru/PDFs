package uk.co.ybs.digital.customer.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.customer.model.adgcore.FatcaParty;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class FatcaPartyRepositoryTest {

  @Autowired private FatcaPartyRepository testSubject;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  private static final Long PARTY_ID = 1234567L;
  private static final Long SYS_ID = 123L;
  private static final LocalDateTime NOW = LocalDateTime.now();

  @Test
  void shouldFindById() {
    final FatcaParty persisted =
        persistFatca(SYS_ID, PARTY_ID, true, false, NOW.minusDays(1), NOW.plusDays(1));
    Optional<FatcaParty> result = testSubject.findById(SYS_ID);

    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldFindByPartyIdWhenNotEnded() {
    final FatcaParty persisted =
        persistFatca(SYS_ID, PARTY_ID, true, false, NOW.minusDays(1), NOW.plusDays(1));
    Optional<FatcaParty> result = testSubject.findByPartyIdAndNotEnded(PARTY_ID, NOW);

    assertThat(result.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldNotFindByPartyIdWhenIdIncorrect() {
    persistFatca(SYS_ID, 121L, true, false, NOW.minusDays(1), NOW.plusDays(1));
    Optional<FatcaParty> result = testSubject.findByPartyIdAndNotEnded(231231L, NOW); // NOPMD

    assertThat(result.isPresent(), is(false));
  }

  @Test
  void shouldNotFindByPartyIdWhenEndedDate() {
    persistFatca(SYS_ID, PARTY_ID, true, true, NOW.minusDays(2), NOW.minusDays(1));
    Optional<FatcaParty> result = testSubject.findByPartyIdAndNotEnded(PARTY_ID, NOW);

    assertThat(result.isPresent(), is(false));
  }

  @Test
  void shouldNotFindByPartyIdWhenNotStarted() {
    persistFatca(SYS_ID, PARTY_ID, true, true, NOW.plusDays(2), NOW.plusDays(3));
    Optional<FatcaParty> result = testSubject.findByPartyIdAndNotEnded(PARTY_ID, NOW);

    assertThat(result.isPresent(), is(false));
  }

  private FatcaParty persistFatca(
      final Long sysId,
      final Long partyId,
      final boolean fatcaResponseUK,
      final boolean fatcaResponseUSA,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {

    final FatcaParty fatcaParty =
        FatcaParty.builder()
            .sysId(sysId)
            .partyId(partyId)
            .fatcaResponseUK(fatcaResponseUK)
            .fatcaResponseUS(fatcaResponseUSA)
            .startDate(startDate)
            .endedDate(endDate)
            .build();

    return adgCoreTestEntityManager.persistAndFlush(fatcaParty);
  }
}
