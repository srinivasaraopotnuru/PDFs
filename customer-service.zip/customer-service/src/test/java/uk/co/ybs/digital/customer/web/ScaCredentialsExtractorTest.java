package uk.co.ybs.digital.customer.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.http.HttpHeaders;
import uk.co.ybs.digital.customer.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.customer.service.ScaCredentialsExtractor;
import uk.co.ybs.digital.sca.service.ScaCredentials;

class ScaCredentialsExtractorTest {

  private final ScaCredentialsExtractor testSubject = new ScaCredentialsExtractor();

  private static final String SCA_HEADER_KEY = "x-ybs-sca-key";
  private static final String SCA_HEADER_KEY_VALUE = "sca-key";
  private static final String SCA_HEADER_CHALLENGE = "x-ybs-sca-challenge";
  private static final String SCA_HEADER_CHALLENGE_RESPONSE = "x-ybs-sca-challenge-response";

  @Test
  void extractShouldReturnEmptyOptionalWhenScaCredentialsNotProvided() {
    final HttpHeaders headers = new HttpHeaders();
    headers.add(SCA_HEADER_KEY, SCA_HEADER_KEY_VALUE);

    final Optional<ScaCredentials> scaCredentials = testSubject.extract(headers);

    assertThat(scaCredentials.isPresent(), is(false));
  }

  @Test
  void extractShouldReturnEmptyOptionalWhenScaCredentialsNotProvidedWithNoScaKey() {
    final HttpHeaders headers = new HttpHeaders();

    final Optional<ScaCredentials> scaCredentials = testSubject.extract(headers);

    assertThat(scaCredentials.isPresent(), is(false));
  }

  @Test
  void extractShouldReturnScaCredentialsWhenProvided() {
    final String challenge = "challenge";
    final String challengeResponse = "challenge-response";

    final HttpHeaders headers = new HttpHeaders();
    headers.add(SCA_HEADER_CHALLENGE, challenge);
    headers.add(SCA_HEADER_CHALLENGE_RESPONSE, challengeResponse);
    headers.add(SCA_HEADER_KEY, SCA_HEADER_KEY_VALUE);

    final Optional<ScaCredentials> scaCredentials = testSubject.extract(headers);

    assertThat(scaCredentials.isPresent(), is(true));
    assertThat(
        scaCredentials.get(),
        is(new ScaCredentials(challenge, challengeResponse, SCA_HEADER_KEY_VALUE)));
  }

  @ParameterizedTest
  @MethodSource("partialScaCredentials")
  void extractShouldThrowInvalidScaHeadersExceptionWhenPartialScaCredentialsProvided(
      final String challenge,
      final String challengeResponse,
      final String scaKey,
      final String expectedMessage,
      final List<String> expectedMissingHeaders) {
    final HttpHeaders headers = new HttpHeaders();
    if (challenge != null) {
      headers.add(SCA_HEADER_CHALLENGE, challenge);
    }
    if (challengeResponse != null) {
      headers.add(SCA_HEADER_CHALLENGE_RESPONSE, challengeResponse);
    }
    if (scaKey != null) {
      headers.add(SCA_HEADER_KEY, scaKey);
    }

    final InvalidScaHeadersException exception =
        assertThrows(InvalidScaHeadersException.class, () -> testSubject.extract(headers));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getMissingHeaders(), is(expectedMissingHeaders));
    assertThat(
        exception.getRequiredHeaders(),
        is(Arrays.asList(SCA_HEADER_CHALLENGE, SCA_HEADER_CHALLENGE_RESPONSE, SCA_HEADER_KEY)));
  }

  private static Stream<Arguments> partialScaCredentials() {
    return Stream.of(
        Arguments.of(
            "challenge",
            null,
            null,
            "Missing headers: [x-ybs-sca-challenge-response, x-ybs-sca-key]",
            Arrays.asList("x-ybs-sca-challenge-response", "x-ybs-sca-key")),
        Arguments.of(
            null,
            "challenge-response",
            null,
            "Missing headers: [x-ybs-sca-challenge, x-ybs-sca-key]",
            Arrays.asList("x-ybs-sca-challenge", "x-ybs-sca-key")),
        Arguments.of(
            "challenge",
            null,
            "sca-key",
            "Missing headers: [x-ybs-sca-challenge-response]",
            Collections.singletonList("x-ybs-sca-challenge-response")),
        Arguments.of(
            null,
            "challenge-response",
            "sca-key",
            "Missing headers: [x-ybs-sca-challenge]",
            Collections.singletonList("x-ybs-sca-challenge")));
  }
}
