package uk.co.ybs.digital.customer.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.NPASourceType;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;
import uk.co.ybs.digital.customer.utils.TestHelper;

@YbsDataJpaTest
@TestPropertySource(properties = {"spring.ldap.urls="})
@Transactional("customerProcessorTransactionManager")
public class NonPostalAddressCoreRepositoryTest {

  @Autowired NonPostalAddressCoreRepository testSubject;

  @Autowired TestEntityManager coreTestEntityManager;

  private static final Integer HOME_ADC_CODE_1 = 1234;
  private static final String HOME_ADDRESS_1 = "456789";
  private static final String MOBILE_ADDRESS_1 = "07123456789";
  private static final Integer HOME_ADC_CODE_2 = 4321;
  private static final String HOME_ADDRESS_2 = "987654";
  private static final String MOBILE_ADDRESS_2 = "07987654321";

  @Test
  void shouldFindById() {
    final NonPostalAddress npa = NonPostalAddress.builder().address(HOME_ADDRESS_1).build();

    final NonPostalAddress npaStored = coreTestEntityManager.persistAndFlush(npa);
    coreTestEntityManager.clear();

    final Optional<NonPostalAddress> found = testSubject.findById(npaStored.getSysId());

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(npaStored));
  }

  @ParameterizedTest
  @MethodSource("phoneNumberRequestArguments")
  void shouldFindNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
      final NonPostalAddress nonPostalAddress,
      final String address,
      final Integer adcCode,
      final NPASourceType sourceType,
      final Country country) {
    final NonPostalAddress npaStored = coreTestEntityManager.persistAndFlush(nonPostalAddress);
    coreTestEntityManager.clear();

    final Optional<NonPostalAddress> found =
        testSubject.findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
            address, AddressType.TEL, adcCode, sourceType, country);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(npaStored));
  }

  @ParameterizedTest
  @MethodSource("phoneNumberRequestFailureArguments")
  void shouldNotFindNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
      final NonPostalAddress nonPostalAddress,
      final String address,
      final Integer adcCode,
      final NPASourceType sourceType,
      final Country country) {
    coreTestEntityManager.persistAndFlush(nonPostalAddress);
    coreTestEntityManager.clear();

    final Optional<NonPostalAddress> found =
        testSubject.findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
            address, AddressType.TEL, adcCode, sourceType, country);

    assertThat(found.isPresent(), is(false));
  }

  @ParameterizedTest
  @MethodSource("landlinePhoneNumberDifferentSourceType")
  void shouldFindLandlineNonPostalAddressFromMultipleWithSameDetailsExceptSourceType(
      final NonPostalAddress npa1, final NonPostalAddress npa2, final NPASourceType sourceType) {
    final NonPostalAddress npaStored = coreTestEntityManager.persistAndFlush(npa1);
    coreTestEntityManager.persistAndFlush(npa2);
    coreTestEntityManager.clear();

    final Optional<NonPostalAddress> found =
        testSubject.findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
            HOME_ADDRESS_1, AddressType.TEL, HOME_ADC_CODE_1, sourceType, buildCountry());

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(npaStored));
  }

  @ParameterizedTest
  @MethodSource("mobilePhoneNumberDifferentSourceType")
  void shouldFindMobileNonPostalAddressFromMultipleWithSameDetailsExceptSourceType(
      final NonPostalAddress npa1, final NonPostalAddress npa2, final NPASourceType sourceType) {
    final NonPostalAddress npaStored1 = coreTestEntityManager.persistAndFlush(npa1);
    coreTestEntityManager.persistAndFlush(npa2);
    coreTestEntityManager.clear();

    final Optional<NonPostalAddress> found =
        testSubject.findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
            MOBILE_ADDRESS_1, AddressType.TEL, null, sourceType, null);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(npaStored1));
  }

  @Test
  void shouldFindMobileNonPostalAddressFromMultipleWithSameDetailsExceptCountry() {
    final NonPostalAddress npaStored1 =
        coreTestEntityManager.persistAndFlush(
            NonPostalAddress.builder()
                .type(AddressType.TEL)
                .address(MOBILE_ADDRESS_1)
                .sourceType(NPASourceType.MOBILE)
                .build());
    coreTestEntityManager.persistAndFlush(
        NonPostalAddress.builder()
            .type(AddressType.TEL)
            .address(MOBILE_ADDRESS_1)
            .sourceType(NPASourceType.MOBILE)
            .country(TestHelper.buildCountry())
            .build());
    coreTestEntityManager.clear();

    final Optional<NonPostalAddress> found =
        testSubject.findNonPostalAddressByAddressAndTypeAndDiallingCodeAndSourceType(
            MOBILE_ADDRESS_1, AddressType.TEL, null, NPASourceType.MOBILE, null);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(npaStored1));
  }

  private static Stream<Arguments> landlinePhoneNumberDifferentSourceType() {
    return Stream.of(
        Arguments.of(
            buildHomePhoneNumberRequest(),
            buildWorkLandlinePhoneNumberRequest(),
            NPASourceType.HOME),
        Arguments.of(
            buildWorkLandlinePhoneNumberRequest(),
            buildHomePhoneNumberRequest(),
            NPASourceType.WORK));
  }

  private static Stream<Arguments> mobilePhoneNumberDifferentSourceType() {
    return Stream.of(
        Arguments.of(
            buildMobilePhoneNumberRequest(),
            buildWorkMobilePhoneNumberRequest(),
            NPASourceType.MOBILE),
        Arguments.of(
            buildWorkMobilePhoneNumberRequest(),
            buildMobilePhoneNumberRequest(),
            NPASourceType.WORK));
  }

  private static Stream<Arguments> phoneNumberRequestArguments() {
    return Stream.of(
        Arguments.of(
            buildHomePhoneNumberRequest(),
            HOME_ADDRESS_1,
            HOME_ADC_CODE_1,
            NPASourceType.HOME,
            buildCountry()),
        Arguments.of(
            buildMobilePhoneNumberRequest(), MOBILE_ADDRESS_1, null, NPASourceType.MOBILE, null),
        Arguments.of(
            buildWorkLandlinePhoneNumberRequest(),
            HOME_ADDRESS_1,
            HOME_ADC_CODE_1,
            NPASourceType.WORK,
            buildCountry()),
        Arguments.of(
            buildWorkMobilePhoneNumberRequest(), MOBILE_ADDRESS_1, null, NPASourceType.WORK, null));
  }

  private static Stream<Arguments> phoneNumberRequestFailureArguments() {
    return Stream.of(
        Arguments.of(
            buildHomePhoneNumberRequest(),
            HOME_ADDRESS_1,
            HOME_ADC_CODE_1,
            NPASourceType.HOME,
            buildOtherCountry()),
        Arguments.of(
            buildHomePhoneNumberRequest(),
            HOME_ADDRESS_1,
            HOME_ADC_CODE_1,
            NPASourceType.WORK,
            buildCountry()),
        Arguments.of(
            buildHomePhoneNumberRequest(),
            HOME_ADDRESS_1,
            HOME_ADC_CODE_2,
            NPASourceType.HOME,
            buildCountry()),
        Arguments.of(
            buildHomePhoneNumberRequest(),
            HOME_ADDRESS_2,
            HOME_ADC_CODE_1,
            NPASourceType.HOME,
            buildCountry()),
        Arguments.of(
            buildMobilePhoneNumberRequest(), MOBILE_ADDRESS_1, null, NPASourceType.WORK, null),
        Arguments.of(
            buildMobilePhoneNumberRequest(), MOBILE_ADDRESS_2, null, NPASourceType.MOBILE, null),
        Arguments.of(
            buildWorkLandlinePhoneNumberRequest(),
            HOME_ADDRESS_1,
            HOME_ADC_CODE_1,
            NPASourceType.WORK,
            buildOtherCountry()),
        Arguments.of(
            buildWorkLandlinePhoneNumberRequest(),
            HOME_ADDRESS_1,
            HOME_ADC_CODE_1,
            NPASourceType.HOME,
            buildCountry()),
        Arguments.of(
            buildWorkLandlinePhoneNumberRequest(),
            HOME_ADDRESS_1,
            HOME_ADC_CODE_2,
            NPASourceType.WORK,
            buildCountry()),
        Arguments.of(
            buildWorkLandlinePhoneNumberRequest(),
            HOME_ADDRESS_2,
            HOME_ADC_CODE_1,
            NPASourceType.WORK,
            buildCountry()),
        Arguments.of(
            buildWorkMobilePhoneNumberRequest(),
            MOBILE_ADDRESS_1,
            null,
            NPASourceType.MOBILE,
            null),
        Arguments.of(
            buildWorkMobilePhoneNumberRequest(), MOBILE_ADDRESS_2, null, NPASourceType.WORK, null));
  }

  private static Country buildCountry() {
    return TestHelper.buildCountry();
  }

  private static Country buildOtherCountry() {
    return TestHelper.buildCountry("ARG", "AR");
  }

  private static NonPostalAddress buildHomePhoneNumberRequest() {
    return TestHelper.buildHomePhoneNumberRequest();
  }

  private static NonPostalAddress buildMobilePhoneNumberRequest() {
    return TestHelper.buildMobilePhoneNumberRequest();
  }

  private static NonPostalAddress buildWorkLandlinePhoneNumberRequest() {
    return TestHelper.buildWorkLandlinePhoneNumberRequest();
  }

  private static NonPostalAddress buildWorkMobilePhoneNumberRequest() {
    return TestHelper.buildWorkMobilePhoneNumberRequest();
  }
}
