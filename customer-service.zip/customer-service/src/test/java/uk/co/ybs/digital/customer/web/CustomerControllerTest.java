package uk.co.ybs.digital.customer.web;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.jwt;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildOnSaleProducts;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildFailureRequestWithFailureType;
import static uk.co.ybs.digital.customer.web.dto.ErrorResponse.ErrorItem;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.InetSocketAddress;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import uk.co.ybs.digital.customer.config.TestClockConfig;
import uk.co.ybs.digital.customer.exception.BadFailureRequestChallengeException;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.exception.CustomerValidationException;
import uk.co.ybs.digital.customer.exception.CustomerValidationExceptionReason;
import uk.co.ybs.digital.customer.exception.InvalidScaHeadersException;
import uk.co.ybs.digital.customer.exception.MultipleRecordsFoundException;
import uk.co.ybs.digital.customer.exception.ScaRequiredException;
import uk.co.ybs.digital.customer.service.AreaDiallingCodesService;
import uk.co.ybs.digital.customer.service.CustomerService;
import uk.co.ybs.digital.customer.service.ScaCredentialsExtractor;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.CustomerBasicResponse;
import uk.co.ybs.digital.customer.web.dto.CustomerDelayedRequest;
import uk.co.ybs.digital.customer.web.dto.CustomerDetailsExtendedResponse;
import uk.co.ybs.digital.customer.web.dto.CustomerDetailsResponse;
import uk.co.ybs.digital.customer.web.dto.EmailAddress;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.FailureRequest;
import uk.co.ybs.digital.customer.web.dto.FailureType;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerExtendedRecord;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.PafData;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.sca.exception.InvalidPemKeyException;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(controllers = {CustomerController.class, CustomerControllerPrivate.class})
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter, SessionIdFilter
  RequestVerificationSecurityAutoConfiguration.class, // Signature verification
  FilterErrorResponseFactory.class,
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class, // Metrics
  TestClockConfig.class
})
@ActiveProfiles({"test", "text-logging"})
class CustomerControllerTest {

  private static final String PATH_CUSTOMER = "/customer/{partyId}";
  private static final String PATH_CUSTOMER_PRIVATE = "/private/customer/{partyId}";
  private static final String PATH_CUSTOMER_DELAYED = "/customer/delayed/{partyId}";
  private static final String PATH_CUSTOMER_DELAYED_PRIVATE = "/private/customer/delayed/{partyId}";
  private static final String PATH_CUSTOMER_DETAILS = "/customer";
  private static final String PATH_CUSTOMER_DETAILS_PRIVATE = "/private/customer";
  private static final String PATH_EMAIL_UPDATE = "/customer/email-address";
  private static final String PATH_PHONE_NUMBER_UPDATE = "/customer/phone-number";
  private static final String PATH_POSTAL_ADDRESS_UPDATE = "/customer/postal-address";

  private static final String PATH_AVAILABLE_PRODUCTS = "/customer/available-products";
  private static final String PATH_AVAILABLE_PRODUCTS_PRIVATE =
      "/private/customer/available-products";

  private static final String PATH_CUSTOMER_DELAYED_POST_PRIVATE = "/private/customer/delayed";
  private static final String HOST_HEADER_VALUE = "customerservice.ybs.co.uk:443";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";

  private static final String POST_CODE_ERROR = "Value must be a valid UK Post Code";
  private static final String MUST_BE_VALID_UK_MOBILE_NUMBER =
      "Value must be a valid UK Mobile Number";
  private static final String PHONE_NUMBER_NOT_VALID = "Phone Number not a valid mobile number";
  private static final String INVALID_EMAIL_ERROR_NON_WHITESPACE =
      "Email Type must contain at least one non-whitespace character";
  private static final String INVALID_EMAIL_ERROR = "You must supply a valid email address";

  private static final String FIELD_MISSING_ERROR = "Field.Missing";
  private static final String FIELD_INVALID_ERROR = "Field.Invalid";
  private static final String INVALID_REQUEST_BODY = "Invalid request body";
  private static final String CHALLENGE = "the-challenge";
  private static final String POSTCODE = "LS1 6LR";

  private static final String HEADER_MISSING = "Header.Missing";
  private static final String SCA_HEADER_CHALLENGE = "x-ybs-sca-challenge";
  private static final String SCA_HEADER_CHALLENGE_RESPONSE = "x-ybs-sca-challenge-response";
  private static final String SCA_HEADER_KEY = "x-ybs-sca-key";

  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final UUID SESSION_ID = UUID.randomUUID();
  private static final InetSocketAddress HOST =
      InetSocketAddress.createUnresolved("customerservice.ybs.co.uk", 443);
  private static final long PARTY_ID = 123456L;
  private static final String PARTY_ID_STRING = "123456";
  private static final String BRAND_CODE_YBS = "YBS";
  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String FORWARDING_AUTH = "<jwt>";

  private static final String VALID_SCOPE = "ACCOUNT_READ";
  private static final String OTHER_SCOPE = "PAYMENT";

  private static final String SESSION_ID_ATTRIBUTE_NAME =
      "uk.co.ybs.digital.logging.session.SessionIdFilter.sessionId";

  private static final String EMAIL_ADDRESS_TYPE = "Email";
  private static final String EMAIL_ADDRESS = "test@test.com";
  private static final String CHALLENGE_FAILURE_ENDPOINT = "/failure";

  @Autowired private MockMvc mvc;

  @Autowired private ObjectMapper objectMapper;

  @MockBean private RequestSigningVerificationService requestSigningVerificationService;

  @MockBean private CustomerService customerService;

  @MockBean private ScaCredentialsExtractor scaCredentialsExtractor;

  @MockBean private AreaDiallingCodesService areaDiallingCodesService;

  @BeforeEach
  void beforeEach() {
    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void shouldGetCustomerBasic(final String path) throws Exception {
    CustomerBasicResponse expectedCustomerBasicResponse = TestHelper.buildCustomerBasicResponse();

    LocalDateTime now = LocalDateTime.parse("2020-04-23T14:56:15");

    when(customerService.getCustomer(eq(PARTY_ID), eq(now)))
        .thenReturn(expectedCustomerBasicResponse.getCustomer());

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            content().json(objectMapper.writeValueAsString(expectedCustomerBasicResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED, PATH_CUSTOMER_DELAYED_PRIVATE})
  void shouldGetCustomerBasicDelayed(final String path) throws Exception {
    CustomerBasicResponse expectedCustomerBasicResponse = TestHelper.buildCustomerBasicResponse();

    LocalDateTime yesterday = LocalDateTime.parse("2020-04-22T23:59:59");

    when(customerService.getCustomer(eq(PARTY_ID), eq(yesterday)))
        .thenReturn(expectedCustomerBasicResponse.getCustomer());

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            content().json(objectMapper.writeValueAsString(expectedCustomerBasicResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void shouldGetCustomerDetails(final String path) throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    RequestMetadata expectedMetadata = buildRequestMetadata();

    String expectedJsonResponse = setGetCustomerDetailsExpectation(path, expectedMetadata);

    mvc.perform(
            get(path)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(jwtWithScope))
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(expectedJsonResponse, true));
  }

  private String setGetCustomerDetailsExpectation(
      final String path, final RequestMetadata expectedMetadata) throws JsonProcessingException {

    if (PATH_CUSTOMER_DETAILS.equals(path)) {
      final CustomerDetailsResponse expectedResponse =
          TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID_STRING);
      when(customerService.getCustomerDetails(expectedMetadata, GoldenCustomerRecord.class))
          .thenReturn(expectedResponse.getGoldenCustomerRecord());

      return objectMapper.writeValueAsString(expectedResponse);
    }

    final CustomerDetailsExtendedResponse expectedResponse =
        TestHelper.buildCustomerDetailsExtendedResponse(false, true, false, PARTY_ID_STRING);
    when(customerService.getCustomerDetails(expectedMetadata, GoldenCustomerExtendedRecord.class))
        .thenReturn(expectedResponse.getGoldenCustomerExtendedRecord());

    return objectMapper.writeValueAsString(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void shouldGetCustomerDetailsWhenWebCustomerNumberDifferentToPartyId(final String path)
      throws Exception {
    final String webCustomerNumber = "654321";
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE, webCustomerNumber);

    RequestMetadata expectedMetadata = buildRequestMetadata(webCustomerNumber);

    String expectedJsonResponse = setGetCustomerDetailsExpectation(path, expectedMetadata);

    mvc.perform(
            get(path)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(jwtWithScope))
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(expectedJsonResponse, true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnNotFoundIfCustomerNotFoundExceptionThrown(final String path)
      throws Exception {
    ErrorResponse errorResponse = TestHelper.buildErrorResponseNotFound(REQUEST_ID);

    when(customerService.getCustomer(anyLong(), any(LocalDateTime.class)))
        .thenThrow(new CustomerNotFoundException("", new Throwable()));

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED, PATH_CUSTOMER_DELAYED_PRIVATE})
  void getCustomerBasicDelayedShouldReturnNotFoundIfCustomerNotFoundExceptionThrown(
      final String path) throws Exception {
    ErrorResponse errorResponse = TestHelper.buildErrorResponseNotFound(REQUEST_ID);

    when(customerService.getCustomer(anyLong(), any(LocalDateTime.class)))
        .thenThrow(new CustomerNotFoundException("", new Throwable()));

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnInternalServerErrorIfCustomerServiceExceptionThrown(
      final String path) throws Exception {
    ErrorResponse errorResponse = TestHelper.buildErrorResponseInternalServerError(REQUEST_ID);

    when(customerService.getCustomer(anyLong(), any(LocalDateTime.class)))
        .thenThrow(new CustomerServiceException("", new Throwable()));

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED, PATH_CUSTOMER_DELAYED_PRIVATE})
  void getCustomerBasicDelayedShouldReturnInternalServerErrorIfCustomerServiceExceptionThrown(
      final String path) throws Exception {
    ErrorResponse errorResponse = TestHelper.buildErrorResponseInternalServerError(REQUEST_ID);

    when(customerService.getCustomer(anyLong(), any(LocalDateTime.class)))
        .thenThrow(new CustomerServiceException("", new Throwable()));

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void getCustomerDetailsShouldReturnInternalServerErrorIfCustomerServiceExceptionThrown(
      final String path) throws Exception {
    Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    ErrorResponse errorResponse = TestHelper.buildErrorResponseInternalServerError(REQUEST_ID);

    when(customerService.getCustomerDetails(any(), any()))
        .thenThrow(new CustomerServiceException("", new Throwable()));

    mvc.perform(
            get(path)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void getCustomerDetailsShouldReturnNotFoundIfCustomerNotFoundExceptionThrown(final String path)
      throws Exception {

    Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    ErrorResponse errorResponse = TestHelper.buildErrorResponseInternalServerError(REQUEST_ID);

    when(customerService.getCustomerDetails(any(), any()))
        .thenThrow(new CustomerNotFoundException("", new Throwable()));

    mvc.perform(
            get(path)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnBadRequestIfPartyIdIsNotANumber(final String path)
      throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse errorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid value")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message("Invalid field: partyId")
                    .build())
            .build();

    mvc.perform(
            get(path, "abc")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED, PATH_CUSTOMER_DELAYED_PRIVATE})
  void getCustomerBasicDelayedShouldReturnBadRequestIfPartyIdIsNotANumber(final String path)
      throws Exception {
    UUID requestId = UUID.randomUUID();

    ErrorResponse errorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid value")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message("Invalid field: partyId")
                    .build())
            .build();

    mvc.perform(
            get(path, "abc")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnBadRequestIfRequestIdIsNotAUUID(final String path)
      throws Exception {
    String requestId = "not-a-uuid";

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            jsonPath("$.id", notNullValue())) // Will be a different value to what we specified
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(HEADER_REQUEST_ID)));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED, PATH_CUSTOMER_DELAYED_PRIVATE})
  void getCustomerBasicDelayedShouldReturnBadRequestIfRequestIdIsNotAUUID(final String path)
      throws Exception {
    String requestId = "not-a-uuid";

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            jsonPath("$.id", notNullValue())) // Will be a different value to what we specified
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(HEADER_REQUEST_ID)));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnMethodNotSupportedIfMethodNotSupported(final String path)
      throws Exception {
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse = TestHelper.buildErrorResponseMethodNotSupported(requestId);
    mvc.perform(
            post(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.GET.name())));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED, PATH_CUSTOMER_DELAYED_PRIVATE})
  void getCustomerBasicDelayedShouldReturnMethodNotSupportedIfMethodNotSupported(final String path)
      throws Exception {
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse = TestHelper.buildErrorResponseMethodNotSupported(requestId);

    mvc.perform(
            post(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.GET.name())));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldIncludeResponseBodyIfUnexpectedSpringInternalExceptionThrown(
      final String path) throws Exception {
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException())
        .when(customerService)
        .getCustomer(anyLong(), any(LocalDateTime.class));

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED, PATH_CUSTOMER_DELAYED_PRIVATE})
  void getCustomerBasicDelayedShouldIncludeResponseBodyIfUnexpectedSpringInternalExceptionThrown(
      final String path) throws Exception {
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException())
        .when(customerService)
        .getCustomer(anyLong(), any(LocalDateTime.class));

    mvc.perform(
            get(path, PARTY_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void getCustomerDetailsShouldReturnBadRequestWhenScopeIsNotValid(final String path)
      throws Exception {
    UUID requestId = UUID.randomUUID();
    ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    mvc.perform(
            get(path)
                .with(jwt().jwt(jwtWithScope(OTHER_SCOPE)))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @ParameterizedTest
  @MethodSource("validEmails")
  void shouldUpdateEmailAddress() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final EmailAddress emailAddress = buildEmailAddressRequest();
    final String json = objectMapper.writeValueAsString(emailAddress);

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID))
        .andExpect(status().isAccepted());
  }

  @ParameterizedTest
  @MethodSource("invalidEmails")
  void shouldFailToUpdateEmailAddressAsInvalidEmail(final String email, final String errorMessage)
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final EmailAddress emailAddress = buildEmailAddressRequest(EMAIL_ADDRESS_TYPE, email);
    final String json = objectMapper.writeValueAsString(emailAddress);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message(errorMessage)
                    .path("email") // NOPMD
                    .build())
            .build();

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest
  @MethodSource("invalidEmailsMultipleErrors")
  void shouldFailToUpdateEmailAddressAsMultipleInvalidEmailErrors(
      final String email, final String errorOne, final String errorTwo) throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final EmailAddress emailAddress = buildEmailAddressRequest(EMAIL_ADDRESS_TYPE, email);
    final String json = objectMapper.writeValueAsString(emailAddress);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message(errorOne)
                    .path("email") // NOPMD
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message(errorTwo)
                    .path("email") // NOPMD
                    .build())
            .build();

    // Strictness set to false as the errors can come back in a different order
    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), false));
  }

  @ParameterizedTest
  @MethodSource("invalidTypes")
  void shouldFailToUpdateEmailAddressAsInvalidType(final String type, final String errorMessage)
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final EmailAddress emailAddress = buildEmailAddressRequest(type, EMAIL_ADDRESS);
    final String json = objectMapper.writeValueAsString(emailAddress);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message(errorMessage)
                    .path("type")
                    .build())
            .build();

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void shouldFailToUpdateEmailAddressWithMissingType() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final EmailAddress emailAddress = buildEmailAddressRequest(null, EMAIL_ADDRESS);
    final String json = objectMapper.writeValueAsString(emailAddress);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_MISSING_ERROR)
                    .message("You must specify an email type")
                    .path("type")
                    .build())
            .build();

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void shouldFailToUpdateEmailAddressWithMissingEmail() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final EmailAddress emailAddress = buildEmailAddressRequest(EMAIL_ADDRESS_TYPE, null);
    final String json = objectMapper.writeValueAsString(emailAddress);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_MISSING_ERROR)
                    .message("You must specify an email address")
                    .path("email") // NOPMD
                    .build())
            .build();

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateEmailAddressShouldReturnBadRequestWhenInvalidScaHeadersExceptionThrown()
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final EmailAddress emailAddress = buildEmailAddressRequest();
    final String json = objectMapper.writeValueAsString(emailAddress);

    final InvalidScaHeadersException exception =
        new InvalidScaHeadersException(
            "",
            Arrays.asList(SCA_HEADER_CHALLENGE, SCA_HEADER_KEY),
            Arrays.asList(SCA_HEADER_CHALLENGE, SCA_HEADER_CHALLENGE_RESPONSE, SCA_HEADER_KEY));

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(
                "Required SCA header missing - Required SCA headers: [x-ybs-sca-challenge, x-ybs-sca-challenge-response, x-ybs-sca-key]")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(HEADER_MISSING)
                    .message("Required SCA header missing: x-ybs-sca-challenge")
                    .path(SCA_HEADER_CHALLENGE)
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(HEADER_MISSING)
                    .message("Required SCA header missing: x-ybs-sca-key")
                    .path(SCA_HEADER_KEY)
                    .build())
            .build();

    doThrow(exception).when(customerService).updateEmailAddress(any(), any(), any());

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateEmailAddressShouldReturnBadRequestWhenInvalidPemKeyExceptionThrown() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final EmailAddress emailAddress = buildEmailAddressRequest();
    final String json = objectMapper.writeValueAsString(emailAddress);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message("SCA key could not be read")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("SCA key must be in PEM format and Base64 encoded")
                    .path(SCA_HEADER_KEY)
                    .build())
            .build();

    doThrow(InvalidPemKeyException.class)
        .when(customerService)
        .updateEmailAddress(any(), any(), any());

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateEmailAddressShouldReturnForbiddenWhenScaRequiredExceptionThrown() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final EmailAddress emailAddress = buildEmailAddressRequest();
    final String json = objectMapper.writeValueAsString(emailAddress);

    final ScaRequiredException exception = new ScaRequiredException(CHALLENGE);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(REQUEST_ID)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    doThrow(exception).when(customerService).updateEmailAddress(any(), any(), any());

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(header().string(SCA_HEADER_CHALLENGE, CHALLENGE))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateEmailAddressShouldReturnForbiddenWhenInvalidScaExceptionThrown() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final EmailAddress emailAddress = buildEmailAddressRequest();
    final String json = objectMapper.writeValueAsString(emailAddress);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(REQUEST_ID)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    doThrow(InvalidScaException.class)
        .when(customerService)
        .updateEmailAddress(any(), any(), any());

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updateEmailAddressShouldReturnForbiddenWhenScopeIsNotValid() throws Exception {
    final EmailAddress emailAddress = buildEmailAddressRequest();
    final String json = objectMapper.writeValueAsString(emailAddress);
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(REQUEST_ID)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    mvc.perform(
            post(PATH_EMAIL_UPDATE)
                .with(jwt().jwt(jwtWithScope(OTHER_SCOPE)))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @ParameterizedTest
  @MethodSource("validPhoneNumbers")
  void shouldUpdatePhoneNumber(final String type, final String phoneNumber) throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.valueOf(type), phoneNumber))
            .build();

    final String json = objectMapper.writeValueAsString(phoneNumberRequest);

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID))
        .andExpect(status().isAccepted());
  }

  @ParameterizedTest
  @MethodSource("invalidPhoneNumbers")
  void shouldFailToUpdatePhoneNumberAsInvalidPhoneNumber(
      final String type, final String number, final String errorMessage) throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final PhoneNumberRequest phoneNumber =
        PhoneNumberRequest.builder()
            .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.valueOf(type), number))
            .build();

    final String json = objectMapper.writeValueAsString(phoneNumber);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message(errorMessage)
                    .path("phoneNumbers[0].number")
                    .build())
            .build();

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void shouldFailToUpdatePhoneNumberAsInvalidType() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final String json =
        TestHelper.readClassPathResource("api/phoneNumberRequest/requestInvalidType.json");

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message("Unable to parse request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message("`gibberish` is not a valid PhoneNumberBasicType")
                    .path("phoneNumber.0.type")
                    .build())
            .build();

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void shouldFailToUpdatePhoneNumberAsDuplicateType() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final PhoneNumberRequest phoneNumber =
        PhoneNumberRequest.builder()
            .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.HOME, "01234 123456")) // NOPMD
            .phoneNumber(
                buildPhoneNumberBasic(PhoneNumberBasicType.MOBILE, "07234 123456")) // NOPMD
            .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.HOME, "01234 123457")) // NOPMD
            .build();

    final String json = objectMapper.writeValueAsString(phoneNumber);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message("Duplicate phone number type in request")
                    .path("phoneNumbers[2].type")
                    .build())
            .build();

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void shouldFailToUpdatePhoneNumberAsDuplicateTypesSetAsNullWithCorrectErrorMessage()
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final PhoneNumberRequest phoneNumber =
        PhoneNumberRequest.builder()
            .phoneNumber(buildPhoneNumberBasic(null, "01234 123456")) // NOPMD
            .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.MOBILE, "07234 123456"))
            .phoneNumber(buildPhoneNumberBasic(null, "01234 123457"))
            .build();

    final String json = objectMapper.writeValueAsString(phoneNumber);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_MISSING_ERROR)
                    .message("You must specify a phone number type")
                    .path("phoneNumbers[0].type")
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_MISSING_ERROR)
                    .message("You must specify a phone number type")
                    .path("phoneNumbers[2].type")
                    .build())
            .build();

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), false));
  }

  @Test
  void shouldFailToUpdatePhoneNumberWithMissingType() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final PhoneNumberRequest phoneNumber =
        PhoneNumberRequest.builder().phoneNumber(buildPhoneNumberBasic(null, "1234")).build();

    final String json = objectMapper.writeValueAsString(phoneNumber);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_MISSING_ERROR)
                    .message("You must specify a phone number type")
                    .path("phoneNumbers[0].type")
                    .build())
            .build();

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void shouldFailToUpdatePhoneNumberWhenPhoneNumbersEmpty() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final PhoneNumberRequest phoneNumber = PhoneNumberRequest.builder().build();
    final String json = objectMapper.writeValueAsString(phoneNumber);

    shouldFailWithAtLeastOnePhoneNumberShouldBeSpecified(jwtWithScope, json);
  }

  @Test
  void shouldFailToUpdatePhoneNumberAsMultipleErrors() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final PhoneNumberRequest phoneNumber =
        PhoneNumberRequest.builder()
            .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.HOME, "01234 123456")) // NOPMD
            .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.MOBILE, "123456"))
            .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.HOME, "01234 123457"))
            .build();

    final String json = objectMapper.writeValueAsString(phoneNumber);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message(PHONE_NUMBER_NOT_VALID)
                    .path("phoneNumbers[1].number")
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message("Duplicate phone number type in request")
                    .path("phoneNumbers[2].type")
                    .build())
            .build();

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), false));
  }

  private void shouldFailWithAtLeastOnePhoneNumberShouldBeSpecified(
      final Jwt jwtWithScope, final String phoneNumberRequestJson) throws Exception {

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message("At least one phone number must be specified")
                    .path("phoneNumbers")
                    .build())
            .build();

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(phoneNumberRequestJson)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void shouldFailToUpdatePhoneNumberWhenEmpty() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final String json = "{}";

    shouldFailWithAtLeastOnePhoneNumberShouldBeSpecified(jwtWithScope, json);
  }

  @Test
  void updatePhoneNumberShouldReturnBadRequestWhenInvalidScaHeadersExceptionThrown()
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PhoneNumberRequest phoneNumber = buildPhoneNumberRequest();
    final String json = objectMapper.writeValueAsString(phoneNumber);

    final InvalidScaHeadersException exception =
        new InvalidScaHeadersException(
            "",
            Arrays.asList(SCA_HEADER_CHALLENGE, SCA_HEADER_KEY),
            Arrays.asList(SCA_HEADER_CHALLENGE, SCA_HEADER_CHALLENGE_RESPONSE, SCA_HEADER_KEY));

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(
                "Required SCA header missing - Required SCA headers: [x-ybs-sca-challenge, x-ybs-sca-challenge-response, x-ybs-sca-key]")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(HEADER_MISSING)
                    .message("Required SCA header missing: x-ybs-sca-challenge")
                    .path(SCA_HEADER_CHALLENGE)
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(HEADER_MISSING)
                    .message("Required SCA header missing: x-ybs-sca-key")
                    .path(SCA_HEADER_KEY)
                    .build())
            .build();

    doThrow(exception).when(customerService).updatePhoneNumber(any(), any(), any());

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePhoneNumberShouldReturnBadRequestWhenInvalidPemKeyExceptionThrown() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PhoneNumberRequest phoneNumber = buildPhoneNumberRequest();
    final String json = objectMapper.writeValueAsString(phoneNumber);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message("SCA key could not be read")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("SCA key must be in PEM format and Base64 encoded")
                    .path(SCA_HEADER_KEY)
                    .build())
            .build();

    doThrow(InvalidPemKeyException.class)
        .when(customerService)
        .updatePhoneNumber(any(), any(), any());

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePhoneNumberShouldReturnForbiddenWhenScaRequiredExceptionThrown() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PhoneNumberRequest phoneNumber = buildPhoneNumberRequest();
    final String json = objectMapper.writeValueAsString(phoneNumber);

    final ScaRequiredException exception = new ScaRequiredException(CHALLENGE);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(REQUEST_ID)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    doThrow(exception).when(customerService).updatePhoneNumber(any(), any(), any());

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(header().string(SCA_HEADER_CHALLENGE, CHALLENGE))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePhoneNumberShouldReturnForbiddenWhenInvalidScaExceptionThrown() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PhoneNumberRequest phoneNumber = buildPhoneNumberRequest();
    final String json = objectMapper.writeValueAsString(phoneNumber);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(REQUEST_ID)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    doThrow(InvalidScaException.class).when(customerService).updatePhoneNumber(any(), any(), any());

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePhoneNumberShouldReturnForbiddenWhenScopeIsNotValid() throws Exception {
    final PhoneNumberRequest phoneNumber = buildPhoneNumberRequest();
    final String json = objectMapper.writeValueAsString(phoneNumber);
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(REQUEST_ID)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .with(jwt().jwt(jwtWithScope(OTHER_SCOPE)))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @ParameterizedTest(
      name =
          "updatePhoneNumberShouldReturnBadRequestWhenCustomerValidationExceptionThrown: {arguments}")
  @MethodSource("customerValidationExceptionReason")
  void updatePhoneNumberShouldReturnBadRequestWhenCustomerValidationExceptionThrown(
      final CustomerValidationExceptionReason reason,
      final int status,
      final String expectedErrorCode,
      final String expectedErrorMessage)
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PhoneNumberRequest phoneNumber = buildPhoneNumberRequest();
    final String json = objectMapper.writeValueAsString(phoneNumber);
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code(status + " " + HttpStatus.resolve(status).getReasonPhrase())
            .id(REQUEST_ID)
            .message("Customer validation error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(expectedErrorCode)
                    .message(expectedErrorMessage)
                    .build())
            .build();

    final CustomerValidationException exception = new CustomerValidationException("", reason);

    doThrow(exception).when(customerService).updatePhoneNumber(any(), any(), any());

    when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(Optional.of(1234));

    mvc.perform(
            post(PATH_PHONE_NUMBER_UPDATE)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID))
        .andExpect(status().is(status))
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @ParameterizedTest(name = "shouldUpdatePostalAddress: {index} {arguments}")
  @MethodSource("validPostCodes")
  void shouldUpdatePostalAddress(final String label, final String postCode) throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PostalAddressRequest request = buildPostalAddressRequest(postCode);
    final String json = objectMapper.writeValueAsString(request);

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isAccepted());
  }

  @Test
  void shouldFailToUpdatePostalAddressWithoutTooManyAddressLines() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PostalAddressRequest request =
        buildPostalAddressRequest(buildPostalAddressWithTooManyAddressLines(), buildPafData());
    final String json = objectMapper.writeValueAsString(request);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message("A maximum of 5 address lines is permitted")
                    .path("address.addressLines")
                    .build())
            .build();

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void shouldFailToUpdatePostalAddressWithoutAnAddressLine() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PostalAddressRequest request =
        buildPostalAddressRequest(buildPostalAddressWithNoAddressLines(), buildPafData());
    final String json = objectMapper.writeValueAsString(request);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(FIELD_INVALID_ERROR)
                    .message("You must have at least 1 address line")
                    .path("address.addressLines")
                    .build())
            .build();

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @ParameterizedTest(
      name = "shouldFailToUpdatePostalAddressWithInvalidRequest: {index} {arguments}")
  @MethodSource("invalidPostalAddresses")
  void shouldFailToUpdatePostalAddressWithInvalidRequest(
      final String label,
      final PostalAddress postalAddress,
      final PafData pafData,
      final String errorCode,
      final String errorMessage,
      final String errorPath)
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PostalAddressRequest request = buildPostalAddressRequest(postalAddress, pafData);
    final String json = objectMapper.writeValueAsString(request);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(errorCode)
                    .message(errorMessage)
                    .path(errorPath)
                    .build())
            .build();

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePostalAddressShouldReturnBadRequestWhenInvalidScaHeadersExceptionThrown()
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PostalAddressRequest request = buildPostalAddressRequest();
    final String json = objectMapper.writeValueAsString(request);

    final InvalidScaHeadersException exception =
        new InvalidScaHeadersException(
            "",
            Arrays.asList(SCA_HEADER_CHALLENGE, SCA_HEADER_KEY),
            Arrays.asList(SCA_HEADER_CHALLENGE, SCA_HEADER_CHALLENGE_RESPONSE, SCA_HEADER_KEY));

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message(
                "Required SCA header missing - Required SCA headers: [x-ybs-sca-challenge, x-ybs-sca-challenge-response, x-ybs-sca-key]")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(HEADER_MISSING)
                    .message("Required SCA header missing: x-ybs-sca-challenge")
                    .path(SCA_HEADER_CHALLENGE)
                    .build())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(HEADER_MISSING)
                    .message("Required SCA header missing: x-ybs-sca-key")
                    .path(SCA_HEADER_KEY)
                    .build())
            .build();

    doThrow(exception).when(customerService).updatePostalAddress(any(), any(), any());

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePostalAddressShouldReturnBadRequestWhenInvalidPemKeyExceptionThrown()
      throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PostalAddressRequest request = buildPostalAddressRequest();
    final String json = objectMapper.writeValueAsString(request);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(REQUEST_ID)
            .message("SCA key could not be read")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Header.Invalid")
                    .message("SCA key must be in PEM format and Base64 encoded")
                    .path(SCA_HEADER_KEY)
                    .build())
            .build();

    doThrow(InvalidPemKeyException.class)
        .when(customerService)
        .updatePostalAddress(any(), any(), any());

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePostalAddressShouldReturnForbiddenWhenScaRequiredExceptionThrown() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PostalAddressRequest request = buildPostalAddressRequest();
    final String json = objectMapper.writeValueAsString(request);

    final ScaRequiredException exception = new ScaRequiredException(CHALLENGE);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(REQUEST_ID)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    doThrow(exception).when(customerService).updatePostalAddress(any(), any(), any());

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(header().string(SCA_HEADER_CHALLENGE, CHALLENGE))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePostalAddressShouldReturnForbiddenWhenInvalidScaExceptionThrown() throws Exception {
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final PostalAddressRequest request = buildPostalAddressRequest();
    final String json = objectMapper.writeValueAsString(request);

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(REQUEST_ID)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    doThrow(InvalidScaException.class)
        .when(customerService)
        .updatePostalAddress(any(), any(), any());

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedErrorResponse), true));
  }

  @Test
  void updatePostalAddressShouldReturnForbiddenWhenScopeIsNotValid() throws Exception {
    final PostalAddressRequest request = buildPostalAddressRequest();
    final String json = objectMapper.writeValueAsString(request);
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(REQUEST_ID)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    mvc.perform(
            post(PATH_POSTAL_ADDRESS_UPDATE)
                .with(jwt().jwt(jwtWithScope(OTHER_SCOPE)))
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  private static Stream<FailureRequest> failureRequests() {
    return Stream.of(
        buildFailureRequestWithFailureType(FailureType.NON_POSTAL_ADDRESS),
        buildFailureRequestWithFailureType(FailureType.POSTAL_ADDRESS),
        FailureRequest.builder().challenge("the-challenge").build());
  }

  @MethodSource("failureRequests")
  @ParameterizedTest
  void reportFailureShouldReturnNoContentOnSuccess(final FailureRequest failureRequest)
      throws Exception {
    final RequestMetadata metadata = buildRequestMetadata();
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    mvc.perform(
            post(CHALLENGE_FAILURE_ENDPOINT)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .headers(standardHeaders(metadata.getRequestId().toString()))
                .content(objectMapper.writeValueAsBytes(failureRequest)))
        .andExpect(status().isNoContent());

    verify(customerService).reportFailure(failureRequest, metadata);
  }

  @Test
  void reportFailureShouldReturnForbiddenWhenBadFailureRequestChallengeExceptionIsThrown()
      throws Exception {
    final RequestMetadata metadata = buildRequestMetadata();
    final FailureRequest request =
        buildFailureRequestWithFailureType(FailureType.NON_POSTAL_ADDRESS);
    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(metadata.getRequestId())
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message("Authenticity of the challenge could not be validated")
                    .build())
            .build();

    doThrow(BadFailureRequestChallengeException.class)
        .when(customerService)
        .reportFailure(request, metadata);

    mvc.perform(
            post(CHALLENGE_FAILURE_ENDPOINT)
                .requestAttr(SESSION_ID_ATTRIBUTE_NAME, SESSION_ID)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .headers(standardHeaders(metadata.getRequestId().toString()))
                .content(objectMapper.writeValueAsBytes(request)))
        .andExpect(status().isForbidden())
        .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
        .andExpect(content().json(objectMapper.writeValueAsString(response)));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void shouldGetAvailableProducts(final String path) throws Exception {

    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final List<ProductCategory> productCategories = buildOnSaleProducts();

    when(customerService.getAvailableProducts(any())).thenReturn(productCategories);

    mvc.perform(
            get(path)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isOk())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(productCategories), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldIncludeResponseBodyIfUnexpectedSpringInternalExceptionThrown(
      final String path) throws Exception {

    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("503 Service Unavailable")
            .id(requestId)
            .message("Service Unavailable")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected Error")
                    .build())
            .build();

    // Fake an internal spring exception that we haven't implemented a specific handler for
    doThrow(new AsyncRequestTimeoutException()).when(customerService).getAvailableProducts(any());

    mvc.perform(
            get(path)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isServiceUnavailable())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnBadRequestIfRequestIdIsNotAUUID(final String path)
      throws Exception {
    final String requestId = "not-a-uuid";

    mvc.perform(
            get(path)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            jsonPath("$.id", notNullValue())) // Will be a different value to what we specified
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(HEADER_REQUEST_ID)));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnInternalServerErrorIfCustomerServiceExceptionThrown(
      final String path) throws Exception {
    final ErrorResponse errorResponse =
        TestHelper.buildErrorResponseInternalServerError(REQUEST_ID);

    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    when(customerService.getAvailableProducts(any()))
        .thenThrow(new CustomerServiceException("", new Throwable()));

    mvc.perform(
            get(path)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnMethodNotSupportedIfMethodNotSupported(final String path)
      throws Exception {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("405 Method Not Allowed")
            .id(requestId)
            .message("Method Not Allowed")
            .error(
                ErrorItem.builder()
                    .errorCode("Unsupported.Method")
                    .message("Unsupported method")
                    .build())
            .build();

    mvc.perform(
            post(path)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)))
        .andExpect(header().string(HttpHeaders.ALLOW, is(HttpMethod.GET.name())));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnNotFoundIfCustomerNotFoundExceptionThrown(final String path)
      throws Exception {
    final ErrorResponse errorResponse = TestHelper.buildErrorResponseNotFound(REQUEST_ID);

    final Jwt jwtWithScope = jwtWithScope(VALID_SCOPE);

    when(customerService.getAvailableProducts(any()))
        .thenThrow(new CustomerNotFoundException("", new Throwable()));

    mvc.perform(
            get(path)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnForbiddenWhenScopeIsNotValid(final String path)
      throws Exception {
    final UUID requestId = UUID.randomUUID();

    final Jwt jwtWithScope = jwtWithScope(OTHER_SCOPE);

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    mvc.perform(
            get(path)
                .with(jwt().jwt(jwtWithScope))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.HOST, HOST_HEADER_VALUE)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isForbidden())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse)));
  }

  private HttpHeaders standardHeaders(final String requestId) {
    final HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    httpHeaders.add(HttpHeaders.HOST, HOST_HEADER_VALUE);
    httpHeaders.add(HEADER_REQUEST_ID, requestId);
    return httpHeaders;
  }

  private Jwt jwtWithScope(final String scope) {
    return jwtWithScope(scope, PARTY_ID_STRING);
  }

  private Jwt jwtWithScope(final String scope, final String webCustomerNumber) {
    return Jwt.withTokenValue("<jwt>")
        .header("kid", "key-id")
        .subject(webCustomerNumber)
        .claim("scope", scope)
        .claim("brand_code", "YBS")
        .claim("party_id", PARTY_ID_STRING)
        .claim("sid", SESSION_ID.toString())
        .build();
  }

  private RequestMetadata buildRequestMetadata() {
    return buildRequestMetadata(PARTY_ID_STRING);
  }

  private RequestMetadata buildRequestMetadata(final String webCustomerNumber) {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .sessionId(SESSION_ID)
        .host(HOST)
        .partyId(PARTY_ID_STRING)
        .brandCode(BRAND_CODE_YBS)
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .webCustomerNumber(webCustomerNumber)
        .build();
  }

  private EmailAddress buildEmailAddressRequest() {
    return buildEmailAddressRequest(EMAIL_ADDRESS_TYPE, EMAIL_ADDRESS);
  }

  private EmailAddress buildEmailAddressRequest(final String type, final String email) {
    return EmailAddress.builder().type(type).email(email).build();
  }

  private PostalAddressRequest buildPostalAddressRequest() {
    return PostalAddressRequest.builder().address(buildPostalAddress()).paf(buildPafData()).build();
  }

  private PostalAddressRequest buildPostalAddressRequest(final String postCode) {
    return PostalAddressRequest.builder()
        .address(buildPostalAddress(postCode))
        .paf(buildPafData())
        .build();
  }

  private PostalAddressRequest buildPostalAddressRequest(
      final PostalAddress postalAddress, final PafData pafData) {
    return PostalAddressRequest.builder().address(postalAddress).paf(pafData).build();
  }

  private static PostalAddress buildPostalAddress() {
    return PostalAddress.builder()
        .type(PostalAddress.PostalAddressType.CORR)
        .subType(PostalAddress.PostalAddressSubType.UKPOST)
        .addressLines(Collections.singleton("Broad Gate"))
        .addressLines(Collections.singleton("The Headrow"))
        .postCode(POSTCODE)
        .country(PermittedCountries.UNITED_KINGDOM)
        .build();
  }

  private static PostalAddress buildPostalAddress(final String postCode) {
    return PostalAddress.builder()
        .type(PostalAddress.PostalAddressType.CORR)
        .subType(PostalAddress.PostalAddressSubType.UKPOST)
        .addressLines(Collections.singleton("Broad Gate"))
        .addressLines(Collections.singleton("The Headrow"))
        .postCode(postCode)
        .country(PermittedCountries.UNITED_KINGDOM)
        .build();
  }

  private static PostalAddress buildPostalAddress(
      final String addressLines, final String postCode, final PermittedCountries country) {
    return PostalAddress.builder()
        .type(PostalAddress.PostalAddressType.CORR)
        .subType(PostalAddress.PostalAddressSubType.UKPOST)
        .addressLines(Arrays.asList(addressLines))
        .postCode(postCode)
        .country(country)
        .build();
  }

  private static PostalAddress buildPostalAddressWithNoAddressLines() {
    return PostalAddress.builder()
        .type(PostalAddress.PostalAddressType.CORR)
        .subType(PostalAddress.PostalAddressSubType.UKPOST)
        .postCode(POSTCODE)
        .country(PermittedCountries.UNITED_KINGDOM)
        .build();
  }

  private static PostalAddress buildPostalAddressWithTooManyAddressLines() {
    return PostalAddress.builder()
        .type(PostalAddress.PostalAddressType.CORR)
        .subType(PostalAddress.PostalAddressSubType.UKPOST)
        .addressLines(Collections.singleton("Valid 1"))
        .addressLines(Collections.singleton("Valid 2"))
        .addressLines(Collections.singleton("Valid 3"))
        .addressLines(Collections.singleton("Valid 4"))
        .addressLines(Collections.singleton("Valid 5"))
        .addressLines(Collections.singleton("Invalid 6"))
        .postCode(POSTCODE)
        .country(PermittedCountries.UNITED_KINGDOM)
        .build();
  }

  private static PafData buildPafData() {
    return PafData.builder().addressKey(12345678).deliveryPointSuffix("1TA").build(); // NOPMD
  }

  private static PafData buildPafData(final Integer addressKey, final String deliveryPointSuffix) {

    return PafData.builder()
        .addressKey(addressKey)
        .deliveryPointSuffix(deliveryPointSuffix)
        .build();
  }

  private PhoneNumberRequest buildPhoneNumberRequest() {

    return PhoneNumberRequest.builder()
        .phoneNumber(buildPhoneNumberBasic(PhoneNumberBasicType.HOME, "01234 123456")) // NOPMD
        .build();
  }

  private PhoneNumberBasic buildPhoneNumberBasic(
      final PhoneNumberBasicType type, final String number) {
    return PhoneNumberBasic.builder().type(type).number(number).build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> invalidPostalAddresses() {
    return Stream.of(
        Arguments.of(
            "Missing Address",
            null,
            buildPafData(12345678, "1TA"), // NOPMD
            FIELD_MISSING_ERROR,
            "You must specify an address",
            "address"),
        Arguments.of(
            "Missing Country",
            buildPostalAddress("1 Main Road", POSTCODE, null),
            buildPafData(12345678, "1TA"), // NOPMD
            FIELD_MISSING_ERROR,
            "You must specify a country",
            "address.country"),
        Arguments.of(
            "Missing Post Code",
            buildPostalAddress("1 Main Road", null, PermittedCountries.GUERNSEY),
            buildPafData(),
            FIELD_MISSING_ERROR,
            "You must specify a post code",
            "address.postCode"),
        Arguments.of(
            "Invalid Post Code with only white space",
            buildPostalAddress("1 Main Road", " ", PermittedCountries.JERSEY),
            buildPafData(),
            FIELD_INVALID_ERROR,
            POST_CODE_ERROR,
            "address.postCode"),
        Arguments.of(
            "Invalid Post Code with non-alpha-numeric character",
            buildPostalAddress("1 Main Road", "LS1 @TR", PermittedCountries.JERSEY),
            buildPafData(),
            FIELD_INVALID_ERROR,
            POST_CODE_ERROR,
            "address.postCode"),
        Arguments.of(
            "Invalid UK Post Code",
            buildPostalAddress("1 Main Road", "L1PT", PermittedCountries.UNITED_KINGDOM),
            buildPafData(),
            FIELD_INVALID_ERROR,
            POST_CODE_ERROR,
            "address.postCode"),
        Arguments.of(
            "Valid Non-UK Post Code (Spain)",
            buildPostalAddress("1 Main Road", "08040", PermittedCountries.JERSEY),
            buildPafData(),
            FIELD_INVALID_ERROR,
            POST_CODE_ERROR,
            "address.postCode"),
        Arguments.of(
            "Missing PAF Address Key",
            buildPostalAddress("1 Main Road", POSTCODE, PermittedCountries.UNITED_KINGDOM),
            buildPafData(null, "1TA"),
            FIELD_MISSING_ERROR,
            "You must specify an address key",
            "paf.addressKey"),
        Arguments.of(
            "Missing PAF Delivery Point Suffix",
            buildPostalAddress("1 Main Road", POSTCODE, PermittedCountries.UNITED_KINGDOM),
            buildPafData(12345678, null),
            FIELD_MISSING_ERROR,
            "You must specify a delivery point suffix",
            "paf.deliveryPointSuffix"),
        Arguments.of(
            "Invalid PAF Delivery Point Suffix",
            buildPostalAddress("1 Main Road", POSTCODE, PermittedCountries.UNITED_KINGDOM),
            buildPafData(12345678, " "),
            FIELD_INVALID_ERROR,
            "Delivery Point Suffix must contain at least one non-whitespace character",
            "paf.deliveryPointSuffix"));
  }

  private static Stream<Arguments> validPostCodes() {
    return Stream.of(
        Arguments.of("England", "WF10 1BP"),
        Arguments.of("Northern Ireland", "BT79 0QN"),
        Arguments.of("Scotland", "EH2 2DY"),
        Arguments.of("Wales", "LL30 2PD"),
        Arguments.of("Isle of Man", "IM8 1RT"),
        Arguments.of("Guernsey", "GY1 1HB"),
        Arguments.of("Jersey", "JE2 4TU"),
        Arguments.of("England - Long Postcode", "SW1W 0NY"),
        Arguments.of("England - Short Postcode", "L1 8JQ"),
        Arguments.of("England - No Space Postcode", "WF101BP"),
        Arguments.of("England - Mixed Case Postcode", "Wf10 1bp"),
        Arguments.of("England - Lower Case Postcode", "wf10 1bp"));
  }

  private static Stream<Arguments> invalidEmails() {
    return Stream.of(
        Arguments.of("testybs.com", INVALID_EMAIL_ERROR),
        Arguments.of("test@ybs", INVALID_EMAIL_ERROR),
        Arguments.of("test@ybs.co.u", INVALID_EMAIL_ERROR),
        Arguments.of("a@b.c", INVALID_EMAIL_ERROR),
        Arguments.of("testybs.com", INVALID_EMAIL_ERROR),
        Arguments.of(
            "test@testxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx.com",
            "Email address must be no longer than 70 characters"),
        Arguments.of("xxxxxxxxxxxx", INVALID_EMAIL_ERROR));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> invalidPhoneNumbers() {
    return Stream.of(
        Arguments.of(
            "HOME",
            "",
            "Phone number if present must contain at least one non-whitespace character"),
        Arguments.of("HOME", "999", "Phone Number not a valid landline number"),
        Arguments.of("WORK", "999", "Phone Number not a valid landline or mobile number"),
        Arguments.of("MOBILE", "020 1234 1234", PHONE_NUMBER_NOT_VALID),
        Arguments.of("MOBILE", "07025648914", PHONE_NUMBER_NOT_VALID),
        Arguments.of("MOBILE", "07615648914", PHONE_NUMBER_NOT_VALID),
        Arguments.of("MOBILE", "07635648914", PHONE_NUMBER_NOT_VALID),
        Arguments.of("MOBILE", "07665648914", PHONE_NUMBER_NOT_VALID));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> invalidEmailsMultipleErrors() {
    return Stream.of(
        Arguments.of(
            " ", "Email must contain at least one non-whitespace character", INVALID_EMAIL_ERROR),
        Arguments.of(
            "", "Email must contain at least one non-whitespace character", INVALID_EMAIL_ERROR),
        Arguments.of(
            "\t", "Email must contain at least one non-whitespace character", INVALID_EMAIL_ERROR),
        Arguments.of(
            "\n", "Email must contain at least one non-whitespace character", INVALID_EMAIL_ERROR));
  }

  private static Stream<String> validEmails() {
    return Stream.of("jase@banjo.com", "trevor@bt.com.uk", "katy@talktalk.com");
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> validPhoneNumbers() {
    return Stream.of(
        Arguments.of("MOBILE", "07125648745"),
        Arguments.of("MOBILE", "07225648914"),
        Arguments.of("MOBILE", "07325648845"),
        Arguments.of("MOBILE", "07425648963"),
        Arguments.of("MOBILE", "07525644584"),
        Arguments.of("MOBILE", "07825644584"),
        Arguments.of("MOBILE", "07925644584"),
        Arguments.of("WORK", "01234 896357"),
        Arguments.of("WORK", "07725621414"),
        Arguments.of("HOME", "01234 589647"),
        Arguments.of("HOME", "01234 154894"),
        Arguments.of("HOME", "01234 123456"));
  }

  private static Stream<Arguments> invalidTypes() {
    return Stream.of(
        Arguments.of(" ", INVALID_EMAIL_ERROR_NON_WHITESPACE),
        Arguments.of("\t", INVALID_EMAIL_ERROR_NON_WHITESPACE),
        Arguments.of("\n", INVALID_EMAIL_ERROR_NON_WHITESPACE),
        Arguments.of("", INVALID_EMAIL_ERROR_NON_WHITESPACE));
  }

  private static Stream<Arguments> customerValidationExceptionReason() {

    return Stream.of(
        Arguments.of(
            CustomerValidationExceptionReason.NO_CHANGES_DETECTED,
            409,
            "Rejected.NoChangesDetected",
            "No changes to the contact details have been detected"),
        Arguments.of(
            CustomerValidationExceptionReason.MIN_PHONE_NUMBERS,
            400,
            "Rejected.MinPhoneNumber",
            "Unable to remove phone number as customer must have at least one"));
  }

  /* Customer delayed record from ADG Core Tests --- Start */

  /**
   * Checks Resource Not Found Exception for no record match
   *
   * @param path path to invoke customer delayed post resource
   * @throws Exception exception to be thrown
   */
  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED_POST_PRIVATE})
  void getCustomerDelayedShouldReturnResourceNotFoundExceptionIfCustomerNotFound(final String path)
      throws Exception {

    final ErrorResponse errorResponse = TestHelper.buildErrorResponseNotFound(REQUEST_ID);
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final String json = objectMapper.writeValueAsString(customerDelayedRequest);

    when(customerService.getCustomerDelayed(
            any(CustomerDelayedRequest.class), any(LocalDateTime.class)))
        .thenThrow(new CustomerNotFoundException("", new Throwable()));

    mockMVCPerformAndAssertsForFailure(path, json, errorResponse, status().isNotFound(), true);
  }

  /**
   * Checks multiple records found Exception for multiple records match
   *
   * @param path path to invoke customer delayed post resource
   * @throws Exception exception to be thrown
   */
  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED_POST_PRIVATE})
  void getCustomerDelayedShouldReturnMultipleRecordsFoundExceptionIfMultipleCustomersFound(
      final String path) throws Exception {

    final ErrorResponse errorResponse =
        TestHelper.buildErrorResponseMultipleRecordsFound(REQUEST_ID);
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final String json = objectMapper.writeValueAsString(customerDelayedRequest);

    when(customerService.getCustomerDelayed(
            any(CustomerDelayedRequest.class), any(LocalDateTime.class)))
        .thenThrow(new MultipleRecordsFoundException("", new Throwable()));

    mockMVCPerformAndAssertsForFailure(path, json, errorResponse, status().isConflict(), true);
  }

  /**
   * checks the customer record for web and non web customer
   *
   * @param path path to invoke customer delayed post resource
   * @throws Exception exception to be thrown
   */
  @ParameterizedTest
  @MethodSource("getCustomerRecord")
  void getCustomerDelayedShouldReturnCustomerRecordForWebAndNonWebCustomer(
      final String path,
      final CustomerDelayedRequest customerDelayedRequest,
      final CustomerBasicResponse expectedCustomerDelayedNonWebResponse)
      throws Exception {

    final String json = objectMapper.writeValueAsString(customerDelayedRequest);
    final LocalDateTime yesterday = LocalDateTime.parse("2020-04-22T23:59:59");

    when(customerService.getCustomerDelayed(customerDelayedRequest, yesterday))
        .thenReturn(expectedCustomerDelayedNonWebResponse.getCustomer());

    mockMVCPerformAndAssertsForSuccess(
        path, json, expectedCustomerDelayedNonWebResponse, status().isOk(), true);
  }

  /**
   * Checks unmatched forename, date of birth, postcode and mobile number
   *
   * @param path path to invoke customer delayed post resource
   * @param customerDelayedRequest request payload to validate
   * @param expectedErrorResponse expected customer response for the request
   * @param status resource not found status
   */
  @ParameterizedTest
  @MethodSource("inCorrectFields")
  void shouldFailToGetCustomerDelayedAsInCorrectFields(
      final String path,
      final CustomerDelayedRequest customerDelayedRequest,
      final ErrorResponse expectedErrorResponse,
      final ResultMatcher status)
      throws Exception {

    final String json = objectMapper.writeValueAsString(customerDelayedRequest);

    when(customerService.getCustomerDelayed(
            any(CustomerDelayedRequest.class), any(LocalDateTime.class)))
        .thenThrow(new CustomerNotFoundException("", new Throwable()));

    mockMVCPerformAndAssertsForFailure(path, json, expectedErrorResponse, status, true);
  }

  /**
   * Validates forename, date of birth, postcode and mobile number values
   *
   * @param path path to invoke customer delayed post resource
   * @param customerDelayedRequest request payload to validate
   * @param expectedErrorResponse expected customer response for the request
   * @param status bad request status
   */
  @ParameterizedTest
  @MethodSource("inValidFields")
  void shouldFailToGetCustomerDelayedAsInValidFields(
      final String path,
      final CustomerDelayedRequest customerDelayedRequest,
      final ErrorResponse expectedErrorResponse,
      final ResultMatcher status)
      throws Exception {

    final String json = objectMapper.writeValueAsString(customerDelayedRequest);

    mockMVCPerformAndAssertsForFailure(path, json, expectedErrorResponse, status, true);
  }

  /**
   * checks the customer record for valid input fields
   *
   * @param path path to invoke customer delayed post resource
   * @param customerDelayedRequest request payload to validate
   * @throws Exception exception to be thrown
   */
  @ParameterizedTest
  @MethodSource("validFields")
  void getCustomerDelayedShouldReturnCustomerRecordForValidFields(
      final String path, final CustomerDelayedRequest customerDelayedRequest) throws Exception {

    final CustomerBasicResponse expectedCustomerDelayedResponse =
        TestHelper.buildCustomerDelayedResponse();
    final String json = objectMapper.writeValueAsString(customerDelayedRequest);
    final LocalDateTime yesterday = LocalDateTime.parse("2020-04-22T23:59:59");

    when(customerService.getCustomerDelayed(customerDelayedRequest, yesterday))
        .thenReturn(expectedCustomerDelayedResponse.getCustomer());

    mockMVCPerformAndAssertsForSuccess(
        path, json, expectedCustomerDelayedResponse, status().isOk(), true);
  }

  /**
   * Internal Server Error Scenario
   *
   * @param path path to invoke customer delayed post resource
   * @throws Exception exception to be thrown
   */
  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED_POST_PRIVATE})
  void getCustomerDelayedShouldReturnInternalServerErrorIfCustomerServiceExceptionThrown(
      final String path) throws Exception {

    final ErrorResponse errorResponse =
        TestHelper.buildErrorResponseInternalServerError(REQUEST_ID);
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final String json = objectMapper.writeValueAsString(customerDelayedRequest);

    when(customerService.getCustomerDelayed(
            any(CustomerDelayedRequest.class), any(LocalDateTime.class)))
        .thenThrow(new CustomerServiceException("", new Throwable()));

    mockMVCPerformAndAssertsForFailure(
        path, json, errorResponse, status().isInternalServerError(), true);
  }

  /**
   * Checks Bad Request for an invalid UUID
   *
   * @param path path to invoke customer delayed post resource
   * @throws Exception exception to be thrown
   */
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @ParameterizedTest(name = "{displayName} {arguments}") // NOPMD
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED_POST_PRIVATE})
  void getCustomerDelayedForUsernameRecoveryShouldReturnBadRequestIfRequestIdIsNotAUUID(
      final String path) throws Exception {
    final String requestId = "not-a-uuid";
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final String json = objectMapper.writeValueAsString(customerDelayedRequest);

    mvc.perform(
            post(path)
                .contentType(MediaType.APPLICATION_JSON)
                .content(json)
                .accept(MediaType.APPLICATION_JSON)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            jsonPath("$.id", notNullValue())) // Will be a different value to what we specified
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(HEADER_REQUEST_ID)));
  }

  private static Stream<Arguments> getCustomerRecord() {
    return Stream.of(
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomerDelayedRequest(),
            TestHelper.buildCustomerDelayedNonWebResponse()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomerDelayedRequest(),
            TestHelper.buildCustomerDelayedResponse()));
  }

  private static Stream<Arguments> inCorrectFields() {
    return Stream.of(
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("rakesh"),
            TestHelper.buildErrorResponseNotFound(REQUEST_ID),
            status().isNotFound()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("smith joe"),
            TestHelper.buildErrorResponseNotFound(REQUEST_ID),
            status().isNotFound()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("smith"),
            TestHelper.buildErrorResponseNotFound(REQUEST_ID),
            status().isNotFound()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("PO770DE"),
            TestHelper.buildErrorResponseNotFound(REQUEST_ID),
            status().isNotFound()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("07123456789"),
            TestHelper.buildErrorResponseNotFound(REQUEST_ID),
            status().isNotFound()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomDateOfBirthCustomerDelayedRequest("1900-01-01"),
            TestHelper.buildErrorResponseNotFound(REQUEST_ID),
            status().isNotFound()));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> inValidFields() {
    return Stream.of(
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest(null),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_MISSING_ERROR, "You must specify forename", "forename"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("joe123"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, "Please specify valid forename", "forename"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("J"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID,
                FIELD_INVALID_ERROR,
                "Forenames must be between 2 and 70 characters in length",
                "forename"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest(
                "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID,
                FIELD_INVALID_ERROR,
                "Forenames must be between 2 and 70 characters in length",
                "forename"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomDateOfBirthCustomerDelayedRequest(null),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_MISSING_ERROR, "You must specify date of birth", "dateOfBirth"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomDateOfBirthCustomerDelayedRequest(" "),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID,
                FIELD_INVALID_ERROR,
                "Date Of Birth must contain at least one non-whitespace character",
                "dateOfBirth"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest(null),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_MISSING_ERROR, "You must specify mobile number", "mobileNumber"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest(" "),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, MUST_BE_VALID_UK_MOBILE_NUMBER, "mobileNumber"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("020 1234 1234"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, MUST_BE_VALID_UK_MOBILE_NUMBER, "mobileNumber"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("071234567890"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, MUST_BE_VALID_UK_MOBILE_NUMBER, "mobileNumber"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("07040JPSDLW"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, MUST_BE_VALID_UK_MOBILE_NUMBER, "mobileNumber"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest(null),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_MISSING_ERROR, "You must specify post code", "postCode"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest(" "),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, POST_CODE_ERROR, "postCode"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("LS1 @TR"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, POST_CODE_ERROR, "postCode"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("L1PT"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, POST_CODE_ERROR, "postCode"),
            status().isBadRequest()),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("08040"),
            TestHelper.buildErrorResponseInvalidField(
                REQUEST_ID, FIELD_INVALID_ERROR, POST_CODE_ERROR, "postCode"),
            status().isBadRequest()));
  }

  private static Stream<Arguments> validFields() {
    return Stream.of(
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("Joe")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("JOE")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("joe")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("Joe Smith")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("JOE SMITH")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("joe smith")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("po570de")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("po57 0De")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("po570De")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("07515059347")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomDateOfBirthCustomerDelayedRequest(
                LocalDate.now().minusYears(18).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))));
  }

  private void mockMVCPerformAndAssertsForSuccess(
      final String path,
      final String input,
      final CustomerBasicResponse expectedCustomerDelayedResponse,
      final ResultMatcher resultMatcher,
      final Boolean strictness)
      throws Exception {
    mvc.perform(
            post(path)
                .contentType(MediaType.APPLICATION_JSON)
                .content(input)
                .accept(MediaType.APPLICATION_JSON)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(resultMatcher)
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(
            content()
                .json(
                    objectMapper.writeValueAsString(expectedCustomerDelayedResponse), strictness));
  }

  private void mockMVCPerformAndAssertsForFailure(
      final String path,
      final String input,
      final ErrorResponse errorResponse,
      final ResultMatcher resultMatcher,
      final Boolean strictness)
      throws Exception {
    mvc.perform(
            post(path)
                .contentType(MediaType.APPLICATION_JSON)
                .content(input)
                .accept(MediaType.APPLICATION_JSON)
                .header(HEADER_REQUEST_ID, REQUEST_ID)
                .header(HEADER_BRAND_CODE, BRAND_CODE_YBS))
        .andExpect(resultMatcher)
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), strictness));
  }
  /* Customer delayed record from ADG Database Tests --- End */
}
