package uk.co.ybs.digital.customer.repository.digitalcustomer;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.net.InetSocketAddress;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import uk.co.ybs.digital.customer.config.JpaAuditingConfig;
import uk.co.ybs.digital.customer.config.TestClockConfig;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Status;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogRequest;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@YbsDataJpaTest
@Import({JpaAuditingConfig.class, TestClockConfig.class})
public class WorkLogRepositoryTest {

  private static final String EMAIL_ADDRESS = "abc@dummy.ybs.co.uk";
  private static final String IP_ADDRESS = "1.2.3.4";
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final Long PARTY_ID = 1234567890L;
  private static final String BRAND_CODE = "YBS";
  private static final LocalDateTime CREATED_DATE = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final InetSocketAddress HOST = InetSocketAddress.createUnresolved("host", 443);
  private static final UUID REQUEST_ID = UUID.fromString("3cfa397f-ff5d-4252-b8f0-69daac23fba4");
  private static final UUID SESSION_ID = UUID.fromString("862ddff4-2b6d-4dda-b4d2-98cfcf83ab60");

  @Autowired private WorkLogRepository testSubject;

  @Autowired private TestEntityManager digitalCustomerTestEntityManager;

  private static WorkLog buildWorkLogUpdateEmailAddress() {
    return buildWorkLogWithStatus(
        Status.PENDING, Operation.EMAIL_ADDRESS, TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS));
  }

  private static WorkLog buildWorkLogUpdatePhoneNumber() {
    return buildWorkLogWithStatus(
        Status.PENDING,
        Operation.UPDATE_PHONE_NUMBER,
        TestHelper.buildUpdateHomePhoneNumberPayload());
  }

  private static WorkLog buildWorkLogUpdateMobilePhoneNumber() {
    return buildWorkLogWithStatus(
        Status.PENDING,
        Operation.UPDATE_PHONE_NUMBER,
        TestHelper.buildUpdateMobilePhoneNumberPayload());
  }

  private static WorkLog buildWorkLogDeletePhoneNumber() {
    return buildWorkLogWithStatus(
        Status.PENDING,
        Operation.DELETE_PHONE_NUMBER,
        TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.MOBILE));
  }

  private static WorkLog buildWorkLogUpdatePostalAddress() {
    return buildWorkLogWithStatus(
        Status.PENDING, Operation.POSTAL_ADDRESS, TestHelper.buildUpdatePostalAddressPayload());
  }

  private static WorkLog buildWorkLogWithStatus(
      final Status status, final Operation operation, final WorkLogPayload workLogPayload) {
    return WorkLog.builder()
        .partyId(PARTY_ID)
        .status(status)
        .operation(operation)
        .message(
            WorkLogRequest.builder()
                .workLogPayload(workLogPayload)
                .metadata(
                    RequestMetadata.builder()
                        .ipAddress(IP_ADDRESS)
                        .sessionId(SESSION_ID)
                        .forwardingAuth(FORWARDING_AUTH)
                        .partyId(Long.toString(PARTY_ID))
                        .brandCode(BRAND_CODE)
                        .host(HOST)
                        .requestId(REQUEST_ID)
                        .webCustomerNumber(Long.toString(PARTY_ID))
                        .build())
                .build())
        .build();
  }

  private static Stream<Arguments> workLogTypes() {
    return Stream.of(
        Arguments.of(buildWorkLogUpdateEmailAddress()),
        Arguments.of(buildWorkLogUpdatePhoneNumber()),
        Arguments.of(buildWorkLogDeletePhoneNumber()),
        Arguments.of(buildWorkLogUpdatePostalAddress()));
  }

  private static Stream<Arguments> pendingPhoneNumberTypes() {
    return Stream.of(
        Arguments.of(buildWorkLogUpdatePhoneNumber()),
        Arguments.of(buildWorkLogDeletePhoneNumber()));
  }

  @ParameterizedTest
  @MethodSource("workLogTypes")
  void shouldPersistWorkLogAndFindById(final WorkLog workLog) {
    Long sysId = digitalCustomerTestEntityManager.persistAndFlush(workLog).getSysId();
    digitalCustomerTestEntityManager.clear();

    final Optional<WorkLog> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(workLog));
  }

  @ParameterizedTest
  @MethodSource("pendingPhoneNumberTypes")
  void shouldPersistWorkLogAndFindPendingUpdateAndDeleteById(final WorkLog workLog) {
    digitalCustomerTestEntityManager.persistAndFlush(workLog).getSysId();
    digitalCustomerTestEntityManager.clear();

    final List<WorkLog> messages =
        testSubject.findPendingWorkLogByPartyIdAndUpdateDeletePhoneNumber(PARTY_ID);

    assertThat(messages.size(), is(1));
  }

  @Test
  void findRequestsInStateShouldReturnEmptyListIfNoRequestsInDesiredState() {
    final WorkLog workLogUpdateEmailAddress =
        buildWorkLogWithStatus(
            Status.COMPLETE,
            Operation.EMAIL_ADDRESS,
            TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS));
    digitalCustomerTestEntityManager.persist(workLogUpdateEmailAddress);

    final WorkLog workLogUpdatePhoneNumber =
        buildWorkLogWithStatus(
            Status.COMPLETE,
            Operation.UPDATE_PHONE_NUMBER,
            TestHelper.buildUpdateHomePhoneNumberPayload());
    digitalCustomerTestEntityManager.persist(workLogUpdatePhoneNumber);

    final WorkLog workLogDeletePhoneNumber =
        buildWorkLogWithStatus(
            Status.COMPLETE,
            Operation.DELETE_PHONE_NUMBER,
            TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.MOBILE));
    digitalCustomerTestEntityManager.persist(workLogDeletePhoneNumber);

    final WorkLog anotherWorkLogUpdateEmailAddress =
        buildWorkLogWithStatus(
            WorkLog.Status.FAILED,
            Operation.EMAIL_ADDRESS,
            TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS));
    digitalCustomerTestEntityManager.persist(anotherWorkLogUpdateEmailAddress);

    final WorkLog anotherWorkLogUpdatePhoneNumber =
        buildWorkLogWithStatus(
            WorkLog.Status.FAILED,
            Operation.UPDATE_PHONE_NUMBER,
            TestHelper.buildUpdateMobilePhoneNumberPayload());
    digitalCustomerTestEntityManager.persist(anotherWorkLogUpdatePhoneNumber);

    final WorkLog workLogUpdatePostalAddress =
        buildWorkLogWithStatus(
            WorkLog.Status.FAILED,
            Operation.POSTAL_ADDRESS,
            TestHelper.buildUpdatePostalAddressPayload());
    digitalCustomerTestEntityManager.persist(workLogUpdatePostalAddress);

    final WorkLog anotherworkLogUpdatePostalAddress =
        buildWorkLogWithStatus(
            WorkLog.Status.FAILED,
            Operation.UPDATE_PHONE_NUMBER,
            TestHelper.buildUpdatePostalAddressPayload());

    digitalCustomerTestEntityManager.persist(anotherworkLogUpdatePostalAddress);

    digitalCustomerTestEntityManager.flush();
    digitalCustomerTestEntityManager.clear();

    final List<WorkLog> found = testSubject.findRequestsInState(WorkLog.Status.PENDING);

    assertThat(found.isEmpty(), is(true));
  }

  @Test
  void findRequestsInStateShouldReturnPendingRequests() {
    final WorkLog firstWorkLog =
        buildWorkLogUpdateEmailAddress().toBuilder().createdDate(CREATED_DATE).build();
    digitalCustomerTestEntityManager.persist(firstWorkLog);

    final WorkLog secondWorkLog =
        buildWorkLogUpdateEmailAddress().toBuilder().createdDate(CREATED_DATE.plusHours(1)).build();
    digitalCustomerTestEntityManager.persist(secondWorkLog);

    digitalCustomerTestEntityManager.flush();
    digitalCustomerTestEntityManager.clear();

    final List<WorkLog> found = testSubject.findRequestsInState(WorkLog.Status.PENDING);

    assertThat(found.isEmpty(), is(not(true)));
    assertThat(
        found, contains(samePropertyValuesAs(firstWorkLog), samePropertyValuesAs(secondWorkLog)));
  }

  @Test
  void findPendingRequestsByPartyIdForUpdateAndDeleteShouldReturnPendingRequests() {
    final WorkLog firstWorkLog =
        buildWorkLogUpdatePhoneNumber().toBuilder().createdDate(CREATED_DATE).build();
    digitalCustomerTestEntityManager.persist(firstWorkLog);

    final WorkLog secondWorkLog =
        buildWorkLogDeletePhoneNumber().toBuilder().createdDate(CREATED_DATE).build();
    digitalCustomerTestEntityManager.persist(secondWorkLog);

    digitalCustomerTestEntityManager.flush();
    digitalCustomerTestEntityManager.clear();

    final List<WorkLog> found =
        testSubject.findPendingWorkLogByPartyIdAndUpdateDeletePhoneNumber(PARTY_ID);

    assertThat(found.isEmpty(), is(not(true)));

    assertThat(found.size(), is(2));
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void findPendingRequestsByPartyIdForDifferentPhoneTypesShouldReturnPendingRequests(
      final WorkLog workLog) {

    digitalCustomerTestEntityManager.persist(workLog);

    digitalCustomerTestEntityManager.flush();
    digitalCustomerTestEntityManager.clear();

    final List<WorkLog> found =
        testSubject.findPendingWorkLogByPartyIdAndUpdateDeletePhoneNumber(PARTY_ID);

    assertThat(found.isEmpty(), is(not(true)));

    assertThat(found.size(), is(1));
  }

  @Test
  void findCountOfRequestsInStateShouldReturnCountsForState() {
    final WorkLog pendingWorkLog =
        buildWorkLogWithStatus(
            Status.PENDING,
            Operation.EMAIL_ADDRESS,
            TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS));
    final WorkLog otherPendingWorkLog =
        buildWorkLogWithStatus(
            Status.PENDING,
            Operation.DELETE_PHONE_NUMBER,
            TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.HOME));
    final WorkLog failedWorkLog =
        buildWorkLogWithStatus(
            Status.FAILED,
            Operation.EMAIL_ADDRESS,
            TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS));
    final WorkLog completedWorkLog =
        buildWorkLogWithStatus(
            Status.COMPLETE,
            Operation.UPDATE_PHONE_NUMBER,
            TestHelper.buildUpdateMobilePhoneNumberPayload());
    final WorkLog otherCompletedWorkLog =
        buildWorkLogWithStatus(
            Status.COMPLETE,
            Operation.EMAIL_ADDRESS,
            TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS));
    final WorkLog anotherCompletedWorkLog =
        buildWorkLogWithStatus(
            Status.COMPLETE,
            Operation.DELETE_PHONE_NUMBER,
            TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.MOBILE));
    final WorkLog workLogUpdatePostalAddress =
        buildWorkLogWithStatus(
            WorkLog.Status.PENDING,
            Operation.POSTAL_ADDRESS,
            TestHelper.buildUpdatePostalAddressPayload());
    final WorkLog anotherWorkLogUpdatePostalAddress =
        buildWorkLogWithStatus(
            WorkLog.Status.COMPLETE,
            Operation.POSTAL_ADDRESS,
            TestHelper.buildUpdatePostalAddressPayload());

    digitalCustomerTestEntityManager.persist(pendingWorkLog);
    digitalCustomerTestEntityManager.persist(otherPendingWorkLog);
    digitalCustomerTestEntityManager.persist(failedWorkLog);
    digitalCustomerTestEntityManager.persist(completedWorkLog);
    digitalCustomerTestEntityManager.persist(otherCompletedWorkLog);
    digitalCustomerTestEntityManager.persist(anotherCompletedWorkLog);
    digitalCustomerTestEntityManager.persist(workLogUpdatePostalAddress);
    digitalCustomerTestEntityManager.persist(anotherWorkLogUpdatePostalAddress);
    digitalCustomerTestEntityManager.flush();
    digitalCustomerTestEntityManager.clear();

    final List<ImmutablePair<WorkLog.Status, Long>> statuses =
        testSubject.findCountOfRequestsInState();

    assertThat(
        statuses,
        containsInAnyOrder(
            new ImmutablePair<>(WorkLog.Status.PENDING, 3L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 1L),
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 4L)));
  }

  @Test
  void findCountOfRequestsShouldReturnEmptyIfNoRecords() {
    final List<ImmutablePair<WorkLog.Status, Long>> statuses =
        testSubject.findCountOfRequestsInState();

    assertThat(statuses, is(empty()));
  }

  @Test
  void findWorkLogByPartyIdAndStatusReturnsCorrectWorkLog() {
    final WorkLog pendingWorkLog =
        buildWorkLogWithStatus(
                Status.PENDING,
                Operation.EMAIL_ADDRESS,
                TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS))
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build();

    final WorkLog pendingWorkLogOlder =
        buildWorkLogWithStatus(
                Status.PENDING,
                Operation.EMAIL_ADDRESS,
                TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS))
            .toBuilder()
            .createdDate(LocalDateTime.parse("2020-05-26T14:43:01"))
            .build();

    final WorkLog pendingWorkLogPostalAddress =
        buildWorkLogWithStatus(
                Status.PENDING,
                Operation.POSTAL_ADDRESS,
                TestHelper.buildUpdatePostalAddressPayload())
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build();

    final WorkLog invalidPartyIdWorkLog =
        buildWorkLogWithStatus(
                Status.PENDING,
                Operation.EMAIL_ADDRESS,
                TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS))
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build()
            .toBuilder()
            .partyId(12321312L)
            .build();

    final WorkLog completeWorkLog =
        buildWorkLogWithStatus(
                Status.COMPLETE,
                Operation.EMAIL_ADDRESS,
                TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS))
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build();

    digitalCustomerTestEntityManager.persist(pendingWorkLog);
    digitalCustomerTestEntityManager.persist(pendingWorkLogOlder);
    digitalCustomerTestEntityManager.persist(pendingWorkLogPostalAddress);
    digitalCustomerTestEntityManager.persist(invalidPartyIdWorkLog);
    digitalCustomerTestEntityManager.persist(completeWorkLog);
    digitalCustomerTestEntityManager.flush();
    digitalCustomerTestEntityManager.clear();

    Optional<WorkLog> found =
        testSubject.findPendingWorkLogByPartyIdAndOperation(PARTY_ID, Operation.EMAIL_ADDRESS);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(pendingWorkLog));
  }

  @Test
  void findWorkLogByPartyIdAndStatusReturnsEmptyWhenNoValidWorkLogs() {
    final WorkLog failedWorkLog =
        buildWorkLogWithStatus(
                Status.FAILED,
                Operation.EMAIL_ADDRESS,
                TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS))
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build();

    final WorkLog pendingWorkLogPostalAddress =
        buildWorkLogWithStatus(
                Status.PENDING,
                Operation.POSTAL_ADDRESS,
                TestHelper.buildUpdatePostalAddressPayload())
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build();

    final WorkLog pendingWorkLogPhoneNUmber =
        buildWorkLogWithStatus(
                Status.PENDING,
                Operation.DELETE_PHONE_NUMBER,
                TestHelper.buildDeletePhoneNumberPayload(PhoneNumberRequestType.HOME))
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build();

    final WorkLog invalidPartyIdWorkLog =
        buildWorkLogWithStatus(
                Status.PENDING,
                Operation.EMAIL_ADDRESS,
                TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS))
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build()
            .toBuilder()
            .partyId(12321312L)
            .build();

    final WorkLog completeWorkLog =
        buildWorkLogWithStatus(
                Status.COMPLETE,
                Operation.EMAIL_ADDRESS,
                TestHelper.buildUpdateEmailPayload(EMAIL_ADDRESS))
            .toBuilder()
            .createdDate(CREATED_DATE)
            .build();

    digitalCustomerTestEntityManager.persist(failedWorkLog);
    digitalCustomerTestEntityManager.persist(pendingWorkLogPostalAddress);
    digitalCustomerTestEntityManager.persist(pendingWorkLogPhoneNUmber);
    digitalCustomerTestEntityManager.persist(completeWorkLog);
    digitalCustomerTestEntityManager.persist(invalidPartyIdWorkLog);
    digitalCustomerTestEntityManager.flush();
    digitalCustomerTestEntityManager.clear();

    Optional<WorkLog> found =
        testSubject.findPendingWorkLogByPartyIdAndOperation(PARTY_ID, Operation.EMAIL_ADDRESS);

    assertThat(found.isPresent(), is(false));
    Assertions.assertEquals(found, Optional.empty());
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(buildWorkLogUpdatePhoneNumber().toBuilder().createdDate(CREATED_DATE).build()),
        Arguments.of(
            buildWorkLogUpdateMobilePhoneNumber().toBuilder().createdDate(CREATED_DATE).build()),
        Arguments.of(
            buildWorkLogDeletePhoneNumber().toBuilder().createdDate(CREATED_DATE).build()));
  }
}
