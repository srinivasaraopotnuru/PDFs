package uk.co.ybs.digital.customer.service;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildFilteredProducts;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildFailureRequestWithFailureType;

import java.net.InetSocketAddress;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.exception.AddressNotPermittedException;
import uk.co.ybs.digital.customer.exception.AmendmentRestrictionException;
import uk.co.ybs.digital.customer.exception.BadFailureRequestChallengeException;
import uk.co.ybs.digital.customer.exception.CustomerNotFoundException;
import uk.co.ybs.digital.customer.exception.CustomerValidationException;
import uk.co.ybs.digital.customer.exception.MultipleRecordsFoundException;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.CustomerPartySysID;
import uk.co.ybs.digital.customer.model.adgcore.CustomerWebLogOnDetails;
import uk.co.ybs.digital.customer.model.adgcore.DeDupeEligibleParty;
import uk.co.ybs.digital.customer.model.adgcore.FatcaParty;
import uk.co.ybs.digital.customer.model.adgcore.FatcaProfile;
import uk.co.ybs.digital.customer.model.adgcore.LinkedParty;
import uk.co.ybs.digital.customer.model.adgcore.LinkedPartyDetails;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdateEmailRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogRequest;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;
import uk.co.ybs.digital.customer.repository.adgcore.FatcaPartyRepository;
import uk.co.ybs.digital.customer.repository.adgcore.FatcaProfileRepository;
import uk.co.ybs.digital.customer.repository.adgcore.MarketingOptInRepository;
import uk.co.ybs.digital.customer.repository.adgcore.PartyRepository;
import uk.co.ybs.digital.customer.repository.adgcore.PostalAddressExceptionRepository;
import uk.co.ybs.digital.customer.repository.digitalcustomer.WorkLogRepository;
import uk.co.ybs.digital.customer.repository.frontoffice.AddressChangeRepository;
import uk.co.ybs.digital.customer.repository.frontoffice.ContactDetailsChangeRepository;
import uk.co.ybs.digital.customer.service.account.AccountService;
import uk.co.ybs.digital.customer.service.audit.AuditService;
import uk.co.ybs.digital.customer.service.audit.dto.AuditAuthenticationFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditCustomerDetailsViewRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditNonPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.AuditPostalAddressUpdateFailureRequest;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalOperation;
import uk.co.ybs.digital.customer.service.audit.dto.NonPostalType;
import uk.co.ybs.digital.customer.service.mapping.AddressChangeMapper;
import uk.co.ybs.digital.customer.service.mapping.AmendmentRestrictionMapper;
import uk.co.ybs.digital.customer.service.mapping.ContactDetailsChangeMapper;
import uk.co.ybs.digital.customer.service.mapping.CustomerBasicMapper;
import uk.co.ybs.digital.customer.service.mapping.GoldenCustomerRecordMapper;
import uk.co.ybs.digital.customer.service.mapping.IsaSubscriptionMapper;
import uk.co.ybs.digital.customer.service.mapping.WorkLogPayloadMapper;
import uk.co.ybs.digital.customer.service.product.ProductFilterService;
import uk.co.ybs.digital.customer.service.shareplan.ShareplanService;
import uk.co.ybs.digital.customer.service.shareplan.ShareplanServiceProperties;
import uk.co.ybs.digital.customer.service.utilities.PostCodeHelper;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.Address;
import uk.co.ybs.digital.customer.web.dto.CustomerBasic;
import uk.co.ybs.digital.customer.web.dto.CustomerDelayedRequest;
import uk.co.ybs.digital.customer.web.dto.EmailAddress;
import uk.co.ybs.digital.customer.web.dto.FailureRequest;
import uk.co.ybs.digital.customer.web.dto.FailureType;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.PafData;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.sca.exception.InvalidScaException;
import uk.co.ybs.digital.sca.service.ScaChallengeService;
import uk.co.ybs.digital.sca.service.ScaCredentials;

@ExtendWith(MockitoExtension.class)
class CustomerServiceTest {

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-09-01T00:00:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);
  private static final LocalDateTime YESTERDAY = LocalDateTime.parse("2020-08-31T23:59:59");
  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final UUID SESSION_ID = UUID.randomUUID();
  private static final InetSocketAddress HOST = InetSocketAddress.createUnresolved("localhost", 80);
  private static final String PARTY_ID = "12462951";
  public static final String NO_RECORD_FOUND_FOR_PARTY =
      "No record found in party database for party id " + PARTY_ID;
  private static final long PARTY_ID_LONG = 12462951L;
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String BRAND_CODE = "YBS";
  private static final String EMAIL_ADDRESS_TYPE = "Email";
  private static final String EMAIL_ADDRESS = "test@test.com";
  public static final String AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT =
      "Amendment restriction found on account";
  public static final String ADDRESS_LINE_1_NOT_PERMITTED = "Address Line 1 is not permitted";

  public static final String ADDRESS_LINE_1 = "Flat 1";
  public static final String ADDRESS_LINE_2 = "Test Estate";
  public static final String ADDRESS_LINE_3 = "10 Test Road";
  public static final String ADDRESS_LINE_4 = "Rothwell";
  public static final String ADDRESS_LINE_5 = "Leeds";
  public static final String POSTCODE = "LS1 6LR";
  public static final String POSTCODE_OTHER = "LS1 6PT";
  public static final Integer PAF_KEY = 123456;
  public static final String PAF_DPS = "2P";
  public static final String CHALLENGE_STRING = "the-challenge";
  public static final PostalAddress.PostalAddressType POSTAL_ADDRESS_FUNCTION =
      PostalAddress.PostalAddressType.CORR;
  public static final PostalAddress.PostalAddressSubType POSTAL_ADDRESS_TYPE =
      PostalAddress.PostalAddressSubType.UKPOST;
  public static final PermittedCountries COUNTRY = PermittedCountries.UNITED_KINGDOM;
  public static final Country DEFAULT_COUNTRY = Country.builder().code("UK").isoCode("GB").build();
  private static final Locale LOCALE = Locale.ROOT;
  private static final String JACK = "Jack";
  private static final String MR = "MR";
  private static final String DAWSON = "Dawson";
  private static final String YES = "Y";
  private static final String NO = "N";
  private static final String POST_CODE = " - postCode:";
  private static final String MOBILE_NUMBER = " - mobileNumber:";

  @Mock AuditService auditService;

  @Mock AccountService accountService;

  @Mock ShareplanService shareplanService;

  @Mock ShareplanServiceProperties shareplanServiceProperties;

  @Mock ProductFilterService productFilterService;

  @Mock PartyRepository partyRepository;

  @Mock CustomerBasicMapper customerBasicMapper;

  @Mock GoldenCustomerRecordMapper goldenCustomerRecordMapper;

  @Mock AmendmentRestrictionMapper amendmentRestrictionMapper;

  @Mock IsaSubscriptionMapper isaSubscriptionMapper;

  CustomerService customerService;

  @Mock WorkLogRepository workLogRepository;

  @Mock ScaManager scaManager;

  @Mock ContactDetailsChangeRepository contactDetailsChangeRepository;

  @Mock ContactDetailsChangeMapper contactDetailsChangeMapper;

  @Mock AddressChangeRepository addressChangeRepository;

  @Mock PostalAddressExceptionRepository postalAddressExceptionRepository;

  @Mock MarketingOptInRepository marketingOptInRepository;

  @Mock AddressChangeMapper addressChangeMapper;

  @Mock WorkLogPayloadMapper workLogPayloadMapper;

  @Mock CustomerServiceProperties customerServiceProperties;

  @Mock ScaChallengeService challengeService;

  @Mock FatcaProfileRepository fatcaProfileRepository;

  @Mock FatcaPartyRepository fatcaPartyRepository;

  @BeforeEach
  void setUp() {

    customerService =
        spy(
            new CustomerService(
                auditService,
                accountService,
                shareplanService,
                shareplanServiceProperties,
                productFilterService,
                partyRepository,
                postalAddressExceptionRepository,
                marketingOptInRepository,
                customerBasicMapper,
                goldenCustomerRecordMapper,
                amendmentRestrictionMapper,
                isaSubscriptionMapper,
                DEFAULT_COUNTRY,
                CLOCK,
                workLogRepository,
                scaManager,
                contactDetailsChangeRepository,
                addressChangeRepository,
                contactDetailsChangeMapper,
                addressChangeMapper,
                workLogPayloadMapper,
                customerServiceProperties,
                challengeService,
                fatcaProfileRepository,
                fatcaPartyRepository));
  }

  @Test
  void getCustomerMapsResponseFromPartiesRepository() {
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    final CustomerBasic customerBasic = TestHelper.buildCustomerBasicResponse().getCustomer();
    final LinkedParty linkedParty = stubLinkedParty();

    doReturn(Optional.of(party))
        .when(partyRepository)
        .findBasicPartyInformation(linkedParty.getCanonicalPartyId(), NOW);
    doReturn(customerBasic).when(customerBasicMapper).map(party);

    assertThat(
        customerService.getCustomer(linkedParty.getOriginalPartyId(), NOW),
        sameInstance(customerBasic));
  }

  @Test
  void getCustomerCallsFindBasicPartyInformationHistoricWhenYesterday() {
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    final CustomerBasic customerBasic = TestHelper.buildCustomerBasicResponse().getCustomer();
    final LinkedParty linkedParty = stubLinkedParty();

    doReturn(Optional.of(party))
        .when(partyRepository)
        .findBasicPartyInformationHistoric(linkedParty.getCanonicalPartyId(), YESTERDAY);
    doReturn(customerBasic).when(customerBasicMapper).map(party);

    assertThat(
        customerService.getCustomer(linkedParty.getOriginalPartyId(), YESTERDAY),
        sameInstance(customerBasic));
  }

  @Test
  void getCustomerThrowsCustomerNotFoundExceptionIfFindCanonicalPartyIdReturnsEmptyOptional() {
    doReturn(Optional.empty()).when(partyRepository).findCanonicalPartyId(0L);

    CustomerNotFoundException ex =
        assertThrows(CustomerNotFoundException.class, () -> customerService.getCustomer(0L, NOW));
    assertThat(ex.getMessage(), equalTo("No record found in party database for party id 0"));
  }

  @Test
  void getCustomerThrowsCustomerServiceExceptionIfFindBasicPartyInformationReturnsEmptyOptional() {
    final LinkedParty linkedParty = stubLinkedParty();

    doReturn(Optional.empty())
        .when(partyRepository)
        .findBasicPartyInformation(linkedParty.getCanonicalPartyId(), NOW);

    CustomerNotFoundException ex =
        assertThrows(
            CustomerNotFoundException.class,
            () -> customerService.getCustomer(linkedParty.getOriginalPartyId(), NOW));
    assertThat(ex.getMessage(), equalTo("No record found in party database for party id 1"));
  }

  @Test
  void getCustomerDetailsWrapsCustomerDetailsInCustomerDetailsResponse() {
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    final GoldenCustomerRecord goldenCustomerRecord =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();
    final RequestMetadata requestMetadata = buildRequestMetadata(String.valueOf(PARTY_ID_LONG));

    final AuditCustomerDetailsViewRequest expectedAuditRequest =
        AuditCustomerDetailsViewRequest.builder().ipAddress(IP_ADDRESS).build();

    final List<MarketingOptIn> marketingOptIns = TestHelper.buildMarketingOptIns();

    doReturn(Optional.of(party))
        .when(partyRepository)
        .findGoldenPartyInformation(PARTY_ID_LONG, NOW);

    when(shareplanServiceProperties.isEnabled()).thenReturn(true);

    when(marketingOptInRepository.findMarketingOptInByParty(PARTY_ID_LONG, NOW))
        .thenReturn(marketingOptIns);

    Optional<FatcaParty> fatcaParty = TestHelper.buildFatcaParty();
    when(fatcaPartyRepository.findByPartyIdAndNotEnded(PARTY_ID_LONG, NOW)).thenReturn(fatcaParty);

    List<FatcaProfile> fatcaProfiles = TestHelper.buildFatcaProfiles();
    when(fatcaProfileRepository.findByPartyIdAndNotEnded(fatcaParty.get().getSysId(), NOW))
        .thenReturn(fatcaProfiles);

    doReturn(goldenCustomerRecord)
        .when(goldenCustomerRecordMapper)
        .map(party, false, true, false, PARTY_ID, marketingOptIns, fatcaProfiles, fatcaParty.get());

    doReturn(TestHelper.buildShareplanAccount().getAccounts())
        .when(shareplanService)
        .getShareplanAccount(requestMetadata);

    final GoldenCustomerRecord actual =
        customerService.getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    verify(auditService).auditCustomerDetailsView(expectedAuditRequest, requestMetadata);
    assertThat(actual, equalTo(goldenCustomerRecord));
  }

  @Test
  void getCustomerDetailsSetsAmendmentRestriction() {
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    final GoldenCustomerRecord goldenCustomerRecord =
        TestHelper.buildCustomerDetailsResponse(true, true, false, PARTY_ID)
            .getGoldenCustomerRecord();
    final RequestMetadata requestMetadata = buildRequestMetadata(String.valueOf(PARTY_ID_LONG));

    final AuditCustomerDetailsViewRequest expectedAuditRequest =
        AuditCustomerDetailsViewRequest.builder().ipAddress(IP_ADDRESS).build();

    final List<MarketingOptIn> marketingOptIns = TestHelper.buildMarketingOptIns();

    doReturn(Optional.of(party))
        .when(partyRepository)
        .findGoldenPartyInformation(PARTY_ID_LONG, NOW);

    when(amendmentRestrictionMapper.isRestricted(any())).thenReturn(true);

    when(marketingOptInRepository.findMarketingOptInByParty(PARTY_ID_LONG, NOW))
        .thenReturn(marketingOptIns);

    doReturn(goldenCustomerRecord)
        .when(goldenCustomerRecordMapper)
        .map(party, true, false, false, PARTY_ID, marketingOptIns, null, null);

    final GoldenCustomerRecord actual =
        customerService.getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    verify(auditService).auditCustomerDetailsView(expectedAuditRequest, requestMetadata);
    assertThat(actual, equalTo(goldenCustomerRecord));
  }

  @Test
  void getCustomerDetailsDefaultCorrespondenceCountryCode() {
    final Party party =
        Party.builder()
            .sysId(PARTY_ID_LONG)
            .address(
                AddressUsage.builder()
                    .postalAddress(
                        uk.co.ybs.digital.customer.model.adgcore.PostalAddress.builder()
                            .line1("AddressLine1_1")
                            .country(null)
                            .type(AddressType.UKPOST)
                            .build())
                    .build())
            .build();

    final GoldenCustomerRecord goldenCustomerRecord =
        TestHelper.buildCustomerDetailsResponse(true, true, true, PARTY_ID)
            .getGoldenCustomerRecord();
    final RequestMetadata requestMetadata = buildRequestMetadata(String.valueOf(PARTY_ID_LONG));

    final AuditCustomerDetailsViewRequest expectedAuditRequest =
        AuditCustomerDetailsViewRequest.builder().ipAddress(IP_ADDRESS).build();

    final List<MarketingOptIn> marketingOptIns = TestHelper.buildMarketingOptIns();

    doReturn(Optional.of(party))
        .when(partyRepository)
        .findGoldenPartyInformation(PARTY_ID_LONG, NOW);

    when(amendmentRestrictionMapper.isRestricted(any())).thenReturn(true);

    when(marketingOptInRepository.findMarketingOptInByParty(PARTY_ID_LONG, NOW))
        .thenReturn(marketingOptIns);

    Optional<FatcaParty> fatcaParty = TestHelper.buildFatcaParty();
    when(fatcaPartyRepository.findByPartyIdAndNotEnded(PARTY_ID_LONG, NOW)).thenReturn(fatcaParty);

    doReturn(goldenCustomerRecord)
        .when(goldenCustomerRecordMapper)
        .map(party, true, false, false, PARTY_ID, marketingOptIns, null, fatcaParty.get());

    final GoldenCustomerRecord actual =
        customerService.getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    verify(auditService).auditCustomerDetailsView(expectedAuditRequest, requestMetadata);
    assertThat(actual, equalTo(goldenCustomerRecord));
    assertThat(actual.getAddresses().get(0).getCountry(), equalTo("GB"));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @MethodSource("postalAddressTestArgs")
  @ParameterizedTest(name = "updatePostalAddressSuccessWithPaf: {index} {arguments}")
  void updatePostalAddressSuccessWithPaf(
      final String label, final Address currentAddress, final PostalAddress newAddress) {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, currentAddress)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(true, newAddress);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AddressChange addressChange =
        AddressChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .addressLine1(postalAddressRequest.getAddress().getAddressLines().get(0))
            .addressLine2(postalAddressRequest.getAddress().getAddressLines().get(1))
            .addressLine3(postalAddressRequest.getAddress().getAddressLines().get(2))
            .addressLine4(postalAddressRequest.getAddress().getAddressLines().get(3))
            .country(postalAddressRequest.getAddress().getCountry().getCode())
            .postCode(postalAddressRequest.getAddress().getPostCode())
            .pafKey(postalAddressRequest.getPaf().getAddressKey().toString())
            .pafDeliveryPrefix(postalAddressRequest.getPaf().getDeliveryPointSuffix())
            .build();

    final WorkLogRequest workLogRequest =
        buildWorkLogRequest(requestMetadata, postalAddressRequest, 5, true);

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(addressChangeMapper.map(postalAddressRequest)).thenReturn(addressChange);

    when(workLogPayloadMapper.map(postalAddressRequest))
        .thenReturn(workLogRequest.getWorkLogPayload());

    customerService.updatePostalAddress(postalAddressRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("partyId", is(PARTY_ID_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty("operation", is(Operation.POSTAL_ADDRESS)),
                    hasProperty("message", is(workLogRequest)),
                    hasProperty("createdBy", is("SAPP")))));

    verify(addressChangeRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("partySysId", is(PARTY_ID)),
                    hasProperty("addressLine1", is(newAddress.getAddressLines().get(0))),
                    hasProperty("addressLine2", is(newAddress.getAddressLines().get(1))),
                    hasProperty("addressLine3", is(newAddress.getAddressLines().get(2))),
                    hasProperty("addressLine4", is(newAddress.getAddressLines().get(3))),
                    hasProperty("country", is(newAddress.getCountry().getCode())),
                    hasProperty("postCode", is(newAddress.getPostCode())),
                    hasProperty("pafKey", is(PAF_KEY.toString())),
                    hasProperty("pafDeliveryPrefix", is(PAF_DPS)))));

    verifyNoInteractions(auditService);
    verifyNoInteractions(postalAddressExceptionRepository);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @MethodSource("postalAddressTestArgs")
  @ParameterizedTest(name = "updatePostalAddressSuccessWithoutPaf: {index} {arguments}")
  void updatePostalAddressSuccessWithoutPaf(
      final String label, final Address currentAddress, final PostalAddress newAddress) {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, currentAddress)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(false, newAddress);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AddressChange addressChange =
        AddressChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .addressLine1(postalAddressRequest.getAddress().getAddressLines().get(0))
            .addressLine2(postalAddressRequest.getAddress().getAddressLines().get(1))
            .addressLine3(postalAddressRequest.getAddress().getAddressLines().get(2))
            .addressLine4(postalAddressRequest.getAddress().getAddressLines().get(3))
            .country(postalAddressRequest.getAddress().getCountry().getCode())
            .postCode(postalAddressRequest.getAddress().getPostCode())
            .build();

    final WorkLogRequest workLogRequest =
        buildWorkLogRequest(requestMetadata, postalAddressRequest, 5, false);

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(addressChangeMapper.map(postalAddressRequest)).thenReturn(addressChange);

    when(workLogPayloadMapper.map(postalAddressRequest))
        .thenReturn(workLogRequest.getWorkLogPayload());

    when(postalAddressExceptionRepository.findExceptionForAddressLine(any()))
        .thenReturn(Optional.empty());

    customerService.updatePostalAddress(postalAddressRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("partyId", is(PARTY_ID_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty("operation", is(Operation.POSTAL_ADDRESS)),
                    hasProperty("message", is(workLogRequest)),
                    hasProperty("createdBy", is("SAPP")))));

    verify(addressChangeRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("partySysId", is(PARTY_ID)),
                    hasProperty("addressLine1", is(newAddress.getAddressLines().get(0))),
                    hasProperty("addressLine2", is(newAddress.getAddressLines().get(1))),
                    hasProperty("addressLine3", is(newAddress.getAddressLines().get(2))),
                    hasProperty("addressLine4", is(newAddress.getAddressLines().get(3))),
                    hasProperty("country", is(newAddress.getCountry().getCode())),
                    hasProperty("postCode", is(newAddress.getPostCode())))));

    verifyNoInteractions(auditService);
    verifyNoMoreInteractions(postalAddressExceptionRepository);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @MethodSource("postalAddressShortTestArgs")
  @ParameterizedTest(
      name = "updatePostalAddressSuccessWithPafAndLessAddressLines: {index} {arguments}")
  void updatePostalAddressSuccessWithPafAndLessAddressLines(
      final String label, final Address currentAddress, final PostalAddress newAddress) {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, currentAddress)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(true, newAddress);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AddressChange addressChange =
        AddressChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .addressLine1(postalAddressRequest.getAddress().getAddressLines().get(0))
            .addressLine2(postalAddressRequest.getAddress().getAddressLines().get(1))
            .country(postalAddressRequest.getAddress().getCountry().getCode())
            .postCode(postalAddressRequest.getAddress().getPostCode())
            .pafKey(postalAddressRequest.getPaf().getAddressKey().toString())
            .pafDeliveryPrefix(postalAddressRequest.getPaf().getDeliveryPointSuffix())
            .build();

    final WorkLogRequest workLogRequest =
        buildWorkLogRequest(requestMetadata, postalAddressRequest, 2, true);

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(addressChangeMapper.map(postalAddressRequest)).thenReturn(addressChange);

    when(workLogPayloadMapper.map(postalAddressRequest))
        .thenReturn(workLogRequest.getWorkLogPayload());

    customerService.updatePostalAddress(postalAddressRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("partyId", is(PARTY_ID_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty("operation", is(Operation.POSTAL_ADDRESS)),
                    hasProperty("message", is(workLogRequest)),
                    hasProperty("createdBy", is("SAPP")))));

    verify(addressChangeRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("partySysId", is(PARTY_ID)),
                    hasProperty("addressLine1", is(newAddress.getAddressLines().get(0))),
                    hasProperty("addressLine2", is(newAddress.getAddressLines().get(1))),
                    hasProperty("country", is(newAddress.getCountry().getCode())),
                    hasProperty("postCode", is(newAddress.getPostCode())),
                    hasProperty("pafKey", is(PAF_KEY.toString())),
                    hasProperty("pafDeliveryPrefix", is(PAF_DPS)))));

    verifyNoInteractions(auditService);
    verifyNoInteractions(postalAddressExceptionRepository);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  @MethodSource("postalAddressShortTestArgs")
  @ParameterizedTest(
      name = "updatePostalAddressSuccessWithoutPafAndLessAddressLines: {index} {arguments}")
  void updatePostalAddressSuccessWithoutPafAndLessAddressLines(
      final String label, final Address currentAddress, final PostalAddress newAddress) {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, currentAddress)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(true, newAddress);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AddressChange addressChange =
        AddressChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .addressLine1(postalAddressRequest.getAddress().getAddressLines().get(0))
            .addressLine2(postalAddressRequest.getAddress().getAddressLines().get(1))
            .country(postalAddressRequest.getAddress().getCountry().getCode())
            .postCode(postalAddressRequest.getAddress().getPostCode())
            .build();

    final WorkLogRequest workLogRequest =
        buildWorkLogRequest(requestMetadata, postalAddressRequest, 2, false);

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(addressChangeMapper.map(postalAddressRequest)).thenReturn(addressChange);

    when(workLogPayloadMapper.map(postalAddressRequest))
        .thenReturn(workLogRequest.getWorkLogPayload());

    customerService.updatePostalAddress(postalAddressRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("partyId", is(PARTY_ID_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty("operation", is(Operation.POSTAL_ADDRESS)),
                    hasProperty("message", is(workLogRequest)),
                    hasProperty("createdBy", is("SAPP")))));

    verify(addressChangeRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("partySysId", is(PARTY_ID)),
                    hasProperty("addressLine1", is(newAddress.getAddressLines().get(0))),
                    hasProperty("addressLine2", is(newAddress.getAddressLines().get(1))),
                    hasProperty("country", is(newAddress.getCountry().getCode())),
                    hasProperty("postCode", is(newAddress.getPostCode())))));

    verifyNoInteractions(auditService);
  }

  @Test
  void updatePostalAddressThrowsValidationExceptionWhenAddressLineNotPermittedForNonPafAddress() {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(false);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AddressChange addressChange =
        AddressChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .addressLine1(postalAddressRequest.getAddress().getAddressLines().get(0))
            .addressLine2(postalAddressRequest.getAddress().getAddressLines().get(1))
            .addressLine3(postalAddressRequest.getAddress().getAddressLines().get(2))
            .addressLine4(postalAddressRequest.getAddress().getAddressLines().get(3))
            .country(postalAddressRequest.getAddress().getCountry().toString())
            .postCode(postalAddressRequest.getAddress().getPostCode())
            .build();

    final WorkLogRequest workLogRequest =
        buildWorkLogRequest(requestMetadata, postalAddressRequest, 5, false);

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(addressChangeMapper.map(postalAddressRequest)).thenReturn(addressChange);

    when(workLogPayloadMapper.map(postalAddressRequest))
        .thenReturn(workLogRequest.getWorkLogPayload());

    when(postalAddressExceptionRepository.findExceptionForAddressLine("Flat 1"))
        .thenReturn(Optional.of("Flat 1"));

    final AuditPostalAddressUpdateFailureRequest auditRequest =
        buildAuditPostalAddressFailureRequest(
            requestMetadata, ADDRESS_LINE_1_NOT_PERMITTED, postalAddressRequest);

    AddressNotPermittedException ex =
        assertThrows(
            AddressNotPermittedException.class,
            () ->
                customerService.updatePostalAddress(
                    postalAddressRequest, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo(ADDRESS_LINE_1_NOT_PERMITTED));

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verify(auditService).auditPostalAddressUpdateFailure(auditRequest, requestMetadata);

    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(addressChangeRepository);
    verifyNoMoreInteractions(postalAddressExceptionRepository);
  }

  @ParameterizedTest
  @ValueSource(strings = {"PO BOX 123", "po box 125", "po box", "Po Box", "po BOX"})
  void updatePostalAddressThrowsValidationExceptionWhenAddressLineNotPermittedForPafAddress(
      final String addressLine1) {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest =
        buildPostalAddressRequest(
            true,
            buildPostalAddress(
                PostalAddress.builder()
                    .addressLine(addressLine1)
                    .country(PermittedCountries.UNITED_KINGDOM)
                    .postCode(POSTCODE_OTHER)
                    .build()));
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AddressChange addressChange =
        AddressChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .addressLine1(postalAddressRequest.getAddress().getAddressLines().get(0))
            .addressLine2(postalAddressRequest.getAddress().getAddressLines().get(1))
            .addressLine3(postalAddressRequest.getAddress().getAddressLines().get(2))
            .addressLine4(postalAddressRequest.getAddress().getAddressLines().get(3))
            .country(postalAddressRequest.getAddress().getCountry().toString())
            .postCode(postalAddressRequest.getAddress().getPostCode())
            .build();

    final WorkLogRequest workLogRequest =
        buildWorkLogRequest(requestMetadata, postalAddressRequest, 5, false);

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(addressChangeMapper.map(postalAddressRequest)).thenReturn(addressChange);

    when(workLogPayloadMapper.map(postalAddressRequest))
        .thenReturn(workLogRequest.getWorkLogPayload());

    final AuditPostalAddressUpdateFailureRequest auditRequest =
        buildAuditPostalAddressFailureRequest(
            requestMetadata, ADDRESS_LINE_1_NOT_PERMITTED, postalAddressRequest);

    AddressNotPermittedException ex =
        assertThrows(
            AddressNotPermittedException.class,
            () ->
                customerService.updatePostalAddress(
                    postalAddressRequest, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo(ADDRESS_LINE_1_NOT_PERMITTED));

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verify(auditService).auditPostalAddressUpdateFailure(auditRequest, requestMetadata);

    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(addressChangeRepository);
    verifyNoInteractions(postalAddressExceptionRepository);
  }

  @MethodSource("postalAddressNoChangeTestArgs")
  @ParameterizedTest(
      name = "updatePostalAddressThrowsValidationExceptionWhenNoChangesMade: {index} {arguments}")
  void updatePostalAddressThrowsValidationExceptionWhenNoChangesMade(
      final String label, final Address currentAddress, final PostalAddress newAddress) {

    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, currentAddress)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(true, newAddress);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AddressChange addressChange =
        AddressChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .addressLine1(postalAddressRequest.getAddress().getAddressLines().get(0))
            .addressLine2(postalAddressRequest.getAddress().getAddressLines().get(1))
            .addressLine3(postalAddressRequest.getAddress().getAddressLines().get(2))
            .addressLine4(postalAddressRequest.getAddress().getAddressLines().get(3))
            .country(postalAddressRequest.getAddress().getCountry().toString())
            .postCode(postalAddressRequest.getAddress().getPostCode())
            .pafKey(postalAddressRequest.getPaf().getAddressKey().toString())
            .pafDeliveryPrefix(postalAddressRequest.getPaf().getDeliveryPointSuffix())
            .build();

    final WorkLogRequest workLogRequest =
        buildWorkLogRequest(requestMetadata, postalAddressRequest, 5, true);

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(addressChangeMapper.map(postalAddressRequest)).thenReturn(addressChange);

    when(workLogPayloadMapper.map(postalAddressRequest))
        .thenReturn(workLogRequest.getWorkLogPayload());

    CustomerValidationException ex =
        assertThrows(
            CustomerValidationException.class,
            () ->
                customerService.updatePostalAddress(
                    postalAddressRequest, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo("No changes have been detected"));

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(auditService);
    verifyNoMoreInteractions(addressChangeRepository);
  }

  @Test
  void updatePostalAddressShouldNotSaveWorkLogOrContactDetailsChangeLogWhenPartyInBlacklist() {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(true);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AddressChange addressChange =
        AddressChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .addressLine1(postalAddressRequest.getAddress().getAddressLines().get(0))
            .addressLine2(postalAddressRequest.getAddress().getAddressLines().get(1))
            .addressLine3(postalAddressRequest.getAddress().getAddressLines().get(2))
            .addressLine4(postalAddressRequest.getAddress().getAddressLines().get(3))
            .country(postalAddressRequest.getAddress().getCountry().toString())
            .postCode(postalAddressRequest.getAddress().getPostCode())
            .pafKey(postalAddressRequest.getPaf().getAddressKey().toString())
            .pafDeliveryPrefix(postalAddressRequest.getPaf().getDeliveryPointSuffix())
            .build();

    final WorkLogRequest workLogRequest =
        buildWorkLogRequest(requestMetadata, postalAddressRequest, 5, true);

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(addressChangeMapper.map(postalAddressRequest)).thenReturn(addressChange);

    when(workLogPayloadMapper.map(postalAddressRequest))
        .thenReturn(workLogRequest.getWorkLogPayload());

    when(customerServiceProperties.getPartyBlacklist())
        .thenReturn(Collections.singletonList(PARTY_ID));

    customerService.updatePostalAddress(postalAddressRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verifyNoInteractions(auditService);
    verifyNoMoreInteractions(addressChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void
      updatePostalAddressThrowsCustomerNotFoundExceptionIfFindBasicPartyInformationReturnsEmptyOptional() {
    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(true);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AuditPostalAddressUpdateFailureRequest auditRequest =
        buildAuditPostalAddressFailureRequest(
            requestMetadata, "Customer Not Found", postalAddressRequest);

    doThrow(new CustomerNotFoundException(NO_RECORD_FOUND_FOR_PARTY))
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    CustomerNotFoundException ex =
        assertThrows(
            CustomerNotFoundException.class,
            () ->
                customerService.updatePostalAddress(
                    postalAddressRequest, requestMetadata, scaCredentials));

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verify(auditService).auditPostalAddressUpdateFailure(auditRequest, requestMetadata);

    verifyNoMoreInteractions(auditService);
    verifyNoInteractions(addressChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void updatePostalAddressThrowsAmendmentRestrictionExceptionIfExistsOnAccount() {
    GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(true, true, true, PARTY_ID)
            .getGoldenCustomerRecord();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest(true);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    final AuditPostalAddressUpdateFailureRequest auditRequest =
        buildAuditPostalAddressFailureRequest(
            requestMetadata, AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT, postalAddressRequest);

    AmendmentRestrictionException ex =
        assertThrows(
            AmendmentRestrictionException.class,
            () ->
                customerService.updatePostalAddress(
                    postalAddressRequest, requestMetadata, scaCredentials));
    assertThat(ex.getMessage(), equalTo(AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT));

    verify(scaManager)
        .validateUpdatePostalAddressSca(
            Operation.POSTAL_ADDRESS, postalAddressRequest, requestMetadata, scaCredentials);

    verify(auditService).auditPostalAddressUpdateFailure(auditRequest, requestMetadata);

    verifyNoMoreInteractions(auditService);
    verifyNoInteractions(addressChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void updateEmailAddressSuccess() {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final EmailAddress emailAddress = buildEmailAddressRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final ContactDetailsChange contactDetailsReturn =
        ContactDetailsChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .emailAddress("contact@provider.com")
            .workTelephoneNumber("01234989898")
            .homeTelephoneNumber("01136767676")
            .mobileTelephoneNumber("07899191919")
            .build();

    final WorkLogRequest workLogRequest =
        WorkLogRequest.builder()
            .workLogPayload(
                UpdateEmailRequest.builder()
                    .requestType(emailAddress.getType())
                    .email(emailAddress.getEmail())
                    .build())
            .metadata(requestMetadata)
            .build();

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(contactDetailsChangeMapper.map(customerGolden)).thenReturn(contactDetailsReturn);

    customerService.updateEmailAddress(emailAddress, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdateEmailSca(
            Operation.EMAIL_ADDRESS, emailAddress, requestMetadata, scaCredentials);

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("partyId", is(PARTY_ID_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty("operation", is(Operation.EMAIL_ADDRESS)),
                    hasProperty("message", is(workLogRequest)),
                    hasProperty("createdBy", is("SAPP")))));

    verify(contactDetailsChangeRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("emailAddress", is("test@test.com")),
                    hasProperty("partySysId", is(PARTY_ID)),
                    hasProperty("homeTelephoneNumber", is("01136767676")),
                    hasProperty("workTelephoneNumber", is("01234989898")),
                    hasProperty("mobileTelephoneNumber", is("07899191919")))));
  }

  @Test
  void updateEmailAddressShouldNotSaveWorkLogOrContactDetailsChangeLogWhenPartyInBlacklist() {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final EmailAddress emailAddress = buildEmailAddressRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final ContactDetailsChange contactDetailsReturn =
        ContactDetailsChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .emailAddress("contact@provider.com")
            .workTelephoneNumber("01234989898")
            .homeTelephoneNumber("01136767676")
            .mobileTelephoneNumber("07899191919")
            .build();

    final WorkLogRequest workLogRequest =
        WorkLogRequest.builder()
            .workLogPayload(
                UpdateEmailRequest.builder()
                    .requestType(emailAddress.getType())
                    .email(emailAddress.getEmail())
                    .build())
            .metadata(requestMetadata)
            .build();

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(contactDetailsChangeRepository.findLatestChangeForPartiesAfterEarliestTime(any(), any()))
        .thenReturn(Optional.empty());

    when(contactDetailsChangeMapper.map(customerGolden)).thenReturn(contactDetailsReturn);

    when(customerServiceProperties.getPartyBlacklist())
        .thenReturn(Collections.singletonList(PARTY_ID));

    customerService.updateEmailAddress(emailAddress, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdateEmailSca(
            Operation.EMAIL_ADDRESS, emailAddress, requestMetadata, scaCredentials);

    verifyNoInteractions(auditService);
    verifyNoMoreInteractions(contactDetailsChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void updateEmailAddressThrowsValidationExceptionWhenNoChangesMade() {
    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final EmailAddress emailAddress = buildEmailAddressRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final ContactDetailsChange contactDetailsReturn =
        ContactDetailsChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(NOW)
            .emailAddress(EMAIL_ADDRESS)
            .workTelephoneNumber("01234989898")
            .homeTelephoneNumber("01136767676")
            .mobileTelephoneNumber("07899191919")
            .build();

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(contactDetailsChangeMapper.map(customerGolden)).thenReturn(contactDetailsReturn);

    when(contactDetailsChangeRepository.findLatestChangeForPartiesAfterEarliestTime(any(), any()))
        .thenReturn(Optional.empty());

    CustomerValidationException ex =
        assertThrows(
            CustomerValidationException.class,
            () ->
                customerService.updateEmailAddress(emailAddress, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo("No changes have been detected"));

    verify(scaManager)
        .validateUpdateEmailSca(
            Operation.EMAIL_ADDRESS, emailAddress, requestMetadata, scaCredentials);

    verifyNoInteractions(workLogRepository);
    verifyNoMoreInteractions(contactDetailsChangeRepository);
  }

  @Test
  void
      updateEmailAddressThrowsCustomerNotFoundExceptionIfFindBasicPartyInformationReturnsEmptyOptional() {
    final EmailAddress emailAddress = buildEmailAddressRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        buildAuditEmailAddressFailureRequest(requestMetadata, "Customer Not Found", EMAIL_ADDRESS);

    doThrow(new CustomerNotFoundException(NO_RECORD_FOUND_FOR_PARTY))
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    CustomerNotFoundException ex =
        assertThrows(
            CustomerNotFoundException.class,
            () ->
                customerService.updateEmailAddress(emailAddress, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo(NO_RECORD_FOUND_FOR_PARTY));

    verify(scaManager)
        .validateUpdateEmailSca(
            Operation.EMAIL_ADDRESS, emailAddress, requestMetadata, scaCredentials);

    verify(auditService).auditNonPostalAddressUpdateFailure(auditRequest, requestMetadata);

    verifyNoMoreInteractions(auditService);
    verifyNoInteractions(contactDetailsChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void updateEmailAddressThrowsAmendmentRestrictionExceptionIfExistsOnAccount() {
    GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(true, true, true, PARTY_ID)
            .getGoldenCustomerRecord();

    final EmailAddress emailAddress = buildEmailAddressRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    final AuditNonPostalAddressUpdateFailureRequest auditRequest =
        buildAuditEmailAddressFailureRequest(
            requestMetadata, AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT, EMAIL_ADDRESS);

    AmendmentRestrictionException ex =
        assertThrows(
            AmendmentRestrictionException.class,
            () ->
                customerService.updateEmailAddress(emailAddress, requestMetadata, scaCredentials));
    assertThat(ex.getMessage(), equalTo(AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT));

    verify(scaManager)
        .validateUpdateEmailSca(
            Operation.EMAIL_ADDRESS, emailAddress, requestMetadata, scaCredentials);

    verify(auditService).auditNonPostalAddressUpdateFailure(auditRequest, requestMetadata);

    verifyNoMoreInteractions(auditService);
    verifyNoInteractions(contactDetailsChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @MethodSource("phoneNumberTestArgs")
  @ParameterizedTest(name = "updatePhoneNumberSuccess: {index} {arguments}")
  @SuppressWarnings("PMD.ExcessiveParameterList")
  void updatePhoneNumberSuccess(
      final Integer homeAreaCode,
      final String homeNumber,
      final String homeFullNumber,
      final String mobileNumber,
      final Integer workAreaCode,
      final String workNumber,
      final String workFullNumber) {

    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final PhoneNumberRequest phoneNumberRequest =
        buildPhoneNumberRequest(homeNumber, mobileNumber, workNumber);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final ContactDetailsChange contactDetailsReturn =
        ContactDetailsChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(null)
            .emailAddress(EMAIL_ADDRESS)
            .workTelephoneNumber("01234989898")
            .homeTelephoneNumber("01136767676")
            .mobileTelephoneNumber("07899191919")
            .build();

    final WorkLogRequest workLogRequestHome =
        buildWorkLogRequest(requestMetadata, PhoneNumberBasicType.HOME, homeAreaCode, homeNumber);
    final WorkLogRequest workLogRequestMobile =
        buildWorkLogRequest(requestMetadata, PhoneNumberBasicType.MOBILE, null, mobileNumber);
    final WorkLogRequest workLogRequestWork =
        buildWorkLogRequest(requestMetadata, PhoneNumberBasicType.WORK, workAreaCode, workNumber);

    when(contactDetailsChangeRepository.findLatestChangeForPartiesAfterEarliestTime(any(), any()))
        .thenReturn(Optional.empty());

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(contactDetailsChangeMapper.map(customerGolden)).thenReturn(contactDetailsReturn);

    when(workLogPayloadMapper.map(phoneNumberRequest.getPhoneNumbers().get(0)))
        .thenReturn(workLogRequestHome.getWorkLogPayload());
    when(workLogPayloadMapper.map(phoneNumberRequest.getPhoneNumbers().get(1)))
        .thenReturn(workLogRequestMobile.getWorkLogPayload());
    when(workLogPayloadMapper.map(phoneNumberRequest.getPhoneNumbers().get(2)))
        .thenReturn(workLogRequestWork.getWorkLogPayload());

    customerService.updatePhoneNumber(phoneNumberRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdatePhoneNumberSca(
            Operation.PHONE_NUMBER, phoneNumberRequest, requestMetadata, scaCredentials);

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("partyId", is(PARTY_ID_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty(
                        "operation",
                        is(
                            homeNumber == null
                                ? Operation.DELETE_PHONE_NUMBER
                                : Operation.UPDATE_PHONE_NUMBER)),
                    hasProperty("message", is(workLogRequestHome)),
                    hasProperty("createdBy", is("SAPP")))));

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("partyId", is(PARTY_ID_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty(
                        "operation",
                        is(
                            mobileNumber == null
                                ? Operation.DELETE_PHONE_NUMBER
                                : Operation.UPDATE_PHONE_NUMBER)),
                    hasProperty("message", is(workLogRequestMobile)),
                    hasProperty("createdBy", is("SAPP")))));

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("partyId", is(PARTY_ID_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty(
                        "operation",
                        is(
                            workNumber == null
                                ? Operation.DELETE_PHONE_NUMBER
                                : Operation.UPDATE_PHONE_NUMBER)),
                    hasProperty("message", is(workLogRequestWork)),
                    hasProperty("createdBy", is("SAPP")))));

    verify(contactDetailsChangeRepository)
        .findLatestChangeForPartiesAfterEarliestTime(any(), any());

    verify(contactDetailsChangeRepository)
        .saveAndFlush(
            argThat(
                allOf(
                    hasProperty("partySysId", is(PARTY_ID)),
                    hasProperty("emailAddress", is("test@test.com")),
                    hasProperty("homeTelephoneNumber", is(homeFullNumber)),
                    hasProperty("mobileTelephoneNumber", is(mobileNumber)),
                    hasProperty("workTelephoneNumber", is(workFullNumber)))));

    verifyNoInteractions(auditService);
    verifyNoMoreInteractions(contactDetailsChangeRepository);
    verifyNoMoreInteractions(workLogRepository);
  }

  @MethodSource("phoneNumberTestArgs")
  @ParameterizedTest(name = "updatePhoneNumberSuccess: {index} {arguments}")
  @SuppressWarnings("PMD.ExcessiveParameterList")
  void updatePhoneNumberShouldNotSaveWorkLogOrContactDetailsChangeLogWhenPartyInBlacklist(
      final Integer homeAreaCode,
      final String homeNumber,
      final String homeFullNumber,
      final String mobileNumber,
      final Integer workAreaCode,
      final String workNumber,
      final String workFullNumber) {

    final GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, true, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final PhoneNumberRequest phoneNumberRequest =
        buildPhoneNumberRequest(homeNumber, mobileNumber, workNumber);
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final ContactDetailsChange contactDetailsReturn =
        ContactDetailsChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(null)
            .emailAddress(EMAIL_ADDRESS)
            .workTelephoneNumber("01234989898")
            .homeTelephoneNumber("01136767676")
            .mobileTelephoneNumber("07899191919")
            .build();

    final WorkLogRequest workLogRequestHome =
        buildWorkLogRequest(requestMetadata, PhoneNumberBasicType.HOME, homeAreaCode, homeNumber);
    final WorkLogRequest workLogRequestMobile =
        buildWorkLogRequest(requestMetadata, PhoneNumberBasicType.MOBILE, null, mobileNumber);
    final WorkLogRequest workLogRequestWork =
        buildWorkLogRequest(requestMetadata, PhoneNumberBasicType.WORK, workAreaCode, workNumber);

    when(contactDetailsChangeRepository.findLatestChangeForPartiesAfterEarliestTime(any(), any()))
        .thenReturn(Optional.empty());

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    when(contactDetailsChangeMapper.map(customerGolden)).thenReturn(contactDetailsReturn);

    when(workLogPayloadMapper.map(phoneNumberRequest.getPhoneNumbers().get(0)))
        .thenReturn(workLogRequestHome.getWorkLogPayload());
    when(workLogPayloadMapper.map(phoneNumberRequest.getPhoneNumbers().get(1)))
        .thenReturn(workLogRequestMobile.getWorkLogPayload());
    when(workLogPayloadMapper.map(phoneNumberRequest.getPhoneNumbers().get(2)))
        .thenReturn(workLogRequestWork.getWorkLogPayload());

    when(customerServiceProperties.getPartyBlacklist())
        .thenReturn(Collections.singletonList(PARTY_ID));

    customerService.updatePhoneNumber(phoneNumberRequest, requestMetadata, scaCredentials);

    verify(scaManager)
        .validateUpdatePhoneNumberSca(
            Operation.PHONE_NUMBER, phoneNumberRequest, requestMetadata, scaCredentials);

    verifyNoInteractions(auditService);
    verifyNoMoreInteractions(contactDetailsChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void
      updatePhoneNumberThrowsCustomerNotFoundExceptionIfFindBasicPartyInformationReturnsEmptyOptional() {

    final String customerNotFound = "Customer Not Found";

    final PhoneNumberRequest phoneNumberRequest =
        buildPhoneNumberRequest("01234 111111", "07000 222222", "01234 333333");
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    final AuditNonPostalAddressUpdateFailureRequest auditHomeRequest =
        buildAuditPhoneNumberFailureRequest(
            requestMetadata, customerNotFound, NonPostalType.HOME, "01234 111111");
    final AuditNonPostalAddressUpdateFailureRequest auditMobileRequest =
        buildAuditPhoneNumberFailureRequest(
            requestMetadata, customerNotFound, NonPostalType.MOBILE, "07000 222222");
    final AuditNonPostalAddressUpdateFailureRequest auditWorkRequest =
        buildAuditPhoneNumberFailureRequest(
            requestMetadata, customerNotFound, NonPostalType.WORK, "01234 333333");

    doThrow(new CustomerNotFoundException(NO_RECORD_FOUND_FOR_PARTY))
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    CustomerNotFoundException ex =
        assertThrows(
            CustomerNotFoundException.class,
            () ->
                customerService.updatePhoneNumber(
                    phoneNumberRequest, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo(NO_RECORD_FOUND_FOR_PARTY));

    verify(scaManager)
        .validateUpdatePhoneNumberSca(
            Operation.PHONE_NUMBER, phoneNumberRequest, requestMetadata, scaCredentials);

    verify(auditService).auditNonPostalAddressUpdateFailure(auditHomeRequest, requestMetadata);
    verify(auditService).auditNonPostalAddressUpdateFailure(auditMobileRequest, requestMetadata);
    verify(auditService).auditNonPostalAddressUpdateFailure(auditWorkRequest, requestMetadata);

    verifyNoMoreInteractions(auditService);
    verifyNoInteractions(contactDetailsChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void updatePhoneNumberThrowsAmendmentRestrictionExceptionIfExistsOnAccount() {
    GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(true, true, true, PARTY_ID)
            .getGoldenCustomerRecord();

    final PhoneNumberRequest phoneNumberRequest =
        buildPhoneNumberRequest("01234 111111", "07000 222222", "01234 333333");
    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    final AuditNonPostalAddressUpdateFailureRequest auditHomeRequest =
        buildAuditPhoneNumberFailureRequest(
            requestMetadata,
            AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT,
            NonPostalType.HOME,
            "01234 111111");
    final AuditNonPostalAddressUpdateFailureRequest auditMobileRequest =
        buildAuditPhoneNumberFailureRequest(
            requestMetadata,
            AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT,
            NonPostalType.MOBILE,
            "07000 222222");
    final AuditNonPostalAddressUpdateFailureRequest auditWorkRequest =
        buildAuditPhoneNumberFailureRequest(
            requestMetadata,
            AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT,
            NonPostalType.WORK,
            "01234 333333");

    AmendmentRestrictionException ex =
        assertThrows(
            AmendmentRestrictionException.class,
            () ->
                customerService.updatePhoneNumber(
                    phoneNumberRequest, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo(AMENDMENT_RESTRICTION_FOUND_ON_ACCOUNT));

    verify(scaManager)
        .validateUpdatePhoneNumberSca(
            Operation.PHONE_NUMBER, phoneNumberRequest, requestMetadata, scaCredentials);

    verify(auditService).auditNonPostalAddressUpdateFailure(auditHomeRequest, requestMetadata);
    verify(auditService).auditNonPostalAddressUpdateFailure(auditMobileRequest, requestMetadata);
    verify(auditService).auditNonPostalAddressUpdateFailure(auditWorkRequest, requestMetadata);

    verifyNoMoreInteractions(auditService);
    verifyNoInteractions(contactDetailsChangeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void updatePhoneNumberThrowsNoChangesException() {
    GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, false, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(
                PhoneNumberBasic.builder()
                    .type(PhoneNumberBasicType.HOME)
                    .number("01234420713") // NOPMD
                    .build())
            .build();

    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    final ContactDetailsChange contactDetailsReturn =
        ContactDetailsChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(null)
            .emailAddress(EMAIL_ADDRESS)
            .workTelephoneNumber("01234989898")
            .homeTelephoneNumber("01234420713") // NOPMD
            .mobileTelephoneNumber("07899191919")
            .build();

    final UpdatePhoneRequest updatePhoneRequest =
        UpdatePhoneRequest.builder()
            .requestType(PhoneNumberRequestType.HOME)
            .number("01234420713") // NOPMD
            .build();

    when(contactDetailsChangeMapper.map(customerGolden)).thenReturn(contactDetailsReturn);

    when(workLogPayloadMapper.map(eq(phoneNumberRequest.getPhoneNumbers().get(0))))
        .thenReturn(updatePhoneRequest);

    CustomerValidationException ex =
        assertThrows(
            CustomerValidationException.class,
            () ->
                customerService.updatePhoneNumber(
                    phoneNumberRequest, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo("No changes have been detected"));

    verify(scaManager)
        .validateUpdatePhoneNumberSca(
            Operation.PHONE_NUMBER, phoneNumberRequest, requestMetadata, scaCredentials);

    verifyNoMoreInteractions(auditService);
    verify(contactDetailsChangeRepository, never()).save(any());
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void updatePhoneNumberThrowsCustomerMustHaveAtLeastOnePhoneNumberException() {
    GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, false, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.HOME).build())
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.MOBILE).build())
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.WORK).build())
            .build();

    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);
    final ScaCredentials scaCredentials = buildScaCredentials();

    doReturn(customerGolden)
        .when(customerService)
        .getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    final ContactDetailsChange contactDetailsReturn =
        ContactDetailsChange.builder()
            .partySysId(PARTY_ID)
            .amendDate(null)
            .emailAddress(EMAIL_ADDRESS)
            .workTelephoneNumber("01234989898")
            .homeTelephoneNumber("01234420713")
            .mobileTelephoneNumber("07899191919")
            .build();

    final DeletePhoneRequest deleteHomePhoneRequest =
        DeletePhoneRequest.builder().requestType(PhoneNumberRequestType.HOME).build();
    final DeletePhoneRequest deleteMobilePhoneRequest =
        DeletePhoneRequest.builder().requestType(PhoneNumberRequestType.MOBILE).build();
    final DeletePhoneRequest deleteWorkPhoneRequest =
        DeletePhoneRequest.builder().requestType(PhoneNumberRequestType.WORK).build();

    when(contactDetailsChangeMapper.map(customerGolden)).thenReturn(contactDetailsReturn);

    when(workLogPayloadMapper.map(eq(phoneNumberRequest.getPhoneNumbers().get(0))))
        .thenReturn(deleteHomePhoneRequest);
    when(workLogPayloadMapper.map(eq(phoneNumberRequest.getPhoneNumbers().get(1))))
        .thenReturn(deleteMobilePhoneRequest);
    when(workLogPayloadMapper.map(eq(phoneNumberRequest.getPhoneNumbers().get(2))))
        .thenReturn(deleteWorkPhoneRequest);

    CustomerValidationException ex =
        assertThrows(
            CustomerValidationException.class,
            () ->
                customerService.updatePhoneNumber(
                    phoneNumberRequest, requestMetadata, scaCredentials));

    assertThat(ex.getMessage(), equalTo("Customer must have at least one phone number"));

    verify(scaManager)
        .validateUpdatePhoneNumberSca(
            Operation.PHONE_NUMBER, phoneNumberRequest, requestMetadata, scaCredentials);

    verify(contactDetailsChangeRepository, never()).save(any());
    verifyNoInteractions(workLogRepository);
  }

  public WorkLogRequest buildWorkLogRequest(
      final RequestMetadata requestMetadata,
      final PhoneNumberBasicType type,
      final Integer areaDiallingCode,
      final String number) {
    return WorkLogRequest.builder()
        .workLogPayload(buildWorkLogPayload(type, areaDiallingCode, number))
        .metadata(requestMetadata)
        .build();
  }

  public WorkLogRequest buildWorkLogRequest(
      final RequestMetadata requestMetadata,
      final PostalAddressRequest request,
      final Integer addressLines,
      final boolean includePaf) {
    return WorkLogRequest.builder()
        .workLogPayload(buildWorkLogPayload(request, addressLines, includePaf))
        .metadata(requestMetadata)
        .build();
  }

  private static Stream<FailureRequest> failureRequests() {
    return Stream.of(
        buildFailureRequestWithFailureType(FailureType.NON_POSTAL_ADDRESS),
        buildFailureRequestWithFailureType(FailureType.POSTAL_ADDRESS),
        FailureRequest.builder().challenge(CHALLENGE_STRING).build());
  }

  @MethodSource("failureRequests")
  @ParameterizedTest
  void reportFailureShouldCheckChallenge(final FailureRequest failureRequest) {
    final RequestMetadata requestMetadata = buildRequestMetadata(String.valueOf(PARTY_ID_LONG));
    final AuditAuthenticationFailureRequest auditRequest =
        AuditAuthenticationFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message("Client-side authentication error reported")
            .build();

    customerService.reportFailure(failureRequest, requestMetadata);

    verify(challengeService).decodeChallenge(CHALLENGE_STRING, Object.class);

    if (!FailureType.POSTAL_ADDRESS.equals(failureRequest.getFailureType())) {
      verify(auditService)
          .auditCustomerNonPostalAddressChallengeFailure(auditRequest, requestMetadata);
    } else {
      verify(auditService)
          .auditCustomerPostalAddressChallengeFailure(auditRequest, requestMetadata);
    }
  }

  @Test
  void reportFailureShouldThrowBadFailureRequestChallengeException() {
    final RequestMetadata requestMetadata = buildRequestMetadata(String.valueOf(PARTY_ID_LONG));
    final FailureRequest request = FailureRequest.builder().challenge(CHALLENGE_STRING).build();

    doThrow(InvalidScaException.class)
        .when(challengeService)
        .decodeChallenge(CHALLENGE_STRING, Object.class);

    assertThrows(
        BadFailureRequestChallengeException.class,
        () -> customerService.reportFailure(request, requestMetadata));
  }

  public WorkLogPayload buildWorkLogPayload(
      final PhoneNumberBasicType type, final Integer areaDiallingCode, final String number) {

    if (number == null) {
      return DeletePhoneRequest.builder()
          .requestType(PhoneNumberRequestType.valueOf(type.toString()))
          .build();
    }
    return UpdatePhoneRequest.builder()
        .requestType(PhoneNumberRequestType.valueOf(type.toString()))
        .areaDiallingCode(areaDiallingCode)
        .number(number)
        .build();
  }

  public WorkLogPayload buildWorkLogPayload(
      final PostalAddressRequest request, final Integer addressLines, final boolean includePaf) {

    final UpdatePostalAddressRequest.UpdatePostalAddressRequestBuilder builder =
        UpdatePostalAddressRequest.builder();

    final Optional<PostCode> splitPostCode =
        PostCodeHelper.splitPostCode(request.getAddress().getPostCode());

    splitPostCode.ifPresent(
        pc ->
            builder
                .areaCode(pc.getAreaCode())
                .districtCode(pc.getDistrictCode())
                .sectorCode(pc.getSectorCode())
                .unitCode(pc.getUnitCode()));

    builder
        .addressType(request.getAddress().getSubType())
        .function(request.getAddress().getType())
        .addressLine1(request.getAddress().getAddressLines().get(0))
        .country(request.getAddress().getCountry().getCode());

    if (addressLines > 1) { // NOPMD
      builder.addressLine2(request.getAddress().getAddressLines().get(1));
    }
    if (addressLines > 2) { // NOPMD
      builder.addressLine3(request.getAddress().getAddressLines().get(2));
    }
    if (addressLines > 3) { // NOPMD
      builder.addressLine4(request.getAddress().getAddressLines().get(3));
    }
    if (addressLines > 4) { // NOPMD
      builder.addressLine5(request.getAddress().getAddressLines().get(4));
    }

    if (includePaf) {
      builder
          .pafAddressKey(request.getPaf().getAddressKey())
          .pafDeliveryPointSuffix(request.getPaf().getDeliveryPointSuffix());
    }

    return builder.build();
  }

  @Test
  void verifyCustomerDetailsWhenNoShareplanAccount() {
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(false, false, false, PARTY_ID)
            .getGoldenCustomerRecord();

    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);

    final List<MarketingOptIn> marketingOptIns = TestHelper.buildMarketingOptIns();

    when(partyRepository.findGoldenPartyInformation(any(), any())).thenReturn(Optional.of(party));

    when(marketingOptInRepository.findMarketingOptInByParty(PARTY_ID_LONG, NOW))
        .thenReturn(marketingOptIns);

    Optional<FatcaParty> fatcaParty = TestHelper.buildFatcaParty();
    when(fatcaPartyRepository.findByPartyIdAndNotEnded(PARTY_ID_LONG, NOW)).thenReturn(fatcaParty);

    List<FatcaProfile> fatcaProfiles = TestHelper.buildFatcaProfiles();
    when(fatcaProfileRepository.findByPartyIdAndNotEnded(fatcaParty.get().getSysId(), NOW))
        .thenReturn(fatcaProfiles);

    doReturn(customerGolden)
        .when(goldenCustomerRecordMapper)
        .map(
            party, false, false, false, PARTY_ID, marketingOptIns, fatcaProfiles, fatcaParty.get());

    when(shareplanServiceProperties.isEnabled()).thenReturn(true);

    doReturn(TestHelper.buildEmptyShareplanAccount().getAccounts())
        .when(shareplanService)
        .getShareplanAccount(requestMetadata);

    final GoldenCustomerRecord actual =
        customerService.getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    assertThat(actual, equalTo(customerGolden));
  }

  @Test
  void verifyCustomerDetailsWhenShareplanServiceDisabled() {
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    GoldenCustomerRecord customerGolden =
        TestHelper.buildCustomerDetailsResponse(true, false, true, PARTY_ID)
            .getGoldenCustomerRecord();

    final RequestMetadata requestMetadata = buildRequestMetadata(PARTY_ID);

    final List<MarketingOptIn> marketingOptIns = TestHelper.buildMarketingOptIns();

    when(partyRepository.findGoldenPartyInformation(any(), any())).thenReturn(Optional.of(party));

    when(marketingOptInRepository.findMarketingOptInByParty(PARTY_ID_LONG, NOW))
        .thenReturn(marketingOptIns);

    doReturn(customerGolden)
        .when(goldenCustomerRecordMapper)
        .map(party, false, false, false, PARTY_ID, marketingOptIns, null, null);

    when(shareplanServiceProperties.isEnabled()).thenReturn(false);

    final GoldenCustomerRecord actual =
        customerService.getCustomerDetails(requestMetadata, GoldenCustomerRecord.class);

    assertThat(actual, equalTo(customerGolden));
  }

  @Test
  void getAvailableProducts() {
    final Party party = Party.builder().sysId(1L).build();

    final RequestMetadata requestMetadata = buildRequestMetadata(String.valueOf(3L));

    final List<ProductCategory> availableProducts = buildFilteredProducts();

    final LinkedParty linkedParty = stubLinkedParty();

    when(partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(linkedParty.getCanonicalPartyId()),
            eq(EnumSet.of(AddressType.UKPOST)),
            eq(EnumSet.of(AddressUsage.AddressFunction.CORR)),
            any()))
        .thenReturn(Optional.of(party));

    when(productFilterService.filterProducts(party, requestMetadata, NOW))
        .thenReturn(availableProducts);

    final List<ProductCategory> actual = customerService.getAvailableProducts(requestMetadata);

    assertThat(actual, equalTo(availableProducts));
  }

  @Test
  void getAvailableProductsThrowsCustomerNotFoundException() {

    final LinkedParty linkedParty = stubLinkedParty();

    final RequestMetadata requestMetadata = buildRequestMetadata(String.valueOf(3L));

    when(partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            eq(linkedParty.getCanonicalPartyId()),
            eq(EnumSet.of(AddressType.UKPOST)),
            eq(EnumSet.of(AddressUsage.AddressFunction.CORR)),
            any()))
        .thenReturn(Optional.empty());

    final CustomerNotFoundException ex =
        assertThrows(
            CustomerNotFoundException.class,
            () -> customerService.getAvailableProducts(requestMetadata));

    assertThat(ex.getMessage(), equalTo("No record found in party database for party id 1"));
  }

  @Test
  void getAvailableProductsThrowsCustomerNotFoundExceptionWhenLinkedPartyNotFound() {

    final RequestMetadata requestMetadata = buildRequestMetadata(String.valueOf(3L));

    final CustomerNotFoundException ex =
        assertThrows(
            CustomerNotFoundException.class,
            () -> customerService.getAvailableProducts(requestMetadata));

    assertThat(ex.getMessage(), equalTo("No record found in party database for party id 3"));
  }

  private LinkedParty stubLinkedParty() {
    final LinkedParty linkedParty =
        LinkedParty.builder().originalPartyId(3L).canonicalPartyId(1L).linkCount(2L).build();

    doReturn(Optional.of(linkedParty)).when(partyRepository).findCanonicalPartyId(3L);

    return linkedParty;
  }

  private RequestMetadata buildRequestMetadata(final String partyId) {
    return buildRequestMetadata(partyId, partyId);
  }

  private RequestMetadata buildRequestMetadata(
      final String partyId, final String webCustomerNumber) {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .sessionId(SESSION_ID)
        .host(HOST)
        .partyId(partyId)
        .brandCode(BRAND_CODE)
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .webCustomerNumber(webCustomerNumber)
        .build();
  }

  private ScaCredentials buildScaCredentials() {
    return new ScaCredentials("mockChallenge", "mockResponse", "mockBase64EncodedPublicKey");
  }

  private AuditPostalAddressUpdateFailureRequest buildAuditPostalAddressFailureRequest(
      final RequestMetadata requestMetadata,
      final String message,
      final PostalAddressRequest request) {
    return AuditPostalAddressUpdateFailureRequest.builder()
        .ipAddress(requestMetadata.getIpAddress())
        .postalAddressRequest(request)
        .message(message)
        .build();
  }

  private AuditNonPostalAddressUpdateFailureRequest buildAuditEmailAddressFailureRequest(
      final RequestMetadata requestMetadata, final String message, final String emailAddress) {
    return AuditNonPostalAddressUpdateFailureRequest.builder()
        .ipAddress(requestMetadata.getIpAddress())
        .operation(NonPostalOperation.EMAIL_ADDRESS)
        .message(message)
        .address(emailAddress)
        .type(NonPostalType.EMAIL)
        .build();
  }

  private AuditNonPostalAddressUpdateFailureRequest buildAuditPhoneNumberFailureRequest(
      final RequestMetadata requestMetadata,
      final String message,
      final NonPostalType type,
      final String number) {
    return AuditNonPostalAddressUpdateFailureRequest.builder()
        .ipAddress(requestMetadata.getIpAddress())
        .operation(NonPostalOperation.PHONE_NUMBER)
        .message(message)
        .address(number)
        .type(type)
        .build();
  }

  private EmailAddress buildEmailAddressRequest() {
    return EmailAddress.builder().type(EMAIL_ADDRESS_TYPE).email(EMAIL_ADDRESS).build();
  }

  private PostalAddressRequest buildPostalAddressRequest(final boolean includePaf) {
    if (includePaf) {
      return PostalAddressRequest.builder()
          .address(buildPostalAddress())
          .paf(buildPafData())
          .build();
    } else {
      return PostalAddressRequest.builder().address(buildPostalAddress()).build();
    }
  }

  private PostalAddressRequest buildPostalAddressRequest(
      final boolean includePaf, final PostalAddress address) {
    if (includePaf) {
      return PostalAddressRequest.builder()
          .address(buildPostalAddress(address))
          .paf(buildPafData())
          .build();
    } else {
      return PostalAddressRequest.builder().address(buildPostalAddress(address)).build();
    }
  }

  private static PostalAddress buildPostalAddress() {
    return PostalAddress.builder()
        .type(POSTAL_ADDRESS_FUNCTION)
        .subType(POSTAL_ADDRESS_TYPE)
        .addressLines(Collections.singleton(ADDRESS_LINE_1))
        .addressLines(Collections.singleton(ADDRESS_LINE_2))
        .addressLines(Collections.singleton(ADDRESS_LINE_3))
        .addressLines(Collections.singleton(ADDRESS_LINE_4))
        .addressLines(Collections.singleton(ADDRESS_LINE_5))
        .postCode(POSTCODE)
        .country(COUNTRY)
        .build();
  }

  @SuppressWarnings("PMD.NullAssignment")
  private static PostalAddress buildPostalAddress(final PostalAddress address) {
    return PostalAddress.builder()
        .type(POSTAL_ADDRESS_FUNCTION)
        .subType(POSTAL_ADDRESS_TYPE)
        .addressLines(Collections.singleton(address.getAddressLines().get(0)))
        .addressLines(
            Collections.singleton(
                address.getAddressLines().size() > 1 ? address.getAddressLines().get(1) : null))
        .addressLines(
            Collections.singleton(
                address.getAddressLines().size() > 2 ? address.getAddressLines().get(2) : null))
        .addressLines(
            Collections.singleton(
                address.getAddressLines().size() > 3 ? address.getAddressLines().get(3) : null))
        .addressLines(
            Collections.singleton(
                address.getAddressLines().size() > 4 ? address.getAddressLines().get(4) : null))
        .country(address.getCountry())
        .postCode(address.getPostCode())
        .build();
  }

  private static PafData buildPafData() {
    return PafData.builder().addressKey(PAF_KEY).deliveryPointSuffix(PAF_DPS).build();
  }

  private PhoneNumberRequest buildPhoneNumberRequest(
      final String homeNumber, final String mobileNumber, final String workNumber) {

    return PhoneNumberRequest.builder()
        .phoneNumber(
            PhoneNumberBasic.builder().type(PhoneNumberBasicType.HOME).number(homeNumber).build())
        .phoneNumber(
            PhoneNumberBasic.builder()
                .type(PhoneNumberBasicType.MOBILE)
                .number(mobileNumber)
                .build())
        .phoneNumber(
            PhoneNumberBasic.builder().type(PhoneNumberBasicType.WORK).number(workNumber).build())
        .build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> phoneNumberTestArgs() {

    // order is homeAreaCode, homeNumber, homeFullNumber,  ,mobileNumber, workAreaCode, workNumber,
    // workFullNumber
    return Stream.of(
        Arguments.of(113, "6767679", "01136767679", "07899191929", 113, "6767679", "01136767679"),
        Arguments.of(
            113, "6767679", "01136767679", "07899191929", null, "07899191930", "07899191930"),
        Arguments.of(null, null, null, "07899191929", 113, "6767679", "01136767679"),
        Arguments.of(113, "6767679", "01136767679", null, 113, "6767679", "01136767679"),
        Arguments.of(113, "6767679", "01136767679", "07899191929", null, null, null));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> postalAddressTestArgs() {

    return Stream.of(
        Arguments.of(
            "Different Address",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("New 1", "New 2", "New 3", "New 4", "New 5"))
                .country(PermittedCountries.JERSEY)
                .postCode("JE2 4TU")
                .build()),
        Arguments.of(
            "Different Postcode",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode("LS2 6PT")
                .build()),
        Arguments.of(
            "Different Address Line 1",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Lin 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()),
        Arguments.of(
            "Different Address Line 2",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Diff 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()),
        Arguments.of(
            "Different Address Line 3",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "L3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()),
        Arguments.of(
            "Different Address Line 4",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "L4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()),
        Arguments.of(
            "Different Address Line 5",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "LINE 4", "EXAMPLE 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()),
        Arguments.of(
            "Different Country",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.GUERNSEY)
                .postCode(POSTCODE_OTHER)
                .build()));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> postalAddressShortTestArgs() {

    return Stream.of(
        Arguments.of(
            "Different Address",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("New 1", "New 2"))
                .country(PermittedCountries.JERSEY)
                .postCode("JE2 4TU")
                .build()),
        Arguments.of(
            "Different Address Line 1",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Lin 1", "Line 2"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()),
        Arguments.of(
            "Different Address Line 2",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Diff 2"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> postalAddressNoChangeTestArgs() {

    return Stream.of(
        Arguments.of(
            "UK - All address lines with same case",
            Address.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line 2", "Line 3", "Line 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()),
        Arguments.of(
            "UK - All address line with mixed case and mixed spacing",
            Address.builder()
                .addressLines(Arrays.asList("LIne 1", "LINE 2", "Lin e 3", "Line 4", "Line5"))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode(POSTCODE_OTHER)
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", "Line2", "Line      3", "LinE 4", "Line 5"))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode(POSTCODE_OTHER)
                .build()),
        Arguments.of(
            "UK - 1 address line with mixed case and mixed spacing",
            Address.builder()
                .addressLines(Arrays.asList("LIne 1", null, null, null, null))
                .country(PermittedCountries.UNITED_KINGDOM.getIsoCode())
                .postCode("LS 1 6PT")
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", null, null, null, null))
                .country(PermittedCountries.UNITED_KINGDOM)
                .postCode("Ls16P  T")
                .build()),
        Arguments.of(
            "Guernsey",
            Address.builder()
                .addressLines(Arrays.asList("LIne 1", null, null, null, null))
                .country(PermittedCountries.GUERNSEY.getIsoCode())
                .postCode("GY57RJ")
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", null, null, null, null))
                .country(PermittedCountries.GUERNSEY)
                .postCode("GY5 7RJ")
                .build()),
        Arguments.of(
            "Jersey",
            Address.builder()
                .addressLines(Arrays.asList("LIne 1", null, null, null, null))
                .country(PermittedCountries.JERSEY.getIsoCode())
                .postCode("je2 4tu")
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", null, null, null, null))
                .country(PermittedCountries.JERSEY)
                .postCode("Je2 4T   u")
                .build()),
        Arguments.of(
            "Ise of Man",
            Address.builder()
                .addressLines(Arrays.asList("LIne 1", null, null, null, null))
                .country(PermittedCountries.ISLE_OF_MAN.getIsoCode())
                .postCode("IM1       2AY")
                .build(),
            PostalAddress.builder()
                .addressLines(Arrays.asList("Line 1", null, null, null, null))
                .country(PermittedCountries.ISLE_OF_MAN)
                .postCode("IM12AY")
                .build()));
  }

  /* Customer delayed record from ADG Core Tests --- Start */

  /** Asserts multiple records found exception when multiple customer records found in ADG Core */
  @Test
  void
      getCustomerDelayedThrowsMultipleRecordsFoundExceptionIfFindPartySysIdsReturnsMultipleRecordCount() {
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final List<CustomerPartySysID> customerPartySysIDList = stubCustomerCustomerPartySysIDList();
    final List<LinkedPartyDetails> linkedPartyDetailsList =
        stubLinkedPartyDetails(PARTY_ID_LONG, 12462953L);
    final DeDupeEligibleParty deDupeEligibleParty =
        DeDupeEligibleParty.builder().eligibility(YES).build();

    doReturn(Optional.of(customerPartySysIDList))
        .when(partyRepository)
        .findPartySysIds(
            customerDelayedRequest.getForename().toUpperCase(LOCALE),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode().replaceAll(" ", "").toUpperCase(LOCALE),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);

    doReturn(Optional.of(linkedPartyDetailsList))
        .when(partyRepository)
        .findLinkedParties(Mockito.anyLong());
    doReturn(deDupeEligibleParty)
        .when(partyRepository)
        .findDeDupeEligiblePartyId(Mockito.anyLong());
    final MultipleRecordsFoundException ex =
        assertThrows(
            MultipleRecordsFoundException.class,
            () -> customerService.getCustomerDelayed(customerDelayedRequest, YESTERDAY));
    assertThat(
        ex.getMessage(),
        equalTo(
            "Multiple records found in ADG Core for the inputs forename:"
                + customerDelayedRequest.getForename()
                + POST_CODE
                + customerDelayedRequest.getPostCode()
                + MOBILE_NUMBER
                + customerService.maskPhoneNumber(customerDelayedRequest.getMobileNumber())));
  }

  /**
   * Asserts multiple records found exception when multiple customer records found in ADG Core (when
   * surname and title not matching)
   */
  @Test
  void
      getCustomerDelayedThrowsMultipleRecordsFoundIfFindPartySysIdsReturnsMultipleRecordCountPostSurnameAndTitleMismatch() {
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final List<CustomerPartySysID> customerPartySysIDList = stubCustomerCustomerPartySysIDList();
    customerPartySysIDList.add(
        CustomerPartySysID.builder().partyId(12462953L).surname(DAWSON).title(MR).build());
    final List<LinkedPartyDetails> linkedPartyDetailsList =
        stubLinkedPartyDetails(PARTY_ID_LONG, 12462953L);
    doReturn(Optional.of(customerPartySysIDList))
        .when(partyRepository)
        .findPartySysIds(
            customerDelayedRequest.getForename().toUpperCase(LOCALE),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode().replaceAll(" ", "").toUpperCase(LOCALE),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);

    doReturn(Optional.of(linkedPartyDetailsList))
        .when(partyRepository)
        .findLinkedParties(Mockito.anyLong());

    final MultipleRecordsFoundException ex =
        assertThrows(
            MultipleRecordsFoundException.class,
            () -> customerService.getCustomerDelayed(customerDelayedRequest, YESTERDAY));
    assertThat(
        ex.getMessage(),
        equalTo(
            "Multiple records found in ADG Core for the inputs forename:"
                + customerDelayedRequest.getForename()
                + POST_CODE
                + customerDelayedRequest.getPostCode()
                + MOBILE_NUMBER
                + customerService.maskPhoneNumber(customerDelayedRequest.getMobileNumber())));
  }

  /** Asserts Resource Not Found Exception when customer record not found in ADG Core */
  @ParameterizedTest
  @MethodSource("matchedZeroPartySysID")
  void getCustomerDelayedThrowsResourceNotFoundExceptionIfFindPartySysIdsReturnsNoRecord(
      final Optional<List<CustomerPartySysID>> customerPartySysIDList) {
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();

    doReturn(customerPartySysIDList)
        .when(partyRepository)
        .findPartySysIds(
            customerDelayedRequest.getForename().toUpperCase(LOCALE),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode().replaceAll(" ", "").toUpperCase(LOCALE),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);

    final CustomerNotFoundException ex =
        assertThrows(
            CustomerNotFoundException.class,
            () -> customerService.getCustomerDelayed(customerDelayedRequest, YESTERDAY));
    assertThat(
        ex.getMessage(),
        equalTo(
            "No record found in ADG Core for the inputs forename:"
                + customerDelayedRequest.getForename()
                + POST_CODE
                + customerDelayedRequest.getPostCode()
                + MOBILE_NUMBER
                + customerService.maskPhoneNumber(customerDelayedRequest.getMobileNumber())));
  }

  /** Asserts Resource Not Found Exception when customer record not found in ADG Core */
  @ParameterizedTest
  @MethodSource("matchedZeroLinkedParties")
  void getCustomerDelayedThrowsResourceNotFoundExceptionIfFindLinkedPartiesReturnsNoRecord(
      final Optional<List<LinkedPartyDetails>> linkedPartyDetailList) {
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final List<CustomerPartySysID> customerPartySysIDList = stubCustomerCustomerPartySysIDList();
    final CustomerPartySysID customerPartySysID = customerPartySysIDList.get(0);

    doReturn(Optional.of(customerPartySysIDList))
        .when(partyRepository)
        .findPartySysIds(
            customerDelayedRequest.getForename().toUpperCase(LOCALE),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode().replaceAll(" ", "").toUpperCase(LOCALE),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);
    doReturn(linkedPartyDetailList)
        .when(partyRepository)
        .findLinkedParties(customerPartySysID.getPartyId());

    final CustomerNotFoundException ex =
        assertThrows(
            CustomerNotFoundException.class,
            () -> customerService.getCustomerDelayed(customerDelayedRequest, YESTERDAY));
    assertThat(
        ex.getMessage(),
        equalTo(
            "No record found in ADG Core for the inputs forename:"
                + customerDelayedRequest.getForename()
                + POST_CODE
                + customerDelayedRequest.getPostCode()
                + MOBILE_NUMBER
                + customerService.maskPhoneNumber(customerDelayedRequest.getMobileNumber())));
  }

  /** Success Scenario -- Asserts the customer record from ADG database for non web customer */
  @Test
  void getCustomerDelayedMapsResponseFromPartiesRepositoryForNonWebCustomer() {

    final CustomerBasic expectedCustomerDelayedNonWebResponse =
        TestHelper.buildCustomerDelayedNonWebResponse().getCustomer();
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final List<CustomerPartySysID> customerPartySysIDList = stubCustomerCustomerPartySysIDList();
    final CustomerPartySysID customerPartySysID = customerPartySysIDList.get(0);
    final CustomerWebLogOnDetails customerWebLogOnDetails =
        CustomerWebLogOnDetails.builder().build();
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    final LinkedParty linkedParty =
        LinkedParty.builder()
            .originalPartyId(PARTY_ID_LONG)
            .canonicalPartyId(PARTY_ID_LONG)
            .linkCount(2L)
            .build();
    final List<LinkedPartyDetails> linkedPartyDetailsList =
        stubLinkedPartyDetails(PARTY_ID_LONG, 12462952L);

    doReturn(Optional.of(customerPartySysIDList))
        .when(partyRepository)
        .findPartySysIds(
            customerDelayedRequest.getForename().toUpperCase(LOCALE),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode().replaceAll(" ", "").toUpperCase(LOCALE),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);
    doReturn(Optional.of(linkedPartyDetailsList))
        .when(partyRepository)
        .findLinkedParties(customerPartySysID.getPartyId());
    doReturn(Optional.empty())
        .when(partyRepository)
        .findWebLogonDetails(customerPartySysID.getPartyId());
    doReturn(Optional.of(linkedParty))
        .when(partyRepository)
        .findCanonicalPartyId(customerPartySysID.getPartyId());
    doReturn(Optional.of(party))
        .when(partyRepository)
        .findBasicPartyInformationHistoric(linkedParty.getCanonicalPartyId(), YESTERDAY);
    doReturn(expectedCustomerDelayedNonWebResponse)
        .when(customerBasicMapper)
        .map(party, customerWebLogOnDetails);

    assertThat(
        customerService.getCustomerDelayed(customerDelayedRequest, YESTERDAY),
        sameInstance(expectedCustomerDelayedNonWebResponse));
  }

  /** Success Scenario -- Asserts the customer record from ADG database for web customer */
  @Test
  void getCustomerDelayedMapsResponseFromPartiesRepositoryForWebCustomer() {

    final CustomerBasic expectedCustomerDelayedWebResponse =
        TestHelper.buildCustomerDelayedResponse().getCustomer();
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final List<CustomerPartySysID> customerPartySysIDList = stubCustomerCustomerPartySysIDList();
    final CustomerWebLogOnDetails customerWebLogOnDetails =
        stubCustomerWebLogOnDetailsSingleRecord();
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    final LinkedParty linkedParty =
        LinkedParty.builder()
            .originalPartyId(PARTY_ID_LONG)
            .canonicalPartyId(PARTY_ID_LONG)
            .linkCount(2L)
            .build();
    final List<LinkedPartyDetails> linkedPartyDetailsList =
        stubLinkedPartyDetails(PARTY_ID_LONG, 12462952L);

    doReturn(Optional.of(customerPartySysIDList))
        .when(partyRepository)
        .findPartySysIds(
            customerDelayedRequest.getForename().toUpperCase(LOCALE),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode().replaceAll(" ", "").toUpperCase(LOCALE),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);
    final CustomerPartySysID customerPartySysID = customerPartySysIDList.get(0);
    doReturn(Optional.of(linkedPartyDetailsList))
        .when(partyRepository)
        .findLinkedParties(customerPartySysID.getPartyId());
    doReturn(Optional.of(customerWebLogOnDetails))
        .when(partyRepository)
        .findWebLogonDetails(customerPartySysID.getPartyId());
    doReturn(Optional.of(linkedParty))
        .when(partyRepository)
        .findCanonicalPartyId(customerPartySysID.getPartyId());
    doReturn(Optional.of(party))
        .when(partyRepository)
        .findBasicPartyInformationHistoric(linkedParty.getCanonicalPartyId(), YESTERDAY);
    doReturn(expectedCustomerDelayedWebResponse)
        .when(customerBasicMapper)
        .map(party, customerWebLogOnDetails);

    assertThat(
        customerService.getCustomerDelayed(customerDelayedRequest, YESTERDAY),
        sameInstance(expectedCustomerDelayedWebResponse));
  }

  /**
   * Success Scenario -- Asserts the customer record from ADG database for web customer post
   * multiple match found
   */
  @Test
  void
      getCustomerDelayedMapsResponseFromPartiesRepositoryForWebCustomerPostEligiblePartiesFoundUnique() {
    final CustomerBasic expectedCustomerDelayedWebResponse =
        TestHelper.buildCustomerDelayedResponse().getCustomer();
    final CustomerDelayedRequest customerDelayedRequest = TestHelper.buildCustomerDelayedRequest();
    final List<CustomerPartySysID> customerPartySysIDList = stubCustomerCustomerPartySysIDList();
    final List<LinkedPartyDetails> linkedPartyDetailsList =
        stubLinkedPartyDetails(PARTY_ID_LONG, 12462953L);
    final DeDupeEligibleParty deDupeEligible =
        DeDupeEligibleParty.builder().eligibility(YES).build();
    final DeDupeEligibleParty deDupeNotEligible =
        DeDupeEligibleParty.builder().eligibility(NO).build();
    final CustomerPartySysID customerPartySysID = customerPartySysIDList.get(0);
    final CustomerWebLogOnDetails customerWebLogOnDetails =
        stubCustomerWebLogOnDetailsSingleRecord();
    final Party party = Party.builder().sysId(PARTY_ID_LONG).build();
    final LinkedParty linkedParty =
        LinkedParty.builder()
            .originalPartyId(PARTY_ID_LONG)
            .canonicalPartyId(PARTY_ID_LONG)
            .linkCount(2L)
            .build();
    doReturn(Optional.of(customerPartySysIDList))
        .when(partyRepository)
        .findPartySysIds(
            customerDelayedRequest.getForename().toUpperCase(LOCALE),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode().replaceAll(" ", "").toUpperCase(LOCALE),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);

    doReturn(Optional.of(linkedPartyDetailsList))
        .when(partyRepository)
        .findLinkedParties(Mockito.anyLong());
    doReturn(deDupeEligible)
        .when(partyRepository)
        .findDeDupeEligiblePartyId(customerPartySysIDList.get(0).getPartyId());
    doReturn(deDupeNotEligible)
        .when(partyRepository)
        .findDeDupeEligiblePartyId(customerPartySysIDList.get(1).getPartyId());
    doReturn(Optional.of(customerWebLogOnDetails))
        .when(partyRepository)
        .findWebLogonDetails(customerPartySysID.getPartyId());
    doReturn(Optional.of(linkedParty))
        .when(partyRepository)
        .findCanonicalPartyId(customerPartySysID.getPartyId());
    doReturn(Optional.of(party))
        .when(partyRepository)
        .findBasicPartyInformationHistoric(linkedParty.getCanonicalPartyId(), YESTERDAY);
    doReturn(expectedCustomerDelayedWebResponse)
        .when(customerBasicMapper)
        .map(party, customerWebLogOnDetails);
    assertThat(
        customerService.getCustomerDelayed(customerDelayedRequest, YESTERDAY),
        sameInstance(expectedCustomerDelayedWebResponse));
  }

  private static Stream<Arguments> matchedZeroPartySysID() {
    return Stream.of(
        Arguments.of(Optional.empty()),
        Arguments.of(Optional.of(new ArrayList<CustomerPartySysID>())));
  }

  private static Stream<Arguments> matchedZeroLinkedParties() {
    return Stream.of(
        Arguments.of(Optional.empty()),
        Arguments.of(Optional.of(new ArrayList<LinkedPartyDetails>())));
  }

  private CustomerWebLogOnDetails stubCustomerWebLogOnDetailsSingleRecord() {
    return CustomerWebLogOnDetails.builder()
        .partyId(PARTY_ID_LONG)
        .webCustomerNumber(1234567890L)
        .webUsername("John123")
        .build();
  }

  private List<CustomerPartySysID> stubCustomerCustomerPartySysIDList() {
    List<CustomerPartySysID> customerPartySysIDList = new ArrayList<>();
    customerPartySysIDList.add(
        CustomerPartySysID.builder().partyId(PARTY_ID_LONG).surname(JACK).title(MR).build());
    customerPartySysIDList.add(
        CustomerPartySysID.builder().partyId(12462952L).surname(JACK).title(MR).build());
    return customerPartySysIDList;
  }

  private List<LinkedPartyDetails> stubLinkedPartyDetails(
      final Long firstPartySysId, final Long secondPartySysId) {
    List<LinkedPartyDetails> linkedPartyDetailsList = new ArrayList<>();
    linkedPartyDetailsList.add(LinkedPartyDetails.builder().partyId(firstPartySysId).build());
    linkedPartyDetailsList.add(LinkedPartyDetails.builder().partyId(secondPartySysId).build());
    return linkedPartyDetailsList;
  }
  /* Customer delayed record from ADG Database Tests --- End */
}
