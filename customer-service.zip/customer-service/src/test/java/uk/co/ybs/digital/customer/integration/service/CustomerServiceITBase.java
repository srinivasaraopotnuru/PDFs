package uk.co.ybs.digital.customer.integration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.hamcrest.beans.HasPropertyWithValue.hasPropertyAtPath;
import static org.junit.jupiter.params.provider.Arguments.arguments;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildAccountGroupedInfo;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildAccountGroupedInfoWithNoRestrictions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import javax.persistence.Query;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.hamcrest.CustomTypeSafeMatcher;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.provider.Arguments;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.customer.integration.IntegrationTestConfig;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.PartyType;
import uk.co.ybs.digital.customer.model.adgcore.Person;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddressException;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdateEmailRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Status;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogRequest;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;
import uk.co.ybs.digital.customer.service.utilities.PostCodeHelper;
import uk.co.ybs.digital.customer.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.customer.utils.SigningUtils;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.CustomerBasic;
import uk.co.ybs.digital.customer.web.dto.CustomerBasicResponse;
import uk.co.ybs.digital.customer.web.dto.CustomerDelayedRequest;
import uk.co.ybs.digital.customer.web.dto.EmailAddress;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.PafData;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberSubType;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@AutoConfigureWebTestClient(timeout = "36000")
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
@SuppressWarnings("PMD.AvoidDuplicateLiterals")
public class CustomerServiceITBase {

  static final String BASE_PATH = "/customer";
  static final String PATH_CUSTOMER = "/customer/%s";
  static final String PATH_CUSTOMER_PRIVATE = "/private/customer/%s";
  static final String PATH_CUSTOMER_DELAYED = "/customer/delayed/%s";
  static final String PATH_CUSTOMER_DELAYED_PRIVATE = "/private/customer/delayed/%s";
  static final String PATH_CUSTOMER_DETAILS = "/customer";
  static final String PATH_CUSTOMER_DETAILS_PRIVATE = "/private/customer";
  static final String PATH_EMAIL_UPDATE = "/customer/email-address";
  static final String PATH_PHONE_NUMBER_UPDATE = "/customer/phone-number";
  static final String PATH_POSTAL_ADDRESS_UPDATE = "/customer/postal-address";
  static final String PATH_CUSTOMER_DELAYED_POST_PRIVATE = "/private/customer/delayed";
  static final String PATH_CUSTOMER_DELAYED_POST = "/customer/delayed";
  static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  static final String HEADER_SESSION_ID = "x-ybs-session-id";
  static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  static final String HEADER_SCA_CHALLENGE = "x-ybs-sca-challenge";
  static final String HEADER_SCA_CHALLENGE_RESPONSE = "x-ybs-sca-challenge-response";
  static final String HEADER_SCA_KEY = "x-ybs-sca-key";
  static final String ACCOUNT_READ_SCOPE = "ACCOUNT_READ";
  static final String OTHER_SCOPE = "PAYMENT";
  static final String REQUESTED_PARTY_ID = "654321";
  static final String CANONICAL_PARTY_ID = TestHelper.CANONICAL_PARTY_ID;
  static final String BRAND_CODE_YBS = "YBS";
  static final String PARTY_SYSID = "12462951";
  static final String CUSTOMER_EMAIL_ADDRESS = "john.smith@gmail.com";
  static final String CUSTOMER_MOBILE_HONE_NUMBER = "07515059347";
  static final String CUSTOMER_WORK_PHONE_NUMBER = "01234421693";
  static final String CUSTOMER_HOME_PHONE_NUMBER = "01234420713";
  static final String REPORT_FAILURE_PATH = "/failure";
  static final String CREATED_BY_DEFAULT = "DEFAULTDC";
  static final LocalDateTime NOW = LocalDateTime.parse("2020-09-01T10:15:30");
  static final LocalDateTime YESTERDAY = NOW.minusDays(1);
  static final UUID SESSION_ID = UUID.randomUUID();
  static final String EMAIL_ADDRESS_TYPE = "Email";
  static final String EMAIL_ADDRESS = "test@test.com";
  static final String LOCALHOST = "localhost";
  static final String PO_BOX = "PO BOX 121";
  static final String ADDRESS_LINE_1 = "FLAT 1";
  static final String ADDRESS_LINE_2 = "TEST ESTATE";
  static final String ADDRESS_LINE_3 = "10 TEST ROAD";
  static final String ADDRESS_LINE_4 = "ROTHWELL";
  static final String ADDRESS_LINE_5 = "LEEDS";
  static final String POSTCODE = "LS1 6LR";
  static final Integer PAF_KEY = 123456;
  static final String ADC_CODE_STRING = "1234";
  static final Integer ADC_CODE = 1234;
  static final String PAF_DPS = "2P";
  private static long nextId;
  static final PermittedCountries COUNTRY = PermittedCountries.UNITED_KINGDOM;
  static final LocalDate LOCAL_DATE = LocalDate.of(2019, 12, 4);
  static final uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressType
      POSTAL_ADDRESS_FUNCTION =
          uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressType.CORR;
  static final uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressSubType
      POSTAL_ADDRESS_TYPE =
          uk.co.ybs.digital.customer.web.dto.PostalAddress.PostalAddressSubType.UKPOST;
  static final String JACK = "Jack";
  static final String NOCK = "NOCK";

  @LocalServerPort private int port;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  @Value("${uk.co.ybs.digital.account-test-port}")
  private int accountTestPort;

  @Value("${uk.co.ybs.digital.product-test-port}")
  private int productTestPort;

  @Value("${uk.co.ybs.digital.apply-test-port}")
  private int applyTestPort;

  @Value("${uk.co.ybs.digital.shareplan-test-port}")
  private int shareplanTestPort;

  @Autowired Clock clock;
  @Autowired ObjectMapper objectMapper;
  @Autowired WebTestClient signingWebTestClient;
  @Autowired PrivateKey jwtSigningPrivateKey;
  @Autowired TestEntityManager adgCoreTestEntityManager;
  @Autowired TestEntityManager frontOfficeTestEntityManager;
  @Autowired TestEntityManager digitalCustomerTestEntityManager;
  @Autowired TransactionTemplate transactionTemplate;
  @Autowired private CacheManager cacheManager;

  @SuppressWarnings("PMD.UnusedPrivateField")
  private KeyPair keyPair;

  MockWebServer mockAuditService;
  MockWebServer mockAccountService;
  MockWebServer mockProductService;
  MockWebServer mockApplyService;
  MockWebServer mockShareplanService;

  @BeforeEach
  void setup() throws Exception {
    mockAuditService = new MockWebServer();
    mockAuditService.start(auditTestPort);
    keyPair = SigningUtils.generateKeyPair();
    mockAccountService = new MockWebServer();
    mockAccountService.start(accountTestPort);
    mockProductService = new MockWebServer();
    mockProductService.start(productTestPort);
    mockApplyService = new MockWebServer();
    mockApplyService.start(applyTestPort);
    mockShareplanService = new MockWebServer();
    mockShareplanService.start(shareplanTestPort);

    TestHelper.clearCacheManager(cacheManager);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockAuditService.shutdown();
    mockAccountService.shutdown();
    mockProductService.shutdown();
    mockApplyService.shutdown();
    mockShareplanService.shutdown();

    transactionTemplate.executeWithoutResult(
        status -> {
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM AddressUsage")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM NonPostalAddress")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM PostalAddress")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM Person")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM MarketingOptIn")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM FatcaParty")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM FatcaProfile")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM Party")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM PartyType")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM PostalAddressException")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM Nationality")
              .executeUpdate();
          digitalCustomerTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM WorkLog")
              .executeUpdate();
          frontOfficeTestEntityManager
              .getEntityManager()
              .createQuery("DELETE FROM ContactDetailsChange")
              .executeUpdate();
        });
  }

  static Stream<Arguments> validDelayedCustomerFields() {
    return Stream.of(
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("John")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("JOHN")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("john")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("John Smith")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("JOHN SMITH")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("john smith")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("po570de")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("po57 0De")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("po570De")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest(CUSTOMER_MOBILE_HONE_NUMBER)),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomDateOfBirthCustomerDelayedRequest(
                LocalDate.now().minusYears(18).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))));
  }

  static Stream<Arguments> incorrectDelayedCustomerFields() {
    return Stream.of(
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("rakesh"),
            TestHelper.buildErrorResponseNotFound(SESSION_ID),
            HttpStatus.NOT_FOUND),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("smith joe"),
            TestHelper.buildErrorResponseNotFound(SESSION_ID),
            HttpStatus.NOT_FOUND),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("smith"),
            TestHelper.buildErrorResponseNotFound(SESSION_ID),
            HttpStatus.NOT_FOUND),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("PO770DE"),
            TestHelper.buildErrorResponseNotFound(SESSION_ID),
            HttpStatus.NOT_FOUND),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("07123456789"),
            TestHelper.buildErrorResponseNotFound(SESSION_ID),
            HttpStatus.NOT_FOUND),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomDateOfBirthCustomerDelayedRequest("1900-01-01"),
            TestHelper.buildErrorResponseNotFound(SESSION_ID),
            HttpStatus.NOT_FOUND));
  }

  static Stream<Arguments> invalidDelayedCustomerFields() {
    return Stream.of(
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest(null),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Missing", "You must specify forename", "forename"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("joe123"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Invalid", "Please specify valid forename", "forename"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest("J"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID,
                "Field.Invalid",
                "Forenames must be between 2 and 70 characters in length",
                "forename"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomForenameCustomerDelayedRequest(
                "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID,
                "Field.Invalid",
                "Forenames must be between 2 and 70 characters in length",
                "forename"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomDateOfBirthCustomerDelayedRequest(null),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Missing", "You must specify date of birth", "dateOfBirth"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomDateOfBirthCustomerDelayedRequest(" "),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID,
                "Field.Invalid",
                "Date Of Birth must contain at least one non-whitespace character",
                "dateOfBirth"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest(null),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Missing", "You must specify mobile number", "mobileNumber"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest(" "),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID,
                "Field.Invalid",
                "Value must be a valid UK Mobile Number",
                "mobileNumber"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("020 1234 1234"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID,
                "Field.Invalid",
                "Value must be a valid UK Mobile Number",
                "mobileNumber"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("071234567890"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID,
                "Field.Invalid",
                "Value must be a valid UK Mobile Number",
                "mobileNumber"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomMobileNumberCustomerDelayedRequest("07140JPSDLW"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID,
                "Field.Invalid",
                "Value must be a valid UK Mobile Number",
                "mobileNumber"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest(null),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Missing", "You must specify post code", "postCode"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest(" "),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Invalid", "Value must be a valid UK Post Code", "postCode"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("LS1 @TR"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Invalid", "Value must be a valid UK Post Code", "postCode"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("L1PT"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Invalid", "Value must be a valid UK Post Code", "postCode"),
            HttpStatus.BAD_REQUEST),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            TestHelper.buildCustomPostCodeCustomerDelayedRequest("08040"),
            TestHelper.buildErrorResponseInvalidField(
                SESSION_ID, "Field.Invalid", "Value must be a valid UK Post Code", "postCode"),
            HttpStatus.BAD_REQUEST));
  }

  static Stream<Arguments> getCustomerDelayedRecord() {
    return Stream.of(
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest(CUSTOMER_MOBILE_HONE_NUMBER),
            buildNonWebCustomerDelayedResponse("12701255"),
            buildNonWebAndWebCustomerRecord(
                12701255L, getPartyType(BRAND_CODE_YBS), CUSTOMER_MOBILE_HONE_NUMBER)),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest(CUSTOMER_MOBILE_HONE_NUMBER),
            buildWebCustomerDelayedResponse("12701256", CUSTOMER_MOBILE_HONE_NUMBER),
            buildNonWebAndWebCustomerRecord(
                12701256L, getPartyType(BRAND_CODE_YBS), CUSTOMER_MOBILE_HONE_NUMBER)),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07754321234"),
            buildWebCustomerDelayedResponse("12701257", "077 54321234"),
            buildNonWebAndWebCustomerRecord(
                12701257L, getPartyType(BRAND_CODE_YBS), "077 54321234")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07543212345"),
            buildWebCustomerDelayedResponse("12701258", "0754 3212345"),
            buildNonWebAndWebCustomerRecord(
                12701258L, getPartyType(BRAND_CODE_YBS), "0754 3212345")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07432123456"),
            buildWebCustomerDelayedResponse("12701259", "07432 123456"),
            buildNonWebAndWebCustomerRecord(
                12701259L, getPartyType(BRAND_CODE_YBS), "07432 123456")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07387654321"),
            buildWebCustomerDelayedResponse("12701260", "073876 54321"),
            buildNonWebAndWebCustomerRecord(
                12701260L, getPartyType(BRAND_CODE_YBS), "073876 54321")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07287654321"),
            buildWebCustomerDelayedResponse("12701261", "0728765 4321"),
            buildNonWebAndWebCustomerRecord(
                12701261L, getPartyType(BRAND_CODE_YBS), "0728765 4321")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07967654321"),
            buildWebCustomerDelayedResponse("12701262", "07967654 321"),
            buildNonWebAndWebCustomerRecord(
                12701262L, getPartyType(BRAND_CODE_YBS), "07967654 321")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07967654321"),
            buildWebCustomerDelayedResponse("12701263", "079676543 21"),
            buildNonWebAndWebCustomerRecord(
                12701263L, getPartyType(BRAND_CODE_YBS), "079676543 21")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07977654321"),
            buildWebCustomerDelayedResponse("12701264", "0797765432 1"),
            buildNonWebAndWebCustomerRecord(
                12701264L, getPartyType(BRAND_CODE_YBS), "0797765432 1")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07976654321"),
            buildWebCustomerDelayedResponse("12701265", "07976654321 "),
            buildNonWebAndWebCustomerRecord(
                12701265L, getPartyType(BRAND_CODE_YBS), "07976654321 ")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07976654323"),
            buildWebCustomerDelayedResponse("12701266", "07976 65 4323"),
            buildNonWebAndWebCustomerRecord(
                12701266L, getPartyType(BRAND_CODE_YBS), "07976 65 4323")),
        Arguments.of(
            PATH_CUSTOMER_DELAYED_POST_PRIVATE,
            buildNonWebAndWebCustomerRequest("07976654324"),
            buildWebCustomerDelayedResponse("12701267", "07976  654324"),
            buildNonWebAndWebCustomerRecord(
                12701267L, getPartyType(BRAND_CODE_YBS), "07976  654324")));
  }

  static CustomerBasicResponse buildWebCustomerDelayedResponse(
      final String partySysId, final String mobileNumber) {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId(partySysId)
                .title("MISS")
                .forename("RACHEL")
                .surname("NOCK")
                .dateOfBirth(LocalDate.now().minusYears(18))
                .email(CUSTOMER_EMAIL_ADDRESS)
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_WORK_PHONE_NUMBER)
                            .type("WORK")
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(mobileNumber)
                            .type("MOBILE")
                            .subType(PhoneNumberSubType.MOBILE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_HOME_PHONE_NUMBER)
                            .type("HOME")
                            .pendingUpdate(false)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build()))
                .webCustomerNumber(partySysId)
                .webUsername("Rachel123")
                .build())
        .build();
  }

  static CustomerBasicResponse buildNonWebCustomerDelayedResponse(final String partySysId) {
    return CustomerBasicResponse.builder()
        .customer(
            CustomerBasic.builder()
                .partyId(partySysId)
                .title("MISS")
                .forename("RACHEL")
                .surname("NOCK")
                .dateOfBirth(LocalDate.now().minusYears(18))
                .email(CUSTOMER_EMAIL_ADDRESS)
                .phoneNumbers(
                    Arrays.asList(
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_WORK_PHONE_NUMBER)
                            .type("WORK")
                            .subType(PhoneNumberSubType.LANDLINE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_MOBILE_HONE_NUMBER)
                            .type("MOBILE")
                            .subType(PhoneNumberSubType.MOBILE)
                            .pendingUpdate(false)
                            .build(),
                        PhoneNumberResponse.builder()
                            .number(CUSTOMER_HOME_PHONE_NUMBER)
                            .type("HOME")
                            .pendingUpdate(false)
                            .subType(PhoneNumberSubType.LANDLINE)
                            .build()))
                .build())
        .build();
  }

  static CustomerDelayedRequest buildNonWebAndWebCustomerRequest(final String mobileNumber) {
    return CustomerDelayedRequest.builder()
        .dateOfBirth(
            LocalDate.now().minusYears(18).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")))
        .postCode("SW193AA")
        .forename("RACHEL")
        .mobileNumber(mobileNumber)
        .build();
  }

  static Party buildNonWebAndWebCustomerRecord(
      final Long sysId, final PartyType partyType, final String mobileNumber) {
    return Party.builder()
        .sysId(sysId)
        .partyType(partyType)
        .person(
            Person.builder()
                .title("MISS")
                .forenames("RACHEL")
                .surname(NOCK)
                .dateOfBirth(LocalDate.now().minusYears(18))
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("AddressLine1_1")
                        .line2("AddressLine2_1")
                        .line4("AddressLine3_1")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("SW")
                                .districtCode("19")
                                .sectorCode("3")
                                .unitCode("AA")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressUsage.AddressFunction.CORR)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddress(CUSTOMER_EMAIL_ADDRESS))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .preferredContactMethod(true)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address(CUSTOMER_HOME_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address(mobileNumber)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address(CUSTOMER_WORK_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .build();
  }

  static Party buildNonWebAndWebCustomerRecord(
      final Long sysId,
      final PartyType partyType,
      final String mobileNumber,
      final String surname) {
    return Party.builder()
        .sysId(sysId)
        .partyType(partyType)
        .person(
            Person.builder()
                .title("MISS")
                .forenames("RACHEL")
                .surname(surname)
                .dateOfBirth(LocalDate.now().minusYears(18))
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("AddressLine1_1")
                        .line2("AddressLine2_1")
                        .line4("AddressLine3_1")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("SW")
                                .districtCode("19")
                                .sectorCode("3")
                                .unitCode("AA")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressUsage.AddressFunction.CORR)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddress(CUSTOMER_EMAIL_ADDRESS))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .preferredContactMethod(true)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address(CUSTOMER_HOME_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address(mobileNumber)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address(CUSTOMER_WORK_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .build();
  }

  static PartyType getPartyType(final String code) {
    return PartyType.builder().code(code).type("PERSON").startDate(YESTERDAY).build();
  }

  public URI getURI(final String path, final Object... args) {
    return URI.create("http://localhost:" + port + BASE_PATH + String.format(path, args));
  }

  void signingWebTestClientForFailure(
      final String path,
      final CustomerDelayedRequest customerDelayedRequest,
      final ErrorResponse errorResponse,
      final HttpStatus status) {
    signingWebTestClient
        .post()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, SESSION_ID.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .bodyValue(customerDelayedRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(status)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  void signingWebTestClientForSuccess(
      final String path,
      final CustomerDelayedRequest customerDelayedRequest,
      final CustomerBasicResponse expectedDelayedResponse) {
    signingWebTestClient
        .post()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, UUID.randomUUID().toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .bodyValue(customerDelayedRequest)
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(CustomerBasicResponse.class)
        .isEqualTo(expectedDelayedResponse);
  }

  /* Customer delayed record from ADG Core Tests --- End */

  static RequestMetadata buildExpectedRequestMetadata(final UUID requestId, final String jwt) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .sessionId(SESSION_ID)
        .host(InetSocketAddress.createUnresolved("localhost/127.0.0.1", 0))
        .brandCode(BRAND_CODE_YBS)
        .partyId(CANONICAL_PARTY_ID)
        .forwardingAuth(jwt)
        .ipAddress("127.0.0.1")
        .webCustomerNumber(CANONICAL_PARTY_ID)
        .build();
  }

  WorkLog workLogPhoneNumber(
      final Operation operation,
      final PhoneNumberRequestType type,
      final Integer areaDiallingCode,
      final String number,
      final RequestMetadata metadata) {

    WorkLogPayload workLogPayload;

    if (operation == Operation.UPDATE_PHONE_NUMBER) {
      workLogPayload =
          UpdatePhoneRequest.builder()
              .requestType(type)
              .areaDiallingCode(areaDiallingCode)
              .number(number)
              .build();
    } else {
      workLogPayload = DeletePhoneRequest.builder().requestType(type).build();
    }

    return WorkLog.builder()
        .partyId(12462951L)
        .status(Status.PENDING)
        .operation(operation)
        .message(WorkLogRequest.builder().workLogPayload(workLogPayload).metadata(metadata).build())
        .createdBy(PARTY_SYSID)
        .updatedBy(PARTY_SYSID)
        .build();
  }

  WorkLog workLogPostalAddressWithPaf(
      final PostalAddressRequest request, final RequestMetadata metadata) {

    final Optional<PostCode> splitPostCode =
        PostCodeHelper.splitPostCode(request.getAddress().getPostCode());

    return WorkLog.builder()
        .partyId(12462951L)
        .status(Status.PENDING)
        .operation(Operation.POSTAL_ADDRESS)
        .message(
            WorkLogRequest.builder()
                .workLogPayload(
                    UpdatePostalAddressRequest.builder()
                        .addressLine1(request.getAddress().getAddressLines().get(0))
                        .addressLine2(request.getAddress().getAddressLines().get(1))
                        .addressLine3(request.getAddress().getAddressLines().get(2))
                        .addressLine4(request.getAddress().getAddressLines().get(3))
                        .addressLine5(request.getAddress().getAddressLines().get(4))
                        .addressType(request.getAddress().getSubType())
                        .function(request.getAddress().getType())
                        .country(request.getAddress().getCountry().getCode())
                        .areaCode(splitPostCode.get().getAreaCode())
                        .districtCode(splitPostCode.get().getDistrictCode())
                        .sectorCode(splitPostCode.get().getSectorCode())
                        .unitCode(splitPostCode.get().getUnitCode())
                        .pafAddressKey(request.getPaf().getAddressKey())
                        .pafDeliveryPointSuffix(request.getPaf().getDeliveryPointSuffix())
                        .build())
                .metadata(metadata)
                .build())
        .createdBy(PARTY_SYSID)
        .updatedBy(PARTY_SYSID)
        .build();
  }

  WorkLog workLogEmail(
      final Operation operation, final String address, final RequestMetadata metadata) {

    return WorkLog.builder()
        .partyId(12462951L)
        .status(Status.PENDING)
        .operation(operation)
        .message(
            WorkLogRequest.builder()
                .workLogPayload(
                    UpdateEmailRequest.builder().requestType("Email").email(address).build())
                .metadata(metadata)
                .build())
        .createdBy(PARTY_SYSID)
        .updatedBy(PARTY_SYSID)
        .build();
  }

  void stubMockAuditServiceResponse() {
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  void stubMockAccountServiceResponseWithWarnings() throws JsonProcessingException {

    String groupedInfo = objectMapper.writeValueAsString(buildAccountGroupedInfo());

    mockAccountService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(groupedInfo));
  }

  void stubMockShareplanServiceResponse() throws JsonProcessingException {

    String shareplanServiceResponse =
        objectMapper.writeValueAsString(TestHelper.buildShareplanAccount());

    mockShareplanService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(shareplanServiceResponse));
  }

  void stubMockAccountServiceResponseWithoutRestrictions() throws JsonProcessingException {

    String groupedInfo =
        objectMapper.writeValueAsString(buildAccountGroupedInfoWithNoRestrictions());

    mockAccountService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(groupedInfo));
  }

  String postPostalAddressRequestWithoutSca(
      final UUID requestId, final PostalAddressRequest postalAddressRequest, final String jwt) {

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    return signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .value(HEADER_SCA_CHALLENGE, is(not(emptyOrNullString())))
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse)
        .returnResult()
        .getResponseHeaders()
        .getFirst(HEADER_SCA_CHALLENGE);
  }

  String postEmailAddressRequestWithoutSca(
      final UUID requestId, final EmailAddress emailAddress, final String jwt) {

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    return signingWebTestClient
        .post()
        .uri(getURI(PATH_EMAIL_UPDATE))
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(emailAddress)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .value(HEADER_SCA_CHALLENGE, is(not(emptyOrNullString())))
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse)
        .returnResult()
        .getResponseHeaders()
        .getFirst(HEADER_SCA_CHALLENGE);
  }

  String postPhoneNumberRequestWithoutSca(
      final UUID requestId, final PhoneNumberRequest phoneNumberRequest, final String jwt) {

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    return signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .value(HEADER_SCA_CHALLENGE, is(not(emptyOrNullString())))
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse)
        .returnResult()
        .getResponseHeaders()
        .getFirst(HEADER_SCA_CHALLENGE);
  }

  String postPhoneNumberRequestWithoutScaBadRequest(
      final UUID requestId, final PhoneNumberRequest phoneNumberRequest, final String jwt) {

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("Area dialling code not recognised")
                    .path("phoneNumbers[0].number")
                    .build())
            .build();

    return signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .value(HEADER_SCA_CHALLENGE, is(emptyOrNullString()))
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse)
        .returnResult()
        .getResponseHeaders()
        .getFirst(HEADER_SCA_CHALLENGE);
  }

  void insert(final PostalAddressException addressException) {
    transactionTemplate.executeWithoutResult(
        status -> {
          adgCoreTestEntityManager.persist(addressException);
          adgCoreTestEntityManager.flush();
          adgCoreTestEntityManager.clear();
        });
  }

  void insert(final Party party) {
    transactionTemplate.executeWithoutResult(
        status -> {
          PartyType partyType =
              PartyType.builder()
                  .code(party.getPartyType().getCode())
                  .type(party.getPartyType().getType())
                  .startDate(party.getPartyType().getStartDate())
                  .endDate(party.getPartyType().getEndDate())
                  .build();

          adgCoreTestEntityManager.persist(partyType);

          // insert the party without the address usages and person record before inserting person
          // and address usages
          // as the there is a foreign key constraint back to this record.
          Party emptyParty =
              Party.builder()
                  .sysId(party.getSysId())
                  .partyType(partyType)
                  .endedDate(party.getEndedDate())
                  .build();

          adgCoreTestEntityManager.persist(emptyParty);

          Optional.ofNullable(party.getPerson())
              .ifPresent(
                  person -> {
                    person.setParty(emptyParty);
                    adgCoreTestEntityManager.persist(person);
                  });

          for (AddressUsage addressUsage : party.getAddresses()) {
            addressUsage.setParty(emptyParty);
            if (addressUsage.getNonPostalAddress() != null) {
              adgCoreTestEntityManager.persist(addressUsage.getNonPostalAddress());
            }
            if (addressUsage.getPostalAddress() != null) {
              adgCoreTestEntityManager.persist(addressUsage.getPostalAddress());
            }
            adgCoreTestEntityManager.persist(addressUsage);
          }

          adgCoreTestEntityManager.flush();
          adgCoreTestEntityManager.clear();
        });
  }

  void insert(final ContactDetailsChange contact) {
    transactionTemplate.executeWithoutResult(
        status -> {
          frontOfficeTestEntityManager.persist(contact);
          frontOfficeTestEntityManager.flush();
          frontOfficeTestEntityManager.clear();
        });
  }

  static NonPostalAddress buildEmailAddress(final String addr) {
    return NonPostalAddress.builder()
        .sysId(getNextId())
        .type(AddressType.EMAIL)
        .address(addr)
        .build();
  }

  private static long getNextId() {
    return nextId++;
  }

  PostalAddressRequest buildPostalAddressRequest() {
    return PostalAddressRequest.builder().address(buildPostalAddress()).paf(buildPafData()).build();
  }

  PostalAddressRequest buildPostalAddressRequestWithPaf() {
    return PostalAddressRequest.builder()
        .address(buildPOBoxPostalAddress())
        .paf(buildPafData())
        .build();
  }

  PostalAddressRequest buildPostalAddressRequestWithoutPaf() {
    return PostalAddressRequest.builder().address(buildPOBoxPostalAddress()).build();
  }

  PostalAddressRequest buildPostalAddressRequestWithNoChange(final Party party) {
    return PostalAddressRequest.builder()
        .address(buildPostalAddressWithNoChange(party))
        .paf(buildPafData())
        .build();
  }

  static uk.co.ybs.digital.customer.web.dto.PostalAddress buildPOBoxPostalAddress() {
    return uk.co.ybs.digital.customer.web.dto.PostalAddress.builder()
        .type(POSTAL_ADDRESS_FUNCTION)
        .subType(POSTAL_ADDRESS_TYPE)
        .addressLines(Collections.singleton(PO_BOX))
        .addressLines(Collections.singleton(ADDRESS_LINE_2))
        .addressLines(Collections.singleton(ADDRESS_LINE_3))
        .addressLines(Collections.singleton(ADDRESS_LINE_4))
        .addressLines(Collections.singleton(ADDRESS_LINE_5))
        .postCode(POSTCODE)
        .country(COUNTRY)
        .build();
  }

  static uk.co.ybs.digital.customer.web.dto.PostalAddress buildPostalAddress() {
    return uk.co.ybs.digital.customer.web.dto.PostalAddress.builder()
        .type(POSTAL_ADDRESS_FUNCTION)
        .subType(POSTAL_ADDRESS_TYPE)
        .addressLines(Collections.singleton(ADDRESS_LINE_1))
        .addressLines(Collections.singleton(ADDRESS_LINE_2))
        .addressLines(Collections.singleton(ADDRESS_LINE_3))
        .addressLines(Collections.singleton(ADDRESS_LINE_4))
        .addressLines(Collections.singleton(ADDRESS_LINE_5))
        .postCode(POSTCODE)
        .country(COUNTRY)
        .build();
  }

  static uk.co.ybs.digital.customer.web.dto.PostalAddress buildPostalAddressWithNoChange(
      final Party party) {
    return uk.co.ybs.digital.customer.web.dto.PostalAddress.builder()
        .type(POSTAL_ADDRESS_FUNCTION)
        .subType(POSTAL_ADDRESS_TYPE)
        .addressLines(
            Collections.singleton(party.getAddresses().get(0).getPostalAddress().getLine1()))
        .addressLines(
            Collections.singleton(party.getAddresses().get(0).getPostalAddress().getLine2()))
        .addressLines(
            Collections.singleton(party.getAddresses().get(0).getPostalAddress().getLine4()))
        .postCode(party.getAddresses().get(0).getPostalAddress().getPostCode().toString())
        .country(PermittedCountries.UNITED_KINGDOM)
        .build();
  }

  static PafData buildPafData() {
    return PafData.builder().addressKey(PAF_KEY).deliveryPointSuffix(PAF_DPS).build();
  }

  EmailAddress buildEmailAddressRequest() {
    return EmailAddress.builder().type(EMAIL_ADDRESS_TYPE).email(EMAIL_ADDRESS).build();
  }

  Matcher<WorkLog> workLogMatching(final WorkLog expected, final LocalDateTime now) {
    return allOf(
        samePropertyValuesAs(expected, "sysId", "message", "createdDate", "updatedDate"),
        hasProperty("sysId", notNullValue()),
        hasProperty("createdDate", equalsOrWithinTenSeconds(now)),
        hasProperty("updatedDate", equalsOrWithinTenSeconds(now)),
        hasPropertyAtPath(
            "message.workLogPayload",
            samePropertyValuesAs((Object) expected.getMessage().getWorkLogPayload())),
        hasPropertyAtPath(
            "message.metadata",
            samePropertyValuesAs((Object) expected.getMessage().getMetadata(), "host")));
  }

  Matcher<LocalDateTime> equalsOrWithinTenSeconds(final LocalDateTime time) {
    final LocalDateTime timeTruncated = time.truncatedTo(ChronoUnit.SECONDS);
    final LocalDateTime maximumTime = timeTruncated.plusSeconds(10);
    return new CustomTypeSafeMatcher<LocalDateTime>("equal or within 10 seconds of time") {
      @Override
      protected boolean matchesSafely(final LocalDateTime argument) {
        return !argument.isBefore(timeTruncated) && !argument.isAfter(maximumTime);
      }
    };
  }

  @SafeVarargs
  final void assertWorkLogs(final Matcher<WorkLog>... expected) {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              digitalCustomerTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from WorkLog e");
          @SuppressWarnings("unchecked")
          final List<WorkLog> actual = query.getResultList();
          assertThat(actual, containsInAnyOrder(expected));
        });
  }

  Matcher<ContactDetailsChange> contactDetailsChangeMatcher(
      final ContactDetailsChange expected, final LocalDateTime now) {
    return allOf(
        samePropertyValuesAs(expected, "amendDate"),
        hasProperty("amendDate", equalsOrWithinTenSeconds(now)));
  }

  @SafeVarargs
  final void assertContactDetailsChange(final Matcher<ContactDetailsChange>... expected) {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              frontOfficeTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from ContactDetailsChange e");
          @SuppressWarnings("unchecked")
          final List<ContactDetailsChange> actual = query.getResultList();
          assertThat(actual, containsInAnyOrder(expected));
        });
  }

  Matcher<AddressChange> addressChangeMatcher(
      final AddressChange expected, final LocalDateTime now) {
    return allOf(
        samePropertyValuesAs(expected, "amendDate"),
        hasProperty("amendDate", equalsOrWithinTenSeconds(now)));
  }

  @SafeVarargs
  final void assertAddressChange(final Matcher<AddressChange>... expected) {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              frontOfficeTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from AddressChange e");
          @SuppressWarnings("unchecked")
          final List<AddressChange> actual = query.getResultList();
          assertThat(actual, containsInAnyOrder(expected));
        });
  }

  static Stream<Arguments> phoneNumberArgs() {
    // type, areaCode, number, formatted number
    return Stream.of(
        Arguments.of(PhoneNumberBasicType.HOME, ADC_CODE, "123456", "01234123456"),
        Arguments.of(PhoneNumberBasicType.MOBILE, null, "07100123456", "07100123456"),
        Arguments.of(PhoneNumberBasicType.WORK, ADC_CODE, "123456", "01234123456"),
        Arguments.of(PhoneNumberBasicType.WORK, 7525, "123456", "07525123456")); // NOPMD
  }

  static Stream<Arguments> badPhoneNumberArgs() {
    // type, areaCode, number, formatted number
    return Stream.of(
        // this area code is listed by ofcom as one that will never be used
        Arguments.of(PhoneNumberBasicType.WORK, 1134, "123456", "01134123456"));
  }

  List<NonPostalAddress> buildPreviousNonPostalAddresses() {
    return Arrays.asList(
        NonPostalAddress.builder()
            .type(AddressType.EMAIL)
            .address("prev.email@gmail.com")
            .sysId(1000L)
            .build(),
        NonPostalAddress.builder()
            .address("10000")
            .adcCode("01234")
            .country(Country.builder().code("UK").build())
            .sysId(1001L)
            .sourceType(NPASourceType.HOME)
            .type(AddressType.TEL)
            .build(),
        NonPostalAddress.builder()
            .address("07525100000")
            .country(Country.builder().code("UK").build())
            .sysId(1002L)
            .sourceType(NPASourceType.MOBILE)
            .type(AddressType.TEL)
            .build(),
        NonPostalAddress.builder()
            .address("20000")
            .adcCode("01234")
            .country(Country.builder().code("UK").build())
            .sysId(1003L)
            .sourceType(NPASourceType.WORK)
            .type(AddressType.TEL)
            .build());
  }

  static Stream<Arguments> shouldGetCustomerDetailsArgs() {
    return Stream.of(
        arguments(PATH_CUSTOMER_DETAILS, null),
        arguments(PATH_CUSTOMER_DETAILS, "518bc97a-468b-4206-ad20-562b23132c17"),
        arguments(PATH_CUSTOMER_DETAILS_PRIVATE, null),
        arguments(PATH_CUSTOMER_DETAILS_PRIVATE, "518bc97a-468b-4206-ad20-562b23132c17"));
  }
}
