package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.NonNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import uk.co.ybs.digital.customer.exception.CustomerServiceException;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.FatcaParty;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.Nationality;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.Person;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddress;
import uk.co.ybs.digital.customer.service.PendingDetailsService;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.EmailAddressResponse;
import uk.co.ybs.digital.customer.web.dto.EncryptedData;
import uk.co.ybs.digital.customer.web.dto.FatcaProfile;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerExtendedRecord;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.MarketingPreferences;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberSubType;
import uk.co.ybs.digital.customer.web.dto.PostalAddressResponse;
import uk.co.ybs.digital.customer.web.dto.Preferences;
import uk.co.ybs.services.crypto.asymmetric.AsymmetricKey;
import uk.co.ybs.services.crypto.asymmetric.Crypto;
import uk.co.ybs.services.crypto.asymmetric.CryptoException;
import uk.co.ybs.services.crypto.asymmetric.CryptoProperties;

@ExtendWith(SpringExtension.class)
@SpringBootTest(
    classes = {
      GoldenCustomerRecordMapperImpl.class,
      PhoneNumberMapperImpl.class,
      EmailMapperImpl.class,
      PostalAddressMapperImpl.class,
      MarketingPreferencesMapperImpl.class,
      PreferencesMapperImpl.class
    })
@SuppressWarnings("PMD.ExcessiveParameterList")
public class GoldenCustomerRecordMapperTest {

  private static final LocalDate DATE_OF_BIRTH = LocalDate.of(1981, 1, 1);
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-09-01T10:15:30");
  private static final LocalDateTime YESTERDAY = NOW.minusDays(1);
  public static final String CRYPTO_EXCEPTION_MESSAGE = "Crypto Exception";
  public static final String CORR_TYPE = "CORR";
  public static final String TITLE = "title";
  public static final String FORENAME = "forename";
  public static final String SURNAME = "surname";
  public static final String EMAIL_ADDRESS = "test@test.com";
  public static final Long SYSID = 123456L;
  public static final String CUSTOMER_NUMBER = "123456";
  public static final String HOME_MOBILE_NUMBER = "01234421693";
  public static final String NATIONAL_INSURANCE_NUMBER = "AB123456C";
  public static final String NATIONALITY = "BRITISH";
  public static final String PHONE_TYPE_HOME = "HOME";
  public static final String ADDRESS_LINE_1 = "AddressLine1_1";
  public static final String ADDRESS_LINE_2 = "AddressLine2_1";
  public static final String ADDRESS_LINE_3 = "AddressLine3_1";
  public static final String POSTCODE = "PO57 7DE";

  @MockBean PendingDetailsService pendingDetailsService;

  @MockBean Crypto crypto;

  @Autowired private GoldenCustomerRecordMapper testSubject;

  @ParameterizedTest
  @MethodSource("mapperArguments")
  void shouldMapPartyToGoldenCustomerRecord(
      final String title,
      final String forenames,
      final String surname,
      final String nationalInsuranceNumber,
      final LocalDate dateOfBirth,
      final List<EmailAddressResponse> emailAddress,
      final List<PhoneNumberResponse> phoneNumbers,
      final List<PostalAddressResponse> address,
      final boolean amendmentRestriction,
      final boolean hasIsaSubscription,
      final boolean hasSharePlanAccount,
      final Nationality nationality,
      final List<MarketingOptIn> marketingOptIns,
      final List<uk.co.ybs.digital.customer.model.adgcore.FatcaProfile> fatcaProfiles,
      final Optional<FatcaParty> fatcaParty) {

    final Party party =
        getPartyAndSetupExpectations(
            title,
            forenames,
            surname,
            nationalInsuranceNumber,
            dateOfBirth,
            emailAddress,
            nationality);

    final GoldenCustomerRecord expectedCustomer;

    if (!fatcaProfiles.isEmpty()) {
      expectedCustomer =
          buildGoldenCustomerRecordWithFatcaResponse(
              title,
              forenames,
              surname,
              nationalInsuranceNumber,
              dateOfBirth,
              emailAddress,
              phoneNumbers,
              address,
              amendmentRestriction,
              hasSharePlanAccount,
              hasIsaSubscription,
              nationality == null ? null : nationality.getName(),
              fatcaProfiles,
              fatcaParty);
    } else {
      expectedCustomer =
          buildGoldenCustomerRecordResponse(
              title,
              forenames,
              surname,
              nationalInsuranceNumber,
              dateOfBirth,
              emailAddress,
              phoneNumbers,
              address,
              amendmentRestriction,
              hasSharePlanAccount,
              hasIsaSubscription,
              nationality == null ? null : nationality.getName());
    }

    final GoldenCustomerRecord customer =
        testSubject.map(
            party,
            amendmentRestriction,
            hasSharePlanAccount,
            hasIsaSubscription,
            CUSTOMER_NUMBER,
            marketingOptIns,
            !fatcaProfiles.isEmpty() ? fatcaProfiles : null,
            fatcaParty.orElse(null));

    assertThat(customer, is(expectedCustomer));
  }

  @ParameterizedTest
  @MethodSource("mapperArguments")
  void shouldMapPartyToGoldenCustomerExtendedRecord(
      final String title,
      final String forenames,
      final String surname,
      final String nationalInsuranceNumber,
      final LocalDate dateOfBirth,
      final List<EmailAddressResponse> emailAddress,
      final List<PhoneNumberResponse> phoneNumbers,
      final List<PostalAddressResponse> address,
      final boolean amendmentRestriction,
      final boolean hasIsaSubscription,
      final boolean hasSharePlanAccount,
      final Nationality nationality,
      final List<MarketingOptIn> marketingOptIns,
      final List<uk.co.ybs.digital.customer.model.adgcore.FatcaProfile> fatcaProfiles,
      final Optional<FatcaParty> fatcaParty)
      throws CryptoException {

    final Party party =
        getPartyAndSetupExpectations(
            title,
            forenames,
            surname,
            nationalInsuranceNumber,
            dateOfBirth,
            emailAddress,
            nationality);

    final GoldenCustomerRecord expectedCustomer;

    if (!fatcaProfiles.isEmpty()) {
      expectedCustomer =
          buildGoldenCustomerExtendedRecordWithFatcaResponse(
              title,
              forenames,
              surname,
              nationalInsuranceNumber,
              dateOfBirth,
              emailAddress,
              phoneNumbers,
              address,
              amendmentRestriction,
              hasSharePlanAccount,
              hasIsaSubscription,
              nationality == null ? null : nationality.getName(),
              fatcaProfiles,
              fatcaParty);
    } else {
      expectedCustomer =
          buildGoldenCustomerExtendedRecordResponse(
              title,
              forenames,
              surname,
              nationalInsuranceNumber,
              dateOfBirth,
              emailAddress,
              phoneNumbers,
              address,
              amendmentRestriction,
              hasSharePlanAccount,
              hasIsaSubscription,
              nationality == null ? null : nationality.getName());
    }

    when(crypto.getCryptoProperties()).thenReturn(buildCryptoProperties());

    when(crypto.encrypt(any(), any()))
        .thenReturn(
            uk.co.ybs.services.model.EncryptedData.builder()
                .keyId("key") // NOPMD
                .data("encrypted") // NOPMD
                .build());

    final GoldenCustomerExtendedRecord customer =
        testSubject.mapExtended(
            party,
            amendmentRestriction,
            hasSharePlanAccount,
            hasIsaSubscription,
            CUSTOMER_NUMBER,
            marketingOptIns,
            !fatcaProfiles.isEmpty() ? fatcaProfiles : null,
            fatcaParty.orElse(null));

    assertThat(customer, is(expectedCustomer));
  }

  @Test
  void shouldThrowCustomerServiceExceptionOnEncryptionFailure() throws CryptoException {

    final Party party =
        getPartyAndSetupExpectations(
            TITLE,
            "forenames",
            SURNAME,
            NATIONAL_INSURANCE_NUMBER,
            DATE_OF_BIRTH,
            Collections.singletonList(buildEmailAddressResponse(EMAIL_ADDRESS, false)),
            null);

    when(crypto.getCryptoProperties()).thenReturn(buildCryptoProperties());

    when(crypto.encrypt(any(), any())).thenThrow(new CryptoException(CRYPTO_EXCEPTION_MESSAGE));

    CustomerServiceException ex =
        assertThrows(
            CustomerServiceException.class,
            () ->
                testSubject.mapExtended(
                    party,
                    true,
                    true,
                    true,
                    CUSTOMER_NUMBER,
                    TestHelper.buildMarketingOptIns(),
                    null,
                    null));

    assertThat(ex.getMessage(), equalTo("Failed to encrypt value"));
    assertThat(ex.getCause().getMessage(), equalTo(CRYPTO_EXCEPTION_MESSAGE));
  }

  @NonNull
  private CryptoProperties buildCryptoProperties() {
    CryptoProperties cryptoProperties = new CryptoProperties();
    AsymmetricKey key =
        new AsymmetricKey("key", "transformation", "privateKey", "publicKey"); // NOPMD
    cryptoProperties.setKeys(Collections.singletonList(key));
    return cryptoProperties;
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private Party getPartyAndSetupExpectations(
      final String title,
      final String forenames,
      final String surname,
      final String nationalInsuranceNumber,
      final LocalDate dateOfBirth,
      final List<EmailAddressResponse> emailAddress,
      final Nationality nationality) {
    NonPostalAddress firstEmail =
        NonPostalAddress.builder().type(AddressType.EMAIL).address(EMAIL_ADDRESS).build();

    PhoneNumberResponse firstNumber =
        PhoneNumberResponse.builder()
            .number(HOME_MOBILE_NUMBER)
            .type(PHONE_TYPE_HOME)
            .subType(PhoneNumberSubType.LANDLINE)
            .pendingUpdate(false)
            .build();

    PostalAddress firstPostalAddress =
        PostalAddress.builder()
            .sysId(3L) // NOPMD
            .line1(ADDRESS_LINE_1)
            .line2(ADDRESS_LINE_2)
            .line3(ADDRESS_LINE_3)
            .country(Country.builder().code("UK").isoCode("GB").build())
            .postCode(
                PostCode.builder()
                    .areaCode("PO")
                    .districtCode("57")
                    .sectorCode("0")
                    .unitCode("DE")
                    .build())
            .type(AddressType.UKPOST)
            .build();

    final Party party =
        Party.builder()
            .sysId(SYSID)
            .placeOfBirth("Leeds")
            .person(
                Person.builder()
                    .title(title)
                    .forenames(forenames)
                    .surname(surname)
                    .dateOfBirth(dateOfBirth)
                    .nationalInsuranceNumber(nationalInsuranceNumber)
                    .nationality(nationality)
                    .build())
            .address(
                AddressUsage.builder()
                    .postalAddress(firstPostalAddress)
                    .function(AddressFunction.CORR)
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(firstEmail)
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.TEL)
                            .address("421693")
                            .adcCode("1234")
                            .sourceType(NPASourceType.HOME)
                            .country(Country.builder().code("UK").isoCode("GB").build())
                            .build())
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .build();

    EmailAddressResponse emailAddressResponse =
        EmailAddressResponse.builder()
            .email(emailAddress.get(0).getEmail())
            .type(emailAddress.get(0).getType())
            .pendingUpdate(emailAddress.get(0).isPendingUpdate())
            .build();

    PhoneNumberResponse phoneNumberResponse =
        PhoneNumberResponse.builder()
            .type(PHONE_TYPE_HOME)
            .subType(PhoneNumberSubType.LANDLINE)
            .number(HOME_MOBILE_NUMBER)
            .build();

    PostalAddressResponse postalAddressResponse =
        buildPostalAddressResponse(
            Arrays.asList(ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3), POSTCODE, false);

    when(pendingDetailsService.buildEmailAddressResponse(party, firstEmail))
        .thenReturn(emailAddressResponse);

    when(pendingDetailsService.buildPhoneNumberResponse(party, firstNumber))
        .thenReturn(phoneNumberResponse);

    when(pendingDetailsService.buildPostalAddressResponse(party, firstPostalAddress, CORR_TYPE))
        .thenReturn(postalAddressResponse);

    return party;
  }

  @Test
  @SuppressWarnings({"PMD.ExcessiveMethodLength", "PMD.AvoidDuplicateLiterals"})
  void shouldMapPartyToGoldenCustomerRecordWithMultipleAddressUsages() {
    NonPostalAddress firstEmail =
        NonPostalAddress.builder()
            .sysId(1L) // NOPMD
            .type(AddressType.EMAIL)
            .address(EMAIL_ADDRESS)
            .build();

    NonPostalAddress secondEmail =
        NonPostalAddress.builder()
            .sysId(2L) // NOPMD
            .type(AddressType.EMAIL)
            .address("test2@test.com")
            .build();

    PostalAddress firstPostalAddress =
        PostalAddress.builder()
            .sysId(3L) // NOPMD
            .line1(ADDRESS_LINE_1)
            .line2(ADDRESS_LINE_2)
            .line3(ADDRESS_LINE_3)
            .country(Country.builder().code("UK").isoCode("GB").build())
            .postCode(
                PostCode.builder()
                    .areaCode("PO")
                    .districtCode("57")
                    .sectorCode("0")
                    .unitCode("DE")
                    .build())
            .type(AddressType.UKPOST)
            .build();

    PostalAddress secondPostalAddress =
        PostalAddress.builder()
            .sysId(4L) // NOPMD
            .line1("AddressLine1_2")
            .line2("AddressLine2_2")
            .line3("AddressLine3_2")
            .country(Country.builder().code("UK").isoCode("GB").build())
            .postCode(
                PostCode.builder()
                    .areaCode("LS")
                    .districtCode("1")
                    .sectorCode("5")
                    .unitCode("AB")
                    .build())
            .type(AddressType.UKPOST)
            .build();

    PhoneNumberResponse firstNumber =
        PhoneNumberResponse.builder()
            .number("01234567890")
            .type(PHONE_TYPE_HOME)
            .subType(PhoneNumberSubType.LANDLINE)
            .pendingUpdate(false)
            .build();

    PhoneNumberResponse secondNumber =
        PhoneNumberResponse.builder()
            .number("07987654321")
            .type("MOBILE")
            .subType(PhoneNumberSubType.MOBILE)
            .pendingUpdate(false)
            .build();

    PhoneNumberResponse thirdNumber =
        PhoneNumberResponse.builder()
            .number("04321567890")
            .type("WORK")
            .subType(PhoneNumberSubType.LANDLINE)
            .pendingUpdate(false)
            .build();

    final Party party =
        Party.builder()
            .sysId(SYSID)
            .person(
                Person.builder()
                    .title(TITLE)
                    .forenames(FORENAME)
                    .surname(SURNAME)
                    .dateOfBirth(DATE_OF_BIRTH)
                    .nationalInsuranceNumber(NATIONAL_INSURANCE_NUMBER)
                    .nationality(Nationality.builder().code("BRIT").name(NATIONALITY).build())
                    .build())
            .address(
                AddressUsage.builder()
                    .postalAddress(firstPostalAddress)
                    .function(AddressFunction.CORR)
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .address(
                AddressUsage.builder()
                    .postalAddress(secondPostalAddress)
                    .function(AddressFunction.CORR)
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(firstEmail)
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(secondEmail)
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.TEL)
                            .address("567890")
                            .adcCode("1234")
                            .sourceType(NPASourceType.HOME)
                            .country(Country.builder().code("UK").isoCode("GB").build())
                            .build())
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.TEL)
                            .address("567890")
                            .adcCode("4321")
                            .sourceType(NPASourceType.WORK)
                            .country(Country.builder().code("UK").isoCode("GB").build())
                            .build())
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.TEL)
                            .address("07987654321")
                            .sourceType(NPASourceType.MOBILE)
                            .build())
                    .startDate(YESTERDAY)
                    .createdDate(YESTERDAY)
                    .build())
            .build();

    final GoldenCustomerRecord expectedCustomer =
        buildGoldenCustomerRecordResponse(
            Arrays.asList(
                buildEmailAddressResponse(EMAIL_ADDRESS, false),
                buildEmailAddressResponse("test2@test.com", false)),
            Arrays.asList(
                buildPhoneNumberResponse(
                    "01234567890", PHONE_TYPE_HOME, PhoneNumberSubType.LANDLINE),
                buildPhoneNumberResponse("07987654321", "MOBILE", PhoneNumberSubType.MOBILE),
                buildPhoneNumberResponse("04321567890", "WORK", PhoneNumberSubType.LANDLINE)),
            Arrays.asList(
                buildPostalAddressResponse(
                    Arrays.asList(ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3), POSTCODE, false),
                buildPostalAddressResponse(
                    Arrays.asList("AddressLine1_2", "AddressLine2_2", "AddressLine3_2"),
                    "LS1 5AB",
                    false)));

    PostalAddressResponse firstPostalAddressMapped =
        buildPostalAddressResponse(
            Arrays.asList(ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3), POSTCODE, false);

    PostalAddressResponse secondPostalAddressMapped =
        buildPostalAddressResponse(
            Arrays.asList("AddressLine1_2", "AddressLine2_2", "AddressLine3_2"), "LS1 5AB", false);

    EmailAddressResponse firstEmailMapped =
        EmailAddressResponse.builder()
            .email(EMAIL_ADDRESS)
            .type("DEFAULT")
            .pendingUpdate(false)
            .build();

    EmailAddressResponse secondEmailMapped =
        EmailAddressResponse.builder()
            .email("test2@test.com")
            .type("DEFAULT")
            .pendingUpdate(false)
            .build();

    PhoneNumberResponse phoneNumberResponse =
        PhoneNumberResponse.builder()
            .type(PHONE_TYPE_HOME)
            .subType(PhoneNumberSubType.LANDLINE)
            .pendingUpdate(false)
            .number("01234567890")
            .build();

    PhoneNumberResponse phoneNumberResponse2 =
        PhoneNumberResponse.builder()
            .type("WORK")
            .subType(PhoneNumberSubType.LANDLINE)
            .pendingUpdate(false)
            .number("04321567890")
            .build();

    PhoneNumberResponse phoneNumberResponse3 =
        PhoneNumberResponse.builder()
            .type("MOBILE")
            .subType(PhoneNumberSubType.MOBILE)
            .pendingUpdate(false)
            .number("07987654321")
            .build();

    when(pendingDetailsService.buildEmailAddressResponse(party, firstEmail))
        .thenReturn(firstEmailMapped);

    when(pendingDetailsService.buildEmailAddressResponse(party, secondEmail))
        .thenReturn(secondEmailMapped);

    when(pendingDetailsService.buildPhoneNumberResponse(party, firstNumber))
        .thenReturn(phoneNumberResponse);

    when(pendingDetailsService.buildPhoneNumberResponse(party, secondNumber))
        .thenReturn(phoneNumberResponse2);

    when(pendingDetailsService.buildPhoneNumberResponse(party, thirdNumber))
        .thenReturn(phoneNumberResponse3);

    when(pendingDetailsService.buildPostalAddressResponse(party, firstPostalAddress, CORR_TYPE))
        .thenReturn(firstPostalAddressMapped);

    when(pendingDetailsService.buildPostalAddressResponse(party, secondPostalAddress, CORR_TYPE))
        .thenReturn(secondPostalAddressMapped);

    final GoldenCustomerRecord customer =
        testSubject.map(party, false, false, false, CUSTOMER_NUMBER, null, null, null);
    assertThat(customer, is(expectedCustomer));
  }

  @Test
  void shouldMapPartyToGoldenCustomerRecordWithNoAddressUsages() {
    final Party party =
        Party.builder()
            .sysId(SYSID)
            .person(
                Person.builder()
                    .title(TITLE)
                    .forenames(FORENAME)
                    .surname(SURNAME)
                    .dateOfBirth(DATE_OF_BIRTH)
                    .nationalInsuranceNumber(NATIONAL_INSURANCE_NUMBER)
                    .nationality(Nationality.builder().code("BRIT").name(NATIONALITY).build())
                    .build())
            .build();

    final GoldenCustomerRecord expectedCustomer =
        buildGoldenCustomerRecordResponse(
            Collections.emptyList(), Collections.emptyList(), Collections.emptyList());

    final GoldenCustomerRecord customer =
        testSubject.map(party, false, false, false, CUSTOMER_NUMBER, null, null, null);
    assertThat(customer, is(expectedCustomer));
  }

  private static GoldenCustomerRecord buildGoldenCustomerRecordResponse(
      final List<EmailAddressResponse> emailAddresses,
      final List<PhoneNumberResponse> phoneNumbers,
      final List<PostalAddressResponse> addresses) {
    return GoldenCustomerRecord.builder()
        .partyId(CUSTOMER_NUMBER)
        .title(TITLE)
        .forename(FORENAME)
        .surname(SURNAME)
        .nationalInsuranceNumber(NATIONAL_INSURANCE_NUMBER)
        .dateOfBirth(DATE_OF_BIRTH)
        .emailAddresses(emailAddresses)
        .phoneNumbers(phoneNumbers)
        .addresses(addresses)
        .amendmentRestriction(false)
        .hasSharePlanAccount(false)
        .hasIsaSubscription(false)
        .webCustomerNumber(CUSTOMER_NUMBER)
        .nationality(NATIONALITY)
        .build();
  }

  private static GoldenCustomerRecord buildGoldenCustomerRecordResponse(
      final String title,
      final String forename,
      final String surname,
      final String nationalInsuranceNumber,
      final LocalDate dateOfBirth,
      final List<EmailAddressResponse> emailAddress,
      final List<PhoneNumberResponse> phoneNumbers,
      final List<PostalAddressResponse> address,
      final boolean amendmentRestriction,
      final boolean hasSharePlanAccount,
      final boolean hasIsaSubscription,
      final String nationality) {
    return GoldenCustomerRecord.builder()
        .partyId(CUSTOMER_NUMBER)
        .title(title)
        .forename(forename)
        .surname(surname)
        .nationalInsuranceNumber(nationalInsuranceNumber)
        .dateOfBirth(dateOfBirth)
        .emailAddresses(emailAddress)
        .phoneNumbers(phoneNumbers)
        .addresses(address)
        .amendmentRestriction(amendmentRestriction)
        .hasSharePlanAccount(hasSharePlanAccount)
        .hasIsaSubscription(hasIsaSubscription)
        .webCustomerNumber(CUSTOMER_NUMBER)
        .nationality(nationality)
        .marketingPreferences(
            MarketingPreferences.builder().post(true).phone(true).email(true).eagm(true).build())
        .preferences(buildPreferences())
        .build();
  }

  private static GoldenCustomerExtendedRecord buildGoldenCustomerExtendedRecordResponse(
      final String title,
      final String forename,
      final String surname,
      final String nationalInsuranceNumber,
      final LocalDate dateOfBirth,
      final List<EmailAddressResponse> emailAddress,
      final List<PhoneNumberResponse> phoneNumbers,
      final List<PostalAddressResponse> address,
      final boolean amendmentRestriction,
      final boolean hasSharePlanAccount,
      final boolean hasIsaSubscription,
      final String nationality) {
    return GoldenCustomerExtendedRecord.builder()
        .partyId(CUSTOMER_NUMBER)
        .title(title)
        .forename(forename)
        .surname(surname)
        .nationalInsuranceNumber(nationalInsuranceNumber)
        .dateOfBirth(dateOfBirth)
        .placeOfBirth(EncryptedData.builder().keyId("key").data("encrypted").build()) // NOPMD
        .emailAddresses(emailAddress)
        .phoneNumbers(phoneNumbers)
        .addresses(address)
        .amendmentRestriction(amendmentRestriction)
        .hasSharePlanAccount(hasSharePlanAccount)
        .hasIsaSubscription(hasIsaSubscription)
        .webCustomerNumber(CUSTOMER_NUMBER)
        .nationality(nationality)
        .marketingPreferences(
            MarketingPreferences.builder().post(true).phone(true).email(true).eagm(true).build())
        .preferences(buildPreferences())
        .build();
  }

  private static GoldenCustomerRecord buildGoldenCustomerRecordWithFatcaResponse(
      final String title,
      final String forename,
      final String surname,
      final String nationalInsuranceNumber,
      final LocalDate dateOfBirth,
      final List<EmailAddressResponse> emailAddress,
      final List<PhoneNumberResponse> phoneNumbers,
      final List<PostalAddressResponse> address,
      final boolean amendmentRestriction,
      final boolean hasSharePlanAccount,
      final boolean hasIsaSubscription,
      final String nationality,
      final List<uk.co.ybs.digital.customer.model.adgcore.FatcaProfile> fatcaProfiles,
      final Optional<FatcaParty> fatcaParty) {
    return GoldenCustomerRecord.builder()
        .partyId(CUSTOMER_NUMBER)
        .title(title)
        .forename(forename)
        .surname(surname)
        .nationalInsuranceNumber(nationalInsuranceNumber)
        .dateOfBirth(dateOfBirth)
        .emailAddresses(emailAddress)
        .phoneNumbers(phoneNumbers)
        .addresses(address)
        .amendmentRestriction(amendmentRestriction)
        .hasSharePlanAccount(hasSharePlanAccount)
        .hasIsaSubscription(hasIsaSubscription)
        .webCustomerNumber(CUSTOMER_NUMBER)
        .nationality(nationality)
        .marketingPreferences(
            MarketingPreferences.builder().post(true).phone(true).email(true).eagm(true).build())
        .preferences(buildPreferences())
        .fatcaProfiles(buildFatcaProfilesResponse(fatcaProfiles))
        .fatcaParty(buildFatcaPartyResponse(fatcaParty))
        .build();
  }

  private static GoldenCustomerExtendedRecord buildGoldenCustomerExtendedRecordWithFatcaResponse(
      final String title,
      final String forename,
      final String surname,
      final String nationalInsuranceNumber,
      final LocalDate dateOfBirth,
      final List<EmailAddressResponse> emailAddress,
      final List<PhoneNumberResponse> phoneNumbers,
      final List<PostalAddressResponse> address,
      final boolean amendmentRestriction,
      final boolean hasSharePlanAccount,
      final boolean hasIsaSubscription,
      final String nationality,
      final List<uk.co.ybs.digital.customer.model.adgcore.FatcaProfile> fatcaProfiles,
      final Optional<FatcaParty> fatcaParty) {
    return GoldenCustomerExtendedRecord.builder()
        .partyId(CUSTOMER_NUMBER)
        .title(title)
        .forename(forename)
        .surname(surname)
        .nationalInsuranceNumber(nationalInsuranceNumber)
        .dateOfBirth(dateOfBirth)
        .placeOfBirth(EncryptedData.builder().keyId("key").data("encrypted").build()) // NOPMD
        .emailAddresses(emailAddress)
        .phoneNumbers(phoneNumbers)
        .addresses(address)
        .amendmentRestriction(amendmentRestriction)
        .hasSharePlanAccount(hasSharePlanAccount)
        .hasIsaSubscription(hasIsaSubscription)
        .webCustomerNumber(CUSTOMER_NUMBER)
        .nationality(nationality)
        .marketingPreferences(
            MarketingPreferences.builder().post(true).phone(true).email(true).eagm(true).build())
        .preferences(buildPreferences())
        .fatcaProfiles(buildFatcaProfilesResponse(fatcaProfiles))
        .fatcaParty(buildFatcaPartyResponse(fatcaParty))
        .build();
  }

  private static List<FatcaProfile> buildFatcaProfilesResponse(
      final List<uk.co.ybs.digital.customer.model.adgcore.FatcaProfile> fatcaProfiles) {

    return Arrays.asList(
        FatcaProfile.builder()
            .countryCode(fatcaProfiles.get(0).getCountryCode())
            .countryRelationCode(fatcaProfiles.get(0).getCountryRelationCode())
            .nonUKTaxReferenceCode(fatcaProfiles.get(0).getNonUKTaxReferenceCode())
            .build(),
        (FatcaProfile.builder()
            .countryCode(fatcaProfiles.get(1).getCountryCode())
            .countryRelationCode(fatcaProfiles.get(1).getCountryRelationCode())
            .nonUKTaxReferenceCode(fatcaProfiles.get(1).getNonUKTaxReferenceCode())
            .build()));
  }

  private static uk.co.ybs.digital.customer.web.dto.FatcaParty buildFatcaPartyResponse(
      final Optional<FatcaParty> fatcaPartyOptional) {
    return uk.co.ybs.digital.customer.web.dto.FatcaParty.builder()
        .fatcaResponseUS(fatcaPartyOptional.get().getFatcaResponseUS())
        .fatcaResponseUK(fatcaPartyOptional.get().getFatcaResponseUK())
        .build();
  }

  private static EmailAddressResponse buildEmailAddressResponse(
      final String email, final boolean pendingUpdate) {
    return EmailAddressResponse.builder()
        .type("DEFAULT")
        .email(email)
        .pendingUpdate(pendingUpdate)
        .build();
  }

  private static PhoneNumberResponse buildPhoneNumberResponse(
      final String phoneNumber, final String type, final PhoneNumberSubType subType) {
    return PhoneNumberResponse.builder().number(phoneNumber).type(type).subType(subType).build();
  }

  private static PostalAddressResponse buildPostalAddressResponse(
      final List<String> addressLines, final String postcode, final boolean pendingUpdate) {
    return PostalAddressResponse.builder()
        .addressLines(addressLines)
        .postCode(postcode)
        .country("GB")
        .pendingUpdate(pendingUpdate)
        .type("CORR")
        .build();
  }

  private static Nationality buildNationality() {
    return Nationality.builder().code("BRIT").name(NATIONALITY).build();
  }

  private static Preferences buildPreferences() {
    return Preferences.builder()
        .marketing(
            Preferences.Marketing.builder()
                .eagm(Preferences.Marketing.Eagm.builder().status(true).deemedConsent(true).build())
                .email(Preferences.Marketing.Email.builder().status(true).build())
                .phone(Preferences.Marketing.Phone.builder().status(true).build())
                .post(Preferences.Marketing.Post.builder().status(true).build())
                .build())
        .build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> mapperArguments() {
    return Stream.of(
        Arguments.of(
            "Mr",
            "John",
            "Smith",
            NATIONAL_INSURANCE_NUMBER,
            DATE_OF_BIRTH,
            Collections.singletonList(buildEmailAddressResponse(EMAIL_ADDRESS, false)),
            Collections.singletonList(
                buildPhoneNumberResponse(
                    HOME_MOBILE_NUMBER, PHONE_TYPE_HOME, PhoneNumberSubType.LANDLINE)),
            Collections.singletonList(
                buildPostalAddressResponse(
                    Arrays.asList(ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3),
                    POSTCODE,
                    false)),
            false,
            false,
            false,
            buildNationality(),
            TestHelper.buildMarketingOptIns(),
            TestHelper.buildFatcaProfiles(),
            TestHelper.buildFatcaParty()),
        Arguments.of(
            null,
            "John",
            "Smith",
            NATIONAL_INSURANCE_NUMBER,
            DATE_OF_BIRTH,
            Collections.singletonList(buildEmailAddressResponse(EMAIL_ADDRESS, true)),
            Collections.singletonList(
                buildPhoneNumberResponse(
                    HOME_MOBILE_NUMBER, PHONE_TYPE_HOME, PhoneNumberSubType.LANDLINE)),
            Collections.singletonList(
                buildPostalAddressResponse(
                    Arrays.asList(ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3),
                    POSTCODE,
                    false)),
            false,
            false,
            false,
            buildNationality(),
            TestHelper.buildMarketingOptIns(),
            TestHelper.buildFatcaProfiles(),
            TestHelper.buildFatcaParty()),
        Arguments.of(
            "Mr",
            "John",
            "Smith",
            null,
            null,
            Collections.singletonList(buildEmailAddressResponse(EMAIL_ADDRESS, false)),
            Collections.singletonList(
                buildPhoneNumberResponse(
                    HOME_MOBILE_NUMBER, PHONE_TYPE_HOME, PhoneNumberSubType.LANDLINE)),
            Collections.singletonList(
                buildPostalAddressResponse(
                    Arrays.asList(ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3),
                    POSTCODE,
                    false)),
            false,
            false,
            false,
            buildNationality(),
            TestHelper.buildMarketingOptIns(),
            Collections.emptyList(),
            Optional.empty()),
        Arguments.of(
            "Mr",
            "John",
            "Smith",
            NATIONAL_INSURANCE_NUMBER,
            DATE_OF_BIRTH,
            Collections.singletonList(buildEmailAddressResponse(EMAIL_ADDRESS, false)),
            Collections.singletonList(
                buildPhoneNumberResponse(
                    HOME_MOBILE_NUMBER, PHONE_TYPE_HOME, PhoneNumberSubType.LANDLINE)),
            Collections.singletonList(
                buildPostalAddressResponse(
                    Arrays.asList(ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3),
                    POSTCODE,
                    false)),
            true,
            true,
            true,
            null,
            TestHelper.buildMarketingOptIns(),
            Collections.emptyList(),
            Optional.empty()));
  }
}
