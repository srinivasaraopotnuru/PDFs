package uk.co.ybs.digital.customer.service.product;

import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;

import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.experimental.UtilityClass;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationResponsePrivate;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationResponsePublic;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationStatus;
import uk.co.ybs.digital.customer.service.apply.dto.ApplicationsResponsePrivate;
import uk.co.ybs.digital.customer.service.apply.dto.CombinedIdentificationResult;
import uk.co.ybs.digital.customer.service.apply.dto.CurrentAddress;
import uk.co.ybs.digital.customer.service.apply.dto.CustomerDetailsResponsePrivate;
import uk.co.ybs.digital.customer.service.apply.dto.Decision;
import uk.co.ybs.digital.customer.service.apply.dto.MarketingPreferences;
import uk.co.ybs.digital.customer.service.apply.dto.PhoneNumber.HomePhoneNumber;
import uk.co.ybs.digital.customer.service.apply.dto.PhoneNumber.MobilePhoneNumber;
import uk.co.ybs.digital.customer.service.apply.dto.PreviousAddress;
import uk.co.ybs.digital.customer.service.apply.dto.TaxDetails;
import uk.co.ybs.digital.customer.service.apply.dto.TaxDetails.NonUkTaxDetail;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;
import uk.co.ybs.digital.customer.web.dto.products.Fact;
import uk.co.ybs.digital.customer.web.dto.products.InterestFrequency;
import uk.co.ybs.digital.customer.web.dto.products.InterestTier;
import uk.co.ybs.digital.customer.web.dto.products.Product;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;
import uk.co.ybs.digital.customer.web.dto.products.ProductType;
import uk.co.ybs.digital.customer.web.dto.products.Warning;
import uk.co.ybs.digital.customer.web.dto.products.WarningCode;

@SuppressWarnings("PMD.AvoidDuplicateLiterals")
@UtilityClass
public class ProductTestHelper {

  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final UUID SESSION_ID = UUID.randomUUID();

  private static final String EMAIL_ADDRESS = "email@email.com";
  private static final int BIRTH_YEAR = 1977;
  private static final int BIRTH_MONTH = 12;
  private static final int BIRTH_DAY = 1;
  private static final String URL_EASY_ACCESS =
      "http://localhost:%d/easy-access/index.html?display=allWaysToApply";
  private static final String URL_ISA =
      "http://localhost:%d/isas/index.html?display=allWaysToApply";
  private static final String URL_CHILDRENS_SAVINGS =
      "http://localhost:%d/childrens-savings/index.html?display=allWaysToApply";

  public static List<ProductCategory> buildOnSaleProducts(
      final Integer minAge, final Integer maxAge) {

    final Product easyISA =
        buildProductDto(
            "Six Access e-Saver ISA Issue 3",
            "YB851266W",
            minAge,
            maxAge,
            null,
            emptyList(),
            emptyList(),
            ProductType.ISA,
            InterestFrequency.ANNUAL,
            null);

    return singletonList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(URL_EASY_ACCESS, 8080),
            false,
            singletonList(easyISA),
            emptyList()));
  }

  public static List<ProductCategory> buildFilteredProducts(
      final Integer minAge, final Integer maxAge, final Warning warning) {

    final Product easyISA =
        buildProductDto(
            "Six Access e-Saver ISA Issue 3",
            "YB851266W",
            minAge,
            maxAge,
            null,
            emptyList(),
            emptyList(),
            ProductType.ISA,
            InterestFrequency.ANNUAL,
            singletonList(warning));

    return singletonList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(URL_EASY_ACCESS, 8080),
            false,
            emptyList(),
            singletonList(easyISA)));
  }

  public static List<ProductCategory> buildFilteredProducts(
      final Integer maximumNumberOfAccounts,
      final String productId,
      final List<String> facts,
      final Warning warning) {
    final Product easyISA =
        buildProductDto(
            "Six Access e-Saver ISA Issue 3",
            productId,
            null,
            null,
            maximumNumberOfAccounts,
            emptyList(),
            facts,
            ProductType.ISA,
            InterestFrequency.ANNUAL,
            singletonList(warning));

    return singletonList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(URL_EASY_ACCESS, 8080),
            false,
            emptyList(),
            singletonList(easyISA)));
  }

  public static List<ProductCategory> buildOnSaleProducts(
      final Integer maximumNumberOfAccounts, final String productId, final List<String> facts) {

    final Product easyISA =
        buildProductDto(
            "Six Access e-Saver ISA Issue 3",
            productId,
            null,
            null,
            maximumNumberOfAccounts,
            emptyList(),
            facts,
            ProductType.ISA,
            InterestFrequency.ANNUAL,
            null);

    return singletonList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(URL_EASY_ACCESS, 8080),
            false,
            Arrays.asList(easyISA),
            emptyList()));
  }

  public static List<ProductCategory> buildOnSaleProducts(
      final Integer maximumNumberOfAccounts, final String productId) {

    return buildOnSaleProducts(maximumNumberOfAccounts, productId, emptyList());
  }

  public static List<ProductCategory> buildFilteredProducts() {
    return buildOnSaleProducts().stream()
        .map(pg -> pg.toBuilder().unavailableProducts(emptyList()).build())
        .collect(Collectors.toList());
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  public static List<ProductCategory> buildOnSaleProducts() {

    return Arrays.asList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(URL_EASY_ACCESS, 8080),
            true,
            Arrays.asList(getEasyISA4(), getEasyIsa3()),
            null),
        buildProductCategory(
            ProductCategoryTypeHelper.FIXED_BOND,
            String.format(
                "http://localhost:%d/fixed-rate-bonds/index.html?display=allWaysToApply", 8080),
            true,
            Arrays.asList(getFixedRateBond21(), getFixedRateBond22(), getFixedRateBond23()),
            null),
        buildProductCategory(
            ProductCategoryTypeHelper.ISA_FIXED,
            String.format(URL_ISA, 8080),
            false,
            Arrays.asList(getFixedIsa21(), getFixedIsa22(), getFixedIsa23()),
            null),
        buildProductCategory(
            ProductCategoryTypeHelper.ISA_VARIABLE,
            String.format(URL_ISA, 8080),
            true,
            singletonList(getEasyIsa3()),
            null),
        buildProductCategory(
            ProductCategoryTypeHelper.CHILDRENS,
            String.format(URL_CHILDRENS_SAVINGS, 8080),
            true,
            emptyList(),
            null));
  }

  private static Product getFixedIsa23() {
    return getFixedIsa23(null);
  }

  private static Product getFixedIsa23(final List<Warning> warnings) {
    return buildProductDto(
        "Fixed Rate ISA until 31/12/2023",
        "YB291273W",
        16,
        null,
        null,
        singletonList(
            InterestTier.builder().description("Tax-free p.a./AER fixed").rate("0.60%").build()),
        Arrays.asList(
            "Save from £100 in this Cash ISA",
            "Annual interest",
            "Withdrawals Not Permitted",
            "Closure permitted with 180 days' loss of interest"),
        ProductType.ISA,
        InterestFrequency.ANNUAL,
        warnings);
  }

  private static Product getFixedIsa22() {
    return getFixedIsa22(null);
  }

  private static Product getFixedIsa22(final List<Warning> warnings) {
    return buildProductDto(
        "Fixed Rate ISA until 31/12/2022",
        "YB291272W",
        16,
        null,
        null,
        singletonList(
            InterestTier.builder().description("Tax-free p.a./AER fixed").rate("0.60%").build()),
        Arrays.asList(
            "Save from £100 in this Cash ISA",
            "Annual interest",
            "Withdrawals Not Permitted",
            "Closure permitted with 120 days' loss of interest"),
        ProductType.ISA,
        InterestFrequency.ANNUAL,
        warnings);
  }

  private static Product getFixedIsa21() {
    return getFixedIsa21(null);
  }

  private static Product getFixedIsa21(final List<Warning> warnings) {
    return buildProductDto(
        "Fixed Rate ISA until 31/12/2021",
        "YB291271W",
        16,
        null,
        null,
        singletonList(
            InterestTier.builder().description("Tax-free p.a./AER fixed").rate("0.55%").build()),
        Arrays.asList(
            "Save from £100 in this Cash ISA",
            "Annual interest",
            "Withdrawals Not Permitted",
            "Closure permitted with 60 days' loss of interest"),
        ProductType.ISA,
        InterestFrequency.ANNUAL,
        warnings);
  }

  private static Product getFixedRateBond21() {
    return getFixedRateBond21(null);
  }

  private static Product getFixedRateBond21(final List<Warning> warnings) {
    return buildProductDto(
        "Fixed Rate Bond until 31/12/2021",
        "YB271280W",
        16,
        null,
        1,
        singletonList(
            InterestTier.builder().description("Gross p.a./AER fixed").rate("0.50%").build()),
        Arrays.asList("Save from £1,000", "Annual interest", "Withdrawals Not Permitted"),
        ProductType.BOND,
        InterestFrequency.ANNUAL,
        warnings);
  }

  private static Product getFixedRateBond23() {
    return getFixedRateBond23(null);
  }

  private static Product getFixedRateBond23(final List<Warning> warnings) {
    return buildProductDto(
        "Fixed Rate Bond until 31/12/2023",
        "YB271270W",
        16,
        null,
        null,
        singletonList(
            InterestTier.builder().description("Gross p.a./AER fixed").rate("0.65%").build()),
        Arrays.asList("Save from £1,000", "Annual interest", "Withdrawals Not Permitted"),
        ProductType.BOND,
        InterestFrequency.ANNUAL,
        warnings);
  }

  private static Product getFixedRateBond22() {
    return getFixedRateBond22(null);
  }

  private static Product getFixedRateBond22(final List<Warning> warnings) {
    return buildProductDto(
        "Fixed Rate Bond until 31/12/2022",
        "YB271269W",
        16,
        null,
        null,
        singletonList(
            InterestTier.builder().description("Gross p.a./AER fixed").rate("0.65%").build()),
        Arrays.asList("Save from £1,000", "Annual interest", "Withdrawals Not Permitted"),
        ProductType.BOND,
        InterestFrequency.ANNUAL,
        warnings);
  }

  private static Product getEasyISA4() {
    return getEasyISA4(null);
  }

  private static Product getEasyISA4(final List<Warning> warnings) {
    return buildProductDto(
        "Six Access e-Saver Issue 4",
        "YB841278W",
        16,
        99,
        1,
        Arrays.asList(
            InterestTier.builder()
                .description("Gross p.a./AER variable on balances of")
                .rate("0.15%")
                .range("£1 - £999")
                .build(),
            InterestTier.builder()
                .description("Gross p.a./AER variable on balances of")
                .rate("0.25%")
                .range("£1,000 - £9,999")
                .build(),
            InterestTier.builder()
                .description("Gross p.a./AER variable on balances of")
                .rate("0.40%")
                .range("£10,000 - £49,999")
                .build(),
            InterestTier.builder()
                .description("Gross p.a./AER variable on balances of")
                .rate("0.45%")
                .range("£50,000+")
                .build()),
        Arrays.asList(
            "Save from £1",
            "Four tiered interest rates - rate depends on account balance",
            "Annual interest",
            "Allows withdrawals on 6 days per year plus closure"),
        ProductType.EASY_ACCESS,
        InterestFrequency.ANNUAL,
        warnings);
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  public static List<ProductCategory> buildOnSaleProductsWithRemovedProduct() {

    final Product easyISA = getEasyIsa3();

    return Arrays.asList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(URL_EASY_ACCESS, 8080),
            true,
            Arrays.asList(
                buildProductDto(
                    "Six Access e-Saver Issue 4",
                    "YB841278W",
                    16,
                    99,
                    1,
                    Arrays.asList(
                        InterestTier.builder()
                            .description("Gross p.a./AER variable on balances of")
                            .rate("0.15%")
                            .range("£1 - £999")
                            .build(),
                        InterestTier.builder()
                            .description("Gross p.a./AER variable on balances of")
                            .rate("0.25%")
                            .range("£1,000 - £9,999")
                            .build(),
                        InterestTier.builder()
                            .description("Gross p.a./AER variable on balances of")
                            .rate("0.40%")
                            .range("£10,000 - £49,999")
                            .build(),
                        InterestTier.builder()
                            .description("Gross p.a./AER variable on balances of")
                            .rate("0.45%")
                            .range("£50,000+")
                            .build()),
                    Arrays.asList(
                        "Save from £1",
                        "Four tiered interest rates - rate depends on account balance",
                        "Annual interest",
                        "Allows withdrawals on 6 days per year plus closure"),
                    ProductType.EASY_ACCESS,
                    InterestFrequency.ANNUAL,
                    null),
                easyISA),
            emptyList()),
        buildProductCategory(
            ProductCategoryTypeHelper.FIXED_BOND,
            String.format(
                "http://localhost:%d/fixed-rate-bonds/index.html?display=allWaysToApply", 8080),
            true,
            Arrays.asList(
                buildProductDto(
                    "Fixed Rate Bond until 31/12/2022",
                    "YB271269W",
                    16,
                    null,
                    null,
                    singletonList(
                        InterestTier.builder()
                            .description("Gross p.a./AER fixed")
                            .rate("0.65%")
                            .build()),
                    Arrays.asList(
                        "Save from £1,000", "Annual interest", "Withdrawals Not Permitted"),
                    ProductType.BOND,
                    InterestFrequency.ANNUAL,
                    null),
                buildProductDto(
                    "Fixed Rate Bond until 31/12/2023",
                    "YB271270W",
                    16,
                    null,
                    null,
                    singletonList(
                        InterestTier.builder()
                            .description("Gross p.a./AER fixed")
                            .rate("0.65%")
                            .build()),
                    Arrays.asList(
                        "Save from £1,000", "Annual interest", "Withdrawals Not Permitted"),
                    ProductType.BOND,
                    InterestFrequency.ANNUAL,
                    null)),
            singletonList(
                getFixedRateBond21(
                    singletonList(
                        Warning.builder()
                            .code(WarningCode.MAX_NO_OF_ACCOUNTS)
                            .message(
                                "Exceeded maximum number of Accounts. 0 open accounts, 1 applications in progress")
                            .build())))),
        buildProductCategory(
            ProductCategoryTypeHelper.ISA_FIXED,
            String.format(URL_ISA, 8080),
            false,
            Arrays.asList(
                buildProductDto(
                    "Fixed Rate ISA until 31/12/2021",
                    "YB291271W",
                    16,
                    null,
                    null,
                    singletonList(
                        InterestTier.builder()
                            .description("Tax-free p.a./AER fixed")
                            .rate("0.55%")
                            .build()),
                    Arrays.asList(
                        "Save from £100 in this Cash ISA",
                        "Annual interest",
                        "Withdrawals Not Permitted",
                        "Closure permitted with 60 days' loss of interest"),
                    ProductType.ISA,
                    InterestFrequency.ANNUAL,
                    null),
                buildProductDto(
                    "Fixed Rate ISA until 31/12/2022",
                    "YB291272W",
                    16,
                    null,
                    null,
                    singletonList(
                        InterestTier.builder()
                            .description("Tax-free p.a./AER fixed")
                            .rate("0.60%")
                            .build()),
                    Arrays.asList(
                        "Save from £100 in this Cash ISA",
                        "Annual interest",
                        "Withdrawals Not Permitted",
                        "Closure permitted with 120 days' loss of interest"),
                    ProductType.ISA,
                    InterestFrequency.ANNUAL,
                    null),
                buildProductDto(
                    "Fixed Rate ISA until 31/12/2023",
                    "YB291273W",
                    16,
                    null,
                    null,
                    singletonList(
                        InterestTier.builder()
                            .description("Tax-free p.a./AER fixed")
                            .rate("0.60%")
                            .build()),
                    Arrays.asList(
                        "Save from £100 in this Cash ISA",
                        "Annual interest",
                        "Withdrawals Not Permitted",
                        "Closure permitted with 180 days' loss of interest"),
                    ProductType.ISA,
                    InterestFrequency.ANNUAL,
                    null)),
            emptyList()),
        buildProductCategory(
            ProductCategoryTypeHelper.ISA_VARIABLE,
            String.format(URL_ISA, 8080),
            true,
            singletonList(easyISA),
            emptyList()),
        buildProductCategory(
            ProductCategoryTypeHelper.CHILDRENS,
            String.format(URL_CHILDRENS_SAVINGS, 8080),
            true,
            emptyList(),
            emptyList()));
  }

  private static Product getEasyIsa3() {
    return getEasyIsa3(null);
  }

  private static Product getEasyIsa3(final List<Warning> warnings) {
    final Product easyISA =
        buildProductDto(
            "Six Access e-Saver ISA Issue 3",
            "YB851266W",
            16,
            99,
            1,
            Arrays.asList(
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.20%")
                    .range("£1 - £999")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.45%")
                    .range("£1,000 - £9,999")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.50%")
                    .range("£10,000 - £49,999")
                    .build(),
                InterestTier.builder()
                    .description("Tax-free p.a./AER variable on balances of")
                    .rate("0.55%")
                    .range("£50,000+")
                    .build()),
            Arrays.asList(
                "Save from £1 in this Cash ISA",
                "Four tiered interest rates - rate depends on account balance",
                "Annual interest",
                "Allows withdrawals on 6 days per year"),
            ProductType.ISA,
            InterestFrequency.ANNUAL,
            warnings);
    return easyISA;
  }

  public static RequestMetadata buildRequestMetadata(final UUID requestId) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .sessionId(SESSION_ID)
        .host(InetSocketAddress.createUnresolved("localhost", 80))
        .partyId("1234567890")
        .brandCode("YBS")
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .webCustomerNumber("1234567890")
        .build();
  }

  public static List<ProductCategory> buildProductCategoriesUnavailableProductsOnly() {

    final List<Warning> warnings =
        singletonList(
            Warning.builder()
                .code(WarningCode.NON_UK_ADDRESS)
                .message("Customer has Non UK Address.")
                .build());

    return Arrays.asList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            String.format(URL_EASY_ACCESS, 8080),
            true,
            emptyList(),
            Arrays.asList(getEasyISA4(warnings), getEasyIsa3(warnings))),
        buildProductCategory(
            ProductCategoryTypeHelper.FIXED_BOND,
            String.format(
                "http://localhost:%d/fixed-rate-bonds/index.html?display=allWaysToApply", 8080),
            true,
            emptyList(),
            Arrays.asList(
                getFixedRateBond21(warnings),
                getFixedRateBond22(warnings),
                getFixedRateBond23(warnings))),
        buildProductCategory(
            ProductCategoryTypeHelper.ISA_FIXED,
            String.format(URL_ISA, 8080),
            false,
            emptyList(),
            Arrays.asList(
                getFixedIsa21(warnings), getFixedIsa22(warnings), getFixedIsa23(warnings))),
        buildProductCategory(
            ProductCategoryTypeHelper.ISA_VARIABLE,
            String.format(URL_ISA, 8080),
            true,
            emptyList(),
            singletonList(getEasyIsa3(warnings))),
        buildProductCategory(
            ProductCategoryTypeHelper.CHILDRENS,
            String.format(URL_CHILDRENS_SAVINGS, 8080),
            true,
            emptyList(),
            emptyList()));
  }

  private static ProductCategory buildProductCategory(
      final ProductCategoryTypeHelper type,
      final String url,
      final boolean offlineAvailable,
      final List<Product> products,
      final List<Product> unavailableProducts) {
    return ProductCategory.builder()
        .title(type.getTitle())
        .subTitle(type.getSubTitle())
        .description(type.getDescription())
        .url(url)
        .offlineOnlyProductsAvailable(offlineAvailable)
        .products(products)
        .unavailableProducts(unavailableProducts)
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private static Product buildProductDto(
      final String productName,
      final String productId,
      final Integer minimumAge,
      final Integer maximumAge,
      final Integer maximumNumberOfAccounts,
      final List<InterestTier> tiers,
      final List<String> facts,
      final ProductType productType,
      final InterestFrequency interestFrequency,
      final List<Warning> warnings) {
    return Product.builder()
        .name(productName)
        .type(productType)
        .url(String.format("http://localhost:%d/product.html?id=%s", 8080, productId))
        .interestTiers(tiers)
        .facts(buildFacts(facts))
        .minimumAge(minimumAge)
        .maximumAge(maximumAge)
        .maximumNumberOfAccounts(maximumNumberOfAccounts)
        .interestFrequency(interestFrequency)
        .warnings(warnings)
        .loyalty(false)
        .build();
  }

  private static List<Fact> buildFacts(final List<String> facts) {
    return facts.stream()
        .map(fact -> Fact.builder().text(fact).build())
        .collect(Collectors.toList());
  }

  public static ApplicationsResponsePrivate buildMockApplicationResponsePrivate(
      final int applicants, final String productId) {
    return ApplicationsResponsePrivate.builder()
        .applications(singletonList(getMockApplicationResponse(applicants, productId)))
        .totalApplications(1)
        .build();
  }

  public static ApplicationsResponsePrivate buildMockApplicationResponsePrivate(
      final int applicants, final String productId, final ApplicationStatus status) {
    return ApplicationsResponsePrivate.builder()
        .applications(singletonList(getMockApplicationResponse(applicants, productId, status)))
        .totalApplications(1)
        .build();
  }

  public static ApplicationsResponsePrivate getMockApplicationResponsePrivateEmpty() {
    return ApplicationsResponsePrivate.builder().applications(emptyList()).build();
  }

  public static ApplicationResponsePrivate getMockApplicationResponse(
      final int applicants, final String productId) {
    return getMockApplicationResponse(applicants, productId, ApplicationStatus.SUBMITTED);
  }

  public static ApplicationsResponsePrivate buildMockApplicationResponsePrivate(
      final List<ApplicationResponsePrivate> applications) {
    return ApplicationsResponsePrivate.builder().applications(applications).build();
  }

  public static ApplicationResponsePrivate getMockApplicationResponse(
      final int applicants, final String productId, final ApplicationStatus status) {
    LocalDate date = LocalDate.parse("2020-08-13");
    return ApplicationResponsePrivate.builder()
        .account(
            ApplicationResponsePublic.Account.builder()
                .number("123")
                .sortCode("609204")
                .lastFundDate(date.plusDays(42))
                .build())
        .applicants(mockResponseCustomerDetailsArray(applicants))
        .combinedIdentificationResult(getCombinedIdentificationResult())
        .product(ApplicationResponsePublic.Product.builder().productIdentifier(productId).build())
        .status(status)
        .uuid(UUID.randomUUID())
        .isaDeclaration(false)
        .build();
  }

  private static CombinedIdentificationResult getCombinedIdentificationResult() {
    return CombinedIdentificationResult.builder()
        .decision(Decision.AUTHENTICATED)
        .depositAllowed(true)
        .build();
  }

  private static List<CustomerDetailsResponsePrivate> mockResponseCustomerDetailsArray(
      final int applicants) {

    CustomerDetailsResponsePrivate details =
        CustomerDetailsResponsePrivate.builder()
            .dob(LocalDate.of(BIRTH_YEAR, BIRTH_MONTH, BIRTH_DAY))
            .primary(true)
            .email(EMAIL_ADDRESS)
            .firstNames("firstNames")
            .lastName("lastName")
            .nationalityCode("DANISH")
            .title("MR")
            .currentAddress(
                CurrentAddress.builder()
                    .line1("line1")
                    .line2("line2")
                    .line3("line3")
                    .town("town")
                    .county("county")
                    .pafData(
                        CurrentAddress.PafData.builder()
                            .addressKey(new BigDecimal("12345678"))
                            .deliveryPointSuffix("abc")
                            .build())
                    .postcode("BD5 8LJ")
                    .countryCode("UK")
                    .build())
            .previousAddress(
                PreviousAddress.builder()
                    .line1("line1")
                    .line2("line2")
                    .line3("line3")
                    .town("town")
                    .county("county")
                    .postcode("BD5 8LJ")
                    .pafData(
                        PreviousAddress.PafData.builder()
                            .addressKey(new BigDecimal("12345678"))
                            .deliveryPointSuffix("abc")
                            .build())
                    .country("UK")
                    .build())
            .marketingPreferences(
                MarketingPreferences.builder().email(true).phone(true).post(false).build())
            .homePhone(
                HomePhoneNumber.homePhoneBuilder().areaCode("01274").localNumber("357102").build())
            .mobilePhone(
                MobilePhoneNumber.mobilePhoneBuilder()
                    .areaCode("07440")
                    .localNumber("038010")
                    .build())
            .taxDetails(
                TaxDetails.builder()
                    .usCitizen(true)
                    .taxIdentificationNumber("999999999")
                    .ukTaxPayer(true)
                    .nonUkTaxDetails(
                        NonUkTaxDetail.builder()
                            .countryCode("CAN")
                            .taxReferenceNumber("AOEP99999")
                            .build())
                    .nonUkTaxDetails(
                        NonUkTaxDetail.builder()
                            .countryCode("SIN")
                            .taxReferenceNumber("AOEP9991")
                            .build())
                    .build())
            .build();

    List<CustomerDetailsResponsePrivate> customerDetailsList = new ArrayList<>();
    customerDetailsList.add(details);
    if (applicants == 2) {
      customerDetailsList.add(details);
      customerDetailsList.get(1).setPrimary(false);
    }

    return customerDetailsList;
  }

  public static List<ProductCategory> buildProductListResponse(
      final List<Product> availableProducts, final List<Product> unavailableProducts) {
    return singletonList(
        ProductCategory.builder()
            .title("Easy Access")
            .subTitle("Manage your money with greater freedom.")
            .description("Straightforward and flexible")
            .offlineOnlyProductsAvailable(false)
            .url("test.com")
            .products(availableProducts)
            .unavailableProducts(unavailableProducts)
            .build());
  }

  public static Product buildUnavailableProductWithWarning(
      final Integer maximumNumberOfAccounts, final String productId, final Warning warning) {
    return buildProductDto(
        "Six Access e-Saver ISA Issue 3",
        productId,
        null,
        null,
        maximumNumberOfAccounts,
        emptyList(),
        emptyList(),
        ProductType.ISA,
        InterestFrequency.ANNUAL,
        singletonList(warning));
  }

  public static Product buildOnSaleProductMock(
      final Integer maximumNumberOfAccounts,
      final String productId,
      final InterestFrequency interestFrequency) {
    return buildProductDto(
        "Six Access e-Saver ISA Issue 3",
        productId,
        null,
        null,
        maximumNumberOfAccounts,
        emptyList(),
        emptyList(),
        ProductType.ISA,
        interestFrequency,
        null);
  }

  public static List<ProductCategory> buildOnSaleProducts(final Product product) {

    return singletonList(
        buildProductCategory(
            ProductCategoryTypeHelper.EASY_ACCESS,
            "test.com",
            false,
            Arrays.asList(product),
            emptyList()));
  }
}
