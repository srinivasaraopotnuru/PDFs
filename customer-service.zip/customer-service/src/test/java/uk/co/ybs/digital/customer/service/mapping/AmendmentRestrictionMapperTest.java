package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;

public class AmendmentRestrictionMapperTest {

  private AmendmentRestrictionMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new AmendmentRestrictionMapper();
  }

  @ParameterizedTest
  @MethodSource("testCombinations")
  void shouldMapAmendmentRestrictionFlag(
      final AccountGroupedInfo accountInfo, final boolean expected) {
    boolean result = testSubject.isRestricted(accountInfo);

    assertThat(result, is(expected));
  }

  private static Stream<Arguments> testCombinations() {

    return Stream.of(
        Arguments.of(
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountNoRestriction()), buildBalances()))
                .other(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountNoRestriction()), buildBalances()))
                .build(),
            false),
        Arguments.of(
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountRestricted()), buildBalances()))
                .other(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountNoRestriction()), buildBalances()))
                .build(),
            true),
        Arguments.of(
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountNoRestriction()), buildBalances()))
                .other(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountRestricted()), buildBalances()))
                .build(),
            true),
        Arguments.of(
            AccountGroupedInfo.builder()
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountRestricted()), buildBalances()))
                .other(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountRestricted()), buildBalances()))
                .build(),
            true),
        Arguments.of(
            AccountGroupedInfo.builder()
                .owned(null)
                .other(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountRestricted()), buildBalances()))
                .build(),
            true),
        Arguments.of(
            AccountGroupedInfo.builder()
                .other(null)
                .owned(
                    buildAccountGroup(
                        Collections.singletonList(buildAccountRestricted()), buildBalances()))
                .build(),
            true),
        Arguments.of(AccountGroupedInfo.builder().owned(null).other(null).build(), false));
  }

  private static AccountGroupedInfo.AccountSummary buildAccountNoRestriction() {
    return buildAccount().toBuilder().amendmentRestriction(false).build();
  }

  private static AccountGroupedInfo.AccountSummary buildAccountRestricted() {
    return buildAccount().toBuilder().amendmentRestriction(true).build();
  }

  private static AccountGroupedInfo.AccountGroup buildAccountGroup(
      final List<AccountGroupedInfo.AccountSummary> accounts,
      final List<AccountGroupedInfo.Balance> balances) {
    return AccountGroupedInfo.AccountGroup.builder().accounts(accounts).balances(balances).build();
  }

  private static AccountGroupedInfo.AccountSummary buildAccount() {
    return AccountGroupedInfo.AccountSummary.builder()
        .accountNumber("1234567890")
        .accountName("Test")
        .accountSortCode("123456")
        .accountType("Savings")
        .externalAccountNumber("12345678")
        .deposits(AccountGroupedInfo.DepositsSummary.builder().permittedOverApi(true).build())
        .withdrawals(AccountGroupedInfo.WithdrawalsSummary.builder().permittedOverApi(true).build())
        .currency("GBP")
        .productIdentifier("test")
        .productDescription("Monthly Regular Saver: Issue 2")
        .isa(AccountGroupedInfo.Isa.builder().flexible(true).helpToBuy(false).build())
        .balances(buildBalances())
        .build();
  }

  private static List<AccountGroupedInfo.Balance> buildBalances() {
    return Collections.singletonList(
        AccountGroupedInfo.Balance.builder()
            .type("InterimAvailable")
            .amount(new BigDecimal("100.0"))
            .build());
  }
}
