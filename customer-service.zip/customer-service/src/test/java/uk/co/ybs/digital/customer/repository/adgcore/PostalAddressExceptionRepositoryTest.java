package uk.co.ybs.digital.customer.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddressException;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class PostalAddressExceptionRepositoryTest {
  @Autowired PostalAddressExceptionRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @Test
  void shouldFindById() {

    final PostalAddressException addressException = buildPostalAddressException();

    adgCoreTestEntityManager.persistAndFlush(addressException);
    adgCoreTestEntityManager.clear();

    final Optional<PostalAddressException> found = testSubject.findById("POBOX");

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(addressException));
  }

  @Test
  void shouldNotFindById() {

    final PostalAddressException addressException = buildPostalAddressException();

    adgCoreTestEntityManager.persistAndFlush(addressException);
    adgCoreTestEntityManager.clear();

    final Optional<PostalAddressException> found = testSubject.findById("PO BOX");

    assertThat(found.isPresent(), is(false));
  }

  @ParameterizedTest
  @MethodSource("addressLineArguments")
  void findExceptionForAddressLine(final String addressLine, final boolean expectedFind) {

    final PostalAddressException addressException = buildPostalAddressException();

    adgCoreTestEntityManager.persistAndFlush(addressException);
    adgCoreTestEntityManager.clear();

    final Optional<String> found = testSubject.findExceptionForAddressLine(addressLine);

    assertThat(found.isPresent(), is(expectedFind));
  }

  private static Stream<Arguments> addressLineArguments() {
    return Stream.of(
        Arguments.of("1 Leeds Road", false),
        Arguments.of("po bbox 123", false),
        Arguments.of("pop box 321", false),
        Arguments.of("pobox", false),
        Arguments.of("po box", true),
        Arguments.of("PO BOX LEEDS", true),
        Arguments.of("Another Po BoX Leeds", true),
        Arguments.of("MORE Po BoXS Leeds", true));
  }

  private PostalAddressException buildPostalAddressException() {

    return PostalAddressException.builder()
        .code("POBOX")
        .invalidText("PO BOX")
        .matchingType("F")
        .build();
  }
}
