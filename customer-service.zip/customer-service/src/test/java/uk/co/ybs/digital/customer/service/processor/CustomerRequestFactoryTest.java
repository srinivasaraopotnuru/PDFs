package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.digitalcustomer.AddressFunction;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.PostalAddressType;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class CustomerRequestFactoryTest {

  private static final long PARTY_ID = 123456L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final String EMAIL_ADDRESS = "customer@provider.com";

  @InjectMocks private CustomerRequestFactory testSubject;
  @Mock private UpdateEmailAddressProcessor updateEmailAddressProcessor;
  @Mock private DeletePhoneNumberProcessor deletePhoneNumberProcessor;
  @Mock private UpdatePhoneNumberProcessor updatePhoneNumberProcessor;
  @Mock private UpdatePostalAddressProcessor updatePostalAddressProcessor;

  @Test
  public void buildShouldReturnUpdateEmailAddressRequestWhenOperationIsUpdateEmail() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog =
        TestHelper.buildWorkLogWithUpdateEmailAddress(PARTY_ID, requestMetadata);

    final CustomerRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new UpdateEmailAddressRequest(
                new UpdateEmailAddressRequestArguments(
                    PARTY_ID, requestMetadata, PROCESS_TIME, EMAIL_ADDRESS),
                updateEmailAddressProcessor)));
  }

  @Test
  public void buildShouldReturnUpdatePhoneNumberRequestWhenOperationIsUpdatePhone() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = TestHelper.buildWorkLogWithUpdatePhoneNumber(PARTY_ID, requestMetadata);

    final CustomerRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new UpdatePhoneNumberRequest(
                new UpdatePhoneNumberRequestArguments(
                    PARTY_ID,
                    requestMetadata,
                    PROCESS_TIME,
                    PhoneNumberRequestType.HOME,
                    1234,
                    "456789"),
                updatePhoneNumberProcessor)));
  }

  @Test
  public void buildShouldReturnDeletePhoneNumberRequestWhenOperationIsDeletePhoneNumber() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog = TestHelper.buildWorkLogWithDeletePhoneNumber(PARTY_ID, requestMetadata);

    final CustomerRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new DeletePhoneNumberRequest(
                new DeletePhoneNumberRequestArguments(
                    PARTY_ID, requestMetadata, PROCESS_TIME, PhoneNumberRequestType.MOBILE),
                deletePhoneNumberProcessor)));
  }

  @Test
  public void buildShouldReturnUpdatePostalAddressRequestWhenOperationIsPostalAddress() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();
    final WorkLog workLog =
        TestHelper.buildWorkLogWithUpdatePostalAddress(PARTY_ID, requestMetadata);

    final CustomerRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertThat(
        request,
        is(
            new UpdatePostalAddressRequest(
                new UpdatePostalAddressRequestArguments(
                    PARTY_ID,
                    requestMetadata,
                    PROCESS_TIME,
                    PostalAddressType.UKPOST,
                    AddressFunction.CORR,
                    "1 FAKE LANE",
                    null,
                    null,
                    null,
                    null,
                    "UK",
                    "RM",
                    "4",
                    "1",
                    "PL",
                    null,
                    null),
                updatePostalAddressProcessor)));
  }
}
