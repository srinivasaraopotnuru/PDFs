package uk.co.ybs.digital.customer.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static uk.co.ybs.digital.customer.model.adgcore.PostalAddress.PAF_STATUS_PAFNUS;

import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestPropertySource;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.core.AddressType;
import uk.co.ybs.digital.customer.model.core.Country;
import uk.co.ybs.digital.customer.model.core.PostalAddress;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;
import uk.co.ybs.digital.customer.utils.TestHelper;

@YbsDataJpaTest()
@TestPropertySource(properties = {"spring.ldap.urls="})
@Transactional("customerProcessorTransactionManager")
public class PostalAddressRepositoryTest {

  public static final String POSTCODE_UNIT_CODE = "LE";
  public static final String POSTCODE_SECTOR_CODE = "8";
  public static final String POSTCODE_DISTRICT_CODE = "3";
  public static final String POSTCODE_AREA_CODE = "AL";
  @Autowired private PostalAddressRepository postalAddressRepository;
  @Autowired private TestEntityManager coreTestEntityManager;

  private static PostalAddress createPostalAddressWithPAF(
      final Integer pafAddressKey, final String pafDps, final String pafKeyPart3) {

    return PostalAddress.builder()
        .pafAddressKey(pafAddressKey)
        .pafKeyPart3(pafKeyPart3)
        .type(AddressType.UKPOST)
        .line1("22 Benny Drive")
        .pafDps(pafDps)
        .pafStatus(PAF_STATUS_PAFNUS)
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private static PostalAddress createPostalAddressWithAddressData(
      final String line1,
      final String line2,
      final String line3,
      final String line4,
      final String line5,
      final String cntryCode,
      final AddressType adtypCode,
      final String unitCode,
      final String sectorCode,
      final String districtCode,
      final String areaCode) {

    return PostalAddress.builder()
        .line1(line1)
        .line2(line2)
        .line3(line3)
        .line4(line4)
        .line5(line5)
        .type(adtypCode)
        .country(Country.builder().code(cntryCode).build())
        .pafStatus(PAF_STATUS_PAFNUS)
        .postCode(
            PostCode.builder()
                .areaCode(areaCode)
                .unitCode(unitCode)
                .districtCode(districtCode)
                .sectorCode(sectorCode)
                .build())
        .build();
  }

  private static Stream<Arguments> addressDetails() {

    return Stream.of(
        Arguments.of(
            "MAY COTTAGE",
            "5 THE GREEN COTTAGES",
            "THE GREEN	HAVERING-ATTE-BOWER",
            "ROMFORD",
            "*",
            TestHelper.buildCountry(),
            AddressType.UKPOST,
            "RM",
            "1",
            "PL",
            "4"),
        Arguments.of(
            "KINGSWAY ASSET FINANCE",
            "BARONS COURT",
            "MANCHESTER",
            "WILMSLOW",
            "CHESHIRE",
            TestHelper.buildCountry(),
            AddressType.UKPOST,
            "SK",
            "9",
            "BQ",
            "1"),
        Arguments.of(
            "18 GURDON ROAD",
            "RUNDISBURGH",
            "WOODBRIDGE",
            null,
            "*",
            TestHelper.buildCountry(),
            AddressType.UKPOST,
            "IP",
            "6",
            "XA",
            "13"));
  }

  private static Stream<Arguments> pafDetails() {

    return Stream.of(
        Arguments.of("282594", "1A", "80 HIGH ST"),
        Arguments.of("336063", "1L", "115 HIGH S"),
        Arguments.of("367524", "1E", "2 HADLEY R"));
  }

  @BeforeEach
  public void setUp() {

    coreTestEntityManager.persistAndFlush(createPostalAddressWithPAF(2356471, "1A", "PO BOX 430"));

    coreTestEntityManager.persistAndFlush(
        createPostalAddressWithAddressData(
            "80 HIGH STREET",
            "MARKYATE",
            "ST. ALBANS",
            "HERTFORDSHIRE",
            "",
            "UK",
            AddressType.UKPOST,
            POSTCODE_UNIT_CODE,
            POSTCODE_SECTOR_CODE,
            POSTCODE_DISTRICT_CODE,
            POSTCODE_AREA_CODE));
  }

  @Test
  public void testFindByPAFDataNotPresent() {
    Optional<PostalAddress> actual =
        postalAddressRepository.findPostalAddressByPafData(123123, "ru", "rtyry67"); // NOPMD

    assertThat(actual.isPresent(), is(false));
  }

  @Test
  public void testFindByPAFDataIsPresent() {
    Optional<PostalAddress> actual =
        postalAddressRepository.findPostalAddressByPafData(2356471, "1A", "PO BOX 430"); // NOPMD

    assertThat(actual.isPresent(), is(true));
  }

  @Test
  public void testFindByAddressDataIsPresent() {

    Optional<PostalAddress> actual =
        postalAddressRepository.findPostalAddressByAddressData(
            "80 HIGH STREET",
            "MARKYATE",
            "ST. ALBANS",
            "HERTFORDSHIRE",
            null,
            Country.builder().code("UK").build(),
            AddressType.UKPOST,
            POSTCODE_AREA_CODE,
            POSTCODE_DISTRICT_CODE,
            POSTCODE_SECTOR_CODE,
            POSTCODE_UNIT_CODE);

    assertThat(actual.isPresent(), is(true));
  }

  @Test
  public void testFindByAddressDataIsNotPresent() {

    Optional<PostalAddress> actual =
        postalAddressRepository.findPostalAddressByAddressData(
            "1 RUB STREET",
            "MARKYATE",
            "ST. ALBANS",
            "HERTFORDSHIRE",
            "*",
            Country.builder().code("UK").build(),
            AddressType.UKPOST,
            POSTCODE_AREA_CODE,
            POSTCODE_DISTRICT_CODE,
            POSTCODE_SECTOR_CODE,
            POSTCODE_UNIT_CODE);

    assertThat(actual.isPresent(), is(false));
  }

  @ParameterizedTest
  @MethodSource("addressDetails")
  @SuppressWarnings("PMD.ExcessiveParameterList")
  void shouldFindPostalAddressesFromMultipleAddressInputParams(
      final String line1,
      final String line2,
      final String line3,
      final String line4,
      final String line5,
      final Country country,
      final AddressType addressType,
      final String unitCode,
      final String sectorCode,
      final String districtCode,
      final String areaCode) {

    final PostalAddress storedAddress =
        coreTestEntityManager.persistAndFlush(
            createPostalAddressWithAddressData(
                line1,
                line2,
                line3,
                line4,
                line5,
                country.getCode(),
                addressType,
                unitCode,
                sectorCode,
                districtCode,
                areaCode));

    Optional<PostalAddress> actual =
        postalAddressRepository.findPostalAddressByAddressData(
            line1,
            line2,
            line3,
            line4,
            line5,
            country,
            addressType,
            areaCode,
            districtCode,
            sectorCode,
            unitCode);

    assertThat(actual.isPresent(), is(true));
    assertThat(actual.get(), samePropertyValuesAs(storedAddress));
  }

  @ParameterizedTest
  @MethodSource("pafDetails")
  public void shouldFindPostalAddressesFromMultipleAddressInputParams(
      final Integer pafAddressKey, final String pafDPS, final String pafKeyPart3) {

    final PostalAddress storedAddress =
        coreTestEntityManager.persistAndFlush(
            createPostalAddressWithPAF(pafAddressKey, pafDPS, pafKeyPart3));

    Optional<PostalAddress> actual =
        postalAddressRepository.findPostalAddressByPafData(pafAddressKey, pafDPS, pafKeyPart3);

    assertThat(actual.isPresent(), is(true));
    assertThat(actual.get(), samePropertyValuesAs(storedAddress));
  }
}
