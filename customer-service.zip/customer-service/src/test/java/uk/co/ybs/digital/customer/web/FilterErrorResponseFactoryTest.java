package uk.co.ybs.digital.customer.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.logging.filters.session.SessionIdSourceType;

class FilterErrorResponseFactoryTest {

  private FilterErrorResponseFactory testSubject;

  @BeforeEach
  void setUp() {
    testSubject = new FilterErrorResponseFactory();
  }

  @Test
  void shouldBuildAccessDeniedInvalidSignatureErrorResponse() {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        testSubject.createAccessDeniedInvalidSignatureErrorResponse(request(requestId));

    assertThat(
        errorResponse,
        is(
            ErrorResponse.builder()
                .id(requestId)
                .code("403 Forbidden")
                .message("Forbidden")
                .errors(
                    Collections.singletonList(
                        ErrorResponse.ErrorItem.builder()
                            .errorCode("AccessDenied.InvalidRequestSignature")
                            .message("Access Denied")
                            .build()))
                .build()));
  }

  @Test
  void shouldBuildAccessDeniedErrorResponse() {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        testSubject.createAccessDeniedErrorResponse(request(requestId));

    assertThat(
        errorResponse,
        is(
            ErrorResponse.builder()
                .id(requestId)
                .code("403 Forbidden")
                .message("Forbidden")
                .error(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("AccessDenied")
                        .message("Access Denied")
                        .build())
                .build()));
  }

  @Test
  void shouldBuildInvalidRequestIdErrorResponse() {
    final UUID requestId = UUID.randomUUID();
    final String header = "request-id-header";
    final ErrorResponse errorResponse =
        testSubject.createInvalidRequestIdErrorResponse(request(requestId), header);

    assertThat(
        errorResponse,
        is(
            ErrorResponse.builder()
                .id(requestId)
                .code("400 Bad Request")
                .message("Bad Request")
                .errors(
                    Collections.singletonList(
                        ErrorResponse.ErrorItem.builder()
                            .errorCode("Header.Invalid")
                            .message("Header invalid")
                            .path(header)
                            .build()))
                .build()));
  }

  @Test
  void shouldBuildInvalidSessionIdErrorResponse() {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        testSubject.createInvalidSessionIdErrorResponse(
            request(requestId), SessionIdSourceType.HEADER);

    assertThat(
        errorResponse,
        is(
            ErrorResponse.builder()
                .id(requestId)
                .code("400 Bad Request")
                .message("Bad Request")
                .errors(
                    Collections.singletonList(
                        ErrorResponse.ErrorItem.builder()
                            .errorCode("Header.Invalid")
                            .message("SessionId is not a valid UUID")
                            .path(SessionIdSourceType.HEADER.toString())
                            .build()))
                .build()));
  }

  @Test
  void shouldBuildMissingSessionIdErrorResponse() {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse errorResponse =
        testSubject.createMissingSessionIdErrorResponse(
            request(requestId), SessionIdSourceType.JWT);

    assertThat(
        errorResponse,
        is(
            ErrorResponse.builder()
                .id(requestId)
                .code("400 Bad Request")
                .message("Bad Request")
                .errors(
                    Collections.singletonList(
                        ErrorResponse.ErrorItem.builder()
                            .errorCode("Header.Invalid")
                            .message("JWT does not contain a sessionId (sid) claim")
                            .path(SessionIdSourceType.JWT.toString())
                            .build()))
                .build()));
  }

  private MockHttpServletRequest request(final UUID requestId) {
    final MockHttpServletRequest request = new MockHttpServletRequest();
    request.setAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME, requestId);
    return request;
  }
}
