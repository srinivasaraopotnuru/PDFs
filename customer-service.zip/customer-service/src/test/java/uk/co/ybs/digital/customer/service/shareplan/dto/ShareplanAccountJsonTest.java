package uk.co.ybs.digital.customer.service.shareplan.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;
import uk.co.ybs.digital.customer.utils.TestHelper;

@JsonTest
public class ShareplanAccountJsonTest {

  @Autowired private JacksonTester<ShareplanAccount> tester;

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void serializes(final ShareplanAccount account, final ClassPathResource json) throws IOException {
    assertThat(tester.write(account)).isEqualToJson(json, JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void deserialize(final ShareplanAccount account, final ClassPathResource json)
      throws IOException {
    assertThat(tester.read(json)).isEqualTo(account);
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildShareplanAccount(),
            new ClassPathResource("api/shareplanService/shareplanAccounts.json")));
  }
}
