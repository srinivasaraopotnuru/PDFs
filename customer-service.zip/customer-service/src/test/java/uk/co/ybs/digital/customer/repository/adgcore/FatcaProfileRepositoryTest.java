package uk.co.ybs.digital.customer.repository.adgcore;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.customer.model.adgcore.FatcaProfile;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class FatcaProfileRepositoryTest {

  @Autowired private FatcaProfileRepository testSubject;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  private static final Long FATCA_PARTIES_SYSID = 1234567L;
  private static final Long SYS_ID = 123L;
  private static final LocalDateTime NOW = LocalDateTime.now();
  private static final String COUNTRY_CODE_USA = "USA";
  private static final String COUNTRY_RELATION_CODE = "CITZEN";
  private static final String TAX_REFERENCE = "223697542";

  @Test
  void shouldFindById() {
    final FatcaProfile persisted =
        persistFatca(
            SYS_ID,
            FATCA_PARTIES_SYSID,
            COUNTRY_CODE_USA,
            TAX_REFERENCE,
            COUNTRY_RELATION_CODE,
            NOW.minusDays(1),
            NOW.plusDays(1));
    Optional<FatcaProfile> result = testSubject.findById(SYS_ID);

    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldFindByPartyIdWhenNotEnded() {
    persistFatca(
        SYS_ID,
        FATCA_PARTIES_SYSID,
        COUNTRY_CODE_USA,
        TAX_REFERENCE,
        COUNTRY_RELATION_CODE,
        NOW.minusDays(1),
        NOW.plusDays(1));
    persistFatca(
        SYS_ID + 1,
        FATCA_PARTIES_SYSID,
        "PHI",
        TAX_REFERENCE,
        "TAXRES",
        NOW.minusDays(1),
        NOW.plusDays(1));
    Collection<FatcaProfile> result =
        testSubject.findByPartyIdAndNotEnded(FATCA_PARTIES_SYSID, NOW);

    assertThat(result.size(), is(2));
    assertThat(
        result,
        contains(
            allOf(
                hasProperty("sysId", equalTo(SYS_ID)),
                hasProperty("fatcaPartySysId", equalTo(FATCA_PARTIES_SYSID)),
                hasProperty("countryCode", equalTo(COUNTRY_CODE_USA)),
                hasProperty("nonUKTaxReferenceCode", equalTo(TAX_REFERENCE)),
                hasProperty("countryRelationCode", equalTo(COUNTRY_RELATION_CODE)),
                hasProperty("startDate", equalTo(NOW.minusDays(1))),
                hasProperty("endedDate", equalTo(NOW.plusDays(1)))),
            allOf(
                hasProperty("sysId", equalTo(SYS_ID + 1)),
                hasProperty("fatcaPartySysId", equalTo(FATCA_PARTIES_SYSID)),
                hasProperty("countryCode", equalTo("PHI")),
                hasProperty("nonUKTaxReferenceCode", equalTo(TAX_REFERENCE)),
                hasProperty("countryRelationCode", equalTo("TAXRES")),
                hasProperty("startDate", equalTo(NOW.minusDays(1))),
                hasProperty("endedDate", equalTo(NOW.plusDays(1))))));
  }

  @Test
  void shouldNotFindByPartyIdWhenIdIncorrect() {
    persistFatca(
        SYS_ID,
        FATCA_PARTIES_SYSID,
        COUNTRY_CODE_USA,
        TAX_REFERENCE,
        COUNTRY_RELATION_CODE,
        NOW.minusDays(1),
        NOW.plusDays(1));
    Collection<FatcaProfile> result = testSubject.findByPartyIdAndNotEnded(231231L, NOW); // NOPMD

    assertThat(result.isEmpty(), is(true));
  }

  @Test
  void shouldNotFindByPartyIdWhenEndedDate() {
    persistFatca(
        SYS_ID,
        FATCA_PARTIES_SYSID,
        "AUS",
        TAX_REFERENCE,
        COUNTRY_RELATION_CODE,
        NOW.minusDays(2),
        NOW.minusDays(1));
    Collection<FatcaProfile> result =
        testSubject.findByPartyIdAndNotEnded(FATCA_PARTIES_SYSID, NOW);

    assertThat(result.isEmpty(), is(true));
  }

  @Test
  void shouldNotFindByPartyIdWhenNotStarted() {
    persistFatca(
        SYS_ID,
        FATCA_PARTIES_SYSID,
        "JAM",
        TAX_REFERENCE,
        COUNTRY_RELATION_CODE,
        NOW.plusDays(2),
        NOW.plusDays(3));
    Collection<FatcaProfile> result =
        testSubject.findByPartyIdAndNotEnded(FATCA_PARTIES_SYSID, NOW);

    assertThat(result.isEmpty(), is(true));
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private FatcaProfile persistFatca(
      final Long sysId,
      final Long partyId,
      final String countryCode,
      final String taxReference,
      final String countryRelationCode,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {

    final FatcaProfile fatcaProfile =
        FatcaProfile.builder()
            .sysId(sysId)
            .fatcaPartySysId(partyId)
            .countryCode(countryCode)
            .nonUKTaxReferenceCode(taxReference)
            .countryRelationCode(countryRelationCode)
            .startDate(startDate)
            .endedDate(endDate)
            .build();

    return adgCoreTestEntityManager.persistAndFlush(fatcaProfile);
  }
}
