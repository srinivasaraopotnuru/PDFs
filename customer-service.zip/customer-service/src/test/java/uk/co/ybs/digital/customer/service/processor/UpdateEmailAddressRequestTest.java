package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class UpdateEmailAddressRequestTest {

  private UpdateEmailAddressRequest testSubject;
  private UpdateEmailAddressRequestArguments arguments;
  private Party party;
  @Mock private UpdateEmailAddressProcessor updateEmailAddressProcessor;

  @BeforeEach
  void setUp() {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    arguments =
        new UpdateEmailAddressRequestArguments(
            123456,
            requestMetadata,
            LocalDateTime.parse("2020-05-26T14:45:01"),
            "customer@provider.com");

    party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(TestHelper.buildEmailAddress("john.smith@gmail.com")));
    testSubject = new UpdateEmailAddressRequest(arguments, updateEmailAddressProcessor);
  }

  @Test
  void resolveShouldReturnResolvedOUpdateEmailAddressRequest() {

    when(updateEmailAddressProcessor.resolve(arguments)).thenReturn(party);

    final ResolvedCustomerRequest resolved = testSubject.resolve();
    assertThat(
        resolved,
        is(new ResolvedUpdateEmailAddressRequest(arguments, updateEmailAddressProcessor, party)));
  }
}
