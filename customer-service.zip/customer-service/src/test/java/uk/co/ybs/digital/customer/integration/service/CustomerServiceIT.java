package uk.co.ybs.digital.customer.integration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildFullCustomerRecordADG;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildPhoneNumberRequest;
import static uk.co.ybs.digital.customer.utils.TestHelper.readClassPathResource;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.MACSigner;
import io.netty.handler.logging.LogLevel;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.RecordedRequest;
import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.logging.AdvancedByteBufFormat;
import uk.co.ybs.digital.customer.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.customer.integration.IntegrationTestConfig;
import uk.co.ybs.digital.customer.integration.IntegrationTestJwtFactory;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.FatcaParty;
import uk.co.ybs.digital.customer.model.adgcore.FatcaProfile;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn.MarketingOptInCode;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.Nationality;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.PartyType;
import uk.co.ybs.digital.customer.model.adgcore.Person;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddressException;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLog.Operation;
import uk.co.ybs.digital.customer.model.frontoffice.AddressChange;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;
import uk.co.ybs.digital.customer.service.audit.dto.AuditCustomerDetailsViewRequest;
import uk.co.ybs.digital.customer.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.customer.utils.SigningUtils;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.CustomerBasic;
import uk.co.ybs.digital.customer.web.dto.CustomerBasicResponse;
import uk.co.ybs.digital.customer.web.dto.CustomerDelayedRequest;
import uk.co.ybs.digital.customer.web.dto.CustomerDetailsResponse;
import uk.co.ybs.digital.customer.web.dto.EmailAddress;
import uk.co.ybs.digital.customer.web.dto.EmailAddressResponse;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.FailureRequest;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.MarketingPreferences;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberRequest;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberSubType;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;
import uk.co.ybs.digital.customer.web.dto.PostalAddressResponse;
import uk.co.ybs.digital.customer.web.dto.Preferences;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@AutoConfigureWebTestClient(timeout = "36000")
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
@SuppressWarnings("PMD.AvoidDuplicateLiterals")
class CustomerServiceIT extends CustomerServiceITBase {

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void shouldGetCustomerBasic(final String path) {
    final UUID requestId = UUID.randomUUID();

    CustomerBasicResponse expectedResponse = TestHelper.buildCustomerBasicResponse();

    setupParty(
        Arrays.asList(
            NonPostalAddress.builder()
                .type(AddressType.EMAIL)
                .address(CUSTOMER_EMAIL_ADDRESS)
                .sysId(100L)
                .build(),
            NonPostalAddress.builder()
                .address("216932")
                .adcCode("01234")
                .country(Country.builder().code("UK").build())
                .sysId(200L)
                .sourceType(NPASourceType.HOME)
                .type(AddressType.TEL)
                .build()),
        buildPreviousNonPostalAddresses());

    signingWebTestClient
        .get()
        .uri(getURI(path, REQUESTED_PARTY_ID))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(CustomerBasicResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DELAYED, PATH_CUSTOMER_DELAYED_PRIVATE})
  void shouldGetCustomerBasicDelayed(final String path) {
    final UUID requestId = UUID.randomUUID();

    CustomerBasicResponse expectedResponse = TestHelper.buildCustomerBasicDelayedResponse();

    setupParty(
        Arrays.asList(
            NonPostalAddress.builder()
                .type(AddressType.EMAIL)
                .address(CUSTOMER_EMAIL_ADDRESS)
                .sysId(100L)
                .build(),
            NonPostalAddress.builder()
                .address("216932")
                .adcCode("01234")
                .country(Country.builder().code("UK").build())
                .sysId(200L)
                .sourceType(NPASourceType.HOME)
                .type(AddressType.TEL)
                .build()),
        buildPreviousNonPostalAddresses());

    signingWebTestClient
        .get()
        .uri(getURI(path, REQUESTED_PARTY_ID))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(CustomerBasicResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnEmptyEmailIfNoneExistOnTheDatabase(final String path) {
    final UUID requestId = UUID.randomUUID();

    CustomerBasicResponse expectedResponse =
        CustomerBasicResponse.builder()
            .customer(
                CustomerBasic.builder()
                    .partyId(CANONICAL_PARTY_ID)
                    .title("Mr")
                    .forename("John")
                    .surname("Smith")
                    .deceasedDate(LOCAL_DATE)
                    .phoneNumbers(
                        Collections.singletonList(
                            PhoneNumberResponse.builder()
                                .type("HOME")
                                .number("01234216932")
                                .subType(PhoneNumberSubType.LANDLINE)
                                .build()))
                    .build())
            .build();

    setupParty(
        Collections.singletonList(
            NonPostalAddress.builder()
                .address("216932")
                .adcCode("01234")
                .country(Country.builder().code("UK").build())
                .sourceType(NPASourceType.HOME)
                .sysId(100L)
                .type(AddressType.TEL)
                .build()),
        buildPreviousNonPostalAddresses());

    signingWebTestClient
        .get()
        .uri(getURI(path, REQUESTED_PARTY_ID))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(CustomerBasicResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnEmptyPhoneNumberArrayIfNoneExist(final String path) {
    final UUID requestId = UUID.randomUUID();

    CustomerBasicResponse expectedResponse =
        CustomerBasicResponse.builder()
            .customer(
                CustomerBasic.builder()
                    .partyId(CANONICAL_PARTY_ID)
                    .title("Mr")
                    .forename("John")
                    .surname("Smith")
                    .deceasedDate(LOCAL_DATE)
                    .email(CUSTOMER_EMAIL_ADDRESS)
                    .phoneNumbers(Collections.emptyList())
                    .build())
            .build();

    setupParty(
        Collections.singletonList(
            NonPostalAddress.builder()
                .type(AddressType.EMAIL)
                .address(CUSTOMER_EMAIL_ADDRESS)
                .sysId(100L)
                .build()),
        buildPreviousNonPostalAddresses());

    signingWebTestClient
        .get()
        .uri(getURI(path, REQUESTED_PARTY_ID))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(CustomerBasicResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @MethodSource("shouldGetCustomerDetailsArgs")
  @SuppressWarnings("PMD.ExcessiveMethodLength")
  void shouldGetCustomerDetails(final String path, final String sessionId)
      throws InterruptedException, IOException {
    final UUID requestId = UUID.randomUUID();
    Map<String, Object> claimsMap =
        IntegrationTestJwtFactory.claimsMap(
            TestHelper.CANONICAL_PARTY_ID,
            TestHelper.CANONICAL_PARTY_ID,
            sessionId,
            ACCOUNT_READ_SCOPE,
            BRAND_CODE_YBS);
    final String jwt = IntegrationTestJwtFactory.createJwt(claimsMap, jwtSigningPrivateKey);
    final LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS);

    final String accountResponseBody =
        readClassPathResource("api/accountService/accountsGroupedNoRestriction.json");

    final String shareplanResponseBody =
        readClassPathResource("api/shareplanService/shareplanAccounts.json");

    String expectedResponse;

    if (PATH_CUSTOMER_DETAILS.equals(path)) {
      expectedResponse =
          objectMapper.writeValueAsString(
              TestHelper.buildCustomerDetailsResponse(
                  false, true, false, TestHelper.CANONICAL_PARTY_ID));
    } else {
      expectedResponse =
          objectMapper.writeValueAsString(
              TestHelper.buildCustomerDetailsExtendedResponse(
                  false, true, false, TestHelper.CANONICAL_PARTY_ID));
    }
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final PartyType partyType =
              adgCoreTestEntityManager.persistAndFlush(
                  PartyType.builder()
                      .code("PERSON")
                      .type("PERSON")
                      .startDate(LocalDateTime.now(clock).minusDays(1))
                      .build());

          final Party party =
              adgCoreTestEntityManager.persistFlushFind(
                  Party.builder()
                      .sysId(12462951L)
                      .partyType(partyType)
                      .placeOfBirth("PlaceOfBirth")
                      .build());

          final Nationality nationality =
              adgCoreTestEntityManager.persistFlushFind(
                  Nationality.builder().code("BRIT").name("BRITISH").build());

          adgCoreTestEntityManager.persistFlushFind(
              Person.builder()
                  .party(party)
                  .forenames("John")
                  .surname("Smith")
                  .title("Mr")
                  .dateOfBirth(LocalDate.of(1980, 12, 12))
                  .nationalInsuranceNumber("NI12345")
                  .nationality(nationality)
                  .build());

          final PostalAddress postalAddress =
              adgCoreTestEntityManager.persistFlushFind(
                  PostalAddress.builder()
                      .sysId(0L)
                      .line1("AddressLine1_1")
                      .line2("AddressLine2_1")
                      .line3("AddressLine3_1")
                      .line4("AddressLine4_1")
                      .country(Country.builder().code("UK").isoCode("GB").build())
                      .postCode(
                          PostCode.builder()
                              .areaCode("PO")
                              .districtCode("57")
                              .sectorCode("0")
                              .unitCode("DE")
                              .build())
                      .type(AddressType.UKPOST)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(0L)
                  .postalAddress(postalAddress)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.CORR)
                  .party(party)
                  .build());

          final NonPostalAddress emailAddress =
              adgCoreTestEntityManager.persistFlushFind(
                  NonPostalAddress.builder()
                      .sysId(1L)
                      .address(CUSTOMER_EMAIL_ADDRESS)
                      .type(AddressType.EMAIL)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(1L)
                  .nonPostalAddress(emailAddress)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .preferredContactMethod(true)
                  .party(party)
                  .build());

          final NonPostalAddress homePhone =
              adgCoreTestEntityManager.persistFlushFind(
                  NonPostalAddress.builder()
                      .sysId(2L)
                      .address(CUSTOMER_HOME_PHONE_NUMBER)
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.HOME)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(2L)
                  .nonPostalAddress(homePhone)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .party(party)
                  .build());

          final NonPostalAddress mobilePhone =
              adgCoreTestEntityManager.persistFlushFind(
                  NonPostalAddress.builder()
                      .sysId(3L)
                      .address(CUSTOMER_MOBILE_HONE_NUMBER)
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.MOBILE)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(3L)
                  .nonPostalAddress(mobilePhone)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .party(party)
                  .build());

          final NonPostalAddress workPhone =
              adgCoreTestEntityManager.persistFlushFind(
                  NonPostalAddress.builder()
                      .sysId(4L)
                      .address("421693")
                      .adcCode(ADC_CODE_STRING)
                      .country(Country.builder().code("UK").build())
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.WORK)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(4L)
                  .nonPostalAddress(workPhone)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .party(party)
                  .build());

          adgCoreTestEntityManager.persist(
              MarketingOptIn.builder()
                  .sysId(1L)
                  .partyId(party.getSysId())
                  .code(MarketingOptInCode.ADDR)
                  .status(true)
                  .startDate(now)
                  .createdBy(CREATED_BY_DEFAULT)
                  .build());

          adgCoreTestEntityManager.persist(
              MarketingOptIn.builder()
                  .sysId(2L)
                  .partyId(party.getSysId())
                  .code(MarketingOptInCode.TEL)
                  .status(true)
                  .startDate(now)
                  .createdBy(CREATED_BY_DEFAULT)
                  .build());

          adgCoreTestEntityManager.persist(
              MarketingOptIn.builder()
                  .sysId(3L)
                  .partyId(party.getSysId())
                  .code(MarketingOptInCode.EMAIL)
                  .status(true)
                  .startDate(now)
                  .createdBy(CREATED_BY_DEFAULT)
                  .build());

          adgCoreTestEntityManager.persist(
              MarketingOptIn.builder()
                  .sysId(4L)
                  .partyId(party.getSysId())
                  .code(MarketingOptInCode.AGMEML)
                  .status(true)
                  .startDate(now)
                  .createdBy(CREATED_BY_DEFAULT)
                  .build());

          adgCoreTestEntityManager.persist(
              FatcaParty.builder()
                  .sysId(111L)
                  .partyId(party.getSysId())
                  .fatcaResponseUK(false)
                  .fatcaResponseUS(true)
                  .startDate(now.minusDays(1))
                  .endedDate(now.plusDays(1))
                  .build());

          adgCoreTestEntityManager.persist(
              FatcaProfile.builder()
                  .countryCode("USA")
                  .nonUKTaxReferenceCode("223697542")
                  .countryRelationCode("CITZEN")
                  .fatcaPartySysId(111L)
                  .sysId(1L)
                  .startDate(now)
                  .build());

          adgCoreTestEntityManager.persist(
              FatcaProfile.builder()
                  .countryCode("USA")
                  .nonUKTaxReferenceCode("223697542")
                  .countryRelationCode("TAXRES")
                  .fatcaPartySysId(111L)
                  .sysId(2L)
                  .startDate(now)
                  .build());

          adgCoreTestEntityManager.flush();
        });

    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
    mockAccountService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(accountResponseBody));
    mockShareplanService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(shareplanResponseBody));

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody()
        .consumeWith(
            response -> {
              try {
                String responseBody =
                    new String(response.getResponseBody(), StandardCharsets.UTF_8);
                JSONAssert.assertEquals(responseBody, expectedResponse, JSONCompareMode.STRICT);
              } catch (JSONException e) {
                throw new RuntimeException(e);
              }
            });

    final RecordedRequest auditRequest = mockAuditService.takeRequest();
    assertThat(auditRequest.getMethod(), is("POST"));
    assertThat(auditRequest.getPath(), is("/audit/customer/view"));
    assertThat(auditRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(auditRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(auditRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(auditRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(auditRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final RecordedRequest accountRequest = mockAccountService.takeRequest();
    assertThat(accountRequest.getMethod(), is("GET"));
    assertThat(
        accountRequest.getPath(), is("/account/private/accounts/grouped?showClosedAccounts=false"));
    assertThat(accountRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(accountRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(accountRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(accountRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(accountRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final RecordedRequest shareplanRequest = mockShareplanService.takeRequest();
    assertThat(shareplanRequest.getMethod(), is("GET"));
    assertThat(shareplanRequest.getPath(), is("/shareplan-account/"));
    assertThat(shareplanRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(
        shareplanRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(shareplanRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(shareplanRequest.getHeader(HEADER_BRAND_CODE), is(BRAND_CODE_YBS));
    assertThat(shareplanRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(shareplanRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditCustomerDetailsViewRequest actual =
        objectMapper.readValue(
            auditRequest.getBody().readUtf8(), AuditCustomerDetailsViewRequest.class);
    assertThat(
        actual, is(AuditCustomerDetailsViewRequest.builder().ipAddress("127.0.0.1").build()));
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  @SuppressWarnings("PMD.ExcessiveMethodLength")
  void shouldGetUpdatedCustomerDetailsWhenPendingWorkLogExists(final String path)
      throws InterruptedException, IOException {
    final UUID requestId = UUID.randomUUID();
    Map<String, Object> claimsMap =
        IntegrationTestJwtFactory.claimsMap(
            TestHelper.CANONICAL_PARTY_ID,
            TestHelper.CANONICAL_PARTY_ID,
            SESSION_ID,
            ACCOUNT_READ_SCOPE,
            BRAND_CODE_YBS);
    final String jwt = IntegrationTestJwtFactory.createJwt(claimsMap, jwtSigningPrivateKey);
    final LocalDateTime now = LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS);

    final String accountResponseBody =
        readClassPathResource("api/accountService/accountsGroupedNoRestriction.json");

    final String shareplanResponseBody =
        readClassPathResource("api/shareplanService/shareplanAccounts.json");

    EmailAddressResponse emailAddressResponse =
        (EmailAddressResponse.builder()
            .email("updated@updated.com")
            .pendingUpdate(true)
            .type("Email")
            .build());

    List<PhoneNumberResponse> phoneNumberResponse =
        Arrays.asList(
            PhoneNumberResponse.builder()
                .number("01234421693")
                .type("WORK")
                .subType(PhoneNumberSubType.LANDLINE)
                .build(),
            PhoneNumberResponse.builder()
                .number("07515059347")
                .type("MOBILE")
                .subType(PhoneNumberSubType.MOBILE)
                .build(),
            PhoneNumberResponse.builder()
                .number("0668420713")
                .type("HOME")
                .pendingUpdate(true)
                .subType(PhoneNumberSubType.LANDLINE)
                .build());

    PostalAddressResponse postalAddressResponse =
        PostalAddressResponse.builder()
            .type("CORR")
            .postCode("LS1 6LR")
            .country("GB")
            .addressLines(
                Arrays.asList("FLAT 1", "TEST ESTATE", "10 TEST ROAD", "ROTHWELL", "LEEDS"))
            .pendingUpdate(true)
            .build();

    CustomerDetailsResponse expectedResponse =
        buildCustomerDetailsResponseWithPendingUpdates(
            false,
            true,
            false,
            TestHelper.CANONICAL_PARTY_ID,
            Collections.singletonList(emailAddressResponse),
            phoneNumberResponse,
            Collections.singletonList(postalAddressResponse));

    WorkLog workLogEmailAddress =
        workLogEmail(
            Operation.EMAIL_ADDRESS, "updated@updated.com", TestHelper.createRequestMetadata());

    WorkLog workLogPhoneNumber =
        workLogPhoneNumber(
            Operation.UPDATE_PHONE_NUMBER,
            PhoneNumberRequestType.HOME,
            668, // NOPMD
            "420713",
            TestHelper.createRequestMetadata());

    PostalAddressRequest newAddress =
        PostalAddressRequest.builder().address(buildPostalAddress()).paf(buildPafData()).build();
    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    WorkLog workLogPostalAddress = workLogPostalAddressWithPaf(newAddress, requestMetadata);

    transactionTemplate.executeWithoutResult(
        transactionStatus -> digitalCustomerTestEntityManager.persistAndFlush(workLogEmailAddress));

    transactionTemplate.executeWithoutResult(
        transactionStatus -> digitalCustomerTestEntityManager.persistAndFlush(workLogPhoneNumber));

    transactionTemplate.executeWithoutResult(
        transactionStatus ->
            digitalCustomerTestEntityManager.persistAndFlush(workLogPostalAddress));

    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final PartyType partyType =
              adgCoreTestEntityManager.persistAndFlush(
                  PartyType.builder()
                      .code("PERSON")
                      .type("PERSON")
                      .startDate(LocalDateTime.now(clock).minusDays(1))
                      .build());

          final Party party =
              adgCoreTestEntityManager.persistFlushFind(
                  Party.builder().sysId(12462951L).partyType(partyType).build());

          final Nationality nationality =
              adgCoreTestEntityManager.persistFlushFind(
                  Nationality.builder().code("BRIT").name("BRITISH").build());

          adgCoreTestEntityManager.persistFlushFind(
              Person.builder()
                  .party(party)
                  .forenames("John")
                  .surname("Smith")
                  .title("Mr")
                  .dateOfBirth(LocalDate.of(1980, 12, 12))
                  .nationalInsuranceNumber("NI12345")
                  .nationality(nationality)
                  .build());

          final PostalAddress postalAddress =
              adgCoreTestEntityManager.persistFlushFind(
                  PostalAddress.builder()
                      .sysId(0L)
                      .line1("AddressLine1_1")
                      .line2("AddressLine2_1")
                      .line3("AddressLine3_1")
                      .line4("AddressLine4_1")
                      .country(Country.builder().code("UK").isoCode("GB").build())
                      .postCode(
                          PostCode.builder()
                              .areaCode("PO")
                              .districtCode("57")
                              .sectorCode("0")
                              .unitCode("DE")
                              .build())
                      .type(AddressType.UKPOST)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(0L)
                  .postalAddress(postalAddress)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.CORR)
                  .party(party)
                  .build());

          final NonPostalAddress emailAddress =
              adgCoreTestEntityManager.persistFlushFind(
                  NonPostalAddress.builder()
                      .sysId(1L)
                      .address(CUSTOMER_EMAIL_ADDRESS)
                      .type(AddressType.EMAIL)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(1L)
                  .nonPostalAddress(emailAddress)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .preferredContactMethod(true)
                  .party(party)
                  .build());

          final NonPostalAddress homePhone =
              adgCoreTestEntityManager.persistFlushFind(
                  NonPostalAddress.builder()
                      .sysId(2L)
                      .address(CUSTOMER_HOME_PHONE_NUMBER)
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.HOME)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(2L)
                  .nonPostalAddress(homePhone)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .party(party)
                  .build());

          final NonPostalAddress mobilePhone =
              adgCoreTestEntityManager.persistFlushFind(
                  NonPostalAddress.builder()
                      .sysId(3L)
                      .address(CUSTOMER_MOBILE_HONE_NUMBER)
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.MOBILE)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(3L)
                  .nonPostalAddress(mobilePhone)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .party(party)
                  .build());

          final NonPostalAddress workPhone =
              adgCoreTestEntityManager.persistFlushFind(
                  NonPostalAddress.builder()
                      .sysId(4L)
                      .address("421693")
                      .adcCode(ADC_CODE_STRING)
                      .country(Country.builder().code("UK").build())
                      .type(AddressType.TEL)
                      .sourceType(NPASourceType.WORK)
                      .build());

          adgCoreTestEntityManager.persist(
              AddressUsage.builder()
                  .sysId(4L)
                  .nonPostalAddress(workPhone)
                  .startDate(now)
                  .createdDate(now)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .party(party)
                  .build());

          adgCoreTestEntityManager.persist(
              MarketingOptIn.builder()
                  .sysId(1L)
                  .partyId(party.getSysId())
                  .code(MarketingOptInCode.ADDR)
                  .status(true)
                  .startDate(now)
                  .createdBy(CREATED_BY_DEFAULT)
                  .build());

          adgCoreTestEntityManager.persist(
              MarketingOptIn.builder()
                  .sysId(2L)
                  .partyId(party.getSysId())
                  .code(MarketingOptInCode.TEL)
                  .status(true)
                  .startDate(now)
                  .createdBy(CREATED_BY_DEFAULT)
                  .build());

          adgCoreTestEntityManager.persist(
              MarketingOptIn.builder()
                  .sysId(3L)
                  .partyId(party.getSysId())
                  .code(MarketingOptInCode.EMAIL)
                  .status(true)
                  .startDate(now)
                  .createdBy(CREATED_BY_DEFAULT)
                  .build());

          adgCoreTestEntityManager.persist(
              MarketingOptIn.builder()
                  .sysId(4L)
                  .partyId(party.getSysId())
                  .code(MarketingOptInCode.AGMEML)
                  .status(true)
                  .startDate(now)
                  .createdBy(CREATED_BY_DEFAULT)
                  .build());

          adgCoreTestEntityManager.flush();
        });

    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
    mockAccountService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(accountResponseBody));
    mockShareplanService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(shareplanResponseBody));

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(CustomerDetailsResponse.class)
        .isEqualTo(expectedResponse);

    final RecordedRequest auditRequest = mockAuditService.takeRequest();
    assertThat(auditRequest.getMethod(), is("POST"));
    assertThat(auditRequest.getPath(), is("/audit/customer/view"));
    assertThat(auditRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(auditRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(auditRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(auditRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(auditRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final RecordedRequest accountRequest = mockAccountService.takeRequest();
    assertThat(accountRequest.getMethod(), is("GET"));
    assertThat(
        accountRequest.getPath(), is("/account/private/accounts/grouped?showClosedAccounts=false"));
    assertThat(accountRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(accountRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(accountRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(accountRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(accountRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final RecordedRequest shareplanRequest = mockShareplanService.takeRequest();
    assertThat(shareplanRequest.getMethod(), is("GET"));
    assertThat(shareplanRequest.getPath(), is("/shareplan-account/"));
    assertThat(shareplanRequest.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(
        shareplanRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(shareplanRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(shareplanRequest.getHeader(HEADER_BRAND_CODE), is(BRAND_CODE_YBS));
    assertThat(shareplanRequest.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(shareplanRequest.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditCustomerDetailsViewRequest actual =
        objectMapper.readValue(
            auditRequest.getBody().readUtf8(), AuditCustomerDetailsViewRequest.class);
    assertThat(
        actual, is(AuditCustomerDetailsViewRequest.builder().ipAddress("127.0.0.1").build()));
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private static CustomerDetailsResponse buildCustomerDetailsResponseWithPendingUpdates(
      final boolean amendmentRestriction,
      final boolean hasSharePlanAccount,
      final boolean hasIsaSubscription,
      final String webCustomerNumber,
      final List<EmailAddressResponse> emailAddresses,
      final List<PhoneNumberResponse> phoneNumbers,
      final List<PostalAddressResponse> postalAddress) {
    return CustomerDetailsResponse.builder()
        .goldenCustomerRecord(
            GoldenCustomerRecord.builder()
                .addresses(postalAddress)
                .partyId(CANONICAL_PARTY_ID)
                .dateOfBirth(LocalDate.of(1980, 12, 12))
                .nationalInsuranceNumber("NI12345")
                .emailAddresses(emailAddresses)
                .phoneNumbers(phoneNumbers)
                .forename("John")
                .surname("Smith")
                .title("Mr")
                .amendmentRestriction(amendmentRestriction)
                .hasSharePlanAccount(hasSharePlanAccount)
                .hasIsaSubscription(hasIsaSubscription)
                .webCustomerNumber(webCustomerNumber)
                .nationality("BRITISH")
                .marketingPreferences(
                    MarketingPreferences.builder()
                        .post(true)
                        .phone(true)
                        .email(true)
                        .eagm(true)
                        .build())
                .preferences(
                    Preferences.builder()
                        .marketing(
                            Preferences.Marketing.builder()
                                .eagm(
                                    Preferences.Marketing.Eagm.builder()
                                        .status(true)
                                        .deemedConsent(true)
                                        .build())
                                .email(Preferences.Marketing.Email.builder().status(true).build())
                                .phone(Preferences.Marketing.Phone.builder().status(true).build())
                                .post(Preferences.Marketing.Post.builder().status(true).build())
                                .build())
                        .build())
                .build())
        .build();
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnNotFoundWhenCustomerDoesntExist(final String path) {
    final UUID requestId = UUID.randomUUID();
    ErrorResponse expectedResponse = TestHelper.buildErrorResponseNotFound(requestId);

    signingWebTestClient
        .get()
        .uri(getURI(path, REQUESTED_PARTY_ID))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void getCustomerDetailsShouldReturnInternalServerErrorWhenPartyIDDoesNotExist(final String path) {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);
    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.buildErrorResponseInternalServerError(requestId));
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER, PATH_CUSTOMER_PRIVATE})
  void getCustomerBasicShouldReturnForbiddenWhenSignatureIsInvalid(final String path) {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message("Access Denied")
                    .build())
            .build();

    signingWebTestClient
        .get()
        .uri(getURI(path, REQUESTED_PARTY_ID))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header("x-ybs-request-signature-key-id", "FKbfNeQxsVQL5CwAJKP0q5fWOVe9ukn1K0lw")
        .header("x-ybs-request-signature", "invalid-signature")
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void getCustomerDetailsShouldReturnUnauthorisedWhenBearerTokenIsNotValidJwt(final String path) {
    final UUID requestId = UUID.randomUUID();

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer invalid.bearer.token")
        .header(HEADER_REQUEST_ID, requestId.toString())
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.unauthorizedErrorResponse(requestId));
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void getCustomerDetailsShouldReturnForbiddenWhenJwtLacksRequiredScope(final String path) {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithoutRequiredScope =
        IntegrationTestJwtFactory.createJwtWithScope(OTHER_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithoutRequiredScope)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.accessDeniedErrorResponse(requestId));
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_CUSTOMER_DETAILS, PATH_CUSTOMER_DETAILS_PRIVATE})
  void getCustomerDetailsShouldReturnBadRequestWhenSessionIdIsNotValid(final String path) {
    final UUID requestId = UUID.randomUUID();

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SESSION_ID, "invalid_session_id")
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSessionIdErrorResponse(requestId));
  }

  private void setupParty(
      final List<NonPostalAddress> addresses, final List<NonPostalAddress> previousAddresses) {

    final LocalDateTime today = LocalDate.now().atTime(0, 0, 0);
    final LocalDateTime lastWeek = today.minusDays(7);

    transactionTemplate.executeWithoutResult(
        status -> {
          final PartyType partyType =
              adgCoreTestEntityManager.persistAndFlush(
                  PartyType.builder()
                      .code("PERSON")
                      .type("PERSON")
                      .startDate(LocalDateTime.now(clock).minusDays(1))
                      .build());

          final Party party =
              adgCoreTestEntityManager.persist(
                  Party.builder()
                      .sysId(Long.parseLong(CANONICAL_PARTY_ID))
                      .partyType(partyType)
                      .build());

          adgCoreTestEntityManager.persist(
              Person.builder()
                  .party(party)
                  .title("Mr")
                  .forenames("John")
                  .surname("Smith")
                  .nationalInsuranceNumber("NI12345")
                  .dateOfDeath(LOCAL_DATE)
                  .build());

          for (NonPostalAddress address : addresses) {
            adgCoreTestEntityManager.persist(address);
            adgCoreTestEntityManager.persist(
                AddressUsage.builder()
                    .sysId(address.getSysId() + 1)
                    .party(party)
                    .nonPostalAddress(address)
                    .function(AddressUsage.AddressFunction.DIRCOM)
                    .startDate(today)
                    .createdDate(today)
                    .build());
          }

          for (NonPostalAddress address : previousAddresses) {
            adgCoreTestEntityManager.persist(address);
            adgCoreTestEntityManager.persist(
                AddressUsage.builder()
                    .sysId(address.getSysId() + 1)
                    .party(party)
                    .nonPostalAddress(address)
                    .function(AddressUsage.AddressFunction.DIRCOM)
                    .startDate(lastWeek)
                    .createdDate(lastWeek)
                    .endDate(today)
                    .build());
          }

          adgCoreTestEntityManager
              .getEntityManager()
              .createNativeQuery(
                  "INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES ("
                      + REQUESTED_PARTY_ID
                      + ", "
                      + CANONICAL_PARTY_ID
                      + ")")
              .executeUpdate();
        });
  }

  private RequestMetadata postEmailAddressUpdate(final EmailAddress emailAddressRequest)
      throws NoSuchAlgorithmException, NoSuchProviderException, SignatureException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();

    final String challenge = postEmailAddressRequestWithoutSca(requestId, emailAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_EMAIL_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(emailAddressRequest)
        .exchange()
        .expectStatus()
        .isAccepted();

    return requestMetadata;
  }

  @Test
  void shouldPostEmailAddressUpdate()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final EmailAddress emailAddressRequest = buildEmailAddressRequest();

    RequestMetadata requestMetadata = postEmailAddressUpdate(emailAddressRequest);

    final LocalDateTime now = LocalDateTime.now(clock);

    WorkLog workLog = workLogEmail(Operation.EMAIL_ADDRESS, EMAIL_ADDRESS, requestMetadata);

    assertWorkLogs(workLogMatching(workLog, now));

    ContactDetailsChange contact =
        ContactDetailsChange.builder()
            .partySysId(PARTY_SYSID)
            .emailAddress(EMAIL_ADDRESS)
            .homeTelephoneNumber(CUSTOMER_HOME_PHONE_NUMBER)
            .workTelephoneNumber(CUSTOMER_WORK_PHONE_NUMBER)
            .mobileTelephoneNumber(CUSTOMER_MOBILE_HONE_NUMBER)
            .build();
    assertContactDetailsChange(contactDetailsChangeMatcher(contact, now));
  }

  private RequestMetadata postPostalAddressUpdate(final PostalAddressRequest postalAddressRequest)
      throws NoSuchAlgorithmException, NoSuchProviderException, SignatureException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();

    final String challenge =
        postPostalAddressRequestWithoutSca(requestId, postalAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isAccepted();

    return requestMetadata;
  }

  @Test
  void shouldPostPostalAddressUpdate()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest();

    RequestMetadata requestMetadata = postPostalAddressUpdate(postalAddressRequest);

    final LocalDateTime now = LocalDateTime.now(clock);

    WorkLog worklog = workLogPostalAddressWithPaf(postalAddressRequest, requestMetadata);

    assertWorkLogs(workLogMatching(worklog, now));

    AddressChange address =
        AddressChange.builder()
            .partySysId(PARTY_SYSID)
            .addressLine1(ADDRESS_LINE_1)
            .addressLine2(ADDRESS_LINE_2)
            .addressLine3(ADDRESS_LINE_3)
            .addressLine4(ADDRESS_LINE_4)
            .country(COUNTRY.getCode())
            .postCode(POSTCODE)
            .pafKey(PAF_KEY.toString())
            .pafDeliveryPrefix(PAF_DPS)
            .build();

    assertAddressChange(addressChangeMatcher(address, now));
  }

  @Test
  void postPostalAddressUpdateShouldThrowConflictExceptionWhenNoChangesDetected()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequestWithNoChange(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();
    stubMockShareplanServiceResponse();

    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();

    final String challenge =
        postPostalAddressRequestWithoutSca(requestId, postalAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody()
        .jsonPath("$.errors[0].errorCode")
        .isEqualTo("Rejected.NoChangesDetected")
        .jsonPath("$.errors[0].message")
        .isEqualTo("No changes to the contact details have been detected");
  }

  @Test
  void postPostalAddressUpdateShouldThrowBadRequestExceptionWhenAddressLineFoundInExceptions()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequestWithoutPaf();

    final PostalAddressException addressException =
        PostalAddressException.builder()
            .code("POBOX")
            .invalidText("PO BOX")
            .matchingType("F")
            .endDate(null)
            .build();
    insert(addressException);

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();
    stubMockShareplanServiceResponse();

    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("400 Bad Request")
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("PO BOX, Care of & company addresses are not valid")
                    .path("address.addressLines[0]")
                    .build())
            .build();

    final String challenge =
        postPostalAddressRequestWithoutSca(requestId, postalAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.BAD_REQUEST)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void postPostalAddressUpdateShouldThrowBadRequestExceptionWhenPafAddressIsPoBox()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequestWithPaf();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();
    stubMockShareplanServiceResponse();

    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("400 Bad Request")
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("PO BOX, Care of & company addresses are not valid")
                    .path("address.addressLines[0]")
                    .build())
            .build();

    final String challenge =
        postPostalAddressRequestWithoutSca(requestId, postalAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.BAD_REQUEST)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void postPostalAddressUpdateShouldThrowForbiddenExceptionWhenAccountAmendmentRestrictions()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithWarnings();
    stubMockShareplanServiceResponse();

    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Contact details amendments are not allowed for this account")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Forbidden")
                    .build())
            .build();

    final String challenge =
        postPostalAddressRequestWithoutSca(requestId, postalAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void postPostalAddressUpdateShouldReturnNotFoundWhenCustomerDoesNotExist()
      throws NoSuchProviderException, NoSuchAlgorithmException, SignatureException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest();
    final ErrorResponse expectedResponse = TestHelper.buildErrorResponseNotFound(requestId);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();
    stubMockShareplanServiceResponse();

    final String challenge =
        postPostalAddressRequestWithoutSca(requestId, postalAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.NOT_FOUND)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void postPostalAddressUpdateShouldThrowScaRequiredExceptionWhenScaHeaderValuesUnpopulated() {
    final UUID requestId = UUID.randomUUID();

    final UUID sessionIdOther = UUID.fromString("e5c3c4bf-8b48-44e2-b120-eea2dd84bf46");

    final String jwtWithOtherSession =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, sessionIdOther);

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    final String challenge =
        postPostalAddressRequestWithoutSca(requestId, postalAddressRequest, jwt);

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithOtherSession)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void postPostalAddressUpdateShouldReturnForbiddenWhenJwtSessionIdsDoNotMatch()
      throws NoSuchProviderException, NoSuchAlgorithmException, SignatureException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();

    final UUID sessionIdOther = UUID.fromString("e5c3c4bf-8b48-44e2-b120-eea2dd84bf46");

    final String jwtWithOtherSession =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, sessionIdOther);

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest();

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    final String challenge =
        postPostalAddressRequestWithoutSca(requestId, postalAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithOtherSession)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void postPostalAddressUpdateShouldReturnForbiddenWhenJwtLacksRequiredScope() {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithoutRequiredScope =
        IntegrationTestJwtFactory.createJwtWithScope(OTHER_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final PostalAddressRequest postalAddressRequest = buildPostalAddressRequest();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_POSTAL_ADDRESS_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithoutRequiredScope)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(postalAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.accessDeniedErrorResponse(requestId));
  }

  @Test
  void shouldPostEmailAddressUpdateExistingContactDetailsChange()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final LocalDateTime now = LocalDateTime.now(clock);

    final EmailAddress emailAddressRequest = buildEmailAddressRequest();

    final ContactDetailsChange existingContactDetailsChange =
        ContactDetailsChange.builder()
            .partySysId(PARTY_SYSID)
            .amendDate(now.minusMinutes(10))
            .emailAddress("contact@gmail.com")
            .workTelephoneNumber("012342222222")
            .homeTelephoneNumber("012341111111")
            .mobileTelephoneNumber("071001111111")
            .build();
    insert(existingContactDetailsChange);

    RequestMetadata requestMetadata = postEmailAddressUpdate(emailAddressRequest);

    WorkLog workLog = workLogEmail(Operation.EMAIL_ADDRESS, EMAIL_ADDRESS, requestMetadata);

    assertWorkLogs(workLogMatching(workLog, now));

    ContactDetailsChange newContactDetailsChange =
        existingContactDetailsChange.toBuilder().amendDate(now).emailAddress(EMAIL_ADDRESS).build();

    assertContactDetailsChange(
        contactDetailsChangeMatcher(
            existingContactDetailsChange, existingContactDetailsChange.getAmendDate()),
        contactDetailsChangeMatcher(newContactDetailsChange, now));
  }

  @Test
  void postEmailUpdateShouldThrowForbiddenExceptionWhenAccountAmendmentRestrictions()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final EmailAddress emailAddressRequest = buildEmailAddressRequest();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithWarnings();
    stubMockShareplanServiceResponse();

    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Contact details amendments are not allowed for this account")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Forbidden")
                    .build())
            .build();

    final String challenge = postEmailAddressRequestWithoutSca(requestId, emailAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_EMAIL_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(emailAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void postEmailUpdateShouldReturnNotFoundWhenCustomerDoesNotExist()
      throws NoSuchProviderException, NoSuchAlgorithmException, SignatureException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final EmailAddress emailAddressRequest = buildEmailAddressRequest();
    final ErrorResponse expectedResponse = TestHelper.buildErrorResponseNotFound(requestId);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();
    stubMockShareplanServiceResponse();

    final String challenge = postEmailAddressRequestWithoutSca(requestId, emailAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_EMAIL_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(emailAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.NOT_FOUND)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void postEmailUpdateShouldThrowScaRequiredExceptionWhenScaHeaderValuesUnpopulated() {
    final UUID requestId = UUID.randomUUID();

    final UUID sessionIdOther = UUID.fromString("e5c3c4bf-8b48-44e2-b120-eea2dd84bf46");

    final String jwtWithOtherSession =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, sessionIdOther);

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final EmailAddress emailAddressRequest = buildEmailAddressRequest();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    final String challenge = postEmailAddressRequestWithoutSca(requestId, emailAddressRequest, jwt);

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_EMAIL_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithOtherSession)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(emailAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void postEmailUpdateShouldReturnForbiddenWhenJwtSessionIdsDoNotMatch()
      throws NoSuchProviderException, NoSuchAlgorithmException, SignatureException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();

    final UUID sessionIdOther = UUID.fromString("e5c3c4bf-8b48-44e2-b120-eea2dd84bf46");

    final String jwtWithOtherSession =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, sessionIdOther);

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final EmailAddress emailAddressRequest = buildEmailAddressRequest();

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    final String challenge = postEmailAddressRequestWithoutSca(requestId, emailAddressRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_EMAIL_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithOtherSession)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(emailAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void postEmailUpdateShouldReturnForbiddenWhenJwtLacksRequiredScope() {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithoutRequiredScope =
        IntegrationTestJwtFactory.createJwtWithScope(OTHER_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final EmailAddress emailAddressRequest = buildEmailAddressRequest();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_EMAIL_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithoutRequiredScope)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(emailAddressRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.accessDeniedErrorResponse(requestId));
  }

  private void postPhoneNumberUpdateBadRequest(final PhoneNumberRequest phoneNumberRequest)
      throws NoSuchAlgorithmException, SignatureException, NoSuchProviderException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();

    postPhoneNumberRequestWithoutScaBadRequest(requestId, phoneNumberRequest, jwt);
  }

  private RequestMetadata postPhoneNumberUpdate(final PhoneNumberRequest phoneNumberRequest)
      throws NoSuchAlgorithmException, SignatureException, NoSuchProviderException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();

    final String challenge = postPhoneNumberRequestWithoutSca(requestId, phoneNumberRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isAccepted();

    return requestMetadata;
  }

  @MethodSource("badPhoneNumberArgs")
  @ParameterizedTest(name = "shouldNotPostPhoneNumberUpdateSingleUpdate: Type={0}")
  void shouldNotPostPhoneNumberUpdateSingleUpdate(
      final PhoneNumberBasicType type,
      final Integer areaCode,
      final String number,
      final String formattedNumber)
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(PhoneNumberBasic.builder().type(type).number(formattedNumber).build())
            .build();
    // This call should fail with a bad request as the supplied phone number is invalid
    // and the validator should reject it, which appear as a bad data request.
    postPhoneNumberUpdateBadRequest(phoneNumberRequest);
  }

  @MethodSource("phoneNumberArgs")
  @ParameterizedTest(name = "shouldPostPhoneNumberUpdateSingleUpdate: Type={0}")
  void shouldPostPhoneNumberUpdateSingleUpdate(
      final PhoneNumberBasicType type,
      final Integer areaCode,
      final String number,
      final String formattedNumber)
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(PhoneNumberBasic.builder().type(type).number(formattedNumber).build())
            .build();

    final RequestMetadata requestMetadata = postPhoneNumberUpdate(phoneNumberRequest);

    final LocalDateTime now = LocalDateTime.now(clock);

    WorkLog workLogUpdatePhone =
        workLogPhoneNumber(
            Operation.UPDATE_PHONE_NUMBER,
            PhoneNumberRequestType.valueOf(type.toString()),
            areaCode,
            number,
            requestMetadata);

    assertWorkLogs(workLogMatching(workLogUpdatePhone, now));

    ContactDetailsChange contact =
        ContactDetailsChange.builder()
            .partySysId(PARTY_SYSID)
            .emailAddress(CUSTOMER_EMAIL_ADDRESS)
            .homeTelephoneNumber(
                type == PhoneNumberBasicType.HOME ? formattedNumber : CUSTOMER_HOME_PHONE_NUMBER)
            .workTelephoneNumber(
                type == PhoneNumberBasicType.WORK ? formattedNumber : CUSTOMER_WORK_PHONE_NUMBER)
            .mobileTelephoneNumber(
                type == PhoneNumberBasicType.MOBILE ? formattedNumber : CUSTOMER_MOBILE_HONE_NUMBER)
            .build();

    assertContactDetailsChange(contactDetailsChangeMatcher(contact, now));
  }

  @Test
  void shouldPostPhoneNumberUpdateHomeMobileWorkUpdate()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest = buildPhoneNumberRequest();

    final RequestMetadata requestMetadata = postPhoneNumberUpdate(phoneNumberRequest);

    final LocalDateTime now = LocalDateTime.now(clock);

    WorkLog workLogUpdateHomePhone =
        workLogPhoneNumber(
            Operation.UPDATE_PHONE_NUMBER,
            PhoneNumberRequestType.HOME,
            ADC_CODE,
            "123457",
            requestMetadata);

    WorkLog workLogUpdateMobilePhone =
        workLogPhoneNumber(
            Operation.UPDATE_PHONE_NUMBER,
            PhoneNumberRequestType.MOBILE,
            null,
            "07100123457",
            requestMetadata);

    WorkLog workLogDeleteWorkPhone =
        workLogPhoneNumber(
            Operation.UPDATE_PHONE_NUMBER,
            PhoneNumberRequestType.WORK,
            ADC_CODE,
            "333333",
            requestMetadata);

    assertWorkLogs(
        workLogMatching(workLogUpdateHomePhone, now),
        workLogMatching(workLogUpdateMobilePhone, now),
        workLogMatching(workLogDeleteWorkPhone, now));

    ContactDetailsChange contact =
        ContactDetailsChange.builder()
            .partySysId(PARTY_SYSID)
            .emailAddress(CUSTOMER_EMAIL_ADDRESS)
            .homeTelephoneNumber("01234123457")
            .workTelephoneNumber("01234333333")
            .mobileTelephoneNumber("07100123457")
            .build();

    assertContactDetailsChange(contactDetailsChangeMatcher(contact, now));
  }

  @EnumSource(PhoneNumberBasicType.class)
  @ParameterizedTest(name = "shouldPostPhoneNumberUpdateSingleDelete: Type={0}")
  void shouldPostPhoneNumberUpdateSingleDelete(final PhoneNumberBasicType type)
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(PhoneNumberBasic.builder().type(type).build())
            .build();

    final RequestMetadata requestMetadata = postPhoneNumberUpdate(phoneNumberRequest);

    final LocalDateTime now = LocalDateTime.now(clock);

    WorkLog workLogDeletePhone =
        workLogPhoneNumber(
            Operation.DELETE_PHONE_NUMBER,
            PhoneNumberRequestType.valueOf(type.toString()),
            null,
            null,
            requestMetadata);

    assertWorkLogs(workLogMatching(workLogDeletePhone, now));

    ContactDetailsChange contact =
        ContactDetailsChange.builder()
            .partySysId(PARTY_SYSID)
            .emailAddress(CUSTOMER_EMAIL_ADDRESS)
            .homeTelephoneNumber(
                type == PhoneNumberBasicType.HOME ? null : CUSTOMER_HOME_PHONE_NUMBER)
            .workTelephoneNumber(
                type == PhoneNumberBasicType.WORK ? null : CUSTOMER_WORK_PHONE_NUMBER)
            .mobileTelephoneNumber(
                type == PhoneNumberBasicType.MOBILE ? null : CUSTOMER_MOBILE_HONE_NUMBER)
            .build();

    assertContactDetailsChange(contactDetailsChangeMatcher(contact, now));
  }

  @Test
  void shouldPostPhoneNumberUpdateHomeWorkDelete()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.HOME).build())
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.WORK).build())
            .build();

    final RequestMetadata requestMetadata = postPhoneNumberUpdate(phoneNumberRequest);

    final LocalDateTime now = LocalDateTime.now(clock);

    WorkLog workLogUpdateHomePhone =
        workLogPhoneNumber(
            Operation.DELETE_PHONE_NUMBER,
            PhoneNumberRequestType.HOME,
            null,
            null,
            requestMetadata);

    WorkLog workLogDeleteWorkPhone =
        workLogPhoneNumber(
            Operation.DELETE_PHONE_NUMBER,
            PhoneNumberRequestType.WORK,
            null,
            null,
            requestMetadata);

    assertWorkLogs(
        workLogMatching(workLogUpdateHomePhone, now), workLogMatching(workLogDeleteWorkPhone, now));

    ContactDetailsChange contact =
        ContactDetailsChange.builder()
            .partySysId(PARTY_SYSID)
            .emailAddress(CUSTOMER_EMAIL_ADDRESS)
            .homeTelephoneNumber(null)
            .workTelephoneNumber(null)
            .mobileTelephoneNumber(CUSTOMER_MOBILE_HONE_NUMBER)
            .build();

    assertContactDetailsChange(contactDetailsChangeMatcher(contact, now));
  }

  @Test
  void shouldPostPhoneNumberUpdateExistingContactDetailsChangeHomeMobileWorkUpdate()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest = buildPhoneNumberRequest();

    final LocalDateTime now = LocalDateTime.now(clock);

    final ContactDetailsChange existingContactDetailsChange =
        ContactDetailsChange.builder()
            .partySysId(PARTY_SYSID)
            .amendDate(now.minusMinutes(10))
            .emailAddress("contact@gmail.com")
            .workTelephoneNumber("012342222222")
            .homeTelephoneNumber("012341111111")
            .mobileTelephoneNumber("07515333333")
            .build();
    insert(existingContactDetailsChange);

    final RequestMetadata requestMetadata = postPhoneNumberUpdate(phoneNumberRequest);

    WorkLog workLogUpdateHomePhone =
        workLogPhoneNumber(
            Operation.UPDATE_PHONE_NUMBER,
            PhoneNumberRequestType.HOME,
            ADC_CODE,
            "123457",
            requestMetadata);

    WorkLog workLogUpdateMobilePhone =
        workLogPhoneNumber(
            Operation.UPDATE_PHONE_NUMBER,
            PhoneNumberRequestType.MOBILE,
            null,
            "07100123457",
            requestMetadata);

    WorkLog workLogDeleteWorkPhone =
        workLogPhoneNumber(
            Operation.UPDATE_PHONE_NUMBER,
            PhoneNumberRequestType.WORK,
            ADC_CODE,
            "333333",
            requestMetadata);

    assertWorkLogs(
        workLogMatching(workLogUpdateHomePhone, now),
        workLogMatching(workLogUpdateMobilePhone, now),
        workLogMatching(workLogDeleteWorkPhone, now));

    ContactDetailsChange newContactDetailsChange =
        existingContactDetailsChange
            .toBuilder()
            .homeTelephoneNumber("01234123457")
            .workTelephoneNumber("01234333333")
            .mobileTelephoneNumber("07100123457")
            .build();

    assertContactDetailsChange(
        contactDetailsChangeMatcher(
            existingContactDetailsChange, existingContactDetailsChange.getAmendDate()),
        contactDetailsChangeMatcher(newContactDetailsChange, now));
  }

  @Test
  void shouldPostPhoneNumberUpdateExistingContactDetailsChangeHomeWorkDelete()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.HOME).build())
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.WORK).build())
            .build();

    final LocalDateTime now = LocalDateTime.now(clock);

    final ContactDetailsChange existingContactDetailsChange =
        ContactDetailsChange.builder()
            .partySysId(PARTY_SYSID)
            .amendDate(now.minusMinutes(10))
            .emailAddress("contact@gmail.com")
            .workTelephoneNumber("012342222222")
            .homeTelephoneNumber("012341111111")
            .mobileTelephoneNumber("07515333333")
            .build();
    insert(existingContactDetailsChange);

    final RequestMetadata requestMetadata = postPhoneNumberUpdate(phoneNumberRequest);

    WorkLog workLogUpdateHomePhone =
        workLogPhoneNumber(
            Operation.DELETE_PHONE_NUMBER,
            PhoneNumberRequestType.HOME,
            null,
            null,
            requestMetadata);

    WorkLog workLogDeleteWorkPhone =
        workLogPhoneNumber(
            Operation.DELETE_PHONE_NUMBER,
            PhoneNumberRequestType.WORK,
            null,
            null,
            requestMetadata);

    assertWorkLogs(
        workLogMatching(workLogUpdateHomePhone, now), workLogMatching(workLogDeleteWorkPhone, now));

    ContactDetailsChange newContactDetailsChange =
        existingContactDetailsChange
            .toBuilder()
            .homeTelephoneNumber(null)
            .workTelephoneNumber(null)
            .mobileTelephoneNumber("07515333333")
            .build();

    assertContactDetailsChange(
        contactDetailsChangeMatcher(
            existingContactDetailsChange, existingContactDetailsChange.getAmendDate()),
        contactDetailsChangeMatcher(newContactDetailsChange, now));
  }

  @Test
  void postPhoneNumberUpdateShouldThrowConflictWhenNoDetailsChanged()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(
                PhoneNumberBasic.builder()
                    .type(PhoneNumberBasicType.HOME)
                    .number(CUSTOMER_HOME_PHONE_NUMBER)
                    .build())
            .phoneNumber(
                PhoneNumberBasic.builder()
                    .type(PhoneNumberBasicType.MOBILE)
                    .number(CUSTOMER_MOBILE_HONE_NUMBER)
                    .build())
            .phoneNumber(
                PhoneNumberBasic.builder()
                    .type(PhoneNumberBasicType.WORK)
                    .number(CUSTOMER_WORK_PHONE_NUMBER)
                    .build())
            .build();

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final RequestMetadata requestMetadata = buildExpectedRequestMetadata(requestId, jwt);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();

    final String challenge = postPhoneNumberRequestWithoutSca(requestId, phoneNumberRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT)
        .expectBody()
        .jsonPath("$.errors[0].errorCode")
        .isEqualTo("Rejected.NoChangesDetected")
        .jsonPath("$.errors[0].message")
        .isEqualTo("No changes to the contact details have been detected");
  }

  @Test
  void postPhoneNumberUpdateShouldThrowsBadRequestWhenAllPhoneNumbersDeleted()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {

    final PhoneNumberRequest phoneNumberRequest =
        PhoneNumberRequest.builder()
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.HOME).build())
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.MOBILE).build())
            .phoneNumber(PhoneNumberBasic.builder().type(PhoneNumberBasicType.WORK).build())
            .build();

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();

    final String challenge = postPhoneNumberRequestWithoutSca(requestId, phoneNumberRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    HttpClient httpClient =
        HttpClient.create()
            .wiretap(
                this.getClass().getCanonicalName(), LogLevel.DEBUG, AdvancedByteBufFormat.TEXTUAL);
    ClientHttpConnector conn = new ReactorClientHttpConnector(httpClient);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectBody()
        .jsonPath("$.errors[0].errorCode")
        .isEqualTo("Rejected.MinPhoneNumber")
        .jsonPath("$.errors[0].message")
        .isEqualTo("Unable to remove phone number as customer must have at least one");
  }

  @Test
  void postPhoneNumberUpdateShouldThrowForbiddenExceptionWhenAccountAmendmentRestrictions()
      throws IOException, NoSuchAlgorithmException, NoSuchProviderException, InvalidKeyException,
          SignatureException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final PhoneNumberRequest phoneNumberRequest = buildPhoneNumberRequest();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithWarnings();

    stubMockShareplanServiceResponse();

    stubMockAuditServiceResponse(); // Customer Details View

    // once for each phone number passed
    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Contact details amendments are not allowed for this account")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Forbidden")
                    .build())
            .build();

    final String challenge = postPhoneNumberRequestWithoutSca(requestId, phoneNumberRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void postPhoneNumberUpdateShouldReturnNotFoundWhenCustomerDoesNotExist()
      throws NoSuchProviderException, NoSuchAlgorithmException, SignatureException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final PhoneNumberRequest phoneNumberRequest = buildPhoneNumberRequest();
    final ErrorResponse expectedResponse = TestHelper.buildErrorResponseNotFound(requestId);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    // once for each phone number passed
    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();
    stubMockAuditServiceResponse();

    stubMockShareplanServiceResponse();

    final String challenge = postPhoneNumberRequestWithoutSca(requestId, phoneNumberRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.NOT_FOUND)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void postPhoneNumberUpdateShouldThrowScaRequiredExceptionWhenScaHeaderValuesUnpopulated() {
    final UUID requestId = UUID.randomUUID();

    final UUID sessionIdOther = UUID.fromString("e5c3c4bf-8b48-44e2-b120-eea2dd84bf46");

    final String jwtWithOtherSession =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, sessionIdOther);

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final PhoneNumberRequest phoneNumberRequest = buildPhoneNumberRequest();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    final String challenge = postPhoneNumberRequestWithoutSca(requestId, phoneNumberRequest, jwt);

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("403 Forbidden")
            .id(requestId)
            .message("Strong customer authentication required")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("SCA.Required")
                    .message("Please sign the value in x-ybs-sca-challenge header with the request")
                    .build())
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithOtherSession)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @Test
  void postPhoneNumberUpdateShouldReturnForbiddenWhenJwtSessionIdsDoNotMatch()
      throws NoSuchProviderException, NoSuchAlgorithmException, SignatureException,
          InvalidKeyException, IOException {
    final UUID requestId = UUID.randomUUID();

    final UUID sessionIdOther = UUID.fromString("e5c3c4bf-8b48-44e2-b120-eea2dd84bf46");

    final String jwtWithOtherSession =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, sessionIdOther);

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final KeyPair scaKeyPair = SigningUtils.generateKeyPair();

    final PhoneNumberRequest phoneNumberRequest = buildPhoneNumberRequest();

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    final String challenge = postPhoneNumberRequestWithoutSca(requestId, phoneNumberRequest, jwt);

    final String challengeResponse = SigningUtils.signWithPrivateKey(scaKeyPair, challenge);
    final String encodedPublicKey = SigningUtils.encodePublicKey(scaKeyPair);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied")
                    .message("Access Denied")
                    .build())
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithOtherSession)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_SCA_CHALLENGE, challenge)
        .header(HEADER_SCA_CHALLENGE_RESPONSE, challengeResponse)
        .header(HEADER_SCA_KEY, encodedPublicKey)
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void postPhoneNumberUpdateShouldReturnForbiddenWhenJwtLacksRequiredScope() {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithoutRequiredScope =
        IntegrationTestJwtFactory.createJwtWithScope(OTHER_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final PhoneNumberRequest phoneNumberRequest = buildPhoneNumberRequest();

    signingWebTestClient
        .post()
        .uri(getURI(PATH_PHONE_NUMBER_UPDATE))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwtWithoutRequiredScope)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(phoneNumberRequest)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.accessDeniedErrorResponse(requestId));
  }

  @Test
  void checkReportFailureCallsAuditServiceAndReturnsNoContent() throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final EmailAddress emailAddressRequest = buildEmailAddressRequest();

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubMockAuditServiceResponse(); // Challenge
    stubMockAuditServiceResponse(); // Challenge success

    stubMockAccountServiceResponseWithoutRestrictions();

    stubMockAuditServiceResponse();
    stubMockShareplanServiceResponse();

    final String challenge = postEmailAddressRequestWithoutSca(requestId, emailAddressRequest, jwt);

    signingWebTestClient
        .post()
        .uri(getURI(REPORT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(FailureRequest.builder().challenge(challenge).build())
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  void reportFailureReturnsForbiddenIfChallengeIsNotAuthentic() throws Exception {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final JWSSigner signer = new MACSigner("bad-key-that-is-long-enough-to-be-valid");
    final JWSObject badChallenge =
        new JWSObject(new JWSHeader(JWSAlgorithm.HS256), new Payload("some-payload"));
    badChallenge.sign(signer);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder(HttpStatus.FORBIDDEN)
            .id(requestId)
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Field.Invalid")
                    .message("Authenticity of the challenge could not be validated")
                    .build())
            .build();

    signingWebTestClient
        .post()
        .uri(getURI(REPORT_FAILURE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(FailureRequest.builder().challenge(badChallenge.serialize()).build())
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void shouldGetCustomerDelayedThrowMultipleRecordsFoundException() {
    insert(
        buildNonWebAndWebCustomerRecord(
            1234567890L, getPartyType("PERSON"), CUSTOMER_MOBILE_HONE_NUMBER));
    insert(
        buildNonWebAndWebCustomerRecord(
            1234567891L, getPartyType(BRAND_CODE_YBS), CUSTOMER_MOBILE_HONE_NUMBER));

    signingWebTestClientForFailure(
        PATH_CUSTOMER_DELAYED_POST_PRIVATE,
        buildNonWebAndWebCustomerRequest(CUSTOMER_MOBILE_HONE_NUMBER),
        TestHelper.buildErrorResponseMultipleRecordsFound(SESSION_ID),
        HttpStatus.CONFLICT);
  }

  @Test
  void shouldGetCustomerDelayedThrowMultipleRecordsFoundExceptionPostSurnameTitleMismatch() {
    insert(
        buildNonWebAndWebCustomerRecord(
            1234567890L, getPartyType("PERSON"), CUSTOMER_MOBILE_HONE_NUMBER, NOCK));
    insert(
        buildNonWebAndWebCustomerRecord(
            1234567891L, getPartyType(BRAND_CODE_YBS), CUSTOMER_MOBILE_HONE_NUMBER, JACK));

    signingWebTestClientForFailure(
        PATH_CUSTOMER_DELAYED_POST_PRIVATE,
        buildNonWebAndWebCustomerRequest(CUSTOMER_MOBILE_HONE_NUMBER),
        TestHelper.buildErrorResponseMultipleRecordsFound(SESSION_ID),
        HttpStatus.CONFLICT);
  }

  @Test
  void customerDelayedShouldReturnSuccessPostMultipleMatchFound() {
    insert(
        buildNonWebAndWebCustomerRecord(
            1234567890L, getPartyType("PERSON"), CUSTOMER_MOBILE_HONE_NUMBER, NOCK));
    insert(
        buildNonWebAndWebCustomerRecord(
            1234567892L, getPartyType(BRAND_CODE_YBS), CUSTOMER_MOBILE_HONE_NUMBER, NOCK));
    signingWebTestClientForSuccess(
        PATH_CUSTOMER_DELAYED_POST_PRIVATE,
        buildNonWebAndWebCustomerRequest(CUSTOMER_MOBILE_HONE_NUMBER),
        buildNonWebCustomerDelayedResponse("1234567890"));
  }

  @Test
  void getCustomerDelayedShouldReturnMethodNotAllowedException() {
    insert(buildFullCustomerRecordADG());

    signingWebTestClientForFailure(
        PATH_CUSTOMER_DELAYED_POST,
        buildNonWebAndWebCustomerRequest(CUSTOMER_MOBILE_HONE_NUMBER),
        TestHelper.buildErrorResponseMethodNotSupported(SESSION_ID),
        HttpStatus.METHOD_NOT_ALLOWED);
  }

  @Test
  void shouldGetCustomerDelayedThrowRecordNotFoundException() {
    insert(buildFullCustomerRecordADG());

    signingWebTestClientForFailure(
        PATH_CUSTOMER_DELAYED_POST_PRIVATE,
        TestHelper.buildCustomForenameCustomerDelayedRequest("Rakesh"),
        TestHelper.buildErrorResponseNotFound(SESSION_ID),
        HttpStatus.NOT_FOUND);
  }

  @ParameterizedTest
  @MethodSource("getCustomerDelayedRecord")
  void shouldGetCustomerRecordForNonWebAndWebCustomer(
      final String path,
      final CustomerDelayedRequest customerDelayedRequest,
      final CustomerBasicResponse expectedDelayedResponse,
      final Party party) {
    insert(party);
    signingWebTestClientForSuccess(path, customerDelayedRequest, expectedDelayedResponse);
  }

  @ParameterizedTest
  @MethodSource("incorrectDelayedCustomerFields")
  void shouldFailToGetCustomerDelayedAsInCorrectField(
      final String path,
      final CustomerDelayedRequest customerDelayedRequest,
      final ErrorResponse expectedErrorResponse,
      final HttpStatus status) {
    insert(buildFullCustomerRecordADG());

    signingWebTestClientForFailure(path, customerDelayedRequest, expectedErrorResponse, status);
  }

  @ParameterizedTest
  @MethodSource("invalidDelayedCustomerFields")
  void shouldFailToGetCustomerDelayedAsInvalidFields(
      final String path,
      final CustomerDelayedRequest customerDelayedRequest,
      final ErrorResponse expectedErrorResponse,
      final HttpStatus status) {
    insert(buildFullCustomerRecordADG());

    signingWebTestClientForFailure(path, customerDelayedRequest, expectedErrorResponse, status);
  }

  @ParameterizedTest
  @MethodSource("validDelayedCustomerFields")
  void getCustomerDelayedShouldReturnCustomerRecordForValidFields(
      final String path, final CustomerDelayedRequest customerDelayedRequest) {
    insert(buildFullCustomerRecordADG());

    signingWebTestClientForSuccess(
        path, customerDelayedRequest, TestHelper.buildCustomerDelayedResponse());
  }
}
