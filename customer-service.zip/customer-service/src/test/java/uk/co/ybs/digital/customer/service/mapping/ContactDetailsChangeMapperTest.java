package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.nullValue;
import static org.hamcrest.core.Is.is;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.customer.model.frontoffice.ContactDetailsChange;
import uk.co.ybs.digital.customer.web.dto.EmailAddressResponse;
import uk.co.ybs.digital.customer.web.dto.GoldenCustomerRecord;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberSubType;
import uk.co.ybs.digital.customer.web.dto.PostalAddressResponse;

class ContactDetailsChangeMapperTest {

  private static final String HOME_TYPE = "HOME";
  private ContactDetailsChangeMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new ContactDetailsChangeMapper();
  }

  @Test
  void shouldMapGoldenCustomerOnlyToContactDetailsChange() {

    ContactDetailsChange contactDetailsChange =
        testSubject.map(buildGoldenCustomerRecord(HOME_TYPE));

    assertThat(contactDetailsChange.getPartySysId(), is("123456"));
    assertThat(contactDetailsChange.getAmendDate(), is(nullValue()));
    assertThat(contactDetailsChange.getEmailAddress(), is("john.smith@gmail.com"));
    assertThat(contactDetailsChange.getHomeTelephoneNumber(), is("01234420713"));
    assertThat(contactDetailsChange.getMobileTelephoneNumber(), is("07975732685"));
    assertThat(contactDetailsChange.getWorkTelephoneNumber(), is("8756987"));
    assertThat(contactDetailsChange.getPreferredContactTime(), is(nullValue()));
    assertThat(contactDetailsChange.getPreferredContactMethod(), is(nullValue()));
  }

  private GoldenCustomerRecord buildGoldenCustomerRecord(final String homeType) {
    return GoldenCustomerRecord.builder()
        .addresses(
            Collections.singletonList(
                PostalAddressResponse.builder()
                    .type("PersonalAddressType_1")
                    .postCode("PostCode_1")
                    .country("CountryCode_1")
                    .addressLines(
                        Arrays.asList("AddressLine1_1", "AddressLine2_1", "AddressLine3_1"))
                    .build()))
        .partyId("123456")
        .emailAddresses(
            Collections.singletonList(
                EmailAddressResponse.builder()
                    .email("john.smith@gmail.com")
                    .pendingUpdate(false)
                    .type("DEFAULT")
                    .build()))
        .phoneNumbers(
            Arrays.asList(
                PhoneNumberResponse.builder()
                    .number("01234420713")
                    .type(homeType)
                    .subType(PhoneNumberSubType.LANDLINE)
                    .build(),
                PhoneNumberResponse.builder()
                    .number("07975732685")
                    .type("MOBILE")
                    .subType(PhoneNumberSubType.MOBILE)
                    .build(),
                PhoneNumberResponse.builder()
                    .number("8756987")
                    .type("WORK")
                    .subType(PhoneNumberSubType.INTERNATIONAL)
                    .countryCode("1")
                    .build()))
        .nationalInsuranceNumber("NI12345")
        .dateOfBirth(LocalDate.of(1980, 12, 12))
        .forename("John")
        .surname("Smith")
        .title("Mr")
        .amendmentRestriction(false)
        .build();
  }
}
