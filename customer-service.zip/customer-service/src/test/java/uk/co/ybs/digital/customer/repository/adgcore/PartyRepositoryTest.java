package uk.co.ybs.digital.customer.repository.adgcore;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Stream;
import org.assertj.core.util.Strings;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.CustomerPartySysID;
import uk.co.ybs.digital.customer.model.adgcore.CustomerWebLogOnDetails;
import uk.co.ybs.digital.customer.model.adgcore.DeDupeEligibleParty;
import uk.co.ybs.digital.customer.model.adgcore.LinkedParty;
import uk.co.ybs.digital.customer.model.adgcore.LinkedPartyDetails;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.PartyType;
import uk.co.ybs.digital.customer.model.adgcore.Person;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddress;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.CustomerDelayedRequest;

@YbsDataJpaTest
class PartyRepositoryTest {

  private static long nextId;
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-09-01T10:15:30");
  private static final LocalDateTime TODAY = LocalDateTime.parse("2020-09-01T00:00:00");
  private static final LocalDateTime YESTERDAY = LocalDateTime.parse("2020-08-31T23:59:59");
  private static final LocalDateTime LAST_WEEK = LocalDateTime.parse("2020-08-24T23:59:59");
  private static final LocalDateTime CORE_ENDED_TODAY = LocalDateTime.parse("2020-08-31T00:00:00");

  public static final String CUSTOMER_EMAIL_ADDRESS = "john.smith@gmail.com";
  public static final String CUSTOMER_MOBILE_PHONE_NUMBER = "07515059347";
  public static final String CUSTOMER_WORK_PHONE_NUMBER = "01234421693";
  public static final String CUSTOMER_HOME_PHONE_NUMBER = "01234420713";
  public static final String PERSON = "PERSON";
  private static final Locale LOCALE = Locale.ROOT;

  @Autowired PartyRepository partyRepository;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @Autowired TransactionTemplate transactionTemplate;

  @ParameterizedTest
  @MethodSource("linkedParties")
  void findCanonicalPartyIdReturnsCanonicalIdAndNumberOfLinks(
      final Long originalPartyId, final Optional<LinkedParty> expected) {
    transactionTemplate.executeWithoutResult(
        status -> {
          adgCoreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (0, NULL)")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (1, 0)")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (2, 1)")
              .executeUpdate();
        });

    final Optional<LinkedParty> actual = partyRepository.findCanonicalPartyId(originalPartyId);
    assertThat(actual, equalTo(expected));
  }

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void findGoldenPartyRecordReturnsAllAddresses() {
    final Party party = buildFullCustomerRecord();
    insert(party);

    final Optional<Party> maybeActual =
        partyRepository.findGoldenPartyInformation(party.getSysId(), NOW);
    assertThat(maybeActual.isPresent(), equalTo(true));

    final Party actual = maybeActual.get();

    assertThat(
        actual,
        allOf(
            hasProperty("sysId", equalTo(party.getSysId())),
            hasProperty("placeOfBirth", equalTo("PlaceOfBirth")),
            hasProperty(
                "person",
                allOf(
                    hasProperty("partyId", equalTo(party.getSysId())),
                    hasProperty("dateOfDeath", equalTo(NOW.toLocalDate())),
                    hasProperty("title", equalTo("Mr")),
                    hasProperty("forenames", equalTo("John")),
                    hasProperty("surname", equalTo("Smith")))),
            hasProperty(
                "addresses",
                contains(
                    matchesEmailAddress(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(true)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address(CUSTOMER_EMAIL_ADDRESS)
                                    .type(AddressType.EMAIL)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("421693")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.WORK)
                                    .adcCode("1234")
                                    .country(Country.builder().code("UK").build())
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address(CUSTOMER_MOBILE_PHONE_NUMBER)
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.MOBILE)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address(CUSTOMER_HOME_PHONE_NUMBER)
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.HOME)
                                    .build())
                            .build()),
                    matchesPostalAddress(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.CORR)
                            .postalAddress(
                                PostalAddress.builder()
                                    .line1("AddressLine1_1")
                                    .line2("AddressLine2_1")
                                    .line4("AddressLine3_1")
                                    .country(Country.builder().code("UK").isoCode("GB").build())
                                    .postCode(
                                        PostCode.builder()
                                            .areaCode("PO")
                                            .districtCode("57")
                                            .sectorCode("0")
                                            .unitCode("DE")
                                            .build())
                                    .type(AddressType.UKPOST)
                                    .build())
                            .build())))));
  }

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void findGoldenPartyRecordReturnsAllYesterdaysAddresses() {
    final Party party = buildFullCustomerRecord();
    insert(party);

    final Optional<Party> maybeActual =
        partyRepository.findGoldenPartyInformation(party.getSysId(), YESTERDAY);
    assertThat(maybeActual.isPresent(), equalTo(true));

    final Party actual = maybeActual.get();

    assertThat(
        actual,
        allOf(
            hasProperty("sysId", equalTo(party.getSysId())),
            hasProperty("placeOfBirth", equalTo("PlaceOfBirth")),
            hasProperty(
                "person",
                allOf(
                    hasProperty("partyId", equalTo(party.getSysId())),
                    hasProperty("dateOfDeath", equalTo(NOW.toLocalDate())),
                    hasProperty("title", equalTo("Mr")),
                    hasProperty("forenames", equalTo("John")),
                    hasProperty("surname", equalTo("Smith")))),
            hasProperty(
                "addresses",
                contains(
                    matchesEmailAddress(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(true)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("prev.email@gmail.com")
                                    .type(AddressType.EMAIL)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("200000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.WORK)
                                    .adcCode("1234")
                                    .country(Country.builder().code("UK").build())
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("07515100000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.MOBILE)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("01234100000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.HOME)
                                    .build())
                            .build()),
                    matchesPostalAddress(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.CORR)
                            .postalAddress(
                                PostalAddress.builder()
                                    .line1("PrevAddressLine1_1")
                                    .line2("PrevAddressLine2_1")
                                    .line4("PrevAddressLine3_1")
                                    .country(Country.builder().code("UK").isoCode("GB").build())
                                    .postCode(
                                        PostCode.builder()
                                            .areaCode("LS")
                                            .districtCode("1")
                                            .sectorCode("0")
                                            .unitCode("AA")
                                            .build())
                                    .type(AddressType.UKPOST)
                                    .build())
                            .build())))));
  }

  @Test
  void findBasicPartyInformationReturnsEmailAndTelOnly() {
    final Party party = buildFullCustomerRecord();
    insert(party);

    final Optional<Party> maybeActual =
        partyRepository.findBasicPartyInformation(party.getSysId(), NOW);
    assertThat(maybeActual.isPresent(), equalTo(true));

    final Party actual = maybeActual.get();

    assertThat(
        actual,
        allOf(
            hasProperty("sysId", equalTo(party.getSysId())),
            hasProperty("placeOfBirth", equalTo("PlaceOfBirth")),
            hasProperty(
                "person",
                allOf(
                    hasProperty("partyId", equalTo(party.getSysId())),
                    hasProperty("dateOfDeath", equalTo(NOW.toLocalDate())),
                    hasProperty("title", equalTo("Mr")),
                    hasProperty("forenames", equalTo("John")),
                    hasProperty("surname", equalTo("Smith")))),
            hasProperty(
                "addresses",
                contains(
                    matchesEmailAddress(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(true)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address(CUSTOMER_EMAIL_ADDRESS)
                                    .type(AddressType.EMAIL)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("421693")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.WORK)
                                    .adcCode("1234")
                                    .country(Country.builder().code("UK").build())
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address(CUSTOMER_MOBILE_PHONE_NUMBER)
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.MOBILE)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address(CUSTOMER_HOME_PHONE_NUMBER)
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.HOME)
                                    .build())
                            .build())))));
  }

  @Test
  void findBasicPartyInformationReturnsYesterdaysEmailAndTelOnly() {
    final Party party = buildFullCustomerRecord();
    insert(party);

    final Optional<Party> maybeActual =
        partyRepository.findBasicPartyInformation(party.getSysId(), YESTERDAY);
    assertThat(maybeActual.isPresent(), equalTo(true));

    final Party actual = maybeActual.get();

    assertThat(
        actual,
        allOf(
            hasProperty("sysId", equalTo(party.getSysId())),
            hasProperty("placeOfBirth", equalTo("PlaceOfBirth")),
            hasProperty(
                "person",
                allOf(
                    hasProperty("partyId", equalTo(party.getSysId())),
                    hasProperty("dateOfDeath", equalTo(NOW.toLocalDate())),
                    hasProperty("title", equalTo("Mr")),
                    hasProperty("forenames", equalTo("John")),
                    hasProperty("surname", equalTo("Smith")))),
            hasProperty(
                "addresses",
                contains(
                    matchesEmailAddress(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(true)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("prev.email@gmail.com")
                                    .type(AddressType.EMAIL)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("200000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.WORK)
                                    .adcCode("1234")
                                    .country(Country.builder().code("UK").build())
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("07515100000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.MOBILE)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("01234100000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.HOME)
                                    .build())
                            .build())))));
  }

  @Test
  void findBasicPartyInformationReturnsYesterdaysEmailAndTelOnlyWhenEndedOnCoreToday() {
    final Party party = buildFullCustomerRecordEndedByCoreToday();
    insert(party);

    final Optional<Party> maybeActual =
        partyRepository.findBasicPartyInformationHistoric(party.getSysId(), YESTERDAY);
    assertThat(maybeActual.isPresent(), equalTo(true));

    final Party actual = maybeActual.get();

    assertThat(
        actual,
        allOf(
            hasProperty("sysId", equalTo(party.getSysId())),
            hasProperty(
                "person",
                allOf(
                    hasProperty("partyId", equalTo(party.getSysId())),
                    hasProperty("dateOfDeath", equalTo(NOW.toLocalDate())),
                    hasProperty("title", equalTo("Mr")),
                    hasProperty("forenames", equalTo("John")),
                    hasProperty("surname", equalTo("Smith")))),
            hasProperty(
                "addresses",
                contains(
                    matchesEmailAddress(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(CORE_ENDED_TODAY)
                            .preferredContactMethod(true)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address(CUSTOMER_EMAIL_ADDRESS)
                                    .type(AddressType.EMAIL)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(CORE_ENDED_TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("200000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.WORK)
                                    .adcCode("1234")
                                    .country(Country.builder().code("UK").build())
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(CORE_ENDED_TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("07515100000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.MOBILE)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(CORE_ENDED_TODAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address(CUSTOMER_HOME_PHONE_NUMBER)
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.HOME)
                                    .build())
                            .build())))));
  }

  @Test
  void findBasicPartyInformationReturnsYesterdaysEmailAndTelOnlyUpdatedInCoreToday() {
    final Party party = buildFullCustomerRecordUpdatedInCoreToday();
    insert(party);

    final Optional<Party> maybeActual =
        partyRepository.findBasicPartyInformationHistoric(party.getSysId(), YESTERDAY);
    assertThat(maybeActual.isPresent(), equalTo(true));

    final Party actual = maybeActual.get();

    assertThat(
        actual,
        allOf(
            hasProperty("sysId", equalTo(party.getSysId())),
            hasProperty(
                "person",
                allOf(
                    hasProperty("partyId", equalTo(party.getSysId())),
                    hasProperty("dateOfDeath", equalTo(NOW.toLocalDate())),
                    hasProperty("title", equalTo("Mr")),
                    hasProperty("forenames", equalTo("John")),
                    hasProperty("surname", equalTo("Smith")))),
            hasProperty(
                "addresses",
                contains(
                    matchesEmailAddress(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(true)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("prev.email@gmail.com")
                                    .type(AddressType.EMAIL)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("200000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.WORK)
                                    .adcCode("1234")
                                    .country(Country.builder().code("UK").build())
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("07515100000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.MOBILE)
                                    .build())
                            .build()),
                    matchesPhoneNumber(
                        AddressUsage.builder()
                            .startDate(LAST_WEEK)
                            .endDate(YESTERDAY)
                            .preferredContactMethod(false)
                            .function(AddressUsage.AddressFunction.DIRCOM)
                            .nonPostalAddress(
                                NonPostalAddress.builder()
                                    .address("01234100000")
                                    .type(AddressType.TEL)
                                    .sourceType(NPASourceType.HOME)
                                    .build())
                            .build())))));
  }

  @Test
  void findPartyInformationWithAddressTypesReturnsEmptyOptionalIfPartyIdDoesNotExist() {
    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            9999L, Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(false));
  }

  @Test
  void findPartyInformationWithAddressTypesReturnsEmptyOptionalIfPartyIsEnded() {
    final Party endedParty = buildFullCustomerRecord();
    endedParty.setEndedDate(TODAY);
    insert(endedParty);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            endedParty.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(false));
  }

  @Test
  void
      findPartyInformationWithAddressTypesReturnsEmptyOptionalIfAssociatedPersonRecordDoesNotExist() {
    final Party party = buildFullCustomerRecord();
    party.setPerson(null);
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(false));
  }

  @Test
  void findPartyInformationWithAddressTypesReturnsEmptyOptionalIfPersonIsEnded() {
    final Party party = buildFullCustomerRecord();
    party.getPerson().setEndedDate(TODAY);
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(false));
  }

  @ParameterizedTest
  @CsvSource({
    "PERSON,PERSON,true",
    "INTUSG,PERSON,true",
    "PCKUSG,PERSON,true",
    "YBSBRN,INTORG,false",
    "UKBNK,FINST,false",
    "PACKER,EXTORG,false"
  })
  void findPartyInformationWithAddressTypesShouldOnlyFindPartiesWithAPersonPartyType(
      final String code, final String type, final boolean expectedFind) {
    final Party party = buildFullCustomerRecord();
    party.setPartyType(PartyType.builder().code(code).type(type).startDate(TODAY).build());
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(), Collections.emptySet(), Collections.emptySet(), NOW);
    assertThat(actual.isPresent(), equalTo(expectedFind));
  }

  @Test
  void findPartyInformationWithAddressTypesHasEmptyAddressesIfNoneExist() {
    final Party party = buildFullCustomerRecord();
    party.setAddresses(Collections.emptyList());

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            EnumSet.allOf(AddressType.class),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(actual.get().getAddresses(), empty());
  }

  @Test
  void
      findPartyInformationWithAddressTypesDoesNotReturnNonEmailAddressesIfFilteredOnEmailAddressType() {
    final Party party = buildFullCustomerRecord();
    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(
        actual.get().getAddresses(),
        contains(
            allOf(
                hasProperty("startDate", equalTo(TODAY)), // NOPMD
                hasProperty("preferredContactMethod", equalTo(true)),
                hasProperty(
                    "nonPostalAddress",
                    allOf(
                        hasProperty("address", equalTo(CUSTOMER_EMAIL_ADDRESS)),
                        hasProperty("type", equalTo(AddressType.EMAIL)), // NOPMD
                        hasProperty("sourceType", nullValue()))))));
  }

  @Test
  void findPartyInformationWithAddressTypesDoesNotReturnEndedAddresses() {
    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(
                AddressUsage.builder()
                    .sysId(getNextId())
                    .endDate(TODAY)
                    .nonPostalAddress(buildEmailAddress("ended@email.com"))
                    .startDate(TODAY)
                    .function(AddressUsage.AddressFunction.DIRCOM)
                    .build())
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(actual.get().getAddresses(), empty());
  }

  @Test
  void findPartyInformationWithAddressTypesDoesNotReturnAddressWhenAddressFunctionUnknown() {
    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(
                AddressUsage.builder()
                    .sysId(getNextId())
                    .nonPostalAddress(buildEmailAddress("address@email.com"))
                    .startDate(TODAY)
                    .build())
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(actual.get().getAddresses(), empty());
  }

  @Test
  void findPartyInformationWithAddressTypesReturnsPreferredAddressesFirst() {
    final AddressUsage nonPreferredAddress =
        AddressUsage.builder()
            .sysId(getNextId())
            .preferredContactMethod(false)
            .startDate(TODAY)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .sysId(getNextId())
                    .type(AddressType.EMAIL)
                    .address("non.preferred.address@gmail.com")
                    .build())
            .function(AddressUsage.AddressFunction.DIRCOM)
            .build();

    final AddressUsage preferredAddress =
        AddressUsage.builder()
            .sysId(getNextId())
            .preferredContactMethod(true)
            .startDate(TODAY)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .sysId(getNextId())
                    .type(AddressType.EMAIL)
                    .address("preferred.address@gmail.com")
                    .build())
            .function(AddressUsage.AddressFunction.DIRCOM)
            .build();

    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(preferredAddress)
            .address(nonPreferredAddress)
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(
        actual.get().getAddresses(),
        contains(matchesEmailAddress(preferredAddress), matchesEmailAddress(nonPreferredAddress)));
  }

  @Test
  void
      findPartyInformationWithAddressTypesReturnsReturnsLatestCreatedAddressFirstIfPreferredContactMethodValueIsEqual() {
    final AddressUsage expected =
        AddressUsage.builder()
            .sysId(getNextId())
            .startDate(NOW)
            .function(AddressUsage.AddressFunction.DIRCOM)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .sysId(getNextId())
                    .type(AddressType.EMAIL)
                    .address("expected.address@gmail.com")
                    .build())
            .build();

    final AddressUsage otherAddress =
        AddressUsage.builder()
            .sysId(getNextId())
            .startDate(TODAY)
            .function(AddressUsage.AddressFunction.CORR)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .sysId(getNextId())
                    .type(AddressType.EMAIL)
                    .address("other.address@gmail.com")
                    .build())
            .build();

    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(otherAddress)
            .address(expected)
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(
        actual.get().getAddresses(),
        contains(matchesEmailAddress(expected), matchesEmailAddress(otherAddress)));
  }

  @Test
  void
      findPartyInformationWithAddressTypesReturnsLatestSysIdFirstIfCreatedAddressAndPreferredContactMethodValueIsEqual() {
    final AddressUsage olderAddress =
        AddressUsage.builder()
            .sysId(getNextId())
            .startDate(NOW)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .sysId(getNextId())
                    .type(AddressType.EMAIL)
                    .address("other.address@gmail.com")
                    .build())
            .function(AddressUsage.AddressFunction.DIRCOM)
            .build();

    final AddressUsage newerAddress =
        AddressUsage.builder()
            .sysId(getNextId())
            .startDate(NOW)
            .nonPostalAddress(
                NonPostalAddress.builder()
                    .sysId(getNextId())
                    .type(AddressType.EMAIL)
                    .address("expected.address@gmail.com")
                    .build())
            .function(AddressUsage.AddressFunction.DIRCOM)
            .build();

    final Party party =
        Party.builder()
            .sysId(getNextId())
            .partyType(buildPartyType())
            .person(buildPerson())
            .address(olderAddress)
            .address(newerAddress)
            .build();

    insert(party);

    final Optional<Party> actual =
        partyRepository.findPartyInformationWithAddressTypesAndFunctions(
            party.getSysId(),
            Collections.singleton(AddressType.EMAIL),
            EnumSet.allOf(AddressUsage.AddressFunction.class),
            NOW);
    assertThat(actual.isPresent(), equalTo(true));
    assertThat(
        actual.get().getAddresses(),
        contains(matchesEmailAddress(newerAddress), matchesEmailAddress(olderAddress)));
  }

  /* Customer delayed record from ADG Core Tests --- Start */

  /** Asserts multiple party sys id's */
  @ParameterizedTest
  @MethodSource("partySysIdsWithAndWithoutSpacesInMobileNumbers")
  void findPartySysIdsReturnsMultipleMatchedPartySysIds(
      final Long partySysId, final String inputMobileNumber, final String dbMobileNumber) {

    final CustomerDelayedRequest customerDelayedRequest =
        TestHelper.buildCustomMobileNumberCustomerDelayedRequest(inputMobileNumber);

    final PartyType firstPartyType =
        PartyType.builder().code(PERSON).type(PERSON).startDate(TODAY).build();
    final Party party = buildFullDelayedCustomerRecord(partySysId, firstPartyType, dbMobileNumber);
    insert(party);
    final PartyType secondPartyType =
        PartyType.builder().code("YS").type(PERSON).startDate(TODAY).build();
    final Party secondParty =
        buildFullDelayedCustomerRecord(partySysId + 20, secondPartyType, dbMobileNumber);
    insert(secondParty);

    final Optional<List<CustomerPartySysID>> customerPartySysID =
        partyRepository.findPartySysIds(
            customerDelayedRequest.getForename().trim().toUpperCase(LOCALE),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode().replaceAll(" ", "").toUpperCase(LOCALE),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);
    assertThat(customerPartySysID.isPresent(), equalTo(true));
    assertThat(customerPartySysID.get().size(), equalTo(2));
  }

  /** Asserts no record found */
  @ParameterizedTest
  @MethodSource("mismatchInputs")
  void findPartySysIdsReturnsZeroMatchedPartySysIds(
      final CustomerDelayedRequest customerDelayedRequest) {
    final PartyType firstPartyType =
        PartyType.builder().code(PERSON).type(PERSON).startDate(TODAY).build();
    final Party party =
        buildFullDelayedCustomerRecord(123456L, firstPartyType, CUSTOMER_MOBILE_PHONE_NUMBER);
    insert(party);

    final Optional<List<CustomerPartySysID>> customerPartySysID =
        partyRepository.findPartySysIds(
            customerDelayedRequest.getForename(),
            customerDelayedRequest.getDateOfBirth(),
            customerDelayedRequest.getPostCode(),
            customerDelayedRequest.getMobileNumber(),
            YESTERDAY);
    assertThat(customerPartySysID.isPresent(), equalTo(true));
    assertThat(customerPartySysID.get().size(), equalTo(0));
  }

  /** Asserts linked party sys id's */
  @ParameterizedTest
  @MethodSource("linkedPartyDetails")
  void findLinkedPartiesReturnsMultipleMatchedLinkedParties(
      final Long partySysId, final int linkedPartiesCount) {
    final Optional<List<LinkedPartyDetails>> linkedPartyDetails =
        partyRepository.findLinkedParties(partySysId);
    assertThat(linkedPartyDetails.isPresent(), equalTo(true));
    assertThat(linkedPartyDetails.get().size(), equalTo(linkedPartiesCount));
  }

  /** Asserts Web Customer details - customer with and without username */
  @ParameterizedTest
  @MethodSource("webLogOnDetails")
  void findWebLogonDetailsReturnsWebLogOnDetails(
      final Long partySysId, final CustomerWebLogOnDetails expectedCustomerWebLogOnDetails) {
    final Optional<CustomerWebLogOnDetails> customerWebLogOnDetails =
        partyRepository.findWebLogonDetails(partySysId);
    assertThat(customerWebLogOnDetails.isPresent(), equalTo(true));
    assertThat(customerWebLogOnDetails.get(), equalTo(expectedCustomerWebLogOnDetails));
  }

  /** Asserts Non Web Customer */
  @Test
  void findWebLogonDetailsReturnsNoData() {
    final Optional<CustomerWebLogOnDetails> customerWebLogOnDetails =
        partyRepository.findWebLogonDetails(123456L);
    assertThat(customerWebLogOnDetails.isPresent(), equalTo(false));
  }

  /** Asserts If a PartyId is eligible for DeDupe or not */
  @Test
  void findDeDupeEligiblePartyId() {
    final DeDupeEligibleParty deDupeEligibleParty =
        partyRepository.findDeDupeEligiblePartyId(4567890123L);
    assertThat(deDupeEligibleParty.getEligibility(), equalTo("Y"));
  }

  private static Stream<Arguments> partySysIdsWithAndWithoutSpacesInMobileNumbers() {
    return Stream.of(
        Arguments.of(12462951L, CUSTOMER_MOBILE_PHONE_NUMBER, CUSTOMER_MOBILE_PHONE_NUMBER),
        Arguments.of(12462953L, "07987654321", " 07987654321"),
        Arguments.of(12462955L, "07876543212", "0 7876543212"),
        Arguments.of(12462956L, "07765432123", "07 765432123"),
        Arguments.of(12462957L, "07754321234", "077 54321234"),
        Arguments.of(12462958L, "07543212345", "0754 3212345"),
        Arguments.of(12462959L, "07432123456", "07432 123456"),
        Arguments.of(12462960L, "07387654321", "073876 54321"),
        Arguments.of(12462961L, "07287654321", "0728765 4321"),
        Arguments.of(12462962L, "07967654321", "07967654 321"),
        Arguments.of(12462962L, "07957654321", "079576543 21"),
        Arguments.of(12462963L, "07977654321", "0797765432 1"),
        Arguments.of(12462964L, "07976654321", "07976654321 "),
        Arguments.of(12462965L, "07976654323", "07976 65 4323"),
        Arguments.of(12462966L, "07976654324", "07976  654324"));
  }

  private static Stream<Arguments> mismatchInputs() {
    return Stream.of(
        Arguments.of(TestHelper.buildCustomForenameCustomerDelayedRequest("TEST")),
        Arguments.of(TestHelper.buildCustomDateOfBirthCustomerDelayedRequest("1990-01-01")),
        Arguments.of(TestHelper.buildCustomPostCodeCustomerDelayedRequest("LS18NQ")),
        Arguments.of(TestHelper.buildCustomMobileNumberCustomerDelayedRequest("07123456789")));
  }

  private static Stream<Arguments> linkedPartyDetails() {
    return Stream.of(Arguments.of(4567890123L, 1));
  }

  private static Stream<Arguments> webLogOnDetails() {
    return Stream.of(
        Arguments.of(
            1234567893L,
            CustomerWebLogOnDetails.builder()
                .partyId(1234567893L)
                .webCustomerNumber(1234567893L)
                .build()),
        Arguments.of(
            1234567894L,
            CustomerWebLogOnDetails.builder()
                .partyId(1234567894L)
                .webCustomerNumber(1234567894L)
                .webUsername("John123")
                .build()));
  }

  /* Customer delayed record from ADG Database Tests --- End */

  private Matcher<AddressUsage> matchesPostalAddress(final AddressUsage addressUsage) {
    return allOf(
        hasProperty("startDate", equalTo(addressUsage.getStartDate())), // NOPMD
        hasProperty("function", equalTo(addressUsage.getFunction())),
        hasProperty(
            "postalAddress",
            allOf(
                hasProperty("line1", equalTo(addressUsage.getPostalAddress().getLine1())),
                hasProperty("line2", equalTo(addressUsage.getPostalAddress().getLine2())),
                hasProperty("line3", equalTo(addressUsage.getPostalAddress().getLine3())),
                hasProperty("line4", equalTo(addressUsage.getPostalAddress().getLine4())),
                hasProperty("line5", equalTo(addressUsage.getPostalAddress().getLine5())),
                hasProperty("postCode", equalTo(addressUsage.getPostalAddress().getPostCode())),
                hasProperty("country", equalTo(addressUsage.getPostalAddress().getCountry())),
                hasProperty("type", equalTo(addressUsage.getPostalAddress().getType()))))); // NOPMD
  }

  private Matcher<AddressUsage> matchesEmailAddress(final AddressUsage addressUsage) {
    return allOf(
        hasProperty("startDate", equalTo(addressUsage.getStartDate())), // NOPMD
        hasProperty("function", equalTo(addressUsage.getFunction())),
        hasProperty(
            "nonPostalAddress",
            allOf(
                hasProperty("address", equalTo(addressUsage.getNonPostalAddress().getAddress())),
                hasProperty(
                    "type", equalTo(addressUsage.getNonPostalAddress().getType()))))); // NOPMD
  }

  private Matcher<AddressUsage> matchesPhoneNumber(final AddressUsage addressUsage) {
    return allOf(
        hasProperty("startDate", equalTo(addressUsage.getStartDate())), // NOPMD
        hasProperty("function", equalTo(addressUsage.getFunction())),
        hasProperty(
            "nonPostalAddress",
            allOf(
                hasProperty("address", equalTo(addressUsage.getNonPostalAddress().getAddress())),
                hasProperty("type", equalTo(addressUsage.getNonPostalAddress().getType())), // NOPMD
                hasProperty(
                    "sourceType", equalTo(addressUsage.getNonPostalAddress().getSourceType())),
                matchesAdcCode(addressUsage.getNonPostalAddress().getAdcCode()),
                matchesCountry(addressUsage.getNonPostalAddress().getCountry()))));
  }

  private Matcher<AddressUsage> matchesAdcCode(final String adcCode) {
    if (!Strings.isNullOrEmpty(adcCode)) {
      return hasProperty("adcCode", equalTo(adcCode));
    }
    return hasProperty("adcCode", is(nullValue()));
  }

  private Matcher<AddressUsage> matchesCountry(final Country country) {
    if (country != null) {
      return hasProperty("country", allOf(hasProperty("code", equalTo(country.getCode()))));
    }
    return hasProperty("country", is(nullValue()));
  }

  private Person buildPerson() {
    return Person.builder()
        .title("Mr")
        .forenames("John")
        .surname("Smith")
        .dateOfBirth(LocalDate.now().minusYears(18))
        .dateOfDeath(NOW.toLocalDate())
        .build();
  }

  private static Stream<Arguments> linkedParties() {
    return Stream.of(
        Arguments.of(
            0L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(0L)
                    .canonicalPartyId(0L)
                    .linkCount((0L))
                    .build())),
        Arguments.of(
            1L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(1L)
                    .canonicalPartyId(0L)
                    .linkCount((1L))
                    .build())),
        Arguments.of(
            2L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(2L)
                    .canonicalPartyId(0L)
                    .linkCount((2L))
                    .build())),
        Arguments.of(3L, Optional.empty()));
  }

  private void insert(final Party party) {
    transactionTemplate.executeWithoutResult(
        status -> {
          PartyType partyType =
              PartyType.builder()
                  .code(party.getPartyType().getCode())
                  .type(party.getPartyType().getType())
                  .startDate(party.getPartyType().getStartDate())
                  .endDate(party.getPartyType().getEndDate())
                  .build();

          adgCoreTestEntityManager.persist(partyType);

          // insert the party without the address usages and person record before inserting person
          // and address usages
          // as the there is a foreign key constraint back to this record.
          Party emptyParty =
              Party.builder()
                  .sysId(party.getSysId())
                  .partyType(partyType)
                  .endedDate(party.getEndedDate())
                  .placeOfBirth(party.getPlaceOfBirth())
                  .build();

          adgCoreTestEntityManager.persist(emptyParty);

          Optional.ofNullable(party.getPerson())
              .ifPresent(
                  person -> {
                    person.setParty(emptyParty);
                    adgCoreTestEntityManager.persist(person);
                  });

          for (AddressUsage addressUsage : party.getAddresses()) {
            addressUsage.setParty(emptyParty);
            if (addressUsage.getNonPostalAddress() != null) {
              adgCoreTestEntityManager.persist(addressUsage.getNonPostalAddress());
            }
            if (addressUsage.getPostalAddress() != null) {
              adgCoreTestEntityManager.persist(addressUsage.getPostalAddress());
            }
            adgCoreTestEntityManager.persist(addressUsage);
          }

          adgCoreTestEntityManager.flush();
          adgCoreTestEntityManager.clear();
        });
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  private Party buildFullCustomerRecord() {
    return Party.builder()
        .sysId(getNextId())
        .partyType(buildPartyType())
        .person(buildPerson())
        .placeOfBirth("PlaceOfBirth")
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("AddressLine1_1")
                        .line2("AddressLine2_1")
                        .line4("AddressLine3_1")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("PO")
                                .districtCode("57")
                                .sectorCode("0")
                                .unitCode("DE")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressUsage.AddressFunction.CORR)
                .startDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("PrevAddressLine1_1")
                        .line2("PrevAddressLine2_1")
                        .line4("PrevAddressLine3_1")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("LS")
                                .districtCode("1")
                                .sectorCode("0")
                                .unitCode("AA")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressUsage.AddressFunction.CORR)
                .startDate(LAST_WEEK)
                .endDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddress(CUSTOMER_EMAIL_ADDRESS))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(TODAY)
                .preferredContactMethod(true)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddress("prev.email@gmail.com"))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .endDate(TODAY)
                .preferredContactMethod(true)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address(CUSTOMER_HOME_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address("01234100000")
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .endDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address(CUSTOMER_MOBILE_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address("07515100000")
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .endDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address("421693")
                        .adcCode("1234")
                        .country(Country.builder().code("UK").build())
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address("200000")
                        .adcCode("1234")
                        .country(Country.builder().code("UK").build())
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .endDate(TODAY)
                .build())
        .build();
  }

  private Party buildFullCustomerRecordEndedByCoreToday() {

    return Party.builder()
        .sysId(getNextId())
        .partyType(buildPartyType())
        .person(buildPerson())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddress(CUSTOMER_EMAIL_ADDRESS))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .preferredContactMethod(true)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address(CUSTOMER_HOME_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address("07515100000")
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address("200000")
                        .adcCode("1234")
                        .country(Country.builder().code("UK").build())
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .build())
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  private Party buildFullCustomerRecordUpdatedInCoreToday() {
    return Party.builder()
        .sysId(getNextId())
        .partyType(buildPartyType())
        .person(buildPerson())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("AddressLine1_1")
                        .line2("AddressLine2_1")
                        .line4("AddressLine3_1")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("PO")
                                .districtCode("57")
                                .sectorCode("0")
                                .unitCode("DE")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressUsage.AddressFunction.CORR)
                .startDate(TODAY)
                .createdDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("PrevAddressLine1_1")
                        .line2("PrevAddressLine2_1")
                        .line4("PrevAddressLine3_1")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("LS")
                                .districtCode("1")
                                .sectorCode("0")
                                .unitCode("AA")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressUsage.AddressFunction.CORR)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddress(CUSTOMER_EMAIL_ADDRESS))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(TODAY)
                .createdDate(TODAY)
                .preferredContactMethod(true)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddress("prev.email@gmail.com"))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .preferredContactMethod(true)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address(CUSTOMER_HOME_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(TODAY)
                .createdDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address("01234100000")
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address(CUSTOMER_MOBILE_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(TODAY)
                .createdDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address("07515100000")
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address("421693")
                        .adcCode("1234")
                        .country(Country.builder().code("UK").build())
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(TODAY)
                .createdDate(TODAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address("200000")
                        .adcCode("1234")
                        .country(Country.builder().code("UK").build())
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(LAST_WEEK)
                .createdDate(LAST_WEEK)
                .endDate(CORE_ENDED_TODAY)
                .build())
        .build();
  }

  private NonPostalAddress buildEmailAddress(final String address) {
    return NonPostalAddress.builder()
        .sysId(getNextId())
        .type(AddressType.EMAIL)
        .address(address)
        .build();
  }

  private static PartyType buildPartyType() {
    return PartyType.builder().code(PERSON).type(PERSON).startDate(TODAY).build();
  }

  private static long getNextId() {
    return nextId++;
  }

  public Party buildFullDelayedCustomerRecord(
      final Long partySysId, final PartyType partyType, final String mobileNumber) {
    return Party.builder()
        .sysId(partySysId)
        .partyType(partyType)
        .person(buildPerson())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .postalAddress(
                    PostalAddress.builder()
                        .sysId(getNextId())
                        .line1("AddressLine1_1")
                        .line2("AddressLine2_1")
                        .line4("AddressLine3_1")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("PO")
                                .districtCode("57")
                                .sectorCode("0")
                                .unitCode("DE")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressUsage.AddressFunction.CORR)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(buildEmailAddress(CUSTOMER_EMAIL_ADDRESS))
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .preferredContactMethod(true)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.HOME)
                        .address(CUSTOMER_HOME_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.MOBILE)
                        .address(mobileNumber)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .address(
            AddressUsage.builder()
                .sysId(getNextId())
                .nonPostalAddress(
                    NonPostalAddress.builder()
                        .sysId(getNextId())
                        .type(AddressType.TEL)
                        .sourceType(NPASourceType.WORK)
                        .address(CUSTOMER_WORK_PHONE_NUMBER)
                        .build())
                .function(AddressUsage.AddressFunction.DIRCOM)
                .startDate(YESTERDAY)
                .createdDate(YESTERDAY)
                .build())
        .build();
  }
}
