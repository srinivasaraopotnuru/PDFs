package uk.co.ybs.digital.customer.integration;

import java.io.IOException;
import java.net.URI;
import java.util.UUID;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.filter.OncePerRequestFilter;
import uk.co.ybs.digital.customer.integration.WhitelabelErrorPageIT.WhitelabelErrorPageTestConfig;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, WhitelabelErrorPageTestConfig.class})
@ActiveProfiles("test")
class WhitelabelErrorPageIT {
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";

  @LocalServerPort private int port;

  @Autowired private WebTestClient signingWebTestClient;

  @Test
  void
      whitelabelErrorPageShouldReturnInternalServerErrorWhenRequestFilterThrowsUnexpectedException() {
    final UUID requestId = UUID.randomUUID();

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("500 Internal Server Error")
            .message("Internal Server Error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("UnexpectedError")
                    .message("Unexpected error")
                    .build())
            .build();

    signingWebTestClient
        .get()
        .uri(getURI())
        .accept(MediaType.APPLICATION_JSON)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  private URI getURI() {
    return URI.create("http://localhost:" + port + "/customer/customer/123456");
  }

  @TestConfiguration
  static class WhitelabelErrorPageTestConfig {
    @Bean
    FilterRegistrationBean<Filter> filterRegistrationBean() {
      return new FilterRegistrationBean<>(
          new OncePerRequestFilter() {
            @Override
            protected void doFilterInternal(
                final HttpServletRequest request,
                final HttpServletResponse response,
                final FilterChain filterChain)
                throws IOException {
              throw new IOException("Unexpected exception");
            }
          });
    }
  }
}
