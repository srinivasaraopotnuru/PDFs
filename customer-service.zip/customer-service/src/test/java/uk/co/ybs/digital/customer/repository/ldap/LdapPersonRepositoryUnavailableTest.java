package uk.co.ybs.digital.customer.repository.ldap;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.ldap.DataLdapTest;
import org.springframework.ldap.CommunicationException;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@DataLdapTest(properties = {"spring.ldap.urls=ldap://localhost:1"})
class LdapPersonRepositoryUnavailableTest {

  @Autowired private LdapPersonRepository ldapPersonRepository;

  /*
   * This proves that exceptions of type org.springframework.ldap.NamingException are thrown by the repository
   * in the event unexpected LDAP errors occur.
   */
  @Test
  void shouldThrowCommunicationExceptionWhenUnavailable() {
    assertThrows(CommunicationException.class, () -> ldapPersonRepository.findByUid("0000123456"));
  }
}
