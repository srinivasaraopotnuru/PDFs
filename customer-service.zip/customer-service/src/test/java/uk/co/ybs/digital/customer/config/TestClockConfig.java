package uk.co.ybs.digital.customer.config;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;

@TestConfiguration
public class TestClockConfig {
  public static final Instant NOW = Instant.parse("2020-04-23T13:56:15Z");

  @Bean
  public Clock clock() {
    return Clock.fixed(NOW, ZoneId.of("Europe/London"));
  }
}
