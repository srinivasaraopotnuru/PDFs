package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.CustomerWebLogOnDetails;
import uk.co.ybs.digital.customer.model.adgcore.NPASourceType;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.Person;
import uk.co.ybs.digital.customer.service.PendingDetailsService;
import uk.co.ybs.digital.customer.web.dto.CustomerBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberResponse;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberSubType;

@ExtendWith(SpringExtension.class)
@SpringBootTest(
    classes = {CustomerBasicMapperImpl.class, PhoneNumberMapperImpl.class, EmailMapperImpl.class})
class CustomerBasicMapperTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");
  private static final String TITLE = "title";
  private static final String FORENAME = "forename";
  private static final String SURNAME = "surname";
  private static final String PARTY_ID = "123456";
  private static final String TELEPHONE_NUMBER = "01234420713";

  @MockBean private PendingDetailsService pendingDetailsService;

  @Autowired private CustomerBasicMapper testSubject;

  private static CustomerBasic buildCustomerBasicResponse(
      final String email, final List<PhoneNumberResponse> phone) {
    return CustomerBasic.builder()
        .partyId(PARTY_ID)
        .title(TITLE)
        .forename(FORENAME)
        .surname(SURNAME)
        .email(email)
        .phoneNumbers(phone)
        .deceasedDate(LocalDate.of(2020, 1, 1))
        .build();
  }

  private static Country buildCountry() {
    return Country.builder().code("UK").build();
  }

  private CustomerBasic buildCustomerDelayedBasicResponse(
      final String email, final List<PhoneNumberResponse> phone) {
    return CustomerBasic.builder()
        .partyId(PARTY_ID)
        .title(TITLE)
        .forename(FORENAME)
        .surname(SURNAME)
        .email(email)
        .phoneNumbers(phone)
        .dateOfBirth(LocalDate.now().minusYears(18))
        .deceasedDate(LocalDate.of(2020, 1, 1))
        .webCustomerNumber("1234567890")
        .webUsername("John123")
        .build();
  }

  private CustomerWebLogOnDetails buildWebLogonDetailsRequest() {
    return CustomerWebLogOnDetails.builder()
        .partyId(123456L)
        .webCustomerNumber(1234567890L)
        .webUsername("John123")
        .build();
  }

  @Test
  void shouldMapPartyToCustomerBasicUsingFirstEmailAddressInTheList() {
    final String email = "john.smith@aol.com";
    final Party party =
        Party.builder()
            .sysId(123456L)
            .person(
                Person.builder()
                    .title(TITLE)
                    .forenames(FORENAME)
                    .surname(SURNAME)
                    .dateOfBirth(LocalDate.now().minusYears(18))
                    .dateOfDeath(LocalDate.of(2020, 1, 1))
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder().type(AddressType.EMAIL).address(email).build())
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.EMAIL)
                            .address("not.used@gmail.com")
                            .build())
                    .build())
            .build();

    final CustomerBasic expectedCustomer =
        buildCustomerBasicResponse(email, Collections.emptyList());

    final CustomerBasic customer = testSubject.map(party);
    assertThat(customer, is(expectedCustomer));

    final CustomerWebLogOnDetails customerWebLogOnDetails = buildWebLogonDetailsRequest();
    final CustomerBasic expectedCustomerDelayed =
        buildCustomerDelayedBasicResponse(email, Collections.emptyList());

    final CustomerBasic customerDelayed = testSubject.map(party, customerWebLogOnDetails);
    assertThat(customerDelayed, is(expectedCustomerDelayed));
  }

  @Test
  void shouldMapPartyToCustomerBasicIgnoringEmailIfItDoesNotExist() {
    final Party party =
        Party.builder()
            .sysId(123456L)
            .person(
                Person.builder()
                    .title(TITLE)
                    .forenames(FORENAME)
                    .surname(SURNAME)
                    .dateOfBirth(LocalDate.now().minusYears(18))
                    .dateOfDeath(LocalDate.of(2020, 1, 1))
                    .build())
            .build();

    final CustomerBasic expectedCustomer =
        buildCustomerBasicResponse(null, Collections.emptyList());

    final CustomerBasic customer = testSubject.map(party);
    assertThat(customer, is(expectedCustomer));

    final CustomerWebLogOnDetails customerWebLogOnDetails = buildWebLogonDetailsRequest();
    final CustomerBasic expectedCustomerDelayed =
        buildCustomerDelayedBasicResponse(null, Collections.emptyList());

    final CustomerBasic customerDelayed = testSubject.map(party, customerWebLogOnDetails);
    assertThat(customerDelayed, is(expectedCustomerDelayed));
  }

  @Test
  void shouldMapPartyToCustomerBasicWithPhoneNumber() {
    final Party party =
        Party.builder()
            .sysId(123456L)
            .person(
                Person.builder()
                    .title(TITLE)
                    .forenames(FORENAME)
                    .surname(SURNAME)
                    .dateOfBirth(LocalDate.now().minusYears(18))
                    .dateOfDeath(LocalDate.of(2020, 1, 1))
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.TEL)
                            .address(TELEPHONE_NUMBER)
                            .country(buildCountry())
                            .build())
                    .startDate(NOW)
                    .createdDate(NOW)
                    .build())
            .build();

    final CustomerBasic expectedCustomer =
        buildCustomerBasicResponse(
            null,
            Collections.singletonList(
                PhoneNumberResponse.builder()
                    .number(TELEPHONE_NUMBER)
                    .type("DEFAULT")
                    .subType(PhoneNumberSubType.LANDLINE)
                    .build()));

    final CustomerBasic customer = testSubject.map(party);
    assertThat(customer, is(expectedCustomer));

    final CustomerWebLogOnDetails customerWebLogOnDetails = buildWebLogonDetailsRequest();
    final CustomerBasic expectedCustomerDelayed =
        buildCustomerDelayedBasicResponse(
            null,
            Collections.singletonList(
                PhoneNumberResponse.builder()
                    .number(TELEPHONE_NUMBER)
                    .type("DEFAULT")
                    .subType(PhoneNumberSubType.LANDLINE)
                    .build()));

    final CustomerBasic customerDelayed = testSubject.map(party, customerWebLogOnDetails);
    assertThat(customerDelayed, is(expectedCustomerDelayed));
  }

  @Test
  void shouldMapPartyToCustomerBasicWithAllPhoneNumbers() {
    final Party party =
        Party.builder()
            .sysId(123456L)
            .person(
                Person.builder()
                    .title(TITLE)
                    .forenames(FORENAME)
                    .surname(SURNAME)
                    .dateOfBirth(LocalDate.now().minusYears(18))
                    .dateOfDeath(LocalDate.of(2020, 1, 1))
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.TEL)
                            .address(TELEPHONE_NUMBER)
                            .sourceType(NPASourceType.WORK)
                            .country(buildCountry())
                            .build())
                    .startDate(NOW)
                    .createdDate(NOW)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.TEL)
                            .address("07515059347")
                            .sourceType(NPASourceType.MOBILE)
                            .build())
                    .startDate(NOW)
                    .createdDate(NOW)
                    .build())
            .address(
                AddressUsage.builder()
                    .nonPostalAddress(
                        NonPostalAddress.builder()
                            .type(AddressType.TEL)
                            .address("01234421693")
                            .sourceType(NPASourceType.HOME)
                            .country(buildCountry())
                            .build())
                    .startDate(NOW)
                    .createdDate(NOW)
                    .build())
            .build();

    final CustomerBasic expectedCustomer =
        buildCustomerBasicResponse(
            null,
            Arrays.asList(
                PhoneNumberResponse.builder()
                    .number(TELEPHONE_NUMBER)
                    .type("WORK")
                    .subType(PhoneNumberSubType.LANDLINE)
                    .build(),
                PhoneNumberResponse.builder()
                    .number("07515059347")
                    .type("MOBILE")
                    .subType(PhoneNumberSubType.MOBILE)
                    .build(),
                PhoneNumberResponse.builder()
                    .number("01234421693")
                    .type("HOME")
                    .subType(PhoneNumberSubType.LANDLINE)
                    .build()));

    final CustomerBasic customer = testSubject.map(party);
    assertThat(customer, is(expectedCustomer));

    final CustomerWebLogOnDetails customerWebLogOnDetails = buildWebLogonDetailsRequest();
    final CustomerBasic expectedCustomerDelayed =
        buildCustomerDelayedBasicResponse(
            null,
            Arrays.asList(
                PhoneNumberResponse.builder()
                    .number(TELEPHONE_NUMBER)
                    .type("WORK")
                    .subType(PhoneNumberSubType.LANDLINE)
                    .build(),
                PhoneNumberResponse.builder()
                    .number("07515059347")
                    .type("MOBILE")
                    .subType(PhoneNumberSubType.MOBILE)
                    .build(),
                PhoneNumberResponse.builder()
                    .number("01234421693")
                    .type("HOME")
                    .subType(PhoneNumberSubType.LANDLINE)
                    .build()));

    final CustomerBasic customerDelayed = testSubject.map(party, customerWebLogOnDetails);
    assertThat(customerDelayed, is(expectedCustomerDelayed));
  }
}
