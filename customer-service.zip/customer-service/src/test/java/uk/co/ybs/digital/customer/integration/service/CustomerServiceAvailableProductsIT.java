package uk.co.ybs.digital.customer.integration.service;

import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildFilteredProducts;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildOnSaleProducts;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildOnSaleProductsWithRemovedProduct;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.buildProductCategoriesUnavailableProductsOnly;
import static uk.co.ybs.digital.customer.service.product.ProductTestHelper.getMockApplicationResponsePrivateEmpty;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildAccountGroupedInfo;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildFullCustomerRecordADG;
import static uk.co.ybs.digital.customer.utils.TestHelper.buildFullCustomerRecordNonUKPostalAddressADG;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import lombok.NonNull;
import okhttp3.mockwebserver.MockResponse;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.ResolvableType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.customer.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.customer.integration.IntegrationTestConfig;
import uk.co.ybs.digital.customer.integration.IntegrationTestJwtFactory;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.service.account.dto.AccountGroupedInfo;
import uk.co.ybs.digital.customer.service.product.ProductTestHelper;
import uk.co.ybs.digital.customer.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.ErrorResponse;
import uk.co.ybs.digital.customer.web.dto.products.ProductCategory;

/* Available products tests moved to isolated class as will be removed in the future  */
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@AutoConfigureWebTestClient(timeout = "36000")
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
@SuppressWarnings("PMD.AvoidDuplicateLiterals")
class CustomerServiceAvailableProductsIT extends CustomerServiceITBase {

  private static final String PATH_AVAILABLE_PRODUCTS = "/customer/available-products";
  private static final String PATH_AVAILABLE_PRODUCTS_PRIVATE =
      "/private/customer/available-products";
  private static final String ACCOUNT_READ_SCOPE = "ACCOUNT_READ";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_SESSION_ID = "x-ybs-session-id";
  private static final String LOCALHOST = "localhost";
  private static final String BRAND_CODE_YBS = "YBS";
  private static final String OTHER_SCOPE = "PAYMENT";

  private static final UUID SESSION_ID = UUID.randomUUID();

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void shouldGetAvailableProducts(final String path) throws IOException {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubGetAccountGroupInfo();

    stubGetOnSaleProducts();

    stubGetCurrentApplicationsEmpty();

    doGetAvailableProducts(path, requestId, jwt, buildFilteredProducts());
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void shouldGetAvailableProductsShouldUseCachedOnSaleProducts(final String path)
      throws IOException {

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubGetAccountGroupInfo();
    stubGetOnSaleProducts();
    stubGetCurrentApplicationsEmpty();

    final List<ProductCategory> expectedResponse = buildFilteredProducts();

    // 1st Call
    doGetAvailableProducts(path, UUID.randomUUID(), jwt, expectedResponse);

    stubGetAccountGroupInfo();
    stubGetCurrentApplicationsEmpty();

    // 2nd Call
    doGetAvailableProducts(path, UUID.randomUUID(), jwt, expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsRemovesProductsWhereMaximumApplicationsExceeded(final String path)
      throws IOException {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final Party party = buildFullCustomerRecordADG();
    insert(party);

    stubGetAccountGroupInfo();

    stubGetOnSaleProducts();

    stubGetCurrentApplications();

    doGetAvailableProducts(path, requestId, jwt, buildOnSaleProductsWithRemovedProduct());
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnOnlyUnavailableProductsWhenNotUkAddress(final String path)
      throws IOException {

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final Party party = buildFullCustomerRecordNonUKPostalAddressADG();
    insert(party);

    stubGetAccountGroupInfo();

    stubGetOnSaleProducts();

    stubGetCurrentApplicationsEmpty();

    doGetAvailableProducts(
        path, UUID.randomUUID(), jwt, buildProductCategoriesUnavailableProductsOnly());
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldBeIdempotent(final String path) throws IOException {

    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final Party party = buildFullCustomerRecordNonUKPostalAddressADG();
    insert(party);

    stubGetAccountGroupInfo();

    stubGetOnSaleProducts();

    stubGetCurrentApplicationsEmpty();

    final List<ProductCategory> expectedResponse = buildProductCategoriesUnavailableProductsOnly();
    doGetAvailableProducts(path, UUID.randomUUID(), jwt, expectedResponse);

    stubGetAccountGroupInfo();

    stubGetCurrentApplicationsEmpty();

    doGetAvailableProducts(path, UUID.randomUUID(), jwt, expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnNotFoundWhenCustomerDoesntExist(final String path) {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final ErrorResponse expectedResponse = TestHelper.buildErrorResponseNotFound(requestId);

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.NOT_FOUND)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnUnAuthorisedWhenBearerTokenIsNotValidJwt(final String path) {
    final UUID requestId = UUID.randomUUID();

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer invalid.bearer.token")
        .header(HEADER_REQUEST_ID, requestId.toString())
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.unauthorizedErrorResponse(requestId));
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnForbiddenWhenSignatureIsInvalid(final String path) {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("403 Forbidden")
            .message("Forbidden")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message("Access Denied")
                    .build())
            .build();

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .header("x-ybs-request-signature-key-id", "FKbfNeQxsVQL5CwAJKP0q5fWOVe9ukn1K0lw")
        .header("x-ybs-request-signature", "invalid-signature")
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldReturnForbiddenWhenJwtLacksRequiredScope(final String path) {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(OTHER_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.accessDeniedErrorResponse(requestId));
  }

  @ParameterizedTest(name = "{displayName} {arguments}")
  @ValueSource(strings = {PATH_AVAILABLE_PRODUCTS, PATH_AVAILABLE_PRODUCTS_PRIVATE})
  void getAvailableProductsShouldThrowInternalServerErrorWhenNoCustomerDOB(final String path) {

    final UUID requestId = UUID.randomUUID();
    final String jwt =
        IntegrationTestJwtFactory.createJwtWithScope(
            ACCOUNT_READ_SCOPE, jwtSigningPrivateKey, SESSION_ID);

    final Party party = buildFullCustomerRecordADG();
    party.getPerson().setDateOfBirth(null);
    insert(party);

    final ErrorResponse expectedResponse =
        TestHelper.buildErrorResponseInternalServerError(requestId);

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @NonNull
  private String stubGetAccountGroupInfo() throws JsonProcessingException {

    AccountGroupedInfo accountGroupedInfo = buildAccountGroupedInfo();

    final String groupedInfo = objectMapper.writeValueAsString(accountGroupedInfo);

    mockAccountService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(groupedInfo));
    return groupedInfo;
  }

  private void stubGetOnSaleProducts() throws JsonProcessingException {
    final String onSaleProducts = objectMapper.writeValueAsString(buildOnSaleProducts());

    mockProductService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(onSaleProducts));
  }

  private void stubGetCurrentApplicationsEmpty() throws JsonProcessingException {
    final String customerApplications =
        objectMapper.writeValueAsString(getMockApplicationResponsePrivateEmpty());

    mockApplyService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(customerApplications));
  }

  private void stubGetCurrentApplications() throws JsonProcessingException {
    final String customerApplications =
        objectMapper.writeValueAsString(
            ProductTestHelper.buildMockApplicationResponsePrivate(1, "YB271280WA"));

    mockApplyService.enqueue(
        new MockResponse()
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
            .setBody(customerApplications));
  }

  private void doGetAvailableProducts(
      final String path,
      final UUID requestId,
      final String jwt,
      final List<ProductCategory> expectedResponse) {
    final ResolvableType resolvableType =
        ResolvableType.forClassWithGenerics(List.class, ProductCategory.class);

    final ParameterizedTypeReference<List<ProductCategory>> responseTypeRef =
        ParameterizedTypeReference.forType(resolvableType.getType());

    signingWebTestClient
        .get()
        .uri(getURI(path))
        .accept(MediaType.APPLICATION_JSON)
        .header(HttpHeaders.HOST, LOCALHOST)
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + jwt)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_BRAND_CODE, BRAND_CODE_YBS)
        .header(HEADER_SESSION_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(responseTypeRef)
        .isEqualTo(expectedResponse);
  }
}
