package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.emptyCollectionOf;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.PostCode;
import uk.co.ybs.digital.customer.model.adgcore.AddressType;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage;
import uk.co.ybs.digital.customer.model.adgcore.AddressUsage.AddressFunction;
import uk.co.ybs.digital.customer.model.adgcore.Country;
import uk.co.ybs.digital.customer.model.adgcore.NonPostalAddress;
import uk.co.ybs.digital.customer.model.adgcore.Party;
import uk.co.ybs.digital.customer.model.adgcore.PartyType;
import uk.co.ybs.digital.customer.model.adgcore.PostalAddress;
import uk.co.ybs.digital.customer.service.PendingDetailsService;
import uk.co.ybs.digital.customer.web.dto.PostalAddressResponse;

@ExtendWith(MockitoExtension.class)
public class PostalAddressMapperTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");
  private static final LocalDateTime YESTERDAY = NOW.minusDays(1L);
  public static final String CORR_TYPE = "CORR";
  private static final String ADDRESS_LINE_1 = "AddressLine1";
  private static final String ADDRESS_LINE_2 = "AddressLine2";
  private static final String ADDRESS_LINE_3 = "AddressLine3";

  PostalAddressMapper testSubject;

  @Mock PendingDetailsService pendingDetailsService;

  @BeforeEach
  void setUp() {
    testSubject = Mappers.getMapper(PostalAddressMapper.class);
    testSubject.setService(pendingDetailsService);
  }

  @Test
  void mapsPostalAddresses() {
    PostalAddress firstAddress =
        PostalAddress.builder()
            .sysId(1L)
            .line1(ADDRESS_LINE_1)
            .line2(ADDRESS_LINE_2)
            .line3(ADDRESS_LINE_3)
            .country(Country.builder().code("UK").isoCode("GB").build())
            .postCode(
                PostCode.builder()
                    .areaCode("PO")
                    .districtCode("57")
                    .sectorCode("0")
                    .unitCode("DE")
                    .build())
            .type(AddressType.UKPOST)
            .build();

    final Party party = buildPartyWithPostalAddressUsages(Collections.singletonList(firstAddress));

    PostalAddressResponse expectedResponse =
        PostalAddressResponse.builder()
            .addressLines(Arrays.asList(ADDRESS_LINE_1, ADDRESS_LINE_2, ADDRESS_LINE_3))
            .country("UK")
            .postCode("P0570DE")
            .type("CORR")
            .pendingUpdate(true)
            .build();

    when(pendingDetailsService.buildPostalAddressResponse(party, firstAddress, CORR_TYPE))
        .thenReturn(expectedResponse);

    final List<PostalAddressResponse> response = testSubject.postalAddresses(party);

    assertThat(response.stream().findFirst().get(), samePropertyValuesAs(expectedResponse));
  }

  @Test
  void postalAddressWithDuplicateEntriesForSourceTypeReturnLatestBasedOnCreationDate() {

    List<AddressUsage> addresses =
        Arrays.asList(
            AddressUsage.builder()
                .postalAddress(
                    PostalAddress.builder()
                        .line1(ADDRESS_LINE_1)
                        .line2(ADDRESS_LINE_2)
                        .line3(ADDRESS_LINE_3)
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("PO")
                                .districtCode("57")
                                .sectorCode("0")
                                .unitCode("DE")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressFunction.CORR)
                .createdDate(NOW.minusSeconds(1L))
                .build(),
            AddressUsage.builder()
                .postalAddress(
                    PostalAddress.builder()
                        .line1("AddressLine1_Recent")
                        .line2("AddressLine2_Recent")
                        .line3("AddressLine3_Recent")
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("PO")
                                .districtCode("57")
                                .sectorCode("0")
                                .unitCode("DE")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .createdDate(NOW)
                .function(AddressFunction.CORR)
                .build(),
            AddressUsage.builder()
                .postalAddress(
                    PostalAddress.builder()
                        .line1(ADDRESS_LINE_1)
                        .line2(ADDRESS_LINE_2)
                        .line3(ADDRESS_LINE_3)
                        .country(Country.builder().code("UK").isoCode("GB").build())
                        .postCode(
                            PostCode.builder()
                                .areaCode("LE")
                                .districtCode("57")
                                .sectorCode("0")
                                .unitCode("DE")
                                .build())
                        .type(AddressType.UKPOST)
                        .build())
                .function(AddressFunction.CORR)
                .createdDate(NOW.minusSeconds(2L))
                .build());

    Party party = buildParty();
    party.setAddresses(addresses);

    PostalAddressResponse expected =
        PostalAddressResponse.builder()
            .addressLines(
                Arrays.asList("AddressLine1_Recent", "AddressLine2_Recent", "AddressLine3_Recent"))
            .country("UK")
            .postCode("P0570DE")
            .type("CORR")
            .pendingUpdate(false)
            .build();

    when(pendingDetailsService.buildPostalAddressResponse(
            party, party.getAddresses().get(0).getPostalAddress(), CORR_TYPE))
        .thenReturn(expected);

    final List<PostalAddressResponse> mapped = testSubject.postalAddresses(party);

    assertThat(mapped, hasSize(1));
    assertThat(mapped.get(0), samePropertyValuesAs(expected));
  }

  @ParameterizedTest
  @MethodSource("partyWithNoPostalAddress")
  void postalAddressShouldReturnEmptyListIfNoPostalAddresses(final Party party) {
    final List<PostalAddressResponse> mapped = testSubject.postalAddresses(party);

    assertThat(mapped, is(emptyCollectionOf(PostalAddressResponse.class)));
  }

  private static Stream<Arguments> partyWithNoPostalAddress() {
    return Stream.of(
        Arguments.of(
            buildPartyWithNonPostalAddressUsages(
                Collections.singletonList(buildNonPostalAddress(AddressType.TEL, "0750303434"))),
            buildPartyWithNonPostalAddressUsages(
                Collections.singletonList(buildNonPostalAddress(AddressType.FAX, "fax"))),
            buildPartyWithNonPostalAddressUsages(
                Collections.singletonList(buildNonPostalAddress(AddressType.BFPO, "BFPO")))));
  }

  private static PartyType buildPartyType() {
    return PartyType.builder().code("PERSON").type("PERSON").startDate(YESTERDAY).build();
  }

  private static NonPostalAddress buildNonPostalAddress(
      final AddressType type, final String address) {
    return NonPostalAddress.builder().type(type).address(address).build();
  }

  private static Party buildParty() {
    return Party.builder().sysId(1L).partyType(buildPartyType()).build();
  }

  public static Party buildPartyWithPostalAddressUsages(final List<PostalAddress> addresses) {

    Party party = buildParty();
    List<AddressUsage> au = new ArrayList<>();
    addresses.forEach(
        address -> {
          au.add(
              AddressUsage.builder()
                  .postalAddress(address)
                  .function(AddressUsage.AddressFunction.CORR)
                  .startDate(YESTERDAY)
                  .createdDate(YESTERDAY)
                  .preferredContactMethod(true)
                  .build());
        });
    party.setAddresses(au);
    return party;
  }

  public static Party buildPartyWithNonPostalAddressUsages(
      final List<NonPostalAddress> nonPostalAddresses) {

    Party party = buildParty();
    List<AddressUsage> au = new ArrayList<>();
    nonPostalAddresses.forEach(
        npa -> {
          au.add(
              AddressUsage.builder()
                  .nonPostalAddress(npa)
                  .function(AddressUsage.AddressFunction.DIRCOM)
                  .startDate(YESTERDAY)
                  .createdDate(YESTERDAY)
                  .preferredContactMethod(true)
                  .build());
        });
    party.setAddresses(au);
    return party;
  }
}
