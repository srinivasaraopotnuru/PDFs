package uk.co.ybs.digital.customer.repository.adgcore;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.customer.model.adgcore.AreaDiallingCode;
import uk.co.ybs.digital.customer.model.adgcore.AreaDiallingCodePK;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class AreaDiallingCodesRepositoryTest {

  @Autowired private AreaDiallingCodesRepository areaDiallingCodesRepository;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  public static final LocalDateTime YESTERDAY = LocalDateTime.now().minusDays(1);
  public static final String MOBILE = "MOBILE";

  @BeforeEach
  public void setUp() {
    adgCoreTestEntityManager.persistAndFlush(areaDiallingCode("UK", "113", "LEEDS", null, 7));
    adgCoreTestEntityManager.persistAndFlush(areaDiallingCode("UK", "7848", MOBILE, null, 6));
    adgCoreTestEntityManager.persistAndFlush(areaDiallingCode("UK1", "7847", MOBILE, null, 6));

    adgCoreTestEntityManager.persistAndFlush(
        areaDiallingCode("UK", "1362", "DEREHAM", YESTERDAY, 6));
    adgCoreTestEntityManager.persistAndFlush(
        areaDiallingCode("UK2", "7846", MOBILE, LocalDateTime.now(), 6));
  }

  @ParameterizedTest
  @MethodSource("validPhoneNumberArgs")
  public void testFindAreaDiallingCodeForPhoneNumberSuccess(
      final String countryCode, final int areaCode, final String phoneNumber) {
    Optional<Integer> result =
        areaDiallingCodesRepository.findAreaDiallingCodeForPhoneNumber(countryCode, phoneNumber);

    assertThat(result.isPresent(), is(true));

    assertThat(result.get(), is(areaCode));
  }

  @ParameterizedTest
  @MethodSource("invalidPhoneNumberArgs")
  public void testFindAreaDiallingCodeForPhoneNumberFailure(
      final String countryCode, final String phoneNumber) {
    Optional<Integer> result =
        areaDiallingCodesRepository.findAreaDiallingCodeForPhoneNumber(countryCode, phoneNumber);

    assertThat(result.isPresent(), is(false));
  }

  @Test
  public void testFindByIdReturnsEntry() {
    Optional<AreaDiallingCode> actual =
        areaDiallingCodesRepository.findById(new AreaDiallingCodePK("UK", 7848)); // NOPMD

    assertThat(actual.isPresent(), is(true));

    assertThat(
        actual.get(),
        allOf(
            hasProperty(
                "id",
                allOf(hasProperty("cntryCode", equalTo("UK")), hasProperty("code", equalTo(7848)))),
            hasProperty("name", equalTo(MOBILE)),
            hasProperty("lengthOfLocalNo", equalTo(6)),
            hasProperty("startDate", is(notNullValue())),
            hasProperty("updateId", equalTo("TestID")),
            hasProperty("endDate", equalTo(null)),
            hasProperty("updateTime", is(notNullValue()))));
  }

  @Test
  public void testFindByIdReturnsNotPresent() {
    Optional<AreaDiallingCode> actual =
        areaDiallingCodesRepository.findById(new AreaDiallingCodePK("UK", 1111)); // NOPMD

    assertThat(actual.isPresent(), is(false));
  }

  private static Stream<Arguments> validPhoneNumberArgs() {
    // countryCode, areaCode, phoneNumber
    return Stream.of(
        Arguments.of("UK", 1234, "1234123456"),
        Arguments.of("UK", 1234, "1234123456"),
        Arguments.of("UK", 113, "1138057787"),
        Arguments.of("UK1", 7847, "7847057787"));
  }

  private static Stream<Arguments> invalidPhoneNumberArgs() {
    // countryCode, phoneNumber
    return Stream.of(
        Arguments.of("NZ", "1234123456"),
        Arguments.of("UK", "6668057787"),
        Arguments.of("UK", "1362057787"),
        Arguments.of("UK", "11320577878"),
        Arguments.of("UK", "13620577878"),
        Arguments.of("UK", "113205778"),
        Arguments.of("UK", "136205778"));
  }

  private static AreaDiallingCode areaDiallingCode(
      final String countryCode,
      final String areaCode,
      final String name,
      final LocalDateTime endDate,
      final Integer lengthOfLocalNo) {

    AreaDiallingCodePK areaDiallingCodePK =
        AreaDiallingCodePK.builder()
            .cntryCode(countryCode)
            .code(Integer.parseInt(areaCode))
            .build();

    return AreaDiallingCode.builder()
        .id(areaDiallingCodePK)
        .name(name)
        .startDate(LocalDateTime.now())
        .updateId("TestID")
        .updateTime(LocalDateTime.now())
        .lengthOfLocalNo(lengthOfLocalNo)
        .endDate(endDate)
        .build();
  }
}
