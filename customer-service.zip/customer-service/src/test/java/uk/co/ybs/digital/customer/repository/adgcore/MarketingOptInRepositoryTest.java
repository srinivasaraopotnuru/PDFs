package uk.co.ybs.digital.customer.repository.adgcore;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn;
import uk.co.ybs.digital.customer.model.adgcore.MarketingOptIn.MarketingOptInCode;
import uk.co.ybs.digital.customer.repository.YbsDataJpaTest;

@YbsDataJpaTest
class MarketingOptInRepositoryTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-09-01T10:15:30");
  private static final LocalDateTime YESTERDAY = LocalDateTime.parse("2020-08-31T23:59:59");
  private static final LocalDateTime LAST_WEEK = LocalDateTime.parse("2020-08-24T23:59:59");
  private static final String CREATED_BY_ADG = "DEFAULTDC";

  private static final String SYS_ID = "sysId";
  private static final String PARTY_ID = "partyId";
  private static final String CODE = "code";
  private static final String STATUS = "status";
  private static final String START_DATE = "startDate";
  private static final String END_DATE = "endDate";
  private static final String CREATED_BY = "createdBy";

  @Autowired MarketingOptInRepository marketingOptInRepository;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @Autowired TransactionTemplate transactionTemplate;

  @BeforeEach
  public void setUp() {
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(1L, 1L, MarketingOptInCode.ADDR, true, YESTERDAY, null, CREATED_BY_ADG));
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(2L, 1L, MarketingOptInCode.TEL, false, YESTERDAY, null, CREATED_BY_ADG));
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(3L, 1L, MarketingOptInCode.EMAIL, null, YESTERDAY, null, CREATED_BY_ADG));
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(4L, 1L, MarketingOptInCode.AGMEML, true, YESTERDAY, null, CREATED_BY_ADG));
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(5L, 1L, MarketingOptInCode.ANSTMT, true, YESTERDAY, null, CREATED_BY_ADG));
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(6L, 1L, MarketingOptInCode.FAX, true, YESTERDAY, null, CREATED_BY_ADG));
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(7L, 1L, MarketingOptInCode.THRDPY, true, YESTERDAY, null, CREATED_BY_ADG));
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(8L, 2L, MarketingOptInCode.ADDR, true, YESTERDAY, null, CREATED_BY_ADG));
    adgCoreTestEntityManager.persistAndFlush(
        marketingOptIn(
            9L, 1L, MarketingOptInCode.ADDR, true, LAST_WEEK, YESTERDAY, CREATED_BY_ADG));
  }

  @Test
  void findById() {

    final Optional<MarketingOptIn> actual = marketingOptInRepository.findById(1L);

    assertThat(actual.isPresent(), is(true));

    assertThat(
        actual.get(),
        allOf(
            hasProperty(SYS_ID, equalTo(1L)),
            hasProperty(PARTY_ID, equalTo(1L)),
            hasProperty(CODE, equalTo(MarketingOptInCode.ADDR)),
            hasProperty(STATUS, equalTo(true)),
            hasProperty(START_DATE, equalTo(YESTERDAY)),
            hasProperty(END_DATE, equalTo(null)),
            hasProperty(CREATED_BY, equalTo(CREATED_BY_ADG))));
  }

  @Test
  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  void findMarketingOptInByParty() {

    final List<MarketingOptIn> actual = marketingOptInRepository.findMarketingOptInByParty(1L, NOW);

    assertThat(
        actual,
        contains(
            allOf(
                hasProperty(SYS_ID, equalTo(1L)),
                hasProperty(PARTY_ID, equalTo(1L)),
                hasProperty(CODE, equalTo(MarketingOptInCode.ADDR)),
                hasProperty(STATUS, equalTo(true)),
                hasProperty(START_DATE, equalTo(YESTERDAY)),
                hasProperty(END_DATE, equalTo(null)),
                hasProperty(CREATED_BY, equalTo(CREATED_BY_ADG))),
            allOf(
                hasProperty(SYS_ID, equalTo(2L)),
                hasProperty(PARTY_ID, equalTo(1L)),
                hasProperty(CODE, equalTo(MarketingOptInCode.TEL)),
                hasProperty(STATUS, equalTo(false)),
                hasProperty(START_DATE, equalTo(YESTERDAY)),
                hasProperty(END_DATE, equalTo(null)),
                hasProperty(CREATED_BY, equalTo(CREATED_BY_ADG))),
            allOf(
                hasProperty(SYS_ID, equalTo(3L)),
                hasProperty(PARTY_ID, equalTo(1L)),
                hasProperty(CODE, equalTo(MarketingOptInCode.EMAIL)),
                hasProperty(STATUS, equalTo(null)),
                hasProperty(START_DATE, equalTo(YESTERDAY)),
                hasProperty(END_DATE, equalTo(null)),
                hasProperty(CREATED_BY, equalTo(CREATED_BY_ADG))),
            allOf(
                hasProperty(SYS_ID, equalTo(4L)),
                hasProperty(PARTY_ID, equalTo(1L)),
                hasProperty(CODE, equalTo(MarketingOptInCode.AGMEML)),
                hasProperty(STATUS, equalTo(true)),
                hasProperty(START_DATE, equalTo(YESTERDAY)),
                hasProperty(END_DATE, equalTo(null)),
                hasProperty(CREATED_BY, equalTo(CREATED_BY_ADG)))));
  }

  @Test
  void findMarketingOptInByPartyAndCodes() {

    final List<MarketingOptIn> actual =
        marketingOptInRepository.findMarketingOptInByPartyAndCodes(
            1L, EnumSet.of(MarketingOptInCode.THRDPY), NOW);

    assertThat(
        actual,
        contains(
            allOf(
                hasProperty(SYS_ID, equalTo(7L)),
                hasProperty(PARTY_ID, equalTo(1L)),
                hasProperty(CODE, equalTo(MarketingOptInCode.THRDPY)),
                hasProperty(STATUS, equalTo(true)),
                hasProperty(START_DATE, equalTo(YESTERDAY)),
                hasProperty(END_DATE, equalTo(null)),
                hasProperty(CREATED_BY, equalTo(CREATED_BY_ADG)))));
  }

  @ParameterizedTest(name = "findMarketingOptInByPartyHistoric: {0}")
  @CsvSource({"2020-08-24T23:59:59", "2020-08-31T23:59:58"})
  void findMarketingOptInByPartyHistoric(final LocalDateTime now) {

    final List<MarketingOptIn> actual = marketingOptInRepository.findMarketingOptInByParty(1L, now);

    assertThat(
        actual,
        contains(
            allOf(
                hasProperty(SYS_ID, equalTo(9L)),
                hasProperty(PARTY_ID, equalTo(1L)),
                hasProperty(CODE, equalTo(MarketingOptInCode.ADDR)),
                hasProperty(STATUS, equalTo(true)),
                hasProperty(START_DATE, equalTo(LAST_WEEK)),
                hasProperty(END_DATE, equalTo(YESTERDAY)),
                hasProperty(CREATED_BY, equalTo(CREATED_BY_ADG)))));
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private static MarketingOptIn marketingOptIn(
      final Long sysId,
      final Long partySysId,
      final MarketingOptInCode code,
      final Boolean status,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final String createdBy) {
    return MarketingOptIn.builder()
        .sysId(sysId)
        .partyId(partySysId)
        .code(code)
        .status(status)
        .startDate(startDate)
        .endDate(endDate)
        .createdBy(createdBy)
        .build();
  }
}
