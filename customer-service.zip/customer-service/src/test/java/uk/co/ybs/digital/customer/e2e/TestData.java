package uk.co.ybs.digital.customer.e2e;

import java.time.LocalDateTime;

public class TestData {
  public static final Long PARTY_ID = 123456L;
  public static final String CUSTOMER_LDAP_PERSON_UID_VALID = "0000123456";
  public static final long PARTY_ID_NOT_ON_LDAP = 123L;
  public static final String CUSTOMER_LDAP_PERSON_UID_NOT_ON_LDAP = "0000000123";
  public static final String CREATED_AT = "0795";
  public static final String CREATED_BY = "SAPP";
  public static final LocalDateTime PARTY_CREATED_DATE = LocalDateTime.parse("2020-05-26T14:45:01");
  public static final String EMAIL_ADDRESS = "john.smith@gmail.com";
  public static final String HOME_ADDRESS = "012344207138";
  public static final String WORK_ADDRESS = "012344216932";
  public static final String MOBILE_ADDRESS = "07515059347";
}
