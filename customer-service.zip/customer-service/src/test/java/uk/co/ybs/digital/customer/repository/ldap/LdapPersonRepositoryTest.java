package uk.co.ybs.digital.customer.repository.ldap;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.time.Instant;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.ldap.DataLdapTest;
import org.springframework.ldap.support.LdapUtils;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import uk.co.ybs.digital.customer.model.ldap.LdapPerson;
import uk.co.ybs.digital.customer.utils.TestHelper;

@RunWith(SpringRunner.class)
@DataLdapTest(properties = {"spring.ldap.urls="})
@ActiveProfiles({"test", "text-logging"})
class LdapPersonRepositoryTest {

  @Autowired private LdapPersonRepository ldapPersonRepository;

  @Test
  void shouldRetrieveLdapPersonForUid() {
    final LdapPerson expected = TestHelper.buildLdapPerson();

    final Optional<LdapPerson> result = ldapPersonRepository.findByUid("0000123456");
    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), is(expected));
  }

  @Test
  void shouldRetrieveLdapPersonForUidInvalidPasswordState() {
    final LdapPerson expected =
        LdapPerson.builder()
            .id(LdapUtils.newLdapName("uid=0000223456,ou=People,o=ybs.co.uk,dc=ybs,dc=co,dc=uk"))
            .accessTime(Instant.parse("2019-04-02T10:21:41.894Z"))
            .uid("0000223456")
            .groups(Collections.singletonList("direct"))
            .passwordState("PWD_MANUALCREATE")
            .customerNumber("0000223456")
            .emailAddress("test2@ybs.co.uk")
            .build();

    final Optional<LdapPerson> result = ldapPersonRepository.findByUid("0000223456");
    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), is(expected));
  }

  @Test
  void shouldNotRetrieveLdapPersonForNonExistentUid() {
    final Optional<LdapPerson> result = ldapPersonRepository.findByUid("0000923456");
    assertThat(result.isPresent(), is(false));
  }

  @Test
  void shouldUpdateLdapPersonForUid() {
    final LdapPerson toSave =
        TestHelper.buildLdapPerson().toBuilder().emailAddress("updated@provider.com").build();

    ldapPersonRepository.save(toSave);

    final Optional<LdapPerson> result = ldapPersonRepository.findByUid("0000123456");
    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), is(toSave));
  }
}
