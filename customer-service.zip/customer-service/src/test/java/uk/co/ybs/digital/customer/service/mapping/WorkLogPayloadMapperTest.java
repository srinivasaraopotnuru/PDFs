package uk.co.ybs.digital.customer.service.mapping;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.digitalcustomer.DeletePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePhoneRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.UpdatePostalAddressRequest;
import uk.co.ybs.digital.customer.model.digitalcustomer.WorkLogPayload;
import uk.co.ybs.digital.customer.service.AreaDiallingCodesService;
import uk.co.ybs.digital.customer.web.dto.PafData;
import uk.co.ybs.digital.customer.web.dto.PermittedCountries;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic;
import uk.co.ybs.digital.customer.web.dto.PhoneNumberBasic.PhoneNumberBasicType;
import uk.co.ybs.digital.customer.web.dto.PostalAddress;
import uk.co.ybs.digital.customer.web.dto.PostalAddressRequest;

@ExtendWith(MockitoExtension.class)
public class WorkLogPayloadMapperTest {

  @Mock private AreaDiallingCodesService areaDiallingCodesService;

  @InjectMocks private WorkLogPayloadMapper testSubject;

  private static final PostalAddress.PostalAddressType ADDRESS_FUNCTION =
      PostalAddress.PostalAddressType.CORR;
  private static final PostalAddress.PostalAddressSubType ADDRESS_TYPE =
      PostalAddress.PostalAddressSubType.UKPOST;
  private static final String ADDRESS_LINE_1 = "Address Line 1";
  private static final String ADDRESS_LINE_2 = "Address Line 2";
  private static final String ADDRESS_LINE_3 = "Address Line 3";
  private static final String ADDRESS_LINE_4 = "Address Line 4";
  private static final String ADDRESS_LINE_5 = "Address Line 5";
  private static final PermittedCountries COUNTRY = PermittedCountries.UNITED_KINGDOM;
  private static final String POSTCODE = "ls1 6pt";
  private static final String AREA_CODE = "LS";
  private static final String DISTRICT_CODE = "1";
  private static final String SECTOR_CODE = "6";
  private static final String UNIT_CODE = "PT";
  private static final Integer PAF_KEY = 12345678;
  private static final String PAF_DPS = "1TA";
  private static final Locale LOCALE = Locale.ROOT;

  @Test
  void mapsPostalAddressWithPafAndLessAddressLinesUpdate() {

    PostalAddressRequest postalAddressRequest = buildPostalAddressRequestPayload(true, false);

    final WorkLogPayload mapped = testSubject.map(postalAddressRequest);

    assertThat(mapped instanceof UpdatePostalAddressRequest, is(true));

    UpdatePostalAddressRequest update = (UpdatePostalAddressRequest) mapped;

    assertEquals(ADDRESS_FUNCTION, update.getFunction());
    assertEquals(ADDRESS_TYPE, update.getAddressType());
    assertEquals(ADDRESS_LINE_1.toUpperCase(LOCALE), update.getAddressLine1());
    assertEquals(ADDRESS_LINE_2.toUpperCase(LOCALE), update.getAddressLine2());
    assertEquals(COUNTRY.getCode(), update.getCountry());
    assertEquals(AREA_CODE, update.getAreaCode());
    assertEquals(DISTRICT_CODE, update.getDistrictCode());
    assertEquals(SECTOR_CODE, update.getSectorCode());
    assertEquals(UNIT_CODE, update.getUnitCode());
    assertEquals(PAF_KEY, update.getPafAddressKey());
    assertEquals("1T", update.getPafDeliveryPointSuffix());
  }

  @Test
  @SuppressWarnings("PMD.UnnecessaryCaseChange")
  void mapsPostalAddressWithPafAndMaxAddressLinesUpdate() {

    PostalAddressRequest postalAddressRequest = buildPostalAddressRequestPayload(true, true);

    final WorkLogPayload mapped = testSubject.map(postalAddressRequest);

    assertThat(mapped instanceof UpdatePostalAddressRequest, is(true));

    UpdatePostalAddressRequest update = (UpdatePostalAddressRequest) mapped;

    assertEquals(ADDRESS_FUNCTION, update.getFunction());
    assertEquals(ADDRESS_TYPE, update.getAddressType());
    assertEquals(ADDRESS_LINE_1.toUpperCase(LOCALE), update.getAddressLine1());
    assertEquals(ADDRESS_LINE_2.toUpperCase(LOCALE), update.getAddressLine2());
    assertEquals(ADDRESS_LINE_3.toUpperCase(LOCALE), update.getAddressLine3());
    assertEquals(ADDRESS_LINE_4.toUpperCase(LOCALE), update.getAddressLine4());
    assertEquals(ADDRESS_LINE_5.toUpperCase(LOCALE), update.getAddressLine5());
    assertEquals(COUNTRY.getCode(), update.getCountry());
    assertEquals(AREA_CODE, update.getAreaCode());
    assertEquals(DISTRICT_CODE, update.getDistrictCode());
    assertEquals(SECTOR_CODE, update.getSectorCode());
    assertEquals(UNIT_CODE, update.getUnitCode());
    assertEquals(PAF_KEY, update.getPafAddressKey());
    assertEquals("1T", update.getPafDeliveryPointSuffix());
  }

  @Test
  @SuppressWarnings("PMD.UnnecessaryCaseChange")
  void mapsPostalAddressWithOutPafAndLessAddressLinesUpdate() {

    PostalAddressRequest postalAddressRequest = buildPostalAddressRequestPayload(false, false);

    final WorkLogPayload mapped = testSubject.map(postalAddressRequest);

    assertThat(mapped instanceof UpdatePostalAddressRequest, is(true));

    UpdatePostalAddressRequest update = (UpdatePostalAddressRequest) mapped;

    assertEquals(ADDRESS_FUNCTION, update.getFunction());
    assertEquals(ADDRESS_TYPE, update.getAddressType());
    assertEquals(ADDRESS_LINE_1.toUpperCase(LOCALE), update.getAddressLine1());
    assertEquals(ADDRESS_LINE_2.toUpperCase(LOCALE), update.getAddressLine2());
    assertEquals(COUNTRY.getCode(), update.getCountry());
    assertEquals(AREA_CODE, update.getAreaCode());
    assertEquals(DISTRICT_CODE, update.getDistrictCode());
    assertEquals(SECTOR_CODE, update.getSectorCode());
    assertEquals(UNIT_CODE, update.getUnitCode());
  }

  @Test
  @SuppressWarnings("PMD.UnnecessaryCaseChange")
  void mapsPostalAddressWithOutPafAndMaxAddressLinesUpdate() {

    PostalAddressRequest postalAddressRequest = buildPostalAddressRequestPayload(false, true);

    final WorkLogPayload mapped = testSubject.map(postalAddressRequest);

    assertThat(mapped instanceof UpdatePostalAddressRequest, is(true));

    UpdatePostalAddressRequest update = (UpdatePostalAddressRequest) mapped;

    assertEquals(ADDRESS_FUNCTION, update.getFunction());
    assertEquals(ADDRESS_TYPE, update.getAddressType());
    assertEquals(ADDRESS_LINE_1.toUpperCase(LOCALE), update.getAddressLine1());
    assertEquals(ADDRESS_LINE_2.toUpperCase(LOCALE), update.getAddressLine2());
    assertEquals(ADDRESS_LINE_3.toUpperCase(LOCALE), update.getAddressLine3());
    assertEquals(ADDRESS_LINE_4.toUpperCase(LOCALE), update.getAddressLine4());
    assertEquals(ADDRESS_LINE_5.toUpperCase(LOCALE), update.getAddressLine5());
    assertEquals(COUNTRY.getCode(), update.getCountry());
    assertEquals(AREA_CODE, update.getAreaCode());
    assertEquals(DISTRICT_CODE, update.getDistrictCode());
    assertEquals(SECTOR_CODE, update.getSectorCode());
    assertEquals(UNIT_CODE, update.getUnitCode());
  }

  @Test
  void mapsPhoneNumberDelete() {
    PhoneNumberBasic phoneNumber =
        PhoneNumberBasic.builder().type(PhoneNumberBasicType.HOME).number(null).build();

    final WorkLogPayload mapped = testSubject.map(phoneNumber);

    assertThat(mapped instanceof DeletePhoneRequest, is(true));

    DeletePhoneRequest delete = (DeletePhoneRequest) mapped;

    assertThat(delete.getRequestType() == PhoneNumberRequestType.HOME, is(true));
  }

  @ParameterizedTest
  @MethodSource("providePhoneNumbersArgs")
  void mapsPhoneNumberUpdate(
      final PhoneNumberBasicType basicType,
      final PhoneNumberRequestType type,
      final String number,
      final String formattedNumber,
      final Optional<Integer> areaCode,
      final boolean landLine) {

    PhoneNumberBasic phoneNumber =
        PhoneNumberBasic.builder().type(basicType).number(number).build();

    if (landLine) {
      when(areaDiallingCodesService.determineAreaDiallingCode(any())).thenReturn(areaCode);
    }

    final WorkLogPayload mapped = testSubject.map(phoneNumber);

    assertThat(mapped instanceof UpdatePhoneRequest, is(true));

    UpdatePhoneRequest update = (UpdatePhoneRequest) mapped;

    assertThat(update.getRequestType() == type, is(true));
    assertThat(update.getNumber(), is(formattedNumber));
    assertThat(update.getAreaDiallingCode(), is(areaCode.orElse(null)));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> providePhoneNumbersArgs() {
    return Stream.of(
        Arguments.of(
            PhoneNumberBasicType.HOME,
            PhoneNumberRequestType.HOME,
            "01234 123457",
            "123457",
            Optional.of(1234),
            true),
        Arguments.of(
            PhoneNumberBasicType.HOME,
            PhoneNumberRequestType.HOME,
            "+44 1234 123457",
            "123457",
            Optional.of(1234),
            true),
        Arguments.of(
            PhoneNumberBasicType.MOBILE,
            PhoneNumberRequestType.MOBILE,
            "07525 123457",
            "07525123457",
            Optional.empty(),
            false),
        Arguments.of(
            PhoneNumberBasicType.MOBILE,
            PhoneNumberRequestType.MOBILE,
            "07525 123457",
            "07525123457",
            Optional.empty(),
            false),
        Arguments.of(
            PhoneNumberBasicType.WORK,
            PhoneNumberRequestType.WORK,
            "01234 123457",
            "123457",
            Optional.of(1234),
            true),
        Arguments.of(
            PhoneNumberBasicType.WORK,
            PhoneNumberRequestType.WORK,
            "+44 1234 123457",
            "123457",
            Optional.of(1234),
            true),
        Arguments.of(
            PhoneNumberBasicType.WORK,
            PhoneNumberRequestType.WORK,
            "07525 123457",
            "07525123457",
            Optional.empty(),
            false));
  }

  private static PostalAddressRequest buildPostalAddressRequestPayload(
      final boolean includePaf, final boolean maxAddressLines) {
    if (includePaf) {
      return PostalAddressRequest.builder()
          .address(buildPostalAddress(maxAddressLines))
          .paf(buildPafData())
          .build();
    } else {
      return PostalAddressRequest.builder().address(buildPostalAddress(maxAddressLines)).build();
    }
  }

  private static PostalAddress buildPostalAddress(final boolean maxAddressLines) {

    if (maxAddressLines) {
      return PostalAddress.builder()
          .type(ADDRESS_FUNCTION)
          .subType(ADDRESS_TYPE)
          .addressLines(Collections.singleton(ADDRESS_LINE_1))
          .addressLines(Collections.singleton(ADDRESS_LINE_2))
          .addressLines(Collections.singleton(ADDRESS_LINE_3))
          .addressLines(Collections.singleton(ADDRESS_LINE_4))
          .addressLines(Collections.singleton(ADDRESS_LINE_5))
          .postCode(POSTCODE)
          .country(COUNTRY)
          .build();
    } else {
      return PostalAddress.builder()
          .type(ADDRESS_FUNCTION)
          .subType(ADDRESS_TYPE)
          .addressLines(Collections.singleton(ADDRESS_LINE_1))
          .addressLines(Collections.singleton(ADDRESS_LINE_2))
          .postCode(POSTCODE)
          .country(COUNTRY)
          .build();
    }
  }

  private static PafData buildPafData() {
    return PafData.builder().addressKey(PAF_KEY).deliveryPointSuffix(PAF_DPS).build();
  }
}
