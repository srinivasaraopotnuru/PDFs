package uk.co.ybs.digital.customer.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.customer.model.core.NonPostalAddress;
import uk.co.ybs.digital.customer.model.core.Party;
import uk.co.ybs.digital.customer.model.digitalcustomer.PhoneNumberRequestType;
import uk.co.ybs.digital.customer.utils.TestHelper;
import uk.co.ybs.digital.customer.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class UpdatePhoneNumberRequestTest {

  @Mock private UpdatePhoneNumberProcessor updatePhoneNumberProcessor;

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments")
  void resolveShouldReturnResolvedUpdatePhoneNumberRequest(
      final NonPostalAddress nonPostalAddress) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final UpdatePhoneNumberRequestArguments arguments =
        UpdatePhoneNumberRequestArguments.builder()
            .partyId(123456)
            .requestMetadata(requestMetadata)
            .processTime(LocalDateTime.parse("2020-05-26T14:45:01"))
            .phoneNumberRequestType(
                PhoneNumberRequestType.valueOf(nonPostalAddress.getSourceType().toString()))
            .adcCode(nonPostalAddress.getAdcCode())
            .number(nonPostalAddress.getAddress())
            .build();

    final Party party =
        TestHelper.buildPartyWithNonPostalAddressUsages(
            Collections.singletonList(nonPostalAddress));

    final UpdatePhoneNumberRequest testSubject =
        new UpdatePhoneNumberRequest(arguments, updatePhoneNumberProcessor);

    when(updatePhoneNumberProcessor.resolve(arguments)).thenReturn(party);

    final ResolvedCustomerRequest resolved = testSubject.resolve();
    assertThat(
        resolved,
        is(new ResolvedUpdatePhoneNumberRequest(arguments, updatePhoneNumberProcessor, party)));
  }

  @ParameterizedTest
  @MethodSource("nonPostalAddressArguments")
  void resolveShouldAuditFailure(final NonPostalAddress nonPostalAddress) {
    final RequestMetadata requestMetadata = TestHelper.createRequestMetadata();

    final UpdatePhoneNumberRequestArguments arguments =
        UpdatePhoneNumberRequestArguments.builder()
            .partyId(123456)
            .requestMetadata(requestMetadata)
            .processTime(LocalDateTime.parse("2020-05-26T14:45:01"))
            .phoneNumberRequestType(
                PhoneNumberRequestType.valueOf(nonPostalAddress.getSourceType().toString()))
            .adcCode(nonPostalAddress.getAdcCode())
            .number(nonPostalAddress.getAddress())
            .build();

    final UpdatePhoneNumberRequest testSubject =
        new UpdatePhoneNumberRequest(arguments, updatePhoneNumberProcessor);

    testSubject.auditFailure(TestHelper.TECHNICAL_FAILURE_MESSAGE);

    verify(updatePhoneNumberProcessor)
        .auditFailure(arguments, TestHelper.TECHNICAL_FAILURE_MESSAGE);
  }

  private static Stream<NonPostalAddress> nonPostalAddressArguments() {
    return Stream.of(
        TestHelper.buildHomePhoneNumberRequest(),
        TestHelper.buildMobilePhoneNumberRequest(),
        TestHelper.buildWorkLandlinePhoneNumberRequest(),
        TestHelper.buildWorkMobilePhoneNumberRequest());
  }
}
