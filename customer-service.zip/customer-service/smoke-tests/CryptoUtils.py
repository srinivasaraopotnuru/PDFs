import base64

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.serialization import load_pem_public_key

public_key_str = {
    "customer-service-encryption-key-nonprod-1": """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAt7aAAhl+dKwzMMSxl93q
3Cqrup9m90NxAG1818T0UuXPPwLTIUhTx01cWth0/z9/yvj22mzRxoGoAA/KHR3v
icVxmQDLPY00dej5EbOFr/esRiX6Jw/vb2536cWEg0LPnJoF2FjxQomJyYVDB7ai
Yuwb0MKMRhBQsHdN9GSSWA/PeLbWI/ju8gConwvlwp9yjr8OeBUr0bG9V8uKlu93
BRdzrgWNO48ijAETusLY/OAAZVtLMHUOOH4Oowbk0QKSFZel4kJf23vChq7fVdP/
Q7m5MsOIelQUNJLZsRQuNgHVIJz8xnDLJ2jhKBqaTljDJXA/4aUlRRQ4HSCAKnLb
qQIDAQAB
-----END PUBLIC KEY-----""",
    "encryption-build-client-nonprod-1": """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAowS84DVZytXZpmvm8Ov1
auORMfIDmQNS+OaEnOui6KDrWc0wuTtcIfWWktN8et+6oXmK3jJ6PZyn759DL6ip
ADXusBeZ8AD4BkNCjGwsH8c9ERSJsHcM6vXWfm8HkLIfHjF83XVGOEQQ70sKq/ti
gMJ+eeRwXeo9iLo/zwcA9UVfet80QMi8w2GKdCF42zY5n2ViEzw5g4CwawWwKFLE
hLhHj1kNgWseCy8JUfXAoC+Q1sjQMJM70naLALmrJGeOBbJAymFooRGc0/3JukTx
h5VRzHMZKOwUeTT4Ut8Cw+9sm1XKmqtMyYAGcUJri/Id2t58UhLdE49q86zYBBDp
EwIDAQAB
-----END PUBLIC KEY-----""",
}

private_key_str = {
    "customer-service-encryption-key-nonprod-1": """-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEAt7aAAhl+dKwzMMSxl93q3Cqrup9m90NxAG1818T0UuXPPwLT
IUhTx01cWth0/z9/yvj22mzRxoGoAA/KHR3vicVxmQDLPY00dej5EbOFr/esRiX6
Jw/vb2536cWEg0LPnJoF2FjxQomJyYVDB7aiYuwb0MKMRhBQsHdN9GSSWA/PeLbW
I/ju8gConwvlwp9yjr8OeBUr0bG9V8uKlu93BRdzrgWNO48ijAETusLY/OAAZVtL
MHUOOH4Oowbk0QKSFZel4kJf23vChq7fVdP/Q7m5MsOIelQUNJLZsRQuNgHVIJz8
xnDLJ2jhKBqaTljDJXA/4aUlRRQ4HSCAKnLbqQIDAQABAoIBAQCL3YbRkmVDIIMM
owNuUsbm/hmmSIuUvqS+pZzBjTJSFqJVH6psEWuvNceVZmyUk9yQREF0BBslnTqx
aVQAHPVsl4Sn7wHNB78j8c4GWv3x/YcMFQfBS5GH7bufoAAGCwyS9nRyxSxQ8vOT
GEDzE2nIFGgM5MD06qDz6LDR2uvL3FtpjwUMdcXoS3ak3D/rUIQNjaUyV4K1NqkM
F/8SMaPXkwnMr4rNeDidcE78bf1TmyKq0oZzrEmYwOWfTolW4GxBg54pV8Qgo2qT
YJ1FtRlfO0xALZ2inzvBIomjtKmkCv7D0CPm2h6Esluuj9BNrtxWaS2JSrRl5ha4
f4ZC51HdAoGBANnCYLWKO6V/egILy6C60CaJcO2w3AehK7OBqEzfLmzgJrf5Ktej
MuFlZBcQclsI0aWmFMOTmPUL/0/pq8hDoyQEJDkkibhlUnSgCcOgsUR3sFxx/MsD
OPts8q0fz9Gf1237nfpy9ll7TBNaP1HYbznHgXIh69wyAqhkl2GCB5KjAoGBANf5
ht8pAcaWLDX5OxqlvOa35hPEQlXgnCFU4LmRjpK5c4UXPYU7f5RWe9cJm8Gv0Hx3
gqfnocKSPa9TVwOMQBcrJs2uoc89BwJUsaefRDKC/c4qlsdQrADaZH578SYj66je
57Th2M/+BqW1IPrtSgVMpQSv1SBqRhzdjYsxLUlDAoGAF1178v66F6/t73pEhyKE
Yx4sN9TaRxdMER7AaD8qRBRpEyRxLGIee4DdlHv3ST1RAW0onTOhHeoDoxd3jy1y
u9KV8GuzO03j4w+o/IypeKc/DSxN65qU6qVuBJV9PwjfnLV65fyf4koQh6MPWEDY
7mIxyYVKQX48OsVQWO4S0fECgYEAlpAmLjzwN/lJKPdu9MzGPDHH+8++TxAeyD3b
zIJk2nTey9G/2bn43vjLrMXOB+EBf0PxmgwpAPPifO+koZyMsZormwg7VbY9xKo2
j5zAdlZLiga2xoy+3HljxamyG9y+1SNQdRFdjOKSz8LOEyCJkdg00meiNM7hwg3S
N085OvECgYEAkWAkMKQ/X1qRZ/YCN6jxahPY8bNhSOYZiJUUWMIdfgIFfejE+ud7
BEhZW8oOUTGUomWW2dSOvjXTEdVoBRU64FdQerbKTN9gTdsHR6Mkik9GMe1Sqfax
y4Vr9Pa9/35HgxPjgTQK/QXiKssFjwzOFXtP7gB6u4VUPUgw6X31ROQ=
-----END RSA PRIVATE KEY-----""",
    "encryption-build-client-nonprod-1": """-----BEGIN RSA PRIVATE KEY-----
MIIEowIBAAKCAQEAowS84DVZytXZpmvm8Ov1auORMfIDmQNS+OaEnOui6KDrWc0w
uTtcIfWWktN8et+6oXmK3jJ6PZyn759DL6ipADXusBeZ8AD4BkNCjGwsH8c9ERSJ
sHcM6vXWfm8HkLIfHjF83XVGOEQQ70sKq/tigMJ+eeRwXeo9iLo/zwcA9UVfet80
QMi8w2GKdCF42zY5n2ViEzw5g4CwawWwKFLEhLhHj1kNgWseCy8JUfXAoC+Q1sjQ
MJM70naLALmrJGeOBbJAymFooRGc0/3JukTxh5VRzHMZKOwUeTT4Ut8Cw+9sm1XK
mqtMyYAGcUJri/Id2t58UhLdE49q86zYBBDpEwIDAQABAoIBAHVatMnHPmPZvTyk
EvW/N8aCGoVVDyf5D6Mk97SroXRMXAEiyP+f7vx3erUqUEN4ijcyczjwJ7Xw76h+
A3TsuvTu3mygIO55FBQWGXNTcBRUbu671T9XBNKktYwBS/XrdKFcyOH4Sdu5jGNn
p0AV0VyWJ0yCmi3Rsgia49Ka3SKzbwioOE/9m9tAuCPdbxUTMubnyTHiqx03fIgB
Nk4BKzjbhmV9XDj2+MaprE3yQnGZcCwdFcD7DBavHiBRNGcqAePR52X8U4Iah1Qj
++6EPQMTFabofGPYK0LMzFgzWWjvGElXHEGHF21Q52j2EuM88IDuSSmrwbCgTmzn
YdW8RtECgYEA0VDtYC4/olyfZfiZtGwu5qGtHMyt3jX+t3dDmrTIRyvnEUTl6Is6
vgbm6rF35eHHziSEBQr93GSZKH5dllNNpTmre1ZkacZvH3/twxIo7J91Z3rkcIyo
bCuAWn4H7D/8krBif4PJO4eipltZraMJGHJwfI41vIzyfa5kORgxqNkCgYEAx2Bp
L/wVJbRuNBAxVEL/1hNGLhNArQ28hZyF/5ldMkavN0Xa68HsXX144Q78jYOlcNRD
Ge8d8AP/5spxt4SH2oQssYSdjs6qGZ/yDTVwFsX41RB925DGLABqTJ5K9yELKL8V
UULIu6WVqNRFmwzyOar19L1JqKei8xd88k3lDcsCgYAY/fGpxzvf1fFOSpWHnlcn
QGycALBN1OKZ40qWITm8jbhkLnbJAj68S7Sslw36y6+ApImC1KIk+3nyBMyF02J0
9OLNsi4BFylTeIHaBcQPJKbu+RRnf9PoPnVv2JZ3ldhBZ4ALO5/+VJ6OAGA/xDSk
z50wsgYmgim96eGbk5DyWQKBgQC2l8E9xOvJIDldTQcgWEvdTsGTKOaulkn1Q6gk
sdv8U2fcgwk/qNZDuMmftA3vvIUjlAHwGmGcks0mHHmQzLtukGYuHXn+c56s4SLY
nfwNnzmISBY7o5cabTbs/HtDYOvLYVSwmy0jTT6G5ADrQywDTGL8xO5Um1JMt1Ii
xtvjiQKBgBlPSCpalOE5lVw4yvPMFWNzvMbXfaW3I3kP3XOPhEEsHRpALQNkuuJZ
NHP+fFJm0MLfZxMZdtIK1I4LYLuU00swj5/hc1NdgUgGVobU4zVxM34FvDthZMQp
OhVUBZESUtxs1AhwXBG7QopF1QQJQDzebt0kwNxh8a7H3jh0BAzq
-----END RSA PRIVATE KEY-----""",
}


def encrypt_data_e2e(message, key_id):
    public_key = load_pem_public_key(
        public_key_str[key_id].encode(), backend=default_backend()
    )

    ciphertext = public_key.encrypt(
        str(message).encode(),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA1()),
            algorithm=hashes.SHA1(),
            label=None,
        ),
    )

    return base64.b64encode(ciphertext).decode("utf-8")


def decrypt_data(encrypted_data):

    private_key = serialization.load_pem_private_key(
        private_key_str[encrypted_data["keyId"]].encode(),
        password=None,
        backend=default_backend()
    )

    decrypted_data = private_key.decrypt(
        base64.b64decode(encrypted_data["data"]),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA1()),
            algorithm=hashes.SHA1(),
            label=None
        )
    ).decode()

    return decrypted_data
