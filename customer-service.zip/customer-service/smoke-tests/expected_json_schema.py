expected_customer_basic_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "party": {
            "type": "object",
            "properties": {
                "partyId": {
                    "type": "string"
                },
                "title": {
                    "type": "string"
                },
                "forename": {
                    "type": "string"
                },
                "surname": {
                    "type": "string"
                },
                "deceasedDate": {
                    "type": "string"
                },
                "email": {
                    "type": "string"
                },
                "phoneNumber": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                "subType": {
                                    "type": "string"
                                },
                                "countryCode": {
                                    "type": "string"
                                },
                                "number": {
                                    "type": "string"
                                }
                            },
                            "required": [
                                "type",
                                "subType",
                                "number"
                            ]
                        }
                    ]
                },
            },
            "required": [
                "partyId",
                "forename",
                "surname"
            ]
        }
    },
    "required": [
        "party"
    ]
}

marketing_preferences_schema = {
    "type": "object",
    "properties": {
        "eagm": {"type": "boolean"},
        "email": {"type": "boolean"},
        "phone": {"type": "boolean"},
        "post": {"type": "boolean"}
    }
}

preferences_schema = {
    "type": "object",
    "properties": {
        "marketing": {"type": "object",
                      "properties": {
                          "eagm": {"type": "object",
                                   "properties": {
                                       "deemedConsent": {
                                           "type": "boolean"
                                       },
                                       "status": {
                                           "type": "boolean"
                                       }
                                   },
                                   "required": [
                                       "deemedConsent",
                                       "status"
                                   ],
                                   },
                          "email": {"type": "object",

                                    "properties": {
                                        "status": {
                                            "type": "boolean"
                                        }
                                    },
                                    "required": [
                                        "status"
                                    ],
                                    },
                          "phone": {"type": "object",

                                    "properties": {
                                        "status": {
                                            "type": "boolean"
                                        }
                                    },
                                    "required": [
                                        "status"
                                    ],
                                    },
                          "post": {"type": "object",

                                   "properties": {
                                       "status": {
                                           "type": "boolean"
                                       }
                                   },
                                   "required": [
                                       "status"
                                   ],
                                   },
                      },
                      "required": [
                          "eagm",
                          "email",
                          "phone",
                          "post"
                      ],
                      }
    }
}

fatca_profiles_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["countryRelationCode", "countryCode", "nonUKTaxReference"],
            "properties": {
                "countryRelationCode": {"type": "string"},
                "countryCode": {"type": "string"},
                "nonUKTaxReference": {"type": "string"},
            }
        }
    ]
}

fatca_party_schema = {
    "type": "object",
    "required": ["fatcaResponseUS", "fatcaResponseUK"],
    "properties": {
        "fatcaResponseUS": {"type": "boolean"},
        "fatcaResponseUK": {"type": "boolean"}
    }
}

_encrypted_data_schema = {
    "type": "object",
    "properties": {
        "keyId": {"type": "string"},
        "data": {"type": "string"}
    },
    "required": [
        "keyId",
        "data"
    ]
}

expected_customer__details_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "party": {
            "type": "object",
            "properties": {
                "partyId": {
                    "type": "string"
                },
                "title": {
                    "type": "string"
                },
                "forename": {
                    "type": "string"
                },
                "surname": {
                    "type": "string"
                },
                "nationalInsuranceNumber": {
                    "type": "string"
                },
                "dateOfBirth": {
                    "type": "string"
                },
                "emailAddress": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                "email": {
                                    "type": "string"
                                },
                                "pendingUpdate": {
                                    "type": "boolean"
                                }
                            },
                            "required": [
                                "type",
                                "email",
                                "pendingUpdate"
                            ]
                        }
                    ]
                },
                "phoneNumber": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                "subType": {
                                    "type": "string"
                                },
                                "countryCode": {
                                    "type": "string"
                                },
                                "number": {
                                    "type": "string"
                                },
                                "pendingUpdate": {
                                    "type": "boolean"
                                }
                            },
                            "required": [
                                "type",
                                "subType",
                                "number",
                                "pendingUpdate"
                            ]
                        }
                    ]
                },
                "address": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                 "pendingUpdate": {
                                    "type": "boolean"
                                },
                                "addressLine": {
                                    "type": "array",
                                    "items": [
                                        {
                                            "type": "string"
                                        },
                                        {
                                            "type": "string"
                                        },
                                        {
                                            "type": "string"
                                        },
                                        {
                                            "type": "string"
                                        }
                                    ]
                                },
                                "postCode": {
                                    "type": "string"
                                },
                                "country": {
                                    "type": "string"
                                }
                            },
                            "required": [
                                "type",
                                "addressLine",
                                "postCode",
                                "country",
                                "pendingUpdate"
                            ]
                        }
                    ]
                },
                "amendmentRestriction": {"type": "boolean"},
                "hasIsaSubscription": {"type": "boolean"},
                "webCustomerNumber": {"type": "string"},
                "nationality": {"type": "string"},
                "marketingPreferences": marketing_preferences_schema,
                "preferences": preferences_schema,
                "fatcaProfiles": fatca_profiles_schema,
                "fatcaParty": fatca_party_schema
            },
            "required": [
                "partyId",
                "forename",
                "surname",
                "emailAddress",
                "phoneNumber",
                "address",
                "amendmentRestriction",
                "hasIsaSubscription",
                "webCustomerNumber",
                "marketingPreferences",
                "preferences"
            ]
        }
    },
    "required": [
        "party"
    ]
}

expected_customer_extended_details_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "party": {
            "type": "object",
            "properties": {
                "partyId": {
                    "type": "string"
                },
                "title": {
                    "type": "string"
                },
                "forename": {
                    "type": "string"
                },
                "surname": {
                    "type": "string"
                },
                "nationalInsuranceNumber": {
                    "type": "string"
                },
                "dateOfBirth": {
                    "type": "string"
                },
                "placeOfBirth": _encrypted_data_schema,
                "emailAddress": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                "email": {
                                    "type": "string"
                                },
                                "pendingUpdate": {
                                    "type": "boolean"
                                }
                            },
                            "required": [
                                "type",
                                "email",
                                "pendingUpdate"
                            ]
                        }
                    ]
                },
                "phoneNumber": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                "subType": {
                                    "type": "string"
                                },
                                "countryCode": {
                                    "type": "string"
                                },
                                "number": {
                                    "type": "string"
                                },
                                "pendingUpdate": {
                                    "type": "boolean"
                                }
                            },
                            "required": [
                                "type",
                                "subType",
                                "number",
                                "pendingUpdate"
                            ]
                        }
                    ]
                },
                "address": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                "addressLine": {
                                    "type": "array",
                                    "items": [
                                        {
                                            "type": "string"
                                        },
                                        {
                                            "type": "string"
                                        },
                                        {
                                            "type": "string"
                                        },
                                        {
                                            "type": "string"
                                        }
                                    ]
                                },
                                "postCode": {
                                    "type": "string"
                                },
                                "country": {
                                    "type": "string"
                                }
                            },
                            "required": [
                                "type",
                                "addressLine",
                                "postCode",
                                "country"
                            ]
                        }
                    ]
                },
                "amendmentRestriction": {"type": "boolean"},
                "hasIsaSubscription": {"type": "boolean"},
                "webCustomerNumber": {"type": "string"},
                "nationality": {"type": "string"},
                "marketingPreferences": marketing_preferences_schema,
                "preferences": preferences_schema,
                "fatcaProfiles": fatca_profiles_schema,
                "fatcaParty": fatca_party_schema
            },
            "required": [
                "partyId",
                "forename",
                "surname",
                "emailAddress",
                "phoneNumber",
                "address",
                "amendmentRestriction",
                "hasIsaSubscription",
                "webCustomerNumber",
                "marketingPreferences",
                "preferences"
            ]
        }
    },
    "required": [
        "party"
    ]
}

available_product_interest_tiers_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["rate", "description"],
            "properties": {
                "rate": {"type": "string"},
                "description": {"type": "string"},
                "range": {"type": "string"}
            }
        }
    ]
}

available_product_facts_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["text"],
            "properties": {
                "text": {"type": "string"}
            }
        }
    ]
}

available_product_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "required": ["name", "type" , "url", "loyalty", "interestTiers", "facts", "interestFrequency"],
            "properties": {
                "name": {"type": "string"},
                "type": {"type": "string"},
                "url": {"type": "string"},
                "minimumAge": {"type": "integer"},
                "maximumAge": {"type": "integer"},
                "maximumNumberOfAccounts": {"type": "integer"},
                "loyalty": {"type": "boolean"},
                "interestFrequency": {"type": "string"},
                "interestTiers": available_product_interest_tiers_schema,
                "facts": available_product_facts_schema
            }
        }
    ]
}
available_products_schema = {
    "type": "array",
    "items": [
        {
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "subTitle": {"type": "string"},
                "description": {"type": "string"},
                "offlineOnlyProductsAvailable": {"type": "boolean"},
                "url": {"type": "string"},
                "products": available_product_schema
            },
            "required": ["title", "subTitle", "description", "products", "url", "offlineOnlyProductsAvailable"]
        }
    ]
}

expected_customer_delayed_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "party": {
            "type": "object",
            "properties": {
                "partyId": {
                    "type": "string"
                },
                "title": {
                    "type": "string"
                },
                "forename": {
                    "type": "string"
                },
                "surname": {
                    "type": "string"
                },
                "dateOfBirth": {
                    "type": "string"
                },
                "email": {
                    "type": "string"
                },
                "phoneNumber": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {
                                    "type": "string"
                                },
                                "subType": {
                                    "type": "string"
                                },
                                "countryCode": {
                                    "type": "string"
                                },
                                "number": {
                                    "type": "string"
                                }
                            },
                            "required": [
                                "type",
                                "subType",
                                "number"
                            ]
                        }
                    ]
                },
                "webCustomerNumber": {
                    "type": "string"
                },
                "webUsername": {
                    "type": "string"
                },

            },
            "required": [
                "partyId",
                "forename",
                "surname"
            ]
        }
    },
    "required": [
        "party"
    ]
}
