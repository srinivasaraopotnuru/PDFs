import pytest

import config
import ecdsa
import expected_json_schema
import hashlib
import jsonschema
import os
import requests
import uuid
from base64 import b64encode
from jwt import (
    JWT,
    jwk_from_pem,
)

from CryptoUtils import decrypt_data
from signer import Signer
from time import time

host = os.getenv('SERVICE_HOST', default='localhost:8080')
protocol = os.getenv('SERVICE_PROTOCOL', default='http://')
target_env = os.getenv('SMOKE_TARGET_ENV', default='test')

jwt_alg = 'RS256'
base_path = '/customer'
customer_path = '/customer'
customer_path_private = '/private/customer'
update_email_path = '/email-address'
update_phone_number_path = "/phone-number"
update_postal_address_path = "/postal-address"
failure_path = '/failure'
host_presented = host
x_request_id = str(uuid.uuid4())
request_signing_key_id = 'login-service-nonprod-1'
apigee_request_signing_key_id = 'apigee-nonprod-1'
sca_signing_key_id = 'sca_key'

update_email_address_request = {
    'type': 'Email',
    'email': 'updated@dummy.ybs.co.uk'
}

update_phone_number_request = {
    'phoneNumber': [
        {
            'type': 'HOME',
            'number': '01234049421'
        }
    ]
}

update_postal_address_request = {
    "address": {
        "type": "CORR",
        "subType": "UKPOST",
        "addressLines": [
            "Broad Gate",
            "The Headrow"
        ],
        "country": "UNITED_KINGDOM",
        "postCode": "LS1 6LR"
    },
    "pafData": {
        "addressKey": 12345678,
        "deliveryPointSuffix": "1TA"
    }
}

customer_delayed_request = {
    'forename': 'YUEN',
    'postCode': 'SA626QY',
    'mobileNumber': '07100100000',
    'dateOfBirth': '1977-01-06'
}

customer_delayed_request_not_found = {
    'forename': 'RAKESH',
    'postCode': 'SA626QY',
    'mobileNumber': '07100100000',
    'dateOfBirth': '1977-01-06'
}

customer_delayed_request_bad_request = {
    'forename': 'YUEN123',
    'postCode': 'SA626QY',
    'mobileNumber': '07100100000',
    'dateOfBirth': '1977-01-06'
}

if target_env == 'dev' or target_env == 'test' or target_env == 'idam-test2':
    party_id = '12462951'
    party_place_of_birth = 'GILLINGHAM'
elif target_env == 'flex':
    party_id = '12462951'
    party_place_of_birth = 'GILLINGHAM'
    customer_delayed_request = {
        'forename': 'STEPHEN',
        'postCode': 'MK442QL',
        'mobileNumber': '07100100000',
        'dateOfBirth': '1977-01-06'
    }
else:
    raise Exception('Unexpected SMOKE_TARGET_ENV: {}'.format(target_env))

signer = Signer({
    request_signing_key_id: ecdsa.SigningKey.from_pem(config.request_signature_private_key, hashlib.sha256),
    apigee_request_signing_key_id: ecdsa.SigningKey.from_pem(config.apigee_request_signature_private_key,
                                                             hashlib.sha256),
    sca_signing_key_id: ecdsa.SigningKey.from_pem(config.sca_private_key, hashlib.sha256)
})


# GET BASIC CUSTOMER DETAILS

@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_basic_should_succeed_with_valid_signature(path):
    response = make_request('get', f'{path}/{party_id}', brand_code='YBS', key_id=request_signing_key_id)
    assert response.status_code == 200

    response_body = response.json()
    jsonschema.validate(response_body, expected_json_schema.expected_customer_basic_schema)


@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_basic_should_fail_without_signature(path):
    response = make_request('get', f'{path}/{party_id}', brand_code='YBS',
                            key_id=request_signing_key_id, no_sign=True)
    assert response.status_code == 403
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


# GET BASIC CUSTOMER DETAILS DELAYED

@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_basic_delayed_should_succeed_with_valid_signature(path):
    response = make_request('get', f'{path}/delayed/{party_id}', brand_code='YBS', key_id=request_signing_key_id)
    assert response.status_code == 200

    response_body = response.json()
    jsonschema.validate(response_body, expected_json_schema.expected_customer_basic_schema)


@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_basic_delayed_should_fail_without_signature(path):
    response = make_request('get', f'{path}/delayed/{party_id}', brand_code='YBS',
                            key_id=request_signing_key_id, no_sign=True)
    assert response.status_code == 403
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


# GET GOLDEN CUSTOMER DETAILS

@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_details_should_succeed_with_valid_signature_and_scope(path):
    authorization = create_authorization(create_jwt('ACCOUNT_READ'))
    response = make_request('get', f'{path}', authorization=authorization,
                            key_id=apigee_request_signing_key_id)
    assert response.status_code == 200

    response_body = response.json()

    if path == customer_path:
        jsonschema.validate(response_body, expected_json_schema.expected_customer__details_schema)
    else:
        jsonschema.validate(response_body, expected_json_schema.expected_customer_extended_details_schema)

        decrypted_place_of_birth = decrypt_data(response_body["party"]["placeOfBirth"])

        assert decrypted_place_of_birth == party_place_of_birth


@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_details_should_fail_without_valid_scope(path):
    authorization = create_authorization(create_jwt('PAYMENT'))
    response = make_request('get', f'{path}', authorization=authorization,
                            key_id=apigee_request_signing_key_id)
    assert response.status_code == 403
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied',
                'message': 'Access Denied'
            }
        ]
    }


# UPDATE POSTAL ADDRESS

def test_post_update_postal_address_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt('ACCOUNT_READ'))

    response = make_request('post', f'{customer_path}{update_postal_address_path}', json=update_postal_address_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id)
    assert response.status_code == 403

    challenge = response.headers.get("x-ybs-sca-challenge")
    challenge_response = signer.create_ecdsa_signature(sca_signing_key_id, challenge)

    response = make_request('post', f'{customer_path}{update_postal_address_path}', json=update_postal_address_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id,
                            challenge=challenge, challenge_response=challenge_response)
    assert response.status_code == 202, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_post_update_postal_address_should_fail_without_signature():
    response = make_request('post', f'{customer_path}{update_postal_address_path}', brand_code='YBS',
                            key_id=request_signing_key_id, no_sign=True)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


def test_post_update_postal_address_should_fail_without_valid_scope():
    authorization = create_authorization(create_jwt('PAYMENT'))
    response = make_request('post', f'{customer_path}{update_postal_address_path}', json=update_postal_address_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied',
                'message': 'Access Denied'
            }
        ]
    }


# UPDATE EMAIL ADDRESS

def test_post_update_email_address_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt('ACCOUNT_READ'))

    response = make_request('post', f'{customer_path}{update_email_path}', json=update_email_address_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id)
    assert response.status_code == 403

    challenge = response.headers.get("x-ybs-sca-challenge")
    challenge_response = signer.create_ecdsa_signature(sca_signing_key_id, challenge)

    response = make_request('post', f'{customer_path}{update_email_path}', json=update_email_address_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id,
                            challenge=challenge, challenge_response=challenge_response)
    assert response.status_code == 202, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_post_update_email_address_should_fail_without_signature():
    response = make_request('post', f'{customer_path}{update_email_path}', brand_code='YBS',
                            key_id=request_signing_key_id, no_sign=True)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


def test_challenge_failure_audit():
    authorization = create_authorization(create_jwt('ACCOUNT_READ'))

    response = make_request('post', f'{customer_path}{update_email_path}', json=update_email_address_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id)
    assert response.status_code == 403

    challenge = response.headers.get("x-ybs-sca-challenge")

    response = make_request('post', f'{failure_path}',
                            json={'challenge': challenge},
                            authorization=authorization,
                            key_id=apigee_request_signing_key_id)

    assert response.status_code == 204, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_post_update_email_address_should_fail_without_valid_scope():
    authorization = create_authorization(create_jwt('PAYMENT'))
    response = make_request('post', f'{customer_path}{update_email_path}', json=update_email_address_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied',
                'message': 'Access Denied'
            }
        ]
    }


# UPDATE PHONE NUMBER

def test_post_update_phone_number_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt('ACCOUNT_READ'))
    response = make_request('post', f'{customer_path}{update_phone_number_path}', json=update_phone_number_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id)
    assert response.status_code == 403

    challenge = response.headers.get("x-ybs-sca-challenge")
    challenge_response = signer.create_ecdsa_signature(sca_signing_key_id, challenge)

    response = make_request('post', f'{customer_path}{update_phone_number_path}', json=update_phone_number_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id,
                            challenge=challenge, challenge_response=challenge_response)

    assert response.status_code == 202, f'unexpected http status: [{response.status_code}]: {response.text}'


def test_post_update_phone_number_should_fail_without_signature():
    response = make_request('post', f'{customer_path}{update_phone_number_path}', brand_code='YBS',
                            key_id=request_signing_key_id, no_sign=True)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


def test_post_update_phone_number_should_fail_without_valid_scope():
    authorization = create_authorization(create_jwt('PAYMENT'))
    response = make_request('post', f'{customer_path}{update_phone_number_path}', json=update_phone_number_request,
                            authorization=authorization, key_id=apigee_request_signing_key_id)
    assert response.status_code == 403, f'unexpected http status: [{response.status_code}]: {response.text}'
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied',
                'message': 'Access Denied'
            }
        ]
    }


@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_available_products_should_succeed_with_valid_signature_and_scope(path):
    authorization = create_authorization(create_jwt('ACCOUNT_READ'))
    response = make_request('get', f'{path}/available-products', authorization=authorization,
                            key_id=apigee_request_signing_key_id)
    assert response.status_code == 200

    response_body = response.json()
    jsonschema.validate(response_body, expected_json_schema.available_products_schema)


@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_available_products_should_fail_without_signature(path):
    authorization = create_authorization(create_jwt('ACCOUNT_READ'))
    response = make_request('get', f'{path}/available-products', authorization=authorization,
                            key_id=request_signing_key_id, no_sign=True)
    assert response.status_code == 403
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


@pytest.mark.parametrize("path", [customer_path, customer_path_private])
def test_get_customer_available_products_should_fail_without_valid_scope(path):
    authorization = create_authorization(create_jwt('PAYMENT'))
    response = make_request('get', f'{path}/available-products', authorization=authorization,
                            key_id=request_signing_key_id, no_sign=False)
    assert response.status_code == 403
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied',
                'message': 'Access Denied'
            }
        ]
    }


# GET CUSTOMER DELAYED FROM ADG CORE USING FORENAME, DOB, POSTCODE, MOBILE NUMBER
def test_get_customer_delayed_should_succeed_with_valid_signature():
    response = make_request('post', f'{customer_path_private}/delayed', brand_code='YBS', json=customer_delayed_request,
                            key_id=request_signing_key_id)
    assert response.status_code == 200

    response_body = response.json()
    jsonschema.validate(response_body, expected_json_schema.expected_customer_delayed_schema)


def test_get_customer_delayed_should_fail_without_signature():
    response = make_request('post', f'{customer_path_private}/delayed', brand_code='YBS', json=customer_delayed_request,
                            key_id=request_signing_key_id, no_sign=True)
    assert response.status_code == 403
    assert response.json() == {
        'id': x_request_id,
        'code': '403 Forbidden',
        'message': 'Forbidden',
        'errors': [
            {
                'errorCode': 'AccessDenied.InvalidRequestSignature',
                'message': 'Access Denied'
            }
        ]
    }


def test_get_customer_delayed_should_fail_with_incorrect_data():
    response = make_request('post', f'{customer_path_private}/delayed', brand_code='YBS', json=customer_delayed_request_not_found,
                            key_id=request_signing_key_id)
    assert response.status_code == 404
    assert response.json() == {
        'id': x_request_id,
        'code': '404 Not Found',
        'message': 'Resource not found',
        'errors': [
            {
                'errorCode': 'Resource.NotFound',
                'message': 'Resource not found'
            }
        ]
    }


def test_get_customer_delayed_should_fail_with_bad_request():
    response = make_request('post', f'{customer_path_private}/delayed', brand_code='YBS', json=customer_delayed_request_bad_request,
                            key_id=request_signing_key_id)
    assert response.status_code == 400
    assert response.json() == {
        'id': x_request_id,
        'code': '400 Bad Request',
        'message': 'Invalid request body',
        'errors': [
            {
                'errorCode': 'Field.Invalid',
                'message': 'Please specify valid forename',
                'path': 'forename'
            }
        ]
    }


def create_authorization(bearer_token):
    return 'Bearer ' + bearer_token


def create_jwt(scope):
    signing_key = jwk_from_pem(config.jwt_private_key.encode())
    jwt = JWT()

    headers = {
        'kid': 'OPAa9voYNByjE_lpbtHanOFKiV4',
        'alg': jwt_alg
    }

    message = {
        'sub': party_id,
        'iat': time(),
        'sid': str(uuid.uuid4()),
        'aud': 'DIGITAL_API',
        'brand_code': 'YBS',
        'scope': scope,
        'channel': 'SAPP',
        'registration_id': str(uuid.uuid4()),
        'verification_method': 'BIOMETRIC',
        'party_id': party_id,
        'sub_type': 'customer'
    }
    return jwt.encode(message, signing_key, jwt_alg, headers)


def get_current_home_phone_number():
    response = make_request('get', f'{customer_path}/{party_id}', brand_code='YBS', key_id=request_signing_key_id)
    assert response.status_code == 200

    response_body = response.json()

    # trunc to 11 digits as we have some invalid phone numbers on test db's'
    return response_body["party"]["phoneNumber"][0]["number"][:11]


def increment_phone_number(phone_number):
    last_digit = phone_number[-1]

    new_last_digit = int(last_digit) + 1

    if new_last_digit > 9:
        new_last_digit = 0

    return phone_number[:-1] + str(new_last_digit)


def make_request(method, path, json=None, authorization=None, challenge=None, challenge_response=None,
                 brand_code=None, key_id=None, no_sign=False):
    url = protocol + host + base_path + path

    headers = {
        'Host': host_presented,
        'x-ybs-request-id': x_request_id
    }

    def add_header_if_not_none(header, value):
        if value is not None:
            headers[header] = value

    add_header_if_not_none('Authorization', authorization)
    add_header_if_not_none('x-ybs-brand-code', brand_code)
    add_header_if_not_none('x-ybs-request-signature-key-id', key_id)
    add_header_if_not_none('x-ybs-sca-challenge', challenge)
    add_header_if_not_none('x-ybs-sca-challenge-response', challenge_response)
    if challenge_response or challenge:
        headers['x-ybs-sca-key'] = b64encode(config.sca_public_key.encode("utf-8")).decode()

    request = requests.Request(method, url, headers, json=json).prepare()
    if not no_sign:
        signer.sign_request(request)
    return requests.session().send(request, verify=False)
