from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from base64 import b32encode

import importlib
config = importlib.import_module("sboot-tools.pytestconf.Config")

class Tokenizer:

    def __init__(
        self,
        tokenizer_key,
    ):
        self.tokenizer_key = tokenizer_key
        self.tokenize_cipher = self.build_tokenizer()

    def build_tokenizer(self):
        backend = default_backend()
        digest = hashes.Hash(hashes.SHA256(), backend=backend)
        digest.update(config.account_number_tokenization_secret_key.encode())
        digest.update(b"|")
        print("tokenizer_key:", self.tokenizer_key)
        digest.update(str(self.tokenizer_key).encode())
        key = digest.finalize()
        return Cipher(algorithms.AES(key), modes.ECB(), backend=backend)

    def tokenize(self, account_number):
        padder = padding.PKCS7(128).padder()
        padded = padder.update(account_number.encode())
        padded += padder.finalize()

        encryptor = self.tokenize_cipher.encryptor()
        encrypted = encryptor.update(padded)
        encrypted += encryptor.finalize()

        encoded = b32encode(encrypted).decode("utf-8").replace("=", "0")
        return encoded
