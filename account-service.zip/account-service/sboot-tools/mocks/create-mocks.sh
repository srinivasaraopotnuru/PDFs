curl -v -X PUT "https://ds-mocks-dev.apps.ostest.ybs.com/mockserver/expectation" -d '{
  "priority" : -100,
  "httpRequest" : {
    "path" : "/path-to-mocked"
  },
  "httpResponse" : {
    "statusCode" : 200,
    "body" : "{\"message\" : \"hello\"}"
  }
}'
