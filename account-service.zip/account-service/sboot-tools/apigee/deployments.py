import json
import os
import sys
from base64 import b64decode

import requests

import git_utils


def get_deployments(apiproxies, sharedflows):
    with requests.Session() as session:
        base_path = os.getenv('APIGEE_DEPLOY_BASE_PATH')
        environment = os.getenv('TARGET_ENV')
        org = os.getenv('APIGEE_DEPLOY_ORG')
        apg_password = os.getenv('APIGEE_DEPLOY_PASSWORD')
        if apg_password is None or apg_password == "":
            apg_password = b64decode(os.getenv('APIGEE_DEPLOY_PASSWORD_B64')).decode("ascii")

        session.auth = os.getenv('APIGEE_DEPLOY_USER'), apg_password
        session.headers.update({
            'Accept': 'application/json'
        })

        apiproxy_revisions = {}
        sharedflow_revisions = {}
        revisions = {
            'apiproxies': apiproxy_revisions,
            'sharedflows': sharedflow_revisions
        }

        if apiproxies:
            uri = '/v1/organizations/{}/environments/{}/deployments'.format(org, 'dev')
            response = session.get('https://api.enterprise.apigee.com' + uri)
            assert response.status_code == 200, (response.status_code, response.text)

            # this is _not_ a typo, this is the actual key that Apigee went with...
            for entry in json.loads(response.text)['aPIProxy']:
                name = entry['name']
                if name in apiproxies:
                    # Because we're asking for revisions in an environment, we know
                    # there is only the one so we can index it safely.
                    apiproxy_revisions[name] = entry['revision'][0]['name']

        for sharedflow in sharedflows:
            uri = '/v1/organizations/{}/sharedflows/{}/revisions'.format(org, sharedflow)
            response = session.get('https://api.enterprise.apigee.com' + uri)
            assert response.status_code in [200, 404], (response.status_code, response.text)
            if response.status_code == 200:
                sharedflow_revisions[sharedflow] = json.loads(response.text)[-1]

        return revisions



def list_dirs(root):
    '''gets the list of child directories in the specified directory'''
    return filter(os.path.isdir, os.scandir(root))


def main():
    repo = git_utils.find_git_root(os.getcwd())
    git_root_dir = repo.working_tree_dir

    apiproxies = list_dirs(os.path.join(git_root_dir, 'apiproxies'))
    sharedflows = list_dirs(os.path.join(git_root_dir, 'sharedflows'))
    apiproxy_names = list(map(lambda d: d.name, apiproxies))
    sharedflow_names = list(map(lambda d: d.name, sharedflows))

    json.dump(get_deployments(apiproxy_names, sharedflow_names), sys.stdout, indent=4)

if __name__ == '__main__':
    main()
