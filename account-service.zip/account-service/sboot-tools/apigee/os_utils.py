import os

def chmod_dir(dir, mod):
    for root, dirs, files in os.walk(dir):
        for d in dirs:
            os.chmod(os.path.join(root, d), mod)
        for f in files:
            os.chmod(os.path.join(root, f), mod)

def updateEnv(key, value):

    if not os.path.isfile(".env"):
        return

    envVars = dict((kv.split('=', 1)  for kv in (l.strip('\n') for l in open('.env'))))
    envVars[key] = value

    with open('.env', 'w') as f:
        for key, value in envVars.items():
            f.write('{0}={1}\n'.format(key, value))
