# Function to write a Name-Value-Pair line in a file.
WritePropertyInFile () {
    #$1 = file name
    #$2 = prop key
    #$3 = prop value
    #$4 = overwrite
    if grep -q "$2 *=" $1; then
        if [ "false" != "$4" ] ; then
            cleanVal=$3
            #If the value contains slashes, escape them.
            if echo $3 | grep -q "/"; then
                cleanVal=`echo $3 | sed 's:/:\d092\d092/:g'`
            fi
            sed -i "s/$2 *=.*/$2=$cleanVal/g" $1
        fi
    else
        echo "$2=$3" >> $1
    fi
}
