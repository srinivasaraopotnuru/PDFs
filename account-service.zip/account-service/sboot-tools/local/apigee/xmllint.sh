#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
#cd "$gwd"
xmllint_bin=`command -v xmllint`

WIN_PATH="C:\\api\\tools\\xmllint"
WIN_EXE="$WIN_PATH\\xmllint.exe"

echo `uname -s`

if [ "$xmllint_bin" = "" ] && [[ "$(uname -s)" == MINGW* ]]; then
    if [ -f "$WIN_EXE" ]; then
        xmllint_bin=$WIN_EXE
    fi
fi

echo Found $xmllint_bin

#Check if xmllint not already installed
if [ "$xmllint_bin" = "" ]; then
    echo Need to install xmllint
    if [ "$(uname -s)" == "Linux" ]; then
        ### Install xmllint linux package
        #Need sudo here. (write access to /var/lib/dpkg/lock-frontend is required)
        sudo apt-get install libxml2-utils
    elif [[ "$(uname -s)" == MINGW* ]]; then
        echo Installing xmllint locally
        mkdir -p "$WIN_PATH"
        xcopy  "\\\\h14719\\GlobalReadOnlyShare\\api\\tools\\xmllint" "$WIN_PATH"
    fi
fi

echo Checking XML Files
result=0
find . -not -path '*/target*' -not -path "*/.*" -not -name ".*" -name \*.xml -exec $xmllint_bin {} \+ > /dev/null
result=$?
echo Finished
exit $result