#!/usr/bin/env bash

YELLOW='\033[1;33m'
NC='\033[0m'

read -p "Openshift instance (os4): " OSHIFT_INSTANCE
if [ "" = "$OSHIFT_INSTANCE" ]; then
  OSHIFT_INSTANCE=os4
fi
read -p "Project namespace (e.g. ds-calculator-dev/ds-savings-dev): " NAMESPACE
read -p "Service (e.g. maxborrowing/mort-illustrator): " SERVICE
read -p "Logger (default: uk.co.ybs.services): " LOGGER
if [ "" = "$LOGGER" ]; then
  LOGGER="uk.co.ybs.services"
fi
read -p "Log level (e.g. INFO/DEBUG/TRACE): " LOG_LEVEL
if [ "" = "$LOG_LEVEL" ]; then
  LOG_LEVEL="INFO"
fi
read -p "Number of replica pods (default: 1): " REPLICAS
if [ "" = "$REPLICAS" ]; then
  REPLICAS=1
fi
read -p "Service username (leave blank for none): " USERNAME
if [ "" != "$USERNAME" ]; then
  read -s -p "Service password: " PASSWORD
fi
echo ""

HOSTNAME="apps.ostest.ybs.com"
if [ "os4" != "$OSHIFT_INSTANCE" ]; then
  HOSTNAME="test.os.ybs.com"
fi
if echo $NAMESPACE | grep -qE '^[[:alnum:]]+-[[:alnum:]]+-prod$';
then
    HOSTNAME="apps.osprod.ybs.com"
    if [ "os4" != "$OSHIFT_INSTANCE" ]; then
      HOSTNAME="prod.os.ybs.com"
    fi
fi

USER_PARAM=
if [ "" != "$USERNAME" ]; then
  USER_PARAM="-u $USERNAME:$PASSWORD"
fi
HTTP_URL="https://$NAMESPACE-$SERVICE.$HOSTNAME"
echo HTTP_URL=$HTTP_URL

HITS=$REPLICAS
if [ "1" != "$REPLICAS" ]; then
  HITS=$((REPLICAS*2))
fi
for i in $(seq 1 $HITS);
do
  echo "Update $i..."
  CODE=$(curl -X "POST" \
      "$HTTP_URL/actuator/loggers/$LOGGER" \
      $USER_PARAM \
      -H "Content-Type: application/json; charset=utf-8" \
      -d $'{"configuredLevel": "'$LOG_LEVEL'"}' \
      -w "%{http_code}" \
      -s \
      -o /dev/null)

  STATUS_CODE="${CODE}"
  echo STATUS_CODE=$STATUS_CODE

  if echo $STATUS_CODE | grep -qE '^[2][[:digit:]]{2}$';
  then
      echo "Log level update success!"
  else
      echo "Error: failed to update ("$STATUS_CODE")"
  fi
done

if [ "1" != "$REPLICAS" ]; then
  printf "${YELLOW}Warning!${NC} $HITS updates took place, but doesn't guarantee a hit on each replica. With multiple replicas this may need to be executed several times\n"
fi
