#!/bin/bash

set -e

#Default warning rules to all default apigeelint warnings.
WARNING_RULES="unknown,CC001,CC003,CC004,BN003,BN004,BN005,BN006,BN007,BN009,PO007,PO008,PO013,PO022"
RESET="\033[0m"
BOLD_GREEN="\033[1;32m"
BOLD_RED="\033[1;31m"
BOLD_AMBER="\033[1;33m"

RESULTS_DIR="${APIGEE_LINT_RESULTS_DIR:-target/apigeelint}"

# This will the run the linter and will return an negative result on warnings as
# well as errors. This is required because some of the warnings are severe
# to fail the build but apigeelint cannot be configured to fail in this way.
function lint_fail_on_warning() {
	local PROXY_DIR="$1"
	local RESULTS_FILE="${RESULTS_DIR}/${PROXY_DIR#./}.xml"
	local PARENT_DIR="$(dirname "$RESULTS_FILE")"

	echo -ne "${BOLD_GREEN}linting ${PROXY_DIR}${RESET}: "

	mkdir -p "$PARENT_DIR"

	EXCLUSIONS=""
	#Load exclusions from the config.
	moreconfig=1
	loopvar=1
	while [ $moreconfig == 1 ]; do
		prx_key="EXCLUDE_PROXY$loopvar"
		rul_key="EXCLUDE_RULES$loopvar"
		#echo "EXCLUDE_PROXY$loopvar" = ${!prx_key}
		#echo "EXCLUDE_RULES$loopvar" = ${!rul_key}
		if [ "${!prx_key}" == "" ]; then
			#echo "prx_key is unset"
			moreconfig=0
		else
			if [[ $PROXY_DIR == *${!prx_key} ]]; then
				if [ "$EXCLUSIONS" != "" ]; then
					EXCLUSIONS="$EXCLUSIONS,"
				fi
				EXCLUSIONS="$EXCLUSIONS${!rul_key}"
			fi
		fi
		((loopvar+=1))
	done
	echo -ne "EXCLUDING: $EXCLUSIONS "

	# Dump a JUNIT format results file so we can export a report later
	apigeelint -s "$PROXY_DIR" -e $EXCLUSIONS -f junit.js > "$RESULTS_FILE"
	lintResult=$?

	# If there are any test cases in the junit file then we know there is at least one failure

	errorCodes=$(grep -e '<testcase\s' "$RESULTS_FILE" | sed 's/.*name="org.eslint.\([^"]*\)".*/\1/')
  errCount=0
	myErrCodes=
	myErrCount=0
	myWarnCodes=
	myWarnCount=0
	for errorCode in $errorCodes
	do
		#echo errorCode=$errorCode
  	((errCount+=1))
		if ! grep -q -e "$errorCode" <<< "$WARNING_RULES"; then
      ((myErrCount+=1))
			myErrCodes="$myErrCodes $errorCode"
    else
      ((myWarnCount+=1))
			myWarnCodes="$myWarnCodes $errorCode"
		fi
	done

	if [ $myErrCount -gt "0" ]; then
	  #if grep -q -e ', Error -\s' "$RESULTS_FILE"; then
		echo -e "${BOLD_RED}FAILED${RESET}"
		# Print out the error codes that we are counting as errors first.
		echo -ne "errCount=$myErrCount "
		echo -e "errorCodes=$(echo $myErrCodes | tr ' ' '\n' | sort | uniq | tr '\n' ' ') "
		# Print out the failures in a more readable form and return an error
		apigeelint -s "$PROXY_DIR" -e $EXCLUSIONS -f table
		false
	elif [ $myWarnCount -gt "0" ]; then
    if [ "$myWarnCodes" != " unknown" ]; then
      echo -e "${BOLD_AMBER}WARNING${RESET}"
      echo -ne "warnCount=$myWarnCount "
      echo -e "warnCodes=$(echo $myWarnCodes | tr ' ' '\n' | sort | uniq | tr '\n' ' ') "
    fi
	elif [[ $lintResult -gt 0 ]]; then
    #Some other script error occurred?
		echo -e "${BOLD_RED}FAILED${RESET}"
    echo -e "Unexpected error!"
		false
	else
		echo -e "${BOLD_GREEN}SUCCESS${RESET}"
	fi
}

# This will run the linter on all directories passed into it on stdin. It will
# return a negative result if any of them fail, but will not short-circuit so
# we can see all failures rather than just the first.
function lint_all() {
	local result=0
	while read proxy; do
		echo -e "Testing: $proxy"
		lint_fail_on_warning "$proxy" || result=1;
	done
	[ $result -eq 0 ]
}

EXCLUDES_CFG="api-tools-cfg/apigeelint-excludes.cfg"
if [ -f "api-tools-cfg/apigeelint-excludes.cfg" ]; then
	echo "Loading config: $EXCLUDES_CFG"
	. $EXCLUDES_CFG
else
	echo "config not found: $EXCLUDES_CFG"
fi
SKIPS_CFG="api-tools-cfg/apigeelint-skips.cfg"
skips=
if [ -f "api-tools-cfg/apigeelint-skips.cfg" ]; then
	echo "Loading config: $SKIPS_CFG"
	skips=$(printf "! -path %s " $(cat $SKIPS_CFG))
else
	echo "config not found: $SKIPS_CFG"
fi
WARNINGS_CFG="api-tools-cfg/apigeelint-warnings.cfg"
if [ -f "api-tools-cfg/apigeelint-warnings.cfg" ]; then
	echo "Loading config: $WARNINGS_CFG"
	. $WARNINGS_CFG
else
	echo "config not found: $WARNINGS_CFG"
fi

### Find the directories named apiproxy or sharedflowbundle and run the linter against them
find . -not -path '*/\.*' -not -path '*/target*' \
$(echo $skips) \
-type d \( -name apiproxy -o -name sharedflowbundle \) | lint_all
