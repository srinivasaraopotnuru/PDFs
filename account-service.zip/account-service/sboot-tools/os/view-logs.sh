#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd

if [ "" == "$TAILSIZE" ]; then
  TAILSIZE=100
fi
echo "This script allows you to see the last $TAILSIZE lines of a current or previous log for a chosen pod."
echo "You can also choose to follow the log. To see more log lines, set TAILSIZE, e.g: export TAILSIZE=1000"
echo ""

if [ "" == "$AD_USERNAME" ]; then
  echo "INFO: Run: \`. ./sboot-tools/set-env.sh\` to persist env vars in this shell"
  . $gwd/sboot-tools/set-env.sh
fi

if [ "$OPENSHIFT_DEPLOY_PASSWD" == "" ]; then
  OPENSHIFT_DEPLOY_PASSWD=`echo -n $OPENSHIFT_DEPLOY_PASSWD_B64 | base64 --decode`
fi
OPENSHIFT_DEPLOY_HOST=$OPENSHIFT_DEPLOY_SUBDOMAIN.$OPENSHIFT_DEPLOY_DOMAIN
echo "Connecting to: $OPENSHIFT_DEPLOY_HOST..."
oc login --insecure-skip-tls-verify=true -u $OPENSHIFT_DEPLOY_USER -p $OPENSHIFT_DEPLOY_PASSWD $OPENSHIFT_DEPLOY_HOST >/dev/null

projects=`oc projects | grep '^ ' | tr '*' ' '`
echo "Which namespace?"
select project in $projects
do
  echo "You have chosen $project"
  oc project $project

  oc get pods
  PODS=`oc get pods | tail -n +2 | awk '{ print $1 }' | tr '\n' ' '`
  echo "Which pod?"
  select pod in $PODS
  do
    echo "You have chosen $pod"

    echo "Do you wish to see logs for the current or previous pod?"
    select curprev in "Current" "Previous"
    do
    case $curprev in
      "Current")
      echo "Do you wish to tail (follow) the log"
      select yn in "Yes" "No"; do
          case $yn in
              Yes ) oc logs -f $pod --tail=$TAILSIZE; break;;
              No ) oc logs $pod --tail=$TAILSIZE; break;;
          esac
      done
      break
      ;;
      # Three case values are declared here for matching
      "Previous")
      oc logs -p $pod --tail=$TAILSIZE
      break
      ;;
      # Matching with invalid data
      *)
      echo "Invalid entry."
      break
      ;;
    esac
    break
    done

  break
  done

break
done
