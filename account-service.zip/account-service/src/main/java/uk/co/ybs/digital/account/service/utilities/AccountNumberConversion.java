package uk.co.ybs.digital.account.service.utilities;

import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.experimental.UtilityClass;

@UtilityClass
public class AccountNumberConversion {

  public static Map<Long, String> buildAccountNumberMappings(
      final Collection<String> accountNumbers) {
    return accountNumbers.stream().collect(Collectors.toMap(Long::valueOf, Function.identity()));
  }

  public static String mapAccountNumberToString(
      final Map<Long, String> accountNumberLongToString, final Long accountNumberLong) {
    return Optional.ofNullable(accountNumberLongToString.get(accountNumberLong))
        .orElseThrow(
            () -> new IllegalArgumentException("Unknown account number: " + accountNumberLong));
  }
}
