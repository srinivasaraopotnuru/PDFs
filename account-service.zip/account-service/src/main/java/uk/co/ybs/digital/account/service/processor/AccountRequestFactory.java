package uk.co.ybs.digital.account.service.processor;

import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogPayload;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogPayloadVisitor;

@Component
@RequiredArgsConstructor
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public class AccountRequestFactory {

  private final SubmitIsaDeclarationProcessor submitIsaDeclarationProcessor;
  private final AccountWarningProcessor accountWarningProcessor;
  private final DeleteAccountProcessor deleteAccountProcessor;
  private final DeleteAccountWarningProcessor deleteAccountWarningProcessor;
  private final UpdateAccountDetailsProcessor updateAccountDetailsProcessor;

  public AccountRequest build(final WorkLog workLog, final LocalDateTime processTime) {

    final WorkLogPayload workLogPayload = workLog.getMessage().getWorkLogPayload();

    return workLogPayload.accept(new BuildWorkLogPayloadVisitor(workLog, processTime));
  }

  @AllArgsConstructor
  public class BuildWorkLogPayloadVisitor implements WorkLogPayloadVisitor<AccountRequest> {

    private final WorkLog workLog;
    private final LocalDateTime processTime;

    @Override
    public AccountRequest visit(
        final uk.co.ybs.digital.account.model.digitalaccount.SubmitIsaDeclarationRequest
            submitIsaDeclarationRequest) {

      return SubmitIsaDeclarationRequest.builder()
          .arguments(
              SubmitIsaDeclarationRequestArguments.builder()
                  .accountNumber(workLog.getAccountNumber())
                  .processTime(processTime)
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .build())
          .processor(submitIsaDeclarationProcessor)
          .build();
    }

    @Override
    public AccountRequest visit(
        final uk.co.ybs.digital.account.model.digitalaccount.AccountWarningRequest
            accountWarningRequest) {

      return AccountWarningRequest.builder()
          .arguments(
              AccountWarningRequestArguments.builder()
                  .accountNumber(workLog.getAccountNumber())
                  .warningCode(accountWarningRequest.getWarningType())
                  .createdAt(accountWarningRequest.getCreatedAt())
                  .createdBy(accountWarningRequest.getCreatedBy())
                  .notes(accountWarningRequest.getNotes())
                  .processTime(processTime)
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .build())
          .processor(accountWarningProcessor)
          .build();
    }

    @Override
    public AccountRequest visit(
        final uk.co.ybs.digital.account.model.digitalaccount.DeleteAccountRequest
            deleteAccountRequest) {

      return DeleteAccountRequest.builder()
          .arguments(
              DeleteAccountRequestArguments.builder()
                  .accountNumber(workLog.getAccountNumber())
                  .processTime(processTime)
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .build())
          .processor(deleteAccountProcessor)
          .build();
    }

    @Override
    public AccountRequest visit(
        final uk.co.ybs.digital.account.model.digitalaccount.DeleteAccountWarningRequest
            deleteAccountWarningRequest) {

      return DeleteAccountWarningRequest.builder()
          .arguments(
              DeleteAccountWarningRequestArguments.builder()
                  .accountNumber(workLog.getAccountNumber())
                  .warningCode(deleteAccountWarningRequest.getWarningType())
                  .endAt(deleteAccountWarningRequest.getEndedAt())
                  .endBy(deleteAccountWarningRequest.getEndedBy())
                  .processTime(processTime)
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .build())
          .processor(deleteAccountWarningProcessor)
          .build();
    }

    @Override
    public AccountRequest visit(
        final uk.co.ybs.digital.account.model.digitalaccount.UpdateAccountDetailsRequest
            updateAccountDetailsRequest) {

      return UpdateAccountDetailsRequest.builder()
          .arguments(
              UpdateAccountDetailsRequestArguments.builder()
                  .accountNumber(workLog.getAccountNumber())
                  .accountName(updateAccountDetailsRequest.getAccountName())
                  .processTime(processTime)
                  .requestMetadata(workLog.getMessage().getMetadata())
                  .build())
          .processor(updateAccountDetailsProcessor)
          .build();
    }
  }
}
