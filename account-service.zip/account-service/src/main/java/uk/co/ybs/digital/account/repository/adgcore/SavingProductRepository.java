package uk.co.ybs.digital.account.repository.adgcore;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;

public interface SavingProductRepository extends JpaRepository<SavingProduct, Long> {

  @Query(
      "SELECT sp "
          + "FROM SavingProduct sp "
          + "JOIN AccountNumber an ON sp.sysid = an.savingProductSysId "
          + "WHERE an.accountNumber = :accountNumber "
          + "AND an.tableId = uk.co.ybs.digital.account.model.adgcore.AccountNumber.TABLE_ID_SAVACC")
  Optional<SavingProduct> findBySavingAccountNumber(@Param("accountNumber") Long accountNumber);
}
