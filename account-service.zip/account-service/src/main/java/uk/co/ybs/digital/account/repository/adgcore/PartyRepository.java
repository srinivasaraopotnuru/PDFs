package uk.co.ybs.digital.account.repository.adgcore;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.account.model.adgcore.LinkedParty;
import uk.co.ybs.digital.account.model.adgcore.LinkedPartyDetails;
import uk.co.ybs.digital.account.model.adgcore.Party;

public interface PartyRepository extends JpaRepository<Party, Long> {

  /**
   * Fetch all linked party sysids.
   *
   * @param partyId
   * @return List<LinkedPartyDetails>
   */
  @Query(name = LinkedPartyDetails.LINKED_PARTY_DETAILS_QUERY)
  List<LinkedPartyDetails> findLinkedParties(String partyId);

  @Query(name = LinkedParty.FIND_CANONICAL_PARTY_ID_QUERY)
  Optional<LinkedParty> findCanonicalPartyId(Long partyId);
}
