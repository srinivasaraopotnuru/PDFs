package uk.co.ybs.digital.account.service.product;

import io.micrometer.core.annotation.Timed;
import java.util.List;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.product.dto.ProductInfoPage;
import uk.co.ybs.digital.account.service.product.dto.ProductReinvestmentResponse;
import uk.co.ybs.digital.account.web.ErrorResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class ProductService {
  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";
  private static final String EMPTY_RESPONSE_ERROR_MESSAGE = "Empty response from product service";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling product service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Error calling product service: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private final WebClient productServiceWebClient;

  public ProductInfo getProductInfo(
      final String productIdentifier, final RequestMetadata metadata) {
    return get(
        metadata, ProductInfo.class, "/private/product/{productIdentifier}", productIdentifier);
  }

  public List<ProductInfo> searchProductInfo(
      final Set<String> productIdentifiers, final RequestMetadata metadata) {
    final int pageSize = productIdentifiers.size();
    final String productIdentifiersParam = String.join(",", productIdentifiers);
    return get(
            metadata,
            ProductInfoPage.class,
            "/private/product?productIdentifiers={productIdentifiers}&page=0&size={pageSize}",
            productIdentifiersParam,
            pageSize)
        .getContent();
  }

  public ProductReinvestmentResponse getReinvestmentProducts(
      final RequestMetadata metadata, final String productIdentifier) {
    return get(
        metadata,
        ProductReinvestmentResponse.class,
        "/private/product/{productIdentifier}/reinvestment-products",
        productIdentifier);
  }

  private <T> T get(
      final RequestMetadata metadata,
      final Class<T> responseType,
      final String uri,
      final Object... uriVariables) {
    return productServiceWebClient
        .get()
        .uri(uri, uriVariables)
        .header(REQUEST_ID_HEADER, metadata.getRequestId().toString())
        .header(HttpHeaders.AUTHORIZATION, "Bearer " + metadata.getForwardingAuth())
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .bodyToMono(responseType)
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new ProductServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new ProductServiceException(EMPTY_RESPONSE_ERROR_MESSAGE));
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !ProductServiceException.class.isInstance(thrown);
  }

  private Mono<ProductServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new ProductServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new ProductServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new ProductServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
