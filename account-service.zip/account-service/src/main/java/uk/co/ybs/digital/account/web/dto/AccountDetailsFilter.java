package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum AccountDetailsFilter {
  AVAILABLE_DEPOSIT_LIMIT("availableDepositLimit"),
  OTHER_ACCOUNT("otherAccount");

  @JsonValue private final String value;
}
