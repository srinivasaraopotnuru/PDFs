package uk.co.ybs.digital.account.repository.adgcore;

import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.account.model.adgcore.db.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.db.AccountNumberMapper;
import uk.co.ybs.digital.account.model.adgcore.db.SqlReturnStructArray;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Slf4j
@Repository
@CallLogged(logParameters = true)
public class SoaSavingsAccountListRepository {
  /*
   * The in memory H2 database used for tests does not support stored procedures with custom data types, so it is not
   * possible to easily test this repository. This will just be covered by E2E tests.
   */

  private static final Integer CLOSED_SINCE_MONTHS = 24;

  private final transient SimpleJdbcCall getSavingsAccountListCall;

  public SoaSavingsAccountListRepository(final DataSource adgCoreDataSource) {

    getSavingsAccountListCall =
        new SimpleJdbcCall(adgCoreDataSource)
            .withProcedureName("SOA_SAVINGSACCOUNT_DATA.PR_GET_ACC_CUST_DTLS")
            .withoutProcedureColumnMetaDataAccess()
            .declareParameters(new SqlParameter("ps_brand", Types.VARCHAR))
            .declareParameters(new SqlParameter("pn_party_sysid", Types.NUMERIC))
            .declareParameters(new SqlParameter("pn_cls_acc_since_mth", Types.NUMERIC))
            .declareParameters(new SqlParameter("ps_show_closed_acc", Types.VARCHAR))
            .declareParameters(
                new SqlOutParameter(
                    "tab_soa_tbl_acc",
                    Types.ARRAY,
                    "SOA_TBL_ACC",
                    new SqlReturnStructArray<>(new AccountNumberMapper())));
  }

  public List<AccountNumber> getSavingsAccountList(
      final String partyId, final String brandCode, final boolean showClosedAccounts) {

    final Map<String, Object> in = new HashMap<>();
    in.put("ps_brand", brandCode);
    in.put("pn_party_sysid", partyId);
    in.put("pn_cls_acc_since_mth", CLOSED_SINCE_MONTHS);
    in.put("ps_show_closed_acc", showClosedAccounts ? "Y" : "N");

    final Object[] accounts;

    try {

      accounts = getSavingsAccountListCall.executeObject(Object[].class, in);

    } catch (final UncategorizedSQLException ex) {
      throw new SoaSavingsAccountListException(ex.getSQLException().getMessage(), ex);
    } catch (final Exception ex) {
      throw new SoaSavingsAccountListException(
          "An error occurred calling SOA_SAVINGSACCOUNT_DATA.PR_GET_ACC_CUST_DTLS " + partyId, ex);
    }

    return Stream.of(accounts).map(o -> (AccountNumber) o).collect(Collectors.toList());
  }
}
