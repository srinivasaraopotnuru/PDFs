package uk.co.ybs.digital.account.repository.adgcore;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;

public interface RestrictionTypeRepository extends JpaRepository<RestrictionType, Long> {

  Optional<RestrictionType> findByCode(String code);
}
