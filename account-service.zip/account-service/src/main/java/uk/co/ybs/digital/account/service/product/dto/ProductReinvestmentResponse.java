package uk.co.ybs.digital.account.service.product.dto;

import java.util.List;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ProductReinvestmentResponse {
  List<ReinvestmentProduct> reinvestmentProducts;
}
