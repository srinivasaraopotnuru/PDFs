package uk.co.ybs.digital.account.service.utilities;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.account.repository.frontoffice.SavingsTransactionLogRepository;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;

@Component
@RequiredArgsConstructor
@Slf4j
public class AccountWarningFilter {
  @NonNull private final SavingsTransactionLogRepository savingsTransactionLogRepository;

  public Map<String, List<AccountWarningRestrictionRule>> filter(
      final Map<String, String> productIdentifierByAccountNumber,
      final Map<String, ProductInfo> productInfoByProductIdentifier,
      final Map<String, List<AccountWarningRestrictionRule>>
          accountWarningRestrictionRulesByAccountNumber,
      final LocalDateTime date) {

    final Map<String, Set<AccountWarningRestrictionRule>> removeCandidates =
        getRemoveCandidates(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber);

    if (!removeCandidates.isEmpty()) {
      final Set<String> accountNumbersWithPendingIsaDeclaration =
          getAccountsWithPendingIsaDeclaration(removeCandidates, date);

      if (!accountNumbersWithPendingIsaDeclaration.isEmpty()) {
        final Map<String, List<AccountWarningRestrictionRule>> filtered =
            getFilteredAccountWarningRules(
                accountWarningRestrictionRulesByAccountNumber,
                removeCandidates,
                accountNumbersWithPendingIsaDeclaration);

        log.info(
            "Filtered account warnings - original: {}, filtered: {}",
            accountWarningRestrictionRulesByAccountNumber,
            filtered);
        return filtered;
      }
    }

    return accountWarningRestrictionRulesByAccountNumber;
  }

  private Map<String, Set<AccountWarningRestrictionRule>> getRemoveCandidates(
      final Map<String, String> productIdentifierByAccountNumber,
      final Map<String, ProductInfo> productInfoByProductIdentifier,
      final Map<String, List<AccountWarningRestrictionRule>>
          accountWarningRestrictionRulesByAccountNumber) {
    return accountWarningRestrictionRulesByAccountNumber.entrySet().stream()
        .filter(
            entry -> {
              final String productIdentifier = productIdentifierByAccountNumber.get(entry.getKey());
              final ProductInfo productInfo = productInfoByProductIdentifier.get(productIdentifier);
              return Objects.equals(productInfo.getProductType(), "ISA");
            })
        .filter(
            entry ->
                entry.getValue().stream()
                    .map(AccountWarningRestrictionRule::getRestrictionTypeCode)
                    .anyMatch(RestrictionType.WARNING_NO_RESTRICTION_CODES::contains))
        .collect(
            Collectors.toMap(
                Map.Entry::getKey,
                entry ->
                    entry.getValue().stream()
                        .filter(
                            warnings ->
                                RestrictionType.WARNING_NO_RESTRICTION_CODES.contains(
                                    warnings.getRestrictionTypeCode()))
                        .collect(Collectors.toSet())));
  }

  private Set<String> getAccountsWithPendingIsaDeclaration(
      final Map<String, Set<AccountWarningRestrictionRule>> removeCandidates,
      final LocalDateTime date) {

    final LocalDateTime retrieveAfter = date.minusDays(1L);

    final Set<String> accountNumbersAsSet = removeCandidates.keySet();
    final Map<Long, String> accountNumberMappings =
        AccountNumberConversion.buildAccountNumberMappings(accountNumbersAsSet);

    log.info("Retrieving pending ISA declaration for accounts: {}", accountNumbersAsSet);

    return savingsTransactionLogRepository
        .findAllAccountsWithEntriesStartingAfterEarliestTime(
            accountNumberMappings.keySet(),
            retrieveAfter,
            SavingsTransactionLogEntry.STATUS_ISA_DECLARATION)
        .stream()
        .map(
            accountNumberLong ->
                AccountNumberConversion.mapAccountNumberToString(
                    accountNumberMappings, accountNumberLong))
        .collect(Collectors.toSet());
  }

  private Map<String, List<AccountWarningRestrictionRule>> getFilteredAccountWarningRules(
      final Map<String, List<AccountWarningRestrictionRule>>
          accountWarningRestrictionRulesByAccountNumber,
      final Map<String, Set<AccountWarningRestrictionRule>> removeCandidates,
      final Set<String> accountNumbersWithPendingIsaDeclaration) {
    return accountWarningRestrictionRulesByAccountNumber.entrySet().stream()
        .collect(
            Collectors.toMap(
                Map.Entry::getKey,
                entry -> {
                  final String accountNumber = entry.getKey();
                  if (accountNumbersWithPendingIsaDeclaration.contains(accountNumber)) {
                    final Set<AccountWarningRestrictionRule> removeWarnings =
                        removeCandidates.get(accountNumber);
                    return entry.getValue().stream()
                        .filter(warning -> !removeWarnings.contains(warning))
                        .collect(Collectors.toList());
                  } else {
                    return entry.getValue();
                  }
                }));
  }
}
