package uk.co.ybs.digital.account.model.adgcore;

import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@Entity
@Table(name = "ACTIVITY_TYPE_GROUPS")
public class ActivityTypeGroup {

  public static final String ACTIVITY_GROUP_CODE_AHLDRS = "AHLDRS";
  public static final String ACTIVITY_GROUP_CODE_AISP = "AISP";
  public static final String ACTIVITY_GROUP_CODE_PISP = "PISP";

  @EmbeddedId @EqualsAndHashCode.Include private PrimaryKey primaryKey;

  @ManyToOne
  @MapsId("activityTypeCode")
  @JoinColumn(name = "ACTTYP_CODE")
  private ActivityType activityType;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  public ActivityTypeGroup(
      final String activityGroupCode,
      final ActivityType activityType,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    this.primaryKey = new PrimaryKey(activityGroupCode, activityType.getCode(), startDate);
    this.activityType = activityType;
    this.endDate = endDate;
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  @Embeddable
  public class PrimaryKey implements Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "ACTGRP_CODE", nullable = false, updatable = false)
    private String activityGroupCode;

    @Column(name = "ACTTYP_CODE", nullable = false, updatable = false)
    private String activityTypeCode;

    @Column(name = "START_DATE", nullable = false, updatable = false)
    private LocalDateTime startDate;
  }
}
