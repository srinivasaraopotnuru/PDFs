package uk.co.ybs.digital.account.service.processor;

import lombok.experimental.UtilityClass;

@UtilityClass
public class AccountProcessorConstants {

  public static final String ENDED_AT = "0795";
  public static final String ENDED_BY = "SAPP";
}
