package uk.co.ybs.digital.account.repository.core;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.account.model.core.Metadata;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public interface MetadataCoreRepository extends JpaRepository<Metadata, Long> {}
