package uk.co.ybs.digital.account.service.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;

@Data
@Builder
@Jacksonized
public class ReinvestmentProduct {

  @Schema(required = true)
  private String productIdentifier;
}
