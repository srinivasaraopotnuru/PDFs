package uk.co.ybs.digital.account.service.utilities;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.repository.frontoffice.SavingsTransactionLogRepository;

@Component
@AllArgsConstructor
public class ManageInterestCalculator {

  private static final List<String> PERMITTED_PRODUCT_TYPES =
      Arrays.asList("SAVER", "ISA", "BOND", "FBOND", "VBOND");

  private static final String WEB_ACCESS_CODE = "WEBACC";
  private SavingsTransactionLogRepository savingsTransactionLogRepository;
  private AccountInstructionsHelper accountInstructionsHelper;

  @SuppressWarnings("PMD.ExcessiveParameterList")
  @Transactional(readOnly = true, transactionManager = "transactionManager")
  public boolean areInterestOptionsPermitted(
      final String accountNumber,
      final String witCode,
      final boolean productAllowsInterestAmendments,
      final Set<String> activityGroupCodeAccountList,
      final String productType,
      final LocalDate closedDate,
      final List<AccountWarningRestrictionRule> restrictionRules) {
    return accountIsSavingsAccount(productType)
        && accountAllowsWebAmendments(restrictionRules, productAllowsInterestAmendments)
        && accountInstructionsHelper.instructionAllowed(
            Long.parseLong(accountNumber), witCode, activityGroupCodeAccountList)
        && accountIsOpen(closedDate, accountNumber);
  }

  private boolean accountAllowsWebAmendments(
      final List<AccountWarningRestrictionRule> restrictionRules,
      final boolean productAllowsInterestAmendments) {
    return restrictionRules.stream()
            .noneMatch(rule -> rule.isRestrictionTypeRuleCode(WEB_ACCESS_CODE))
        && productAllowsInterestAmendments;
  }

  private boolean accountIsSavingsAccount(final String productType) {
    return PERMITTED_PRODUCT_TYPES.contains(productType);
  }

  private boolean accountIsOpen(final LocalDate closedDate, final String accountNumber) {
    return closedDate == null
        && savingsTransactionLogRepository
            .findAccountInClosure(Long.valueOf(accountNumber))
            .isEmpty();
  }
}
