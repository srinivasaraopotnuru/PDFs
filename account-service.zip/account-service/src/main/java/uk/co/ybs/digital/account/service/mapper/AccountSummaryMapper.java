package uk.co.ybs.digital.account.service.mapper;

import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.AccountSummaryMappingBundle;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.web.dto.AccountSummary;

@Component
@AllArgsConstructor
public class AccountSummaryMapper {
  private final CommonAccountMapper commonAccountMapper;
  private final BalanceMapper balanceMapper;
  private final WithdrawalsMapper withdrawalsMapper;
  private final DepositsMapper depositsMapper;
  private final IsaMapper isaMapper;
  private final AmendmentRestrictionMapper amendmentRestrictionMapper;
  private final ProductMapper productMapper;

  public AccountSummary mapAccountSummary(final AccountSummaryMappingBundle bundle) {
    final SavingAccountDetails savingAccountDetails = bundle.getSavingAccountDetails();
    final String accountNumber = savingAccountDetails.getAccountNumber().toString();
    final ProductInfo productInfo = bundle.getProductInfo();
    final boolean productMigrationInProgress = bundle.isProductMigrationInProgress();
    final boolean closed = bundle.isClosed();
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        bundle.getAccountWarningRestrictionRules();

    return AccountSummary.builder()
        .accountNumber(accountNumber)
        .accountName(savingAccountDetails.getAccountName())
        .amendmentRestriction(
            amendmentRestrictionMapper.amendmentRestricted(accountWarningRestrictionRules))
        .accountSortCode(
            commonAccountMapper.convertAndPadSortCode(savingAccountDetails.getSortCode()))
        .currency(savingAccountDetails.getCurrencyCode())
        .externalAccountNumber(commonAccountMapper.internalToExternalAccountNumber(accountNumber))
        .productIdentifier(productInfo.getProductIdentifier())
        .productDescription(productInfo.getCustomerDescription())
        .product(productMapper.map(productInfo))
        .balances(
            balanceMapper.filterAndMapAccountBalanceTypeList(
                bundle.getBalances(),
                withdrawalsMapper.isPermittedOverApi(
                    accountNumber,
                    productInfo,
                    productMigrationInProgress,
                    accountWarningRestrictionRules,
                    bundle.getActivityGroupCodes(),
                    bundle.getAnniversaryWithdrawalLimit(),
                    closed)))
        .deposits(
            depositsMapper.mapSummary(
                accountNumber,
                productInfo,
                productMigrationInProgress,
                accountWarningRestrictionRules,
                closed))
        .withdrawals(
            withdrawalsMapper.mapSummary(
                accountNumber,
                productInfo,
                productMigrationInProgress,
                accountWarningRestrictionRules,
                bundle.getActivityGroupCodes(),
                bundle.getAnniversaryWithdrawalLimit(),
                closed))
        .isa(isaMapper.mapIsa(productInfo, accountNumber))
        .openedDate(bundle.getOpenedDate())
        .build();
  }
}
