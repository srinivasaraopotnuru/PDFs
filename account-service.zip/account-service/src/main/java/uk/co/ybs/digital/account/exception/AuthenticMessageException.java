package uk.co.ybs.digital.account.exception;

public class AuthenticMessageException extends RuntimeException {

  /** Serial Version ID. */
  private static final long serialVersionUID = 1L;

  /** @param errorMessage : String */
  public AuthenticMessageException(final String errorMessage) {
    super(errorMessage);
  }

  /**
   * @param errorMessage : String
   * @param cause - cause of the exception
   */
  public AuthenticMessageException(final String errorMessage, final Throwable cause) {
    super(errorMessage, cause);
  }

  /** @param cause - cause of the exception */
  public AuthenticMessageException(final Throwable cause) {
    super(cause.getMessage(), cause);
  }
}
