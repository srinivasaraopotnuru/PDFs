package uk.co.ybs.digital.account.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ACCOUNT_WARNINGS")
public class AccountWarning {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  private Long sysId;

  @ManyToOne
  @JoinColumn(name = "ACCNUM_ACCOUNT_NUMBER")
  @EqualsAndHashCode.Include
  private AccountNumber accountNumber;

  @ManyToOne
  @JoinColumn(name = "RESTYP_SYSID")
  @EqualsAndHashCode.Include
  private RestrictionType restrictionType;

  @Column(name = "START_DATE", nullable = false)
  @EqualsAndHashCode.Include
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;
}
