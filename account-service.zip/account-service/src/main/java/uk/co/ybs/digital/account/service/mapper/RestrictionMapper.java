package uk.co.ybs.digital.account.service.mapper;

import static uk.co.ybs.digital.account.model.adgcore.RestrictionType.ISA_TRANSFERRED_OUT;
import static uk.co.ybs.digital.account.model.adgcore.RestrictionType.NEW_ACCOUNT_14_DAYS;
import static uk.co.ybs.digital.account.model.adgcore.RestrictionType.NO_RECEIPTS;
import static uk.co.ybs.digital.account.model.adgcore.RestrictionType.NO_SUBSCRIPTIONS;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;
import uk.co.ybs.digital.account.web.dto.Restriction;
import uk.co.ybs.digital.account.web.dto.RestrictionCategory;

@Component
public class RestrictionMapper {

  public List<Restriction> map(
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final String restrictionType) {
    final List<Restriction> resList = new ArrayList<Restriction>();
    accountWarningRestrictionRules.forEach(
        rule -> {
          if (rule.isRestrictionTypeRuleCode(restrictionType)) {
            final Restriction resNew =
                Restriction.builder()
                    .code(getRestrictionDescription(rule))
                    .message(
                        getWebTextForRestriction(
                            accountWarningRestrictionRules, rule.getRestrictionTypeCode()))
                    .restrictionTypes(
                        Stream.of(rule.getRestrictionTypeCode())
                            .collect(Collectors.toCollection(LinkedHashSet::new)))
                    .build();
            final Restriction combi =
                resList.stream().filter(rest -> rest.isMergeable(resNew)).findFirst().orElse(null);
            if (!(combi != null && combi.merge(resNew))) {
              resList.add(resNew);
            }
          }
        });
    return resList;
  }

  private RestrictionCategory getRestrictionDescription(
      final AccountWarningRestrictionRule accountWarningRestrictionRule) {
    final String restrictionTypeCode = accountWarningRestrictionRule.getRestrictionTypeCode();
    if (accountWarningRestrictionRule.isRestrictionTypeRuleCode(
        RestrictionTypeRule.CODE_WEB_RECEIPTS)) {
      return getDepositRestrictionDescription(restrictionTypeCode);
    }
    return getWithdrawalRestrictionDescription(restrictionTypeCode);
  }

  private RestrictionCategory getDepositRestrictionDescription(final String restrictionTypeCode) {
    switch (restrictionTypeCode.toUpperCase(Locale.ROOT)) {
      case NO_SUBSCRIPTIONS:
      case NO_RECEIPTS:
        return RestrictionCategory.DEPOSIT_ISA_DECLARATION;
      case ISA_TRANSFERRED_OUT:
        return RestrictionCategory.DEPOSIT_ISA_TRANSFERRED;
      default:
        return RestrictionCategory.DEPOSIT_DEFAULT;
    }
  }

  private RestrictionCategory getWithdrawalRestrictionDescription(
      final String restrictionTypeCode) {
    if (restrictionTypeCode.equalsIgnoreCase(NEW_ACCOUNT_14_DAYS)) {
      return RestrictionCategory.WITHDRAWAL_NEW_ACCOUNT;
    }
    return RestrictionCategory.WITHDRAWAL_DEFAULT;
  }

  private String getWebTextForRestriction(
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final String restrictionTypeCode) {
    final AccountWarningRestrictionRule webTxtRule =
        accountWarningRestrictionRules.stream()
            .filter(
                rule ->
                    rule.isRestrictionTypeRuleCode(RestrictionTypeRule.CODE_WEB_TEXT)
                        && rule.getRestrictionTypeCode().equals(restrictionTypeCode))
            .findFirst()
            .orElse(null);
    return webTxtRule != null ? webTxtRule.getRestrictionTypeRuleCharValue() : null;
  }
}
