package uk.co.ybs.digital.account.service.mapper;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.web.dto.WithdrawalLimit;

@Component
@Slf4j
@AllArgsConstructor
public class WithdrawalsPermittedOverApiMapper {
  @SuppressWarnings("PMD.ExcessiveParameterList")
  public boolean withdrawalPermittedOverApi(
      final String accountNumber,
      final boolean productAllowsWithdrawals,
      final boolean productMigrationInProgress,
      final boolean withdrawalsBlockedByAccountWarnings,
      final Set<String> activityGroups,
      final WithdrawalLimit withdrawalLimit,
      final boolean accountClosed) {

    final boolean isPispActivityPlayer =
        activityGroups.contains(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);

    final boolean withdrawalLimitReached =
        withdrawalLimit != null && withdrawalLimit.getAvailable() == 0;

    final boolean withdrawalPermittedOverApi =
        productAllowsWithdrawals
            && !productMigrationInProgress
            && !accountClosed
            && !withdrawalsBlockedByAccountWarnings
            && isPispActivityPlayer
            && !withdrawalLimitReached;
    if (!withdrawalPermittedOverApi) {
      log.info(
          "Withdrawals not permitted for account number {}. productAllowsWithdrawals: {}, productMigrationInProgress: {}, accountClosed: {}, "
              + "withdrawalsBlockedByAccountWarnings: {}, isPispActivityPlayer: {}, withdrawalLimitReached: {}",
          accountNumber,
          productAllowsWithdrawals,
          productMigrationInProgress,
          accountClosed,
          withdrawalsBlockedByAccountWarnings,
          isPispActivityPlayer,
          withdrawalLimitReached);
    }

    return withdrawalPermittedOverApi;
  }
}
