package uk.co.ybs.digital.account.repository.adgcore;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.adgcore.Account;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;

public interface AccountNumberRepository extends JpaRepository<AccountNumber, Long> {
  @Query(
      "SELECT an "
          + "FROM AccountNumber an "
          + "JOIN ActivityPlayer ap ON an.accountNumber = ap.tableSysId AND an.tableId = 'SAVACC' "
          + "JOIN SavingAccount sa ON an.accountNumber = sa.accountNumber "
          + "JOIN SavingProduct sp ON an.savingProductSysId = sp.sysid "
          + "WHERE ap.partySysId = :partyId "
          + "AND ap.endDate IS NULL "
          + "AND ap.tableId = 'ACCNUM' "
          + "AND sp.brandCode IN :brandCodes "
          + "AND (sa.closedDate IS NULL OR sa.closedDate > :earliestDate)")
  Collection<AccountNumber>
      findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
          @Param("partyId") Long partyId,
          @Param("brandCodes") Collection<String> brandCodes,
          @Param("earliestDate") LocalDateTime earliestDate);

  @Query(
      "SELECT distinct new uk.co.ybs.digital.account.model.adgcore.Account(an.accountNumber, sa.openedDate) "
          + "FROM AccountNumber an "
          + "JOIN ActivityPlayer ap ON an.accountNumber = ap.tableSysId "
          + "LEFT JOIN SavingAccount sa ON an.accountNumber = sa.accountNumber "
          + "WHERE ap.partySysId IN ( :partyId ) "
          + "AND an.tableId IN ( :accountType )"
          + " AND ap.startDate <= :now AND (ap.endDate > :now OR ap.endDate IS NULL) ")
  List<Account> findAccountNumbersByPartyIdAndAccountType(
      @Param("partyId") List<Long> partyId,
      @Param("accountType") List<String> accountType,
      @Param("now") LocalDateTime now);
}
