package uk.co.ybs.digital.account.model.copy;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "RESTRICTION_TYPES")
public class RestrictionType {
  private static final String NO_SUBSCRIPTIONS = "NOSUBS";

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  private Long sysId;

  @Column(name = "CODE", nullable = false)
  @EqualsAndHashCode.Include
  private String code;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDate endDate;
}
