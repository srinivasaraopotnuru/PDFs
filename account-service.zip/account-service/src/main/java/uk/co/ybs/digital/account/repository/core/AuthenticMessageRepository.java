package uk.co.ybs.digital.account.repository.core;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.account.exception.AuthenticMessageException;
import uk.co.ybs.digital.logging.calls.CallLogged;

/** This repository interface has a method to call stored procedure PACK_ATM.PR_WRITE_MESSAGE. */
@Slf4j
@Repository
@CallLogged(logParameters = true)
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public class AuthenticMessageRepository {

  private static final String SPACE = " ";
  private static final String POSITIVE = "+";
  private static final int ZERO = 0;

  @PersistenceContext(unitName = "coreEntityManagerFactory")
  private transient EntityManager coreEntityManagerFactory;

  public int writeAuthenticMessage(
      final String hostType,
      final String productSysId,
      final Long accNum,
      final String status,
      final int function,
      final LocalDateTime currentDateTime)
      throws AuthenticMessageException {

    try {
      final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dMMuu");
      final Integer busAndTransactionDate =
          Integer.valueOf(currentDateTime.format(DateTimeFormatter.ofPattern("dMMuu")));
      final Integer transactionTime =
          Integer.valueOf(currentDateTime.format(DateTimeFormatter.ofPattern("HHmmss")));

      final StoredProcedureQuery query =
          coreEntityManagerFactory
              .createStoredProcedureQuery("PACK_ATM.PR_WRITE_MESSAGE")
              .registerStoredProcedureParameter("PN_STREAM_ID", Long.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PS_HOST_TYPE", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PS_PROD_CODE", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_FEP_HOST", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_RELATIVE_REC", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_BUS_DDMMYY", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_TXN_DDMMYY", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_TIME_HHMMSS", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_ACNT_NUM", Long.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_AMOUNT", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_LEDGER_BAL", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PS_LBALSIGN", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_AVAILABLE_BAL", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PS_ABALSIGN", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PS_PAN", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PS_TXN_CATEGORY", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PS_TXN_DESC", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PS_STATUS", String.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_FUNCTION", Integer.class, ParameterMode.IN)
              .registerStoredProcedureParameter("PN_EXPIRY_DATE", Integer.class, ParameterMode.IN)
              .setParameter("PN_STREAM_ID", null)
              .setParameter("PS_HOST_TYPE", hostType)
              .setParameter("PS_PROD_CODE", productSysId)
              .setParameter("PN_FEP_HOST", ZERO)
              .setParameter("PN_RELATIVE_REC", ZERO)
              .setParameter("PN_BUS_DDMMYY", busAndTransactionDate)
              .setParameter("PN_TXN_DDMMYY", busAndTransactionDate)
              .setParameter("PN_TIME_HHMMSS", transactionTime)
              .setParameter("PN_ACNT_NUM", accNum)
              .setParameter("PN_AMOUNT", ZERO)
              .setParameter("PN_LEDGER_BAL", ZERO)
              .setParameter("PS_LBALSIGN", POSITIVE)
              .setParameter("PN_AVAILABLE_BAL", ZERO)
              .setParameter("PS_ABALSIGN", POSITIVE)
              .setParameter("PS_PAN", null)
              .setParameter("PS_TXN_CATEGORY", SPACE)
              .setParameter("PS_TXN_DESC", SPACE)
              .setParameter("PS_STATUS", status)
              .setParameter("PN_FUNCTION", function)
              .setParameter("PN_EXPIRY_DATE", ZERO);
      final int resultCode = query.executeUpdate();

      return resultCode;
    } catch (final Exception e) {
      log.error("Exception when sending message to Authentic", e);
      throw new AuthenticMessageException(e);
    }
  }
}
