package uk.co.ybs.digital.account.repository.adgcore;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.adgcore.AccountWarning;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;

@SuppressWarnings("PMD.AvoidDuplicateLiterals")
public interface AccountWarningRepository extends JpaRepository<AccountWarning, Long> {

  @Query(
      "SELECT new uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule(an.accountNumber, rt.code, rtr.code, rtr.charValue) "
          + "FROM AccountWarning aw "
          + "JOIN aw.accountNumber an "
          + "JOIN aw.restrictionType rt "
          + "JOIN RestrictionTypeRule rtr ON rtr.restrictionType = rt "
          + "WHERE rtr.code IN :restrictionTypeRuleCodes "
          + "AND aw.startDate <= :now "
          + "AND (aw.endDate > :now OR aw.endDate IS NULL) "
          + "AND rt.startDate <= :now "
          + "AND (rt.endDate > :now OR rt.endDate IS NULL) "
          + "AND rtr.startDate <= :now "
          + "AND (rtr.endDate > :now OR rtr.endDate IS NULL) "
          + "AND an.accountNumber IN :accountNumbers "
          + "ORDER BY an.accountNumber DESC, aw.startDate, rtr.code ")
  Collection<AccountWarningRestrictionRule>
      findAccountWarningRestrictionRulesByAccountNumbersAndDate(
          @Param("accountNumbers") Collection<Long> accountNumbers,
          @Param("restrictionTypeRuleCodes") Collection<String> restrictionTypeRuleCodes,
          @Param("now") LocalDateTime now);

  @Query(
      "SELECT aw "
          + "FROM AccountWarning aw "
          + "JOIN aw.accountNumber an "
          + "JOIN aw.restrictionType rt "
          + "WHERE aw.startDate <= :now "
          + "AND (aw.endDate > :now OR aw.endDate IS NULL) "
          + "AND rt.startDate <= :now "
          + "AND (rt.endDate > :now OR rt.endDate IS NULL) "
          + "AND an.accountNumber in ( :accountNumber ) ")
  Collection<AccountWarning> findActiveAccountWarningsByAccountNumberAndDate(
      @Param("accountNumber") List<Long> accountNumber, @Param("now") LocalDateTime now);

  @Query(
      "SELECT aw "
          + "FROM AccountWarning aw "
          + "JOIN aw.accountNumber an "
          + "JOIN aw.restrictionType rt "
          + "WHERE rt.code IN :restrictionTypeCodes "
          + "AND aw.startDate <= :now "
          + "AND (aw.endDate > :now OR aw.endDate IS NULL) "
          + "AND rt.startDate <= :now "
          + "AND (rt.endDate > :now OR rt.endDate IS NULL) "
          + "AND an.accountNumber = :accountNumber ")
  Collection<AccountWarning> findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
      @Param("accountNumber") Long accountNumber,
      @Param("restrictionTypeCodes") Collection<String> restrictionTypeCodes,
      @Param("now") LocalDateTime now);

  @Query(
      "SELECT aw "
          + "FROM AccountWarning aw "
          + "JOIN aw.accountNumber an "
          + "JOIN aw.restrictionType rt "
          + "WHERE aw.startDate <= :now "
          + "AND rt.startDate <= :now "
          + "AND an.accountNumber in ( :accountNumber ) ")
  Collection<AccountWarning> findAccountWarningsByAccountNumberAndDate(
      @Param("accountNumber") List<Long> accountNumber, @Param("now") LocalDateTime now);
}
