package uk.co.ybs.digital.account.service.mapper;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.exception.AccountTransactionMapperException;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransaction;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactions;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType.BalanceConstants;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransaction;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransactions;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse.Amount;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse.Meta;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse.Transaction;

@Component
@RequiredArgsConstructor
@Slf4j
public class AccountTransactionsMapper {
  private final BalanceMapper balanceMapper;

  private static final int DEFAULT_PAGE_SIZE = 10;

  private AccountTransactionsResponse.Transaction mapAdgTransaction(
      final StatementTransaction transaction) {
    return Transaction.builder()
        .accountNumber(transaction.getAccountNumber().toString())
        .transactionId(transaction.getTransactionId().toString())
        .transactionReference(transaction.getTransactionRef())
        .creditDebitIndicator(
            map(transaction.getTransactionAmount(), transaction.getTransactionIndicator()))
        .status(transaction.getStatus())
        .bookingDateTime(map(transaction.getBookingDate()))
        .valueDateTime(map(transaction.getValueDate()))
        .amount(
            Amount.builder()
                .amount(map(transaction.getTransactionAmount()))
                .currency("GBP")
                .build())
        .transactionCode(mapTransactionCode(transaction))
        .transactionInformation(transaction.getInformation())
        .balances(
            balanceMapper.filterAndMapAccountBalanceTypeList(
                Arrays.asList(
                    AccountBalanceType.builder()
                        .balanceType(BalanceConstants.TYPE_CAPITAL_AVAILABLE)
                        .balanceAmount(transaction.getAvailableBalanceAfterTxn())
                        .build(),
                    AccountBalanceType.builder()
                        .balanceType(BalanceConstants.TYPE_CAPITAL_LEDGER)
                        .balanceAmount(transaction.getLedgerBalanceAfterTxn())
                        .build())))
        .build();
  }

  private AccountTransactionsResponse.Transaction mapAuthenticTransaction(
      final AuthenticTransaction transaction) {

    return Transaction.builder()
        .accountNumber(transaction.getAccountNumber())
        .transactionId(transaction.getTransactionID())
        .transactionReference(transaction.getTransactionDesc())
        .creditDebitIndicator(transaction.getCreditorDebitIndicator())
        .status("Booked")
        .bookingDateTime(map(transaction.getTransactionBookingDateTime()))
        .amount(
            Amount.builder()
                .amount(map(transaction.getFinancialTransactionAmount()))
                .currency("GBP")
                .build())
        .transactionInformation(transaction.getTransactionDesc())
        .balances(
            balanceMapper.filterAndMapAccountBalanceTypeList(
                Collections.singletonList(
                    AccountBalanceType.builder()
                        .balanceType(BalanceConstants.TYPE_CAPITAL_LEDGER)
                        .balanceAmount(transaction.getBalanceAmount())
                        .build())))
        .build();
  }

  private Instant map(final LocalDateTime dateTime) {
    if (dateTime != null) {
      return dateTime.atZone(ZoneId.of("GMT")).toInstant();
    }
    return null;
  }

  private String map(final BigDecimal amount) {
    // Credit or Debit indicator determines if the transaction amount is negative or positive
    return amount.abs().toString();
  }

  private String map(final BigDecimal amount, final String indicator) {
    final String returnValue;
    if (amount.intValue() > 0) {
      returnValue = "Credit";
    } else if (amount.intValue() < 0) {
      returnValue = "Debit";
    } else {
      if ("R".equals(indicator)) {
        returnValue = "Credit";
      } else if ("W".equals(indicator)) {
        returnValue = "Debit";
      } else {
        throw new AccountTransactionMapperException(
            String.format("Unable to map credit-debit value %s %s", amount, indicator));
      }
    }
    return returnValue;
  }

  private AccountTransactionsResponse.TransactionCode mapTransactionCode(
      final StatementTransaction transaction) {
    final String transactionTypeCode = transaction.getTransactionTypeCode();
    final String transactionTypeMethod = transaction.getTransactionMethod();

    if (transactionTypeCode != null || transactionTypeMethod != null) {
      return AccountTransactionsResponse.TransactionCode.builder()
          .code(transactionTypeCode)
          .method(transactionTypeMethod)
          .build();
    } else {
      return null;
    }
  }

  public AccountTransactionsResponse getTransactionsToResponse(
      final AuthenticTransactions authenticTransactions,
      final StatementTransactions statementTransactions) {

    final List<AccountTransactionsResponse.Transaction> allTransactions =
        authenticTransactions.getTransactionList().stream()
            .map(this::mapAuthenticTransaction)
            .collect(Collectors.toList());

    allTransactions.addAll(
        statementTransactions.getTransactionList().stream()
            .map(this::mapAdgTransaction)
            .collect(Collectors.toList()));

    final int totalTransactions =
        authenticTransactions.getTotalNumberOfRecords()
            + statementTransactions.getTotalNumberOfTransactions();

    final int totalPages = getTotalPages(totalTransactions);

    return AccountTransactionsResponse.builder()
        .transactions(allTransactions)
        .meta(Meta.builder().totalPages(totalPages).totalTransactions(totalTransactions).build())
        .build();
  }

  public AccountTransactionsResponse getTransactionsToResponse(
      final StatementTransactions statementTransactions) {
    final List<AccountTransactionsResponse.Transaction> allTransactions =
        statementTransactions.getTransactionList().stream()
            .map(this::mapAdgTransaction)
            .collect(Collectors.toList());

    final int totalTransactions = statementTransactions.getTotalNumberOfTransactions();

    final int totalPages = getTotalPages(totalTransactions);

    return AccountTransactionsResponse.builder()
        .transactions(allTransactions)
        .meta(Meta.builder().totalPages(totalPages).totalTransactions(totalTransactions).build())
        .build();
  }

  // This method is required to round the number up. Math.ceil doesn't work for ints
  private int getTotalPages(final int value) {
    if (value == 0) {
      return 1;
    }
    return value / DEFAULT_PAGE_SIZE + ((value % DEFAULT_PAGE_SIZE == 0) ? 0 : 1);
  }
}
