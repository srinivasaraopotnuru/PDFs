package uk.co.ybs.digital.account.service.utilities;

import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMMENCE;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMPLETE;

import com.google.common.collect.ImmutableSet;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.model.adgcore.Country;
import uk.co.ybs.digital.account.repository.adgcore.CountryRepository;
import uk.co.ybs.digital.account.repository.adgcore.TessaDetailsRepository;
import uk.co.ybs.digital.account.repository.frontoffice.SavingsTransactionLogRepository;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.web.dto.DepositLimit;

@Component
@AllArgsConstructor
@Slf4j
@Transactional(readOnly = true, transactionManager = "transactionManager")
public class DepositByCardCalculator {

  private static final List<String> UK_ISO_COUNTRY_CODES = Arrays.asList("GB", "JE", "GG", "IM");
  private static final String[] DEPOSIT_ALLOWED_FOR_NON_ISA_WIT_CODES =
      new String[] {
        "ONE", "SSIGN", "ED", "ANO", "AN1", "AOTS", "ETW", "JSIGN", "AS", "BTS", "AN2", "ATS",
        "ATTS", "AOATO", "ALLATO", "ATOTS", "AETS", "ROTS", "AN3"
      };

  private static final Set<String> ACTIVITY_GROUP_CODES_ACCOUNT_LIST =
      ImmutableSet.of(
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_AISP,
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP,
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS);

  private static final List<String> IN_CLOSURE_PROCESS_STATUSES =
      Arrays.asList(STATUS_CLOSE_COMMENCE, STATUS_CLOSE_COMPLETE);

  private CountryRepository countryRepository;
  private TessaDetailsRepository tessaDetailsRepository;

  private AccountInstructionsHelper accountInstructionsHelper;
  private SavingsTransactionLogRepository savingsTransactionLogRepository;

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public boolean isDepositByCardPermitted(
      final Long accountNumber,
      final Long partyId,
      final LocalDateTime now,
      final ProductInfo productInfo,
      final boolean depositsBlockedByAccountWarnings,
      final String witCode,
      final DepositLimit depositLimit,
      final boolean accountClosed) {

    if (!productInfo.getDeposits().isPermittedByCard()) {
      log.debug(
          "Deposit by card not permitted for account {} as not allowed on products", accountNumber);
      return false;
    }

    if (depositsBlockedByAccountWarnings) {
      log.debug(
          "Deposit by card not permitted for account {} as deposits blocked by account warnings.",
          accountNumber);
      return false;
    }

    if (accountAtDepositLimit(depositLimit)) {
      log.debug(
          "Deposit by card not permitted for account {} as account is at the deposit limit.",
          accountNumber);
      return false;
    }

    if (accountClosed) {
      log.debug(
          "Deposit by card not permitted for account {} as account is closed.", accountNumber);
      return false;
    }

    if (accountIsInClosureProcess(accountNumber)) {
      log.debug(
          "Deposit by card not permitted for account {} as account is in closure process.",
          accountNumber);
      return false;
    }

    if (!witCodeAllowsDeposits(
        accountNumber, witCode, "ISA".equals(productInfo.getProductType()))) {
      log.debug(
          "Deposit by card not permitted for account {} as wit code {} does not allow deposits.",
          accountNumber,
          witCode);
      return false;
    }

    if (partyIsSubscribedToOtherIsa(accountNumber, productInfo, partyId)) {
      log.debug(
          "Deposit by card not permitted for account {} as party {} is subscribed to other ISA",
          accountNumber,
          partyId);
      return false;
    }

    return (isFlexIsa(productInfo) || partyIsUkResident(partyId, now));
  }

  private boolean accountAtDepositLimit(final DepositLimit depositLimit) {
    return depositLimit != null
        && (accountDepositLimitReached(depositLimit) || productMaxBalanceReached(depositLimit));
  }

  private boolean accountDepositLimitReached(final DepositLimit depositLimit) {
    return depositLimit.getAvailable() != null
        && depositLimit.getAvailable().compareTo(BigDecimal.ZERO) <= 0;
  }

  private boolean productMaxBalanceReached(final DepositLimit depositLimit) {
    return depositLimit.getMaxProductBalRemaining() != null
        && depositLimit.getMaxProductBalRemaining().compareTo(BigDecimal.ZERO) <= 0;
  }

  private boolean witCodeAllowsDeposits(
      final Long accountNumber, final String witCode, final boolean isIsa) {
    if (isIsa) {
      return accountInstructionsHelper.instructionAllowed(
          accountNumber, witCode, ACTIVITY_GROUP_CODES_ACCOUNT_LIST);
    } else {
      return Arrays.asList(DEPOSIT_ALLOWED_FOR_NON_ISA_WIT_CODES).contains(witCode);
    }
  }

  private boolean isFlexIsa(final ProductInfo productInfo) {
    return productInfo.getIsa() != null && Boolean.TRUE.equals(productInfo.getIsa().getFlexible());
  }

  private boolean partyIsUkResident(final Long partyId, final LocalDateTime now) {
    final List<Country> countries = countryRepository.findCountriesForPartyId(partyId, now);
    if (countries.isEmpty()) {
      log.debug("Deposit by card not permitted as no country found for partyId {}", partyId);
      return false;
    } else if (!UK_ISO_COUNTRY_CODES.contains(countries.get(0).getIsoCode())) {
      log.debug(
          "Deposit by card not permitted as country {} of partyId {} is non-UK",
          countries.get(0).getIsoCode(),
          partyId);
      return false;
    }

    return true;
  }

  private boolean partyIsSubscribedToOtherIsa(
      final Long accountNumber, final ProductInfo productInfo, final Long partyId) {
    return productInfo.getIsa() != null
        && productInfo.getIsa().getIsaYear() != null
        && tessaDetailsRepository.existsOtherSubscriptionsInIsaYear(
            accountNumber, productInfo.getIsa().getIsaYear(), partyId);
  }

  private boolean accountIsInClosureProcess(final Long accountNumber) {
    return !savingsTransactionLogRepository
        .findEntriesByStatus(accountNumber, IN_CLOSURE_PROCESS_STATUSES)
        .isEmpty();
  }
}
