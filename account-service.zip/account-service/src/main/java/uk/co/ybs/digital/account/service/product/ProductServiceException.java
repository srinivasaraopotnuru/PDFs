package uk.co.ybs.digital.account.service.product;

public class ProductServiceException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public ProductServiceException(final String message) {
    super(message);
  }

  public ProductServiceException(final String message, final Throwable ex) {
    super(message, ex);
  }
}
