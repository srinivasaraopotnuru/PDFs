package uk.co.ybs.digital.account.model.core;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.ColumnTransformer;

@Data
@Builder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "WARNING_NOTES")
public class WarningNote {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "WN_SYSID_SEQ")
  @SequenceGenerator(sequenceName = "WN_SYSID_SEQ", allocationSize = 1, name = "WN_SYSID_SEQ")
  private Long sysId;

  @Column(name = "ACCWAR_SYSID", nullable = false)
  private Long accountWarningSysId;

  @Column(name = "NOTES", nullable = false)
  @ColumnTransformer(write = "UPPER(?)")
  private String notes;

  @Column(name = "CREATED_AT", nullable = false)
  private String createdAt;

  @Column(name = "CREATED_DATE", nullable = false)
  private LocalDateTime createdDate;

  @Column(name = "CREATED_BY", nullable = false)
  private String createdBy;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDate endDate;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Column(name = "ENDED_AT")
  private String endedAt;

  @Column(name = "ENDED_BY")
  private String endedBy;
}
