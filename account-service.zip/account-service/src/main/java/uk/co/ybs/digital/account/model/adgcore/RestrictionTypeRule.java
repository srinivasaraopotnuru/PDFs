package uk.co.ybs.digital.account.model.adgcore;

import com.google.common.collect.ImmutableSet;
import java.time.LocalDateTime;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "RESTYP_RULES")
public class RestrictionTypeRule {
  public static final String CODE_WEB_RECEIPTS = "WEBREC";
  public static final String CODE_WEB_WITHDRAWALS = "WEBWDL";
  public static final String CODE_WEB_TEXT = "WEBTXT";
  public static final String CODE_WEB_ACCESS = "WEBACC";
  public static final String CODE_WEB_REGISTER = "WEBREG";
  public static final String CODE_ISA_TRANSFER = "ISATFR";

  public static final Set<String> KNOWN_CODES =
      ImmutableSet.of(
          CODE_WEB_RECEIPTS,
          CODE_WEB_WITHDRAWALS,
          CODE_WEB_TEXT,
          CODE_WEB_ACCESS,
          CODE_WEB_REGISTER,
          CODE_ISA_TRANSFER);

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  private Long sysId;

  @Column(name = "AVLRUL_CODE", nullable = false)
  @EqualsAndHashCode.Include
  private String code;

  @Column(name = "CHAR_VALUE", nullable = false)
  private String charValue;

  @ManyToOne
  @JoinColumn(name = "RESTYP_SYSID")
  @EqualsAndHashCode.Include
  private RestrictionType restrictionType;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  @EqualsAndHashCode.Include
  private LocalDateTime endDate;
}
