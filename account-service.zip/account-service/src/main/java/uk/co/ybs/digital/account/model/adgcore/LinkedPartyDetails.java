package uk.co.ybs.digital.account.model.adgcore;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@SqlResultSetMapping(
    name = LinkedPartyDetails.LINKED_PARTY_DETAILS_RESULT_SET_MAPPING,
    entities =
        @EntityResult(
            entityClass = LinkedPartyDetails.class,
            fields = {@FieldResult(name = "partyId", column = "SYSID")}))
@NamedNativeQuery(
    name = LinkedPartyDetails.LINKED_PARTY_DETAILS_QUERY,
    resultSetMapping = LinkedPartyDetails.LINKED_PARTY_DETAILS_RESULT_SET_MAPPING,
    query = "SELECT LP.SYSID FROM PACK_WEB_LOGON.FN_GET_LINKED_PARTIES(?1) LP ")
public class LinkedPartyDetails {
  public static final String LINKED_PARTY_DETAILS_QUERY = "findLinkedParties";
  public static final String LINKED_PARTY_DETAILS_RESULT_SET_MAPPING = "LinkedPartyDetails";

  @Id private Long partyId;
}
