package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.Instant;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = AccountTransactionsResponse.AccountTransactionsResponseBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountTransactionsResponse {
  @JsonProperty(value = "transaction")
  List<Transaction> transactions;

  Meta meta;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AccountTransactionsResponseBuilder {}

  @Value
  @Builder
  @JsonDeserialize(builder = Transaction.TransactionBuilder.class)
  public static class Transaction {
    @Schema(required = true, example = "1234567890")
    String accountNumber;

    @Schema(example = "786374157")
    String transactionId;

    @Schema(example = "50000000032367")
    String transactionReference;

    @Schema(required = true, example = "Credit")
    String creditDebitIndicator;

    @Schema(required = true, example = "Booked")
    String status;

    @Schema(
        required = true,
        type = "string",
        format = "date-time",
        example = "2017-12-20T01:00:00Z")
    Instant bookingDateTime;

    @Schema(type = "string", format = "date-time", example = "2017-12-20T01:00:00Z")
    Instant valueDateTime;

    @Schema(required = true)
    Amount amount;

    @Schema(required = true)
    TransactionCode transactionCode;

    @Schema(example = "Direct Debit in")
    String transactionInformation;

    @Schema(required = true)
    @JsonProperty(value = "balance")
    List<Balance> balances;

    @Schema(example = "0.055")
    String interestRate;

    @Schema(
        description = "Flag to determine if blended interest rate was used over new interest rate")
    Boolean blendedFlag;

    @JsonPOJOBuilder(withPrefix = "")
    public static class TransactionBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Meta.MetaBuilder.class)
  public static class Meta {
    @Schema(example = "1")
    int totalPages;

    @Schema(example = "2")
    int totalTransactions;

    @JsonPOJOBuilder(withPrefix = "")
    public static class MetaBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Amount.AmountBuilder.class)
  @SuppressWarnings("PMD.AvoidFieldNameMatchingTypeName")
  public static class Amount {
    @Schema(required = true, example = "999999999.99")
    String amount;

    @Schema(required = true, example = "GBP")
    String currency;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AmountBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = TransactionCode.TransactionCodeBuilder.class)
  public static class TransactionCode {
    @Schema(required = true, example = "0037")
    String code;

    @Schema(required = true, example = "TFR")
    String method;

    @JsonPOJOBuilder(withPrefix = "")
    public static class TransactionCodeBuilder {}
  }
}
