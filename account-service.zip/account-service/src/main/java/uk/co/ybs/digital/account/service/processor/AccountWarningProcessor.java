package uk.co.ybs.digital.account.service.processor;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException.Reason;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.WarningNote;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.adgcore.RestrictionTypeRepository;
import uk.co.ybs.digital.account.repository.core.AccountWarningCoreRepository;
import uk.co.ybs.digital.account.repository.core.WarningNoteCoreRepository;

@Component
@RequiredArgsConstructor
@Transactional("accountProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
@Slf4j
public class AccountWarningProcessor {

  private final AccountNumberRepository accountNumberRepository;
  private final AccountWarningCoreRepository accountWarningCoreRepository;
  private final RestrictionTypeRepository restrictionTypeRepository;
  private final WarningNoteCoreRepository warningNoteCoreRepository;

  public AccountNumber resolve(final AccountWarningRequestArguments arguments) {

    final Long accountNumber = arguments.getAccountNumber();

    return accountNumberRepository
        .findById(accountNumber)
        .orElseThrow(
            () ->
                (new AccountNotFoundException(
                    "Failed to find account " + accountNumber + " in the database")));
  }

  public void execute(
      final AccountWarningRequestArguments arguments, final AccountNumber accountNumber) {
    final RestrictionType restrictionType =
        restrictionTypeRepository
            .findByCode(arguments.getWarningCode())
            .orElseThrow(() -> (new AccountRequestProcessingException(Reason.WARNING_NOT_FOUND)));

    final AccountWarning accountWarningCore =
        AccountWarning.builder()
            .accountNumber(
                uk.co.ybs.digital.account.model.core.AccountNumber.builder()
                    .accountNumber(arguments.getAccountNumber())
                    .savingProductSysId(accountNumber.getSavingProductSysId())
                    .tableId(accountNumber.getTableId())
                    .build())
            .startDate(arguments.getProcessTime())
            .createdAt(arguments.getCreatedAt())
            .createdBy(arguments.getCreatedBy())
            .createdDate(arguments.getProcessTime())
            .restrictionType(
                uk.co.ybs.digital.account.model.core.RestrictionType.builder()
                    .sysId(restrictionType.getSysId())
                    .code(restrictionType.getCode())
                    .build())
            .build();
    log.info(
        "Creating warning {} for user {}",
        arguments.getWarningCode(),
        arguments.getAccountNumber());
    accountWarningCoreRepository.saveAndFlush(accountWarningCore);

    if (arguments.getNotes() != null) {
      final WarningNote warningNote =
          WarningNote.builder()
              .accountWarningSysId(accountWarningCore.getSysId())
              .notes(arguments.getNotes())
              .startDate(arguments.getProcessTime())
              .createdAt(arguments.getCreatedAt())
              .createdBy(arguments.getCreatedBy())
              .createdDate(arguments.getProcessTime())
              .build();
      warningNoteCoreRepository.saveAndFlush(warningNote);
    }
  }
}
