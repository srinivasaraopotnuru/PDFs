package uk.co.ybs.digital.account.service.utilities;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.repository.adgcore.ActivityPlayerRepository;

/**
 * Class used to determine whether account closure, interest amendment or deposit to ISA
 * instructions are allowed based on witCode and whether the account is a joint account.
 */
@Component
@AllArgsConstructor
public class AccountInstructionsHelper {

  private static final String SIGNATURE_CARD_WIT_CODE = "CONV";
  private static final List<String> EXCLUDED_ACTIVITY_TYPES = Arrays.asList("DSCAUT", "POA");
  private static final List<String> SINGLE_SIGNATURE_WIT_CODES =
      Arrays.asList("ED", "ANO", "AN1", "AOTS", "ETW", "JSIGN", "AOATO", "ATOTS", "AORTO", "ROTS");

  private ActivityPlayerRepository activityPlayerRepository;

  private Clock clock;

  public boolean instructionAllowed(
      final Long accountNumber, final String witCode, final Set<String> activityGroups) {
    return doesNotReferToSignatureCard(witCode)
        && (canBeOperatedBySingleSignature(witCode)
            || isNotJointAccount(accountNumber, activityGroups));
  }

  private boolean doesNotReferToSignatureCard(final String witCode) {
    return !SIGNATURE_CARD_WIT_CODE.equals(witCode);
  }

  private boolean canBeOperatedBySingleSignature(final String witCode) {
    return SINGLE_SIGNATURE_WIT_CODES.contains(witCode);
  }

  private boolean isNotJointAccount(final Long accountNumber, final Set<String> activityGroups) {
    return activityPlayerRepository
            .getAllActivityPlayers(activityGroups, accountNumber, LocalDateTime.now(clock)).stream()
            .filter(
                activityPlayer ->
                    !EXCLUDED_ACTIVITY_TYPES.contains(activityPlayer.getActivityType().getCode()))
            .count()
        == 1;
  }
}
