package uk.co.ybs.digital.account.service.utilities;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.adgcore.SavingTransaction;
import uk.co.ybs.digital.account.model.adgcore.TessaDetails;
import uk.co.ybs.digital.account.repository.adgcore.SavingTransactionRepository;
import uk.co.ybs.digital.account.repository.adgcore.TessaDetailsRepository;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AuthenticService;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransaction;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;

@Component
@RequiredArgsConstructor
@Slf4j
public class AvailableDepositLimitCalculator {

  @NonNull private final SavingTransactionRepository savingTransactionRepository;
  @NonNull private final TessaDetailsRepository tessaDetailsRepository;
  @NonNull private final AuthenticService authenticService;
  @NonNull private final PeriodStartCalculator periodStartCalculator;

  public BigDecimal calculateRemainingDepositLimit(
      final String accountNumber,
      final boolean accountClosed,
      final boolean productMigrationInProgress,
      final ProductInfo productInfo,
      final List<AccountWarningRestrictionRule> restrictionRules,
      final LocalDateTime now) {
    final ProductInfo.Deposits deposits = productInfo.getDeposits();
    if (accountClosed
        || productMigrationInProgress
        || deposits == null
        || !deposits.isPermittedInternal()
        || deposits.getLimits() == null) {
      return null;
    }

    // In the worst case we will get the last 2 days worth of transactions from Authentic
    final LocalDateTime authenticTransactionBufferPeriod = now.minusDays(2L);
    final List<BigDecimal> remainingLimits = new ArrayList<>();
    final ProductInfo.AmountPeriodLimits periodLimits = deposits.getLimits().getAmount();
    if (periodLimits.getMonth() != null) {
      remainingLimits.add(
          calculateMonthlyRemainingDepositLimit(
              accountNumber, productInfo, restrictionRules, now, authenticTransactionBufferPeriod));
    }
    if (periodLimits.getTaxYear() != null) {
      remainingLimits.add(
          calculateTaxYearRemainingDepositLimit(
              accountNumber, productInfo, restrictionRules, now, authenticTransactionBufferPeriod));
    }

    final BigDecimal remaining =
        remainingLimits.stream()
            .min(BigDecimal::compareTo)
            .map(remainingLimit -> remainingLimit.max(BigDecimal.ZERO))
            .orElse(null);

    log.info("Calculated remaining deposit limit for account {}: {}", accountNumber, remaining);

    return remaining;
  }

  public BigDecimal calculateRemainingMaxProductBalance(
      final String accountNumber,
      final boolean accountClosed,
      final boolean productMigrationInProgress,
      final ProductInfo productInfo,
      final Optional<AccountBalanceType> ledgerBalanceType) {
    final ProductInfo.Deposits deposits = productInfo.getDeposits();
    if (accountClosed
        || productMigrationInProgress
        || deposits == null
        || !deposits.isPermittedInternal()
        || productInfo.getBalance() == null) {
      return null;
    }

    final BigDecimal maxProductBalance = productInfo.getBalance().getMax();
    if (maxProductBalance == null) {
      log.info(
          "Max product balance does not exist for account - {}, product - {} ",
          accountNumber,
          productInfo.getProductIdentifier());
      return null;
    }

    final BigDecimal ledgerBalance =
        ledgerBalanceType.isPresent()
            ? ledgerBalanceType.get().getBalanceAmount()
            : BigDecimal.valueOf(0);
    final BigDecimal remaining = maxProductBalance.subtract(ledgerBalance);
    log.info(
        "Calculated remaining max product balance for account {} - remaining: {}, max product balance "
            + "allowed: {}, ledger balance: {}",
        accountNumber,
        remaining,
        maxProductBalance,
        ledgerBalance);

    return remaining;
  }

  private BigDecimal calculateMonthlyRemainingDepositLimit(
      final String accountNumber,
      final ProductInfo productInfo,
      final List<AccountWarningRestrictionRule> restrictionRules,
      final LocalDateTime now,
      final LocalDateTime authenticTransactionBufferPeriod) {
    final LocalDateTime periodStart = periodStartCalculator.getMonthStart(now);
    final LocalDateTime retrieveAfter =
        getLatestDateTime(periodStart, authenticTransactionBufferPeriod);

    final Map<Long, SavingTransaction> savingTransactions =
        savingTransactionRepository
            .findSavingTransactionsInPeriod(
                Long.parseLong(accountNumber),
                periodStart,
                SavingTransaction.DEPOSIT_SUM_EXCLUDED_TRANSACTION_TYPES)
            .stream()
            .collect(Collectors.toMap(SavingTransaction::getSysid, Function.identity()));
    log.info("Saving transaction ids for period: {}", savingTransactions.keySet());

    final Map<String, AuthenticTransaction> authenticTransactions =
        authenticService.getTransactions(accountNumber, retrieveAfter, now, true, false, null, null)
            .getTransactionList().stream()
            .collect(Collectors.toMap(AuthenticTransaction::getTransactionID, Function.identity()));
    log.info("Authentic transactions ids for period: {}", authenticTransactions.keySet());

    authenticTransactions
        .keySet()
        .removeAll(
            savingTransactions.keySet().stream().map(String::valueOf).collect(Collectors.toList()));
    log.info(
        "Authentic transaction ids for period after deduplication: {}",
        authenticTransactions.keySet());

    final BigDecimal savingTransactionAmountDeposited =
        savingTransactions.values().stream()
            .map(SavingTransaction::getTransactionAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

    final BigDecimal authenticAmountDeposited =
        authenticTransactions.values().stream()
            .map(AuthenticTransaction::getFinancialTransactionAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

    final BigDecimal amountDeposited =
        savingTransactionAmountDeposited.add(authenticAmountDeposited);
    final BigDecimal periodLimit = productInfo.getDeposits().getLimits().getAmount().getMonth();
    final BigDecimal isaAdjustedLimit =
        getIsaAdjustedLimit(periodLimit, productInfo, restrictionRules);
    final BigDecimal remaining = isaAdjustedLimit.subtract(amountDeposited);

    log.info(
        "Calculated month remaining deposit limit for account {} - periodStart: {}, amountDeposited: {}, "
            + "savingTransactionAmountDeposited: {}, authenticAmountDeposited: {}, periodLimit: {}, "
            + "isaAdjustedLimit: {}, remaining: {}",
        accountNumber,
        periodStart,
        amountDeposited,
        savingTransactionAmountDeposited,
        authenticAmountDeposited,
        periodLimit,
        isaAdjustedLimit,
        remaining);

    return remaining;
  }

  private BigDecimal calculateTaxYearRemainingDepositLimit(
      final String accountNumber,
      final ProductInfo productInfo,
      final List<AccountWarningRestrictionRule> restrictionRules,
      final LocalDateTime now,
      final LocalDateTime authenticTransactionBufferPeriod) {
    final LocalDateTime periodStart = periodStartCalculator.getTaxYearStart(now);
    final Integer isaYear = productInfo.getIsa().getIsaYear();
    final Optional<TessaDetails> tessaDetailsOptional =
        tessaDetailsRepository.findActiveByAccountNumberAndTessaYear(
            Long.parseLong(accountNumber), isaYear);

    final Long tessaDetailsSysId;
    final BigDecimal dbAmountDeposited;
    final BigDecimal previousYearFlexibility;
    final LocalDateTime tessaCreatedDate;
    if (tessaDetailsOptional.isPresent()) {
      final TessaDetails tessaDetails = tessaDetailsOptional.get();
      tessaDetailsSysId = tessaDetails.getSysid();
      dbAmountDeposited = tessaDetails.getAmountInvested();
      previousYearFlexibility =
          Optional.ofNullable(tessaDetails.getPreviousYearFlexibility()).orElse(BigDecimal.ZERO);
      tessaCreatedDate =
          getLatestDateTime(tessaDetails.getCreatedDate(), authenticTransactionBufferPeriod);
    } else {
      tessaDetailsSysId = null;
      dbAmountDeposited = BigDecimal.ZERO;
      previousYearFlexibility = BigDecimal.ZERO;
      tessaCreatedDate = authenticTransactionBufferPeriod;
    }

    final LocalDateTime retrieveAfter = getLatestDateTime(periodStart, tessaCreatedDate);

    final Map<String, AuthenticTransaction> authenticTransactions =
        authenticService.getTransactions(accountNumber, retrieveAfter, now, true, false, null, null)
            .getTransactionList().stream()
            .collect(Collectors.toMap(AuthenticTransaction::getTransactionID, Function.identity()));
    log.info("Authentic transaction ids for period: {}", authenticTransactions.keySet());

    if (authenticTransactions.size() > 0) {
      final Map<Long, SavingTransaction> savingTransactions =
          savingTransactionRepository
              .findSavingTransactionsInPeriod(
                  Long.parseLong(accountNumber),
                  periodStart,
                  SavingTransaction.DEPOSIT_SUM_EXCLUDED_TRANSACTION_TYPES)
              .stream()
              .collect(Collectors.toMap(SavingTransaction::getSysid, Function.identity()));
      log.info("Saving transaction ids for period: {}", savingTransactions.keySet());

      savingTransactions.keySet().stream()
          .map(String::valueOf)
          .collect(Collectors.toList())
          .forEach(authenticTransactions.keySet()::remove);

      log.info(
          "Authentic transaction ids for period after deduplication: {}",
          authenticTransactions.keySet());
    }

    final BigDecimal authenticAmountDeposited =
        authenticTransactions.values().stream()
            .map(AuthenticTransaction::getFinancialTransactionAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

    final BigDecimal amountDeposited = dbAmountDeposited.add(authenticAmountDeposited);
    final BigDecimal periodLimit = productInfo.getDeposits().getLimits().getAmount().getTaxYear();
    final BigDecimal isaAdjustedLimit =
        getIsaAdjustedLimit(periodLimit, productInfo, restrictionRules);
    final BigDecimal flexibilityAdjustedLimit = isaAdjustedLimit.add(previousYearFlexibility);
    final BigDecimal remaining = flexibilityAdjustedLimit.subtract(amountDeposited);

    log.info(
        "Calculated tax year remaining deposit limit for account {} - isaYear: {}, tessaDetailsSysId: {}, "
            + "amountDeposited: {}, authenticAmountDeposited: {}, "
            + "previousYearFlexibility: {}, periodLimit: {}, isaAdjustedLimit: {}, "
            + "flexibilityAdjustedLimit: {}, remaining: {}",
        accountNumber,
        isaYear,
        tessaDetailsSysId,
        amountDeposited,
        authenticAmountDeposited,
        previousYearFlexibility,
        periodLimit,
        isaAdjustedLimit,
        flexibilityAdjustedLimit,
        remaining);

    return remaining;
  }

  private BigDecimal getIsaAdjustedLimit(
      final BigDecimal periodLimit,
      final ProductInfo productInfo,
      final List<AccountWarningRestrictionRule> restrictionRules) {
    final boolean zeroPeriodLimit =
        isFlexibleIsaWithWarningOfTypeNoDeclaration(productInfo, restrictionRules);
    if (zeroPeriodLimit) {
      log.info("Flexible ISA without declaration, ignoring period limit {}", periodLimit);
    }
    return zeroPeriodLimit ? BigDecimal.ZERO : periodLimit;
  }

  private boolean isFlexibleIsaWithWarningOfTypeNoDeclaration(
      final ProductInfo productInfo, final List<AccountWarningRestrictionRule> restrictionRules) {
    return productInfo.getIsa() != null
        && productInfo.getIsa().getFlexible()
        && restrictionRules.stream()
            .map(AccountWarningRestrictionRule::getRestrictionTypeCode)
            .anyMatch(RestrictionType.WARNING_NO_RESTRICTION_CODES::contains);
  }

  private static LocalDateTime getLatestDateTime(
      final LocalDateTime localDateTime, final LocalDateTime anotherLocalDateTime) {
    return localDateTime.isAfter(anotherLocalDateTime) ? localDateTime : anotherLocalDateTime;
  }
}
