package uk.co.ybs.digital.account.service.authentic;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum AccountStatus {
  OPEN("O"),
  CLOSED("C"),
  NOT_FOUND("U");

  @Getter private final String statusCode;
}
