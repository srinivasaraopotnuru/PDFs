package uk.co.ybs.digital.account.exception;

public class AccountNoCustomerRelationshipException extends AccountAccessDeniedException {

  private static final long serialVersionUID = -5851431956285843576L;

  public AccountNoCustomerRelationshipException(final String message) {
    super(message);
  }
}
