package uk.co.ybs.digital.account.model.frontoffice;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.GenerationTime;
import uk.co.ybs.digital.account.model.OracleSequence;

@Builder
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "E_SAVINGS_TRANSACTION_LOGS")
public class SavingsTransactionLogEntry {

  public static final String STATUS_PRODUCT_TRANSFER_START = "PRODUCT_TRANSFER_START";
  public static final String STATUS_PRODUCT_TRANSFER_END = "PRODUCT_TRANSFER_END";
  public static final String STATUS_PRODUCT_TRANSFER_FAILED = "PRODUCT_TRANSFER_FAILED";
  public static final String STATUS_CLOSE_COMMENCE = "CLOSE_COMMENCE";
  public static final String STATUS_CLOSE_COMPLETE = "CLOSE_COMPLETE";
  public static final String STATUS_ISA_DECLARATION = "ISA_DECLARATION";
  public static final String STATUS_ACCOUNT_NAME_CHANGE_COMPLETE = "ACCOUNT_NAME_CHANGE_COMPLETE";
  public static final String STATUS_ADD_REGULAR_INTERNAL_TRANSFER = "ADD_REGULAR_INTERNAL_TRANSFER";
  public static final String STATUS_AMEND_REGULAR_INTERNAL_TRANSFER =
      "AMND_REGULAR_INTERNAL_TRANSFER";
  public static final String STATUS_REMOVE_REGULAR_INTERNAL_TRANSFER =
      "REM_REGULAR_INTERNAL_TRANSFER";
  public static final String STATUS_DEPOSIT_COMMENCE = "DEPOSIT_COMMENCE";
  public static final String STATUS_DEPOSIT_COMPLETED = "DEPOSIT_COMPLETED";

  public static final String CLOSURE_NO = "N";

  public static final String TRANSFER_INDICATOR_INTERNAL = "I";

  public static final Set<String> STATUSES_PRODUCT_MIGRATION =
      Collections.unmodifiableSet(
          new HashSet<>(
              Arrays.asList(
                  STATUS_PRODUCT_TRANSFER_START,
                  STATUS_PRODUCT_TRANSFER_END,
                  STATUS_PRODUCT_TRANSFER_FAILED)));

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ESTL_SYSID_SEQ")
  @SequenceGenerator(sequenceName = "ESTL_SYSID_SEQ", allocationSize = 1, name = "ESTL_SYSID_SEQ")
  @EqualsAndHashCode.Include // Generated ids's are bad for equality in JPA, but nothing else unique
  private Long sysId;

  @Column(name = "ACCOUNT_NUMBER", nullable = false)
  private Long accountNumber;

  @Column(name = "TRANS_START_DATE", nullable = false)
  private LocalDateTime startTime;

  @Column(name = "TRANS_END_DATE")
  private LocalDateTime endTime;

  @Column(name = "TRANSFER_IND", nullable = false)
  private String transferIndicator;

  @Column(name = "TARGET_ACCOUNT_NUMBER", nullable = false)
  private Long targetAccountNumber;

  @Column(name = "CLOSURE", nullable = false)
  private String closure;

  @Column(name = "AMOUNT", nullable = false)
  private BigDecimal amount;

  @Column(name = "ACCOUNT_NAME")
  private String accountName;

  // Some nasty hibernate specific generator stuff because JPA doesn't support @GeneratedValue
  // on non 'Id' columns
  @OracleSequence(sequenceName = "ESTL_DAILY_SEQ_NUM", generationTime = GenerationTime.INSERT)
  @Column(name = "DAILY_SEQ_NUM", nullable = false, updatable = false)
  private Long dailySequenceNumber;

  @Column(name = "PARTY_SYSID", nullable = false)
  private Long partySysId;

  @Column(name = "STATUS")
  private String status;

  @Column(name = "DATE_PROCESSED")
  private LocalDateTime dateProcessed;
}
