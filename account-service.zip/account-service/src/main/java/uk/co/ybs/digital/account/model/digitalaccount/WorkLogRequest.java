package uk.co.ybs.digital.account.model.digitalaccount;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WorkLogRequest {
  @NonNull WorkLogPayload workLogPayload;
  @NonNull RequestMetadata metadata;
}
