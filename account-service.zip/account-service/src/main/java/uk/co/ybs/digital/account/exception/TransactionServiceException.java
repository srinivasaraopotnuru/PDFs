package uk.co.ybs.digital.account.exception;

public class TransactionServiceException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public TransactionServiceException(final String message) {
    super(message);
  }
}
