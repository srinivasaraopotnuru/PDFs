package uk.co.ybs.digital.account.service.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.web.dto.PermittedRule;
import uk.co.ybs.digital.account.web.dto.PermittedRulesCode;
import uk.co.ybs.digital.account.web.dto.Restriction;
import uk.co.ybs.digital.account.web.dto.RestrictionCategory;
import uk.co.ybs.digital.account.web.dto.WithdrawalLimit;
import uk.co.ybs.digital.account.web.dto.Withdrawals;
import uk.co.ybs.digital.account.web.dto.WithdrawalsSummary;

@Component
@AllArgsConstructor
@Slf4j
public class WithdrawalsMapper {
  private final WithdrawalLimitMapper withdrawalLimitMapper;
  private final WithdrawalsPermittedOverApiMapper withdrawalsPermittedOverApiMapper;
  private final RestrictionMapper restrictionMapper;

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public Withdrawals map(
      final String accountNumber,
      final ProductInfo productInfo,
      final boolean productMigrationInProgress,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final Set<String> activityGroups,
      final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit,
      final boolean accountClosed) {
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final boolean withdrawalsBlockedByAccountWarnings =
        withdrawalsBlockedByAccountWarnings(accountWarningRestrictionRules);
    final WithdrawalLimit withdrawalLimit = getWithdrawalLimit(savingAccountAnnualWithdrawalLimit);
    final boolean permittedOverApi =
        isPermittedOverApi(
            accountNumber,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroups,
            savingAccountAnnualWithdrawalLimit,
            accountClosed);

    return Withdrawals.builder()
        .permittedOverApi(permittedOverApi)
        .permittedRules(
            buildPermittedRules(
                productAllowsWithdrawals,
                productMigrationInProgress,
                withdrawalsBlockedByAccountWarnings,
                accountClosed))
        .limit(withdrawalLimit)
        .restrictions(getRestrictions(productInfo, accountWarningRestrictionRules))
        .interestPenalty(getInterestPenalty(productInfo))
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public WithdrawalsSummary mapSummary(
      final String accountNumber,
      final ProductInfo productInfo,
      final boolean productMigrationInProgress,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final Set<String> activityGroups,
      final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit,
      final boolean accountClosed) {

    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final boolean withdrawalsBlockedByAccountWarnings =
        withdrawalsBlockedByAccountWarnings(accountWarningRestrictionRules);
    final boolean permittedOverApi =
        isPermittedOverApi(
            accountNumber,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroups,
            savingAccountAnnualWithdrawalLimit,
            accountClosed);

    return WithdrawalsSummary.builder()
        .permittedOverApi(permittedOverApi)
        .permittedRules(
            buildPermittedRules(
                productAllowsWithdrawals,
                productMigrationInProgress,
                withdrawalsBlockedByAccountWarnings,
                accountClosed))
        .build();
  }

  private WithdrawalLimit getWithdrawalLimit(
      final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit) {
    return Optional.ofNullable(savingAccountAnnualWithdrawalLimit)
        .filter(limit -> limit.getYearStart() != null)
        .map(withdrawalLimitMapper::mapWithdrawalLimit)
        .orElse(null);
  }

  private List<Restriction> getRestrictions(
      final ProductInfo productInfo,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules) {
    final List<Restriction> restrictions =
        restrictionMapper.map(
            accountWarningRestrictionRules, RestrictionTypeRule.CODE_WEB_WITHDRAWALS);

    final List<Restriction> allRestrictions = new ArrayList<>(restrictions);
    if (productInfo.getWithdrawals().getInterestPenalty() != null) {
      allRestrictions.add(
          Restriction.builder().code(RestrictionCategory.WITHDRAWAL_INTEREST_PENALTY).build());
    }

    if (allRestrictions.isEmpty()) {
      return null; // NOPMD
    } else {
      return allRestrictions;
    }
  }

  private Withdrawals.InterestPenalty getInterestPenalty(final ProductInfo productInfo) {
    return Optional.ofNullable(productInfo.getWithdrawals().getInterestPenalty())
        .map(
            interestPenalty ->
                Withdrawals.InterestPenalty.builder().days(interestPenalty.getDays()).build())
        .orElse(null);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public boolean isPermittedOverApi(
      final String accountNumber,
      final ProductInfo productInfo,
      final boolean productMigrationInProgress,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final Set<String> activityGroups,
      final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit,
      final boolean accountClosed) {
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final boolean withdrawalsBlockedByAccountWarnings =
        withdrawalsBlockedByAccountWarnings(accountWarningRestrictionRules);
    final WithdrawalLimit withdrawalLimit = getWithdrawalLimit(savingAccountAnnualWithdrawalLimit);
    final Optional<SavingAccountAnnualWithdrawalLimit> optionalWithdrawalLimits =
        Optional.ofNullable(savingAccountAnnualWithdrawalLimit);

    if (optionalWithdrawalLimits.isPresent()
        && !optionalWithdrawalLimits
            .map(SavingAccountAnnualWithdrawalLimit::getYearStart)
            .isPresent()) {
      log.info(
          "Withdrawals not permitted for account: {} as year start is not specified",
          accountNumber);
      return false;
    }

    return withdrawalsPermittedOverApiMapper.withdrawalPermittedOverApi(
        accountNumber,
        productAllowsWithdrawals,
        productMigrationInProgress,
        withdrawalsBlockedByAccountWarnings,
        activityGroups,
        withdrawalLimit,
        accountClosed);
  }

  private boolean withdrawalsBlockedByAccountWarnings(
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules) {
    final List<AccountWarningRestrictionRule> blockedBy =
        accountWarningRestrictionRules.stream()
            .filter(this::blocksWithdrawals)
            .collect(Collectors.toList());

    final boolean blocked = !blockedBy.isEmpty();

    if (blocked) {
      log.info("Withdrawals blocked by account warning restrictions rules: {}", blockedBy);
    }

    return blocked;
  }

  private boolean blocksWithdrawals(
      final AccountWarningRestrictionRule accountWarningRestrictionRule) {
    return accountWarningRestrictionRule.isRestrictionTypeRuleCode(
        RestrictionTypeRule.CODE_WEB_WITHDRAWALS);
  }

  private List<PermittedRule> buildPermittedRules(
      final boolean productAllowsWithdrawals,
      final boolean productMigrationInProgress,
      final boolean withdrawalsBlockedByAccountWarnings,
      final boolean accountClosed) {
    final List<PermittedRule> permittedRules = new ArrayList<>();
    permittedRules.add(
        PermittedRule.builder()
            .code(PermittedRulesCode.PRODUCT_ALLOWED.getCode())
            .allowed(productAllowsWithdrawals)
            .build());
    permittedRules.add(
        PermittedRule.builder()
            .code(PermittedRulesCode.ACCOUNT_MIGRATION.getCode())
            .allowed(productMigrationInProgress)
            .build());
    permittedRules.add(
        PermittedRule.builder()
            .code(PermittedRulesCode.ACCOUNT_WARNING.getCode())
            .allowed(withdrawalsBlockedByAccountWarnings)
            .build());
    permittedRules.add(
        PermittedRule.builder()
            .code(PermittedRulesCode.ACCOUNT_CLOSED.getCode())
            .allowed(accountClosed)
            .build());

    return permittedRules;
  }
}
