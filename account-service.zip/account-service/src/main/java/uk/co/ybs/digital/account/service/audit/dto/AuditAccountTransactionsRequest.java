package uk.co.ybs.digital.account.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(
    builder = AuditAccountTransactionsRequest.AuditAccountTransactionsRequestBuilder.class)
public class AuditAccountTransactionsRequest {
  @NonNull private final String ipAddress;
  @NonNull private final AccountInformation accountInformation;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditAccountTransactionsRequestBuilder {}

  @Value
  @Builder
  @JsonDeserialize(builder = AccountInformation.AccountInformationBuilder.class)
  public static class AccountInformation {
    @NonNull private final String accountNumber;
    private final String startDate;
    private final String endDate;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AccountInformationBuilder {}
  }
}
