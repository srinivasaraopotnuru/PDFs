package uk.co.ybs.digital.account.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = AuditAccountListRequest.AuditAccountListRequestBuilder.class)
public class AuditAccountListRequest {
  @NonNull private final String ipAddress;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditAccountListRequestBuilder {}
}
