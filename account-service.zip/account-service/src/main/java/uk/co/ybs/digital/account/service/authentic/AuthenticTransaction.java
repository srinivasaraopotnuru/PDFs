package uk.co.ybs.digital.account.service.authentic;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuthenticTransaction {
  String transactionID;
  String authUid;
  BigDecimal financialTransactionAmount;
  String transactionDesc;
  LocalDateTime transactionBookingDateTime;
  BigDecimal balanceAmount;
  String balanceType;
  String creditorDebitIndicator;
  String accountNumber;
}
