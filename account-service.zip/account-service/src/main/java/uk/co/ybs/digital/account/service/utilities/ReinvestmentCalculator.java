package uk.co.ybs.digital.account.service.utilities;

import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_ADD_REGULAR_INTERNAL_TRANSFER;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_AMEND_REGULAR_INTERNAL_TRANSFER;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMMENCE;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMPLETE;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_DEPOSIT_COMMENCE;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_DEPOSIT_COMPLETED;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_REMOVE_REGULAR_INTERNAL_TRANSFER;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.TRANSFER_INDICATOR_INTERNAL;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.repository.copy.MetadataCopyRepository;
import uk.co.ybs.digital.account.repository.frontoffice.SavingsTransactionLogRepository;
import uk.co.ybs.digital.account.service.product.ProductService;
import uk.co.ybs.digital.account.service.product.ProductServiceException;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Component
@AllArgsConstructor
@Slf4j
@Transactional(readOnly = true, transactionManager = "transactionManager")
public class ReinvestmentCalculator {
  private static final String SAVER = "SAVER";
  private static final List<String> PENDING_TRANSACTION_STATUSES =
      Arrays.asList(STATUS_DEPOSIT_COMMENCE, STATUS_DEPOSIT_COMPLETED);
  private static final List<String> REGULAR_TRANSFER_STATUSES =
      Arrays.asList(
          STATUS_ADD_REGULAR_INTERNAL_TRANSFER,
          STATUS_AMEND_REGULAR_INTERNAL_TRANSFER,
          STATUS_REMOVE_REGULAR_INTERNAL_TRANSFER);
  private static final List<String> IN_CLOSURE_PROCESS_STATUSES =
      Arrays.asList(STATUS_CLOSE_COMMENCE, STATUS_CLOSE_COMPLETE);

  private ProductService productService;
  private SavingsTransactionLogRepository savingsTransactionLogRepository;
  private MetadataCopyRepository metadataCopyRepository;

  public boolean isReinvestmentPermitted(
      final String accountNumber,
      final String productIdentifier,
      final String productType,
      final LocalDate closedDate,
      final RequestMetadata metadata) {

    if (!SAVER.equals(productType)) {
      if (accountIsInValidState(accountNumber, closedDate)) {
        return isProductReinvestable(metadata, productIdentifier);
      }
    }
    return false;
  }

  private boolean isProductReinvestable(
      final RequestMetadata metadata, final String productIdentifier) {
    try {
      return !productService
          .getReinvestmentProducts(metadata, productIdentifier)
          .getReinvestmentProducts()
          .isEmpty();
    } catch (ProductServiceException ex) {
      log.info(
          "Product service response -> current product {} is not reinvestable: {}",
          productIdentifier,
          ex.getCause() != null ? ex.getCause().getMessage() : ex.getMessage());
      return false;
    }
  }

  private boolean accountIsInValidState(final String accountNumber, final LocalDate closedDate) {

    final LocalDateTime copyDbUpdateDate = metadataCopyRepository.findAll().get(0).getCreated();
    return accountIsOpen(closedDate, accountNumber)
        && accountHasNoPendingTransactions(accountNumber, copyDbUpdateDate)
        && accountHasNoRegularTransfersInProgress(accountNumber, copyDbUpdateDate);
  }

  private boolean accountIsOpen(final LocalDate closedDate, final String accountNumber) {
    return closedDate == null
        && savingsTransactionLogRepository
            .findEntriesByStatus(Long.valueOf(accountNumber), IN_CLOSURE_PROCESS_STATUSES)
            .isEmpty();
  }

  private boolean accountHasNoPendingTransactions(
      final String accountNumber, final LocalDateTime copyDbUpdateDate) {
    return savingsTransactionLogRepository
        .findEntriesEndingAtOrAfterTimeByStatuses(
            Long.valueOf(accountNumber), PENDING_TRANSACTION_STATUSES, copyDbUpdateDate)
        .isEmpty();
  }

  private boolean accountHasNoRegularTransfersInProgress(
      final String accountNumber, final LocalDateTime copyDbUpdateDate) {
    return savingsTransactionLogRepository
        .findUnprocessedEntriesStartingAtOrAfterTimeByStatusesAndTransferIndicator(
            Long.valueOf(accountNumber),
            REGULAR_TRANSFER_STATUSES,
            TRANSFER_INDICATOR_INTERNAL,
            copyDbUpdateDate)
        .isEmpty();
  }
}
