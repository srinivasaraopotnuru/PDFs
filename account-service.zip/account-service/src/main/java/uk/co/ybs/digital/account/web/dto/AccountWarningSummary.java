package uk.co.ybs.digital.account.web.dto;

import java.time.LocalDateTime;
import java.util.Set;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class AccountWarningSummary {
  private String accountNumber;
  private LocalDateTime openedDate;
  private Set<Warning> accountWarnings;
}
