package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = PermittedRule.PermittedRuleBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class PermittedRule {
  @Schema(required = true)
  String code;

  @Schema(required = true)
  boolean allowed;

  @JsonPOJOBuilder(withPrefix = "")
  public static class PermittedRuleBuilder {}
}
