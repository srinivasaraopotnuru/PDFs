package uk.co.ybs.digital.account.repository.adgcore;

public class SoaSavingsAccountException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public SoaSavingsAccountException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
