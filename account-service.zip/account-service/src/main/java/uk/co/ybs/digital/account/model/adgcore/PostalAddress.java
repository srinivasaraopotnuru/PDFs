package uk.co.ybs.digital.account.model.adgcore;

import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name = "POSTAL_ADDRESSES")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class PostalAddress {

  @Id
  @Column(name = "SYSID")
  @EqualsAndHashCode.Include
  private Long sysId;

  @ManyToOne
  @JoinColumn(name = "CNTRY_CODE")
  private Country country;

  @OneToMany(mappedBy = "postalAddress")
  @ToString.Exclude
  private Set<AddressUsage> usages;
}
