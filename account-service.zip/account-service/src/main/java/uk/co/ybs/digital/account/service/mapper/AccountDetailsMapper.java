package uk.co.ybs.digital.account.service.mapper;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.AccountClosureMapper;
import uk.co.ybs.digital.account.web.dto.AccountDetails;
import uk.co.ybs.digital.account.web.dto.Interest;
import uk.co.ybs.digital.account.web.dto.InterestTier;
import uk.co.ybs.digital.account.web.dto.Reinvestment;

@Component
@AllArgsConstructor
public class AccountDetailsMapper {
  private final CommonAccountMapper commonAccountMapper;
  private final BalanceMapper balanceMapper;
  private final WithdrawalsMapper withdrawalsMapper;
  private final DepositsMapper depositsMapper;
  private final IsaMapper isaMapper;
  private final AccountClosureMapper accountClosureMapper;
  private final AmendmentRestrictionMapper amendmentRestrictionMapper;
  private final ProductMapper productMapper;

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public AccountDetails accountSummaryResponseTypeToAccount(
      final SavingAccountDetails accountSummary,
      final List<AccountBalanceType> balances,
      final ProductInfo productInfo,
      final boolean productMigrationInProgress,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final Set<String> activityGroups,
      final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit,
      final boolean accountClosed,
      final BigDecimal remainingDepositLimit,
      final BigDecimal maxProductBalRemaining,
      final LocalDate openedDate,
      final Reinvestment reinvestment,
      final Boolean interestOptionsPermitted,
      final String witCode,
      final Long partyId,
      final LocalDateTime now) {
    final String accountNumber = accountSummary.getAccountNumber().toString();

    return AccountDetails.builder()
        .accountNumber(accountNumber)
        .accountName(accountSummary.getAccountName())
        .accountSortCode(commonAccountMapper.convertAndPadSortCode(accountSummary.getSortCode()))
        .currency(accountSummary.getCurrencyCode())
        .externalAccountNumber(commonAccountMapper.internalToExternalAccountNumber(accountNumber))
        .openedDate(openedDate)
        .closedDate(accountSummary.getClosedDate())
        .productIdentifier(productInfo.getProductIdentifier())
        .productDescription(productInfo.getCustomerDescription())
        .product(productMapper.map(productInfo))
        .balances(
            balanceMapper.filterAndMapAccountBalanceTypeList(
                balances,
                withdrawalsMapper.isPermittedOverApi(
                    accountNumber,
                    productInfo,
                    productMigrationInProgress,
                    accountWarningRestrictionRules,
                    activityGroups,
                    savingAccountAnnualWithdrawalLimit,
                    accountClosed)))
        .deposits(
            depositsMapper.map(
                accountNumber,
                productInfo,
                productMigrationInProgress,
                accountWarningRestrictionRules,
                accountClosed,
                remainingDepositLimit,
                maxProductBalRemaining,
                partyId,
                now,
                witCode))
        .withdrawals(
            withdrawalsMapper.map(
                accountNumber,
                productInfo,
                productMigrationInProgress,
                accountWarningRestrictionRules,
                activityGroups,
                savingAccountAnnualWithdrawalLimit,
                accountClosed))
        .isa(isaMapper.mapIsa(productInfo, accountNumber))
        .interest(mapInterest(accountSummary, productInfo, interestOptionsPermitted))
        .reinvestment(reinvestment)
        .closure(
            accountClosureMapper.map(
                productInfo,
                accountWarningRestrictionRules,
                accountSummary.getClosedDate(),
                accountNumber,
                activityGroups,
                witCode))
        .amendmentRestriction(
            amendmentRestrictionMapper.amendmentRestricted(accountWarningRestrictionRules))
        .build();
  }

  private Interest mapInterest(
      final SavingAccountDetails accountDetails,
      final ProductInfo productInfo,
      final boolean interestOptionsPermitted) {
    if (accountDetails.getInterestRate() == null
        && accountDetails.getNextInterestDate() == null
        && accountDetails.getInterestFrequency() == null
        && accountDetails.getAccountInterestFrequency() == null
        && accountDetails.getAnnualEquivalentRate() == null
        && accountDetails.getInterestInstruction() == null
        && !interestOptionsPermitted) {
      return null;
    } else {

      if (productInfo.getSmartTiered()) {
        return Interest.builder()
            .interestInstruction(accountDetails.getInterestInstruction())
            .nextPaymentDate(accountDetails.getNextInterestDate())
            .calculationFrequency(accountDetails.getInterestFrequency())
            .applicationFrequency(accountDetails.getAccountInterestFrequency())
            .interestTiers(
                productInfo.getInterest().getTiers().stream()
                    .map(
                        product ->
                            InterestTier.builder()
                                .interestRate(String.valueOf(product.getRate()))
                                .annualEquivalentRate(String.valueOf(product.getRate()))
                                .rangeLow(product.getRangeLow())
                                .rangeHigh(product.getRangeHigh())
                                .build())
                    .collect(Collectors.toList()))
            .interestOptionsPermitted(interestOptionsPermitted)
            .build();
      }
      return Interest.builder()
          .interestInstruction(accountDetails.getInterestInstruction())
          .nextPaymentDate(accountDetails.getNextInterestDate())
          .calculationFrequency(accountDetails.getInterestFrequency())
          .applicationFrequency(accountDetails.getAccountInterestFrequency())
          .interestTiers(
              Collections.singletonList(
                  InterestTier.builder()
                      .interestRate(accountDetails.getInterestRate())
                      .annualEquivalentRate(accountDetails.getAnnualEquivalentRate())
                      .build()))
          .interestOptionsPermitted(interestOptionsPermitted)
          .build();
    }
  }
}
