package uk.co.ybs.digital.account.service.processor;

public interface AccountRequest {
  ResolvedAccountRequest resolve();

  default void auditFailure(final String message) {};
}
