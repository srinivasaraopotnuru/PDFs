package uk.co.ybs.digital.account.web.dto;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Warning {

  String code;

  String description;

  LocalDateTime endDate;
}
