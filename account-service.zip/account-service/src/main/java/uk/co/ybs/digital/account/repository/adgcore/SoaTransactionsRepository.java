package uk.co.ybs.digital.account.repository.adgcore;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.account.model.adgcore.db.SqlArrayValue;
import uk.co.ybs.digital.account.model.adgcore.db.SqlReturnStructArray;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransaction;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactionMapper;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactions;
import uk.co.ybs.digital.account.web.dto.TransactionDates;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Slf4j
@Repository
@CallLogged(logParameters = true)
public class SoaTransactionsRepository {

  private final transient SimpleJdbcCall getTransactionsCall;

  public SoaTransactionsRepository(final DataSource adgCoreDataSource) {

    getTransactionsCall =
        new SimpleJdbcCall(adgCoreDataSource)
            .withProcedureName("SOA_SAVINGSACCOUNT_DATA.PR_GET_TRANSACTIONS")
            .withoutProcedureColumnMetaDataAccess()
            .declareParameters(new SqlParameter("pn_savacc_number", Types.NUMERIC))
            .declareParameters(new SqlParameter("pd_trans_from_date", Types.DATE))
            .declareParameters(new SqlParameter("pd_trans_to_date", Types.DATE))
            .declareParameters(new SqlParameter("ps_include_credit", Types.VARCHAR))
            .declareParameters(new SqlParameter("ps_include_debit", Types.VARCHAR))
            .declareParameters(new SqlParameter("pn_from_record", Types.VARCHAR))
            .declareParameters(new SqlParameter("pn_to_record", Types.VARCHAR))
            .declareParameters(
                new SqlParameter("tbl_soa_excluded_txns", Types.ARRAY, "SOA_TBL_EXCLUDED_TXNS"))
            .declareParameters(
                new SqlOutParameter(
                    "tbl_soa_txn_stmt",
                    Types.ARRAY,
                    "SOA_TBL_TXN_STMT",
                    new SqlReturnStructArray<>(new StatementTransactionMapper())))
            .declareParameters(new SqlOutParameter("pn_total_transactions", Types.NUMERIC))
            .declareParameters(new SqlOutParameter("pn_total_pages", Types.NUMERIC))
            .declareParameters(new SqlOutParameter("ps_brand_code", Types.VARCHAR));
  }

  public StatementTransactions getTransactions(
      final Long accountNumber,
      final int recordFrom,
      final int recordTo,
      final TransactionDates transactionDates) {

    // If we ever need to exclude codes, use the commented out line
    // FinancialTransactionCodeWrapper[] excludedCodes = {new
    // FinancialTransactionCodeWrapper("9999")};

    final Map<String, Object> in = new HashMap<>();
    in.put("pn_savacc_number", accountNumber);
    in.put("pd_trans_from_date", transactionDates.getStartDate());
    in.put("pd_trans_to_date", transactionDates.getEndDate());
    in.put("ps_include_credit", "Y");
    in.put("ps_include_debit", "Y");
    in.put("pn_from_record", recordFrom);
    in.put("pn_to_record", recordTo);
    in.put("tbl_soa_excluded_txns", new SqlArrayValue<>(null));

    final Map<String, Object> statement;

    final StatementTransactions statementTransactions;
    try {
      statement = getTransactionsCall.execute(in);

      final Object[] transactions = (Object[]) statement.get("tbl_soa_txn_stmt");
      final BigDecimal totalTransactions = (BigDecimal) statement.get("pn_total_transactions");
      final BigDecimal totalPages = (BigDecimal) statement.get("pn_total_pages");
      final String brandCode = (String) statement.get("ps_brand_code");

      // Filter out the empty record that can come back when no transactions are found
      final List<StatementTransaction> transactionList =
          Stream.of(transactions)
              .map(o -> (StatementTransaction) o)
              .filter(tran -> Optional.ofNullable(tran.getBookingDate()).isPresent())
              .collect(Collectors.toList());

      statementTransactions =
          StatementTransactions.builder()
              .totalNumberOfPages(totalPages.intValueExact())
              .totalNumberOfTransactions(totalTransactions.intValueExact())
              .transactionList(transactionList)
              .build();

    } catch (final UncategorizedSQLException ex) {
      throw new SoaSavingsAccountException(ex.getSQLException().getMessage(), ex);
    } catch (final Exception ex) {
      throw new SoaSavingsAccountException(
          "An error occurred calling SOA_SAVINGSACCOUNT_DATA.PR_GET_TRANSACTIONS " + accountNumber,
          ex);
    }

    return statementTransactions;
  }
}
