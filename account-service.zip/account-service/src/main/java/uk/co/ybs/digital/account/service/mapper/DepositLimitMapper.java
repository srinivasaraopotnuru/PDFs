package uk.co.ybs.digital.account.service.mapper;

import java.math.BigDecimal;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.web.dto.DepositLimit;

@Component
public class DepositLimitMapper {

  public DepositLimit mapDepositLimit(
      final BigDecimal remainingDepositLimit, final BigDecimal maxProductBalRemaining) {
    // this item must be null if both of its elements are null
    if (remainingDepositLimit == null && maxProductBalRemaining == null) {
      return null;
    }
    return DepositLimit.builder()
        .available(remainingDepositLimit)
        .maxProductBalRemaining(maxProductBalRemaining)
        .build();
  }
}
