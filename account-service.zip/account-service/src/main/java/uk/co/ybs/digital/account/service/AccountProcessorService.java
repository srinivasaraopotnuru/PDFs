package uk.co.ybs.digital.account.service;

import io.micrometer.core.annotation.Timed;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException.Reason;
import uk.co.ybs.digital.account.exception.AccountServiceException;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Status;
import uk.co.ybs.digital.account.repository.core.MetadataCoreRepository;
import uk.co.ybs.digital.account.repository.digitalaccount.WorkLogRepository;
import uk.co.ybs.digital.account.service.processor.AccountRequest;
import uk.co.ybs.digital.account.service.processor.AccountRequestFactory;
import uk.co.ybs.digital.account.service.processor.ResolvedAccountRequest;
import uk.co.ybs.digital.account.service.utilities.WorkLogMetrics;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@AllArgsConstructor
@Slf4j
@Timed(extraTags = {"type", "accountProcessor"})
@Service
@EnableScheduling
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public class AccountProcessorService {

  private final WorkLogRepository workLogRepository;
  private final MetadataCoreRepository metadataRepository;
  private final AccountRequestFactory accountRequestFactory;
  private final WorkLogMetrics workLogMetrics;
  private final Clock clock;

  @Scheduled(fixedDelayString = "${uk.co.ybs.digital.account.processor.frequency}")
  public void process() {
    try {
      workLogMetrics.setValues(getWorkLogStatuses());
      final List<WorkLog> pendingWorkLogs =
          workLogRepository.findRequestsInState(WorkLog.Status.PENDING);
      log.info("Found {} pending account requests to process", pendingWorkLogs.size());
      pendingWorkLogs.forEach(this::processWorkLog);
    } catch (final DataAccessResourceFailureException e) {
      log.warn("Error occurred connecting to the database", e);
    } catch (final Exception e) {
      log.error("Unexpected error occurred", e);
    }
  }

  private void processWorkLog(final WorkLog workLog) {
    final LocalDateTime processTime = LocalDateTime.now(clock);
    final Long accountNumber = workLog.getAccountNumber();
    final WorkLog.Operation operation = workLog.getOperation();
    final RequestMetadata requestMetadata = workLog.getMessage().getMetadata();

    log.info(
        "Processing WorkLog - Account: {}, Operation: {}, RequestId: {}, WorkLog SysId: {}",
        accountNumber,
        operation,
        requestMetadata.getRequestId(),
        workLog.getSysId());

    // Check that Core is available and accepting connections before processing
    metadataRepository.count();

    final AccountRequest request = accountRequestFactory.build(workLog, processTime);
    final ResolvedAccountRequest resolvedAccountRequest;
    try {
      resolvedAccountRequest = request.resolve();
    } catch (final AccountNotFoundException e) {
      log.warn(
          "Account number not found failure when resolving request - AccountNumber: {}, Operation: {}, RequestId: {}, "
              + "WorkLog SysId: {}",
          accountNumber,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e);
      updateStatus(workLog, WorkLog.Status.FAILED);
      request.auditFailure(e.getMessage());
      return;
    } catch (final Exception e) {
      log.error(
          "Error resolving request - Party: {}, Operation: {}, RequestId: {}, WorkLog SysId: {}",
          accountNumber,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e);

      updateStatus(workLog, WorkLog.Status.FAILED);
      request.auditFailure(Reason.UNEXPECTED.getDescription());
      return;
    }

    try {
      resolvedAccountRequest.execute();
      updateStatus(workLog, Status.COMPLETE);
      try {
        resolvedAccountRequest.auditSuccess();
      } catch (final Exception e) {
        log.error(
            "Failed to create success audit message - Account: {}, Operation: {}, RequestId: {}, WorkLog SysId: {}",
            accountNumber,
            operation,
            requestMetadata.getRequestId(),
            workLog.getSysId(),
            e);
      }
    } catch (final AccountServiceException e) {
      log.warn(
          "Evaluated failure processing request - Account: {}, Operation: {}, RequestId: {}, "
              + "WorkLog SysId: {}, Message: {}",
          accountNumber,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e.getMessage());

      updateStatus(workLog, WorkLog.Status.FAILED);
      resolvedAccountRequest.auditFailure(e.getMessage());
    } catch (final AccountRequestProcessingException e) {
      log.warn(
          "Error processing worklog - AccountNumber: {}, Operation: {}, RequestId: {}, "
              + "WorkLog SysId: {}",
          accountNumber,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e);
      updateStatus(workLog, WorkLog.Status.FAILED);
      request.auditFailure(e.getMessage());
      return;
    } catch (final Exception e) {
      log.error(
          "Error processing request - Account: {}, Operation: {}, RequestId: {}, WorkLog SysId: {}",
          accountNumber,
          operation,
          requestMetadata.getRequestId(),
          workLog.getSysId(),
          e);

      updateStatus(workLog, WorkLog.Status.FAILED);
      request.auditFailure(Reason.UNEXPECTED.getDescription());
    }
  }

  private void updateStatus(final WorkLog request, final WorkLog.Status status) {
    workLogRepository.save(request.toBuilder().status(status).build());
  }

  private Map<WorkLog.Status, Long> getWorkLogStatuses() {
    return workLogRepository.findCountOfRequestsInState().stream()
        .collect(Collectors.toMap(s -> s.left, o -> o.right));
  }
}
