package uk.co.ybs.digital.account.service.audit.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(
    builder =
        AuditIsaDeclarationSubmissionFailureRequest
            .AuditIsaDeclarationSubmissionFailureRequestBuilder.class)
public class AuditIsaDeclarationSubmissionFailureRequest {
  @NonNull private final String ipAddress;
  @NonNull private final AccountInformation accountInformation;
  @NonNull private final String message;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AuditIsaDeclarationSubmissionFailureRequestBuilder {}

  @Value
  @Builder
  @JsonDeserialize(builder = AccountInformation.AccountInformationBuilder.class)
  public static class AccountInformation {
    @NonNull private final String accountNumber;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AccountInformationBuilder {}
  }
}
