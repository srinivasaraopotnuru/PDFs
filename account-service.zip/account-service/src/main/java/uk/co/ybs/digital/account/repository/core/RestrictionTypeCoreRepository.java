package uk.co.ybs.digital.account.repository.core;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.account.model.core.RestrictionType;

public interface RestrictionTypeCoreRepository extends JpaRepository<RestrictionType, Long> {

  Optional<RestrictionType> findByCode(String code);
}
