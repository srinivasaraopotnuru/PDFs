package uk.co.ybs.digital.account.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactions;
import uk.co.ybs.digital.account.repository.adgcore.SoaTransactionsRepository;
import uk.co.ybs.digital.account.web.dto.TransactionDates;

@Service
@Slf4j
@AllArgsConstructor
public class SavingAccountTransactionsService {
  @Autowired private final SoaTransactionsRepository soaTransactionsRepository;

  public StatementTransactions getTransactions(
      final Long accountNumber,
      final int recordFrom,
      final int recordTo,
      final TransactionDates transactionDates) {
    log.info(
        "Get transaction records {}-{} from ADG for account: {}, with startDate: '{}' and endDate: '{}'",
        recordFrom,
        recordTo,
        accountNumber,
        transactionDates.getStartDate(),
        transactionDates.getEndDate());
    return soaTransactionsRepository.getTransactions(
        accountNumber, recordFrom, recordTo, transactionDates);
  }
}
