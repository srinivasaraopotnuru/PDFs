package uk.co.ybs.digital.account.web.dto;

import java.util.Set;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountWarnings {
  Set<AccountWarningSummary> account;
}
