package uk.co.ybs.digital.account.web.dto;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountWarningsResponse {

  AccountWarnings savings;
  AccountWarnings shareplan;
}
