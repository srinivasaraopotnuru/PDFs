package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.math.BigDecimal;
import lombok.Value;

@Value
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WithdrawalInterestPenalty {

  BigDecimal value;

  @JsonCreator
  public WithdrawalInterestPenalty(final BigDecimal value) {
    this.value = value;
  }
}
