package uk.co.ybs.digital.account.service;

import static org.springframework.util.CollectionUtils.isEmpty;
import static uk.co.ybs.digital.account.web.dto.AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT;
import static uk.co.ybs.digital.account.web.dto.AccountDetailsFilter.OTHER_ACCOUNT;

import com.google.common.collect.ImmutableSet;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import uk.co.ybs.digital.account.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.account.exception.AccountNameConflictException;
import uk.co.ybs.digital.account.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.account.exception.AccountServiceException;
import uk.co.ybs.digital.account.exception.AccountWarningsResourceNotFoundException;
import uk.co.ybs.digital.account.exception.NoUpdatedAccountDetailsSpecifiedException;
import uk.co.ybs.digital.account.exception.WorkLogConflictException;
import uk.co.ybs.digital.account.model.AccountSummaryMappingBundle;
import uk.co.ybs.digital.account.model.adgcore.Account;
import uk.co.ybs.digital.account.model.adgcore.AccountActivityGroup;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.AccountWarning;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.model.adgcore.LinkedPartyDetails;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;
import uk.co.ybs.digital.account.model.adgcore.SavingAccount;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.model.digitalaccount.AccountWarningRequest;
import uk.co.ybs.digital.account.model.digitalaccount.DeleteAccountRequest;
import uk.co.ybs.digital.account.model.digitalaccount.DeleteAccountWarningRequest;
import uk.co.ybs.digital.account.model.digitalaccount.SubmitIsaDeclarationRequest;
import uk.co.ybs.digital.account.model.digitalaccount.UpdateAccountDetailsRequest;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Operation;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogPayload;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogRequest;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.adgcore.AccountWarningRepository;
import uk.co.ybs.digital.account.repository.adgcore.ActivityPlayerRepository;
import uk.co.ybs.digital.account.repository.adgcore.PartyRepository;
import uk.co.ybs.digital.account.repository.adgcore.RestrictionTypeRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingAccountAnnualWithdrawalLimitRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingAccountRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingProductRepository;
import uk.co.ybs.digital.account.repository.digitalaccount.WorkLogRepository;
import uk.co.ybs.digital.account.repository.frontoffice.SavingsTransactionLogRepository;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AccountClosedException;
import uk.co.ybs.digital.account.service.authentic.AccountNotFoundException;
import uk.co.ybs.digital.account.service.authentic.AuthenticService;
import uk.co.ybs.digital.account.service.mapper.AccountDetailsMapper;
import uk.co.ybs.digital.account.service.mapper.GroupedAccountListMapper;
import uk.co.ybs.digital.account.service.product.ProductService;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.account.service.utilities.AccountClosedCalculator;
import uk.co.ybs.digital.account.service.utilities.AccountNumberConversion;
import uk.co.ybs.digital.account.service.utilities.AccountWarningFilter;
import uk.co.ybs.digital.account.service.utilities.AvailableDepositLimitCalculator;
import uk.co.ybs.digital.account.service.utilities.ManageInterestCalculator;
import uk.co.ybs.digital.account.service.utilities.ReinvestmentCalculator;
import uk.co.ybs.digital.account.web.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.account.web.dto.AccountDetails;
import uk.co.ybs.digital.account.web.dto.AccountDetailsFilter;
import uk.co.ybs.digital.account.web.dto.AccountDetailsResponse;
import uk.co.ybs.digital.account.web.dto.AccountWarningSummary;
import uk.co.ybs.digital.account.web.dto.AccountWarnings;
import uk.co.ybs.digital.account.web.dto.AccountWarningsResponse;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.Reinvestment;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.UpdateAccountDetails;
import uk.co.ybs.digital.account.web.dto.Warning;
import uk.co.ybs.digital.account.web.dto.WarningCode;

@Service
@RequiredArgsConstructor
@Slf4j
public class AccountService {

  private static final Set<String> ACTIVITY_GROUP_CODES_ACCOUNT_DETAILS =
      ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
  private static final Set<String> ACTIVITY_GROUP_CODES_ACCOUNT_LIST =
      ImmutableSet.of(
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_AISP,
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP,
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS);
  private static final String ACCOUNT_ON_BLACKLIST_LOG_MESSAGE =
      "Account {} is found on the blacklist, not inserting a WorkLog or SavingsTransactionLog entry";
  private static final String ISA_PRODUCT_TYPE = "ISA";
  public static final String SERVICE_USER = "SACCSRV";
  private static final Period TWO_YEARS_AGO = Period.ofYears(2);

  private final AccountAccessValidator accountAccessValidator;
  private final ProductService productService;
  private final AccountServiceProperties accountServiceProperties;
  private final AuthenticService authenticService;
  private final SavingProductRepository savingProductRepository;
  private final ActivityPlayerRepository activityPlayerRepository;
  private final AccountWarningRepository accountWarningRepository;
  private final RestrictionTypeRepository restrictionTypeRepository;
  private final SavingAccountRepository savingAccountRepository;
  private final SavingAccountAnnualWithdrawalLimitRepository
      savingAccountAnnualWithdrawalLimitRepository;
  private final SavingsTransactionLogRepository savingsTransactionLogRepository;
  private final WorkLogRepository workLogRepository;
  private final AccountNumberRepository accountNumberRespository;
  private final AccountDetailsMapper accountDetailsMapper;
  private final GroupedAccountListMapper groupedAccountListMapper;
  private final AvailableDepositLimitCalculator availableDepositLimitCalculator;
  private final AccountWarningFilter accountWarningRestrictionRuleFilter;
  private final Clock clock;
  private final SavingAccountDetailsService savingAccountDetailsService;
  private final SavingAccountDetailsListService savingAccountDetailsListService;
  private final PartyRepository partyRepository;
  private final ReinvestmentCalculator reinvestmentCalculator;
  private final ManageInterestCalculator manageInterestCalculator;

  @Transactional(readOnly = true, transactionManager = "transactionManager")
  public AccountDetailsResponse getAccountDetails(
      final String accountNumber,
      final List<AccountDetailsFilter> filters,
      final RequestMetadata metadata) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final LocalDate today = now.toLocalDate();

    final Set<String> activityGroups;
    if (filters.contains(OTHER_ACCOUNT)) {
      accountAccessValidator.validateAccountExistenceAndBrand(accountNumber, metadata);
      activityGroups = Collections.emptySet();
    } else {
      activityGroups =
          accountAccessValidator.validateOwnAccountAccess(
              accountNumber, metadata, ACTIVITY_GROUP_CODES_ACCOUNT_DETAILS, now);
    }

    final SavingAccountDetails accountDetails =
        savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(accountNumber)).get(0);

    final boolean accountClosed = isAccountClosed(accountDetails.getClosedDate(), today);

    final SavingAccount savingAccount = getSavingsAccountFromDatabase(accountNumber);
    final LocalDate openedDate = savingAccount.getOpenedDate().toLocalDate();

    final List<AccountBalanceType> balance = getAccountBalance(savingAccount, accountClosed);

    final Set<String> accountNumberAsSet = Collections.singleton(accountNumber);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber =
            getAccountWarningRestrictionRulesByAccountNumber(accountNumberAsSet, now);

    final ProductInfo productInfo =
        productService.getProductInfo(accountDetails.getProductIdentifier(), metadata);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.join("", accountNumberAsSet), accountDetails.getProductIdentifier());
    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRulesFiltered =
        accountWarningRestrictionRuleFilter
            .filter(
                productIdentifierByAccountNumber, productInfoByProductIdentifier,
                accountWarningRestrictionRulesByAccountNumber, now)
            .getOrDefault(accountNumber, Collections.emptyList());

    final SavingAccountAnnualWithdrawalLimit annualWithdrawalLimits;
    if (productInfo.hasAnniversaryWithdrawalLimit()) {
      annualWithdrawalLimits =
          getAnnualWithdrawalLimitByAccountNumber(accountNumberAsSet).get(accountNumber);
    } else {
      annualWithdrawalLimits = null;
    }

    final boolean productMigrationInProgress =
        getAccountsWithProductMigrationInProgress(accountNumberAsSet, now).contains(accountNumber);

    final BigDecimal remainingDepositLimit;
    final BigDecimal maxProductBalanceRemaining;

    if (filters.contains(AVAILABLE_DEPOSIT_LIMIT)) {
      remainingDepositLimit =
          availableDepositLimitCalculator.calculateRemainingDepositLimit(
              accountNumber,
              accountClosed,
              productMigrationInProgress,
              productInfo,
              accountWarningRestrictionRulesFiltered,
              now);
      final Optional<AccountBalanceType> ledgerBalance = getLedgerBalance(balance);
      maxProductBalanceRemaining =
          availableDepositLimitCalculator.calculateRemainingMaxProductBalance(
              accountNumber, accountClosed, productMigrationInProgress, productInfo, ledgerBalance);
    } else {
      remainingDepositLimit = null;
      maxProductBalanceRemaining = null;
    }
    boolean interestOptionsPermitted =
        manageInterestCalculator.areInterestOptionsPermitted(
            accountNumber,
            savingAccount.getWitCode(),
            productInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRulesFiltered);

    final Reinvestment reinvestment =
        Reinvestment.builder()
            .permittedOverApi(
                reinvestmentCalculator.isReinvestmentPermitted(
                    accountNumber,
                    productInfo.getProductIdentifier(),
                    productInfo.getProductType(),
                    accountDetails.getClosedDate(),
                    metadata))
            .build();

    final AccountDetails account =
        accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            balance,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRulesFiltered,
            activityGroups,
            annualWithdrawalLimits,
            accountClosed,
            remainingDepositLimit,
            maxProductBalanceRemaining,
            openedDate,
            reinvestment,
            interestOptionsPermitted,
            savingAccount.getWitCode(),
            Long.parseLong(metadata.getPartyId()),
            now);

    return AccountDetailsResponse.builder().account(account).build();
  }

  private SavingAccount getSavingsAccountFromDatabase(final String accountNumber) {
    return savingAccountRepository
        .findById(Long.valueOf(accountNumber))
        .orElseThrow(
            () ->
                (new AccountResourceNotFoundException(
                    String.format("Account %s not found", accountNumber))));
  }

  @Transactional(readOnly = true, transactionManager = "transactionManager")
  public GroupedAccountListResponse getAccountGroups(
      final RequestMetadata metadata, final boolean showClosedAccounts) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final LocalDate today = now.toLocalDate();

    final List<Long> accountNumbers =
        savingAccountDetailsListService.getSavingsAccountList(metadata, showClosedAccounts);

    final List<String> accountNumbersAsString =
        accountNumbers.stream().map(String::valueOf).collect(Collectors.toList());

    final List<SavingAccountDetails> savingAccountDetailsList =
        savingAccountDetailsService.getSavingAccountDetails(accountNumbers);

    final Map<String, Set<String>> activityGroupsByAccountNumber =
        getAccountListActivityGroupsByAccountNumber(
            metadata.getPartyId(), accountNumbersAsString, now);

    final Map<String, SavingAccountDetails> accountSummaryTypeByAccountNumber =
        new LinkedHashMap<>();
    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    final Set<String> productIdentifiers = new HashSet<>();
    final Set<String> closedAccountNumbers = new HashSet<>();

    savingAccountDetailsList.stream()
        .filter(
            accountDetails -> hasAispRelationship(activityGroupsByAccountNumber, accountDetails))
        .forEach(
            accountDetails -> {
              final String accountNumberString = String.valueOf(accountDetails.getAccountNumber());
              final String productIdentifier = accountDetails.getProductIdentifier();
              accountSummaryTypeByAccountNumber.put(accountNumberString, accountDetails);
              productIdentifierByAccountNumber.put(accountNumberString, productIdentifier);
              productIdentifiers.add(productIdentifier);
              if (isAccountClosed(accountDetails.getClosedDate(), today)) {
                closedAccountNumbers.add(accountNumberString);
              }
            });

    final List<SavingAccount> savingAccounts =
        getSavingsAccountsFromDatabase(accountSummaryTypeByAccountNumber.keySet());

    final Map<String, List<AccountBalanceType>> balancesByAccountNumber =
        getAccountBalancesByAccountNumber(savingAccounts, closedAccountNumbers);

    final Set<String> accountNumbersAsSet = balancesByAccountNumber.keySet();
    accountSummaryTypeByAccountNumber.keySet().retainAll(accountNumbersAsSet);
    productIdentifierByAccountNumber.keySet().retainAll(accountNumbersAsSet);

    final Map<String, ProductInfo> productInfoByProductIdentifier =
        getProductInfoByProductIdentifier(productIdentifiers, metadata);
    final Map<String, List<AccountWarningRestrictionRule>> accountWarningRestrictionRules =
        getAccountWarningRestrictionRulesByAccountNumber(accountNumbersAsSet, now);
    final Map<String, List<AccountWarningRestrictionRule>> accountWarningRestrictionRuleFiltered =
        accountWarningRestrictionRuleFilter.filter(
            productIdentifierByAccountNumber, productInfoByProductIdentifier,
            accountWarningRestrictionRules, now);

    final Set<String> accountNumbersWithAnniversaryWithdrawalLimit =
        productIdentifierByAccountNumber.entrySet().stream()
            .filter(
                entry ->
                    productInfoByProductIdentifier
                        .get(entry.getValue())
                        .hasAnniversaryWithdrawalLimit())
            .map(Map.Entry::getKey)
            .collect(Collectors.toSet());
    final Map<String, SavingAccountAnnualWithdrawalLimit>
        savingAccountAnnualWithdrawalLimitByAccountNumber =
            getAnnualWithdrawalLimitByAccountNumber(accountNumbersWithAnniversaryWithdrawalLimit);
    final Set<String> accountsWithProductMigrationInProgress =
        getAccountsWithProductMigrationInProgress(accountNumbersAsSet, now);
    final Map<Long, LocalDateTime> accountOpenedDateByAccountNumber =
        savingAccounts.stream()
            .collect(
                Collectors.toMap(SavingAccount::getAccountNumber, SavingAccount::getOpenedDate));

    final List<AccountSummaryMappingBundle> accountSummaryDataBundles =
        accountSummaryTypeByAccountNumber.entrySet().stream()
            .map(
                entry -> {
                  final String accountNumber = entry.getKey();
                  final SavingAccountDetails accountDetails = entry.getValue();
                  return AccountSummaryMappingBundle.builder()
                      .savingAccountDetails(accountDetails)
                      .balances(balancesByAccountNumber.get(accountNumber))
                      .productInfo(
                          productInfoByProductIdentifier.get(accountDetails.getProductIdentifier()))
                      .productMigrationInProgress(
                          accountsWithProductMigrationInProgress.contains(accountNumber))
                      .accountWarningRestrictionRules(
                          accountWarningRestrictionRuleFiltered.getOrDefault(
                              accountNumber, Collections.emptyList()))
                      .activityGroupCodes(
                          activityGroupsByAccountNumber.getOrDefault(
                              accountNumber, Collections.emptySet()))
                      .anniversaryWithdrawalLimit(
                          savingAccountAnnualWithdrawalLimitByAccountNumber.get(accountNumber))
                      .closed(closedAccountNumbers.contains(accountNumber))
                      .openedDate(
                          accountOpenedDateByAccountNumber
                              .get(Long.valueOf(accountNumber))
                              .toLocalDate())
                      .build();
                })
            .collect(Collectors.toList());

    return groupedAccountListMapper.mapToAccountGroups(
        accountSummaryDataBundles, showClosedAccounts);
  }

  private List<SavingAccount> getSavingsAccountsFromDatabase(final Set<String> accountNumbers) {
    final List<SavingAccount> savingAccounts =
        savingAccountRepository.findAllById(
            accountNumbers.stream().map(Long::parseLong).collect(Collectors.toSet()));

    final List<String> accountNumbersInDatabase =
        savingAccounts.stream()
            .map(s -> Long.toString(s.getAccountNumber()))
            .collect(Collectors.toList());

    for (final String accountNumber : accountNumbers) {
      if (!accountNumbersInDatabase.contains(accountNumber)) {
        log.info(
            "Account {} not found in database. Account will be removed from response.",
            accountNumber);
      }
    }

    return savingAccounts;
  }

  @Transactional(transactionManager = "transactionManager")
  public void createIsaDeclaration(final RequestMetadata metadata, final String accountNumber)
      throws WorkLogConflictException {
    final LocalDateTime now = LocalDateTime.now(clock);
    final Long accountNumberLong = Long.valueOf(accountNumber);

    final SavingProduct savingProduct = getSavingsProductForAccount(accountNumberLong);

    final ProductInfo productInfo =
        productService.getProductInfo(savingProduct.getProductIdentifier(), metadata);

    if (!ISA_PRODUCT_TYPE.equals(productInfo.getProductType())) {
      log.info(
          "Product type for account {} is not \"ISA\". Product type is {}. Unable to create an isa declaration",
          accountNumber,
          productInfo.getProductType());
      throw new WorkLogConflictException("Account type is not valid for an ISA declaration");
    }

    final Set<Long> accountNumbersWithInProgressDeclaration =
        getIsaDeclarationInProgress(accountNumberLong, now.minusDays(1L));

    if (!accountNumbersWithInProgressDeclaration.isEmpty()) {
      log.info("ISA declaration for account {} is already in progress", accountNumber);
      throw new WorkLogConflictException("ISA declaration is currently in progress");
    }

    final Collection<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        getDepositWarningsForAccount(accountNumberLong, now);
    final long noSubsWarningsCount =
        accountWarningRestrictionRules.stream()
            .filter(
                warning ->
                    RestrictionType.NO_SUBSCRIPTIONS.equals(warning.getRestrictionTypeCode()))
            .count();

    if (noSubsWarningsCount == 0) {
      log.info("No \"NOSUBS\" warnings found for account {}", accountNumber);
      throw new WorkLogConflictException("No deposit warnings set against account");
    }

    // If this is an account that is used in e2e tests we do not want save any
    // records
    if (!shouldInsertRecords(accountNumber)) {
      log.info(ACCOUNT_ON_BLACKLIST_LOG_MESSAGE, accountNumber);
      return;
    }

    final SubmitIsaDeclarationRequest request = SubmitIsaDeclarationRequest.builder().build();

    workLogRepository.save(
        buildWorkLog(metadata, accountNumberLong, Operation.SUBMIT_ISA_DEC, request, SERVICE_USER));

    savingsTransactionLogRepository.save(
        buildSavingsTransactionLogEntry(
            accountNumberLong,
            null,
            SavingsTransactionLogEntry.STATUS_ISA_DECLARATION,
            now,
            metadata));
  }

  public void checkForRecentAccounts(final Long partyId, final RequestMetadata metadata)
      throws AccountResourceNotFoundException {
    final LocalDateTime earliestDate = LocalDateTime.now(clock).minus(TWO_YEARS_AGO);
    final Collection<String> brandCodes = Collections.singletonList(metadata.getBrandCode());

    final Collection<AccountNumber> accountNumbers =
        accountNumberRespository
            .findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
                partyId, brandCodes, earliestDate);

    if (isEmpty(accountNumbers)) {
      throw new AccountResourceNotFoundException(
          String.format(
              "No open or closed accounts found for %d since %s",
              partyId, earliestDate.toString()));
    }
  }

  public Collection<Warning> getActiveWarningsForAccount(final String accountNumber) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final Collection<Warning> result = new HashSet<>();

    final Collection<AccountWarning> accountWarningList =
        accountWarningRepository.findActiveAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(Long.valueOf(accountNumber)), now);

    accountWarningList.stream()
        .filter(Objects::nonNull)
        .forEach(
            item ->
                result.add(
                    Warning.builder()
                        .code(item.getRestrictionType().getCode())
                        .description(item.getRestrictionType().getDescription())
                        .build()));
    result.addAll(getPendingWarningsFromWorkLog(accountNumber));
    return result;
  }

  public Collection<Warning> getAllWarningsForAccount(final String accountNumber) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final Collection<Warning> result = new HashSet<>();
    final Collection<AccountWarning> accountWarningList =
        accountWarningRepository.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(Long.valueOf(accountNumber)), now);

    for (final AccountWarning warning : accountWarningList) {
      final Warning.WarningBuilder warningBuilder =
          Warning.builder()
              .code(warning.getRestrictionType().getCode())
              .description(warning.getRestrictionType().getDescription());
      if (warning.getEndDate() != null && warning.getEndDate().isBefore(now)) {
        warningBuilder.endDate(warning.getEndDate());
      }
      result.add(warningBuilder.build());
    }
    result.addAll(getPendingWarningsFromWorkLog(accountNumber));
    return result;
  }

  public void createWarningForAccount(
      final String accountNumber, final WarningCode warningCode, final RequestMetadata metadata) {

    final String serviceSchemaUser = warningCode.getServiceSchemaUser();
    final Long partyId = warningCode.getPartyId();
    final Long accountNumberLong = Long.valueOf(accountNumber);

    accountNumberRespository
        .findById(accountNumberLong)
        .orElseThrow(
            () ->
                (new AccountServiceException(
                    String.format(
                        "Failed to find account %s for request ID: %s",
                        accountNumber, metadata.getRequestId()))));

    log.info("Finding restriction type: " + warningCode.getCode());
    final RestrictionType restrictionType =
        restrictionTypeRepository
            .findByCode(warningCode.getCode())
            .orElseThrow(
                () ->
                    (new AccountServiceException(
                        String.format(
                            "Failed to find restriction type %s for request ID: %s",
                            warningCode.getCode(), metadata.getRequestId()))));

    final LocalDateTime now = LocalDateTime.now(clock);

    final Collection<AccountWarning> accountWarningList =
        accountWarningRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            Long.valueOf(accountNumber), Collections.singletonList(restrictionType.getCode()), now);

    if (accountWarningList.isEmpty()) {
      final AccountWarningRequest request =
          AccountWarningRequest.builder()
              .warningType(warningCode.getCode())
              .notes(warningCode.getNotes())
              .createdAt(serviceSchemaUser != null ? serviceSchemaUser : "SAPP")
              .createdBy(partyId != null ? partyId.toString() : "SAPP")
              .build();

      workLogRepository.save(
          buildWorkLog(
              metadata,
              accountNumberLong,
              Operation.INS_ACCOUNT_WARNING,
              request,
              request.getCreatedBy()));
    } else {
      log.info("{} warning exists for account {}: ", warningCode.getCode(), accountNumber);
    }
  }

  public void deleteAccount(final String accountNumber, final RequestMetadata metadata) {

    if (!shouldInsertRecords(accountNumber)) {
      log.info(ACCOUNT_ON_BLACKLIST_LOG_MESSAGE, accountNumber);
      return;
    }

    final DeleteAccountRequest request = DeleteAccountRequest.builder().build();
    workLogRepository.save(
        buildWorkLog(
            metadata,
            Long.valueOf(accountNumber),
            Operation.DELETE_ACCOUNT,
            request,
            SERVICE_USER));
  }

  public void deleteWarningForAccount(
      final String accountNumber, final WarningCode warningCode, final RequestMetadata metadata) {

    final String serviceSchemaUser = warningCode.getServiceSchemaUser();
    final Long partyId = warningCode.getPartyId();
    final Long accountNumberLong = Long.valueOf(accountNumber);

    if (!shouldInsertRecords(accountNumber)) {
      log.info(ACCOUNT_ON_BLACKLIST_LOG_MESSAGE, accountNumber);
      return;
    }

    accountNumberRespository
        .findById(accountNumberLong)
        .orElseThrow(
            () ->
                (new AccountServiceException(
                    "Failed to find account "
                        + accountNumber
                        + " for request ID: "
                        + metadata.getRequestId())));

    log.info("Finding restriction type: " + warningCode.getCode());
    final RestrictionType restrictionType =
        restrictionTypeRepository
            .findByCode(warningCode.getCode())
            .orElseThrow(
                () ->
                    (new AccountServiceException(
                        "Failed to find restriction type "
                            + warningCode.getCode()
                            + " for request ID: "
                            + metadata.getRequestId())));

    final LocalDateTime now = LocalDateTime.now(clock);

    final Collection<AccountWarning> accountWarningList =
        accountWarningRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            Long.valueOf(accountNumber), Collections.singletonList(restrictionType.getCode()), now);

    if (!accountWarningList.isEmpty()) {
      final DeleteAccountWarningRequest request =
          DeleteAccountWarningRequest.builder()
              .warningType(warningCode.getCode())
              .endedAt(serviceSchemaUser != null ? serviceSchemaUser : SERVICE_USER)
              .endedBy(partyId != null ? partyId.toString() : SERVICE_USER)
              .build();

      workLogRepository.save(
          buildWorkLog(
              metadata,
              accountNumberLong,
              Operation.DEL_ACCOUNT_WARNING,
              request,
              request.getEndedBy()));
    } else {
      log.info("{} warning doesn't exists for account {}: ", warningCode.getCode(), accountNumber);
    }
  }

  private boolean hasAispRelationship(
      final Map<String, Set<String>> activityGroupsByAccountNumber,
      final SavingAccountDetails accountDetails) {
    return activityGroupsByAccountNumber
        .getOrDefault(String.valueOf(accountDetails.getAccountNumber()), Collections.emptySet())
        .contains(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AISP);
  }

  private Map<String, List<AccountBalanceType>> getAccountBalancesByAccountNumber(
      final List<SavingAccount> accounts, final Set<String> closedAccountNumbers) {

    final Map<String, List<AccountBalanceType>> accountNumberAccountBalances =
        new LinkedHashMap<>();
    for (final SavingAccount account : accounts) {
      final String accountNumber = Long.toString(account.getAccountNumber());
      try {
        final List<AccountBalanceType> balance =
            getAccountBalance(account, closedAccountNumbers.contains(accountNumber));
        accountNumberAccountBalances.put(accountNumber, balance);
      } catch (final AccountNotFoundException | AccountClosedException e) {
        log.info(
            "Error getting balance for account {} from Authentic. Error detail: {}. Removing account from response",
            accountNumber,
            e.getMessage());
      }
    }

    return accountNumberAccountBalances;
  }

  private static Optional<AccountBalanceType> getLedgerBalance(
      final List<AccountBalanceType> balances) {
    return getBalanceByType(balances, AccountBalanceType.BalanceConstants.TYPE_CAPITAL_LEDGER);
  }

  private static Optional<AccountBalanceType> getBalanceByType(
      final List<AccountBalanceType> balances, final String type) {
    return balances.stream().filter(balance -> balance.getBalanceType().equals(type)).findFirst();
  }

  private List<AccountBalanceType> getAccountBalance(
      final SavingAccount savingAccount, final boolean accountClosed) {
    if (accountClosed) {
      return getClosedAccountBalance(savingAccount);
    }
    return authenticService.getBalance(Long.toString(savingAccount.getAccountNumber()));
  }

  private List<AccountBalanceType> getClosedAccountBalance(final SavingAccount savingAccount) {

    final AccountBalanceType interimAvailableBalance =
        AccountBalanceType.builder()
            .balanceType("CapitalAvailable")
            .balanceAmount(savingAccount.getInterimAvailable())
            .build();

    final AccountBalanceType interimLedgerBalance =
        AccountBalanceType.builder()
            .balanceType("CapitalLedger")
            .balanceAmount(savingAccount.getInterimBooked())
            .build();

    return Arrays.asList(interimAvailableBalance, interimLedgerBalance);
  }

  private Map<String, Set<String>> getAccountListActivityGroupsByAccountNumber(
      final String partyId, final Collection<String> accountNumbers, final LocalDateTime dateTime) {
    final Map<String, Set<String>> activityGroups;
    if (accountNumbers.isEmpty()) {
      activityGroups = Collections.emptyMap();
    } else {
      final Map<Long, String> accountNumberMappings =
          AccountNumberConversion.buildAccountNumberMappings(accountNumbers);

      final Collection<AccountActivityGroup> accountActivityGroups =
          activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
              Long.valueOf(partyId),
              ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
              accountNumberMappings.keySet(),
              dateTime);

      // Group the codes by account number.
      activityGroups =
          accountActivityGroups.stream()
              .collect(
                  Collectors.groupingBy(
                      accountActivityGroup ->
                          AccountNumberConversion.mapAccountNumberToString(
                              accountNumberMappings, accountActivityGroup.getAccountNumber()),
                      Collectors.mapping(
                          AccountActivityGroup::getActivityGroupCode, Collectors.toSet())));
    }

    return activityGroups;
  }

  private Map<String, SavingAccountAnnualWithdrawalLimit> getAnnualWithdrawalLimitByAccountNumber(
      final Set<String> accountNumbers) {
    final Map<String, SavingAccountAnnualWithdrawalLimit> limits;
    if (accountNumbers.isEmpty()) {
      limits = Collections.emptyMap();
    } else {
      final Map<Long, String> accountNumberMappings =
          AccountNumberConversion.buildAccountNumberMappings(accountNumbers);

      limits =
          savingAccountAnnualWithdrawalLimitRepository
              .findAllByAccountNumbers(accountNumberMappings.keySet()).stream()
              .collect(
                  Collectors.toMap(
                      limit ->
                          AccountNumberConversion.mapAccountNumberToString(
                              accountNumberMappings, limit.getAccountNumber().getAccountNumber()),
                      Function.identity()));
    }

    return limits;
  }

  private Set<String> getAccountsWithProductMigrationInProgress(
      final Set<String> accountNumbers, final LocalDateTime now) {
    final Set<String> productMigrationInProgress;
    if (accountNumbers.isEmpty()) {
      productMigrationInProgress = Collections.emptySet();
    } else {
      final Map<Long, String> accountNumberMappings =
          AccountNumberConversion.buildAccountNumberMappings(accountNumbers);

      final Set<Long> accountNumberLongsWithMigrationInProgress =
          savingsTransactionLogRepository
              .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                  accountNumberMappings.keySet(),
                  SavingsTransactionLogEntry.STATUSES_PRODUCT_MIGRATION,
                  now.minusDays(2));

      productMigrationInProgress =
          accountNumberLongsWithMigrationInProgress.stream()
              .map(
                  accountNumberLong ->
                      AccountNumberConversion.mapAccountNumberToString(
                          accountNumberMappings, accountNumberLong))
              .collect(Collectors.toSet());
    }

    return productMigrationInProgress;
  }

  private Map<String, ProductInfo> getProductInfoByProductIdentifier(
      final Set<String> productIdentifiers, final RequestMetadata metadata) {
    final Map<String, ProductInfo> productInfoByIdentifier;
    if (productIdentifiers.isEmpty()) {
      productInfoByIdentifier = Collections.emptyMap();
    } else {
      productInfoByIdentifier =
          productService.searchProductInfo(productIdentifiers, metadata).stream()
              .collect(Collectors.toMap(ProductInfo::getProductIdentifier, Function.identity()));
    }

    if (!productIdentifiers.equals(productInfoByIdentifier.keySet())) {
      throw new AccountServiceException(
          "Failed to find all products.  Requested: " + productIdentifiers);
    }

    return productInfoByIdentifier;
  }

  private Map<String, List<AccountWarningRestrictionRule>>
      getAccountWarningRestrictionRulesByAccountNumber(
          final Set<String> accountNumbers, final LocalDateTime now) {
    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber;
    if (accountNumbers.isEmpty()) {
      accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();
    } else {
      final Map<Long, String> accountNumberMappings =
          AccountNumberConversion.buildAccountNumberMappings(accountNumbers);
      accountWarningRestrictionRulesByAccountNumber =
          accountWarningRepository
              .findAccountWarningRestrictionRulesByAccountNumbersAndDate(
                  accountNumberMappings.keySet(), RestrictionTypeRule.KNOWN_CODES, now)
              .stream()
              .collect(
                  Collectors.groupingBy(
                      item ->
                          AccountNumberConversion.mapAccountNumberToString(
                              accountNumberMappings, item.getAccountNumber())));
    }

    return accountWarningRestrictionRulesByAccountNumber;
  }

  private boolean isAccountClosed(final LocalDate closedDate, final LocalDate today) {
    return AccountClosedCalculator.isAccountClosed(closedDate, today);
  }

  private SavingsTransactionLogEntry buildSavingsTransactionLogEntry(
      final Long accountNumber,
      final String accountName,
      final String status,
      final LocalDateTime now,
      final RequestMetadata metadata) {
    return SavingsTransactionLogEntry.builder()
        .accountNumber(accountNumber)
        .startTime(now)
        .endTime(now)
        .transferIndicator(SavingsTransactionLogEntry.TRANSFER_INDICATOR_INTERNAL)
        .closure(SavingsTransactionLogEntry.CLOSURE_NO)
        .partySysId(Long.valueOf(metadata.getPartyId()))
        .status(status)
        // This is a required field, but has no meaning in this context
        .targetAccountNumber(0L)
        .accountName(accountName)
        // This is a required field, but has no meaning in this context
        .amount(BigDecimal.ZERO)
        .build();
  }

  private WorkLog buildWorkLog(
      final RequestMetadata metadata,
      final Long accountNumber,
      final Operation operation,
      final WorkLogPayload request,
      final String createdBy) {
    return WorkLog.builder()
        .accountNumber(accountNumber)
        .status(WorkLog.Status.PENDING)
        .operation(operation)
        .createdBy(createdBy)
        .message(WorkLogRequest.builder().workLogPayload(request).metadata(metadata).build())
        .build();
  }

  private SavingProduct getSavingsProductForAccount(final Long accountNumber) {
    return Stream.of(savingProductRepository.findBySavingAccountNumber(accountNumber))
        .filter(Optional::isPresent)
        .findFirst()
        .orElseThrow(
            () -> new AccountServiceException("Failed to find savings product for account"))
        .get();
  }

  private Collection<AccountWarningRestrictionRule> getDepositWarningsForAccount(
      final Long accountNumber, final LocalDateTime now) {
    return accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
        Collections.singletonList(accountNumber),
        Collections.singletonList(RestrictionTypeRule.CODE_WEB_RECEIPTS),
        now);
  }

  private Set<Long> getIsaDeclarationInProgress(
      final Long accountNumber, final LocalDateTime after) {
    return savingsTransactionLogRepository.findAllAccountsWithEntriesStartingAfterEarliestTime(
        Collections.singletonList(accountNumber),
        after,
        SavingsTransactionLogEntry.STATUS_ISA_DECLARATION);
  }

  private Boolean shouldInsertRecords(final String accountNumber) {
    return Optional.ofNullable(accountServiceProperties.getAccountNumberBlacklist())
        .map(
            blacklist ->
                blacklist.stream()
                    .noneMatch(blacklisted -> blacklisted.equalsIgnoreCase(accountNumber)))
        .orElse(true);
  }

  public AccountWarningsResponse getAccountWarningsByPartyId(
      final boolean includeShareplanAccounts, final String partyId) {
    log.info("Fetching warnings for party Id: " + partyId);
    final LocalDateTime now = LocalDateTime.now(clock);
    final List<String> accountTypes =
        new ArrayList<>(Collections.singletonList(AccountNumber.TABLE_ID_SAVACC));
    final List<LinkedPartyDetails> linkedPartyList = partyRepository.findLinkedParties(partyId);
    if (linkedPartyList.isEmpty()) {
      throw new AccountWarningsResourceNotFoundException(
          String.format("No parties found for Party ID %s", partyId), ErrorItem.RESOURCE_NOT_FOUND);
    }
    final List<Long> partyIdList =
        linkedPartyList.stream().map(LinkedPartyDetails::getPartyId).collect(Collectors.toList());
    if (includeShareplanAccounts) {
      accountTypes.add(AccountNumber.TABLE_ID_CBACC);
    }
    final List<Account> accounts =
        accountNumberRespository.findAccountNumbersByPartyIdAndAccountType(
            partyIdList, accountTypes, now);
    return buildAccountWarningsResponse(accounts, partyId, includeShareplanAccounts, now);
  }

  private AccountWarningsResponse buildAccountWarningsResponse(
      final List<Account> accounts,
      final String partyId,
      final boolean includeShareplanAccounts,
      final LocalDateTime now) {

    log.info("Building warning response for party Id:" + partyId);
    final List<Long> accountNumbers =
        accounts.stream().map(Account::getAccountNumber).collect(Collectors.toList());
    final Collection<AccountWarning> accountWarningsList =
        accountWarningRepository.findActiveAccountWarningsByAccountNumberAndDate(
            accountNumbers, now);
    final Map<Long, Set<Warning>> accountWarningsMapByAccountNumber =
        accountWarningsList.stream()
            .filter(Objects::nonNull)
            .collect(
                Collectors.groupingBy(
                    warningsList -> warningsList.getAccountNumber().getAccountNumber(),
                    Collectors.mapping(
                        warningsList ->
                            Warning.builder()
                                .code(warningsList.getRestrictionType().getCode())
                                .description(warningsList.getRestrictionType().getDescription())
                                .build(),
                        Collectors.toSet())));

    final Map<String, Set<AccountWarningSummary>> accountWarningsMapByAccountType =
        accountWarningsList.stream()
            .collect(
                Collectors.groupingBy(
                    accountWarningData -> accountWarningData.getAccountNumber().getTableId(),
                    Collectors.mapping(
                        accountWarningData ->
                            AccountWarningSummary.builder()
                                .accountNumber(
                                    String.valueOf(
                                        accountWarningData.getAccountNumber().getAccountNumber()))
                                .openedDate(
                                    accounts.stream()
                                        .filter(
                                            account ->
                                                accountWarningData
                                                    .getAccountNumber()
                                                    .getAccountNumber()
                                                    .equals(account.getAccountNumber()))
                                        .map(Account::getOpenedDate)
                                        .filter(Objects::nonNull)
                                        .findFirst()
                                        .orElse(null))
                                .accountWarnings(
                                    accountWarningsMapByAccountNumber.get(
                                        accountWarningData.getAccountNumber().getAccountNumber()))
                                .build(),
                        Collectors.toSet())));
    AccountWarnings savingsAccountWarnings = null;
    AccountWarnings sharePlanAccountWarnings = null;
    if (includeShareplanAccounts
        && accountWarningsMapByAccountType.get(AccountNumber.TABLE_ID_CBACC) != null) {
      sharePlanAccountWarnings =
          AccountWarnings.builder()
              .account(accountWarningsMapByAccountType.get(AccountNumber.TABLE_ID_CBACC))
              .build();
    }
    if (accountWarningsMapByAccountType.get(AccountNumber.TABLE_ID_SAVACC) != null) {
      savingsAccountWarnings =
          AccountWarnings.builder()
              .account(accountWarningsMapByAccountType.get(AccountNumber.TABLE_ID_SAVACC))
              .build();
    }
    return AccountWarningsResponse.builder()
        .savings(savingsAccountWarnings)
        .shareplan(sharePlanAccountWarnings)
        .build();
  }

  public void patchUpdateAccountDetails(
      final String accountNumber,
      final UpdateAccountDetails updateAccountDetail,
      final RequestMetadata metadata) {

    String accountName = updateAccountDetail.getAccountName();
    final Long accountNumberLong = Long.valueOf(accountNumber);

    final LocalDateTime now = LocalDateTime.now(clock);
    final LocalDate today = now.toLocalDate();

    final SavingAccountDetails accountDetails =
        savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(accountNumber)).stream()
            .findFirst()
            .orElseThrow(
                () ->
                    (new AccountServiceException(
                        "Failed to find account "
                            + accountNumber
                            + " for request ID: "
                            + metadata.getRequestId())));

    final boolean accountClosed = isAccountClosed(accountDetails.getClosedDate(), today);

    if (accountClosed) {
      throw new AccountAccessDeniedException("Account is closed");
    }

    if (accountName == null) { // when more properties have been added this will check them all
      throw new NoUpdatedAccountDetailsSpecifiedException("No updated account details specified");
    }

    accountName = !StringUtils.hasLength(accountName.trim()) ? null : accountName; // NOPMD

    if (Objects.equals(accountName, accountDetails.getAccountName())) {
      throw new AccountNameConflictException("Account name has not changed");
    }

    if (!shouldInsertRecords(accountNumber)) {
      log.info(ACCOUNT_ON_BLACKLIST_LOG_MESSAGE, accountNumber);
      return;
    }

    final UpdateAccountDetailsRequest request =
        UpdateAccountDetailsRequest.builder().accountName(accountName).build();

    workLogRepository.save(
        buildWorkLog(
            metadata, accountNumberLong, Operation.UPDATE_ACCOUNT_DET, request, SERVICE_USER));

    savingsTransactionLogRepository.save(
        buildSavingsTransactionLogEntry(
            accountNumberLong,
            accountName,
            SavingsTransactionLogEntry.STATUS_ACCOUNT_NAME_CHANGE_COMPLETE,
            now,
            metadata));
  }

  private Collection<Warning> getPendingWarningsFromWorkLog(final String accountNumber) {
    final Collection<WorkLog> pendingAccountWarningWorkLog =
        workLogRepository.findRequestsByAccountNumberAndStateAndOperation(
            WorkLog.Status.PENDING, Operation.INS_ACCOUNT_WARNING, Long.parseLong(accountNumber));
    final List<Warning> warnings = new ArrayList<>();
    for (final WorkLog workLog : pendingAccountWarningWorkLog) {
      final AccountWarningRequest accountWarning =
          (AccountWarningRequest) workLog.getMessage().getWorkLogPayload();
      final Warning warning =
          Warning.builder()
              .code(accountWarning.getWarningType())
              .description(accountWarning.getNotes())
              .build();
      warnings.add(warning);
    }
    return warnings;
  }
}
