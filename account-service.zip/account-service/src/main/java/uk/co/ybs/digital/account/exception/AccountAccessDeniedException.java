package uk.co.ybs.digital.account.exception;

public class AccountAccessDeniedException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public AccountAccessDeniedException(final String message) {
    super(message);
  }
}
