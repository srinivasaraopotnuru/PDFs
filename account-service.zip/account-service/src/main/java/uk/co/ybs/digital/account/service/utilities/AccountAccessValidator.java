package uk.co.ybs.digital.account.service.utilities;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.account.exception.AccountNoCustomerRelationshipException;
import uk.co.ybs.digital.account.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.account.model.adgcore.AccountActivityGroup;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.model.adgcore.LinkedParty;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.repository.adgcore.ActivityPlayerRepository;
import uk.co.ybs.digital.account.repository.adgcore.PartyRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingProductRepository;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Component
@AllArgsConstructor
public class AccountAccessValidator {

  private static final String REQUIRED_ACTIVITY_GROUP_CODE =
      ActivityTypeGroup.ACTIVITY_GROUP_CODE_AISP;

  private final SavingProductRepository savingProductRepository;
  private final ActivityPlayerRepository activityPlayerRepository;
  private final PartyRepository partyRepository;

  public Set<String> validateOwnAccountAccess(
      final String accountNumber,
      final RequestMetadata metadata,
      final Collection<String> activityTypeGroupCodesToRetrieve,
      final LocalDateTime dateTime) {
    validateAccountExistenceAndBrand(accountNumber, metadata);
    return validateCustomerRelationship(
        accountNumber, metadata, activityTypeGroupCodesToRetrieve, dateTime);
  }

  public void validateAccountExistenceAndBrand(
      final String accountNumber, final RequestMetadata metadata) {
    final SavingProduct savingProduct =
        savingProductRepository
            .findBySavingAccountNumber(Long.parseLong(accountNumber))
            .orElseThrow(
                () ->
                    new AccountResourceNotFoundException(
                        String.format("Account %s not found", accountNumber)));

    if (!metadata.getBrandCode().equals(savingProduct.getBrandCode())) {
      throw new AccountAccessDeniedException(
          String.format(
              "Account %s is for brand %s, but request is for brand %s",
              accountNumber, savingProduct.getBrandCode(), metadata.getBrandCode()));
    }
  }

  private Set<String> validateCustomerRelationship(
      final String accountNumber,
      final RequestMetadata metadata,
      final Collection<String> activityTypeGroupCodesToRetrieve,
      final LocalDateTime dateTime) {
    final Collection<String> allActivityTypeGroupCodesToRetrieve =
        new HashSet<>(activityTypeGroupCodesToRetrieve);
    allActivityTypeGroupCodesToRetrieve.add(REQUIRED_ACTIVITY_GROUP_CODE);

    final Long partySysId = Long.valueOf(metadata.getPartyId());

    final Set<String> activityTypeGroupCodes =
        getActivityTypeGroupCodes(
            accountNumber, partySysId, dateTime, allActivityTypeGroupCodesToRetrieve);

    if (!activityTypeGroupCodes.contains(REQUIRED_ACTIVITY_GROUP_CODE)) {
      return getActivityGroupCodeForLinkedParties(
          accountNumber,
          metadata,
          activityTypeGroupCodesToRetrieve,
          dateTime,
          allActivityTypeGroupCodesToRetrieve,
          partySysId);
    }
    activityTypeGroupCodes.retainAll(activityTypeGroupCodesToRetrieve);
    return activityTypeGroupCodes;
  }

  private Set<String> getActivityGroupCodeForLinkedParties(
      final String accountNumber,
      final RequestMetadata metadata,
      final Collection<String> activityTypeGroupCodesToRetrieve,
      final LocalDateTime dateTime,
      final Collection<String> allActivityTypeGroupCodesToRetrieve,
      final Long partySysId) {
    final LinkedParty canonicalPartyId =
        partyRepository
            .findCanonicalPartyId(partySysId)
            .orElseThrow(
                () ->
                    new AccountNoCustomerRelationshipException(
                        String.format(
                            "Customer %s does not have a %s relationship with account %s",
                            metadata.getPartyId(), REQUIRED_ACTIVITY_GROUP_CODE, accountNumber)));

    final Set<String> linkedPartyActivityTypeGroupCodes =
        getActivityTypeGroupCodes(
            accountNumber,
            canonicalPartyId.getCanonicalPartyId(),
            dateTime,
            allActivityTypeGroupCodesToRetrieve);

    if (!linkedPartyActivityTypeGroupCodes.contains(REQUIRED_ACTIVITY_GROUP_CODE)) {
      throw new AccountNoCustomerRelationshipException(
          String.format(
              "Customer %s does not have a %s relationship with account %s",
              metadata.getPartyId(), REQUIRED_ACTIVITY_GROUP_CODE, accountNumber));
    }

    linkedPartyActivityTypeGroupCodes.retainAll(activityTypeGroupCodesToRetrieve);
    return linkedPartyActivityTypeGroupCodes;
  }

  private Set<String> getActivityTypeGroupCodes(
      final String accountNumber,
      final Long partySysId,
      final LocalDateTime dateTime,
      final Collection<String> allActivityTypeGroupCodesToRetrieve) {
    return activityPlayerRepository
        .findAccountsWherePartyHasActivityGroup(
            partySysId,
            allActivityTypeGroupCodesToRetrieve,
            Collections.singleton(Long.parseLong(accountNumber)),
            dateTime)
        .stream()
        .map(AccountActivityGroup::getActivityGroupCode)
        .collect(Collectors.toSet());
  }
}
