package uk.co.ybs.digital.account.service.mapper;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.AccountSummaryMappingBundle;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.web.dto.AccountSummary;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse.AccountGroup;

@Component
@AllArgsConstructor
public class GroupedAccountListMapper {
  private final AccountSummaryMapper accountSummaryMapper;

  public GroupedAccountListResponse mapToAccountGroups(
      final List<AccountSummaryMappingBundle> accountSummaryDataBundles,
      final boolean showClosedAccounts) {

    final GroupedAccountListResponse.GroupedAccountListResponseBuilder groupedAccountBuilder =
        GroupedAccountListResponse.builder();

    final Map<Boolean, Optional<AccountGroup>> accountGroupsByAccountHolder =
        accountSummaryDataBundles.stream()
            .filter(i -> !i.isClosed())
            .collect(
                Collectors.partitioningBy(
                    bundle ->
                        bundle
                            .getActivityGroupCodes()
                            .contains(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS),
                    Collectors.collectingAndThen(Collectors.toList(), this::mapAccountGroup)));

    if (showClosedAccounts) {
      final Optional<GroupedAccountListResponse.AccountGroup> closedAccounts =
          accountSummaryDataBundles.stream()
              .filter(i -> i.isClosed())
              .collect(Collectors.collectingAndThen(Collectors.toList(), this::mapAccountGroup));

      closedAccounts.ifPresent(groupedAccountBuilder::closed);
    }
    accountGroupsByAccountHolder.get(true).ifPresent(groupedAccountBuilder::owned);
    accountGroupsByAccountHolder.get(false).ifPresent(groupedAccountBuilder::other);

    return groupedAccountBuilder.build();
  }

  private Optional<GroupedAccountListResponse.AccountGroup> mapAccountGroup(
      final List<AccountSummaryMappingBundle> accountSummaryDataBundles) {
    if (accountSummaryDataBundles.isEmpty()) {
      return Optional.empty();
    }

    final List<AccountSummary> accounts =
        accountSummaryDataBundles.stream()
            .map(accountSummaryMapper::mapAccountSummary)
            .sorted(AccountSummary.OPENED_DATE_DESCENDING_THEN_ACCOUNT_NUMBER_DESCENDING)
            .collect(Collectors.toList());

    final Map<String, BigDecimal> summedBalances =
        accounts.stream()
            .map(AccountSummary::getBalances)
            .flatMap(Collection::stream)
            .collect(
                Collectors.groupingBy(
                    Balance::getType,
                    Collectors.reducing(BigDecimal.ZERO, Balance::getAmount, BigDecimal::add)));
    final List<Balance> balanceList =
        summedBalances.entrySet().stream()
            .map(e -> Balance.builder().type(e.getKey()).amount(e.getValue()).build())
            .sorted(Comparator.comparing(Balance::getType))
            .collect(Collectors.toList());

    return Optional.of(
        GroupedAccountListResponse.AccountGroup.builder()
            .accounts(accounts)
            .balances(balanceList)
            .build());
  }
}
