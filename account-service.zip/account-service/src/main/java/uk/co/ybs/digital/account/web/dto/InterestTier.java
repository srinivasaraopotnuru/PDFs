package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = InterestTier.InterestTierBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class InterestTier {
  @Schema(required = true, example = "0.700")
  String interestRate;

  @Schema(required = true, example = "0.700")
  String annualEquivalentRate;

  @Schema(example = "1.24")
  BigDecimal rangeLow;

  @Schema(example = "5.00")
  BigDecimal rangeHigh;

  @JsonPOJOBuilder(withPrefix = "")
  public static class InterestTierBuilder {}
}
