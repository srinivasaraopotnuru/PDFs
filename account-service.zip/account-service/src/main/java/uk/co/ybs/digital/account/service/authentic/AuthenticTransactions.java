package uk.co.ybs.digital.account.service.authentic;

import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AuthenticTransactions {
  int totalNumberOfRecords;
  List<AuthenticTransaction> transactionList;
}
