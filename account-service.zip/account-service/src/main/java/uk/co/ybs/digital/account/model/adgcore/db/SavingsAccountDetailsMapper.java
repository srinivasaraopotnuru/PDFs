package uk.co.ybs.digital.account.model.adgcore.db;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Timestamp;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SavingsAccountDetailsMapper implements StructMapper<SavingAccountDetails> {

  public SavingAccountDetails fromStruct(final Struct struct) throws SQLException {
    final SavingAccountDetails.SavingAccountDetailsBuilder savingAccountDetails =
        SavingAccountDetails.builder();
    final Object[] attributes = struct.getAttributes();

    savingAccountDetails.accountNumber(((Number) attributes[0]).longValue());
    savingAccountDetails.currencyCode(String.valueOf(attributes[1]));

    if (attributes[2] == null) {
      savingAccountDetails.accountName(null);
    } else {
      savingAccountDetails.accountName(String.valueOf(attributes[2]));
    }

    final BigDecimal sortCode = (BigDecimal) attributes[3];
    savingAccountDetails.sortCode(sortCode.intValue());

    savingAccountDetails.productIdentifier(String.valueOf(attributes[4]));
    savingAccountDetails.productType(String.valueOf(attributes[5]));
    savingAccountDetails.productName(String.valueOf(attributes[6]));

    if (attributes[7] == null) {
      savingAccountDetails.isPaymentAccount(null);
    } else {
      savingAccountDetails.isPaymentAccount("Y".equalsIgnoreCase(String.valueOf(attributes[7])));
    }

    if (attributes[8] != null) {
      savingAccountDetails.closedDate(((Timestamp) attributes[8]).toLocalDateTime().toLocalDate());
    }

    savingAccountDetails.brandCode(String.valueOf(attributes[9]));
    savingAccountDetails.interestInstruction(String.valueOf(attributes[10]));

    if (attributes[11] != null) {
      savingAccountDetails.nextInterestDate(
          ((Timestamp) attributes[11]).toLocalDateTime().toLocalDate());
    }

    savingAccountDetails.interestFrequency(String.valueOf(attributes[12]));
    savingAccountDetails.accountInterestFrequency(String.valueOf(attributes[13]));
    savingAccountDetails.annualEquivalentRate(String.valueOf(attributes[14]));
    savingAccountDetails.interestRate(String.valueOf(attributes[15]));
    savingAccountDetails.accountHolderName(String.valueOf(attributes[16]));
    savingAccountDetails.accountHolderContext(String.valueOf(attributes[17]));

    return savingAccountDetails.build();
  }
}
