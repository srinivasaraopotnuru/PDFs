package uk.co.ybs.digital.account.service.utilities;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.MonthDay;
import java.time.temporal.TemporalAdjusters;
import org.springframework.stereotype.Component;

@Component
public class PeriodStartCalculator {

  private static final MonthDay TAX_YEAR_START = MonthDay.of(Month.APRIL, 6);

  public LocalDateTime getMonthStart(final LocalDateTime now) {
    return now.toLocalDate().with(TemporalAdjusters.firstDayOfMonth()).atStartOfDay();
  }

  public LocalDateTime getTaxYearStart(final LocalDateTime now) {
    final LocalDate today = now.toLocalDate();
    final LocalDate startInCurrentCalendarYear = today.with(TAX_YEAR_START);
    final LocalDate start =
        startInCurrentCalendarYear.isAfter(today)
            ? startInCurrentCalendarYear.minusYears(1)
            : startInCurrentCalendarYear;
    return start.atStartOfDay();
  }
}
