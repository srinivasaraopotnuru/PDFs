package uk.co.ybs.digital.account.model.adgcore.db;

import java.sql.SQLException;
import java.sql.Struct;

public interface StructMapper<T> {

  T fromStruct(Struct struct) throws SQLException;
}
