package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = AccountSummary.AccountSummaryBuilder.class)
@Schema(name = "AccountBasic")
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountSummary {

  public static final Comparator<AccountSummary>
      OPENED_DATE_DESCENDING_THEN_ACCOUNT_NUMBER_DESCENDING =
          Comparator.comparing(AccountSummary::getOpenedDate)
              .reversed()
              .thenComparing(Comparator.comparing(AccountSummary::getAccountNumber).reversed());

  @Schema(example = "Holiday")
  String accountName;

  @Schema(required = true, example = "1234567890")
  String accountNumber;

  @Schema(required = true)
  boolean amendmentRestriction;

  @Schema(required = true, example = "123456")
  String accountSortCode;

  @Schema(required = true, example = "12345678")
  String externalAccountNumber;

  @Schema(required = true, example = "2017-04-25")
  LocalDate openedDate;

  @Schema(required = true)
  Product product;

  /** @deprecated Redundant field for savings-account service */
  @Deprecated
  @Schema(required = true, example = "Savings")
  String accountType = "Savings";

  /** @deprecated Use product.identifier */
  @Deprecated
  @Schema(required = true, example = "EGG302A")
  String productIdentifier;

  /** @deprecated Use product.description */
  @Deprecated
  @Schema(required = true, example = "Monthly Regular Saver: Issue 2")
  String productDescription;

  @Schema(required = true, example = "GBP")
  String currency;

  @Schema(required = true)
  @JsonProperty(value = "balance")
  List<Balance> balances;

  @Schema(required = true)
  DepositsSummary deposits;

  @Schema(required = true)
  WithdrawalsSummary withdrawals;

  Isa isa;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AccountSummaryBuilder {}
}
