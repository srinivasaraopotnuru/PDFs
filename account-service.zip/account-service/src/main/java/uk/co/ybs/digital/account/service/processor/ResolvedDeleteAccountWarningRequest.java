package uk.co.ybs.digital.account.service.processor;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;

@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ResolvedDeleteAccountWarningRequest implements ResolvedAccountRequest {

  @NonNull private final DeleteAccountWarningRequestArguments arguments;
  @NonNull private final DeleteAccountWarningProcessor processor;
  @NonNull private final AccountNumber accountNumber;

  @Override
  public void execute() {
    processor.execute(arguments, accountNumber);
  }
}
