package uk.co.ybs.digital.account.config;

import java.net.URL;
import lombok.AllArgsConstructor;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.account.service.audit.AuditServiceProperties;
import uk.co.ybs.digital.account.service.product.ProductServiceProperties;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnectorFactory;

@Configuration
@EnableConfigurationProperties({ProductServiceProperties.class, AuditServiceProperties.class})
@AllArgsConstructor
public class ServiceToServiceConfig {

  private final ProductServiceProperties productServiceProperties;
  private final AuditServiceProperties auditServiceProperties;

  @Bean
  public WebClient productServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return buildWebClient(
        builder, requestSigningClientHttpConnectorFactory, productServiceProperties.getUrl());
  }

  @Bean
  public WebClient auditServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return buildWebClient(
        builder, requestSigningClientHttpConnectorFactory, auditServiceProperties.getUrl());
  }

  private WebClient buildWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory,
      final URL url) {
    return builder
        .baseUrl(url.toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }
}
