package uk.co.ybs.digital.account.model.adgcore;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder(toBuilder = true)
@Table(name = "TESSA_DETAILS")
public class TessaDetails {

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  private Long sysid;

  @Column(name = "ACCNUM_ACCOUNT_NUMBER", nullable = false)
  @EqualsAndHashCode.Include
  private Long accountNumber;

  @Column(name = "TESSA_YEAR", nullable = false)
  @EqualsAndHashCode.Include
  private Integer tessaYear;

  @Column(name = "AMOUNT_INVESTED", nullable = false)
  private BigDecimal amountInvested;

  @Column(name = "CREATED_DATE", nullable = false)
  private LocalDateTime createdDate;

  @Column(name = "ENDED_DATE")
  @EqualsAndHashCode.Include
  private LocalDateTime endedDate;

  @Column(name = "PY_FLEXIBILITY")
  private BigDecimal previousYearFlexibility;

  @Column(name = "CY_FLEXIBILITY")
  private BigDecimal currentYearFlexibility;

  @Column(name = "DATE_FIRST_SUB")
  private LocalDateTime dateFirstSub;
}
