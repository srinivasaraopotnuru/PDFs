package uk.co.ybs.digital.account.service.authentic;

public class AccountClosedException extends AuthenticServiceException {

  private static final long serialVersionUID = 1L;

  public AccountClosedException(final String message) {
    super(message);
  }
}
