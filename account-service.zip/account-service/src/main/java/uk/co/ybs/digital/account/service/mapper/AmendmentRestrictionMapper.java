package uk.co.ybs.digital.account.service.mapper;

import java.util.List;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;

@Component
public class AmendmentRestrictionMapper {
  public boolean amendmentRestricted(
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules) {
    return accountWarningRestrictionRules.stream()
        .map(AccountWarningRestrictionRule::getRestrictionTypeRuleCode)
        .anyMatch(RestrictionTypeRule.KNOWN_CODES::contains);
  }
}
