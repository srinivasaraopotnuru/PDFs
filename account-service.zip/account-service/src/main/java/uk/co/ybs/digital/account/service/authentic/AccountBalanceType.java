package uk.co.ybs.digital.account.service.authentic;

import java.math.BigDecimal;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountBalanceType {

  String balanceType;
  BigDecimal balanceAmount;

  public static final class BalanceConstants {
    public static final String TYPE_CAPITAL_AVAILABLE = "CapitalAvailable";
    public static final String TYPE_CAPITAL_LEDGER = "CapitalLedger";
  }
}
