package uk.co.ybs.digital.account.model.adgcore.db;

import java.sql.SQLException;
import java.sql.Struct;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AccountNumberMapper implements StructMapper<AccountNumber> {
  public AccountNumber fromStruct(final Struct struct) throws SQLException {
    final AccountNumber.AccountNumberBuilder accountNumbers = AccountNumber.builder();
    final Object[] attributes = struct.getAttributes();
    accountNumbers.accountNumber(((Number) attributes[0]).longValue());
    return accountNumbers.build();
  }
}
