package uk.co.ybs.digital.account.model.core;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "SAVING_PRODUCTS")
public class SavingProduct {

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private long sysid;

  @Column(name = "BRAND_CODE")
  private String brandCode;
}
