package uk.co.ybs.digital.account.model.adgcore.db;

import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class StatementTransactions {

  int totalNumberOfPages;
  int totalNumberOfTransactions;
  List<StatementTransaction> transactionList;
}
