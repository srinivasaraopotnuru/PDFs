package uk.co.ybs.digital.account.exception;

public class InvalidTransactionDateException extends RuntimeException {

  private static final long serialVersionUID = -7824933952936963863L;

  public InvalidTransactionDateException(final String message) {
    super(message);
  }
}
