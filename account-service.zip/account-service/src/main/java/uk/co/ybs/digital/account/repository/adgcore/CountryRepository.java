package uk.co.ybs.digital.account.repository.adgcore;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import uk.co.ybs.digital.account.model.adgcore.Country;

public interface CountryRepository extends JpaRepository<Country, String> {
  @Query(
      "SELECT au.postalAddress.country FROM AddressUsage au "
          + "   WHERE (au.endDate IS NULL OR au.endDate > :dateTime) "
          + "   AND au.startDate <= :dateTime "
          + "   AND au.party.sysId = :partyId "
          + "ORDER BY au.preferredContactMethod DESC, "
          + "         au.startDate DESC, "
          + "         au.sysId DESC")
  List<Country> findCountriesForPartyId(Long partyId, LocalDateTime dateTime);
}
