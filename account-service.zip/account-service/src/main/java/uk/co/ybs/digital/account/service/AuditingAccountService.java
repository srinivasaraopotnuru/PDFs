package uk.co.ybs.digital.account.service;

import java.util.List;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.web.dto.AccountDetailsFilter;
import uk.co.ybs.digital.account.web.dto.AccountDetailsResponse;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Service
@AllArgsConstructor
public class AuditingAccountService {
  private final AccountService accountService;
  private final AccountAuditor accountAuditor;

  public AccountDetailsResponse getAccountDetails(
      final String accountNumber,
      final List<AccountDetailsFilter> filters,
      final RequestMetadata requestMetadata) {
    final AccountDetailsResponse response =
        accountService.getAccountDetails(accountNumber, filters, requestMetadata);
    accountAuditor.auditAccountDetails(accountNumber, requestMetadata);

    return response;
  }

  public GroupedAccountListResponse getAccountsByGroup(
      final RequestMetadata requestMetadata, final boolean showClosedAccounts) {
    final GroupedAccountListResponse response =
        accountService.getAccountGroups(requestMetadata, showClosedAccounts);
    accountAuditor.auditAccountList(requestMetadata);
    return response;
  }
}
