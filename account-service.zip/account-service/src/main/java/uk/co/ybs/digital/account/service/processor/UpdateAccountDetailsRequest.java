package uk.co.ybs.digital.account.service.processor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;

@AllArgsConstructor
@Builder
@EqualsAndHashCode
@ToString
public class UpdateAccountDetailsRequest implements AccountRequest {

  @NonNull private final UpdateAccountDetailsRequestArguments arguments;
  @NonNull private final UpdateAccountDetailsProcessor processor;

  @Override
  public ResolvedAccountRequest resolve() {

    final AccountNumber accountNumber = processor.resolve(arguments);

    return new ResolvedUpdateAccountDetailsRequest(arguments, processor, accountNumber);
  }

  @Override
  public void auditFailure(final String message) {
    processor.auditFailure(arguments, message);
  }
}
