package uk.co.ybs.digital.account.config;

import java.time.Clock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import uk.co.ybs.digital.account.service.AccountServiceProperties;

@Configuration
@Slf4j
@EnableConfigurationProperties(AccountServiceProperties.class)
public class AccountServiceConfig {

  @Bean
  public Clock clock() {
    // The application should be run in UK timezone for consistency with other
    // YBS timezone handling.
    final Clock systemClock = Clock.systemDefaultZone();
    log.info("System clock is: {}", systemClock);

    return systemClock;
  }
}
