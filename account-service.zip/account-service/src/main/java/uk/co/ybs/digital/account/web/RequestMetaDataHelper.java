package uk.co.ybs.digital.account.web;

import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import lombok.experimental.UtilityClass;
import org.springframework.http.HttpHeaders;
import org.springframework.security.oauth2.jwt.Jwt;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@UtilityClass
public class RequestMetaDataHelper {
  private static final String BRAND_CODE_CLAIM = "brand_code";
  private static final String PARTY_ID_CLAIM = "party_id";

  public static RequestMetadata buildRequestMetaData(
      final Jwt user,
      final UUID requestId,
      final HttpServletRequest request,
      final HttpHeaders headers) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .host(headers.getHost())
        .partyId(user.getClaimAsString(PARTY_ID_CLAIM))
        .forwardingAuth(user.getTokenValue())
        .brandCode(user.getClaimAsString(BRAND_CODE_CLAIM))
        .ipAddress(request.getRemoteAddr())
        .build();
  }

  public static RequestMetadata buildRequestMetaData(
      final Jwt user,
      final String partyId,
      final UUID requestId,
      final HttpServletRequest request,
      final HttpHeaders headers) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .host(headers.getHost())
        .partyId(partyId)
        .forwardingAuth(user.getTokenValue())
        .brandCode(user.getClaimAsString(BRAND_CODE_CLAIM))
        .ipAddress(request.getRemoteAddr())
        .build();
  }
}
