package uk.co.ybs.digital.account.config.persistence;

import com.zaxxer.hikari.HikariDataSource;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.flyway.FlywayDataSource;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateProperties;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.PlatformTransactionManager;
import uk.co.ybs.digital.account.config.persistence.builder.HibernateEntityManagerFactoryBuilder;
import uk.co.ybs.digital.account.config.persistence.builder.HikariDataSourceBuilder;
import uk.co.ybs.digital.account.config.persistence.builder.JpaTransactionManagerBuilder;

@Configuration
@EnableJpaRepositories(
    basePackages = DigitalAccountConfiguration.REPOSITORY_PACKAGE,
    entityManagerFactoryRef = "digitalAccountEntityManagerFactory")
public class DigitalAccountConfiguration {

  private static final String PERSISTENCE_UNIT = "digitalaccount";

  private static final String DATASOURCE_PROPERTIES =
      PersistenceConfiguration.DATASOURCE_PROPERTY_PREFIX + PERSISTENCE_UNIT;
  private static final String HIKARI_PROPERTIES = DATASOURCE_PROPERTIES + ".hikari";

  private static final String JPA_PROPERTIES =
      PersistenceConfiguration.JPA_PROPERTIES_PREFIX + PERSISTENCE_UNIT;
  private static final String HIBERNATE_PROPERTIES = JPA_PROPERTIES + ".hibernate";

  private static final String MODEL_PACKAGE =
      PersistenceConfiguration.MODEL_PACKAGE_PREFIX + PERSISTENCE_UNIT;
  public static final String REPOSITORY_PACKAGE =
      PersistenceConfiguration.REPOSITORY_PACKAGE_PREFIX + PERSISTENCE_UNIT;

  @Bean
  @ConfigurationProperties(prefix = DATASOURCE_PROPERTIES)
  public DataSourceProperties digitalAccountDataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = HIKARI_PROPERTIES)
  public HikariDataSource digitalAccountDataSource(
      final DataSourceProperties digitalAccountDataSourceProperties) {
    return new HikariDataSourceBuilder()
        .withDataSourceProperties(digitalAccountDataSourceProperties)
        .build();
  }

  @Bean
  @ConfigurationProperties(prefix = JPA_PROPERTIES)
  public JpaProperties digitalAccountJpaProperties() {
    return new JpaProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = HIBERNATE_PROPERTIES)
  public HibernateProperties digitalAccountHibernateProperties() {
    return new HibernateProperties();
  }

  @Bean
  public FactoryBean<EntityManagerFactory> digitalAccountEntityManagerFactory(
      final DataSource digitalAccountDataSource,
      final JpaProperties digitalAccountJpaProperties,
      final HibernateProperties digitalAccountHibernateProperties) {
    return new HibernateEntityManagerFactoryBuilder()
        .withDataSource(digitalAccountDataSource)
        .withHibernateProperties(digitalAccountHibernateProperties)
        .withJpaProperties(digitalAccountJpaProperties)
        .withPackagesToScan(new String[] {MODEL_PACKAGE})
        .withPersistenceUnitName(PERSISTENCE_UNIT)
        .build();
  }

  @Bean
  public PlatformTransactionManager digitalAccountTransactionManager(
      final EntityManagerFactory digitalAccountEntityManagerFactory,
      final ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
    return new JpaTransactionManagerBuilder()
        .withEntityManagerFactory(digitalAccountEntityManagerFactory)
        .withTransactionManagerCustomizers(transactionManagerCustomizers)
        .build();
  }

  @FlywayDataSource
  @Bean(initMethod = "migrate")
  public Flyway flyway(@Qualifier("digitalAccountDataSource") final HikariDataSource dataSource) {
    return Flyway.configure().dataSource(dataSource).load();
  }
}
