package uk.co.ybs.digital.account.service.mapper;

import java.math.RoundingMode;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.model.adgcore.SavingTransaction;
import uk.co.ybs.digital.account.repository.adgcore.SavingTransactionRepository;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse.Transaction;

@Component
@RequiredArgsConstructor
@Slf4j
public class TransactionInterestMapper {
  private final SavingTransactionRepository savingTransactionRepository;

  @Transactional(readOnly = true, transactionManager = "transactionManager")
  public List<Transaction> mapInterestRateForTransactions(final List<Transaction> transactions) {
    return transactions.stream()
        .map(this::mapInterestRateForTransaction)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  private Transaction mapInterestRateForTransaction(final Transaction transaction) {
    return savingTransactionRepository
        .findById(Long.valueOf(transaction.getTransactionId()))
        .map(
            retrievedTransaction ->
                Transaction.builder()
                    .accountNumber(transaction.getAccountNumber())
                    .transactionId(transaction.getTransactionId())
                    .transactionReference(transaction.getTransactionReference())
                    .creditDebitIndicator(transaction.getCreditDebitIndicator())
                    .status(transaction.getStatus())
                    .bookingDateTime(transaction.getBookingDateTime())
                    .valueDateTime(transaction.getValueDateTime())
                    .amount(transaction.getAmount())
                    .transactionCode(transaction.getTransactionCode())
                    .transactionInformation(transaction.getTransactionInformation())
                    .balances(transaction.getBalances())
                    .interestRate(getInterestRateFromTransaction(retrievedTransaction))
                    .blendedFlag(shouldReportBlendedRate(retrievedTransaction))
                    .build())
        .orElse(null);
  }

  private String getInterestRateFromTransaction(final SavingTransaction savingTransaction) {
    return savingTransaction.getBlendedInterestRate() != null
        ? savingTransaction.getBlendedInterestRate().setScale(3, RoundingMode.DOWN).toString()
        : savingTransaction.getNewInterestRate().setScale(3, RoundingMode.DOWN).toString();
  }

  private boolean shouldReportBlendedRate(final SavingTransaction transaction) {
    return transaction.getBlendedInterestRate() != null
        && !transaction.getBlendedInterestRate().equals(transaction.getNewInterestRate());
  }
}
