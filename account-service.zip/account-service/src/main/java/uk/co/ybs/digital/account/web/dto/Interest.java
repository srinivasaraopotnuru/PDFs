package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDate;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Interest.InterestBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Interest {
  @Schema(required = true, example = "PayAway")
  String interestInstruction;

  @Schema(required = true, example = "2019-04-12")
  LocalDate nextPaymentDate;

  @Schema(required = true, example = "Monthly")
  String calculationFrequency;

  @Schema(required = true, example = "Monthly")
  String applicationFrequency;

  @Schema(example = "Fixed")
  String interestRateType = "Fixed";

  @Schema(example = "Whole")
  String interestCalculation = "Whole";

  @Schema(required = true)
  List<InterestTier> interestTiers;

  @Schema(required = true)
  boolean interestOptionsPermitted;

  @JsonPOJOBuilder(withPrefix = "")
  public static class InterestBuilder {}
}
