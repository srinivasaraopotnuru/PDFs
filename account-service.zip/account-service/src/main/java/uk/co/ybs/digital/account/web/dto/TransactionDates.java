package uk.co.ybs.digital.account.web.dto;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class TransactionDates {
  final LocalDateTime startDate;
  final LocalDateTime endDate;
}
