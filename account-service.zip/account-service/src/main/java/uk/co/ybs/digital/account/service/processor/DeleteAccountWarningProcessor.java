package uk.co.ybs.digital.account.service.processor;

import static java.time.LocalDateTime.now;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException.Reason;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.RestrictionType;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.copy.AccountWarningCopyRepository;
import uk.co.ybs.digital.account.repository.core.AccountWarningCoreRepository;
import uk.co.ybs.digital.account.repository.core.RestrictionTypeCoreRepository;

@Component
@RequiredArgsConstructor
@Transactional("accountProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
@Slf4j
public class DeleteAccountWarningProcessor {

  private final AccountNumberRepository accountNumberRepository;
  private final RestrictionTypeCoreRepository restrictionTypeCoreRepository;
  private final AccountWarningCoreRepository accountWarningCoreRepository;
  private final AccountWarningCopyRepository accountWarningCopyRepository;
  private final Clock clock;

  public AccountNumber resolve(final DeleteAccountWarningRequestArguments arguments) {
    final Long accountNumber = arguments.getAccountNumber();
    return accountNumberRepository
        .findById(accountNumber)
        .orElseThrow(
            () ->
                (new AccountNotFoundException(
                    "Failed to find account " + accountNumber + " in the database")));
  }

  public void execute(
      final DeleteAccountWarningRequestArguments arguments, final AccountNumber accountNumber) {

    log.info("Finding restriction type: " + arguments.getWarningCode());
    final RestrictionType restrictionType =
        restrictionTypeCoreRepository
            .findByCode(arguments.getWarningCode())
            .orElseThrow(() -> (new AccountRequestProcessingException(Reason.WARNING_NOT_FOUND)));

    final LocalDateTime now = now(clock);

    // Core
    final Collection<AccountWarning> accountWarningListCore =
        accountWarningCoreRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber.getAccountNumber(),
            Collections.singletonList(restrictionType.getCode()),
            now);
    accountWarningListCore.stream()
        .forEach(
            accWarning -> {
              accWarning.setEndedBy(arguments.getEndAt());
              accWarning.setEndedAt(arguments.getEndAt());
              accWarning.setEndedDate(arguments.getProcessTime());
              accWarning.setEndDate(arguments.getProcessTime().toLocalDate());
            });
    accountWarningCoreRepository.saveAllAndFlush(accountWarningListCore);

    // Copy
    final Collection<uk.co.ybs.digital.account.model.copy.AccountWarning> accountWarningListCopy =
        accountWarningCopyRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber.getAccountNumber(),
            Collections.singletonList(restrictionType.getCode()),
            now);
    accountWarningListCopy.stream()
        .forEach(
            accWarning -> {
              accWarning.setEndedBy(arguments.getEndAt());
              accWarning.setEndedAt(arguments.getEndAt());
              accWarning.setEndedDate(arguments.getProcessTime());
              accWarning.setEndDate(arguments.getProcessTime().toLocalDate());
            });

    log.info(
        "deleting warning {} for user {}",
        arguments.getWarningCode(),
        arguments.getAccountNumber());
    accountWarningCopyRepository.saveAllAndFlush(accountWarningListCopy);
  }
}
