package uk.co.ybs.digital.account.exception;

public class AccountResourceNotFoundException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public AccountResourceNotFoundException(final String message) {
    super(message);
  }
}
