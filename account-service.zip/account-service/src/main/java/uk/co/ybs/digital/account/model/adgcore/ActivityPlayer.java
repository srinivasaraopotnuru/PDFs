package uk.co.ybs.digital.account.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ACTIVITY_PLAYERS")
public class ActivityPlayer {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @EqualsAndHashCode.Include // Generated ids's are bad for equality in JPA, but nothing else unique
  private Long sysId;

  @Column(name = "TABLE_ID", nullable = false)
  private String tableId;

  @Column(name = "TABLE_SYSID", nullable = false)
  private Long tableSysId;

  @Column(name = "PARTY_SYSID", nullable = false)
  private Long partySysId;

  @ManyToOne
  @JoinColumn(name = "ACTTYP_CODE", nullable = false)
  private ActivityType activityType;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;
}
