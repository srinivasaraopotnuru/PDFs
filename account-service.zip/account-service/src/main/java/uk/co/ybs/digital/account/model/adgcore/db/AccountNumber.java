package uk.co.ybs.digital.account.model.adgcore.db;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
@SuppressWarnings("PMD.AvoidFieldNameMatchingTypeName")
public class AccountNumber {

  private Long accountNumber;
}
