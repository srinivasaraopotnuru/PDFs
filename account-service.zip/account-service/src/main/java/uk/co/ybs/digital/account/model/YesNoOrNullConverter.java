package uk.co.ybs.digital.account.model;

import javax.persistence.AttributeConverter;

public class YesNoOrNullConverter implements AttributeConverter<Boolean, String> {
  @Override
  public String convertToDatabaseColumn(final Boolean bool) {
    if (bool == null) {
      return null;
    }

    return bool ? "Y" : "N";
  }

  @Override
  public Boolean convertToEntityAttribute(final String yesOrNo) {

    if (yesOrNo == null) {
      return null;
    }

    return "Y".equalsIgnoreCase(yesOrNo);
  }
}
