package uk.co.ybs.digital.account.model.adgcore;

import java.time.LocalDate;
import java.util.Optional;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "SAVACC_ANNWDL_LIMITS")
public class SavingAccountAnnualWithdrawalLimit {

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  private Long sysId;

  @ManyToOne
  @JoinColumn(name = "SAVACC_ACCOUNT_NUMBER")
  @EqualsAndHashCode.Include
  private AccountNumber accountNumber;

  @Column(name = "SPRD_SYSID", nullable = false)
  @EqualsAndHashCode.Include
  private Long savingProductSysId;

  @Column(name = "WITHDRAWAL_ALLOWED", nullable = false)
  private int withdrawalsAllowed;

  @Column(name = "WITHDRAWAL_MADE", nullable = false)
  private int withdrawalsMade;

  @Column(name = "YEAR_START_DATE")
  private LocalDate yearStart;

  public Optional<Integer> getNonZeroWithdrawalsAllowed() {
    return withdrawalsAllowed > 0 ? Optional.of(withdrawalsAllowed) : Optional.empty();
  }

  public Optional<Integer> getAvailableWithdrawals() {
    return getNonZeroWithdrawalsAllowed()
        .map(allowed -> Integer.max(withdrawalsAllowed - withdrawalsMade, 0));
  }
}
