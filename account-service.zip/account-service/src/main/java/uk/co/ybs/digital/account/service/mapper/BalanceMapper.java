package uk.co.ybs.digital.account.service.mapper;

import com.google.common.collect.ImmutableMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType.BalanceConstants;
import uk.co.ybs.digital.account.web.dto.Balance;

@Component
public class BalanceMapper {
  private static final Map<String, String> BALANCE_TYPE_MAPPINGS =
      ImmutableMap.of(
          BalanceConstants.TYPE_CAPITAL_AVAILABLE, "InterimAvailable",
          BalanceConstants.TYPE_CAPITAL_LEDGER, "InterimBooked");

  private Balance mapBalance(final AccountBalanceType balance) {
    return Balance.builder()
        .type(mapBalanceType(balance.getBalanceType()))
        .amount(balance.getBalanceAmount())
        .build();
  }

  protected String mapBalanceType(final String type) {
    return BALANCE_TYPE_MAPPINGS.get(type);
  }

  public List<Balance> filterAndMapAccountBalanceTypeList(
      final List<AccountBalanceType> accountBalanceTypeList,
      final boolean withdrawalsPermittedOverApi) {
    final List<Balance> balances = this.filterAndMapAccountBalanceTypeList(accountBalanceTypeList);
    if (!withdrawalsPermittedOverApi) {
      balances.removeIf(balance -> "InterimAvailable".equals(balance.getType()));
    }
    return balances;
  }

  public List<Balance> filterAndMapAccountBalanceTypeList(
      final List<AccountBalanceType> accountBalanceTypeList) {
    return accountBalanceTypeList.stream()
        .filter(balanceType -> BALANCE_TYPE_MAPPINGS.containsKey(balanceType.getBalanceType()))
        .map(this::mapBalance)
        .collect(Collectors.toList());
  }
}
