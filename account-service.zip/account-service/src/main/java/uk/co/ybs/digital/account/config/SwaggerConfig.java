package uk.co.ybs.digital.account.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.media.UUIDSchema;
import io.swagger.v3.oas.models.parameters.HeaderParameter;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springdoc.core.customizers.OpenApiCustomiser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import uk.co.ybs.digital.security.HttpHeaderNames;

@Configuration
public class SwaggerConfig {
  public static final String SECURITY_SCHEME = "digital-oauth2";

  @Bean
  public OpenAPI api(@Value("${build.version:0.0.1}") final String appVersion) {
    return new OpenAPI()
        .components(
            new Components()
                .addParameters(
                    "request-id",
                    new Parameter()
                        .name("x-ybs-request-id")
                        .required(false)
                        .in("header")
                        .description("Unique identifier for the request")
                        .schema(new UUIDSchema()))
                .addParameters(
                    "request-signature",
                    new Parameter()
                        .name(HttpHeaderNames.REQUEST_SIGNATURE)
                        .required(true)
                        .in("header")
                        .description("Base64 encoded request signature")
                        .schema(new StringSchema()))
                .addParameters(
                    "request-signature-key-id",
                    new Parameter()
                        .name(HttpHeaderNames.REQUEST_SIGNATURE_KEY_ID)
                        .required(true)
                        .in("header")
                        .description("Identifier for the key used to sign the request")
                        .schema(new StringSchema()))
                .addSecuritySchemes(
                    SECURITY_SCHEME,
                    new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("bearer")
                        .bearerFormat("JWT")))
        .info(new Info().title("Account Service").version(appVersion));
  }

  @Bean
  public OpenApiCustomiser consumerTypeHeaderOpenAPICustomiser() {
    return openApi ->
        openApi.getPaths().values().stream()
            .flatMap(pathItem -> pathItem.readOperations().stream())
            .forEach(
                operation ->
                    operation
                        .addParametersItem(
                            new HeaderParameter().$ref("#/components/parameters/request-id"))
                        .addParametersItem(
                            new HeaderParameter().$ref("#/components/parameters/request-signature"))
                        .addParametersItem(
                            new HeaderParameter()
                                .$ref("#/components/parameters/request-signature-key-id")));
  }
}
