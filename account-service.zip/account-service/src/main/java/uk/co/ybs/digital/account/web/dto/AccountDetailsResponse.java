package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = AccountDetailsResponse.AccountDetailsResponseBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountDetailsResponse {

  AccountDetails account;

  @JsonPOJOBuilder(withPrefix = "")
  public static class AccountDetailsResponseBuilder {}
}
