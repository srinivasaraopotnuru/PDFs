package uk.co.ybs.digital.account.config.persistence;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateProperties;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.PlatformTransactionManager;
import uk.co.ybs.digital.account.config.persistence.builder.HibernateEntityManagerFactoryBuilder;
import uk.co.ybs.digital.account.config.persistence.builder.HikariDataSourceBuilder;
import uk.co.ybs.digital.account.config.persistence.builder.JpaTransactionManagerBuilder;

@Configuration
@EnableJpaRepositories(
    basePackages = CopyConfiguration.REPOSITORY_PACKAGE,
    entityManagerFactoryRef = "copyEntityManagerFactory")
public class CopyConfiguration {

  public static final String PERSISTENCE_UNIT = "copy";

  private static final String DATASOURCE_PROPERTIES =
      PersistenceConfiguration.DATASOURCE_PROPERTY_PREFIX + PERSISTENCE_UNIT;
  private static final String HIKARI_PROPERTIES = DATASOURCE_PROPERTIES + ".hikari";

  private static final String JPA_PROPERTIES =
      PersistenceConfiguration.JPA_PROPERTIES_PREFIX + PERSISTENCE_UNIT;
  private static final String HIBERNATE_PROPERTIES = JPA_PROPERTIES + ".hibernate";

  private static final String MODEL_PACKAGE =
      PersistenceConfiguration.MODEL_PACKAGE_PREFIX + PERSISTENCE_UNIT;
  public static final String REPOSITORY_PACKAGE =
      PersistenceConfiguration.REPOSITORY_PACKAGE_PREFIX + PERSISTENCE_UNIT;

  @Bean
  @ConfigurationProperties(prefix = DATASOURCE_PROPERTIES)
  public DataSourceProperties copyDataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = HIKARI_PROPERTIES)
  public DataSource copyDataSource(final DataSourceProperties copyDataSourceProperties) {
    return new HikariDataSourceBuilder().withDataSourceProperties(copyDataSourceProperties).build();
  }

  @Bean
  @ConfigurationProperties(prefix = JPA_PROPERTIES)
  public JpaProperties copyJpaProperties() {
    return new JpaProperties();
  }

  @Bean
  @ConfigurationProperties(prefix = HIBERNATE_PROPERTIES)
  public HibernateProperties copyHibernateProperties() {
    return new HibernateProperties();
  }

  @Bean
  public FactoryBean<EntityManagerFactory> copyEntityManagerFactory(
      final DataSource copyDataSource,
      final JpaProperties copyJpaProperties,
      final HibernateProperties copyHibernateProperties) {
    return new HibernateEntityManagerFactoryBuilder()
        .withDataSource(copyDataSource)
        .withHibernateProperties(copyHibernateProperties)
        .withJpaProperties(copyJpaProperties)
        .withPackagesToScan(new String[] {MODEL_PACKAGE})
        .withPersistenceUnitName(PERSISTENCE_UNIT)
        .build();
  }

  @Bean
  public PlatformTransactionManager copyTransactionManager(
      final EntityManagerFactory copyEntityManagerFactory,
      final ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers) {
    return new JpaTransactionManagerBuilder()
        .withEntityManagerFactory(copyEntityManagerFactory)
        .withTransactionManagerCustomizers(transactionManagerCustomizers)
        .build();
  }
}
