package uk.co.ybs.digital.account.service.utilities;

import java.time.LocalDate;
import lombok.experimental.UtilityClass;

@UtilityClass
public class AccountClosedCalculator {

  public static boolean isAccountClosed(final LocalDate closedDate, final LocalDate today) {
    return closedDate != null && !closedDate.isAfter(today);
  }
}
