package uk.co.ybs.digital.account.repository.adgcore;

import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;

public interface SavingAccountAnnualWithdrawalLimitRepository
    extends JpaRepository<SavingAccountAnnualWithdrawalLimit, Long> {

  @Query(
      "SELECT sawl "
          + "FROM SavingAccountAnnualWithdrawalLimit sawl "
          + "JOIN FETCH sawl.accountNumber an "
          + "WHERE an.savingProductSysId = sawl.savingProductSysId "
          + "AND an.accountNumber IN :accountNumbers ")
  Collection<SavingAccountAnnualWithdrawalLimit> findAllByAccountNumbers(
      @Param("accountNumbers") Collection<Long> accountNumbers);
}
