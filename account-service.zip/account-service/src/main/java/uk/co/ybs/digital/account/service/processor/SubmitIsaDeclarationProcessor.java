package uk.co.ybs.digital.account.service.processor;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.RestrictionType;
import uk.co.ybs.digital.account.model.core.WarningNote;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.core.AccountWarningCoreRepository;
import uk.co.ybs.digital.account.repository.core.WarningNoteCoreRepository;
import uk.co.ybs.digital.account.service.AccountAuditor;

@Component
@RequiredArgsConstructor
@Transactional("accountProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public class SubmitIsaDeclarationProcessor {

  private final AccountNumberRepository accountNumberRepository;
  private final AccountWarningCoreRepository accountWarningCoreRepository;
  private final WarningNoteCoreRepository warningNoteCoreRepository;
  private final AccountAuditor accountAuditor;

  public AccountNumber resolve(final SubmitIsaDeclarationRequestArguments arguments) {

    final Long accountNumber = arguments.getAccountNumber();

    return accountNumberRepository
        .findById(accountNumber)
        .orElseThrow(
            () ->
                (new AccountNotFoundException(
                    "Failed to find account " + accountNumber + " in the database")));
  }

  public void execute(final SubmitIsaDeclarationRequestArguments arguments) {
    final LocalDateTime processTime = arguments.getProcessTime();
    final Collection<AccountWarning> accountWarnings =
        getAccountWarnings(arguments.getAccountNumber(), processTime);
    if (accountWarnings.size() < 1) {
      throw new AccountRequestProcessingException(
          AccountRequestProcessingException.Reason.ISA_DECLARATION_WARNINGS_NOT_FOUND);
    }

    final Collection<AccountWarning> updatedWarnings =
        accountWarnings.stream()
            .map(warning -> endWarning(warning, processTime))
            .collect(Collectors.toList());

    final Collection<WarningNote> updatedWarningNotes =
        accountWarnings.stream()
            .map(warning -> getWarningNotes(warning, processTime))
            .flatMap(Collection::stream)
            .map(warningNote -> endWarningNote(warningNote, processTime))
            .collect(Collectors.toList());

    accountWarningCoreRepository.saveAll(updatedWarnings);
    warningNoteCoreRepository.saveAll(updatedWarningNotes);

    accountWarningCoreRepository.flush();
    warningNoteCoreRepository.flush();
  }

  public void auditSuccess(final SubmitIsaDeclarationRequestArguments arguments) {
    accountAuditor.auditIsaSubmissionDeclarationSuccess(
        arguments.getAccountNumber().toString(), arguments.getRequestMetadata());
  }

  public void auditFailure(
      final SubmitIsaDeclarationRequestArguments arguments, final String message) {
    accountAuditor.auditIsaSubmissionDeclarationFailure(
        arguments.getAccountNumber().toString(), arguments.getRequestMetadata(), message);
  }

  private Collection<AccountWarning> getAccountWarnings(
      final Long accountNumber, final LocalDateTime processTime) {
    return accountWarningCoreRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
        accountNumber, Collections.singletonList(RestrictionType.NO_SUBSCRIPTIONS), processTime);
  }

  private Collection<WarningNote> getWarningNotes(
      final AccountWarning warning, final LocalDateTime processTime) {
    return warningNoteCoreRepository.findWarningNoteByAccountWarningSysId(
        warning.getSysId(), processTime);
  }

  private AccountWarning endWarning(final AccountWarning warning, final LocalDateTime processTime) {
    return warning
        .toBuilder()
        .endedBy(AccountProcessorConstants.ENDED_BY)
        .endedAt(AccountProcessorConstants.ENDED_AT)
        .endDate(processTime.toLocalDate())
        .endedDate(processTime)
        .build();
  }

  private WarningNote endWarningNote(final WarningNote note, final LocalDateTime processTime) {
    return note.toBuilder()
        .endedBy(AccountProcessorConstants.ENDED_BY)
        .endedAt(AccountProcessorConstants.ENDED_BY)
        .endDate(processTime.toLocalDate())
        .endedDate(processTime)
        .build();
  }
}
