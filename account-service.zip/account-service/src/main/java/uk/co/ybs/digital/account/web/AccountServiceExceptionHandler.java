package uk.co.ybs.digital.account.web;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import javax.validation.ConstraintViolationException;
import javax.validation.ElementKind;
import javax.validation.Path;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.account.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.account.exception.AccountNameConflictException;
import uk.co.ybs.digital.account.exception.AccountNoCustomerRelationshipException;
import uk.co.ybs.digital.account.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.account.exception.AccountWarningsResourceNotFoundException;
import uk.co.ybs.digital.account.exception.InvalidTransactionDateException;
import uk.co.ybs.digital.account.exception.NoUpdatedAccountDetailsSpecifiedException;
import uk.co.ybs.digital.account.exception.WorkLogConflictException;
import uk.co.ybs.digital.account.web.ErrorResponse.ErrorItem;

@Slf4j
@ControllerAdvice
public class AccountServiceExceptionHandler {

  @ExceptionHandler(RuntimeException.class)
  public ResponseEntity<ErrorResponse> handleUnknownErrors(
      final RuntimeException exception, final WebRequest request) {
    log.error(
        "Unhandled exception thrown. Returning 500 Internal Error. {}",
        exception.getMessage(),
        exception);
    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    final ErrorResponse response =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Internal Server Error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorItem.UNEXPECTED_ERROR)
                    .message("Internal Server Error")
                    .build())
            .build();

    return ResponseEntity.status(status).body(response);
  }

  @ExceptionHandler(AccessDeniedException.class)
  public void handleInvalidJwtScope(final AccessDeniedException exception) {
    // Let spring security handle it.
    throw exception;
  }

  @ExceptionHandler(ConstraintViolationException.class)
  public ResponseEntity<ErrorResponse> constraintViolated(
      final ConstraintViolationException exception, final WebRequest webrequest) {
    final HttpStatus status = HttpStatus.BAD_REQUEST;

    final List<ErrorItem> errorItems =
        exception.getConstraintViolations().stream()
            .map(this::mapConstraintViolation)
            .collect(Collectors.toList());

    final UUID requestId = RequestIdHelper.getRequestId(webrequest);
    final ErrorResponse response =
        ErrorResponse.builder(status)
            .id(requestId)
            .message("Invalid value")
            .errors(errorItems)
            .build();
    return ResponseEntity.status(status).body(response);
  }

  private ErrorItem mapConstraintViolation(
      final javax.validation.ConstraintViolation<?> constraintViolation) {
    final boolean missing = constraintViolation.getInvalidValue() == null;
    final String errorCode = missing ? ErrorItem.FIELD_MISSING : ErrorItem.FIELD_INVALID;

    final String parameterName =
        StreamSupport.stream(constraintViolation.getPropertyPath().spliterator(), false)
            .filter(node -> node.getKind() == ElementKind.PARAMETER)
            .map(Path.Node::getName)
            .findFirst()
            .orElse("parameter");

    final String message =
        missing
            ? String.format("%s %s", parameterName, constraintViolation.getMessage())
            : String.format(
                "%s %s %s",
                parameterName,
                constraintViolation.getInvalidValue(),
                constraintViolation.getMessage());

    return ErrorItem.builder().errorCode(errorCode).message(message).build();
  }

  @ExceptionHandler({AccountResourceNotFoundException.class})
  public ResponseEntity<ErrorResponse> resourceNotFound(
      final RuntimeException exception, final WebRequest request) {
    log.info("Handled resource not found, returning 404 Not Found: {}", exception.toString());
    final HttpStatus status = HttpStatus.NOT_FOUND;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Resource not found")
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.RESOURCE_NOT_FOUND)
                    .message("Resource not found")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler({AccountWarningsResourceNotFoundException.class})
  public ResponseEntity<ErrorResponse> resourceNotFoundForWarnings(
      final AccountWarningsResourceNotFoundException exception, final WebRequest request) {
    log.info("Handled resource not found, returning 404 Not Found: {}", exception.toString());
    final HttpStatus status = HttpStatus.NOT_FOUND;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Resource not found")
            .error(
                ErrorItem.builder()
                    .errorCode(exception.getErrorCode())
                    .message(exception.getMessage())
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(AccountAccessDeniedException.class)
  public ResponseEntity<ErrorResponse> accountAccessDenied(
      final AccountAccessDeniedException exception, final WebRequest request) {
    log.info(
        "Caught unhandled AccountAccessDeniedException, returning 403 Forbidden: {}",
        exception.toString());
    final HttpStatus status = HttpStatus.FORBIDDEN;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.ACCESS_DENIED)
                    .message("Access Denied")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(AccountNoCustomerRelationshipException.class)
  public ResponseEntity<ErrorResponse> accountNoCustomerRelationship(
      final AccountNoCustomerRelationshipException exception, final WebRequest request) {
    log.info(
        "Caught unhandled AccountNoCustomerRelationshipException, returning 403 Forbidden: {}",
        exception.toString());
    final HttpStatus status = HttpStatus.FORBIDDEN;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.NO_CUSTOMER_RELATIONSHIP)
                    .message("Access Denied")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(WorkLogConflictException.class)
  public ResponseEntity<ErrorResponse> accountAccessDenied(
      final WorkLogConflictException exception, final WebRequest request) {
    log.info(
        "ISA Declaration in process conflict, returning 409 Conflict: {}", exception.toString());
    final HttpStatus status = HttpStatus.CONFLICT;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(ErrorItem.builder().errorCode(ErrorItem.CONFLICT).message("CONFLICT").build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(AccountNameConflictException.class)
  public ResponseEntity<ErrorResponse> accountNameConflictException(
      final AccountNameConflictException exception, final WebRequest request) {
    log.info("Account name has not changed, returning 409 Conflict: {}", exception.toString());
    final HttpStatus status = HttpStatus.CONFLICT;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(ErrorItem.builder().errorCode(ErrorItem.CONFLICT).message("CONFLICT").build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(NoUpdatedAccountDetailsSpecifiedException.class)
  public ResponseEntity<ErrorResponse> noUpdatedAccountDetailsSpecified(
      final NoUpdatedAccountDetailsSpecifiedException exception, final WebRequest request) {
    log.info(
        "No updated account details specified, returning 400 Bad Request: {}",
        exception.toString());
    final HttpStatus status = HttpStatus.BAD_REQUEST;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.FIELD_MISSING)
                    .message("No updated account details specified")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(InvalidTransactionDateException.class)
  public ResponseEntity<ErrorResponse> invalidDateFormat(
      final InvalidTransactionDateException exception, final WebRequest request) {
    log.info(
        "Invalid date format query parameter(s), returning 400 Bad Request: {}",
        exception.toString());
    final HttpStatus status = HttpStatus.BAD_REQUEST;
    final ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .error(
                ErrorItem.builder()
                    .errorCode(ErrorItem.DATE_INVALID)
                    .message("Invalid date range")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }
}
