package uk.co.ybs.digital.account.service;

import java.util.List;
import lombok.Value;
import lombok.experimental.NonFinal;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.validation.annotation.Validated;

@Value
@NonFinal
@ConstructorBinding
@ConfigurationProperties(prefix = "uk.co.ybs.digital.account")
@Validated
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountServiceProperties {

  // Represents a list of account numbers to not create account requests for.
  // Used by smoke/e2e tests
  List<String> accountNumberBlacklist;
}
