package uk.co.ybs.digital.account.model.digitalaccount;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@EqualsAndHashCode(callSuper = false)
@Builder(toBuilder = true)
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class DeleteAccountWarningRequest extends WorkLogPayload {
  @NonNull String warningType;
  String endedAt;
  String endedBy;

  @Override
  public <T> T accept(final WorkLogPayloadVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
