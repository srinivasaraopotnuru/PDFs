package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Withdrawals.WithdrawalsBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Withdrawals {
  @Schema(required = true)
  boolean permittedOverApi;

  @Schema(required = true)
  List<PermittedRule> permittedRules;

  WithdrawalLimit limit;

  List<Restriction> restrictions;

  InterestPenalty interestPenalty;

  @Value
  @Builder
  @JsonDeserialize(builder = InterestPenalty.InterestPenaltyBuilder.class)
  public static class InterestPenalty {
    @Schema(required = true)
    Integer days;

    @JsonPOJOBuilder(withPrefix = "")
    public static class InterestPenaltyBuilder {}
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class WithdrawalsBuilder {}
}
