package uk.co.ybs.digital.account.repository.adgcore;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.adgcore.TessaDetails;

public interface TessaDetailsRepository extends JpaRepository<TessaDetails, Long> {

  @Query(
      "FROM TessaDetails "
          + "WHERE accountNumber = :accountNumber "
          + "AND tessaYear = :tessaYear "
          + "AND endedDate IS NULL")
  Optional<TessaDetails> findActiveByAccountNumberAndTessaYear(
      @Param("accountNumber") Long accountNumber, @Param("tessaYear") Integer tessaYear);

  @Query(
      value =
          "SELECT td "
              + "FROM TessaDetails td "
              + "WHERE :accountNumber = td.accountNumber "
              + "AND :isaYear = td.tessaYear "
              + "AND dateFirstSub IS NOT NULL "
              + "AND endedDate IS NULL")
  Optional<TessaDetails> findActiveIsaSubscriptionByIsaYearAndAccountNumber(
      Long accountNumber, Integer isaYear);

  @Query(
      value =
          "SELECT count(td) > 0 "
              + "FROM TessaDetails td "
              + "JOIN ActivityPlayer ap "
              + "ON ap.tableId = 'ACCNUM' AND ap.tableSysId = td.accountNumber "
              + "AND ap.activityType.code IN ('MHLDRS', 'BENOWN') "
              + "AND ap.endDate is NULL "
              + "WHERE ap.partySysId= :partyId "
              + "AND td.accountNumber != :accountNumber "
              + "AND td.tessaYear = :isaYear "
              + "AND td.dateFirstSub IS NOT NULL "
              + "AND td.endedDate IS NULL")
  boolean existsOtherSubscriptionsInIsaYear(Long accountNumber, Integer isaYear, Long partyId);
}
