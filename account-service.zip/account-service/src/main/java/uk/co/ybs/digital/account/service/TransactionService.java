package uk.co.ybs.digital.account.service;

import com.google.common.collect.Lists;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.exception.TransactionServiceException;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransaction;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactions;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType.BalanceConstants;
import uk.co.ybs.digital.account.service.authentic.AuthenticService;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransaction;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransactions;
import uk.co.ybs.digital.account.service.mapper.AccountTransactionsMapper;
import uk.co.ybs.digital.account.service.mapper.TransactionInterestMapper;
import uk.co.ybs.digital.account.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.account.service.utilities.AccountClosedCalculator;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.TransactionDates;

@Service
@RequiredArgsConstructor
@Slf4j
public class TransactionService {
  private static final int DEFAULT_TOTAL_PAGES = 1;
  private static final int DEFAULT_PAGE_SIZE = 10;

  private final AccountAccessValidator accountAccessValidator;
  private final AuthenticService authenticService;
  private final SavingAccountTransactionsService savingAccountTransactionsService;
  private final SavingAccountDetailsService savingAccountDetailsService;
  private final AccountTransactionsMapper transactionsMapper;
  private final TransactionInterestMapper transactionInterestMapper;
  private final Clock clock;

  // If this value > page size it can stop us from having to call package multiple times.
  // (Future Enhancement)
  public static final int ADG_BUFFER_SIZE = 1;

  public AccountTransactionsResponse getTransactions(
      final String accountNumber,
      final int pageNumber,
      final TransactionDates transactionDates,
      final RequestMetadata metadata) {

    final LocalDateTime now = LocalDateTime.now(clock);

    accountAccessValidator.validateOwnAccountAccess(
        accountNumber, metadata, Collections.emptySet(), now);

    log.info("Get transactions for the account: {} pageNumber: {}", accountNumber, pageNumber);

    if (pageNumber < 1) {
      log.info("Invalid page number, return empty transactions");
      return AccountTransactionsResponse.builder()
          .transactions(Collections.emptyList())
          .meta(AccountTransactionsResponse.Meta.builder().totalPages(DEFAULT_TOTAL_PAGES).build())
          .build();
    }

    final int recordTo = pageNumber * DEFAULT_PAGE_SIZE;
    final int recordFrom = (recordTo - DEFAULT_PAGE_SIZE + 1);

    return retrieveTransactions(accountNumber, recordFrom, recordTo, transactionDates, now);
  }

  public AccountTransactionsResponse getAllTransactionsInDateRange(
      final String accountNumber,
      final int numberOfTransactions,
      final TransactionDates transactionDates,
      final RequestMetadata metadata) {

    final LocalDateTime now = LocalDateTime.now(clock);

    accountAccessValidator.validateOwnAccountAccess(
        accountNumber, metadata, Collections.emptySet(), now);

    log.info("Get {} transactions for the account: {} ", numberOfTransactions, accountNumber);

    final AccountTransactionsResponse transactionsResponse =
        retrieveTransactions(accountNumber, 1, numberOfTransactions, transactionDates, now);

    return AccountTransactionsResponse.builder()
        .transactions(
            transactionInterestMapper.mapInterestRateForTransactions(
                transactionsResponse.getTransactions()))
        .meta(transactionsResponse.getMeta())
        .build();
  }

  // Option to retry has added to handle the scenario in the creditor account in which transactions
  // appear first in ADG and second in Authentic, even though Authentic is source of truth for
  // real time transactions.
  @Retryable(
      value = TransactionServiceException.class,
      maxAttemptsExpression = "${uk.co.ybs.digital.retry.maxAttempts}",
      backoff =
          @Backoff(
              delayExpression = "${uk.co.ybs.digital.retry.delay}",
              maxDelayExpression = "${uk.co.ybs.digital.retry.maxDelay}",
              multiplierExpression = "${uk.co.ybs.digital.retry.delayMultiplier}"))
  private AccountTransactionsResponse retrieveTransactions(
      final String accountNumber,
      final int recordFrom,
      final int recordTo,
      final TransactionDates transactionDates,
      final LocalDateTime now) {
    if (recentAuthenticTransactionsAreNotRequired(transactionDates, now)
        || accountIsClosed(accountNumber, now.toLocalDate())) {
      final StatementTransactions statementTransactions =
          savingAccountTransactionsService.getTransactions(
              Long.valueOf(accountNumber), recordFrom, recordTo, transactionDates);

      // accountNumber is optional field in SOA response, instead of mapping it through mapstruct
      // in a list, set it from the request path variable
      statementTransactions
          .getTransactionList()
          .forEach(transaction -> transaction.setAccountNumber(Long.valueOf(accountNumber)));

      return transactionsMapper.getTransactionsToResponse(statementTransactions);
    }

    AuthenticTransactions authenticTransactions =
        authenticService.getTransactions(
            accountNumber, now.minusDays(1L), now, true, true, null, null);

    if (transactionDates.getStartDate() != null || transactionDates.getEndDate() != null) {
      authenticTransactions =
          removeAnyTransactionDatesOutsideTransactionDateRange(
              transactionDates, authenticTransactions);
    }

    final StatementTransactions initialBufferOfStatementTransactions =
        savingAccountTransactionsService.getTransactions(
            Long.valueOf(accountNumber), 1, ADG_BUFFER_SIZE, TransactionDates.builder().build());

    final AuthenticTransactions unlinkedTransactions =
        checkUnlinkedTransactions(
            accountNumber, authenticTransactions, initialBufferOfStatementTransactions);

    final AuthenticTransactions authenticPageTransactions =
        getPagesAuthenticTransactions(unlinkedTransactions, recordFrom, recordTo);

    final StatementTransactions statementPageTransactions =
        getPagesStatementTransactions(
            accountNumber,
            unlinkedTransactions.getTotalNumberOfRecords(),
            recordFrom,
            recordTo,
            transactionDates,
            initialBufferOfStatementTransactions);

    log.info(
        "Authentic transactions to map: {}, ADG transactions to map: {}",
        authenticPageTransactions.getTransactionList().size(),
        statementPageTransactions.getTransactionList().size());

    return transactionsMapper.getTransactionsToResponse(
        authenticPageTransactions, statementPageTransactions);
  }

  private boolean recentAuthenticTransactionsAreNotRequired(
      final TransactionDates transactionDates, final LocalDateTime now) {
    if (transactionDates.getEndDate() != null) {
      return !now.minusDays(1L).isBefore(transactionDates.getEndDate());
    }
    return false;
  }

  private boolean accountIsClosed(final String accountNumber, final LocalDate now) {
    return AccountClosedCalculator.isAccountClosed(
        savingAccountDetailsService
            .getSavingAccountDetails(Long.valueOf(accountNumber))
            .get(0)
            .getClosedDate(),
        now);
  }

  private AuthenticTransactions removeAnyTransactionDatesOutsideTransactionDateRange(
      final TransactionDates transactionDates, final AuthenticTransactions authenticTransactions) {
    final List<AuthenticTransaction> authenticTransactionList =
        authenticTransactions.getTransactionList().stream()
            .filter(
                transaction -> authenticTransactionDateWithinRange(transaction, transactionDates))
            .collect(Collectors.toList());

    return AuthenticTransactions.builder()
        .transactionList(authenticTransactionList)
        .totalNumberOfRecords(authenticTransactionList.size())
        .build();
  }

  private boolean authenticTransactionDateWithinRange(
      final AuthenticTransaction authenticTransaction, final TransactionDates transactionDates) {
    return (transactionDates.getStartDate() == null
            || authenticTransaction
                    .getTransactionBookingDateTime()
                    .compareTo(transactionDates.getStartDate())
                >= 0)
        && (transactionDates.getEndDate() == null
            || authenticTransaction
                    .getTransactionBookingDateTime()
                    .compareTo(transactionDates.getEndDate())
                <= 0);
  }

  private AuthenticTransactions getPagesAuthenticTransactions(
      final AuthenticTransactions unlinkedTransactions, final int recordFrom, final int recordTo) {

    boolean transactionsRequired = false;

    final int transactionCount = unlinkedTransactions.getTransactionList().size();

    int authRecordTo = recordTo;

    if (recordFrom <= transactionCount) {
      transactionsRequired = true;
      if (authRecordTo > transactionCount) {
        authRecordTo = transactionCount;
      }
    }

    return AuthenticTransactions.builder()
        .transactionList(
            transactionsRequired
                ? unlinkedTransactions.getTransactionList().subList(recordFrom - 1, authRecordTo)
                : Collections.emptyList())
        .totalNumberOfRecords(unlinkedTransactions.getTotalNumberOfRecords())
        .build();
  }

  private StatementTransactions getPagesStatementTransactions(
      final String accountNumber,
      final int unlinkedTransactionCount,
      final int recordFrom,
      final int recordTo,
      final TransactionDates transactionDates,
      final StatementTransactions initialBufferOfStatementTransactions) {

    int adgRecordFrom = recordFrom - unlinkedTransactionCount;
    int adgRecordTo = recordTo - unlinkedTransactionCount;

    if (adgRecordFrom < 1) {
      adgRecordFrom = 1;
    }

    if (adgRecordTo > initialBufferOfStatementTransactions.getTotalNumberOfTransactions()) {
      adgRecordTo = initialBufferOfStatementTransactions.getTotalNumberOfTransactions();
    }

    if (adgRecordFrom > initialBufferOfStatementTransactions.getTotalNumberOfTransactions()
        || adgRecordTo < 1) {
      return StatementTransactions.builder()
          .transactionList(Collections.emptyList())
          .totalNumberOfPages(initialBufferOfStatementTransactions.getTotalNumberOfPages())
          .totalNumberOfTransactions(
              initialBufferOfStatementTransactions.getTotalNumberOfTransactions())
          .build();
    }

    final StatementTransactions statementTransactions;

    if (adgRecordTo <= initialBufferOfStatementTransactions.getTransactionList().size()
        && transactionDateWithinRange(
            initialBufferOfStatementTransactions.getTransactionList(), transactionDates)) {
      // we can use the statement transaction(s) we already have
      statementTransactions =
          StatementTransactions.builder()
              .totalNumberOfPages(initialBufferOfStatementTransactions.getTotalNumberOfPages())
              .totalNumberOfTransactions(
                  initialBufferOfStatementTransactions.getTotalNumberOfTransactions())
              .transactionList(
                  initialBufferOfStatementTransactions.getTransactionList().subList(0, adgRecordTo))
              .build();
    } else {
      statementTransactions =
          savingAccountTransactionsService.getTransactions(
              Long.valueOf(accountNumber), adgRecordFrom, adgRecordTo, transactionDates);
    }

    // accountNumber is optional field in SOA response, instead of mapping it through mapstruct
    // in a list, set it from the request path variable
    statementTransactions
        .getTransactionList()
        .forEach(transaction -> transaction.setAccountNumber(Long.valueOf(accountNumber)));

    return statementTransactions;
  }

  public AuthenticTransactions checkUnlinkedTransactions(
      final String accountNumber,
      final AuthenticTransactions authenticTransactions,
      final StatementTransactions statementTransactions) {

    log.info("Checking for link between Authentic Transactions and latest from ADG");

    List<AuthenticTransaction> unlinkedTransactions = new ArrayList<>();
    if (!authenticTransactions.getTransactionList().isEmpty()
        && !statementTransactions.getTransactionList().isEmpty()) {

      // Get latest transaction from ADG
      final StatementTransaction statementTransaction =
          statementTransactions.getTransactionList().get(0);

      // Find intersection point between authentic and ADG
      // Using old for loop as we want to break when a record is found rather than
      // continue through all the records
      boolean linkFound = false;
      for (final AuthenticTransaction txn : authenticTransactions.getTransactionList()) {
        if (txn.getTransactionID() != null && statementTransaction.getTransactionId() != null) {
          if (txn.getTransactionID().equals(statementTransaction.getTransactionId().toString())) {
            log.info("Link found on TransactionId: {}", txn.getTransactionID());
            linkFound = true;
          }
        }

        // First check did not find a match, check second criteria
        if (!linkFound) {
          if (txn.getAuthUid() != null && statementTransaction.getSourceTransactionId() != null) {
            if (txn.getAuthUid().equals(statementTransaction.getSourceTransactionId())) {
              log.info("Link found on SourceTransactionId: {}", txn.getAuthUid());
              linkFound = true;
            }
          }
        }

        // If no link found, add to list of Authentic transactions to be mapped,
        // else, latest synced transaction has been found
        if (!linkFound) {
          unlinkedTransactions.add(txn);
        } else {
          break;
        }
      }
    } else {
      unlinkedTransactions = authenticTransactions.getTransactionList();
    }

    if (unlinkedTransactions.size() > 0) {
      calculateBalanceAmount(
          accountNumber,
          unlinkedTransactions,
          statementTransactions,
          authenticTransactions.getTransactionList().size());
    }

    return AuthenticTransactions.builder()
        .totalNumberOfRecords(unlinkedTransactions.size())
        .transactionList(unlinkedTransactions)
        .build();
  }

  private void calculateBalanceAmount(
      final String accountNumber,
      final List<AuthenticTransaction> transactions,
      final StatementTransactions statementTransactions,
      final int numberOfAuthenticTxns) {

    BigDecimal currentTxnBalance =
        statementTransactions.getTransactionList().stream()
            .findFirst()
            .map(StatementTransaction::getAvailableBalanceAfterTxn)
            .orElse(BigDecimal.ZERO);

    final List<AuthenticTransaction> reversed = Lists.reverse(transactions);

    for (final AuthenticTransaction transaction : reversed) {
      if ("Debit".equals(transaction.getCreditorDebitIndicator())) {
        currentTxnBalance =
            currentTxnBalance.subtract(transaction.getFinancialTransactionAmount().abs());
      } else {
        currentTxnBalance = currentTxnBalance.add(transaction.getFinancialTransactionAmount());
      }
      transaction.setBalanceType(BalanceConstants.TYPE_CAPITAL_AVAILABLE);
      transaction.setBalanceAmount(currentTxnBalance);
    }

    if (transactions.size() == numberOfAuthenticTxns) {
      // no intersection between authentic and core found,
      // so we need to validate the final balance
      validateAuthenticBalance(accountNumber, currentTxnBalance);
    }
  }

  private void validateAuthenticBalance(
      final String accountNumber, final BigDecimal calculatedBalance) {
    final List<AccountBalanceType> authenticBalance = authenticService.getBalance(accountNumber);

    final AccountBalanceType ledgerBalance =
        authenticBalance.stream()
            .filter(bal -> BalanceConstants.TYPE_CAPITAL_LEDGER.equals(bal.getBalanceType()))
            .findFirst()
            .orElseThrow(
                () ->
                    new TransactionServiceException(
                        String.format(
                            "Error getting ledger authentic balance for account: %s",
                            accountNumber)));

    // if there's a mismatch between balances, raise an exception
    if (!ledgerBalance.getBalanceAmount().equals(calculatedBalance)) {
      throw new TransactionServiceException(
          String.format(
              "Error calculating balance for account %s, calculatedBalance: %s, authenticBalance: %s",
              accountNumber, calculatedBalance, ledgerBalance.getBalanceAmount()));
    }
  }

  private boolean transactionDateWithinRange(
      final List<StatementTransaction> transactions, final TransactionDates transactionDates) {
    return transactions.stream()
        .allMatch(
            txn ->
                (transactionDates.getStartDate() == null
                        || txn.getBookingDate().compareTo(transactionDates.getStartDate()) >= 0)
                    && (transactionDates.getEndDate() == null
                        || txn.getBookingDate().compareTo(transactionDates.getEndDate()) <= 0));
  }
}
