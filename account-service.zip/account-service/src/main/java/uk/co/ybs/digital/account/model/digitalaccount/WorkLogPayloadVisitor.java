package uk.co.ybs.digital.account.model.digitalaccount;

public interface WorkLogPayloadVisitor<T> {
  T visit(SubmitIsaDeclarationRequest workLog);

  T visit(AccountWarningRequest workLog);

  T visit(DeleteAccountRequest deleteAccountRequest);

  T visit(DeleteAccountWarningRequest deleteAccountWarningRequest);

  T visit(UpdateAccountDetailsRequest updateAccountDetailsRequest);
}
