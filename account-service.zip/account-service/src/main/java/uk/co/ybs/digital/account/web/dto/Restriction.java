package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Set;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Restriction.RestrictionBuilder.class)
public class Restriction {

  @Schema(description = "Category of restriction", required = true)
  private RestrictionCategory code;

  @Schema(description = "Friendly customer message to describe the restriction")
  private String message;

  @Schema(description = "List of restriction type codes", required = true)
  private Set<String> restrictionTypes;

  /**
   * Determine if another Restriction can be merged into this Restriction.<br>
   * Restrictions are only merge-able if they are in the following categories: {@link
   * RestrictionCategory#DEPOSIT_ISA_DECLARATION}, {@link RestrictionCategory#WITHDRAWAL_DEFAULT},
   * {@link RestrictionCategory#DEPOSIT_ISA_DECLARATION} <br>
   * Then both restrictions must also have the same category and both have or not have a message.
   *
   * @param other The restriction to merge into this.
   * @return true if the restrictions can be merged, otherwise false.
   */
  @JsonIgnore
  public boolean isMergeable(final Restriction other) {
    if (RestrictionCategory.DEPOSIT_ISA_DECLARATION == this.getCode()
        || (this.message == null && RestrictionCategory.DEPOSIT_DEFAULT == this.getCode()
            || RestrictionCategory.WITHDRAWAL_DEFAULT == this.getCode())) {
      if (this.getCode() == other.getCode() && this.hasMessage() == other.hasMessage()) {
        return true;
      }
    }
    return false;
  }

  private boolean hasMessage() {
    return message != null;
  }

  /**
   * Merges another restriction into this. First calls {@link isMergeable}, then combines the
   * restrictionTypes of the other restriction into this.
   *
   * @param other The restriction to merge into this.
   * @return true if the restrictions was merged, otherwise false.
   */
  public boolean merge(final Restriction other) {
    if (this.isMergeable(other)) {
      this.getRestrictionTypes().addAll(other.getRestrictionTypes());
      return true;
    }
    return false;
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class RestrictionBuilder {}
}
