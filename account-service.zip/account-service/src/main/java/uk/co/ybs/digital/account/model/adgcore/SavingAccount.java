package uk.co.ybs.digital.account.model.adgcore;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "SAVING_ACCOUNTS")
public class SavingAccount {

  @Id
  @Column(name = "ACCOUNT_NUMBER", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private long accountNumber;

  @Column(name = "OPENED_DATE")
  private LocalDateTime openedDate;

  @Column(name = "CLOSED_DATE")
  private LocalDateTime closedDate;

  @Column(name = "CAPITAL_AVAILABLE_BALANCE")
  private BigDecimal interimAvailable;

  @Column(name = "CAPITAL_LEDGER_BALANCE")
  private BigDecimal interimBooked;

  @Column(name = "WIT_CODE")
  private String witCode;
}
