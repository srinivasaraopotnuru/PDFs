package uk.co.ybs.digital.account.model.adgcore.db;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StatementTransaction {
  private Long transactionId;
  private BigDecimal transactionAmount;
  private String transactionIndicator;
  private String status;
  private LocalDateTime bookingDate;
  private LocalDateTime valueDate;
  private String information;
  private String transactionTypeCode;
  private String transactionMethod;
  private BigDecimal ledgerBalanceAfterTxn;
  private BigDecimal availableBalanceAfterTxn;
  private String transactionRef;
  private Long sortCode;
  private Long accountNumber;
  private String accountName;
  private String bicCode;
  private String foreignAccountNumber;
  private String sourceTransactionId;
  private String chequeNumber;
}
