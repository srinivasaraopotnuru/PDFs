package uk.co.ybs.digital.account.model.adgcore;

import com.google.common.collect.ImmutableSet;
import java.time.LocalDateTime;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "RESTRICTION_TYPES")
public class RestrictionType {
  public static final String NO_SUBSCRIPTIONS = "NOSUBS";
  public static final String NO_RECEIPTS = "NOREC";
  public static final String ISA_TRANSFERRED_OUT = "ICYOUT";
  public static final String NEW_ACCOUNT_14_DAYS = "WEBDCF";

  public static final Set<String> WARNING_NO_RESTRICTION_CODES =
      ImmutableSet.of(NO_SUBSCRIPTIONS, NO_RECEIPTS);

  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  private Long sysId;

  @Column(name = "CODE", nullable = false)
  @EqualsAndHashCode.Include
  private String code;

  @Column(name = "DESCR", nullable = false)
  private String description;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;
}
