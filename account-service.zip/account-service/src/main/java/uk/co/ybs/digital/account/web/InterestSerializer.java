package uk.co.ybs.digital.account.web;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import java.io.IOException;
import java.math.BigDecimal;

public class InterestSerializer extends JsonSerializer<BigDecimal> {
  @Override
  public void serialize(
      final BigDecimal value, final JsonGenerator gen, final SerializerProvider serializers)
      throws IOException {
    // ROUND_UNNECESSARY because the money column on the DB is Number(5,3), and so should never be
    // more than 3 decimal places.
    gen.writeString(value.setScale(3, BigDecimal.ROUND_UNNECESSARY).toString());
  }
}
