package uk.co.ybs.digital.account.exception;

public class AccountWarningsResourceNotFoundException extends RuntimeException {
  private static final long serialVersionUID = 1L;
  private final String errorCode;

  public AccountWarningsResourceNotFoundException(final String message, final String errorCode) {
    super(message);
    this.errorCode = errorCode;
  }

  public String getErrorCode() {
    return this.errorCode;
  }
}
