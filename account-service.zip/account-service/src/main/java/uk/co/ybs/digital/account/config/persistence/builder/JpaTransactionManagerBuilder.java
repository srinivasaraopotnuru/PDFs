package uk.co.ybs.digital.account.config.persistence.builder;

import java.util.Objects;
import javax.persistence.EntityManagerFactory;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.With;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.transaction.TransactionManagerCustomizers;
import org.springframework.orm.jpa.JpaTransactionManager;

@With
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class JpaTransactionManagerBuilder {
  private EntityManagerFactory entityManagerFactory;
  private ObjectProvider<TransactionManagerCustomizers> transactionManagerCustomizers;

  public JpaTransactionManager build() {
    Objects.requireNonNull(entityManagerFactory, "entityManagerFactory required");
    Objects.requireNonNull(transactionManagerCustomizers, "transactionManagerCustomizers required");

    final JpaTransactionManager transactionManager =
        new JpaTransactionManager(entityManagerFactory);
    transactionManagerCustomizers.ifAvailable(
        (customizers) -> customizers.customize(transactionManager));

    return transactionManager;
  }
}
