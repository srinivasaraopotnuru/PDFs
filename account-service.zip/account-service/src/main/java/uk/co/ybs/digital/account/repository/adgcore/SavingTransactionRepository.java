package uk.co.ybs.digital.account.repository.adgcore;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.adgcore.SavingTransaction;

public interface SavingTransactionRepository extends JpaRepository<SavingTransaction, Long> {

  @Query(
      "SELECT st "
          + "FROM SavingTransaction st "
          + "WHERE st.accountNumber = :accountNumber "
          + "AND st.processDate IS NOT NULL "
          + "AND st.category = 'R' "
          + "AND st.transactionDate >= :startDate "
          + "AND st.financialTransactionTypeCode NOT IN :financialTransactionTypeCodes")
  List<SavingTransaction> findSavingTransactionsInPeriod(
      @Param("accountNumber") Long accountNumber,
      @Param("startDate") LocalDateTime startDate,
      @Param("financialTransactionTypeCodes") Collection<String> financialTransactionTypeCodes);
}
