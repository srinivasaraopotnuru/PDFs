package uk.co.ybs.digital.account.service.authentic;

import static uk.co.ybs.digital.account.service.authentic.AccountBalanceType.BalanceConstants;

import com.authentic.GetBalance;
import com.authentic.GetBalanceRequest;
import com.authentic.GetListOfTransactionsReq;
import com.authentic.GetListOfTransactionsRequest;
import com.authentic.GetListOfTransactionsResponse;
import com.authentic.TransactionDetail;
import io.micrometer.core.annotation.Timed;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransactions.AuthenticTransactionsBuilder;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2e"})
@CallLogged(logParameters = true)
public class AuthenticService {

  private static final String EMPTY_RESPONSE_MESSAGE = "Authentic service returned empty response";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling authentic service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Error calling authentic service: %s";

  private static final BigInteger FUNCTION_ID_1 = BigInteger.ONE;
  private static final String FUNCVER_1 = "001";
  private static final String ACC_TYPE_2 = "02";
  private static final String COMMSS_URI = "/CommsS";
  private static final String GET_TRANSACTIONS_URI = "/listtxns";
  private static final Duration DATE_UNTIL_BUFFER = Duration.ofHours(1L);
  private static final String AUTHENTIC_SUCCESS_RESPONSE_CODE = "0";

  private final Clock clock;
  private final WebClient authenticServiceWebClientBanking;
  private final WebClient authenticServiceWebClientWebAuth;

  public List<AccountBalanceType> getBalance(final String accountNumber) {

    final DateTimeFormatter dateTimeFormatter =
        DateTimeFormatter.ofPattern("yyyyMMddHHmmss").withZone(clock.getZone());

    final DateTimeFormatter requestIdFormatter =
        DateTimeFormatter.ofPattern("MMddHHmmss").withZone(clock.getZone());

    final Instant now = clock.instant();

    final GetBalance getBalance =
        GetBalance.builder()
            .request(
                GetBalanceRequest.builder()
                    .functionid(AuthenticService.FUNCTION_ID_1)
                    .requestid(requestIdFormatter.format(now))
                    .funcver(AuthenticService.FUNCVER_1)
                    .timestamp(dateTimeFormatter.format(now))
                    .accnbr(accountNumber)
                    .acctype(AuthenticService.ACC_TYPE_2)
                    .build())
            .build();

    final GetBalance response =
        post(COMMSS_URI, getBalance, GetBalance.class, authenticServiceWebClientBanking);

    if (!Optional.of(response).map(GetBalance::getResponse).isPresent()) {
      throw new AuthenticServiceException(EMPTY_RESPONSE_MESSAGE);
    }

    if (AccountStatus.CLOSED.getStatusCode().equals(response.getResponse().getAccstatus())) {
      throw new AccountClosedException("Authentic Account is closed");
    }

    if (AccountStatus.NOT_FOUND.getStatusCode().equals(response.getResponse().getAccstatus())) {
      throw new AccountNotFoundException("Authentic Account not found");
    }

    final AccountBalanceType interimAvailableBalance =
        AccountBalanceType.builder()
            .balanceType(BalanceConstants.TYPE_CAPITAL_AVAILABLE)
            .balanceAmount(parseAuthenticValue(response.getResponse().getClearedbal()))
            .build();

    final AccountBalanceType interimLedgerBalance =
        AccountBalanceType.builder()
            .balanceType(BalanceConstants.TYPE_CAPITAL_LEDGER)
            .balanceAmount(parseAuthenticValue(response.getResponse().getLedgerbal()))
            .build();

    return Arrays.asList(interimAvailableBalance, interimLedgerBalance);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public AuthenticTransactions getTransactions(
      final String accountNumber,
      final LocalDateTime dateAfter,
      final LocalDateTime dateNow,
      final Boolean includeCreditTransactions,
      final Boolean includeDebitTransactions,
      final Integer recordFrom,
      final Integer recordTo) {

    final Instant now = clock.instant();

    final DateTimeFormatter requestIdFormatter =
        DateTimeFormatter.ofPattern("MMddHHmmss").withZone(clock.getZone());

    final DateTimeFormatter dateTimeFormatter =
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss").withZone(clock.getZone());

    // Must specify a timeTo as the authentic call does not return any results if not specified
    final LocalDateTime dateUntil = dateNow.plus(DATE_UNTIL_BUFFER);

    final GetListOfTransactionsRequest.GetListOfTransactionsRequestBuilder listRequest =
        GetListOfTransactionsRequest.builder()
            .requestid(requestIdFormatter.format(now))
            .accnbr(accountNumber)
            .fromdatetime(dateAfter.format(dateTimeFormatter))
            .todatetime(dateUntil.format(dateTimeFormatter));

    if (recordFrom != null && recordTo != null) {
      listRequest.paginate("Y");
      listRequest.fromrecord(recordFrom.toString());
      listRequest.torecord(recordTo.toString());
    }

    final GetListOfTransactionsReq request =
        GetListOfTransactionsReq.builder().listtxnsrequest(listRequest.build()).build();

    final GetListOfTransactionsResponse transactions =
        post(
            GET_TRANSACTIONS_URI,
            request,
            GetListOfTransactionsResponse.class,
            authenticServiceWebClientWebAuth);

    if (!Optional.of(transactions)
        .map(GetListOfTransactionsResponse::getListtxnsresponse)
        .isPresent()) {
      throw new AuthenticServiceException(EMPTY_RESPONSE_MESSAGE);
    }

    if (!AUTHENTIC_SUCCESS_RESPONSE_CODE.equals(transactions.getListtxnsresponse().getRespcode())) {
      throw new AccountNotFoundException(
          String.format(
              "Account number not found on Authentic, response code %s",
              transactions.getListtxnsresponse().getRespcode()));
    }

    final List<TransactionDetail> transactionDetail =
        transactions.getListtxnsresponse().getTxndetail();
    final List<AuthenticTransaction> transactionsList = new ArrayList<>();
    final AuthenticTransactionsBuilder listOfTransactions =
        AuthenticTransactions.builder()
            .totalNumberOfRecords(
                Integer.parseInt(transactions.getListtxnsresponse().getRectotal()));

    transactionDetail.forEach(
        txn -> {
          final BigDecimal txnAmount = parseAuthenticValue(txn.getTxnamount());
          String creditOrDebit = null;

          if (txn.getTxnamount().endsWith("+")) {
            // Move to the next iteration if not including credit transactions
            if (!includeCreditTransactions) {
              return;
            }
            creditOrDebit = "Credit";
          } else if (txn.getTxnamount().endsWith("-")) {
            // Move to the next iteration if not including debit transactions
            if (!includeDebitTransactions) {
              return;
            }
            creditOrDebit = "Debit";
          }

          final LocalDateTime transactionDate =
              LocalDateTime.parse(
                  txn.getTxndatetime(), DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"));

          final AuthenticTransaction authenticTransaction =
              AuthenticTransaction.builder()
                  .transactionID(txn.getHostuid() == null ? txn.getAuthuid() : txn.getHostuid())
                  .authUid(txn.getAuthuid())
                  .financialTransactionAmount(txnAmount)
                  .transactionDesc(txn.getTxndesc())
                  .transactionBookingDateTime(transactionDate)
                  .creditorDebitIndicator(creditOrDebit)
                  .accountNumber(transactions.getListtxnsresponse().getAccnbr())
                  .build();

          transactionsList.add(authenticTransaction);
        });

    listOfTransactions.transactionList(transactionsList);

    return listOfTransactions.build();
  }

  private BigDecimal parseAuthenticValue(@NonNull final String value) {

    if (!value.endsWith("-") && !value.endsWith("+")) {
      throw new AuthenticServiceException("Authentic value format must end with a sign");
    }

    final String valueWithoutSign = value.substring(0, value.length() - 1);

    BigDecimal newValue = new BigDecimal(valueWithoutSign);

    if (value.endsWith("-")) {
      newValue = newValue.negate();
    }

    newValue = newValue.movePointLeft(2);

    return newValue;
  }

  @SuppressWarnings("SameParameterValue")
  private <T> T post(
      final String uri,
      final Object requestPayload,
      final Class<T> responseType,
      final WebClient webClient) {
    return webClient
        .post()
        .uri(uri)
        .accept(MediaType.APPLICATION_XML)
        .contentType(MediaType.APPLICATION_XML)
        .bodyValue(requestPayload)
        .exchangeToMono(
            response -> {
              if (response.statusCode() == HttpStatus.OK) {
                return response.bodyToMono(responseType);
              } else {
                throw new AuthenticServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, response.statusCode()));
              }
            })
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AuthenticServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .blockOptional()
        .orElseThrow(() -> new AuthenticServiceException(EMPTY_RESPONSE_MESSAGE));
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AuthenticServiceException);
  }
}
