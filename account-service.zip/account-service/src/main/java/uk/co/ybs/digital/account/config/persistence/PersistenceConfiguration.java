package uk.co.ybs.digital.account.config.persistence;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@Import({
  AdgCoreConfiguration.class,
  FrontOfficeConfiguration.class,
  DigitalAccountConfiguration.class,
  CoreConfiguration.class,
  CopyConfiguration.class
})
public class PersistenceConfiguration {
  public static final String DATASOURCE_PROPERTY_PREFIX = "spring.datasource.";
  public static final String JPA_PROPERTIES_PREFIX = "spring.jpa.";

  public static final String MODEL_PACKAGE_PREFIX = "uk.co.ybs.digital.account.model.";
  public static final String REPOSITORY_PACKAGE_PREFIX = "uk.co.ybs.digital.account.repository.";

  @Bean
  public PlatformTransactionManager transactionManager(
      final PlatformTransactionManager adgCoreTransactionManager,
      final PlatformTransactionManager frontOfficeTransactionManager,
      final PlatformTransactionManager digitalAccountTransactionManager) {
    return new ChainedTransactionManager(
        adgCoreTransactionManager, frontOfficeTransactionManager, digitalAccountTransactionManager);
  }

  @Bean
  @ConditionalOnProperty(
      prefix = "uk.co.ybs.digital.account.processor",
      name = "enabled",
      havingValue = "true")
  public PlatformTransactionManager accountProcessorTransactionManager(
      final PlatformTransactionManager coreTransactionManager,
      final PlatformTransactionManager copyTransactionManager,
      final PlatformTransactionManager digitalAccountTransactionManager) {
    return new ChainedTransactionManager(
        coreTransactionManager, copyTransactionManager, digitalAccountTransactionManager);
  }
}
