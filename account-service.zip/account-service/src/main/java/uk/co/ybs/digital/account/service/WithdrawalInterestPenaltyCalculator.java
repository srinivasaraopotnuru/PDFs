package uk.co.ybs.digital.account.service;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.repository.adgcore.WithdrawalInterestPenaltyRepository;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType.BalanceConstants;
import uk.co.ybs.digital.account.service.authentic.AuthenticService;
import uk.co.ybs.digital.account.service.product.ProductService;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.WithdrawalInterestPenalty;

@Service
@AllArgsConstructor
@Slf4j
public class WithdrawalInterestPenaltyCalculator {

  private static final String FASTER_PAYMENT_TRANSACTION_METHOD = "FPT";

  private final AccountAccessValidator accountAccessValidator;
  private final AuthenticService authenticService;
  private final ProductService productService;
  private final WithdrawalInterestPenaltyRepository withdrawalInterestPenaltyRepository;
  private final Clock clock;
  private final SavingAccountDetailsService savingAccountDetailsService;

  @Transactional(readOnly = true, transactionManager = "transactionManager")
  public WithdrawalInterestPenalty calculate(
      final String accountNumber,
      final BigDecimal withdrawalAmount,
      final RequestMetadata requestMetadata) {
    final LocalDateTime now = LocalDateTime.now(clock);
    accountAccessValidator.validateOwnAccountAccess(
        accountNumber, requestMetadata, Collections.emptySet(), now);

    final ProductInfo productInfo = getProductInfo(accountNumber, requestMetadata);
    if (productInfo.getWithdrawals().getInterestPenalty() == null) {
      throw new AccountResourceNotFoundException(
          String.format(
              "No interest penalty for account %s - productIdentifier: %s",
              accountNumber, productInfo.getProductIdentifier()));
    }

    final BigDecimal clearedBalance = getClearedBalance(accountNumber, productInfo);

    final BigDecimal currentInterestRate = getCurrentInterestRate(productInfo, clearedBalance);

    log.info(
        "About to calculate withdrawal interest penalty for withdrawal of {} from account {}",
        withdrawalAmount,
        accountNumber);

    final BigDecimal penalty =
        withdrawalInterestPenaltyRepository.calculateWithdrawalInterestPenalty(
            Long.parseLong(accountNumber),
            now,
            "0073",
            FASTER_PAYMENT_TRANSACTION_METHOD,
            productInfo.getInterest().getPeriodEndIndicator(),
            withdrawalAmount,
            clearedBalance,
            now,
            productInfo.getWithdrawals().getInterestPenalty().getCode(),
            currentInterestRate,
            now,
            productInfo.getInterest().getPeriodEndDate(),
            productInfo.getInterest().getDivisorDays(),
            productInfo.getStartDate(),
            productInfo.getInterest().getPreviousPeriodDivisorDays(),
            productInfo.getWithdrawals().getInterestPenalty().getDays(),
            productInfo.getWithdrawals().getInterestPenalty().getBalanceUpperBound());

    log.info(
        "Calculated withdrawal interest penalty for withdrawal of {} from account {}: {}",
        withdrawalAmount,
        accountNumber,
        penalty);

    return new WithdrawalInterestPenalty(penalty.abs());
  }

  private ProductInfo getProductInfo(
      final String accountNumber, final RequestMetadata requestMetadata) {
    final SavingAccountDetails accountDetails =
        savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(accountNumber)).get(0);
    final String productIdentifier = accountDetails.getProductIdentifier();
    return productService.getProductInfo(productIdentifier, requestMetadata);
  }

  private BigDecimal getClearedBalance(final String accountNumber, final ProductInfo productInfo) {
    final List<AccountBalanceType> balances = authenticService.getBalance(accountNumber);
    final BigDecimal capitalAvailableBalance =
        balances.stream()
            .filter(
                balance -> BalanceConstants.TYPE_CAPITAL_AVAILABLE.equals(balance.getBalanceType()))
            .findFirst()
            .map(AccountBalanceType::getBalanceAmount)
            .orElseThrow(
                () ->
                    new IllegalArgumentException(
                        String.format(
                            "Failed to find CapitalAvailable for account %s: %s",
                            accountNumber, balances)));

    // Authentic balance accounts for the product minimum balance, so add it back on
    return capitalAvailableBalance.add(productInfo.getBalance().getMin());
  }

  private BigDecimal getCurrentInterestRate(
      final ProductInfo productInfo, final BigDecimal clearedBalance) {
    // All ranges start at zero - Matching ECOM negative balance logic
    final BigDecimal adjustedClearedBalance = clearedBalance.max(BigDecimal.ZERO);

    return productInfo.getInterest().getTiers().stream()
        .filter(
            tier ->
                tier.getRangeLow().compareTo(adjustedClearedBalance) <= 0
                    && tier.getRangeHigh().compareTo(adjustedClearedBalance) >= 0)
        .findFirst()
        .map(ProductInfo.Interest.Tier::getRate)
        .orElseThrow(
            () ->
                new IllegalArgumentException(
                    String.format(
                        "Failed to find interest tier for cleared balance %s, tiers: %s",
                        clearedBalance, productInfo.getInterest().getTiers())));
  }
}
