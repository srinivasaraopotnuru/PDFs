package uk.co.ybs.digital.account.service;

import java.time.Clock;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.exception.AuthenticMessageException;
import uk.co.ybs.digital.account.repository.core.AuthenticMessageRepository;

@Slf4j
@AllArgsConstructor
@Setter
@Service
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public class AuthenticMessageService {

  public static final String HOST_3007 = "3007";
  public static final int FUNCTION_0 = 0;
  public static final String STATUS_C = "C";

  private AuthenticMessageRepository authenticMessageRepository;
  private Clock clock;
  /**
   * Send a message to Authentic.
   *
   * @param productSysId
   * @param accNum
   * @param status
   * @return Update count.
   * @throws AuthenticMessageException
   */
  @Transactional("accountProcessorTransactionManager")
  public int writeAuthenticMessage(
      final String productSysId, final Long accNum, final String status)
      throws AuthenticMessageException {

    final int resultCode =
        authenticMessageRepository.writeAuthenticMessage(
            HOST_3007, productSysId, accNum, status, FUNCTION_0, LocalDateTime.now(clock));
    log.info("Created authentic message: " + resultCode);

    return resultCode;
  }
}
