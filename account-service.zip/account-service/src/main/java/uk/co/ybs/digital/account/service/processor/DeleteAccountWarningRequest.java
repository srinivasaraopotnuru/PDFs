package uk.co.ybs.digital.account.service.processor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;

@AllArgsConstructor
@Builder
@EqualsAndHashCode
@ToString
public class DeleteAccountWarningRequest implements AccountRequest {

  @NonNull private final DeleteAccountWarningRequestArguments arguments;
  @NonNull private final DeleteAccountWarningProcessor processor;

  @Override
  public ResolvedAccountRequest resolve() {

    final AccountNumber accountNumber = processor.resolve(arguments);

    return new ResolvedDeleteAccountWarningRequest(arguments, processor, accountNumber);
  }
}
