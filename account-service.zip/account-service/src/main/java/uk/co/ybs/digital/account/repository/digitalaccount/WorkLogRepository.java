package uk.co.ybs.digital.account.repository.digitalaccount;

import java.util.List;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;

public interface WorkLogRepository extends JpaRepository<WorkLog, Long> {

  @Query(
      "SELECT wl " + "FROM WorkLog wl " + "WHERE wl.status = :status " + "ORDER BY wl.createdDate")
  List<WorkLog> findRequestsInState(@Param("status") WorkLog.Status status);

  @Query(
      "SELECT new org.apache.commons.lang3.tuple.ImmutablePair(wl.status, COUNT(wl.sysId)) "
          + "FROM WorkLog wl "
          + "GROUP BY wl.status")
  List<ImmutablePair<WorkLog.Status, Long>> findCountOfRequestsInState();

  @Query(
      "SELECT wl "
          + "FROM WorkLog wl "
          + "WHERE wl.status = :status "
          + "AND wl.operation = :operation "
          + "AND wl.accountNumber = :accountNumber "
          + "ORDER BY wl.createdDate")
  List<WorkLog> findRequestsByAccountNumberAndStateAndOperation(
      @Param("status") WorkLog.Status status,
      @Param("operation") WorkLog.Operation operation,
      @Param("accountNumber") Long accountNumber);
}
