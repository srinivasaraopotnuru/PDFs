package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.net.InetSocketAddress;
import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = RequestMetadata.RequestMetadataBuilder.class)
public class RequestMetadata {
  @NonNull private UUID requestId;
  @NonNull private InetSocketAddress host;
  @NonNull private String partyId;
  @NonNull private String brandCode;
  @ToString.Exclude @NonNull private String forwardingAuth;
  @NonNull private String ipAddress;

  @JsonPOJOBuilder(withPrefix = "")
  public static class RequestMetadataBuilder {}
}
