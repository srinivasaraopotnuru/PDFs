package uk.co.ybs.digital.account.web.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum PermittedRulesCode {
  PRODUCT_ALLOWED("product.allowed"),
  ACCOUNT_CLOSED("account.closed"),
  ACCOUNT_MIGRATION("account.migration"),
  ACCOUNT_WARNING("account.warning");

  private final String code;
}
