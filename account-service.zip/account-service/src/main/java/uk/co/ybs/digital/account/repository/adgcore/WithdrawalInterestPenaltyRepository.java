package uk.co.ybs.digital.account.repository.adgcore;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.account.config.persistence.AdgCoreConfiguration;
import uk.co.ybs.digital.logging.calls.CallLogged;

/*
 * The in memory H2 database used for tests does not support stored procedures with IN OUT parameters, so it is not
 * possible to easily test this repository. This will just be covered by E2E tests.
 */
@Repository
@CallLogged(logParameters = true)
public class WithdrawalInterestPenaltyRepository {

  private transient EntityManager entityManager;

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public BigDecimal calculateWithdrawalInterestPenalty(
      final Long accountNumber,
      final LocalDateTime transactionDate,
      final String transactionCode,
      final String transactionMethod,
      final String transactionPenaltyIndicator,
      final BigDecimal amount,
      final BigDecimal balance,
      final LocalDateTime calculationDate,
      final Integer penaltyCode,
      final BigDecimal interestRate,
      final LocalDateTime interestDate,
      final LocalDateTime periodEndDate,
      final Integer divisor,
      final LocalDateTime previousPeriodEndDate,
      final Integer previousDivisor,
      final Integer penaltyDays,
      final BigDecimal penaltyAmount) {
    final StoredProcedureQuery query =
        entityManager
            .createStoredProcedureQuery("SAV_PACK1.PR_SAVACC_INT_ADJ")
            .registerStoredProcedureParameter("PN_ACCOUNT_NUMBER", Long.class, ParameterMode.IN)
            .registerStoredProcedureParameter(
                "PD_TRANSACTION_DATE", LocalDateTime.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_TRANS_CODE", String.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PS_TRANS_METHOD", String.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_TRAN_PEN_ID", String.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_AMOUNT", BigDecimal.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_BALANCE", BigDecimal.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PD_CALC_DATE", LocalDateTime.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_PENALTY_CODE", Integer.class, ParameterMode.IN)
            .registerStoredProcedureParameter(
                "PN_INTEREST_RATE", BigDecimal.class, ParameterMode.IN)
            .registerStoredProcedureParameter(
                "PD_INTEREST_DATE", LocalDateTime.class, ParameterMode.IN)
            .registerStoredProcedureParameter(
                "PD_PERIOD_END", LocalDateTime.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_DIVISOR", Integer.class, ParameterMode.IN)
            .registerStoredProcedureParameter(
                "PD_PREV_PERIOD_END", LocalDateTime.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_PREV_DIVISOR", Integer.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_PEN_DAYS", Integer.class, ParameterMode.IN)
            .registerStoredProcedureParameter("PN_PEN_AMOUNT", BigDecimal.class, ParameterMode.IN)
            .registerStoredProcedureParameter(
                "PN_OUT_GROSS_INTEREST", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PD_OUT_CALC_DATE", String.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_CALC_DAYS", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_AMT", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_OLD_RATE", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_NEW_RATE", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter(
                "PN_OUT_PEN_TOTAL", BigDecimal.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_1", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_1", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_1", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_2", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_2", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_2", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_3", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_3", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_3", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_4", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_4", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_4", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_5", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_5", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_5", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_6", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_6", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_6", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_7", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_7", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_7", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_8", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_8", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_8", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_9", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_9", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_9", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_TIER_10", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_AMT_10", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_RATE_10", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_DAYS", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter("PN_OUT_PEN_DIVISOR", Long.class, ParameterMode.INOUT)
            .registerStoredProcedureParameter(
                "PS_SUPPRESS_EXTRA_DAYS_INT", String.class, ParameterMode.INOUT)
            .setParameter("PN_ACCOUNT_NUMBER", accountNumber)
            .setParameter("PD_TRANSACTION_DATE", transactionDate)
            .setParameter("PN_TRANS_CODE", transactionCode)
            .setParameter("PS_TRANS_METHOD", transactionMethod)
            .setParameter("PN_TRAN_PEN_ID", transactionPenaltyIndicator)
            .setParameter("PN_AMOUNT", amount)
            .setParameter("PN_BALANCE", balance)
            .setParameter("PD_CALC_DATE", calculationDate)
            .setParameter("PN_PENALTY_CODE", penaltyCode)
            .setParameter("PN_INTEREST_RATE", interestRate)
            .setParameter("PD_INTEREST_DATE", interestDate)
            .setParameter("PD_PERIOD_END", periodEndDate)
            .setParameter("PN_DIVISOR", divisor)
            .setParameter("PD_PREV_PERIOD_END", previousPeriodEndDate)
            .setParameter("PN_PREV_DIVISOR", previousDivisor)
            .setParameter("PN_PEN_DAYS", penaltyDays)
            .setParameter("PN_PEN_AMOUNT", penaltyAmount);

    query.execute();

    return (BigDecimal) query.getOutputParameterValue("PN_OUT_PEN_TOTAL");
  }

  /*
   * I couldn't get @PersistenceContext to work with constructor injection.
   * The annotation processor which handles this runs after the bean is instantiated, however this fails because
   * there are multiple EntityManager candidates. Falling back to field injection resolves this, the bean can be
   * created without an EntityManager, after which the annotation process can wire up the appropriate one.
   */
  @PersistenceContext(unitName = AdgCoreConfiguration.PERSISTENCE_UNIT)
  public void setEntityManager(final EntityManager entityManager) {
    this.entityManager = entityManager;
  }
}
