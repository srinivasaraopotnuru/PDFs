package uk.co.ybs.digital.account.service.processor;

public interface ResolvedAccountRequest {
  void execute();

  default void auditSuccess() {}

  default void auditFailure(final String message) {}
}
