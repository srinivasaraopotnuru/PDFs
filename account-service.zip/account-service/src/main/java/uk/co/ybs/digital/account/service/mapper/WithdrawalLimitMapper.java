package uk.co.ybs.digital.account.service.mapper;

import java.time.Clock;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.web.dto.WithdrawalLimit;

@Component
@RequiredArgsConstructor
public class WithdrawalLimitMapper {

  private final Clock clock;

  public WithdrawalLimit mapWithdrawalLimit(
      final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit) {

    return savingAccountAnnualWithdrawalLimit
        .getNonZeroWithdrawalsAllowed()
        .map(
            permitted ->
                WithdrawalLimit.builder()
                    .permitted(permitted)
                    .available(
                        availableWithdrawalDays(
                            savingAccountAnnualWithdrawalLimit.getYearStart(),
                            savingAccountAnnualWithdrawalLimit
                                .getAvailableWithdrawals()
                                .orElse(permitted)))
                    .periodEnd(toEndOfPeriod(savingAccountAnnualWithdrawalLimit.getYearStart()))
                    .build())
        .orElse(null);
  }

  private int availableWithdrawalDays(final LocalDate startOfPeriod, final int available) {
    final LocalDate endOfPeriod = toEndOfPeriod(startOfPeriod);
    final LocalDate now = LocalDate.now(clock);
    final int period = (int) ChronoUnit.DAYS.between(now, endOfPeriod);
    return Math.min(available, Math.abs(period));
  }

  private LocalDate toEndOfPeriod(final LocalDate startOfPeriod) {
    // This appears to be how ecom defines the period boundary.
    return startOfPeriod.plusYears(1);
  }
}
