package uk.co.ybs.digital.account.exception;

public class AccountNameConflictException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public AccountNameConflictException(final String message) {
    super(message);
  }
}
