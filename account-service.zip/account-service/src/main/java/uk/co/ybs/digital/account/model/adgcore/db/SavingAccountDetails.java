package uk.co.ybs.digital.account.model.adgcore.db;

import java.time.LocalDate;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SavingAccountDetails {

  private Long accountNumber;
  private String currencyCode;
  private String accountName;
  private Integer sortCode;
  private String productIdentifier;
  private String productType;
  private String productName;
  private Boolean isPaymentAccount;
  private LocalDate closedDate;
  private String brandCode;
  private String interestInstruction;
  private LocalDate nextInterestDate;
  private String interestFrequency;
  private String accountInterestFrequency;
  private String annualEquivalentRate;
  private String interestRate;
  private String accountHolderName;
  private String accountHolderContext;
}
