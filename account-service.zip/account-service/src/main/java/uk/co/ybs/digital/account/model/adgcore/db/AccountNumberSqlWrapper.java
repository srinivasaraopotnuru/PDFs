package uk.co.ybs.digital.account.model.adgcore.db;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class AccountNumberSqlWrapper extends AccountNumber implements SQLData {

  public AccountNumberSqlWrapper(final Long accountNumber) {
    super(accountNumber);
  }

  public String getSQLTypeName() {
    return "SOA_OBJ_ACC";
  }

  public void readSQL(final SQLInput sqlInput, final String string) throws SQLException {
    setAccountNumber(sqlInput.readLong());
  }

  public void writeSQL(final SQLOutput sqlOutput) throws SQLException {
    sqlOutput.writeLong(getAccountNumber());
  }
}
