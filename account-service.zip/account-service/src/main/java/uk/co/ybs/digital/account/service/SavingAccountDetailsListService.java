package uk.co.ybs.digital.account.service;

import java.util.List;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.model.adgcore.db.AccountNumber;
import uk.co.ybs.digital.account.repository.adgcore.SoaSavingsAccountListRepository;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Service
@Slf4j
@AllArgsConstructor
public class SavingAccountDetailsListService {
  @Autowired private final SoaSavingsAccountListRepository soaCustomerSavingsAccountsRepository;

  public List<Long> getSavingsAccountList(
      final RequestMetadata metadata, final boolean showClosedAccounts) {
    log.info("Get account details account: {}", metadata.getPartyId());
    return soaCustomerSavingsAccountsRepository
        .getSavingsAccountList(metadata.getPartyId(), metadata.getBrandCode(), showClosedAccounts)
        .stream()
        .map(AccountNumber::getAccountNumber)
        .collect(Collectors.toList());
  }
}
