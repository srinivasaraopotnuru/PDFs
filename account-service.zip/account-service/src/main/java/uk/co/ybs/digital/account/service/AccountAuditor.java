package uk.co.ybs.digital.account.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.service.audit.AuditService;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsUpdateFailureRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsUpdateSuccessRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountListRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountTransactionsRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditIsaDeclarationSubmissionFailureRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditIsaDeclarationSubmissionSuccessRequest;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Service
@AllArgsConstructor
public class AccountAuditor {

  private final AuditService auditService;

  public void auditAccountList(final RequestMetadata requestMetadata) {
    final AuditAccountListRequest auditRequest =
        AuditAccountListRequest.builder().ipAddress(requestMetadata.getIpAddress()).build();

    auditService.auditAccountList(auditRequest, requestMetadata);
  }

  public void auditAccountDetails(
      final String accountNumber, final RequestMetadata requestMetadata) {
    final AuditAccountDetailsRequest auditRequest =
        AuditAccountDetailsRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .accountInformation(
                AuditAccountDetailsRequest.AccountInformation.builder()
                    .accountNumber(accountNumber)
                    .build())
            .build();

    auditService.auditAccountDetails(auditRequest, requestMetadata);
  }

  public void auditAccountTransactions(
      final String accountNumber,
      final RequestMetadata requestMetadata,
      final AccountTransactionsResponse accountTransactionsResponse) {
    final List<Instant> bookingDateTimes =
        accountTransactionsResponse.getTransactions().stream()
            .map(AccountTransactionsResponse.Transaction::getBookingDateTime)
            .collect(Collectors.toList());

    final Optional<String> minimumBookingDateTime =
        bookingDateTimes.stream().min(Instant::compareTo).map(Instant::toString);

    final Optional<String> maximumBookingDateTime =
        bookingDateTimes.stream().max(Instant::compareTo).map(Instant::toString);

    final AuditAccountTransactionsRequest auditRequest =
        AuditAccountTransactionsRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .accountInformation(
                AuditAccountTransactionsRequest.AccountInformation.builder()
                    .accountNumber(accountNumber)
                    .startDate(minimumBookingDateTime.orElse(null))
                    .endDate(maximumBookingDateTime.orElse(null))
                    .build())
            .build();

    auditService.auditAccountTransactions(auditRequest, requestMetadata);
  }

  public void auditIsaSubmissionDeclarationSuccess(
      final String accountNumber, final RequestMetadata requestMetadata) {
    final AuditIsaDeclarationSubmissionSuccessRequest auditRequest =
        AuditIsaDeclarationSubmissionSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .accountInformation(
                AuditIsaDeclarationSubmissionSuccessRequest.AccountInformation.builder()
                    .accountNumber(accountNumber)
                    .build())
            .build();

    auditService.auditIsaDeclarationSubmissionSuccess(auditRequest, requestMetadata);
  }

  public void auditIsaSubmissionDeclarationFailure(
      final String accountNumber, final RequestMetadata requestMetadata, final String reason) {
    final AuditIsaDeclarationSubmissionFailureRequest auditRequest =
        AuditIsaDeclarationSubmissionFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .message(reason)
            .accountInformation(
                AuditIsaDeclarationSubmissionFailureRequest.AccountInformation.builder()
                    .accountNumber(accountNumber)
                    .build())
            .build();

    auditService.auditIsaDeclarationSubmissionFailure(auditRequest, requestMetadata);
  }

  public void auditAccountDetailsUpdateSuccess(
      final String accountName, final String accountNumber, final RequestMetadata requestMetadata) {
    final AuditAccountDetailsUpdateSuccessRequest auditRequest =
        AuditAccountDetailsUpdateSuccessRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .accountName(accountName)
            .accountInformation(
                AuditAccountDetailsUpdateSuccessRequest.AccountInformation.builder()
                    .accountNumber(accountNumber)
                    .build())
            .build();
    auditService.auditAccountDetailsUpdateSuccess(auditRequest, requestMetadata);
  }

  public void auditAccountDetailsUpdateFailure(
      final String accountName,
      final String accountNumber,
      final String reason,
      final RequestMetadata requestMetadata) {
    final AuditAccountDetailsUpdateFailureRequest auditRequest =
        AuditAccountDetailsUpdateFailureRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .accountName(accountName)
            .message(reason)
            .accountInformation(
                AuditAccountDetailsUpdateFailureRequest.AccountInformation.builder()
                    .accountNumber(accountNumber)
                    .build())
            .build();
    auditService.auditAccountDetailsUpdateFailure(auditRequest, requestMetadata);
  }
}
