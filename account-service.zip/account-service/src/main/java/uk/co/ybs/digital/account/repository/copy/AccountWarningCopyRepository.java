package uk.co.ybs.digital.account.repository.copy;

import java.time.LocalDateTime;
import java.util.Collection;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.copy.AccountWarning;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public interface AccountWarningCopyRepository extends JpaRepository<AccountWarning, Long> {

  @Query(
      "SELECT aw "
          + "FROM AccountWarning aw "
          + "JOIN aw.accountNumber an "
          + "JOIN aw.restrictionType rt "
          + "WHERE rt.code IN :restrictionTypeCodes "
          + "AND aw.startDate <= :now "
          + "AND (aw.endDate > :now OR aw.endDate IS NULL) "
          + "AND rt.startDate <= :now "
          + "AND (rt.endDate > :now OR rt.endDate IS NULL) "
          + "AND an.accountNumber = :accountNumber ")
  Collection<AccountWarning> findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
      @Param("accountNumber") Long accountNumber,
      @Param("restrictionTypeCodes") Collection<String> restrictionTypeCodes,
      @Param("now") LocalDateTime now);
}
