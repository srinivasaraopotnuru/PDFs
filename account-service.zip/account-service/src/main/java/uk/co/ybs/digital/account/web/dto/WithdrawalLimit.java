package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.LocalDate;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = WithdrawalLimit.WithdrawalLimitBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WithdrawalLimit {
  @Schema(required = true)
  int permitted;

  @Schema(required = true)
  int available;

  @Schema(required = true)
  LocalDate periodEnd;

  @JsonPOJOBuilder(withPrefix = "")
  public static class WithdrawalLimitBuilder {}
}
