package uk.co.ybs.digital.account.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class WarningCode {

  @Schema(required = true, example = "CA")
  @NotNull(message = "You must specify a warning code")
  String code;

  @Schema(example = "Spoken with customer in branch.")
  @Size(max = 240, message = "Warning notes must be at most 240 characters long")
  String notes;

  @Schema(example = "PROSRV", description = "The service responsible for creating the entry.")
  String serviceSchemaUser;

  @Schema(example = "0012345678")
  Long partyId;
}
