package uk.co.ybs.digital.account.service.mapper;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@AllArgsConstructor
public class DepositsPermittedOverApiMapper {
  public boolean depositsPermittedOverApi(
      final String accountNumber,
      final boolean productAllowsInternalDeposits,
      final boolean productMigrationInProgress,
      final boolean depositsBlockedByAccountWarnings,
      final boolean accountClosed) {

    final boolean depositsPermittedOverApi =
        productAllowsInternalDeposits
            && !accountClosed
            && !productMigrationInProgress
            && !depositsBlockedByAccountWarnings;

    if (!depositsPermittedOverApi) {
      log.info(
          "Deposits not permitted for account number: {}.  productAllowsInternalDeposits: {}, accountClosed: {}, productMigrationInProgress: {}, depositsBlockedByAccountWarnings: {}",
          accountNumber,
          productAllowsInternalDeposits,
          accountClosed,
          productMigrationInProgress,
          depositsBlockedByAccountWarnings);
    }

    return depositsPermittedOverApi;
  }
}
