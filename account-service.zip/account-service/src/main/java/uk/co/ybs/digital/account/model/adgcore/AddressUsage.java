package uk.co.ybs.digital.account.model.adgcore;

import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import uk.co.ybs.digital.account.model.YesNoOrNullConverter;

@Entity
@Table(name = "ADDRESS_USAGES")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class AddressUsage {

  @Id
  @Column(name = "SYSID")
  @EqualsAndHashCode.Include
  private Long sysId;

  @Column(name = "START_DATE")
  private LocalDateTime startDate;

  @Column(name = "END_DATE")
  private LocalDateTime endDate;

  @ManyToOne
  @JoinColumn(name = "PARTY_SYSID")
  @ToString.Exclude
  private Party party;

  @ManyToOne
  @JoinColumn(name = "PSTADD_SYSID")
  private PostalAddress postalAddress;

  @Column(name = "PREF_CONTACT_METH")
  @Convert(converter = YesNoOrNullConverter.class)
  private boolean preferredContactMethod;

  @Column(name = "CREATED_DATE")
  private LocalDateTime createdDate;
}
