package uk.co.ybs.digital.account.exception;

public class NoUpdatedAccountDetailsSpecifiedException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public NoUpdatedAccountDetailsSpecifiedException(final String message) {
    super(message);
  }
}
