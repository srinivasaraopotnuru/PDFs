package uk.co.ybs.digital.account.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import uk.co.ybs.digital.account.web.validators.AlphaNumeric;

@Value
@Builder
@Jacksonized
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class UpdateAccountDetails {

  @Schema(
      example = "John",
      maxLength = 20,
      description =
          "The nickname for the account, passing an empty string will remove the account nickname")
  @AlphaNumeric
  @Size(max = 20, message = "Account name must be at most 20 characters long")
  String accountName;

  // Note: Other updatable properties may be added in the future
}
