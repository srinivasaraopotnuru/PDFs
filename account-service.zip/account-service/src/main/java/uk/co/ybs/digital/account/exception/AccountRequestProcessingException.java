package uk.co.ybs.digital.account.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
public class AccountRequestProcessingException extends RuntimeException {
  private static final long serialVersionUID = 1L;
  private final Reason reason;

  public AccountRequestProcessingException(final Reason reason) {
    super(reason.getDescription());
    this.reason = reason;
  }

  @AllArgsConstructor
  @Getter
  public enum Reason {
    ISA_DECLARATION_WARNINGS_NOT_FOUND("No ISA Declaration warnings found"),
    WARNING_NOT_FOUND("Warning not found"),
    UNEXPECTED("Unexpected Technical failure"),

    ACCOUNT_NOT_FOUND("Account Not Found");

    private final String description;
  }
}
