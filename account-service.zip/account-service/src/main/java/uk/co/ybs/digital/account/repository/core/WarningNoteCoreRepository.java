package uk.co.ybs.digital.account.repository.core;

import java.time.LocalDateTime;
import java.util.Collection;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.core.WarningNote;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public interface WarningNoteCoreRepository extends JpaRepository<WarningNote, Long> {
  @Query(
      "SELECT wn "
          + "FROM WarningNote wn "
          + "WHERE wn.accountWarningSysId = :accountWarningSysId "
          + "AND wn.startDate <= :now "
          + "AND (wn.endDate > :now OR wn.endDate IS NULL) ")
  Collection<WarningNote> findWarningNoteByAccountWarningSysId(
      @Param("accountWarningSysId") Long accountWarningSysId, @Param("now") LocalDateTime now);
}
