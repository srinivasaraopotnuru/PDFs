package uk.co.ybs.digital.account.service.processor;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.account.model.core.SavingAccount;

@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class ResolvedDeleteAccountRequest implements ResolvedAccountRequest {

  @NonNull private final DeleteAccountRequestArguments arguments;
  @NonNull private final DeleteAccountProcessor processor;
  @NonNull private final SavingAccount savingAccount;

  @Override
  public void execute() {
    processor.execute(arguments, savingAccount);
  }
}
