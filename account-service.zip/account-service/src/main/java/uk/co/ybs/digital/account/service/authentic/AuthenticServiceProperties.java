package uk.co.ybs.digital.account.service.authentic;

import java.net.URL;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

@ConfigurationProperties(prefix = "uk.co.ybs.digital.authentic")
@ConstructorBinding
@AllArgsConstructor
@Getter
public class AuthenticServiceProperties {

  private Banking banking;
  private WebAuth webAuth;

  @Getter
  @AllArgsConstructor
  public static class Banking {
    @NonNull private final URL url;
  }

  @Getter
  @AllArgsConstructor
  public static class WebAuth {
    @NonNull private final URL url;
  }
}
