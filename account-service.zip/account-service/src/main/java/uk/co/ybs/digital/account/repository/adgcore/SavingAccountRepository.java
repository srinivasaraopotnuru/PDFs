package uk.co.ybs.digital.account.repository.adgcore;

import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.account.model.adgcore.SavingAccount;

public interface SavingAccountRepository extends JpaRepository<SavingAccount, Long> {}
