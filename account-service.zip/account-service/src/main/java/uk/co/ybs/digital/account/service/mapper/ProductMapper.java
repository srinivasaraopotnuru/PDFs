package uk.co.ybs.digital.account.service.mapper;

import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.web.dto.Product;

@Component
public class ProductMapper {

  public Product map(final ProductInfo product) {
    return Product.builder()
        .identifier(product.getProductIdentifier())
        .description(product.getCustomerDescription())
        .type(product.getProductType())
        .smartTiered(product.getSmartTiered())
        .build();
  }
}
