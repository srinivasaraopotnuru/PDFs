package uk.co.ybs.digital.account.service.product.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = ProductInfoPage.ProductInfoPageBuilder.class)
public class ProductInfoPage {
  private List<ProductInfo> content;

  @JsonPOJOBuilder(withPrefix = "")
  public static class ProductInfoPageBuilder {}
}
