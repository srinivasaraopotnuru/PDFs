package uk.co.ybs.digital.account.model.adgcore.db;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class StatementTransactionMapper implements StructMapper<StatementTransaction> {

  @SuppressWarnings("PMD.NPathComplexity")
  public StatementTransaction fromStruct(final Struct struct) throws SQLException {

    final StatementTransaction.StatementTransactionBuilder statementTransaction =
        StatementTransaction.builder();
    final Object[] attributes = struct.getAttributes();

    if (attributes != null && !Arrays.stream(attributes).allMatch(Objects::isNull)) {

      statementTransaction.transactionId(
          attributes[0] == null ? null : ((Number) attributes[0]).longValue());
      statementTransaction.transactionAmount(
          attributes[1] == null
              ? null
              : new BigDecimal(String.valueOf(attributes[1]))
                  .setScale(2, RoundingMode.UNNECESSARY));
      statementTransaction.transactionIndicator(
          attributes[2] == null ? null : String.valueOf(attributes[2]));
      statementTransaction.status(attributes[3] == null ? null : String.valueOf(attributes[3]));
      statementTransaction.bookingDate(
          attributes[4] == null ? null : ((Timestamp) attributes[4]).toLocalDateTime());
      statementTransaction.valueDate(
          attributes[5] == null ? null : ((Timestamp) attributes[5]).toLocalDateTime());
      statementTransaction.information(
          attributes[6] == null ? null : String.valueOf(attributes[6]));
      statementTransaction.transactionTypeCode(
          attributes[7] == null ? null : String.valueOf(attributes[7]));
      statementTransaction.transactionMethod(
          attributes[8] == null ? null : String.valueOf(attributes[8]));
      statementTransaction.ledgerBalanceAfterTxn(
          attributes[9] == null ? null : (BigDecimal) attributes[9]);
      statementTransaction.availableBalanceAfterTxn(
          attributes[10] == null ? null : (BigDecimal) attributes[10]);
      statementTransaction.transactionRef(
          attributes[11] == null ? null : String.valueOf(attributes[11]));
      statementTransaction.sortCode(
          attributes[12] == null ? null : ((Number) attributes[12]).longValue());
      statementTransaction.accountNumber(
          attributes[13] == null ? null : ((Number) attributes[13]).longValue());
      statementTransaction.accountName(
          attributes[14] == null ? null : String.valueOf(attributes[14]));
      statementTransaction.bicCode(attributes[15] == null ? null : String.valueOf(attributes[15]));
      statementTransaction.foreignAccountNumber(
          attributes[16] == null ? null : String.valueOf(attributes[16]));
      statementTransaction.sourceTransactionId(
          attributes[17] == null ? null : String.valueOf(attributes[17]));
      statementTransaction.chequeNumber(
          attributes[18] == null ? null : String.valueOf(attributes[18]));
    }
    return statementTransaction.build();
  }
}
