package uk.co.ybs.digital.account.exception;

public class AccountServiceException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public AccountServiceException(final String message) {
    super(message);
  }
}
