package uk.co.ybs.digital.account.service.processor;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class SubmitIsaDeclarationRequestArguments {
  Long accountNumber;
  @NonNull RequestMetadata requestMetadata;
  @NonNull LocalDateTime processTime;
}
