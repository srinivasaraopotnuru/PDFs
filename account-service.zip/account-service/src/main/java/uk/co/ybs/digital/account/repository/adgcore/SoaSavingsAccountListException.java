package uk.co.ybs.digital.account.repository.adgcore;

public class SoaSavingsAccountListException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public SoaSavingsAccountListException(final String message) {
    super(message);
  }

  public SoaSavingsAccountListException(final String message, final Throwable cause) {
    super(message, cause);
  }
}
