package uk.co.ybs.digital.account.web;

import static uk.co.ybs.digital.account.web.dto.AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import java.time.YearMonth;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import uk.co.ybs.digital.account.config.SwaggerConfig;
import uk.co.ybs.digital.account.service.AccountService;
import uk.co.ybs.digital.account.service.AuditingAccountService;
import uk.co.ybs.digital.account.service.AuditingTransactionService;
import uk.co.ybs.digital.account.service.TransactionDateService;
import uk.co.ybs.digital.account.web.dto.AccountDetailsFilter;
import uk.co.ybs.digital.account.web.dto.AccountDetailsResponse;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.TransactionDates;
import uk.co.ybs.digital.account.web.dto.UpdateAccountDetails;
import uk.co.ybs.digital.account.web.validators.InternalAccountNumber;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;

@RestController
@AllArgsConstructor
@Validated
@Slf4j
public class AccountController {

  private static final String BAD_REQUEST_MESSAGE = "Bad Request";
  private static final String BAD_REQUEST_RESPONSE_CODE = "400";
  private static final String UNAUTHORISED_MESSAGE = "Unauthorised";
  private static final String UNAUTHORISED_RESPONSE_CODE = "401";
  private static final String FORBIDDEN_MESSAGE = "Forbidden";
  private static final String FORBIDDEN_RESPONSE_CODE = "403";
  private static final String NOT_ACCEPTABLE_MESSAGE = "Not Acceptable";
  private static final String NOT_ACCEPTABLE_RESPONSE_CODE = "406";

  private static final String INTERNAL_SERVER_ERROR_RESPONSE_CODE = "500";
  private static final String INTERNAL_SERVER_ERROR_MESSAGE = "Internal Server Error";
  private static final String ACCOUNT_NUMBER = "accountNumber";
  private static final String ACCOUNT_NUMBER_DESCRIPTION = "10 digit account number";
  private static final String SCOPE_ACCOUNT_READ = "hasAuthority('SCOPE_ACCOUNT_READ')";

  private final AuditingAccountService auditingAccountService;
  private final AuditingTransactionService auditingTransactionService;
  private final AccountService accountService;
  private final TransactionDateService transactionDateService;

  @GetMapping(
      value = {"/accounts/{accountNumber}"},
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get details for an account number",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "200", description = "OK"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  public AccountDetailsResponse getAccountDetails(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final List<AccountDetailsFilter> filters = Collections.singletonList(AVAILABLE_DEPOSIT_LIMIT);
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    return auditingAccountService.getAccountDetails(accountNumber, filters, metadata);
  }

  @PatchMapping(
      value = {"/accounts/{accountNumber}"},
      produces = MediaType.APPLICATION_JSON_VALUE,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Update Account Details",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "202", description = "Account details updated"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  public UpdateAccountDetails patchUpdateAccountDetails(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @RequestBody @Valid final UpdateAccountDetails requestBody,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    accountService.patchUpdateAccountDetails(accountNumber, requestBody, metadata);
    return requestBody;
  }

  @GetMapping(
      value = {"/accounts/grouped"},
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get a list of accounts by group",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "200", description = "OK"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  public GroupedAccountListResponse getAccountsByGroup(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers,
      @RequestParam(defaultValue = "false", required = false) final boolean showClosedAccounts) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    return auditingAccountService.getAccountsByGroup(metadata, showClosedAccounts);
  }

  @GetMapping(
      value = {"/accounts/{accountNumber}/transactions"},
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get transaction details for an account number",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "200", description = "OK"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  @SuppressWarnings("PMD.ExcessiveParameterList")
  public AccountTransactionsResponse getTransactions(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @Parameter(name = "page", description = "Page number of statement transactions")
          @RequestParam(required = false, defaultValue = "1")
          final int page,
      @Parameter(
              name = "startMonth",
              description = "Start month to retrieve transactions from (with the format YYYY-MM)")
          @RequestParam(required = false)
          final YearMonth startMonth,
      @Parameter(
              name = "endMonth",
              description = "End month to retrieve transactions to (with the format YYYY-MM)")
          @RequestParam(required = false)
          final YearMonth endMonth,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    final TransactionDates transactionDates =
        transactionDateService.createTransactionDates(startMonth, endMonth);
    return auditingTransactionService.getTransactions(
        accountNumber, page, transactionDates, metadata);
  }

  @PostMapping(value = "/accounts/{accountNumber}/isa-declaration")
  @Operation(
      description = "Update Isa Declaration if none exists",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "202", description = "ISA Declaration created"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "409",
            description = "Conflict. ISA Declaration already exists",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "415",
            description = "Unsupported Media Type",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  public void isaDeclaration(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    accountService.createIsaDeclaration(metadata, accountNumber);
  }
}
