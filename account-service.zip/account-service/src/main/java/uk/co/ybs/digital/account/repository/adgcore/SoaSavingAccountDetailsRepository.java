package uk.co.ybs.digital.account.repository.adgcore;

import java.sql.Types;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.sql.DataSource;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.account.model.adgcore.db.AccountNumberSqlWrapper;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.model.adgcore.db.SavingsAccountDetailsMapper;
import uk.co.ybs.digital.account.model.adgcore.db.SqlArrayValue;
import uk.co.ybs.digital.account.model.adgcore.db.SqlReturnStructArray;
import uk.co.ybs.digital.logging.calls.CallLogged;

@Slf4j
@Repository
@CallLogged(logParameters = true)
public class SoaSavingAccountDetailsRepository {
  /*
   * The in memory H2 database used for tests does not support stored procedures with custom data types, so it is not
   * possible to easily test this repository. This will just be covered by E2E tests.
   */

  private final transient SimpleJdbcCall getSavingsAccountCall;

  public SoaSavingAccountDetailsRepository(final DataSource adgCoreDataSource) {

    getSavingsAccountCall =
        new SimpleJdbcCall(adgCoreDataSource)
            .withProcedureName("SOA_SAVINGSACCOUNT_DATA.PR_GET_ACC_PROD_DTLS")
            .withoutProcedureColumnMetaDataAccess()
            .declareParameters(new SqlParameter("pn_savacc_num", Types.ARRAY, "SOA_TBL_ACC"))
            .declareParameters(new SqlParameter("pn_party_sysid", Types.NUMERIC))
            .declareParameters(
                new SqlOutParameter(
                    "tab_acc_prod_dtls",
                    Types.ARRAY,
                    "SOA_TBL_ACC_PROD",
                    new SqlReturnStructArray<>(new SavingsAccountDetailsMapper())));
  }

  public List<SavingAccountDetails> getAccountDetails(
      final Long accountNumber, final Long partySysId) {

    return getAccountDetails(Collections.singletonList(accountNumber), partySysId);
  }

  public List<SavingAccountDetails> getAccountDetails(
      final Collection<Long> accountNumbers, final Long partySysId) {

    final Object[] accountNumberWrapped =
        accountNumbers.stream().map(AccountNumberSqlWrapper::new).toArray();

    final Map<String, Object> in = new HashMap<>();
    in.put("pn_savacc_num", new SqlArrayValue<>(accountNumberWrapped));
    in.put("pn_party_sysid", partySysId);

    final Object[] accounts;

    try {

      accounts = getSavingsAccountCall.executeObject(Object[].class, in);

    } catch (final UncategorizedSQLException e) {
      throw new SoaSavingsAccountException(e.getSQLException().getMessage(), e);
    } catch (final Exception e) {
      throw new SoaSavingsAccountException(
          String.format(
              "An error occurred calling SOA_SAVINGSACCOUNT_DATA.PR_GET_ACC_PROD_DTLS, Party: %s Accounts: %s",
              partySysId, StringUtils.join(accountNumbers, ',')),
          e);
    }

    return Stream.of(accounts).map(o -> (SavingAccountDetails) o).collect(Collectors.toList());
  }
}
