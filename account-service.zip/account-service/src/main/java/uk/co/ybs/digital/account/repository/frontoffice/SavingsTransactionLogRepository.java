package uk.co.ybs.digital.account.repository.frontoffice;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;

@SuppressWarnings("PMD.AvoidDuplicateLiterals")
public interface SavingsTransactionLogRepository
    extends JpaRepository<SavingsTransactionLogEntry, Long> {

  @Query(
      "SELECT distinct(l.accountNumber) "
          + "FROM SavingsTransactionLogEntry l "
          + "WHERE l.accountNumber IN :accountNumbers "
          + "AND l.status IN :statuses "
          + "AND (l.endTime >= :earliest "
          + "OR l.startTime >= :earliest)")
  Set<Long> findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
      @Param("accountNumbers") Collection<Long> accountNumbers,
      @Param("statuses") Collection<String> statuses,
      @Param("earliest") LocalDateTime earliest);

  @Query(
      "SELECT distinct(l.accountNumber) "
          + "FROM SavingsTransactionLogEntry l "
          + "WHERE l.accountNumber IN :accountNumbers "
          + "AND l.startTime >= :earliest "
          + "AND l.status = :status ")
  Set<Long> findAllAccountsWithEntriesStartingAfterEarliestTime(
      @Param("accountNumbers") Collection<Long> accountNumbers,
      @Param("earliest") LocalDateTime earliest,
      @Param("status") String status);

  @Query(
      "SELECT l "
          + "FROM SavingsTransactionLogEntry l "
          + "WHERE l.accountNumber = :accountNumber "
          + "AND l.status IN :statuses "
          + "AND l.endTime >= :earliest")
  List<SavingsTransactionLogEntry> findEntriesEndingAtOrAfterTimeByStatuses(
      @Param("accountNumber") Long accountNumber,
      @Param("statuses") Collection<String> statuses,
      @Param("earliest") LocalDateTime earliest);

  @Query(
      "SELECT l "
          + "FROM SavingsTransactionLogEntry l "
          + "WHERE l.accountNumber = :accountNumber "
          + "AND l.status IN :statuses "
          + "AND l.transferIndicator = :transferIndicator "
          + "AND l.dateProcessed IS NULL "
          + "AND l.startTime >= :earliest")
  List<SavingsTransactionLogEntry>
      findUnprocessedEntriesStartingAtOrAfterTimeByStatusesAndTransferIndicator(
          @Param("accountNumber") Long accountNumber,
          @Param("statuses") Collection<String> statuses,
          @Param("transferIndicator") String transferIndicator,
          @Param("earliest") LocalDateTime earliest);

  @Query(
      "SELECT l "
          + "FROM SavingsTransactionLogEntry l "
          + "WHERE l.accountNumber = :accountNumber "
          + "AND l.status IN :statuses ")
  List<SavingsTransactionLogEntry> findEntriesByStatus(
      @Param("accountNumber") Long accountNumber, @Param("statuses") Collection<String> statuses);

  @Query(
      "SELECT distinct(l.accountNumber) "
          + "FROM SavingsTransactionLogEntry l "
          + "WHERE l.accountNumber = :accountNumber "
          + "AND (l.status = 'CLOSE_COMMENCE' OR l.status = 'CLOSE_COMPLETE')")
  Set<Long> findAccountInClosure(@Param("accountNumber") Long accountNumber);
}
