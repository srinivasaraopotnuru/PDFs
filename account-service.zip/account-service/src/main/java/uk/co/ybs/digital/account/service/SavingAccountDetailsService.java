package uk.co.ybs.digital.account.service;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.repository.adgcore.SoaSavingAccountDetailsRepository;

@Service
@Slf4j
@AllArgsConstructor
public class SavingAccountDetailsService {
  @Autowired private final SoaSavingAccountDetailsRepository soaSavingAccountDetailsRepository;

  public List<SavingAccountDetails> getSavingAccountDetails(final Long accountNumber) {
    log.info("Get account details account: {}", accountNumber);
    return soaSavingAccountDetailsRepository.getAccountDetails(accountNumber, null);
  }

  public List<SavingAccountDetails> getSavingAccountDetails(final List<Long> accountNumbers) {
    log.info("Get account details accounts: {}", StringUtils.join(accountNumbers, ','));
    return soaSavingAccountDetailsRepository.getAccountDetails(accountNumbers, null);
  }
}
