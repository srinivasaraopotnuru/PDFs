package uk.co.ybs.digital.account.service.mapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.TessaDetailsUtilities;
import uk.co.ybs.digital.account.web.dto.Isa;

@Component
public class IsaMapper {

  @Autowired private TessaDetailsUtilities tessaDetailsUtilities;

  public Isa mapIsa(final ProductInfo productInfo, final String accountNumber) {
    if (productInfo.getIsa() == null) {
      return null;
    }

    return Isa.builder()
        .flexible(productInfo.getIsa().getFlexible())
        .helpToBuy(productInfo.getIsa().getHelpToBuy())
        .subscribed(
            tessaDetailsUtilities.getTessaDetails(accountNumber, productInfo.getIsa().getIsaYear()))
        .build();
  }
}
