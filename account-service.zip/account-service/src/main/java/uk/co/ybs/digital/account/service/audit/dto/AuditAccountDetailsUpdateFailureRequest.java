package uk.co.ybs.digital.account.service.audit.dto;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder
@Jacksonized
public class AuditAccountDetailsUpdateFailureRequest {

  @NonNull private final String ipAddress;
  @NonNull private final String accountName;
  @NonNull private final AccountInformation accountInformation;
  @NonNull private final String message;

  @Value
  @Builder
  @Jacksonized
  public static class AccountInformation {
    @NonNull private final String accountNumber;
  }
}
