package uk.co.ybs.digital.account.service.utilities;

import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMMENCE;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMPLETE;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;
import uk.co.ybs.digital.account.repository.frontoffice.SavingsTransactionLogRepository;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.web.dto.Closure;

@Component
@AllArgsConstructor
public class AccountClosureMapper {
  private static final List<String> IN_CLOSURE_PROCESS_STATUSES =
      Arrays.asList(STATUS_CLOSE_COMMENCE, STATUS_CLOSE_COMPLETE);

  private SavingsTransactionLogRepository savingsTransactionLogRepository;
  private AccountInstructionsHelper accountInstructionsHelper;

  @Transactional(readOnly = true, transactionManager = "transactionManager")
  public Closure map(
      final ProductInfo productInfo,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final LocalDate closedDate,
      final String accountNumber,
      final Set<String> activityGroups,
      final String witCode) {
    return Closure.builder()
        .permittedOverApi(
            isAccountClosable(
                productInfo,
                accountWarningRestrictionRules,
                closedDate,
                accountNumber,
                activityGroups,
                witCode))
        .build();
  }

  private boolean isAccountClosable(
      final ProductInfo productInfo,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final LocalDate closedDate,
      final String accountNumber,
      final Set<String> activityGroups,
      final String witCode) {
    return productAllowsWithdrawalsOnClosure(productInfo)
        && accountHasNoWithdrawalWarnings(accountWarningRestrictionRules)
        && accountIsNotClosedOrInClosureProcess(closedDate, accountNumber)
        && accountInstructionsHelper.instructionAllowed(
            Long.parseLong(accountNumber), witCode, activityGroups);
  }

  private boolean productAllowsWithdrawalsOnClosure(final ProductInfo productInfo) {
    return productInfo.getWithdrawals().isPermittedOverWebOnAccountClosure();
  }

  private boolean accountHasNoWithdrawalWarnings(
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules) {
    return accountWarningRestrictionRules.stream()
        .noneMatch(
            rule -> rule.isRestrictionTypeRuleCode(RestrictionTypeRule.CODE_WEB_WITHDRAWALS));
  }

  private boolean accountIsNotClosedOrInClosureProcess(
      final LocalDate closedDate, final String accountNumber) {
    return closedDate == null
        && savingsTransactionLogRepository
            .findEntriesByStatus(Long.valueOf(accountNumber), IN_CLOSURE_PROCESS_STATUSES)
            .isEmpty();
  }
}
