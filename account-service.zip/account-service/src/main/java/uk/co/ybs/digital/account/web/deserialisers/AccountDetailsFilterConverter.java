package uk.co.ybs.digital.account.web.deserialisers;

import java.util.Arrays;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.web.dto.AccountDetailsFilter;

@Component
public class AccountDetailsFilterConverter implements Converter<String, AccountDetailsFilter> {

  @Override
  public AccountDetailsFilter convert(final String value) {
    return Arrays.stream(AccountDetailsFilter.values())
        .filter(filter -> filter.getValue().equals(value))
        .findFirst()
        .orElseThrow(
            () -> new IllegalArgumentException(String.format("Failed to find filter: %s", value)));
  }
}
