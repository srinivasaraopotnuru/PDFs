package uk.co.ybs.digital.account.service.processor;

import java.time.LocalDateTime;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.core.SavingAccount;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.core.SavingAccountCoreRepository;
import uk.co.ybs.digital.account.service.AuthenticMessageService;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Component
@RequiredArgsConstructor
@Transactional("accountProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
@Slf4j
public class DeleteAccountProcessor {
  private final SavingAccountCoreRepository savingAccountCoreRepository;
  private final AccountNumberRepository accountNumberRepository;
  private final AuthenticMessageService authenticMessageService;

  public SavingAccount resolve(final DeleteAccountRequestArguments arguments) {

    final Long accountNumber = arguments.getAccountNumber();
    final RequestMetadata metadata = arguments.getRequestMetadata();

    final SavingAccount savingAccount =
        savingAccountCoreRepository
            .findById(Long.valueOf(accountNumber))
            .orElseThrow(
                () ->
                    (new AccountNotFoundException(
                        "Failed to find account "
                            + accountNumber
                            + " for request ID: "
                            + metadata.getRequestId())));
    return savingAccount;
  }

  public void execute(
      final DeleteAccountRequestArguments arguments, final SavingAccount savingAccount) {

    final LocalDateTime processTime = arguments.getProcessTime();
    final LocalDateTime now = arguments.getProcessTime();
    final RequestMetadata metadata = arguments.getRequestMetadata();
    final Long accNumber = arguments.getAccountNumber();
    final String schemaUser = SavingAccount.SCHEMA_USER;

    final AccountNumber accountNumber =
        accountNumberRepository
            .findById(accNumber)
            .orElseThrow(
                () ->
                    (new AccountNotFoundException(
                        "Failed to find account " + accNumber + " in the database")));

    savingAccount.setEndedDate(arguments.getProcessTime());
    savingAccount.setClosedDate(arguments.getProcessTime());
    savingAccount.setEndedAt(schemaUser);
    savingAccount.setEndedBy(schemaUser);

    savingAccountCoreRepository.saveAndFlush(savingAccount);

    // Create initial message for Authentic to close the account.
    authenticMessageService.writeAuthenticMessage(
        String.valueOf(accountNumber.getSavingProductSysId()),
        accNumber,
        AuthenticMessageService.STATUS_C);

    log.info("Deleted account with accountNumber {}", accNumber);
  }
}
