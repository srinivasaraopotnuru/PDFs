package uk.co.ybs.digital.account.service.processor;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.core.SavingAccount;
import uk.co.ybs.digital.account.model.core.SavingAccountHistory;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.core.SavingAccountCoreRepository;
import uk.co.ybs.digital.account.repository.core.SavingAccountHistoryRepository;
import uk.co.ybs.digital.account.service.AccountAuditor;

@Component
@RequiredArgsConstructor
@Transactional("accountProcessorTransactionManager")
@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
@Slf4j
public class UpdateAccountDetailsProcessor {

  private final AccountNumberRepository accountNumberRepository;
  private final SavingAccountCoreRepository savingAccountCoreRepository;
  private final SavingAccountHistoryRepository savingAccountHistoryRepository;
  private final AccountAuditor accountAuditor;

  public AccountNumber resolve(final UpdateAccountDetailsRequestArguments arguments) {

    final Long accountNumber = arguments.getAccountNumber();

    return accountNumberRepository
        .findById(accountNumber)
        .orElseThrow(
            () ->
                (new AccountNotFoundException(
                    "Failed to find account " + accountNumber + " in the database")));
  }

  public void execute(
      final UpdateAccountDetailsRequestArguments arguments, final AccountNumber accountNumber) {

    final String accountName = arguments.getAccountName();

    log.info("Updating Details for account number: " + accountNumber.getAccountNumber());
    final SavingAccount savingAccount =
        savingAccountCoreRepository
            .findById(accountNumber.getAccountNumber())
            .orElseThrow(
                () ->
                    (new AccountRequestProcessingException(
                        AccountRequestProcessingException.Reason.ACCOUNT_NOT_FOUND)));

    final SavingAccountHistory updateSavingAccountHistory =
        SavingAccountHistory.builder()
            .accountNumber(savingAccount.getAccountNumber())
            .witCode(savingAccount.getWitCode())
            .statementRequested(savingAccount.getStatementRequested())
            .taxdeductionCertRequest(savingAccount.getTaxDeductionCertRequest())
            .capitalAvailableBalance(savingAccount.getCapitalAvailableBalance())
            .capitalLedgerBalance(savingAccount.getCapitalLedgerBalance())
            .nextPeriodEndDate(savingAccount.getNextPeriodEndDate())
            .interestToPeriodEnd(savingAccount.getInterestToPeriodEnd())
            .openedDate(savingAccount.getOpenedDate())
            .createdAt(savingAccount.getCreatedAt())
            .createdBy(savingAccount.getCreatedBy())
            .createdDate(savingAccount.getCreatedDate())
            .endedAt(savingAccount.getEndedAt())
            .endedBy(savingAccount.getEndedBy())
            .endedDate(arguments.getProcessTime())
            .pendDivisor(savingAccount.getPendDivisor())
            .accountDesignation(savingAccount.getAccountDesignation())
            .accDesignationEmployeeNo(savingAccount.getAccDesignationEmployeeNo())
            .automatedPaymentFailures(savingAccount.getAutomatedPaymentFailures())
            .subscriptions(savingAccount.getSubscriptions())
            .term(savingAccount.getTerm())
            .maturityDate(savingAccount.getMaturityDate())
            .closedDate(savingAccount.getClosedDate())
            .penaltyInterestAccrued(savingAccount.getPenaltyInterestAccrued())
            .htCode(savingAccount.getHtCode())
            .periodEndId(savingAccount.getPeriodEndId())
            .prevPendDivisor(savingAccount.getPrevPendDivisor())
            .sprdSysId(accountNumber.getSavingProductSysId())
            .charitableExcess(savingAccount.getCharitableExcess())
            .lastMaturityDate(savingAccount.getLastMaturityDate())
            .agreedInterestRate(savingAccount.getAgreedInterestRate())
            .mediaCode(savingAccount.getMediaCode())
            .inactive(savingAccount.getInactive())
            .accountName(accountName)
            .build();

    savingAccount.setAccountName(accountName);

    savingAccountHistoryRepository.saveAndFlush(updateSavingAccountHistory);
    savingAccountCoreRepository.saveAndFlush(savingAccount);
  }

  public void auditSuccess(final UpdateAccountDetailsRequestArguments arguments) {
    accountAuditor.auditAccountDetailsUpdateSuccess(
        arguments.getAccountName(),
        arguments.getAccountNumber().toString(),
        arguments.getRequestMetadata());
  }

  public void auditFailure(
      final UpdateAccountDetailsRequestArguments arguments, final String reason) {
    accountAuditor.auditAccountDetailsUpdateFailure(
        arguments.getAccountName(),
        arguments.getAccountNumber().toString(),
        reason,
        arguments.getRequestMetadata());
  }
}
