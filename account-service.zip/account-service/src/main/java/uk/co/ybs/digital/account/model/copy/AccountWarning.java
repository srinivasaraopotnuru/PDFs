package uk.co.ybs.digital.account.model.copy;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@Entity
@Table(name = "ACCOUNT_WARNINGS")
public class AccountWarning {
  @Id
  @Column(name = "SYSID", nullable = false, updatable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ACCWAR_SYSID_SEQ")
  @SequenceGenerator(
      sequenceName = "ACCWAR_SYSID_SEQ",
      allocationSize = 1,
      name = "ACCWAR_SYSID_SEQ")
  private Long sysId;

  @ManyToOne
  @JoinColumn(name = "ACCNUM_ACCOUNT_NUMBER")
  @EqualsAndHashCode.Include
  private AccountNumber accountNumber;

  @ManyToOne
  @JoinColumn(name = "RESTYP_SYSID")
  @EqualsAndHashCode.Include
  private RestrictionType restrictionType;

  @Column(name = "CREATED_AT", nullable = false)
  private String createdAt;

  @Column(name = "START_DATE", nullable = false)
  private LocalDateTime startDate;

  @Column(name = "CREATED_BY", nullable = false)
  private String createdBy;

  @Column(name = "CREATED_DATE", nullable = false)
  private LocalDateTime createdDate;

  @Column(name = "END_DATE")
  private LocalDate endDate;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Column(name = "ENDED_AT")
  private String endedAt;

  @Column(name = "ENDED_BY")
  private String endedBy;
}
