package uk.co.ybs.digital.account.service.processor;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import uk.co.ybs.digital.account.model.core.SavingAccount;

@AllArgsConstructor
@Builder
@EqualsAndHashCode
@ToString
public class DeleteAccountRequest implements AccountRequest {

  @NonNull private final DeleteAccountRequestArguments arguments;
  @NonNull private final DeleteAccountProcessor processor;

  @Override
  public ResolvedAccountRequest resolve() {

    final SavingAccount savingAccount = processor.resolve(arguments);

    return new ResolvedDeleteAccountRequest(arguments, processor, savingAccount);
  }
}
