package uk.co.ybs.digital.account.repository.core;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.account.model.core.SavingAccount;

@ConditionalOnProperty(
    prefix = "uk.co.ybs.digital.account.processor",
    name = "enabled",
    havingValue = "true")
public interface SavingAccountCoreRepository extends JpaRepository<SavingAccount, Long> {}
