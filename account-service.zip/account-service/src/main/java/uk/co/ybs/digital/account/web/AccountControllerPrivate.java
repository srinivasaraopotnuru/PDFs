package uk.co.ybs.digital.account.web;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import java.math.BigDecimal;
import java.time.YearMonth;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import uk.co.ybs.digital.account.config.SwaggerConfig;
import uk.co.ybs.digital.account.service.AccountService;
import uk.co.ybs.digital.account.service.TransactionDateService;
import uk.co.ybs.digital.account.service.TransactionService;
import uk.co.ybs.digital.account.service.WithdrawalInterestPenaltyCalculator;
import uk.co.ybs.digital.account.web.dto.AccountDetailsFilter;
import uk.co.ybs.digital.account.web.dto.AccountDetailsResponse;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.AccountWarningsResponse;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.TransactionDates;
import uk.co.ybs.digital.account.web.dto.Warning;
import uk.co.ybs.digital.account.web.dto.WarningCode;
import uk.co.ybs.digital.account.web.dto.WithdrawalInterestPenalty;
import uk.co.ybs.digital.account.web.validators.InternalAccountNumber;
import uk.co.ybs.digital.account.web.validators.PartyId;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;

@RestController
@RequestMapping("/private")
@Validated
@AllArgsConstructor
public class AccountControllerPrivate {

  private static final String OK_RESPONSE_CODE = "200";
  private static final String OK_MESSAGE = "OK";
  private static final String BAD_REQUEST_RESPONSE_CODE = "400";
  private static final String BAD_REQUEST_MESSAGE = "Bad Request";
  private static final String UNAUTHORISED_RESPONSE_CODE = "401";
  private static final String UNAUTHORISED_MESSAGE = "Unauthorised";
  private static final String FORBIDDEN_RESPONSE_CODE = "403";
  private static final String FORBIDDEN_MESSAGE = "Forbidden";
  private static final String NOT_ACCEPTABLE_RESPONSE_CODE = "406";
  private static final String NOT_ACCEPTABLE_MESSAGE = "Not Acceptable";
  private static final String INTERNAL_SERVER_ERROR_RESPONSE_CODE = "500";
  private static final String INTERNAL_SERVER_ERROR_MESSAGE = "Internal Server Error";
  private static final String ACCOUNT_NUMBER = "accountNumber";
  private static final String ACCOUNT_NUMBER_DESCRIPTION = "10 digit account number";
  private static final String SCOPE_ACCOUNT_READ = "hasAuthority('SCOPE_ACCOUNT_READ')";
  private static final String SCOPE_ACCOUNT_WRITE = "hasAuthority('SCOPE_ACCOUNT_WRITE')";

  private final AccountService accountService;
  private final WithdrawalInterestPenaltyCalculator withdrawalInterestPenaltyCalculator;
  private final TransactionDateService transactionDateService;
  private final TransactionService transactionService;

  @GetMapping(value = "/accounts/{accountNumber}", produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get details for an account number",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = OK_RESPONSE_CODE, description = OK_MESSAGE),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  public AccountDetailsResponse getAccountDetails(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @RequestParam(required = false, defaultValue = "") final List<AccountDetailsFilter> include,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    return accountService.getAccountDetails(accountNumber, include, metadata);
  }

  @GetMapping(
      value = {"/accounts/grouped"},
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get a list of accounts by group",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = OK_RESPONSE_CODE, description = OK_MESSAGE),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  public GroupedAccountListResponse getAccountsByGroup(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers,
      @RequestParam(defaultValue = "false", required = false) final boolean showClosedAccounts) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    return accountService.getAccountGroups(metadata, showClosedAccounts);
  }

  @GetMapping(
      value = {"/accounts/{accountNumber}/transactions"},
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get transaction details for an account number",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = OK_RESPONSE_CODE, description = OK_MESSAGE),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  @SuppressWarnings("PMD.ExcessiveParameterList")
  public AccountTransactionsResponse getTransactions(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @Parameter(name = "page", description = "Page number of statement transactions")
          @RequestParam(required = false, defaultValue = "1")
          final int page,
      @Parameter(
              name = "startMonth",
              description = "Start month to retrieve transactions from (with the format YYYY-MM)")
          @RequestParam(required = false)
          final YearMonth startMonth,
      @Parameter(
              name = "endMonth",
              description = "End month to retrieve transactions to (with the format YYYY-MM)")
          @RequestParam(required = false)
          final YearMonth endMonth,
      @Parameter(name = "numberOfTransactions", description = "Number of transactions to retrieve")
          @RequestParam(required = false, defaultValue = "0")
          final int numberOfTransactions,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    final TransactionDates transactionDates =
        transactionDateService.createTransactionDates(startMonth, endMonth);
    if (numberOfTransactions > 0) {
      return transactionService.getAllTransactionsInDateRange(
          accountNumber, numberOfTransactions, transactionDates, metadata);
    }
    return transactionService.getTransactions(accountNumber, page, transactionDates, metadata);
  }

  @GetMapping(
      value = "/accounts/{accountNumber}/withdrawal-interest-penalty",
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Calculate the interest penalty for the given withdrawal",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = OK_RESPONSE_CODE, description = OK_MESSAGE),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Not Found",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  public WithdrawalInterestPenalty getWithdrawalInterestPenalty(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @RequestParam @NotNull final BigDecimal withdrawalAmount,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    return withdrawalInterestPenaltyCalculator.calculate(accountNumber, withdrawalAmount, metadata);
  }

  @GetMapping(value = "/accounts/savings/recent")
  @Operation(
      description =
          "Checks whether the customer has any open or closed savings accounts in the last 2 years",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "204", description = OK_MESSAGE),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = "Bad request",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Not Found",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void getRecentSavingsAccounts(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = "partyId", required = true, description = "A canonical party id")
          @RequestParam(name = "partyId", required = true)
          @NotNull(message = "You must specify a party id")
          @Positive(message = "${validatedValue} is not a valid party id; value must be positive")
          final Long partyId,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        // For consistency in how we handle endpoint requests metadata is being built without a
        // partyId being present in the JWT. Looking forward some system requests may be requesting
        // user data without a JWT that represents a user like this instance, if these cases become
        // prevalent we should revist how we want to represent the request metadata.
        RequestMetaDataHelper.buildRequestMetaData(
            user, Long.toString(partyId), requestId, request, headers);
    accountService.checkForRecentAccounts(partyId, metadata);
  }

  @GetMapping(
      value = "/accounts/{accountNumber}/warnings",
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get warnings for an account",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = OK_RESPONSE_CODE, description = OK_MESSAGE),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @ResponseStatus(value = HttpStatus.OK)
  @Validated
  public Collection<Warning> getAccountWarnings(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(
              name = "showHistoricWarnings",
              description = "Boolean flag to return expired warnings")
          @RequestParam(required = false)
          final Optional<Boolean> showHistoricWarnings,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {

    if (showHistoricWarnings.orElse(false)) {
      return accountService.getAllWarningsForAccount(accountNumber);
    } else {
      return accountService.getActiveWarningsForAccount(accountNumber);
    }
  }

  @PostMapping(
      value = "/accounts/{accountNumber}/warnings",
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Creates a warning for an account",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "202", description = "Accepted"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  public void createAccountWarning(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @RequestBody @Valid final WarningCode requestBody,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    accountService.createWarningForAccount(accountNumber, requestBody, metadata);
  }

  @DeleteMapping(value = "/accounts/{accountNumber}")
  @PreAuthorize(SCOPE_ACCOUNT_WRITE)
  @Operation(
      description = "Closes an account",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "202", description = "Accepted"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  public void deleteAccount(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    accountService.deleteAccount(accountNumber, metadata);
  }

  @DeleteMapping(
      value = "/accounts/{accountNumber}/warnings",
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_WRITE)
  @Operation(
      description = "Deletes a warning for an account",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = "202", description = "Accepted"),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  @ResponseStatus(value = HttpStatus.ACCEPTED)
  public void deleteAccountWarning(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @Parameter(name = ACCOUNT_NUMBER, required = true, description = ACCOUNT_NUMBER_DESCRIPTION)
          @PathVariable
          @InternalAccountNumber
          final String accountNumber,
      @RequestBody @Valid final WarningCode requestBody,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    final RequestMetadata metadata =
        RequestMetaDataHelper.buildRequestMetaData(user, requestId, request, headers);
    accountService.deleteWarningForAccount(accountNumber, requestBody, metadata);
  }

  @GetMapping(
      value = {"/accounts/warnings"},
      produces = MediaType.APPLICATION_JSON_VALUE)
  @PreAuthorize(SCOPE_ACCOUNT_READ)
  @Operation(
      description = "Get all warnings for a given party Id",
      security = {@SecurityRequirement(name = SwaggerConfig.SECURITY_SCHEME)},
      responses = {
        @ApiResponse(responseCode = OK_RESPONSE_CODE, description = OK_MESSAGE),
        @ApiResponse(
            responseCode = BAD_REQUEST_RESPONSE_CODE,
            description = BAD_REQUEST_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = UNAUTHORISED_RESPONSE_CODE,
            description = UNAUTHORISED_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = FORBIDDEN_RESPONSE_CODE,
            description = FORBIDDEN_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = NOT_ACCEPTABLE_RESPONSE_CODE,
            description = NOT_ACCEPTABLE_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Not Found",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(
            responseCode = INTERNAL_SERVER_ERROR_RESPONSE_CODE,
            description = INTERNAL_SERVER_ERROR_MESSAGE,
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
      })
  @Validated
  public AccountWarningsResponse getAccountWarningsForGivenPartyId(
      @Parameter(hidden = true) @AuthenticationPrincipal final Jwt user,
      @Parameter(hidden = true) @RequestAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME)
          final UUID requestId,
      @RequestParam(name = "includeShareplanAccounts", required = false, defaultValue = "true")
          final boolean includeShareplanAccounts,
      @RequestParam(name = "partyId") @PartyId final String partyId,
      final HttpServletRequest request,
      @Parameter(hidden = true) @RequestHeader final HttpHeaders headers) {
    return accountService.getAccountWarningsByPartyId(includeShareplanAccounts, partyId);
  }
}
