package uk.co.ybs.digital.account.model.adgcore;

import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@AllArgsConstructor
public class AccountWarningRestrictionRule {
  private final Long accountNumber;
  private final String restrictionTypeCode;
  private final String restrictionTypeRuleCode;
  private final String restrictionTypeRuleCharValue;

  public boolean isRestrictionTypeRuleCode(final String restrictionTypeRuleCode) {
    return Objects.equals(restrictionTypeRuleCode, this.restrictionTypeRuleCode);
  }
}
