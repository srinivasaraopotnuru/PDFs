package uk.co.ybs.digital.account.service;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.exception.InvalidTransactionDateException;
import uk.co.ybs.digital.account.web.dto.TransactionDates;

@Service
@RequiredArgsConstructor
public class TransactionDateService {
  private static final String START_END_INVALID_ORDER = "Start date %s is after end date %s";
  private static final String START_DATE_AFTER_NOW = "Start date %s is after now";

  private final Clock clock;

  public TransactionDates createTransactionDates(
      final YearMonth startMonth, final YearMonth endMonth) {
    final LocalDateTime now = LocalDateTime.now(clock);
    final LocalDateTime startDate = convertStartDate(startMonth);
    final LocalDateTime endDate = convertEndDate(endMonth);

    validateStartDateIsBeforeEndDate(startDate, endDate);
    validateStartDateIsNotAfterNow(startDate, now);

    return TransactionDates.builder().startDate(startDate).endDate(endDate).build();
  }

  private LocalDateTime convertStartDate(final YearMonth startMonth) {
    if (startMonth != null) {
      return startMonth.atDay(1).atTime(LocalTime.MIN);
    }
    return null;
  }

  private LocalDateTime convertEndDate(final YearMonth endMonth) {
    if (endMonth != null) {
      return endMonth.atEndOfMonth().atTime(23, 59, 59);
    }
    return null;
  }

  private void validateStartDateIsBeforeEndDate(
      final LocalDateTime startDate, final LocalDateTime endDate) {
    if (startDate != null && endDate != null && startDate.compareTo(endDate) > 0) {
      throw new InvalidTransactionDateException(
          String.format(START_END_INVALID_ORDER, startDate, endDate));
    }
  }

  private void validateStartDateIsNotAfterNow(
      final LocalDateTime startDate, final LocalDateTime now) {
    if (startDate != null && startDate.isAfter(now)) {
      throw new InvalidTransactionDateException(String.format(START_DATE_AFTER_NOW, startDate));
    }
  }
}
