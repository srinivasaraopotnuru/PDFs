package uk.co.ybs.digital.account.service.product.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import lombok.Builder;
import lombok.Value;
import uk.co.ybs.digital.account.web.InterestSerializer;

@Value
@Builder(toBuilder = true)
@JsonDeserialize(builder = ProductInfo.ProductInfoBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class ProductInfo {

  String productIdentifier;
  LocalDateTime startDate;
  String customerDescription;
  String productType;
  Balance balance;
  Deposits deposits;
  Withdrawals withdrawals;
  Interest interest;
  Isa isa;
  Boolean smartTiered;

  @JsonIgnore
  public Optional<Integer> getAnniversaryWithdrawalLimit() {
    return Optional.ofNullable(withdrawals)
        .map(Withdrawals::getLimits)
        .map(Withdrawals.Limits::getNumber)
        .map(NumberPeriodLimits::getAnniversaryYear);
  }

  public boolean hasAnniversaryWithdrawalLimit() {
    return getAnniversaryWithdrawalLimit().isPresent();
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Balance.BalanceBuilder.class)
  @Schema(name = "ProductBalance")
  public static class Balance {
    BigDecimal min;
    BigDecimal max;

    @JsonPOJOBuilder(withPrefix = "")
    public static class BalanceBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Withdrawals.WithdrawalsBuilder.class)
  public static class Withdrawals {
    InterestPenalty interestPenalty;
    boolean permittedOverWeb;
    boolean permittedOverWebOnAccountClosure;
    Limits limits;

    @Value
    @Builder
    @JsonDeserialize(builder = Limits.LimitsBuilder.class)
    public static class Limits {
      NumberPeriodLimits number;

      @JsonPOJOBuilder(withPrefix = "")
      public static class LimitsBuilder {}
    }

    @Value
    @Builder
    @JsonDeserialize(builder = InterestPenalty.InterestPenaltyBuilder.class)
    public static class InterestPenalty {
      Integer code;
      Integer days;
      BigDecimal balanceUpperBound;

      @JsonPOJOBuilder(withPrefix = "")
      public static class InterestPenaltyBuilder {}
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static class WithdrawalsBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Interest.InterestBuilder.class)
  public static class Interest {
    String periodEndIndicator;
    LocalDateTime periodEndDate;
    Integer divisorDays;
    Integer previousPeriodDivisorDays;
    List<Tier> tiers;
    Boolean webAmendmentsPermitted;

    @Value
    @Builder
    @JsonDeserialize(builder = Tier.TierBuilder.class)
    public static class Tier {
      @JsonSerialize(using = InterestSerializer.class)
      BigDecimal rate;

      BigDecimal rangeLow;
      BigDecimal rangeHigh;

      @JsonPOJOBuilder(withPrefix = "")
      public static class TierBuilder {}
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static class InterestBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Deposits.DepositsBuilder.class)
  public static class Deposits {
    boolean permittedInternal;
    boolean permittedByCard;
    Limits limits;

    @Value
    @Builder
    @JsonDeserialize(builder = Limits.LimitsBuilder.class)
    public static class Limits {
      AmountPeriodLimits amount;

      @JsonPOJOBuilder(withPrefix = "")
      public static class LimitsBuilder {}
    }

    @JsonPOJOBuilder(withPrefix = "")
    public static class DepositsBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = AmountPeriodLimits.AmountPeriodLimitsBuilder.class)
  public static class AmountPeriodLimits {
    BigDecimal month;
    BigDecimal year;
    BigDecimal anniversaryYear;
    BigDecimal taxYear;
    BigDecimal productTerm;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AmountPeriodLimitsBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = NumberPeriodLimits.NumberPeriodLimitsBuilder.class)
  public static class NumberPeriodLimits {
    Integer month;
    Integer year;
    Integer anniversaryYear;
    Integer taxYear;
    Integer productTerm;

    @JsonPOJOBuilder(withPrefix = "")
    public static class NumberPeriodLimitsBuilder {}
  }

  @Value
  @Builder
  @JsonDeserialize(builder = Isa.IsaBuilder.class)
  public static class Isa {
    Boolean flexible;
    Boolean helpToBuy;
    Integer isaYear;

    @JsonPOJOBuilder(withPrefix = "")
    public static class IsaBuilder {}
  }

  @JsonPOJOBuilder(withPrefix = "")
  public static class ProductInfoBuilder {}
}
