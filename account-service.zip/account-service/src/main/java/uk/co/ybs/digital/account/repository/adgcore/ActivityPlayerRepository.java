package uk.co.ybs.digital.account.repository.adgcore;

import java.time.LocalDateTime;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import uk.co.ybs.digital.account.model.adgcore.AccountActivityGroup;
import uk.co.ybs.digital.account.model.adgcore.ActivityPlayer;

public interface ActivityPlayerRepository extends JpaRepository<ActivityPlayer, Long> {

  @Query(
      "SELECT distinct new uk.co.ybs.digital.account.model.adgcore.AccountActivityGroup(ap.tableSysId, atg.primaryKey.activityGroupCode) "
          + "FROM ActivityPlayer ap "
          + "JOIN ap.activityType at "
          + "JOIN ActivityTypeGroup atg ON ap.activityType = atg.activityType "
          + "WHERE ap.partySysId = :partySysId "
          + "AND ap.tableId = 'ACCNUM' "
          + "AND ap.tableSysId IN :accountNumbers "
          + "AND ap.startDate <= :dateTime "
          + "AND (ap.endDate IS NULL OR ap.endDate > :dateTime) "
          + "AND at.startDate <= :dateTime "
          + "AND (at.endDate IS NULL OR at.endDate > :dateTime) "
          + "AND atg.primaryKey.startDate <= :dateTime "
          + "AND (atg.endDate IS NULL OR atg.endDate > :dateTime) "
          + "AND atg.primaryKey.activityGroupCode IN :activityGroupCodes")
  Collection<AccountActivityGroup> findAccountsWherePartyHasActivityGroup(
      @Param("partySysId") Long partySysId,
      @Param("activityGroupCodes") Collection<String> activityGroupCodes,
      @Param("accountNumbers") Collection<Long> accountNumbers,
      @Param("dateTime") LocalDateTime dateTime);

  @Query(
      "SELECT ap "
          + "FROM ActivityPlayer ap "
          + "JOIN ap.activityType at "
          + "JOIN ActivityTypeGroup atg ON ap.activityType = atg.activityType "
          + "WHERE ap.tableId = 'ACCNUM' "
          + "AND ap.tableSysId = :accountNumber "
          + "AND ap.startDate <= :dateTime "
          + "AND (ap.endDate IS NULL OR ap.endDate > :dateTime) "
          + "AND at.startDate <= :dateTime "
          + "AND (at.endDate IS NULL OR at.endDate > :dateTime) "
          + "AND atg.primaryKey.startDate <= :dateTime "
          + "AND (atg.endDate IS NULL OR atg.endDate > :dateTime) "
          + "AND atg.primaryKey.activityGroupCode IN :activityGroupCodes")
  Collection<ActivityPlayer> getAllActivityPlayers(
      @Param("activityGroupCodes") Collection<String> activityGroupCodes,
      @Param("accountNumber") Long accountNumber,
      @Param("dateTime") LocalDateTime dateTime);
}
