package uk.co.ybs.digital.account.model.digitalaccount;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AllArgsConstructor;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@AllArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
  @JsonSubTypes.Type(name = "SubmitIsaDeclaration", value = SubmitIsaDeclarationRequest.class),
  @JsonSubTypes.Type(name = "AccountWarning", value = AccountWarningRequest.class),
  @JsonSubTypes.Type(name = "DeleteAccount", value = DeleteAccountRequest.class),
  @JsonSubTypes.Type(name = "DeleteAccountWarning", value = DeleteAccountWarningRequest.class),
  @JsonSubTypes.Type(name = "UpdateAccountDetails", value = UpdateAccountDetailsRequest.class)
})
public abstract class WorkLogPayload {

  public abstract <T> T accept(WorkLogPayloadVisitor<T> visitor);
}
