package uk.co.ybs.digital.account.service.mapper;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.DepositByCardCalculator;
import uk.co.ybs.digital.account.web.dto.DepositLimit;
import uk.co.ybs.digital.account.web.dto.Deposits;
import uk.co.ybs.digital.account.web.dto.DepositsSummary;
import uk.co.ybs.digital.account.web.dto.PermittedRule;
import uk.co.ybs.digital.account.web.dto.PermittedRulesCode;
import uk.co.ybs.digital.account.web.dto.Restriction;

@Slf4j
@Component
@AllArgsConstructor
public class DepositsMapper {
  private final DepositLimitMapper depositLimitMapper;
  private final RestrictionMapper restrictionMapper;
  private final DepositsPermittedOverApiMapper depositsPermittedOverApiMapper;
  private final DepositByCardCalculator depositByCardCalculator;

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public Deposits map(
      final String accountNumber,
      final ProductInfo productInfo,
      final boolean productMigrationInProgress,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final boolean accountClosed,
      final BigDecimal remainingDepositLimit,
      final BigDecimal maxProductBalRemaining,
      final Long partyId,
      final LocalDateTime time,
      final String witCode) {
    final boolean productAllowsInternalDeposits = productInfo.getDeposits().isPermittedInternal();
    final boolean depositsBlockedByAccountWarnings =
        depositsBlockedByAccountWarnings(accountWarningRestrictionRules, productInfo);
    final List<Restriction> restrictions =
        restrictionMapper.map(
            accountWarningRestrictionRules, RestrictionTypeRule.CODE_WEB_RECEIPTS);

    final DepositLimit limit =
        depositLimitMapper.mapDepositLimit(remainingDepositLimit, maxProductBalRemaining);
    final Deposits.DepositsBuilder depositsBuilder =
        Deposits.builder()
            .permittedOverApi(
                depositsPermittedOverApiMapper.depositsPermittedOverApi(
                    accountNumber,
                    productAllowsInternalDeposits,
                    productMigrationInProgress,
                    depositsBlockedByAccountWarnings,
                    accountClosed))
            .permittedByCard(
                depositByCardCalculator.isDepositByCardPermitted(
                    Long.parseLong(accountNumber),
                    partyId,
                    time,
                    productInfo,
                    depositsBlockedByAccountWarnings,
                    witCode,
                    limit,
                    accountClosed))
            .permittedRules(
                buildPermittedRules(
                    productAllowsInternalDeposits,
                    productMigrationInProgress,
                    depositsBlockedByAccountWarnings,
                    accountClosed))
            .limit(limit);

    if (!restrictions.isEmpty()) {
      depositsBuilder.restrictions(restrictions);
    }

    return depositsBuilder.build();
  }

  public DepositsSummary mapSummary(
      final String accountNumber,
      final ProductInfo productInfo,
      final boolean productMigrationInProgress,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final boolean accountClosed) {
    final boolean productAllowsInternalDeposits = productInfo.getDeposits().isPermittedInternal();
    final boolean depositsBlockedByAccountWarnings =
        depositsBlockedByAccountWarnings(accountWarningRestrictionRules, productInfo);

    final boolean permittedOverApi =
        depositsPermittedOverApiMapper.depositsPermittedOverApi(
            accountNumber,
            productAllowsInternalDeposits,
            productMigrationInProgress,
            depositsBlockedByAccountWarnings,
            accountClosed);
    return DepositsSummary.builder()
        .permittedOverApi(permittedOverApi)
        .permittedRules(
            buildPermittedRules(
                productAllowsInternalDeposits,
                productMigrationInProgress,
                depositsBlockedByAccountWarnings,
                accountClosed))
        .build();
  }

  private boolean depositsBlockedByAccountWarnings(
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final ProductInfo productInfo) {
    final boolean flexibleIsa =
        Optional.ofNullable(productInfo.getIsa()).map(ProductInfo.Isa::getFlexible).orElse(false);

    final List<AccountWarningRestrictionRule> blockedBy =
        accountWarningRestrictionRules.stream()
            .filter(warning -> blocksDeposits(warning, flexibleIsa))
            .collect(Collectors.toList());

    final boolean blocked = !blockedBy.isEmpty();

    if (blocked) {
      log.info("Deposits blocked by account warning restrictions rules: {}", blockedBy);
    }

    return blocked;
  }

  private boolean blocksDeposits(
      final AccountWarningRestrictionRule accountWarningRestrictionRule,
      final boolean flexibleIsa) {
    final String restrictionTypeCode = accountWarningRestrictionRule.getRestrictionTypeCode();
    final boolean flexibleIsaWithoutDeclaration =
        flexibleIsa
            && (RestrictionType.NO_RECEIPTS.equals(restrictionTypeCode)
                || RestrictionType.NO_SUBSCRIPTIONS.equals(restrictionTypeCode));

    return accountWarningRestrictionRule.isRestrictionTypeRuleCode(
            RestrictionTypeRule.CODE_WEB_RECEIPTS)
        && !flexibleIsaWithoutDeclaration;
  }

  private List<PermittedRule> buildPermittedRules(
      final boolean productAllowsInternalDeposits,
      final boolean productMigrationInProgress,
      final boolean depositsBlockedByAccountWarnings,
      final boolean accountClosed) {
    final List<PermittedRule> permittedRules = new ArrayList<>();
    permittedRules.add(
        PermittedRule.builder()
            .code(PermittedRulesCode.PRODUCT_ALLOWED.getCode())
            .allowed(productAllowsInternalDeposits)
            .build());
    permittedRules.add(
        PermittedRule.builder()
            .code(PermittedRulesCode.ACCOUNT_MIGRATION.getCode())
            .allowed(productMigrationInProgress)
            .build());
    permittedRules.add(
        PermittedRule.builder()
            .code(PermittedRulesCode.ACCOUNT_WARNING.getCode())
            .allowed(depositsBlockedByAccountWarnings)
            .build());
    permittedRules.add(
        PermittedRule.builder()
            .code(PermittedRulesCode.ACCOUNT_CLOSED.getCode())
            .allowed(accountClosed)
            .build());

    return permittedRules;
  }
}
