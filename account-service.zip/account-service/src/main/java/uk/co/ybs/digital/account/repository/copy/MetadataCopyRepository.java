package uk.co.ybs.digital.account.repository.copy;

import org.springframework.data.jpa.repository.JpaRepository;
import uk.co.ybs.digital.account.model.copy.Metadata;

public interface MetadataCopyRepository extends JpaRepository<Metadata, Long> {}
