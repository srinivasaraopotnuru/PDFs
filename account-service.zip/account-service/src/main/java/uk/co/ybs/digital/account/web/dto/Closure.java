package uk.co.ybs.digital.account.web.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Jacksonized
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Closure {
  @Schema(required = true)
  boolean permittedOverApi;
}
