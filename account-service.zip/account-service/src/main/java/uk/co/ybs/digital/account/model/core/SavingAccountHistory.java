package uk.co.ybs.digital.account.model.core;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "SAVING_ACCOUNT_HISTORIES")
public class SavingAccountHistory {
  public static final String TABLE_ID_SAVACC = "SAVACC";

  @Id
  @Column(name = "SYSID", nullable = false)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SAVACH_SYSID_SEQ")
  @SequenceGenerator(
      sequenceName = "SAVACH_SYSID_SEQ",
      allocationSize = 1,
      name = "SAVACH_SYSID_SEQ")
  private Long savingAccountSysId;

  @Column(name = "SAVACC_ACCOUNT_NUMBER", nullable = false, updatable = false)
  @EqualsAndHashCode.Include
  private Long accountNumber;

  @Column(name = "WIT_CODE", nullable = false)
  private String witCode;

  @Column(name = "STATEMENT_REQUESTED", nullable = false)
  private String statementRequested;

  @Column(name = "TAX_DEDUCTION_CERT_REQUEST", nullable = false)
  private String taxdeductionCertRequest;

  @Column(name = "CAPITAL_AVAILABLE_BALANCE", nullable = false)
  private BigDecimal capitalAvailableBalance;

  @Column(name = "CAPITAL_LEDGER_BALANCE", nullable = false)
  private BigDecimal capitalLedgerBalance;

  @Column(name = "NEXT_PERIOD_END_DATE")
  private LocalDate nextPeriodEndDate;

  @Column(name = "INTEREST_TO_PERIOD_END", nullable = false)
  private BigDecimal interestToPeriodEnd;

  @Column(name = "OPENED_DATE", nullable = false)
  private LocalDate openedDate;

  @Column(name = "CREATED_AT", nullable = false)
  private String createdAt;

  @Column(name = "CREATED_BY", nullable = false)
  private String createdBy;

  @Column(name = "CREATED_DATE", nullable = false)
  private LocalDateTime createdDate;

  @Column(name = "ENDED_AT")
  private String endedAt;

  @Column(name = "ENDED_BY")
  private String endedBy;

  @Column(name = "ENDED_DATE")
  private LocalDateTime endedDate;

  @Column(name = "PEND_DIVISOR")
  private Long pendDivisor;

  @Column(name = "ACCOUNT_DESIGNATION")
  private String accountDesignation;

  @Column(name = "ACC_DESIGNATION_EMPLOYEE_NO")
  private String accDesignationEmployeeNo;

  @Column(name = "AUTOMATED_PAYMENT_FAILURES")
  private Long automatedPaymentFailures;

  @Column(name = "SUBSCRIPTIONS")
  private BigDecimal subscriptions;

  @Column(name = "TERM")
  private Long term;

  @Column(name = "MATURITY_DATE")
  private LocalDate maturityDate;

  @Column(name = "CLOSED_DATE")
  private LocalDateTime closedDate;

  @Column(name = "AGREED_INTEREST_RATE")
  private BigDecimal agreedInterestRate;

  @Column(name = "PENALTY_INTEREST_ACCRUED")
  private BigDecimal penaltyInterestAccrued;

  @Column(name = "HT_CODE")
  private String htCode;

  @Column(name = "PERIOD_END_ID")
  private String periodEndId;

  @Column(name = "PREV_PEND_DIVISOR")
  private Long prevPendDivisor;

  @Column(name = "SPRD_SYSID")
  private Long sprdSysId;

  @Column(name = "CHARITABLE_EXCESS")
  private String charitableExcess;

  @Column(name = "LAST_MATURITY_DATE")
  private LocalDate lastMaturityDate;

  @Column(name = "MEDIA_CODE")
  private String mediaCode;

  @Column(name = "INACTIVE")
  private String inactive;

  @Column(name = "ACCOUNT_NAME")
  private String accountName;
}
