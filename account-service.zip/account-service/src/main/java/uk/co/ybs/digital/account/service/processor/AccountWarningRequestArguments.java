package uk.co.ybs.digital.account.service.processor;

import java.time.LocalDateTime;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@Value
@Builder
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class AccountWarningRequestArguments {
  @NonNull Long accountNumber;
  @NonNull String warningCode;
  @NonNull String createdAt;
  @NonNull String createdBy;
  String notes;
  @NonNull RequestMetadata requestMetadata;
  @NonNull LocalDateTime processTime;
}
