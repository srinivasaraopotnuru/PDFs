package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = Deposits.DepositsBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class Deposits {
  @Schema(required = true)
  boolean permittedOverApi;

  @Schema(required = true)
  boolean permittedByCard;

  @Schema(required = true)
  List<PermittedRule> permittedRules;

  DepositLimit limit;

  List<Restriction> restrictions;

  @JsonPOJOBuilder(withPrefix = "")
  public static class DepositsBuilder {}
}
