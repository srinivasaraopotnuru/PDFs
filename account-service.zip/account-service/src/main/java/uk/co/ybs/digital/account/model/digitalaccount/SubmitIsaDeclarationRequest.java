package uk.co.ybs.digital.account.model.digitalaccount;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@EqualsAndHashCode(callSuper = false)
@Builder(toBuilder = true)
@Jacksonized
public class SubmitIsaDeclarationRequest extends WorkLogPayload {

  @Override
  public <T> T accept(final WorkLogPayloadVisitor<T> visitor) {
    return visitor.visit(this);
  }
}
