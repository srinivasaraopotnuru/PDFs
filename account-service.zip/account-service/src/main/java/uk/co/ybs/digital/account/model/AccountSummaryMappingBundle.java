package uk.co.ybs.digital.account.model;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;

@Value
@Builder
public class AccountSummaryMappingBundle {
  @NonNull private final SavingAccountDetails savingAccountDetails;
  @NonNull private final List<AccountBalanceType> balances;
  @NonNull private final ProductInfo productInfo;
  private final boolean productMigrationInProgress;
  @NonNull private final List<AccountWarningRestrictionRule> accountWarningRestrictionRules;
  @NonNull private final Set<String> activityGroupCodes;
  private final SavingAccountAnnualWithdrawalLimit anniversaryWithdrawalLimit;
  private final boolean closed;
  @NonNull private LocalDate openedDate;
}
