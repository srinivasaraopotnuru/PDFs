package uk.co.ybs.digital.account.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.TransactionDates;

@Service
@AllArgsConstructor
public class AuditingTransactionService {
  private final TransactionService transactionService;
  private final AccountAuditor accountAuditor;

  public AccountTransactionsResponse getTransactions(
      final String accountNumber,
      final int pageNumber,
      final TransactionDates transactionDates,
      final RequestMetadata requestMetadata) {
    final AccountTransactionsResponse response =
        transactionService.getTransactions(
            accountNumber, pageNumber, transactionDates, requestMetadata);
    accountAuditor.auditAccountTransactions(accountNumber, requestMetadata, response);
    return response;
  }
}
