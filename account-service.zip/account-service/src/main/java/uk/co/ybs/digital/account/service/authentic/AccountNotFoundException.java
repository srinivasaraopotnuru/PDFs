package uk.co.ybs.digital.account.service.authentic;

public class AccountNotFoundException extends AuthenticServiceException {

  private static final long serialVersionUID = 1L;

  public AccountNotFoundException(final String message) {
    super(message);
  }
}
