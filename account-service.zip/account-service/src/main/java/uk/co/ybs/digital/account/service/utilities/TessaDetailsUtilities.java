package uk.co.ybs.digital.account.service.utilities;

import java.util.Optional;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.account.model.adgcore.TessaDetails;
import uk.co.ybs.digital.account.repository.adgcore.TessaDetailsRepository;

@Component
@RequiredArgsConstructor
@Slf4j
public class TessaDetailsUtilities {

  @NonNull private final TessaDetailsRepository tessaDetailsRepository;

  public boolean getTessaDetails(final String accountNumber, final Integer isaYear) {

    final Optional<TessaDetails> subscribed =
        tessaDetailsRepository.findActiveIsaSubscriptionByIsaYearAndAccountNumber(
            Long.valueOf(accountNumber), isaYear);

    return subscribed.isPresent();
  }
}
