package uk.co.ybs.digital.account.web.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonPOJOBuilder;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
@JsonDeserialize(builder = GroupedAccountListResponse.GroupedAccountListResponseBuilder.class)
@SuppressWarnings("PMD.CommentDefaultAccessModifier")
public class GroupedAccountListResponse {
  AccountGroup owned;
  AccountGroup other;
  AccountGroup closed;

  @JsonPOJOBuilder(withPrefix = "")
  public static class GroupedAccountListResponseBuilder {}

  @Value
  @Builder
  @JsonDeserialize(builder = GroupedAccountListResponse.AccountGroup.AccountGroupBuilder.class)
  public static class AccountGroup {
    @JsonProperty(value = "account")
    @Schema(required = true)
    List<AccountSummary> accounts;

    @JsonProperty(value = "balance")
    @Schema(required = true)
    List<Balance> balances;

    @JsonPOJOBuilder(withPrefix = "")
    public static class AccountGroupBuilder {}
  }
}
