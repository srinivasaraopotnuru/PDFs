package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.account.utils.TestHelper.PARTY_ID_LONG;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.DepositByCardCalculator;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.DepositLimit;
import uk.co.ybs.digital.account.web.dto.Deposits;
import uk.co.ybs.digital.account.web.dto.DepositsSummary;
import uk.co.ybs.digital.account.web.dto.Restriction;
import uk.co.ybs.digital.account.web.dto.RestrictionCategory;

@ExtendWith(MockitoExtension.class)
class DepositsMapperTest {
  private static final String ACCOUNT_NUMBER = "12345678";
  private static final String RESTRICTION_TYPE_CODE = "RESTYP";
  private static final String RESTRICTION_RULE_CODE_WEBREC = "WEBREC";
  private static final String RESTRICTION_RULE_CODE_OTHER = "OTHER";
  private static final String RESTRICTION_RESTYP_WEBTXT = "RESTYP_WEBTXT";
  private static final String RESTRICTION_NOSUBS_WEBTXT = "NOSUBS_WEBTXT";
  private static final String RESTRICTION_NOREC_WEBTXT = "NOREC_WEBTXT";
  private static final boolean MIGRATING_PRODUCT = true;
  private static final boolean NOT_MIGRATING_PRODUCT = false;
  private static final boolean ACCOUNT_CLOSED = true;
  private static final boolean ACCOUNT_NOT_CLOSED = false;
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-09-01T00:00:00");
  private static final String WIT_CODE = "SSIGN";

  private DepositsMapper testSubject;

  @Mock private DepositLimitMapper depositLimitMapper;

  @Mock private RestrictionMapper restrictionMapper;

  @Mock private DepositsPermittedOverApiMapper depositsPermittedOverApiMapper;

  @Mock private DepositByCardCalculator depositByCardCalculator;

  @BeforeEach
  void beforeEach() {
    testSubject =
        new DepositsMapper(
            depositLimitMapper,
            restrictionMapper,
            depositsPermittedOverApiMapper,
            depositByCardCalculator);
  }

  @ParameterizedTest
  @MethodSource("mapDepositsArguments")
  @SuppressWarnings("PMD.ExcessiveParameterList")
  void shouldMapDepositsWithLimit(
      final String label,
      final boolean productMigrationInProgress,
      final boolean accountClosed,
      final boolean expectedDepositPermittedOverApi,
      final BigDecimal remainingBalance,
      final BigDecimal maxProductBalRemaining,
      final boolean permittedByCard) {
    final DepositLimit mappedDepositLimit =
        buildDepositLimit(remainingBalance, maxProductBalRemaining);
    final ProductInfo productInfo = buildProductInfo(true, true);
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules = new ArrayList<>();

    final boolean productAllowsInternalDeposits = productInfo.getDeposits().isPermittedInternal();
    when(depositLimitMapper.mapDepositLimit(remainingBalance, maxProductBalRemaining))
        .thenReturn(mappedDepositLimit);
    when(depositsPermittedOverApiMapper.depositsPermittedOverApi(
            eq(ACCOUNT_NUMBER),
            eq(productAllowsInternalDeposits),
            eq(productMigrationInProgress),
            eq(false),
            eq(accountClosed)))
        .thenReturn(expectedDepositPermittedOverApi);
    when(depositByCardCalculator.isDepositByCardPermitted(
            Long.parseLong(ACCOUNT_NUMBER),
            PARTY_ID_LONG,
            NOW,
            productInfo,
            false,
            WIT_CODE,
            mappedDepositLimit,
            accountClosed))
        .thenReturn(permittedByCard);

    final Deposits expected =
        Deposits.builder()
            .permittedOverApi(expectedDepositPermittedOverApi)
            .permittedByCard(permittedByCard)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsInternalDeposits,
                    productMigrationInProgress,
                    false,
                    accountClosed))
            .limit(mappedDepositLimit)
            .build();

    final Deposits actual =
        testSubject.map(
            ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            accountClosed,
            remainingBalance,
            maxProductBalRemaining,
            PARTY_ID_LONG,
            NOW,
            WIT_CODE);

    assertThat(actual, is(expected));
  }

  @ParameterizedTest
  @MethodSource("mapDepositsWithRestrictions")
  void shouldMapDepositsWithRestrictions(
      final String label,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final boolean isRestricted) {

    final BigDecimal remainingBalance = BigDecimal.ZERO;
    final BigDecimal maxProductBalRemaining = new BigDecimal("234.56");

    final ProductInfo productInfo = buildProductInfo(true, false);
    final boolean permittedOverApi = false;

    final boolean productAllowsInternalDeposits = productInfo.getDeposits().isPermittedInternal();

    when(depositsPermittedOverApiMapper.depositsPermittedOverApi(
            ACCOUNT_NUMBER,
            productInfo.getDeposits().isPermittedInternal(),
            NOT_MIGRATING_PRODUCT,
            isRestricted,
            ACCOUNT_NOT_CLOSED))
        .thenReturn(permittedOverApi);

    final DepositLimit mappedDepositLimit = buildDepositLimit(BigDecimal.ZERO, BigDecimal.ZERO);

    when(depositLimitMapper.mapDepositLimit(remainingBalance, maxProductBalRemaining))
        .thenReturn(mappedDepositLimit);

    final List<Restriction> restrictions =
        Collections.singletonList(buildRestriction(RestrictionCategory.DEPOSIT_DEFAULT));
    when(restrictionMapper.map(accountWarningRestrictionRules, RESTRICTION_RULE_CODE_WEBREC))
        .thenReturn(restrictions);

    final Deposits expected =
        Deposits.builder()
            .permittedOverApi(permittedOverApi)
            .permittedByCard(false)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsInternalDeposits,
                    NOT_MIGRATING_PRODUCT,
                    isRestricted,
                    ACCOUNT_NOT_CLOSED))
            .limit(mappedDepositLimit)
            .restrictions(restrictions)
            .build();

    final Deposits actual =
        testSubject.map(
            ACCOUNT_NUMBER,
            productInfo,
            NOT_MIGRATING_PRODUCT,
            accountWarningRestrictionRules,
            ACCOUNT_NOT_CLOSED,
            remainingBalance,
            maxProductBalRemaining,
            PARTY_ID_LONG,
            NOW,
            WIT_CODE);

    assertThat(actual, is(expected));
    verify(depositByCardCalculator)
        .isDepositByCardPermitted(
            Long.parseLong(ACCOUNT_NUMBER),
            PARTY_ID_LONG,
            NOW,
            productInfo,
            isRestricted,
            WIT_CODE,
            mappedDepositLimit,
            false);
  }

  @ParameterizedTest
  @MethodSource("mapDepositsArguments")
  void shouldMapAccountSummaryWithdrawals(
      final String label,
      final boolean productMigrationInProgress,
      final boolean accountClosed,
      final boolean expectedDepositPermittedOverApi) {

    final ProductInfo productInfo = buildProductInfo(true, true);
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules = new ArrayList<>();
    final boolean productAllowsInternalDeposits = productInfo.getDeposits().isPermittedInternal();

    when(depositsPermittedOverApiMapper.depositsPermittedOverApi(
            eq(ACCOUNT_NUMBER),
            eq(productInfo.getDeposits().isPermittedInternal()),
            eq(productMigrationInProgress),
            eq(false),
            eq(accountClosed)))
        .thenReturn(expectedDepositPermittedOverApi);

    final DepositsSummary expected =
        DepositsSummary.builder()
            .permittedOverApi(expectedDepositPermittedOverApi)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsInternalDeposits,
                    productMigrationInProgress,
                    false,
                    accountClosed))
            .build();

    final DepositsSummary mapped =
        testSubject.mapSummary(
            ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            accountClosed);

    assertThat(mapped, is(expected));
  }

  private static Stream<Arguments> mapDepositsArguments() {
    return Stream.of(
        Arguments.of(
            "normal - permitted",
            NOT_MIGRATING_PRODUCT,
            ACCOUNT_NOT_CLOSED,
            true,
            null,
            null,
            true),
        Arguments.of(
            "normal - not permitted",
            NOT_MIGRATING_PRODUCT,
            ACCOUNT_NOT_CLOSED,
            false,
            BigDecimal.valueOf(234.56),
            BigDecimal.valueOf(123.45),
            true),
        Arguments.of(
            "account closed",
            NOT_MIGRATING_PRODUCT,
            ACCOUNT_CLOSED,
            true,
            BigDecimal.valueOf(234.56),
            null,
            true),
        Arguments.of(
            "account migrating product",
            MIGRATING_PRODUCT,
            ACCOUNT_NOT_CLOSED,
            true,
            null,
            BigDecimal.valueOf(123.45),
            true),
        Arguments.of(
            "by card not permitted",
            NOT_MIGRATING_PRODUCT,
            ACCOUNT_NOT_CLOSED,
            true,
            null,
            null,
            false));
  }

  private static Stream<Arguments> mapDepositsWithRestrictions() {
    return Stream.of(
        Arguments.of(
            "permitted when not affected by warnings",
            Collections.singletonList(
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE,
                    RESTRICTION_RULE_CODE_OTHER,
                    RESTRICTION_RESTYP_WEBTXT)),
            false),
        Arguments.of(
            "WEBREC account warning restriction rule",
            Collections.singletonList(
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE,
                    RESTRICTION_RULE_CODE_WEBREC,
                    RESTRICTION_RESTYP_WEBTXT)),
            true),
        Arguments.of(
            "WEBREC account warning restriction rule classic ISA",
            Collections.singletonList(
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE,
                    RESTRICTION_RULE_CODE_WEBREC,
                    RESTRICTION_RESTYP_WEBTXT)),
            true),
        Arguments.of(
            "WEBREC account warning NOSUBS restriction rule flexible ISA",
            Collections.singletonList(
                new AccountWarningRestrictionRule(
                    1L, "NOSUBS", RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_NOSUBS_WEBTXT)),
            true),
        Arguments.of(
            "WEBREC account warning NOREC restriction rule flexible ISA",
            Collections.singletonList(
                new AccountWarningRestrictionRule(
                    1L, "NOREC", RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_NOREC_WEBTXT)),
            true),
        Arguments.of(
            "WEBREC account warning restriction rule with ignored rule",
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L, "NOREC", RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_NOREC_WEBTXT),
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE,
                    RESTRICTION_RULE_CODE_WEBREC,
                    RESTRICTION_RESTYP_WEBTXT)),
            true));
  }

  private static ProductInfo buildProductInfo(
      final boolean depositsPermittedInternal, final boolean depositsPermittedByCard) {
    return ProductInfo.builder()
        .deposits(
            ProductInfo.Deposits.builder()
                .permittedInternal(depositsPermittedInternal)
                .permittedByCard(depositsPermittedByCard)
                .build())
        .build();
  }

  private static DepositLimit buildDepositLimit(
      final BigDecimal available, final BigDecimal maxProductBalRemaining) {
    return DepositLimit.builder()
        .available(available)
        .maxProductBalRemaining(maxProductBalRemaining)
        .build();
  }

  private static Restriction buildRestriction(final RestrictionCategory restrictionCategory) {
    return Restriction.builder().code(restrictionCategory).build();
  }
}
