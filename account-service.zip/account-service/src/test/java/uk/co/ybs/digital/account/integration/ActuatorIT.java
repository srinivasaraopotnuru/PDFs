package uk.co.ybs.digital.account.integration;

import java.net.URI;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.web.server.LocalManagementPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class})
@ActiveProfiles("test")
class ActuatorIT {
  @LocalManagementPort private int port;

  @Autowired private WebTestClient nonSigningWebClient;

  @ParameterizedTest
  @ValueSource(strings = {"/info", "/prometheus"})
  void shouldReturnOkForActuatorEndpointsWithNoJwtOrSignature(final String actuatorEndpoint) {
    nonSigningWebClient
        .get()
        .uri(URI.create("http://localhost:" + port + "/account/actuator" + actuatorEndpoint))
        .accept(MediaType.ALL)
        .exchange()
        .expectStatus()
        .isOk();
  }
}
