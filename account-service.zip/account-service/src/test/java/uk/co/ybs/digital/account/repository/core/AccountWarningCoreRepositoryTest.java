package uk.co.ybs.digital.account.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.model.core.AccountNumber;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.RestrictionType;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("accountProcessorTransactionManager")
class AccountWarningCoreRepositoryTest {
  private static final Long PRODUCT_ID = 1001L;
  private static final Long ACCOUNT_NUMBER_1 = 2001L;
  private static final Long RESTRICTION_TYPE_SYSID = 5001L;
  private static final String RESTRICTION_TYPE_CODE_1 = "RTYP1";

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");

  @Autowired AccountWarningCoreRepository testSubject;

  @Autowired TestEntityManager coreTestEntityManager;

  private TestHelper helper;

  @BeforeEach
  void beforeEach() {
    helper = new TestHelper(coreTestEntityManager);
    helper.persistSavingProduct(PRODUCT_ID);
  }

  @Test
  void shouldFindById() {
    final AccountWarning expectedAccountWarning = persistAccountWarningAndDefaultDependencies();

    final Optional<AccountWarning> accountWarning =
        testSubject.findById(expectedAccountWarning.getSysId());

    assertTrue(accountWarning.isPresent());
    assertThat(accountWarning.get(), samePropertyValuesAs(expectedAccountWarning));
  }

  @ParameterizedTest
  @MethodSource("startDateAndExpectedFoundAccountWarningStatus")
  void shouldOnlyFindAccountWarningWhenAccountWarningHasStarted(
      final LocalDateTime startDate, final Boolean expectedFound) {

    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        helper.persistRestrictionType(
            helper.buildRestrictionType(RESTRICTION_TYPE_SYSID, RESTRICTION_TYPE_CODE_1, NOW));
    helper.persistAccountWarning(
        helper.buildAccountWarning(accountNumber, restrictionType, startDate, null));
    coreTestEntityManager.clear();

    final Collection<AccountWarning> accountWarnings =
        testSubject.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber.getAccountNumber(),
            Collections.singletonList(RESTRICTION_TYPE_CODE_1),
            NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @ParameterizedTest
  @MethodSource("endDateAndExpectedFoundAccountWarningStatus")
  void shouldOnlyFindAccountWarningWhenAccountWarningHasNotEnded(
      final LocalDate endDate, final Boolean expectedFound) {

    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        helper.persistRestrictionType(
            helper.buildRestrictionType(RESTRICTION_TYPE_SYSID, RESTRICTION_TYPE_CODE_1, NOW));
    helper.persistAccountWarning(
        helper.buildAccountWarning(accountNumber, restrictionType, NOW, endDate));
    coreTestEntityManager.clear();

    final Collection<AccountWarning> accountWarnings =
        testSubject.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber.getAccountNumber(),
            Collections.singletonList(RESTRICTION_TYPE_CODE_1),
            NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @ParameterizedTest
  @MethodSource("startDateAndExpectedFoundAccountWarningStatus")
  void shouldOnlyFindAccountWarningWhenRestrictionTypeHasStarted(
      final LocalDateTime startDate, final Boolean expectedFound) {

    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        helper.persistRestrictionType(
            helper.buildRestrictionType(
                RESTRICTION_TYPE_SYSID, RESTRICTION_TYPE_CODE_1, startDate));
    helper.persistAccountWarning(
        helper.buildAccountWarning(accountNumber, restrictionType, NOW, null));
    coreTestEntityManager.clear();

    final Collection<AccountWarning> accountWarnings =
        testSubject.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber.getAccountNumber(),
            Collections.singletonList(RESTRICTION_TYPE_CODE_1),
            NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @ParameterizedTest
  @MethodSource("endDateAndExpectedFoundAccountWarningStatus")
  void shouldOnlyFindAccountWarningWhenRestrictionTypeHasNotEnded(
      final LocalDate endDate, final Boolean expectedFound) {

    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        RestrictionType.builder()
            .sysId(RESTRICTION_TYPE_SYSID)
            .code(RESTRICTION_TYPE_CODE_1)
            .startDate(NOW)
            .endDate(endDate)
            .build();
    helper.persistRestrictionType(restrictionType);
    helper.persistAccountWarning(
        helper.buildAccountWarning(accountNumber, restrictionType, NOW, null));
    coreTestEntityManager.clear();

    final Collection<AccountWarning> accountWarnings =
        testSubject.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber.getAccountNumber(),
            Collections.singletonList(RESTRICTION_TYPE_CODE_1),
            NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @ParameterizedTest
  @CsvSource({"2001,true", "2002,false"})
  void shouldOnlyFindAccountWarningWhenAccountNumberMatches(
      final Long accountNumber, final Boolean expectedFound) {

    persistAccountWarningAndDefaultDependencies();
    coreTestEntityManager.clear();

    final Collection<AccountWarning> accountWarnings =
        testSubject.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber, Collections.singletonList(RESTRICTION_TYPE_CODE_1), NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @ParameterizedTest
  @CsvSource({"RTYP1,true", "RTYP2,false"})
  void shouldNotFindAccountWarningWhenRestrictionTypeCodeMatches(
      final String restrictionType, final Boolean expectedFound) {

    persistAccountWarningAndDefaultDependencies();
    coreTestEntityManager.clear();

    final Collection<AccountWarning> accountWarnings =
        testSubject.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            ACCOUNT_NUMBER_1, Collections.singletonList(restrictionType), NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @Test
  void shouldUpdateAccountWarning() {
    final AccountWarning accountWarning = persistAccountWarningAndDefaultDependencies();
    coreTestEntityManager.clear();

    final Optional<AccountWarning> found = testSubject.findById(accountWarning.getSysId());
    assertTrue(found.isPresent());

    final AccountWarning updatedAccountWarning =
        found
            .get()
            .toBuilder()
            .endDate(NOW.toLocalDate())
            .endedDate(NOW)
            .endedAt("1234")
            .endedBy("SAPP")
            .build();
    updateAccountWarning(updatedAccountWarning);

    final Optional<AccountWarning> foundUpdated = testSubject.findById(accountWarning.getSysId());

    assertTrue(foundUpdated.isPresent());
    assertThat(foundUpdated.get(), samePropertyValuesAs(updatedAccountWarning));
  }

  private static Stream<Arguments> endDateAndExpectedFoundAccountWarningStatus() {
    return Stream.of(
        Arguments.of(NOW.minusDays(1).toLocalDate(), false),
        Arguments.of(NOW.toLocalDate(), false),
        Arguments.of(NOW.plusDays(1).toLocalDate(), true),
        Arguments.of(null, true));
  }

  private static Stream<Arguments> startDateAndExpectedFoundAccountWarningStatus() {
    return Stream.of(
        Arguments.of(NOW.minusDays(1), true),
        Arguments.of(NOW, true),
        Arguments.of(NOW.plusDays(1), false));
  }

  private AccountWarning persistAccountWarningAndDefaultDependencies() {
    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        helper.persistRestrictionType(
            helper.buildRestrictionType(RESTRICTION_TYPE_SYSID, RESTRICTION_TYPE_CODE_1, NOW));
    final AccountWarning accountWarning =
        helper.persistAccountWarning(
            helper.buildAccountWarning(accountNumber, restrictionType, NOW, null));
    return accountWarning;
  }

  private void updateAccountWarning(final AccountWarning accountWarning) {
    coreTestEntityManager.merge(accountWarning);
    coreTestEntityManager.flush();
    coreTestEntityManager.clear();
  }
}
