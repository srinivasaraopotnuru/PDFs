package uk.co.ybs.digital.account.service.processor;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Operation;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class AccountRequestFactoryTest {

  private static final long ACCOUNT_NUMBER = 9876543210L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final String TEST_USER = "TEST";
  private static final String TEST_AT = "TEST";
  @InjectMocks private AccountRequestFactory testSubject;
  @Mock private SubmitIsaDeclarationProcessor submitIsaDeclarationProcessor;
  @Mock private AccountWarningProcessor accountWarningProcessor;
  @Mock private DeleteAccountProcessor deleteAccountProcessor;
  @Mock private DeleteAccountWarningProcessor deleteAccountWarningProcessor;
  @Mock private UpdateAccountDetailsProcessor updateAccountDetailsProcessor;

  @Test
  public void shouldReturnSubmitIsaDeclarationRequestWhenOperationIsSubmitIsaDec() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);
    final WorkLog workLog =
        TestHelper.buildWorkLogWithAccountNumberAndRequestMetadata(
            ACCOUNT_NUMBER,
            TestHelper.buildSubmitIsaDeclarationRequest(),
            requestMetadata,
            Operation.SUBMIT_ISA_DEC);

    final AccountRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertEquals(
        request,
        SubmitIsaDeclarationRequest.builder()
            .arguments(
                SubmitIsaDeclarationRequestArguments.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .requestMetadata(requestMetadata)
                    .processTime(PROCESS_TIME)
                    .build())
            .processor(submitIsaDeclarationProcessor)
            .build());
  }

  @Test
  public void shouldReturnAccountWarningRequestWhenOperationIsInsertAccountWarning() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);
    final WorkLog workLog =
        TestHelper.buildWorkLogWithAccountNumberAndRequestMetadata(
            ACCOUNT_NUMBER,
            TestHelper.buildAccountWarningRequest(),
            requestMetadata,
            Operation.INS_ACCOUNT_WARNING);

    final AccountRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertEquals(
        request,
        AccountWarningRequest.builder()
            .arguments(
                AccountWarningRequestArguments.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .requestMetadata(requestMetadata)
                    .processTime(PROCESS_TIME)
                    .warningCode("ABC")
                    .createdAt(TEST_AT)
                    .createdBy(TEST_USER)
                    .notes("<Notes>")
                    .build())
            .processor(accountWarningProcessor)
            .build());
  }

  @Test
  public void shouldReturnDeleteAccountRequestWhenOperationIsDeleteAccount() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);
    final WorkLog workLog =
        TestHelper.buildWorkLogWithAccountNumberAndRequestMetadata(
            ACCOUNT_NUMBER,
            TestHelper.buildDeleteAccountRequest(),
            requestMetadata,
            Operation.DELETE_ACCOUNT);

    final AccountRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertEquals(
        request,
        DeleteAccountRequest.builder()
            .arguments(
                DeleteAccountRequestArguments.builder()
                    .accountNumber(workLog.getAccountNumber())
                    .processTime(PROCESS_TIME)
                    .requestMetadata(workLog.getMessage().getMetadata())
                    .build())
            .processor(deleteAccountProcessor)
            .build());
  }

  @Test
  public void shouldReturnDeleteAccountWarningRequestWhenOperationIsDeleteAccountWarning() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);
    final WorkLog workLog =
        TestHelper.buildWorkLogWithAccountNumberAndRequestMetadata(
            ACCOUNT_NUMBER,
            TestHelper.buildDeleteAccountWarningRequest(),
            requestMetadata,
            Operation.DEL_ACCOUNT_WARNING);

    final AccountRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertEquals(
        request,
        DeleteAccountWarningRequest.builder()
            .arguments(
                DeleteAccountWarningRequestArguments.builder()
                    .accountNumber(workLog.getAccountNumber())
                    .warningCode("ABC")
                    .endAt(TEST_AT)
                    .endBy(TEST_USER)
                    .processTime(PROCESS_TIME)
                    .requestMetadata(workLog.getMessage().getMetadata())
                    .build())
            .processor(deleteAccountWarningProcessor)
            .build());
  }

  @Test
  public void shouldReturnUpdateAccountDetailsRequestWhenOperationIsUpdateAccountDetails() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);
    final WorkLog workLog =
        TestHelper.buildWorkLogWithAccountNumberAndRequestMetadata(
            ACCOUNT_NUMBER,
            TestHelper.buildUpdateAccountDetailsRequest(),
            requestMetadata,
            Operation.UPDATE_ACCOUNT_DET);

    final AccountRequest request = testSubject.build(workLog, PROCESS_TIME);

    assertEquals(
        request,
        UpdateAccountDetailsRequest.builder()
            .arguments(
                UpdateAccountDetailsRequestArguments.builder()
                    .accountNumber(workLog.getAccountNumber())
                    .accountName("Nickname")
                    .processTime(PROCESS_TIME)
                    .requestMetadata(workLog.getMessage().getMetadata())
                    .build())
            .processor(updateAccountDetailsProcessor)
            .build());
  }
}
