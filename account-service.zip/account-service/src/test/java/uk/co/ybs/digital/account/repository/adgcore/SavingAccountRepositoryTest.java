package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import com.google.common.collect.ImmutableSet;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.SavingAccount;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class SavingAccountRepositoryTest {

  private static final long ACCOUNT_NUMBER = 12345678L;
  private static final long ACCOUNT2_NUMBER = 2372146519L;

  private static final LocalDateTime ACCOUNT_OPENED_DATE =
      LocalDateTime.parse("2019-05-25T14:27:44");
  private static final LocalDateTime ACCOUNT2_OPENED_DATE =
      LocalDateTime.parse("2019-05-25T14:27:44").minusDays(1);

  @Autowired private SavingAccountRepository testSubject;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  @Test
  void shouldFindById() {
    setupTestData();
    final SavingAccount savingAccount =
        TestHelper.buildSavingAccount(ACCOUNT_NUMBER, ACCOUNT_OPENED_DATE);
    adgCoreTestEntityManager.persistAndFlush(savingAccount);
    adgCoreTestEntityManager.clear();

    final Optional<SavingAccount> found = testSubject.findById(ACCOUNT_NUMBER);
    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(savingAccount));
    assertThat(found.get(), samePropertyValuesAs(savingAccount));
  }

  @Test
  void findAllById() {
    setupTestData();
    final SavingAccount savingAccount1 =
        TestHelper.buildSavingAccount(ACCOUNT_NUMBER, ACCOUNT_OPENED_DATE);
    final SavingAccount savingAccount2 =
        TestHelper.buildSavingAccount(ACCOUNT2_NUMBER, ACCOUNT2_OPENED_DATE);
    adgCoreTestEntityManager.persistAndFlush(savingAccount1);
    adgCoreTestEntityManager.persistAndFlush(savingAccount2);
    adgCoreTestEntityManager.clear();
    final ImmutableSet<Long> accountNumberLongs = ImmutableSet.of(ACCOUNT_NUMBER, ACCOUNT2_NUMBER);
    final List<SavingAccount> found = testSubject.findAllById(accountNumberLongs);
    assertThat(found.size(), is(2));
    assertThat(found.get(0), samePropertyValuesAs(savingAccount1));
    assertThat(found.get(1), samePropertyValuesAs(savingAccount2));
  }

  private void setupTestData() {
    adgCoreTestEntityManager.persistAndFlush(TestHelper.buildProduct());
    adgCoreTestEntityManager.persistAndFlush(TestHelper.buildAccountNumber(ACCOUNT_NUMBER));
    adgCoreTestEntityManager.persistAndFlush(TestHelper.buildAccountNumber(ACCOUNT2_NUMBER));
    adgCoreTestEntityManager.clear();
  }
}
