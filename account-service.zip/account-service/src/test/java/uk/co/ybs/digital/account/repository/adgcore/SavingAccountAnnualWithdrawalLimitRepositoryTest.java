package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.Collection;
import java.util.Optional;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
class SavingAccountAnnualWithdrawalLimitRepositoryTest {

  private static final String ACCOUNT_NUMBER_PROPERTY_NAME = "accountNumber";
  private static final Long ACCOUNT_NUMBER_1 = 2001L;
  private static final Long ACCOUNT_NUMBER_2 = 2002L;

  private static final Long PRODUCT_SYS_ID = 3001L;
  private static final LocalDate YEAR_START = LocalDate.of(2021, Month.MARCH, 31);

  @Autowired SavingAccountAnnualWithdrawalLimitRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @Test
  void shouldFindById() {
    // Proves that the repo has been setup with the correct entity and pk types
    final Long sysId = 123L;

    persistSavingProduct(PRODUCT_SYS_ID);
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_SYS_ID);
    final SavingAccountAnnualWithdrawalLimit persisted =
        persistSavingAccountAnnualWithdrawalLimit(
            sysId, accountNumber, PRODUCT_SYS_ID, 10, 1, YEAR_START);
    adgCoreTestEntityManager.clear();

    final Optional<SavingAccountAnnualWithdrawalLimit> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldFindAllByAccountNumbers() {
    persistSavingProduct(PRODUCT_SYS_ID);
    final AccountNumber accountNumber1 = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_SYS_ID);
    final AccountNumber accountNumber2 = persistAccountNumber(ACCOUNT_NUMBER_2, PRODUCT_SYS_ID);
    final SavingAccountAnnualWithdrawalLimit account1Limits =
        persistSavingAccountAnnualWithdrawalLimit(
            1L, accountNumber1, PRODUCT_SYS_ID, 10, 1, YEAR_START);
    final SavingAccountAnnualWithdrawalLimit account2Limits =
        persistSavingAccountAnnualWithdrawalLimit(
            2L, accountNumber2, PRODUCT_SYS_ID, 10, 1, YEAR_START);
    adgCoreTestEntityManager.clear();

    final Collection<SavingAccountAnnualWithdrawalLimit> limits =
        testSubject.findAllByAccountNumbers(Arrays.asList(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2));

    assertThat(limits, containsInAnyOrder(matches(account1Limits), matches(account2Limits)));
  }

  @ParameterizedTest
  @CsvSource({"2001,true", "2002,false"})
  void shouldOnlyFindLimitsWhereAccountNumberMatches(
      final Long testAccountNumber, final boolean expectedFind) {
    persistSavingProduct(PRODUCT_SYS_ID);
    final AccountNumber accountNumber = persistAccountNumber(testAccountNumber, PRODUCT_SYS_ID);
    persistSavingAccountAnnualWithdrawalLimit(1L, accountNumber, PRODUCT_SYS_ID, 10, 1, YEAR_START);
    adgCoreTestEntityManager.clear();

    final Collection<SavingAccountAnnualWithdrawalLimit> limits =
        testSubject.findAllByAccountNumbers(Arrays.asList(ACCOUNT_NUMBER_1));

    assertThat(limits.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"3001,true", "3002,false"})
  void shouldOnlyFindLimitsWhereAccountNumberProductMatchesLimitProduct(
      final Long productSysId, final boolean expectedFind) {
    persistSavingProduct(PRODUCT_SYS_ID);
    persistSavingProduct(3002L);
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, productSysId);
    persistSavingAccountAnnualWithdrawalLimit(1L, accountNumber, PRODUCT_SYS_ID, 10, 1, YEAR_START);
    adgCoreTestEntityManager.clear();

    final Collection<SavingAccountAnnualWithdrawalLimit> limits =
        testSubject.findAllByAccountNumbers(Arrays.asList(ACCOUNT_NUMBER_1));

    assertThat(limits.isEmpty(), not(expectedFind));
  }

  private SavingAccountAnnualWithdrawalLimit persistSavingAccountAnnualWithdrawalLimit(
      final Long sysId,
      final AccountNumber accountNumber,
      final Long savingProductSysId,
      final int withdrawalsAllowed,
      final int withdrawalsUsed,
      final LocalDate yearStart) {
    final SavingAccountAnnualWithdrawalLimit activityTypeGroup =
        new SavingAccountAnnualWithdrawalLimit(
            sysId,
            accountNumber,
            savingProductSysId,
            withdrawalsAllowed,
            withdrawalsUsed,
            yearStart);
    return adgCoreTestEntityManager.persistAndFlush(activityTypeGroup);
  }

  private AccountNumber persistAccountNumber(
      final Long accountNumber, final Long savingProductSysId) {
    final AccountNumber accNum =
        new AccountNumber(accountNumber, AccountNumber.TABLE_ID_SAVACC, savingProductSysId);
    return adgCoreTestEntityManager.persistAndFlush(accNum);
  }

  private void persistSavingProduct(final Long savingProductSysId) {
    adgCoreTestEntityManager.persistAndFlush(
        new SavingProduct(savingProductSysId, "YBS", "PROD_IDENT"));
  }

  private Matcher<SavingAccountAnnualWithdrawalLimit> matches(
      final SavingAccountAnnualWithdrawalLimit expected) {
    return allOf(
        samePropertyValuesAs(expected, ACCOUNT_NUMBER_PROPERTY_NAME),
        hasProperty(
            ACCOUNT_NUMBER_PROPERTY_NAME, samePropertyValuesAs(expected.getAccountNumber())));
  }
}
