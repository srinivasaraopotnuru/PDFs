package uk.co.ybs.digital.account.repository.adgcore;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.ActivityPlayer;
import uk.co.ybs.digital.account.model.adgcore.ActivityType;
import uk.co.ybs.digital.account.model.adgcore.SavingAccount;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;

@AllArgsConstructor
public class TestHelper {

  private static final String YBS_BRAND_CODE = "YBS";
  private static final String PRODUCT_IDENTIFIER = "PROD_IDENT";
  private static final long PRODUCT_ID = 100L;
  private static final BigDecimal BALANCE = new BigDecimal("100.00");
  private static final String VALID_WIT_CODE = "ROTS";

  private final TestEntityManager adgCoreTestEntityManager;

  public AccountNumber persistAccountNumberForSavingProduct(
      final Long accountNumber, final SavingProduct savingProduct) {
    final AccountNumber activityType =
        AccountNumber.builder()
            .accountNumber(accountNumber)
            .tableId(AccountNumber.TABLE_ID_SAVACC)
            .savingProductSysId(savingProduct.getSysid())
            .build();
    return adgCoreTestEntityManager.persistAndFlush(activityType);
  }

  public SavingProduct persistYbsSavingProduct(final Long sysId) {
    return persistSavingProductWithBrandCode(sysId, YBS_BRAND_CODE);
  }

  public SavingProduct persistSavingProductWithBrandCode(final Long sysId, final String brandCode) {
    final SavingProduct savingProduct =
        SavingProduct.builder()
            .sysid(sysId)
            .brandCode(brandCode)
            .productIdentifier(PRODUCT_IDENTIFIER)
            .build();
    return adgCoreTestEntityManager.persistAndFlush(savingProduct);
  }

  public ActivityPlayer persistActivityPlayerForAccountNumber(
      final Long sysId,
      final AccountNumber accountNumber,
      final Long customerId,
      final ActivityType activityType,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    return persistActivityPlayer(
        sysId,
        "ACCNUM",
        accountNumber.getAccountNumber(),
        customerId,
        activityType,
        startDate,
        endDate);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  public ActivityPlayer persistActivityPlayer(
      final Long sysId,
      final String tableId,
      final Long tableSysId,
      final Long partySysId,
      final ActivityType activityType,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    final ActivityPlayer activityPlayer =
        new ActivityPlayer(
            sysId, tableId, tableSysId, partySysId, activityType, startDate, endDate);
    return adgCoreTestEntityManager.persistAndFlush(activityPlayer);
  }

  public ActivityType persistActivityType(
      final String code, final LocalDateTime startDate, final LocalDateTime endDate) {
    final ActivityType activityType = new ActivityType(code, startDate, endDate);
    return adgCoreTestEntityManager.persistAndFlush(activityType);
  }

  public SavingAccount persistSavingAccount(
      final Long accountNumber, final LocalDateTime openedDate, final LocalDateTime closedDate) {
    return adgCoreTestEntityManager.persistAndFlush(
        new SavingAccount(
            accountNumber, openedDate, closedDate, BigDecimal.ZERO, BigDecimal.ZERO, null));
  }

  public static SavingProduct buildProduct() {
    return SavingProduct.builder().sysid(PRODUCT_ID).brandCode("YBS").build();
  }

  public static SavingAccount buildSavingAccount(
      final long accountNumber, final LocalDateTime accountOpenedDate) {
    return SavingAccount.builder()
        .accountNumber(accountNumber)
        .witCode(VALID_WIT_CODE)
        .interimBooked(BALANCE)
        .interimAvailable(BALANCE)
        .openedDate(accountOpenedDate)
        .build();
  }

  public static AccountNumber buildAccountNumber(final long accountNumber) {
    return AccountNumber.builder()
        .accountNumber(accountNumber)
        .savingProductSysId(PRODUCT_ID)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .build();
  }
}
