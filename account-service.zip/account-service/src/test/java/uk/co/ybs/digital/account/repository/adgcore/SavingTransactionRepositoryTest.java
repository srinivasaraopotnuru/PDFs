package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.SavingTransaction;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
class SavingTransactionRepositoryTest {

  private static final long ACCOUNT_NUMBER = 12345678L;
  private static final long SYS_ID = 1L;

  private static final long OTHER_ACCOUNT_NUMBER = 87654321L;
  private static final long OTHER_SYS_ID = 2L;

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-27T13:12:11");

  private static final String TRANSACTION_TYPE_CODE = "0010";
  private static final String OTHER_TRANSACTION_TYPE_CODE = "0011";

  @Autowired SavingTransactionRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @Test
  void shouldFindById() {
    final SavingTransaction savingTransaction = createSavingTransaction(SYS_ID).build();
    adgCoreTestEntityManager.persistAndFlush(savingTransaction);
    adgCoreTestEntityManager.clear();

    final Optional<SavingTransaction> found = testSubject.findById(1L);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(savingTransaction));
  }

  @Test
  void shouldFindSavingTransactionsInPeriod() {
    final SavingTransaction savingTransaction = createSavingTransaction(SYS_ID).build();
    adgCoreTestEntityManager.persistAndFlush(savingTransaction);
    adgCoreTestEntityManager.clear();

    final SavingTransaction otherSavingTransaction = createSavingTransaction(OTHER_SYS_ID).build();
    adgCoreTestEntityManager.persistAndFlush(otherSavingTransaction);
    adgCoreTestEntityManager.clear();

    final List<SavingTransaction> found =
        testSubject.findSavingTransactionsInPeriod(
            ACCOUNT_NUMBER, NOW, Collections.singletonList(OTHER_TRANSACTION_TYPE_CODE));

    assertThat(found, containsInAnyOrder(savingTransaction, otherSavingTransaction));
  }

  @ParameterizedTest
  @CsvSource({"2020-05-27T13:12:10,false", "2020-05-27T13:12:11,true", "2020-05-27T13:12:12,true"})
  void findSavingTransactionsInPeriodShouldOnlyFindTransactionsInPeriod(
      final LocalDateTime transactionDateTime, final boolean present) {
    final SavingTransaction savingTransaction =
        createSavingTransaction(SYS_ID)
            .processDate(transactionDateTime)
            .transactionDate(transactionDateTime)
            .build();
    adgCoreTestEntityManager.persistAndFlush(savingTransaction);
    adgCoreTestEntityManager.clear();

    final List<SavingTransaction> found =
        testSubject.findSavingTransactionsInPeriod(
            ACCOUNT_NUMBER, NOW, Collections.singletonList(OTHER_TRANSACTION_TYPE_CODE));

    assertThat(found, present ? containsInAnyOrder(savingTransaction) : is(empty()));
  }

  @Test
  void findSavingTransactionsInPeriodShouldNotFindDepositsWithWrongCategory() {
    final SavingTransaction savingTransaction =
        createSavingTransaction(SYS_ID).category("W").build();
    adgCoreTestEntityManager.persistAndFlush(savingTransaction);
    adgCoreTestEntityManager.clear();

    final List<SavingTransaction> found =
        testSubject.findSavingTransactionsInPeriod(
            ACCOUNT_NUMBER, NOW, Collections.singletonList(OTHER_TRANSACTION_TYPE_CODE));

    assertThat(found, is(empty()));
  }

  @Test
  void findSavingTransactionsInPeriodShouldNotFindDepositsWhenNoTransactionsForAccount() {
    final SavingTransaction savingTransaction = createSavingTransaction(SYS_ID).build();
    adgCoreTestEntityManager.persistAndFlush(savingTransaction);
    adgCoreTestEntityManager.clear();

    final List<SavingTransaction> found =
        testSubject.findSavingTransactionsInPeriod(
            OTHER_ACCOUNT_NUMBER, NOW, Collections.singletonList(OTHER_TRANSACTION_TYPE_CODE));

    assertThat(found, is(empty()));
  }

  @Test
  void findSavingTransactionsInPeriodShouldNotFindDepositsWhenTransactionTypeFiltered() {
    final SavingTransaction savingTransaction = createSavingTransaction(SYS_ID).build();
    adgCoreTestEntityManager.persistAndFlush(savingTransaction);
    adgCoreTestEntityManager.clear();

    final List<SavingTransaction> found =
        testSubject.findSavingTransactionsInPeriod(
            ACCOUNT_NUMBER, NOW, Collections.singletonList(TRANSACTION_TYPE_CODE));

    assertThat(found, is(empty()));
  }

  @Test
  void findSavingTransactionsInPeriodShouldNotFindDepositsWhenProcessDateIsNull() {
    final SavingTransaction savingTransaction =
        createSavingTransaction(SYS_ID).processDate(null).build();
    adgCoreTestEntityManager.persistAndFlush(savingTransaction);
    adgCoreTestEntityManager.clear();

    final List<SavingTransaction> found =
        testSubject.findSavingTransactionsInPeriod(
            ACCOUNT_NUMBER, NOW, Collections.singletonList(OTHER_TRANSACTION_TYPE_CODE));

    assertThat(found, is(empty()));
  }

  private static SavingTransaction.SavingTransactionBuilder createSavingTransaction(
      final long sysId) {
    return SavingTransaction.builder()
        .sysid(sysId)
        .accountNumber(ACCOUNT_NUMBER)
        .category("R")
        .financialTransactionTypeCode(TRANSACTION_TYPE_CODE)
        .processDate(NOW)
        .transactionAmount(new BigDecimal("1.00"))
        .transactionDate(NOW);
  }
}
