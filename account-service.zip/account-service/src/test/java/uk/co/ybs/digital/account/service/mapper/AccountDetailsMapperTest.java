package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.AccountClosureMapper;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.AccountDetails;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.Closure;
import uk.co.ybs.digital.account.web.dto.Deposits;
import uk.co.ybs.digital.account.web.dto.Interest;
import uk.co.ybs.digital.account.web.dto.InterestTier;
import uk.co.ybs.digital.account.web.dto.Isa;
import uk.co.ybs.digital.account.web.dto.Product;
import uk.co.ybs.digital.account.web.dto.Reinvestment;
import uk.co.ybs.digital.account.web.dto.Withdrawals;

@ExtendWith(MockitoExtension.class)
class AccountDetailsMapperTest {

  private static final String INTERNAL_ACCOUNT_NUMBER = "1234567890";
  private static final String EXTERNAL_ACCOUNT_NUMBER = "12345678";

  private static final int SORT_CODE_INTEGER = 1234;
  private static final String MAPPED_SORT_CODE = "001234";

  private static final LocalDate NEXT_INTEREST_PAYMENT_DATE = LocalDate.now();
  private static final Long PRODUCT_SYS_ID = 2000L;
  private static final int WITHDRAWAL_LIMIT_PERMITTED = 5;
  private static final int WITHDRAWAL_LIMIT_MADE = 3;
  private static final Set<String> ACTIVITY_GROUPS = Collections.singleton("PISP");
  private static final LocalDate ACCOUNT_OPENED_DATE = LocalDate.parse("2017-10-29");
  private static final String MONTHLY_FREQUENCY = "Monthly";
  private static final Long PARTY_ID = 1246295101L;
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-09-01T00:00:00");
  private static final String VALID_WIT_CODE = "ROTS";

  private AccountDetailsMapper mapper;

  @Mock private CommonAccountMapper commonAccountMapper;

  @Mock private BalanceMapper balanceMapper;

  @Mock private WithdrawalsMapper withdrawalsMapper;

  @Mock private DepositsMapper depositsMapper;

  @Mock private IsaMapper isaMapper;

  @Mock private AccountClosureMapper accountClosureMapper;

  @Mock private AmendmentRestrictionMapper amendmentRestrictionMapper;

  @Mock private ProductMapper productMapper;

  @BeforeEach
  void setUp() {
    mapper =
        new AccountDetailsMapper(
            commonAccountMapper,
            balanceMapper,
            withdrawalsMapper,
            depositsMapper,
            isaMapper,
            accountClosureMapper,
            amendmentRestrictionMapper,
            productMapper);
  }

  private static AccountDetails buildExpected(
      final Interest interest, final boolean smartTiered, final boolean reinvestmentPermitted) {
    return AccountDetails.builder()
        .accountNumber(INTERNAL_ACCOUNT_NUMBER)
        .accountName("ACC_NAME1")
        .amendmentRestriction(false)
        .accountSortCode(MAPPED_SORT_CODE)
        .currency("GBP")
        .externalAccountNumber(EXTERNAL_ACCOUNT_NUMBER)
        .openedDate(ACCOUNT_OPENED_DATE)
        .closedDate(LocalDate.of(2018, Month.SEPTEMBER, 29))
        .productIdentifier("EGG302A")
        .productDescription("Customer Description")
        .deposits(createDeposits())
        .product(createProduct(smartTiered))
        .isa(mappedIsa())
        .withdrawals(createWithdrawals())
        .balances(
            Collections.singletonList(
                Balance.builder().type("InterimAvailable").amount(new BigDecimal("56.76")).build()))
        .interest(interest)
        .reinvestment(TestHelper.createReinvestment(reinvestmentPermitted))
        .closure(Closure.builder().permittedOverApi(true).build())
        .build();
  }

  private static Interest buildInterest(final Boolean interestOptionsPermitted) {
    return Interest.builder()
        .interestInstruction("Payaway")
        .nextPaymentDate(NEXT_INTEREST_PAYMENT_DATE)
        .calculationFrequency(MONTHLY_FREQUENCY)
        .applicationFrequency(MONTHLY_FREQUENCY)
        .interestOptionsPermitted(interestOptionsPermitted)
        .interestTiers(
            Collections.singletonList(
                InterestTier.builder().interestRate("3.11").annualEquivalentRate("3.12").build()))
        .build();
  }

  private static Interest buildInterestSmartTiered(final Boolean interestOptionsPermitted) {
    return Interest.builder()
        .interestInstruction("Payaway")
        .nextPaymentDate(NEXT_INTEREST_PAYMENT_DATE)
        .calculationFrequency(MONTHLY_FREQUENCY)
        .applicationFrequency(MONTHLY_FREQUENCY)
        .interestOptionsPermitted(interestOptionsPermitted)
        .interestTiers(
            Arrays.asList(
                InterestTier.builder()
                    .annualEquivalentRate("0.75")
                    .interestRate("0.75")
                    .rangeLow(new BigDecimal("0.00"))
                    .rangeHigh(new BigDecimal("999.99"))
                    .build(),
                InterestTier.builder()
                    .annualEquivalentRate("1.00")
                    .interestRate("1.00")
                    .rangeLow(new BigDecimal("1000.00"))
                    .rangeHigh(new BigDecimal("9999.99"))
                    .build()))
        .build();
  }

  private static Stream<Arguments> products() {
    return Stream.of(
        Arguments.of(
            TestHelper.createFullProductInfo(),
            false,
            false,
            buildExpected(buildInterest(false), false, false)),
        Arguments.of(
            TestHelper.createFullProductInfo(),
            true,
            true,
            buildExpected(buildInterest(true), false, true)),
        Arguments.of(
            TestHelper.createFullProductInfoSmartTiered(),
            false,
            false,
            buildExpected(buildInterestSmartTiered(false), true, false)),
        Arguments.of(
            TestHelper.createFullProductInfoSmartTiered(),
            true,
            false,
            buildExpected(buildInterestSmartTiered(false), true, true)));
  }

  @ParameterizedTest
  @MethodSource("products")
  void shouldMapAccountDetails(
      final ProductInfo productInfo,
      final boolean reinvestmentPermitted,
      final boolean interestOptionsPermitted,
      final AccountDetails expected) {
    final SavingAccountDetails source = createSavingAccountDetails(createSavingAccountDetails());
    final List<AccountBalanceType> accountBalanceTypeList = createAccountBalanceTypeList();
    final boolean productMigrationInProgress = true;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final SavingAccountAnnualWithdrawalLimit annualWithdrawalLimit =
        createSavingAccountAnnualWithdrawalLimit();
    final boolean accountClosed = false;
    final BigDecimal remainingBalance = BigDecimal.ZERO;
    final BigDecimal maxProductBalRemaining = BigDecimal.ZERO;
    final Reinvestment reinvestment = TestHelper.createReinvestment(reinvestmentPermitted);

    when(commonAccountMapper.convertAndPadSortCode(SORT_CODE_INTEGER)).thenReturn(MAPPED_SORT_CODE);
    when(commonAccountMapper.internalToExternalAccountNumber(INTERNAL_ACCOUNT_NUMBER))
        .thenReturn(EXTERNAL_ACCOUNT_NUMBER);

    when(withdrawalsMapper.map(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            ACTIVITY_GROUPS,
            annualWithdrawalLimit,
            accountClosed))
        .thenReturn(expected.getWithdrawals());

    when(withdrawalsMapper.isPermittedOverApi(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            ACTIVITY_GROUPS,
            annualWithdrawalLimit,
            accountClosed))
        .thenReturn(true);

    when(depositsMapper.map(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            accountClosed,
            remainingBalance,
            maxProductBalRemaining,
            PARTY_ID,
            NOW,
            VALID_WIT_CODE))
        .thenReturn(expected.getDeposits());

    when(balanceMapper.filterAndMapAccountBalanceTypeList(accountBalanceTypeList, true))
        .thenReturn(expected.getBalances());

    when(isaMapper.mapIsa(productInfo, INTERNAL_ACCOUNT_NUMBER)).thenReturn(mappedIsa());

    when(accountClosureMapper.map(
            productInfo,
            accountWarningRestrictionRules,
            expected.getClosedDate(),
            INTERNAL_ACCOUNT_NUMBER,
            ACTIVITY_GROUPS,
            VALID_WIT_CODE))
        .thenReturn(Closure.builder().permittedOverApi(true).build());

    when(amendmentRestrictionMapper.amendmentRestricted(accountWarningRestrictionRules))
        .thenReturn(false);

    when(productMapper.map(productInfo)).thenReturn(expected.getProduct());

    final AccountDetails mapped =
        mapper.accountSummaryResponseTypeToAccount(
            source,
            accountBalanceTypeList,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            ACTIVITY_GROUPS,
            annualWithdrawalLimit,
            accountClosed,
            remainingBalance,
            maxProductBalRemaining,
            ACCOUNT_OPENED_DATE,
            reinvestment,
            interestOptionsPermitted,
            VALID_WIT_CODE,
            PARTY_ID,
            NOW);

    assertThat(mapped, is(expected));
  }

  @Test
  void shouldMapMissingProductInfoToNullInterest() {
    final SavingAccountDetails source =
        SavingAccountDetails.builder()
            .accountNumber(Long.valueOf(INTERNAL_ACCOUNT_NUMBER))
            .currencyCode("GBP")
            .accountName("ACC_NAME1")
            .sortCode(SORT_CODE_INTEGER)
            .productIdentifier("PRODUCT_IDEN1")
            .productType("TYPE1")
            .productName("PRODUCT_NAME1")
            .isPaymentAccount(true)
            .closedDate(LocalDate.of(2018, 9, 29))
            .brandCode("YBS")
            .accountHolderName("AccountHolderName1")
            .build();
    final List<AccountBalanceType> accountBalanceTypeList = createAccountBalanceTypeList();
    final ProductInfo productInfo = TestHelper.createFullProductInfo();
    final boolean productMigrationInProgress = true;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final SavingAccountAnnualWithdrawalLimit annualWithdrawalLimit =
        createSavingAccountAnnualWithdrawalLimit();
    final boolean accountClosed = false;
    final BigDecimal remainingBalance = BigDecimal.ZERO;
    final BigDecimal maxProductBalRemaining = BigDecimal.ZERO;
    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    final Boolean interestOptionsPermitted = false;

    when(commonAccountMapper.convertAndPadSortCode(SORT_CODE_INTEGER)).thenReturn(MAPPED_SORT_CODE);
    when(commonAccountMapper.internalToExternalAccountNumber(INTERNAL_ACCOUNT_NUMBER))
        .thenReturn(EXTERNAL_ACCOUNT_NUMBER);
    when(withdrawalsMapper.map(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            ACTIVITY_GROUPS,
            annualWithdrawalLimit,
            accountClosed))
        .thenReturn(createWithdrawals());
    when(depositsMapper.map(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            accountClosed,
            remainingBalance,
            maxProductBalRemaining,
            PARTY_ID,
            NOW,
            VALID_WIT_CODE))
        .thenReturn(createDeposits());
    when(balanceMapper.filterAndMapAccountBalanceTypeList(accountBalanceTypeList, false))
        .thenReturn(Collections.emptyList());

    final AccountDetails mapped =
        mapper.accountSummaryResponseTypeToAccount(
            source,
            accountBalanceTypeList,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            ACTIVITY_GROUPS,
            annualWithdrawalLimit,
            accountClosed,
            remainingBalance,
            maxProductBalRemaining,
            ACCOUNT_OPENED_DATE,
            reinvestment,
            interestOptionsPermitted,
            VALID_WIT_CODE,
            PARTY_ID,
            NOW);

    assertThat(mapped.getInterest(), is(nullValue()));
  }

  private static Deposits createDeposits() {
    return Deposits.builder().permittedOverApi(false).build();
  }

  private static Withdrawals createWithdrawals() {
    return Withdrawals.builder().permittedOverApi(false).build();
  }

  private static Isa mappedIsa() {
    return Isa.builder().flexible(false).helpToBuy(true).subscribed(false).build();
  }

  private static Product createProduct(final boolean smartTiered) {
    return Product.builder()
        .identifier("EGG302A")
        .description("Customer Description")
        .type("Product Type")
        .smartTiered(smartTiered)
        .build();
  }

  private SavingAccountDetails createSavingAccountDetails(
      final SavingAccountDetails savingAccountDetails) {
    return SavingAccountDetails.builder()
        .accountNumber(Long.valueOf(INTERNAL_ACCOUNT_NUMBER))
        .currencyCode("GBP")
        .accountName("ACC_NAME1")
        .sortCode(SORT_CODE_INTEGER)
        .productIdentifier("PRODUCT_IDEN1")
        .productType("TYPE1")
        .productName("PRODUCT_NAME1")
        .isPaymentAccount(true)
        .closedDate(LocalDate.of(2018, 9, 29))
        .brandCode("YBS")
        .interestInstruction(savingAccountDetails.getInterestInstruction())
        .nextInterestDate(savingAccountDetails.getNextInterestDate())
        .interestFrequency(savingAccountDetails.getInterestFrequency())
        .accountInterestFrequency(savingAccountDetails.getAccountInterestFrequency())
        .annualEquivalentRate(savingAccountDetails.getAnnualEquivalentRate())
        .interestRate(savingAccountDetails.getInterestRate())
        .accountHolderName("AccountHolderName1")
        .build();
  }

  private static SavingAccountDetails createSavingAccountDetails() {
    return SavingAccountDetails.builder()
        .interestInstruction("Payaway")
        .nextInterestDate(NEXT_INTEREST_PAYMENT_DATE)
        .interestFrequency(MONTHLY_FREQUENCY)
        .accountInterestFrequency(MONTHLY_FREQUENCY)
        .annualEquivalentRate("3.12")
        .interestRate("3.11")
        .build();
  }

  private static List<AccountBalanceType> createAccountBalanceTypeList() {
    return Collections.singletonList(
        AccountBalanceType.builder()
            .balanceType("CapitalAvailable")
            .balanceAmount(new BigDecimal("56.76"))
            .build());
  }

  private static SavingAccountAnnualWithdrawalLimit createSavingAccountAnnualWithdrawalLimit() {
    return SavingAccountAnnualWithdrawalLimit.builder()
        .sysId(1L)
        .accountNumber(
            AccountNumber.builder()
                .accountNumber(Long.parseLong(INTERNAL_ACCOUNT_NUMBER))
                .tableId(AccountNumber.TABLE_ID_SAVACC)
                .savingProductSysId(PRODUCT_SYS_ID)
                .build())
        .savingProductSysId(PRODUCT_SYS_ID)
        .withdrawalsAllowed(WITHDRAWAL_LIMIT_PERMITTED)
        .withdrawalsMade(WITHDRAWAL_LIMIT_MADE)
        .yearStart(null)
        .build();
  }

  private static List<AccountWarningRestrictionRule> createAccountWarningRestrictionRules() {
    return Collections.singletonList(
        new AccountWarningRestrictionRule(1L, "RESTYP", "RULE", "RESTYP_WEBTXT"));
  }
}
