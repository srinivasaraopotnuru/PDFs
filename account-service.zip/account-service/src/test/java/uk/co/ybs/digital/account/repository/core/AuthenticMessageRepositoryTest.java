package uk.co.ybs.digital.account.repository.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.exception.AuthenticMessageException;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;
import uk.co.ybs.digital.account.service.AuthenticMessageService;

/**
 * This class will test the functionality of repository AuthenticMessageRepository.
 *
 * @author Manish Garg
 */
@YbsDataJpaTest
@Transactional("accountProcessorTransactionManager")
public class AuthenticMessageRepositoryTest {

  @InjectMocks private AuthenticMessageRepository authenticMessageRepository;

  @Mock private EntityManager entityManager;

  @Mock private StoredProcedureQuery query;

  /**
   * Setup data before the test cases.
   *
   * @throws SQLException : SQLException
   */
  @BeforeEach
  void setUp() throws SQLException {
    when(entityManager.createStoredProcedureQuery(anyString())).thenReturn(query);
    when(query.registerStoredProcedureParameter(
            anyString(), any(Class.class), any(ParameterMode.class)))
        .thenReturn(query);
    when(query.setParameter(anyString(), any())).thenReturn(query);
  }

  /**
   * This will test writeAuthenticMessage function for success scenario.
   *
   * @throws IOException throws input output exception.ion
   */
  @Test
  void shouldReturnCount() throws IOException {
    when(query.executeUpdate()).thenReturn(1);
    final long accNum = 1234567890L;
    final int count =
        authenticMessageRepository.writeAuthenticMessage(
            AuthenticMessageService.HOST_3007,
            "123456",
            accNum,
            AuthenticMessageService.STATUS_C,
            AuthenticMessageService.FUNCTION_0,
            LocalDateTime.now());
    assertEquals(1, count);
  }

  @Test
  void shouldThrowAuthenticMessageException() throws IOException {
    when(query.executeUpdate()).thenThrow(new RuntimeException());
    final long accNum = 1234567890L;
    assertThrows(
        AuthenticMessageException.class,
        () ->
            authenticMessageRepository.writeAuthenticMessage(
                AuthenticMessageService.HOST_3007,
                "123456",
                accNum,
                AuthenticMessageService.STATUS_C,
                AuthenticMessageService.FUNCTION_0,
                LocalDateTime.now()));
  }
}
