package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class RestrictionTypeRepositoryTest {

  @Autowired private RestrictionTypeRepository testSubject;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  private static final Long RESTRICTION_TYPE_SYS_ID = 123L;
  private static final String RESTRICTION_TYPE_CODE = "CA";
  private static final String RESTRICTION_TYPE_DESCRIPTION = "Test description";
  private static final LocalDateTime NOW = LocalDateTime.now();

  @Test
  void shouldFindById() {
    final RestrictionType persisted =
        persistRestrictionType(RESTRICTION_TYPE_SYS_ID, RESTRICTION_TYPE_CODE, NOW, null);
    final Optional<RestrictionType> result = testSubject.findById(RESTRICTION_TYPE_SYS_ID);

    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldFindByCode() {
    final RestrictionType persisted =
        persistRestrictionType(RESTRICTION_TYPE_SYS_ID, RESTRICTION_TYPE_CODE, NOW, null);
    final Optional<RestrictionType> result = testSubject.findByCode(RESTRICTION_TYPE_CODE);

    assertThat(result.isPresent(), is(true));
    assertThat(result.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldNotFindByCodeWhenCodeIsDifferent() {
    persistRestrictionType(RESTRICTION_TYPE_SYS_ID, RESTRICTION_TYPE_CODE, NOW, null);
    final Optional<RestrictionType> result = testSubject.findByCode("RV");

    assertThat(result.isPresent(), is(false));
  }

  private RestrictionType persistRestrictionType(
      final Long sysId,
      final String restrictionTypeCode,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    final RestrictionType restrictionType =
        RestrictionType.builder()
            .sysId(sysId)
            .code(restrictionTypeCode)
            .description(RESTRICTION_TYPE_DESCRIPTION)
            .startDate(startDate)
            .endDate(endDate)
            .build();
    return adgCoreTestEntityManager.persistAndFlush(restrictionType);
  }
}
