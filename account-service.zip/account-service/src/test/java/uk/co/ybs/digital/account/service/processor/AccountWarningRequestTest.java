package uk.co.ybs.digital.account.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class AccountWarningRequestTest {
  @Mock private AccountWarningProcessor accountWarningProcessor;

  private AccountWarningRequest testSubject;
  private RequestMetadata requestMetadata;
  private AccountWarningRequestArguments arguments;
  private AccountNumber account;
  private static final Long ACCOUNT_NUMBER = 1L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  @BeforeEach
  void setUp() {
    requestMetadata = TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);
    arguments =
        AccountWarningRequestArguments.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .warningCode("ABC")
            .createdAt("TEST")
            .createdBy("TEST")
            .notes("Some Notes")
            .processTime(PROCESS_TIME)
            .requestMetadata(requestMetadata)
            .build();
    account =
        AccountNumber.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .tableId(AccountNumber.TABLE_ID_SAVACC)
            .savingProductSysId(1L)
            .build();
    testSubject =
        AccountWarningRequest.builder()
            .arguments(arguments)
            .processor(accountWarningProcessor)
            .build();
  }

  @Test
  void resolveShouldCallProcessor() {
    when(accountWarningProcessor.resolve(arguments)).thenReturn(account);

    final ResolvedAccountRequest expected =
        new ResolvedAccountWarningRequest(arguments, accountWarningProcessor, account);

    final ResolvedAccountRequest resolved = testSubject.resolve();

    assertThat(resolved, is(expected));
  }
}
