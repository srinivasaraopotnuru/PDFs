package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static uk.co.ybs.digital.account.utils.TestHelper.PARTY_ID_LONG;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.ActivityType;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.model.adgcore.TessaDetails;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
class TessaDetailsRepositoryTest {

  private static final Long PRODUCT_ID = 1001L;
  private static final Long ACCOUNT_NUMBER = 1000000001L;
  private static final Long ACCOUNT_NUMBER_2 = 1000000002L;
  private static final Integer TESSA_YEAR = 22;
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");

  @Autowired private TessaDetailsRepository testSubject;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  private TestHelper testHelper;

  @BeforeEach
  void setup() {
    testHelper = new TestHelper(adgCoreTestEntityManager);
  }

  @Test
  void shouldFindActive() {
    adgCoreTestEntityManager.persist(buildProduct());
    persistAccountNumber(ACCOUNT_NUMBER);

    final TessaDetails details = buildTessaDetails();

    adgCoreTestEntityManager.persistAndFlush(details);
    adgCoreTestEntityManager.clear();

    final Optional<TessaDetails> found =
        testSubject.findActiveByAccountNumberAndTessaYear(ACCOUNT_NUMBER, TESSA_YEAR);
    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(details));
    assertThat(found.get(), samePropertyValuesAs(details));
  }

  @Test
  void shouldNotFindEnded() {
    adgCoreTestEntityManager.persist(buildProduct());
    persistAccountNumber(ACCOUNT_NUMBER);

    final TessaDetails details =
        buildTessaDetails().toBuilder().endedDate(LocalDateTime.of(2020, 6, 2, 16, 20, 5)).build();

    adgCoreTestEntityManager.persistAndFlush(details);
    adgCoreTestEntityManager.clear();

    final Optional<TessaDetails> found =
        testSubject.findActiveByAccountNumberAndTessaYear(ACCOUNT_NUMBER, TESSA_YEAR);
    assertThat(found.isPresent(), is(false));
  }

  @Test
  void shouldNotFindActiveWrongAccountNumber() {
    adgCoreTestEntityManager.persist(buildProduct());
    final Long accountNumber = ACCOUNT_NUMBER + 1;
    persistAccountNumber(accountNumber);

    final TessaDetails details =
        buildTessaDetails().toBuilder().accountNumber(accountNumber).build();

    adgCoreTestEntityManager.persistAndFlush(details);
    adgCoreTestEntityManager.clear();

    final Optional<TessaDetails> found =
        testSubject.findActiveByAccountNumberAndTessaYear(ACCOUNT_NUMBER, TESSA_YEAR);
    assertThat(found.isPresent(), is(false));
  }

  @Test
  void shouldNotFindActiveWrongTessaYear() {
    adgCoreTestEntityManager.persist(buildProduct());
    persistAccountNumber(ACCOUNT_NUMBER);

    final TessaDetails details = buildTessaDetails().toBuilder().tessaYear(TESSA_YEAR + 1).build();

    adgCoreTestEntityManager.persistAndFlush(details);
    adgCoreTestEntityManager.clear();

    final Optional<TessaDetails> found =
        testSubject.findActiveByAccountNumberAndTessaYear(ACCOUNT_NUMBER, TESSA_YEAR);
    assertThat(found.isPresent(), is(false));
  }

  @Test
  void shouldFindById() {
    adgCoreTestEntityManager.persist(buildProduct());
    persistAccountNumber(ACCOUNT_NUMBER);

    final TessaDetails details = buildTessaDetails();

    adgCoreTestEntityManager.persistAndFlush(details);
    adgCoreTestEntityManager.clear();

    final Optional<TessaDetails> found = testSubject.findById(1L);
    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(details));
    assertThat(found.get(), samePropertyValuesAs(details));
  }

  @ParameterizedTest
  @MethodSource("tessaDetails")
  void shouldReturnFoundAndNotFoundTessaDetails(
      final Long sysId,
      final Long accountNumber,
      final Integer tessaYear,
      final LocalDateTime firstSubDate,
      final LocalDateTime endedDate,
      final boolean tessaFound) {

    adgCoreTestEntityManager.persist(buildProduct());
    persistAccountNumber(accountNumber);

    final TessaDetails tessaDetails =
        TessaDetails.builder()
            .sysid(sysId)
            .accountNumber(accountNumber)
            .amountInvested(new BigDecimal("100.10"))
            .createdDate(LocalDateTime.of(2020, 6, 2, 16, 20, 5))
            .tessaYear(tessaYear)
            .dateFirstSub(firstSubDate)
            .endedDate(endedDate)
            .build();

    adgCoreTestEntityManager.persistAndFlush(tessaDetails);
    adgCoreTestEntityManager.clear();

    final Optional<TessaDetails> found =
        testSubject.findActiveIsaSubscriptionByIsaYearAndAccountNumber(accountNumber, tessaYear);

    assertThat(found.isPresent(), is(tessaFound));
  }

  @Test
  void
      existsOtherSubscriptionsInIsaYearShouldReturnTrueWhenPartySubscribedToOtherIsaInSameIsaYear() {
    adgCoreTestEntityManager.persist(buildProduct());
    persistAccountNumber(ACCOUNT_NUMBER);
    persistAccountNumber(ACCOUNT_NUMBER_2);
    final ActivityType activityType = testHelper.persistActivityType("MHLDRS", NOW, null);
    testHelper.persistActivityPlayerForAccountNumber(
        123L,
        AccountNumber.builder().accountNumber(ACCOUNT_NUMBER).build(),
        PARTY_ID_LONG,
        activityType,
        NOW,
        null);
    testHelper.persistActivityPlayerForAccountNumber(
        124L,
        AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_2).build(),
        PARTY_ID_LONG,
        activityType,
        NOW,
        null);
    final TessaDetails details = buildTessaDetails(1L, ACCOUNT_NUMBER, TESSA_YEAR, NOW);
    final TessaDetails detailsOtherIsaSubscribed =
        buildTessaDetails(2L, ACCOUNT_NUMBER_2, TESSA_YEAR, NOW);
    adgCoreTestEntityManager.persistAndFlush(details);
    adgCoreTestEntityManager.persistAndFlush(detailsOtherIsaSubscribed);
    adgCoreTestEntityManager.clear();

    assertThat(
        testSubject.existsOtherSubscriptionsInIsaYear(ACCOUNT_NUMBER, TESSA_YEAR, PARTY_ID_LONG),
        is(true));
  }

  @ParameterizedTest
  @MethodSource("otherIsaNotSubscribedSameTaxYear")
  void
      existsOtherSubscriptionsInIsaYearShouldReturnFalseWhenPartyNotSubscribedToOtherIsaInSameIsaYear(
          final String activityTypeCodeOtherIsa,
          final int tessaYearOtherIsa,
          final LocalDateTime dateFirstSubOtherIsa,
          final LocalDateTime activityPlayerEndDateOtherIsa) {
    adgCoreTestEntityManager.persist(buildProduct());
    persistAccountNumber(ACCOUNT_NUMBER);
    persistAccountNumber(ACCOUNT_NUMBER_2);
    final ActivityType activityType = testHelper.persistActivityType("MHLDRS", NOW, null);
    final ActivityType activityTypeOtherIsa =
        testHelper.persistActivityType(activityTypeCodeOtherIsa, NOW, null);
    testHelper.persistActivityPlayerForAccountNumber(
        123L,
        AccountNumber.builder().accountNumber(ACCOUNT_NUMBER).build(),
        PARTY_ID_LONG,
        activityType,
        NOW,
        null);
    testHelper.persistActivityPlayerForAccountNumber(
        124L,
        AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_2).build(),
        PARTY_ID_LONG,
        activityTypeOtherIsa,
        NOW,
        activityPlayerEndDateOtherIsa);
    final TessaDetails details = buildTessaDetails(1L, ACCOUNT_NUMBER, TESSA_YEAR, NOW);
    final TessaDetails detailsOtherIsaSubscribed =
        buildTessaDetails(2L, ACCOUNT_NUMBER_2, tessaYearOtherIsa, dateFirstSubOtherIsa);
    adgCoreTestEntityManager.persistAndFlush(details);
    adgCoreTestEntityManager.persistAndFlush(detailsOtherIsaSubscribed);
    adgCoreTestEntityManager.clear();

    assertThat(
        testSubject.existsOtherSubscriptionsInIsaYear(ACCOUNT_NUMBER, TESSA_YEAR, PARTY_ID_LONG),
        is(false));
  }

  private static Stream<Arguments> tessaDetails() {

    return Stream.of(
        Arguments.of(1234L, ACCOUNT_NUMBER, 5, NOW, null, true),
        Arguments.of(1235L, 1001184122L, 4, NOW.minusDays(4), null, true),
        Arguments.of(1235L, 1001184888L, 3, NOW.minusDays(8), null, true),
        Arguments.of(1235L, 1001999996L, 2, NOW.minusDays(10), null, true),
        Arguments.of(9999L, 1001999997L, 2, null, null, false),
        Arguments.of(8888L, 1001999998L, 2, null, NOW.minusDays(10), false),
        Arguments.of(8888L, 1001999998L, 2, NOW.minusDays(5), NOW.minusDays(10), false));
  }

  private static Stream<Arguments> otherIsaNotSubscribedSameTaxYear() {

    return Stream.of(
        Arguments.of(
            "SIG", TESSA_YEAR, NOW, null), // Activity type on other isa  is not MHLDRS or BENOWN
        Arguments.of("BENOWN", TESSA_YEAR - 1, NOW, null), // other isa is not in same tessa year
        Arguments.of("BENOWN", TESSA_YEAR, null, null), // Other account has date first sub of null
        Arguments.of(
            "BENOWN", TESSA_YEAR, null, NOW) // Activity player end date not null for other account
        );
  }

  private void persistAccountNumber(final Long accountNumber) {
    adgCoreTestEntityManager.persist(buildAccountNumber(accountNumber));
  }

  private SavingProduct buildProduct() {
    return SavingProduct.builder().sysid(PRODUCT_ID).brandCode("YBS").build();
  }

  private AccountNumber buildAccountNumber(final Long accountNumber) {
    return AccountNumber.builder()
        .accountNumber(accountNumber)
        .savingProductSysId(PRODUCT_ID)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .build();
  }

  private TessaDetails buildTessaDetails() {
    return buildTessaDetails(1L, ACCOUNT_NUMBER, TESSA_YEAR, NOW);
  }

  private TessaDetails buildTessaDetails(
      final Long sysId,
      final Long accountNumber,
      final int tessaYear,
      final LocalDateTime dateFirstSub) {
    return TessaDetails.builder()
        .sysid(sysId)
        .accountNumber(accountNumber)
        .tessaYear(tessaYear)
        .amountInvested(new BigDecimal("100.10"))
        .createdDate(LocalDateTime.of(2020, 6, 2, 16, 20, 5))
        .endedDate(null)
        .previousYearFlexibility(new BigDecimal("200.20"))
        .currentYearFlexibility(new BigDecimal("300.30"))
        .dateFirstSub(dateFirstSub)
        .build();
  }
}
