package uk.co.ybs.digital.account.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.repository.adgcore.WithdrawalInterestPenaltyRepository;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AuthenticService;
import uk.co.ybs.digital.account.service.product.ProductService;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.WithdrawalInterestPenalty;

@ExtendWith(MockitoExtension.class)
class WithdrawalInterestPenaltyCalculatorTest {

  private static final String PRODUCT_IDENTIFIER = "INTSAV";
  private static final BigDecimal MINIMUM_BALANCE = new BigDecimal("100.00");
  private static final String INTEREST_PERIOD_END_INDICATOR = "P";
  private static final LocalDateTime INTEREST_PERIOD_END_DATE =
      LocalDateTime.parse("2021-08-31T00:00:00");
  private static final Integer INTEREST_DIVISOR_DAYS = 366;
  private static final Integer INTEREST_PREVIOUS_DIVISOR_DAYS = 365;
  private static final LocalDateTime START_DATE = LocalDateTime.parse("2020-07-11T00:00:00");
  private static final Integer WITHDRAWALS_INTEREST_PENALTY_CODE = 2;
  private static final Integer WITHDRAWALS_INTEREST_PENALTY_DAYS = 30;
  private static final BigDecimal WITHDRAWALS_INTEREST_PENALTY_BALANCE_UPPER_BOUND =
      new BigDecimal("999999999.99");

  private static final ProductInfo.Interest.Tier TIER_A =
      ProductInfo.Interest.Tier.builder()
          .rate(new BigDecimal("0.750"))
          .rangeLow(new BigDecimal("0.00"))
          .rangeHigh(new BigDecimal("14999.99"))
          .build();

  private static final ProductInfo.Interest.Tier TIER_B =
      ProductInfo.Interest.Tier.builder()
          .rate(new BigDecimal("0.850"))
          .rangeLow(new BigDecimal("15000.00"))
          .rangeHigh(new BigDecimal("999999999.99"))
          .build();

  private static final Long ACCOUNT_NUMBER = 1234567890L;
  private static final BigDecimal WITHDRAWAL_AMOUNT = new BigDecimal("123.45");
  private static final BigDecimal PENALTY = new BigDecimal("-1.23");
  private static final BigDecimal PENALTY_POSITIVE = new BigDecimal("1.23");
  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-05-26T13:45:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);
  private static final String FASTER_PAYMENT_TRANSACTION_METHOD = "FPT";

  private WithdrawalInterestPenaltyCalculator testSubject;

  @Mock private AccountAccessValidator accountAccessValidator;

  @Mock private ProductService productService;

  @Mock private AuthenticService authenticService;

  @Mock private WithdrawalInterestPenaltyRepository withdrawalInterestPenaltyRepository;

  @Mock private SavingAccountDetailsService savingAccountDetailsService;

  @BeforeEach
  void setUp() {
    testSubject =
        new WithdrawalInterestPenaltyCalculator(
            accountAccessValidator,
            authenticService,
            productService,
            withdrawalInterestPenaltyRepository,
            CLOCK,
            savingAccountDetailsService);
  }

  @ParameterizedTest
  @CsvSource({
    "0.00,0.750", "0.01,0.750", "14999.98,0.750", "14999.99,0.750",
    "15000.00,0.850", "15000.01,0.850", "999999999.98,0.850", "999999999.99,0.850",
    "-0.01,0.750", // Special case, negative balances are mapped to zero
  })
  void calculateShouldSelectCorrectInterestTier(
      final BigDecimal clearedBalance, final BigDecimal expectedInterestRate) {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final List<ProductInfo.Interest.Tier> interestTiers = Arrays.asList(TIER_A, TIER_B);

    final BigDecimal capitalLedgerBalance = new BigDecimal("1000000000.00"); // Value ignored
    final BigDecimal capitalAvailableBalance = clearedBalance.subtract(MINIMUM_BALANCE);

    final List<AccountBalanceType> balances =
        Arrays.asList(
            buildCapitalLedgerBalance(capitalLedgerBalance),
            buildCapitalAvailableBalance(capitalAvailableBalance));

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER))
        .thenReturn(Collections.singletonList(createSavingAccountDetails()));
    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(buildProductInfo(buildInterestPenalty(), interestTiers));
    when(authenticService.getBalance(ACCOUNT_NUMBER.toString())).thenReturn(balances);

    when(withdrawalInterestPenaltyRepository.calculateWithdrawalInterestPenalty(
            ACCOUNT_NUMBER,
            NOW,
            "0073",
            FASTER_PAYMENT_TRANSACTION_METHOD,
            INTEREST_PERIOD_END_INDICATOR,
            WITHDRAWAL_AMOUNT,
            clearedBalance,
            NOW,
            WITHDRAWALS_INTEREST_PENALTY_CODE,
            expectedInterestRate,
            NOW,
            INTEREST_PERIOD_END_DATE,
            INTEREST_DIVISOR_DAYS,
            START_DATE,
            INTEREST_PREVIOUS_DIVISOR_DAYS,
            WITHDRAWALS_INTEREST_PENALTY_DAYS,
            WITHDRAWALS_INTEREST_PENALTY_BALANCE_UPPER_BOUND))
        .thenReturn(PENALTY);

    final WithdrawalInterestPenalty withdrawalInterestPenalty =
        testSubject.calculate(ACCOUNT_NUMBER.toString(), WITHDRAWAL_AMOUNT, requestMetadata);

    assertThat(withdrawalInterestPenalty, is(new WithdrawalInterestPenalty(PENALTY_POSITIVE)));

    verify(accountAccessValidator)
        .validateOwnAccountAccess(
            ACCOUNT_NUMBER.toString(), requestMetadata, Collections.emptySet(), NOW);
  }

  @Test
  void calculateShouldSelectFirstBalanceIfMultipleMatch() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final BigDecimal expectedBalance = new BigDecimal("1.00");
    final BigDecimal otherBalance = new BigDecimal("2.00");

    final BigDecimal expectedCapitalAvailableBalance = expectedBalance.subtract(MINIMUM_BALANCE);
    final BigDecimal otherCapitalAvailableBalance = otherBalance.subtract(MINIMUM_BALANCE);

    final List<AccountBalanceType> balances =
        Arrays.asList(
            buildCapitalAvailableBalance(expectedCapitalAvailableBalance),
            buildCapitalAvailableBalance(otherCapitalAvailableBalance));

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER))
        .thenReturn(Collections.singletonList(createSavingAccountDetails()));
    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(buildProductInfo(buildInterestPenalty(), Collections.singletonList(TIER_A)));
    when(authenticService.getBalance(ACCOUNT_NUMBER.toString())).thenReturn(balances);

    when(withdrawalInterestPenaltyRepository.calculateWithdrawalInterestPenalty(
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            eq(expectedBalance),
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any()))
        .thenReturn(PENALTY);

    final WithdrawalInterestPenalty withdrawalInterestPenalty =
        testSubject.calculate(ACCOUNT_NUMBER.toString(), WITHDRAWAL_AMOUNT, requestMetadata);

    assertThat(withdrawalInterestPenalty, is(new WithdrawalInterestPenalty(PENALTY_POSITIVE)));

    verify(accountAccessValidator)
        .validateOwnAccountAccess(
            ACCOUNT_NUMBER.toString(), requestMetadata, Collections.emptySet(), NOW);
  }

  @Test
  void calculateShouldSelectFirstInterestTierIfMultipleMatch() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final BigDecimal expectedInterestRate = new BigDecimal("0.750");
    final BigDecimal otherInterestRate = new BigDecimal("0.850");

    final List<ProductInfo.Interest.Tier> interestTiers =
        Arrays.asList(
            ProductInfo.Interest.Tier.builder()
                .rate(expectedInterestRate)
                .rangeLow(new BigDecimal("0.00"))
                .rangeHigh(new BigDecimal("14999.99"))
                .build(),
            ProductInfo.Interest.Tier.builder()
                .rate(otherInterestRate)
                .rangeLow(new BigDecimal("15000.00"))
                .rangeHigh(new BigDecimal("999999999.99"))
                .build());

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER))
        .thenReturn(Collections.singletonList(createSavingAccountDetails()));
    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(buildProductInfo(buildInterestPenalty(), interestTiers));
    when(authenticService.getBalance(ACCOUNT_NUMBER.toString()))
        .thenReturn(
            Collections.singletonList(buildCapitalAvailableBalance(new BigDecimal("1.00"))));

    when(withdrawalInterestPenaltyRepository.calculateWithdrawalInterestPenalty(
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            eq(expectedInterestRate),
            any(),
            any(),
            any(),
            any(),
            any(),
            any(),
            any()))
        .thenReturn(PENALTY);

    final WithdrawalInterestPenalty withdrawalInterestPenalty =
        testSubject.calculate(ACCOUNT_NUMBER.toString(), WITHDRAWAL_AMOUNT, requestMetadata);

    assertThat(withdrawalInterestPenalty, is(new WithdrawalInterestPenalty(PENALTY_POSITIVE)));

    verify(accountAccessValidator)
        .validateOwnAccountAccess(
            ACCOUNT_NUMBER.toString(), requestMetadata, Collections.emptySet(), NOW);
  }

  @Test
  void calculateShouldThrowExceptionWhenBalanceBelowMinimumInterestTier() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final BigDecimal clearedBalance = TIER_B.getRangeLow().subtract(new BigDecimal("0.01"));
    final BigDecimal capitalAvailableBalance = clearedBalance.subtract(MINIMUM_BALANCE);

    final List<AccountBalanceType> balances =
        Collections.singletonList(buildCapitalAvailableBalance(capitalAvailableBalance));

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER))
        .thenReturn(Collections.singletonList(createSavingAccountDetails()));
    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(buildProductInfo(buildInterestPenalty(), Collections.singletonList(TIER_B)));
    when(authenticService.getBalance(ACCOUNT_NUMBER.toString())).thenReturn(balances);

    final IllegalArgumentException exception =
        assertThrows(
            IllegalArgumentException.class,
            () ->
                testSubject.calculate(
                    String.valueOf(ACCOUNT_NUMBER), WITHDRAWAL_AMOUNT, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(
            "Failed to find interest tier for cleared balance 14999.99, "
                + "tiers: [ProductInfo.Interest.Tier(rate=0.850, rangeLow=15000.00, rangeHigh=999999999.99)]"));

    verify(accountAccessValidator)
        .validateOwnAccountAccess(
            ACCOUNT_NUMBER.toString(), requestMetadata, Collections.emptySet(), NOW);

    verifyNoInteractions(withdrawalInterestPenaltyRepository);
  }

  @Test
  void calculateShouldThrowExceptionWhenBalanceAboveMaximumInterestTier() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final BigDecimal clearedBalance = TIER_B.getRangeHigh().add(new BigDecimal("0.01"));
    final BigDecimal capitalAvailableBalance = clearedBalance.subtract(MINIMUM_BALANCE);

    final List<AccountBalanceType> balances =
        Collections.singletonList(buildCapitalAvailableBalance(capitalAvailableBalance));

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER))
        .thenReturn(Collections.singletonList(createSavingAccountDetails()));
    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(buildProductInfo(buildInterestPenalty(), Collections.singletonList(TIER_B)));
    when(authenticService.getBalance(ACCOUNT_NUMBER.toString())).thenReturn(balances);

    final IllegalArgumentException exception =
        assertThrows(
            IllegalArgumentException.class,
            () ->
                testSubject.calculate(
                    String.valueOf(ACCOUNT_NUMBER), WITHDRAWAL_AMOUNT, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(
            "Failed to find interest tier for cleared balance 1000000000.00, "
                + "tiers: [ProductInfo.Interest.Tier(rate=0.850, rangeLow=15000.00, rangeHigh=999999999.99)]"));

    verify(accountAccessValidator)
        .validateOwnAccountAccess(
            ACCOUNT_NUMBER.toString(), requestMetadata, Collections.emptySet(), NOW);

    verifyNoInteractions(withdrawalInterestPenaltyRepository);
  }

  @Test
  void calculateShouldThrowExceptionWhenNoCapitalAvailableBalance() {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final List<AccountBalanceType> balances =
        Collections.singletonList(buildCapitalLedgerBalance(new BigDecimal("1.00")));

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER))
        .thenReturn(Collections.singletonList(createSavingAccountDetails()));
    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(buildProductInfo(buildInterestPenalty(), Collections.singletonList(TIER_A)));
    when(authenticService.getBalance(ACCOUNT_NUMBER.toString())).thenReturn(balances);

    final IllegalArgumentException exception =
        assertThrows(
            IllegalArgumentException.class,
            () ->
                testSubject.calculate(
                    String.valueOf(ACCOUNT_NUMBER), WITHDRAWAL_AMOUNT, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(
            "Failed to find CapitalAvailable for account "
                + ACCOUNT_NUMBER
                + ": [AccountBalanceType(balanceType=CapitalLedger, balanceAmount=1.00)]"));

    verify(accountAccessValidator)
        .validateOwnAccountAccess(
            ACCOUNT_NUMBER.toString(), requestMetadata, Collections.emptySet(), NOW);

    verifyNoInteractions(withdrawalInterestPenaltyRepository);
  }

  @Test
  void calculateShouldThrowExceptionWhenNoInterestPenaltyExists() {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER))
        .thenReturn(Collections.singletonList(createSavingAccountDetails()));
    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(buildProductInfo(null, Collections.singletonList(TIER_A)));

    final AccountResourceNotFoundException exception =
        assertThrows(
            AccountResourceNotFoundException.class,
            () ->
                testSubject.calculate(
                    String.valueOf(ACCOUNT_NUMBER), WITHDRAWAL_AMOUNT, requestMetadata));

    assertThat(
        exception.getMessage(),
        is(
            "No interest penalty for account "
                + ACCOUNT_NUMBER
                + " - productIdentifier: "
                + PRODUCT_IDENTIFIER));

    verify(accountAccessValidator)
        .validateOwnAccountAccess(
            ACCOUNT_NUMBER.toString(), requestMetadata, Collections.emptySet(), NOW);

    verifyNoInteractions(withdrawalInterestPenaltyRepository);
  }

  private static SavingAccountDetails createSavingAccountDetails() {
    return SavingAccountDetails.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .productIdentifier(PRODUCT_IDENTIFIER)
        .build();
  }

  private static ProductInfo buildProductInfo(
      final ProductInfo.Withdrawals.InterestPenalty interestPenalty,
      final List<ProductInfo.Interest.Tier> interestTiers) {
    return ProductInfo.builder()
        .balance(ProductInfo.Balance.builder().min(MINIMUM_BALANCE).build())
        .interest(
            ProductInfo.Interest.builder()
                .divisorDays(INTEREST_DIVISOR_DAYS)
                .periodEndDate(INTEREST_PERIOD_END_DATE)
                .periodEndIndicator(INTEREST_PERIOD_END_INDICATOR)
                .previousPeriodDivisorDays(INTEREST_PREVIOUS_DIVISOR_DAYS)
                .tiers(interestTiers)
                .build())
        .productIdentifier(PRODUCT_IDENTIFIER)
        .startDate(START_DATE)
        .withdrawals(ProductInfo.Withdrawals.builder().interestPenalty(interestPenalty).build())
        .build();
  }

  private static ProductInfo.Withdrawals.InterestPenalty buildInterestPenalty() {
    return ProductInfo.Withdrawals.InterestPenalty.builder()
        .code(WITHDRAWALS_INTEREST_PENALTY_CODE)
        .days(WITHDRAWALS_INTEREST_PENALTY_DAYS)
        .balanceUpperBound(WITHDRAWALS_INTEREST_PENALTY_BALANCE_UPPER_BOUND)
        .build();
  }

  private AccountBalanceType buildBalance(final String type, final BigDecimal balance) {
    return AccountBalanceType.builder().balanceType(type).balanceAmount(balance).build();
  }

  private AccountBalanceType buildCapitalAvailableBalance(final BigDecimal balance) {
    return buildBalance("CapitalAvailable", balance);
  }

  private AccountBalanceType buildCapitalLedgerBalance(final BigDecimal balance) {
    return buildBalance("CapitalLedger", balance);
  }

  private static RequestMetadata buildRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 443);
  }
}
