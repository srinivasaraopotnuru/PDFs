package uk.co.ybs.digital.account.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.model.core.AccountNumber;
import uk.co.ybs.digital.account.model.core.SavingAccount;
import uk.co.ybs.digital.account.model.core.SavingProduct;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("accountProcessorTransactionManager")
public class SavingAccountCoreRepositoryTest {

  private static final long ACCOUNT_NUMBER = 12345678L;
  private static final long PRODUCT_ID = 100;

  @Autowired private SavingAccountCoreRepository testSubject;

  @Autowired private TestEntityManager coreTestEntityManager;

  @Test
  void shouldFindById() {
    setupTestData();
    final SavingAccount savingAccount = buildSavingAccount();
    coreTestEntityManager.persistAndFlush(savingAccount);
    coreTestEntityManager.clear();

    final Optional<SavingAccount> found = testSubject.findById(ACCOUNT_NUMBER);
    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), is(savingAccount));
    assertThat(found.get(), samePropertyValuesAs(savingAccount));
  }

  private void setupTestData() {
    coreTestEntityManager.persistAndFlush(buildProduct());
    coreTestEntityManager.persistAndFlush(buildAccountNumber());
    coreTestEntityManager.clear();
  }

  private SavingProduct buildProduct() {
    return SavingProduct.builder().sysid(PRODUCT_ID).brandCode("YBS").build();
  }

  private SavingAccount buildSavingAccount() {
    return SavingAccount.builder().accountNumber(ACCOUNT_NUMBER).build();
  }

  private AccountNumber buildAccountNumber() {
    return AccountNumber.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .savingProductSysId(PRODUCT_ID)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .build();
  }
}
