package uk.co.ybs.digital.account.service.authentic;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static uk.co.ybs.digital.account.service.authentic.AccountBalanceType.BalanceConstants.TYPE_CAPITAL_AVAILABLE;
import static uk.co.ybs.digital.account.service.authentic.AccountBalanceType.BalanceConstants.TYPE_CAPITAL_LEDGER;
import static uk.co.ybs.digital.account.utils.TestHelper.readClassPathResource;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.xmlunit.builder.DiffBuilder;
import org.xmlunit.diff.Diff;
import uk.co.ybs.digital.account.config.AccountServiceConfig;
import uk.co.ybs.digital.account.config.AuthenticConfig;
import uk.co.ybs.digital.account.utils.ServiceRandomPortInitializer;

@SpringBootTest(
    classes = {AuthenticService.class, AuthenticConfig.class, AccountServiceConfig.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AuthenticServiceTest {

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Error calling authentic service: ";
  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling authentic service";

  private static final String EMPTY_RESPONSE_MESSAGE = "Authentic service returned empty response";

  private static final String ACCOUNT_NUMBER = "6606051920";
  private static final String ACCOUNT_NUMBER_FOR_TRANSACTIONS = "2712893919";

  private static final LocalDateTime START = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-27T11:39:51");

  private static final int AUTHENTIC_RECORD_FROM = 1;
  private static final int AUTHENTIC_RECORD_TO = 100;
  private static final String BAD_REQUEST_CODE = "400 BAD_REQUEST";
  private static final String FORBIDDEN_CODE = "403 FORBIDDEN";

  @Autowired private AuthenticService authenticService;

  @Value("${uk.co.ybs.digital.authentic.banking.port}")
  private int bankingTestPort;

  @Value("${uk.co.ybs.digital.authentic.webauth.port}")
  private int webAuthTestPort;

  private MockWebServer mockAuthenticBankingService;
  private MockWebServer mockAuthenticWebAuthService;

  @BeforeEach
  void setUp() throws IOException {
    mockAuthenticBankingService = new MockWebServer();
    mockAuthenticBankingService.start(bankingTestPort);
    mockAuthenticWebAuthService = new MockWebServer();
    mockAuthenticWebAuthService.start(webAuthTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockAuthenticBankingService.shutdown();
    mockAuthenticWebAuthService.shutdown();
  }

  @Test
  void shouldGetBalanceFromAuthentic() throws Exception {

    mockAuthenticBankingService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader("Content-type", MediaType.APPLICATION_XML_VALUE)
            .setBody(readClassPathResource("api/authentic/getbalance/SuccessResponse.xml")));

    final List<AccountBalanceType> expectedResponse =
        Arrays.asList(
            AccountBalanceType.builder()
                .balanceType(TYPE_CAPITAL_AVAILABLE)
                .balanceAmount(new BigDecimal("200.50"))
                .build(),
            AccountBalanceType.builder()
                .balanceType(TYPE_CAPITAL_LEDGER)
                .balanceAmount(new BigDecimal("-150.20"))
                .build());

    final List<AccountBalanceType> actualResponse = authenticService.getBalance(ACCOUNT_NUMBER);

    assertEquals(expectedResponse, actualResponse);

    final RecordedRequest recordedRequest = mockAuthenticBankingService.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/CommsS"));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.CONTENT_TYPE), is(MediaType.APPLICATION_XML_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_XML_VALUE));

    final String actualRequest = recordedRequest.getBody().readUtf8();
    final String expectedRequest = readClassPathResource("api/authentic/getbalance/Request.xml");

    final Diff requestDiff =
        DiffBuilder.compare(actualRequest)
            .withTest(expectedRequest)
            .withNodeFilter(
                node ->
                    "requestid".equals(node.getNodeName())
                        || "timestamp".equals(node.getNodeName()))
            .ignoreWhitespace()
            .checkForSimilar()
            .build();
    assertFalse(requestDiff.hasDifferences(), requestDiff.toString());
  }

  @Test
  void shouldGetTransactionsFromAuthentic() throws Exception {

    mockAuthenticWebAuthService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader("Content-type", MediaType.APPLICATION_XML_VALUE)
            .setBody(
                readClassPathResource("api/authentic/getListOfTransactions/SuccessResponse.xml")));

    final List<AuthenticTransaction> expectedResponse =
        Collections.singletonList(
            AuthenticTransaction.builder()
                .accountNumber(ACCOUNT_NUMBER_FOR_TRANSACTIONS)
                .transactionDesc("TFR")
                .transactionBookingDateTime(LocalDateTime.parse("2022-01-17T10:43:02"))
                .financialTransactionAmount(new BigDecimal("1.00"))
                .authUid("B000000137")
                .transactionID("1019924280")
                .creditorDebitIndicator("Credit")
                .build());

    final List<AuthenticTransaction> transactions =
        authenticService
            .getTransactions(
                ACCOUNT_NUMBER_FOR_TRANSACTIONS,
                START,
                NOW,
                true,
                false,
                AUTHENTIC_RECORD_FROM,
                AUTHENTIC_RECORD_TO)
            .getTransactionList();

    assertEquals(expectedResponse, transactions);

    final RecordedRequest recordedRequest = mockAuthenticWebAuthService.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/listtxns"));
    assertThat(
        recordedRequest.getHeader(HttpHeaders.CONTENT_TYPE), is(MediaType.APPLICATION_XML_VALUE));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_XML_VALUE));

    final String actualRequest = recordedRequest.getBody().readUtf8();
    final String expectedRequest =
        readClassPathResource("api/authentic/getListOfTransactions/Request.xml");

    final Diff requestDiff =
        DiffBuilder.compare(actualRequest)
            .withTest(expectedRequest)
            .withNodeFilter(node -> "requestid".equals(node.getNodeName()))
            .ignoreWhitespace()
            .checkForSimilar()
            .build();
    assertFalse(requestDiff.hasDifferences(), requestDiff.toString());
  }

  @Test
  void getBalanceShouldThrowAuthenticServiceExceptionWhenConnectionErrorConnectingToAuthentic()
      throws IOException {
    mockAuthenticBankingService.shutdown();
    final AuthenticServiceException exception =
        assertThrows(
            AuthenticServiceException.class, () -> authenticService.getBalance(ACCOUNT_NUMBER));
    assertThat(exception.getMessage(), equalTo(UNEXPECTED_ERROR_MESSAGE));
  }

  @Test
  void getBalanceShouldThrowAccountNotFoundExceptionForAuthenticAccountNotFoundResponse()
      throws IOException {
    mockAuthenticBankingService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(readClassPathResource("api/authentic/getbalance/AccNotFoundResponse.xml")));

    final AccountNotFoundException exception =
        Assertions.assertThrows(
            AccountNotFoundException.class, () -> authenticService.getBalance(ACCOUNT_NUMBER));
    assertThat(exception.getMessage(), is("Authentic Account not found"));
    assertThat(exception.getCause(), not(instanceOf(AuthenticServiceException.class)));
  }

  @Test
  void getBalanceShouldThrowAccountClosedExceptionForAuthenticAccountClosedResponse()
      throws IOException {
    mockAuthenticBankingService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(readClassPathResource("api/authentic/getbalance/AccClosedResponse.xml")));

    final AccountClosedException exception =
        Assertions.assertThrows(
            AccountClosedException.class, () -> authenticService.getBalance(ACCOUNT_NUMBER));
    assertThat(exception.getMessage(), is("Authentic Account is closed"));
    assertThat(exception.getCause(), not(instanceOf(AuthenticServiceException.class)));
  }

  @Test
  void getBalanceShouldThrowAuthenticServiceExceptionForMissingBalanceSign() throws IOException {
    mockAuthenticBankingService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(readClassPathResource("api/authentic/getbalance/MissingSignResponse.xml")));

    final AuthenticServiceException exception =
        Assertions.assertThrows(
            AuthenticServiceException.class, () -> authenticService.getBalance(ACCOUNT_NUMBER));
    assertThat(exception.getMessage(), is("Authentic value format must end with a sign"));
    assertThat(exception.getCause(), not(instanceOf(AuthenticServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("authenticServiceBalanceErrorResponses")
  void getBalanceShouldThrowAuthenticServiceExceptionsForErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockAuthenticBankingService.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuthenticServiceException exception =
        Assertions.assertThrows(
            AuthenticServiceException.class, () -> authenticService.getBalance(ACCOUNT_NUMBER));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuthenticServiceException.class)));
  }

  @Test
  void getTransactionsShouldThrowAuthenticServiceExceptionWhenConnectionErrorConnectingToAuthentic()
      throws IOException {
    mockAuthenticWebAuthService.shutdown();
    final AuthenticServiceException exception =
        assertThrows(
            AuthenticServiceException.class,
            () ->
                authenticService.getTransactions(
                    ACCOUNT_NUMBER_FOR_TRANSACTIONS,
                    START,
                    NOW,
                    true,
                    false,
                    AUTHENTIC_RECORD_FROM,
                    AUTHENTIC_RECORD_TO));
    assertThat(exception.getMessage(), equalTo(UNEXPECTED_ERROR_MESSAGE));
  }

  @Test
  void getTransactionsShouldThrowAccountNotFoundExceptionForAuthenticAccountNotFoundResponse()
      throws IOException {
    mockAuthenticWebAuthService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(
                readClassPathResource(
                    "api/authentic/getListOfTransactions/AccNotFoundResponse.xml")));

    final AccountNotFoundException exception =
        Assertions.assertThrows(
            AccountNotFoundException.class,
            () ->
                authenticService.getTransactions(
                    ACCOUNT_NUMBER_FOR_TRANSACTIONS,
                    START,
                    NOW,
                    true,
                    false,
                    AUTHENTIC_RECORD_FROM,
                    AUTHENTIC_RECORD_TO));
    assertThat(
        exception.getMessage(), is("Account number not found on Authentic, response code 1"));
    assertThat(exception.getCause(), not(instanceOf(AuthenticServiceException.class)));
  }

  @Test
  void getTransactionsShouldThrowAuthenticServiceExceptionForMissingBalanceSign()
      throws IOException {
    mockAuthenticWebAuthService.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(
                readClassPathResource(
                    "api/authentic/getListOfTransactions/MissingSignResponse.xml")));

    final AuthenticServiceException exception =
        Assertions.assertThrows(
            AuthenticServiceException.class,
            () ->
                authenticService.getTransactions(
                    ACCOUNT_NUMBER_FOR_TRANSACTIONS,
                    START,
                    NOW,
                    true,
                    false,
                    AUTHENTIC_RECORD_FROM,
                    AUTHENTIC_RECORD_TO));
    assertThat(exception.getMessage(), is("Authentic value format must end with a sign"));
    assertThat(exception.getCause(), not(instanceOf(AuthenticServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("authenticServiceTransactionsErrorResponses")
  void getTransactionsShouldThrowAuthenticServiceExceptionsForErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockAuthenticWebAuthService.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuthenticServiceException exception =
        Assertions.assertThrows(
            AuthenticServiceException.class,
            () ->
                authenticService.getTransactions(
                    ACCOUNT_NUMBER_FOR_TRANSACTIONS,
                    START,
                    NOW,
                    true,
                    false,
                    AUTHENTIC_RECORD_FROM,
                    AUTHENTIC_RECORD_TO));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuthenticServiceException.class)));
  }

  private static Stream<Arguments> authenticServiceBalanceErrorResponses() throws IOException {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_XML,
            "",
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FORBIDDEN_CODE))),
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_XML,
            readClassPathResource("api/authentic/errors/GeneralErr.xml"), // NOPMD
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FORBIDDEN_CODE))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_XML,
            readClassPathResource("api/authentic/errors/GeneralErr.xml"), // NOPMD
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + BAD_REQUEST_CODE))),
        Arguments.of(
            HttpStatus.OK,
            MediaType.APPLICATION_XML,
            readClassPathResource("api/authentic/getbalance/EmptyResponse.xml"),
            is(EMPTY_RESPONSE_MESSAGE)),
        Arguments.of(
            HttpStatus.OK,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/authentic/errors/UnexpectedErr.xml"),
            is(UNEXPECTED_ERROR_MESSAGE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_XML,
            "",
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + BAD_REQUEST_CODE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_XML,
            readClassPathResource("api/auditService/response/textResponse.txt"), // NOPMD
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + BAD_REQUEST_CODE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + BAD_REQUEST_CODE)));
  }

  private static Stream<Arguments> authenticServiceTransactionsErrorResponses() throws IOException {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_XML,
            "",
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FORBIDDEN_CODE))),
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_XML,
            readClassPathResource("api/authentic/errors/GeneralErr.xml"),
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FORBIDDEN_CODE))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_XML,
            readClassPathResource("api/authentic/errors/GeneralErr.xml"),
            allOf(startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + BAD_REQUEST_CODE))),
        Arguments.of(
            HttpStatus.OK,
            MediaType.APPLICATION_XML,
            readClassPathResource("api/authentic/getListOfTransactions/EmptyResponse.xml"),
            is(EMPTY_RESPONSE_MESSAGE)),
        Arguments.of(
            HttpStatus.OK,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/authentic/errors/UnexpectedErr.xml"),
            is(UNEXPECTED_ERROR_MESSAGE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_XML,
            "",
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + BAD_REQUEST_CODE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_XML,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + BAD_REQUEST_CODE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + BAD_REQUEST_CODE)));
  }
}
