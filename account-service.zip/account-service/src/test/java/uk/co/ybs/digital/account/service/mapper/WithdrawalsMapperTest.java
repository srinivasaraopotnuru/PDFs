package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyBoolean;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.Restriction;
import uk.co.ybs.digital.account.web.dto.RestrictionCategory;
import uk.co.ybs.digital.account.web.dto.WithdrawalLimit;
import uk.co.ybs.digital.account.web.dto.Withdrawals;
import uk.co.ybs.digital.account.web.dto.WithdrawalsSummary;

@ExtendWith(MockitoExtension.class)
class WithdrawalsMapperTest {
  private static final String INTERNAL_ACCOUNT_NUMBER = "1234567890";
  private static final Long PRODUCT_SYS_ID = 2000L;
  private static final String RESTRICTION_RULE_CODE_WEBWDL = "WEBWDL";

  private static final String RESTRICTION_TYPE_CODE = "RESTYP";
  private static final String RESTRICTION_RULE_CODE_OTHER = "OTHER";
  private static final String RESTRICTION_RESTYP_WEBTXT = "RESTYP_WEBTXT";

  private WithdrawalsMapper testSubject;

  @Mock private WithdrawalLimitMapper withdrawalLimitMapper;

  @Mock private WithdrawalsPermittedOverApiMapper withdrawalsPermittedOverApiMapper;

  @Mock private RestrictionMapper restrictionMapper;

  @BeforeEach
  void setUp() {
    testSubject =
        new WithdrawalsMapper(
            withdrawalLimitMapper, withdrawalsPermittedOverApiMapper, restrictionMapper);
  }

  @Test
  void shouldMapWithdrawals() {
    final ProductInfo productInfo = productInfo();
    final boolean productMigrationInProgress = false;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final Set<String> activityGroupCodes =
        Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
    final boolean accountClosed = false;
    final SavingAccountAnnualWithdrawalLimit limitEntity =
        createSavingAccountAnnualWithdrawalLimit();

    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final WithdrawalLimit mappedWithdrawalLimit = withdrawalLimit();
    when(withdrawalLimitMapper.mapWithdrawalLimit(limitEntity)).thenReturn(mappedWithdrawalLimit);
    final boolean permittedOverApi = true;
    when(withdrawalsPermittedOverApiMapper.withdrawalPermittedOverApi(
            INTERNAL_ACCOUNT_NUMBER,
            productAllowsWithdrawals,
            productMigrationInProgress,
            false,
            activityGroupCodes,
            mappedWithdrawalLimit,
            accountClosed))
        .thenReturn(permittedOverApi);

    final Withdrawals mapped =
        testSubject.map(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroupCodes,
            limitEntity,
            accountClosed);

    final Withdrawals expected =
        Withdrawals.builder()
            .permittedOverApi(permittedOverApi)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals, productMigrationInProgress, false, accountClosed))
            .limit(mappedWithdrawalLimit)
            .build();
    assertThat(mapped, is(expected));
  }

  @Test
  void shouldMapWithdrawalsWhenSavingAccountAnnualWithdrawalLimitNotSet() {
    final ProductInfo productInfo = productInfo();
    final boolean productMigrationInProgress = false;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final Set<String> activityGroupCodes =
        Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
    final boolean accountClosed = false;
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final boolean permittedOverApi = true;
    when(withdrawalsPermittedOverApiMapper.withdrawalPermittedOverApi(
            INTERNAL_ACCOUNT_NUMBER,
            productAllowsWithdrawals,
            productMigrationInProgress,
            false,
            activityGroupCodes,
            null,
            accountClosed))
        .thenReturn(permittedOverApi);

    final Withdrawals mapped =
        testSubject.map(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroupCodes,
            null,
            accountClosed);

    final Withdrawals expected =
        Withdrawals.builder()
            .permittedOverApi(permittedOverApi)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals, productMigrationInProgress, false, accountClosed))
            .limit(null)
            .build();

    assertThat(mapped, is(expected));
    verify(withdrawalLimitMapper, never()).mapWithdrawalLimit(any());
  }

  @Test
  void shouldMapWithdrawalsWhenSavingAccountAnnualWithdrawalLimitHasNoStartDate() {
    final ProductInfo productInfo = productInfo();
    final boolean productMigrationInProgress = false;
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final Set<String> activityGroupCodes =
        Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
    final boolean accountClosed = false;
    final SavingAccountAnnualWithdrawalLimit limitEntity =
        createSavingAccountAnnualWithdrawalLimit().toBuilder().yearStart(null).build();

    final Withdrawals mapped =
        testSubject.map(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroupCodes,
            limitEntity,
            accountClosed);

    final Withdrawals expected =
        Withdrawals.builder()
            .permittedOverApi(false)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals, productMigrationInProgress, false, accountClosed))
            .limit(null)
            .build();

    assertThat(mapped, is(expected));
    verify(withdrawalLimitMapper, never()).mapWithdrawalLimit(any());
    verify(withdrawalsPermittedOverApiMapper, never())
        .withdrawalPermittedOverApi(
            anyString(), anyBoolean(), anyBoolean(), anyBoolean(), any(), any(), anyBoolean());
  }

  @Test
  void shouldMapWithdrawalsWithRestrictionsAndInterestPenalty() {
    final ProductInfo productInfo =
        productInfo()
            .toBuilder()
            .withdrawals(
                ProductInfo.Withdrawals.builder()
                    .interestPenalty(
                        ProductInfo.Withdrawals.InterestPenalty.builder()
                            .code(2)
                            .days(30)
                            .balanceUpperBound(new BigDecimal("999999999.99"))
                            .build())
                    .build())
            .build();
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final boolean productMigrationInProgress = false;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final Set<String> activityGroupCodes =
        Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
    final boolean accountClosed = false;
    final SavingAccountAnnualWithdrawalLimit limitEntity =
        createSavingAccountAnnualWithdrawalLimit();

    final WithdrawalLimit mappedWithdrawalLimit = withdrawalLimit();
    when(withdrawalLimitMapper.mapWithdrawalLimit(limitEntity)).thenReturn(mappedWithdrawalLimit);

    final boolean permittedOverApi = true;
    when(withdrawalsPermittedOverApiMapper.withdrawalPermittedOverApi(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo.getWithdrawals().isPermittedOverWeb(),
            productMigrationInProgress,
            false,
            activityGroupCodes,
            mappedWithdrawalLimit,
            accountClosed))
        .thenReturn(permittedOverApi);

    final List<Restriction> restrictions = new ArrayList<>();
    restrictions.add(restriction(RestrictionCategory.WITHDRAWAL_DEFAULT));

    when(restrictionMapper.map(accountWarningRestrictionRules, RESTRICTION_RULE_CODE_WEBWDL))
        .thenReturn(restrictions);

    final Withdrawals mapped =
        testSubject.map(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroupCodes,
            limitEntity,
            accountClosed);

    restrictions.add(restriction(RestrictionCategory.WITHDRAWAL_INTEREST_PENALTY));
    final Withdrawals expected =
        Withdrawals.builder()
            .permittedOverApi(permittedOverApi)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals, productMigrationInProgress, false, accountClosed))
            .limit(mappedWithdrawalLimit)
            .restrictions(restrictions)
            .interestPenalty(Withdrawals.InterestPenalty.builder().days(30).build())
            .build();
    assertThat(mapped, is(expected));
  }

  @Test
  void shouldMapAccountSummaryWithdrawals() {
    final ProductInfo productInfo = productInfo();
    final boolean productMigrationInProgress = false;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final Set<String> activityGroupCodes =
        Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
    final boolean accountClosed = false;
    final SavingAccountAnnualWithdrawalLimit limitEntity =
        createSavingAccountAnnualWithdrawalLimit();
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final WithdrawalLimit mappedWithdrawalLimit = withdrawalLimit();
    when(withdrawalLimitMapper.mapWithdrawalLimit(limitEntity)).thenReturn(mappedWithdrawalLimit);

    final boolean permittedOverApi = true;
    when(withdrawalsPermittedOverApiMapper.withdrawalPermittedOverApi(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo.getWithdrawals().isPermittedOverWeb(),
            productMigrationInProgress,
            false,
            activityGroupCodes,
            mappedWithdrawalLimit,
            accountClosed))
        .thenReturn(permittedOverApi);

    final WithdrawalsSummary mapped =
        testSubject.mapSummary(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroupCodes,
            limitEntity,
            accountClosed);

    final WithdrawalsSummary expected =
        WithdrawalsSummary.builder()
            .permittedOverApi(permittedOverApi)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals, productMigrationInProgress, false, accountClosed))
            .build();
    assertThat(mapped, is(expected));
  }

  @Test
  void shouldMapAccountSummaryWithdrawalsWhenSavingAccountAnnualWithdrawalLimitNotSet() {
    final ProductInfo productInfo = productInfo();
    final boolean productMigrationInProgress = false;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final Set<String> activityGroupCodes =
        Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
    final boolean accountClosed = false;
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final boolean permittedOverApi = true;
    when(withdrawalsPermittedOverApiMapper.withdrawalPermittedOverApi(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo.getWithdrawals().isPermittedOverWeb(),
            productMigrationInProgress,
            false,
            activityGroupCodes,
            null,
            accountClosed))
        .thenReturn(permittedOverApi);

    final WithdrawalsSummary mapped =
        testSubject.mapSummary(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroupCodes,
            null,
            accountClosed);

    final WithdrawalsSummary expected =
        WithdrawalsSummary.builder()
            .permittedOverApi(permittedOverApi)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals, productMigrationInProgress, false, accountClosed))
            .build();

    assertThat(mapped, is(expected));
    verify(withdrawalLimitMapper, never()).mapWithdrawalLimit(any());
  }

  @Test
  void shouldMapAccountSummaryWithdrawalsWhenSavingAccountAnnualWithdrawalLimitHasNoStartDate() {
    final ProductInfo productInfo = productInfo();
    final boolean productMigrationInProgress = false;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();
    final Set<String> activityGroupCodes =
        Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
    final boolean accountClosed = false;
    final SavingAccountAnnualWithdrawalLimit limitEntity =
        createSavingAccountAnnualWithdrawalLimit().toBuilder().yearStart(null).build();
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    final WithdrawalsSummary mapped =
        testSubject.mapSummary(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroupCodes,
            limitEntity,
            accountClosed);

    final WithdrawalsSummary expected =
        WithdrawalsSummary.builder()
            .permittedOverApi(false)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals, productMigrationInProgress, false, accountClosed))
            .build();

    assertThat(mapped, is(expected));
    verify(withdrawalLimitMapper, never()).mapWithdrawalLimit(any());
    verify(withdrawalsPermittedOverApiMapper, never())
        .withdrawalPermittedOverApi(
            anyString(), anyBoolean(), anyBoolean(), anyBoolean(), any(), any(), anyBoolean());
  }

  @ParameterizedTest
  @MethodSource("withdrawalWithAccountRestrictionsArgs")
  void shouldMapWithdrawalsSummaryWhenAccountWarningRestrictionRulesArePresent(
      final String label,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final boolean permittedOverApi,
      final boolean hasAccountWarning) {
    final ProductInfo productInfo = productInfo();
    final boolean productMigrationInProgress = false;

    final Set<String> activityGroupCodes =
        Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
    final boolean accountClosed = false;
    final SavingAccountAnnualWithdrawalLimit limitEntity =
        createSavingAccountAnnualWithdrawalLimit();
    final boolean productAllowsWithdrawals = productInfo.getWithdrawals().isPermittedOverWeb();
    when(withdrawalsPermittedOverApiMapper.withdrawalPermittedOverApi(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo.getWithdrawals().isPermittedOverWeb(),
            productMigrationInProgress,
            hasAccountWarning,
            activityGroupCodes,
            null,
            accountClosed))
        .thenReturn(permittedOverApi);
    final WithdrawalsSummary mapped =
        testSubject.mapSummary(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroupCodes,
            limitEntity,
            accountClosed);

    final WithdrawalsSummary expected =
        WithdrawalsSummary.builder()
            .permittedOverApi(permittedOverApi)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals,
                    productMigrationInProgress,
                    hasAccountWarning,
                    accountClosed))
            .build();

    assertThat(mapped, is(expected));
  }

  private static Stream<Arguments> withdrawalWithAccountRestrictionsArgs() {
    return Stream.of(
        Arguments.of(
            "permitted - warning restriction rule does not prevent withdrawals",
            Collections.singletonList(
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE,
                    RESTRICTION_RULE_CODE_OTHER,
                    RESTRICTION_RESTYP_WEBTXT)),
            true,
            false),
        Arguments.of(
            "not permitted - warning restriction rule prevents withdrawals",
            Collections.singletonList(
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE,
                    RESTRICTION_RULE_CODE_WEBWDL,
                    RESTRICTION_RESTYP_WEBTXT)),
            false,
            true));
  }

  private static ProductInfo productInfo() {
    return ProductInfo.builder()
        .withdrawals(ProductInfo.Withdrawals.builder().permittedOverWeb(true).build())
        .build();
  }

  private static WithdrawalLimit withdrawalLimit() {
    return WithdrawalLimit.builder().permitted(5).available(2).build();
  }

  private static SavingAccountAnnualWithdrawalLimit createSavingAccountAnnualWithdrawalLimit() {
    return SavingAccountAnnualWithdrawalLimit.builder()
        .sysId(1L)
        .accountNumber(
            AccountNumber.builder()
                .accountNumber(Long.parseLong(INTERNAL_ACCOUNT_NUMBER))
                .tableId(AccountNumber.TABLE_ID_SAVACC)
                .savingProductSysId(PRODUCT_SYS_ID)
                .build())
        .savingProductSysId(PRODUCT_SYS_ID)
        .withdrawalsAllowed(5)
        .withdrawalsMade(1)
        .yearStart(LocalDate.now())
        .build();
  }

  private static List<AccountWarningRestrictionRule> createAccountWarningRestrictionRules() {
    return Collections.singletonList(
        new AccountWarningRestrictionRule(1L, "RESTYP", "RULE", "RULE_WEBTXT"));
  }

  private static Restriction restriction(final RestrictionCategory restrictionCategory) {
    return Restriction.builder().code(restrictionCategory).build();
  }
}
