package uk.co.ybs.digital.account.integration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;
import uk.co.ybs.digital.account.config.TestClockConfig;
import uk.co.ybs.digital.account.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.account.integration.IntegrationTestConfig;
import uk.co.ybs.digital.account.integration.IntegrationTestJwtFactory;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactions;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Operation;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Status;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.account.repository.adgcore.SoaSavingsAccountListException;
import uk.co.ybs.digital.account.repository.adgcore.WithdrawalInterestPenaltyRepository;
import uk.co.ybs.digital.account.service.SavingAccountDetailsListService;
import uk.co.ybs.digital.account.service.SavingAccountDetailsService;
import uk.co.ybs.digital.account.service.SavingAccountTransactionsService;
import uk.co.ybs.digital.account.service.TransactionService;
import uk.co.ybs.digital.account.service.mapper.TransactionInterestMapper;
import uk.co.ybs.digital.account.utils.AccountAccessRequiredEntities;
import uk.co.ybs.digital.account.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.ErrorResponse;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.AccountWarningSummary;
import uk.co.ybs.digital.account.web.dto.AccountWarningsResponse;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.TransactionDates;
import uk.co.ybs.digital.account.web.dto.Warning;
import uk.co.ybs.digital.account.web.dto.WarningCode;
import uk.co.ybs.digital.account.web.dto.WithdrawalInterestPenalty;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class, TestClockConfig.class},
    properties = "spring.main.allow-bean-definition-overriding=true")
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AccountServiceIT extends AccountServiceITBase {

  private static final String GMT = "GMT";
  private static final String AUTHENTIC_TRANSACTION_RESPONSE_2 =
      "/it/AuthenticTransactionsResponse#2.xml";

  @LocalServerPort private int port;

  @Value("classpath:it/productInfoPage.json")
  private Resource productInfoPageResponse;

  @Value("classpath:it/isaProductInfoPage.json")
  private Resource isaProductInfoPageResponse;

  @Autowired private WebTestClient signingWebClientPublic;

  @Autowired private WebTestClient signingWebClientPrivate;

  @Autowired private WebTestClient nonSigningWebClient;

  @Autowired private Clock clock;

  /*
   * See comment in WithdrawalInterestPenaltyRepository on why a mock is being used
   */
  @MockBean private WithdrawalInterestPenaltyRepository withdrawalInterestPenaltyRepository;
  @MockBean private SavingAccountDetailsService savingAccountDetailsService;
  @MockBean private SavingAccountDetailsListService savingAccountDetailsListService;
  @MockBean private SavingAccountTransactionsService savingAccountTransactionsService;
  @MockBean private TransactionInterestMapper transactionInterestMapper;

  private static Stream<Arguments> getAccountsGroupArguments() {
    return Stream.of(
        Arguments.of(false, false, false, WITHDRAWAL_LIMIT_NOT_REACHED, true, true, false),
        Arguments.of(false, false, false, WITHDRAWAL_LIMIT, true, false, false),
        Arguments.of(false, true, false, WITHDRAWAL_LIMIT_NOT_REACHED, false, false, false),
        Arguments.of(false, false, true, WITHDRAWAL_LIMIT_NOT_REACHED, false, false, true),
        Arguments.of(true, false, false, WITHDRAWAL_LIMIT_NOT_REACHED, true, true, false),
        Arguments.of(true, false, false, WITHDRAWAL_LIMIT, true, false, false),
        Arguments.of(true, true, false, WITHDRAWAL_LIMIT_NOT_REACHED, false, false, false),
        Arguments.of(true, false, true, WITHDRAWAL_LIMIT_NOT_REACHED, false, false, true));
  }

  private static Stream<Arguments> pathsForInvalidRequestSigningKey() {
    return Stream.of(
        Arguments.of(BASE_PATH_PRIVATE, ACCOUNT_WITHDRAWAL_INTEREST_PENALTY),
        Arguments.of(BASE_PATH_PUBLIC, ACCOUNT_TRANSACTIONS_PATH),
        Arguments.of(BASE_PATH_PRIVATE, ACCOUNT_GROUP_PATH),
        Arguments.of(BASE_PATH_PUBLIC, ACCOUNT_GROUP_PATH),
        Arguments.of(BASE_PATH_PUBLIC, ACCOUNTS_PATH),
        Arguments.of(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH),
        Arguments.of(BASE_PATH_PRIVATE, ACCOUNT_DETAIL_PATH),
        Arguments.of(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH));
  }

  private static Stream<Arguments> requestPathsAndInvalidScopes() {
    return Stream.of(
        Arguments.of(HttpMethod.GET, BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, null, OTHER_SCOPE),
        Arguments.of(HttpMethod.GET, BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, null, OTHER_SCOPE),
        Arguments.of(
            HttpMethod.GET,
            BASE_PATH_PRIVATE,
            RECENT_SAVINGS_ACCOUNTS_PATH,
            "?partyId=123456",
            OTHER_SCOPE));
  }

  @ParameterizedTest
  @MethodSource("getAccountsGroupArguments")
  @SuppressWarnings("PMD.ExcessiveParameterList") // NOPMD
  void getAccountsByGroupShouldReturnGroupedAccountListResponseWhenRequestIsValid(
      final boolean usePrivate,
      final boolean isProductMigrationInProgress,
      final boolean accountRestrictionsExist,
      final int withdrawalsMade,
      final boolean expectedDepositsPermitted,
      final boolean expectedWithdrawalsPermitted,
      final boolean expectedAmendmentRestriction)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final long account1Number = 2372146519L;
    final long account2Number = 1234567890L;
    final long account3Number = 2514552619L;

    stubGetSavingsAccountList(savingAccountDetailsListService, savingAccountDetailsService);
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#2.xml"); // NOPMD
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#1.xml"); // NOPMD
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml"); // NOPMD

    final SavingProduct savingProduct1 = setUpSavingProduct(6001L);
    final SavingProduct savingProduct2 = setUpSavingProduct(6002L);
    final SavingProduct savingProduct3 = setUpSavingProduct(6003L);
    final AccountNumber accountNumber1 = setUpAccountNumber(account1Number, savingProduct1);
    final AccountNumber accountNumber2 = setUpAccountNumber(account2Number, savingProduct2);
    final AccountNumber accountNumber3 = setUpAccountNumber(account3Number, savingProduct3);
    setupSavingAccount(
        account1Number,
        ACCOUNT1_OPENED_DATE_TIME,
        LocalDateTime.now(clock).minusDays(1),
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setupSavingAccount(
        account2Number,
        ACCOUNT2_OPENED_DATE_TIME,
        null,
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setupSavingAccount(
        account3Number,
        ACCOUNT2_OPENED_DATE_TIME,
        null,
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setUpAnnualWithdrawalLimits(1L, withdrawalsMade, accountNumber1, savingProduct1);
    setUpAnnualWithdrawalLimits(2L, withdrawalsMade, accountNumber2, savingProduct2);
    setUpAnnualWithdrawalLimits(3L, withdrawalsMade, accountNumber3, savingProduct3);
    setUpAispAndPispActivityPlayers(account1Number, account2Number, account3Number);
    if (isProductMigrationInProgress) {
      setUpProductMigrationInProgress(account1Number);
      setUpProductMigrationInProgress(account2Number);
      setUpProductMigrationInProgress(account3Number);
    }
    if (accountRestrictionsExist) {
      final RestrictionType restrictionType = setUpRestrictionType(RTYPE, 1001L, 2001L, 2002L);
      setupAccountWarning(1L, accountNumber1, restrictionType);
      setupAccountWarning(2L, accountNumber2, restrictionType);
      setupAccountWarning(3L, accountNumber3, restrictionType);
    }
    stubMockProductServiceResponse(productInfoPageResponse);
    stubMockAuditServiceResponse();

    final boolean expectedProductAllowsDepositOrWithdrawals = true;
    final boolean expectedAccountClosed = false;

    if (usePrivate) {
      signingWebClientPrivate
          .get()
          .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(
              createGroupedAccountListResponse(
                  eggSavProduct(),
                  expectedDepositsPermitted,
                  expectedWithdrawalsPermitted,
                  expectedAmendmentRestriction,
                  expectedProductAllowsDepositOrWithdrawals,
                  isProductMigrationInProgress,
                  expectedAccountClosed,
                  accountRestrictionsExist));

      assertProductServiceCall(
          requestId,
          jwt,
          "/product/private/product?productIdentifiers=EGG302A&page=0&size=1"); // NOPMD
    } else {
      signingWebClientPublic
          .get()
          .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(
              createGroupedAccountListResponse(
                  eggSavProduct(),
                  expectedDepositsPermitted,
                  expectedWithdrawalsPermitted,
                  expectedAmendmentRestriction,
                  expectedProductAllowsDepositOrWithdrawals,
                  isProductMigrationInProgress,
                  expectedAccountClosed,
                  accountRestrictionsExist));

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
      assertAuditAccountList(requestId, jwt);
    }
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void getAccountsByGroupShouldFilterAccountsWithoutAnAispRelationship(final boolean usePrivate)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final long account1Number = 2372146519L;
    final long account2Number = 1234567890L;
    final long account3Number = 2514552619L;

    stubGetSavingsAccountList(savingAccountDetailsListService, savingAccountDetailsService);

    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#1.xml");

    final SavingProduct savingProduct1 = setUpSavingProduct(6001L);
    final SavingProduct savingProduct2 = setUpSavingProduct(6002L);
    final SavingProduct savingProduct3 = setUpSavingProduct(6003L);

    setUpAccountNumber(account1Number, savingProduct1);
    setUpAccountNumber(account2Number, savingProduct2);
    setUpAccountNumber(account3Number, savingProduct3);
    setupSavingAccount(
        account1Number,
        ACCOUNT1_OPENED_DATE_TIME,
        LocalDateTime.now(clock).minusDays(1),
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setupSavingAccount(
        account2Number,
        ACCOUNT1_OPENED_DATE_TIME,
        null,
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setupSavingAccount(
        account3Number,
        ACCOUNT1_OPENED_DATE_TIME,
        null,
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setUpAispAndPispActivityPlayers(account1Number); // Just account 1
    stubMockProductServiceResponse(productInfoPageResponse);
    stubMockAuditServiceResponse();

    final GroupedAccountListResponse expectedResponse =
        GroupedAccountListResponse.builder()
            .other(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            createGroupedAccountListResponseAccount1(
                                eggSavProduct(), true, true, false)))
                    .balances(
                        Arrays.asList(
                            Balance.builder()
                                .type(INTERIM_AVAILABLE)
                                .amount(new BigDecimal("200.50")) // NOPMD
                                .build(),
                            Balance.builder()
                                .type(INTERIM_BOOKED)
                                .amount(new BigDecimal("150.20")) // NOPMD
                                .build()))
                    .build())
            .build();

    if (usePrivate) {
      signingWebClientPrivate
          .get()
          .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(expectedResponse);

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
    } else {
      signingWebClientPublic
          .get()
          .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(expectedResponse);

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
      assertAuditAccountList(requestId, jwt);
    }
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void getAccountsByGroupsWithClosedAccounts(final boolean usePrivate)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final long account1Number = 2372146519L;
    final long account2Number = 1234567890L;
    final long account3Number = 2514552619L;

    stubGetSavingsAccountListWithClosedAccount(
        savingAccountDetailsListService, savingAccountDetailsService);
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#1.xml");

    final SavingProduct savingProduct1 = setUpSavingProduct(6001L);
    final SavingProduct savingProduct2 = setUpSavingProduct(6002L);

    setUpAccountNumber(account1Number, savingProduct1);
    setUpAccountNumber(account2Number, savingProduct2);
    setUpAccountNumber(account3Number, savingProduct2);

    setUpAispAndPispActivityPlayers(account1Number, account2Number);
    setupSavingAccount(
        account1Number,
        ACCOUNT1_OPENED_DATE_TIME,
        null,
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setupSavingAccount(
        account3Number,
        ACCOUNT2_OPENED_DATE_TIME,
        null,
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setupSavingAccount(
        account2Number,
        ACCOUNT2_OPENED_DATE_TIME,
        LocalDateTime.now(clock).minusDays(1),
        new BigDecimal("300.76"),
        new BigDecimal("299.41"));
    stubMockProductServiceResponse(productInfoPageResponse);
    stubMockAuditServiceResponse();

    final GroupedAccountListResponse expectedResponse =
        GroupedAccountListResponse.builder()
            .other(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            createGroupedAccountListResponseAccount1(
                                eggSavProduct(), true, true, false)))
                    .balances(
                        Arrays.asList(
                            Balance.builder()
                                .type(INTERIM_AVAILABLE)
                                .amount(new BigDecimal("200.50")) // NOPMD
                                .build(),
                            Balance.builder()
                                .type(INTERIM_BOOKED)
                                .amount(new BigDecimal("150.20")) // NOPMD
                                .build()))
                    .build())
            .closed(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            createGroupedAccountListResponseAccount2(
                                eggSavProduct(), false, false, false, true, false, true, false)))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .type(INTERIM_BOOKED)
                                .amount(new BigDecimal("299.41"))
                                .build()))
                    .build())
            .build();

    if (usePrivate) {
      signingWebClientPrivate
          .get()
          .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_GROUP_PATH, "?showClosedAccounts=true", port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(expectedResponse);

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
    } else {
      signingWebClientPublic
          .get()
          .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_GROUP_PATH, "?showClosedAccounts=true", port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(expectedResponse);

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
      assertAuditAccountList(requestId, jwt);
    }
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void getAccountsByGroupShouldFilterAccountsWhichDontExistInAdgCore(final boolean usePrivate)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final long account1Number = 2372146519L;

    stubGetSavingsAccountList(savingAccountDetailsListService, savingAccountDetailsService);
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#1.xml");

    final SavingProduct savingProduct1 = setUpSavingProduct(6001L);
    setUpAccountNumber(account1Number, savingProduct1);
    setUpAispAndPispActivityPlayers(account1Number);
    setupSavingAccount(
        account1Number,
        ACCOUNT1_OPENED_DATE_TIME,
        LocalDateTime.now(clock).minusDays(1),
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    stubMockProductServiceResponse(productInfoPageResponse);
    stubMockAuditServiceResponse();

    final GroupedAccountListResponse expectedResponse =
        GroupedAccountListResponse.builder()
            .other(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            createGroupedAccountListResponseAccount1(
                                eggSavProduct(), true, true, false)))
                    .balances(
                        Arrays.asList(
                            Balance.builder()
                                .type(INTERIM_AVAILABLE)
                                .amount(new BigDecimal("200.50")) // NOPMD
                                .build(),
                            Balance.builder()
                                .type(INTERIM_BOOKED)
                                .amount(new BigDecimal("150.20")) // NOPMD
                                .build()))
                    .build())
            .build();

    if (usePrivate) {
      signingWebClientPrivate
          .get()
          .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(expectedResponse);

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
    } else {
      signingWebClientPublic
          .get()
          .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(expectedResponse);

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
      assertAuditAccountList(requestId, jwt);
    }
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void getAccountsByGroupShouldReturnGroupedAccountListResponseWhenIsaPendingDeclaration(
      final boolean usePrivate) throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final LocalDateTime today = LocalDateTime.now(clock);

    final long account1Number = 2372146519L;
    final long account2Number = 1234567890L;
    final long account3Number = 2514552619L;

    stubGetSavingsAccountList(savingAccountDetailsListService, savingAccountDetailsService);
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#2.xml");
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#1.xml");
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");

    final SavingProduct savingProduct1 = setUpSavingProduct(6001L);
    final SavingProduct savingProduct2 = setUpSavingProduct(6002L);
    final SavingProduct savingProduct3 = setUpSavingProduct(6003L);
    final AccountNumber accountNumber1 = setUpAccountNumber(account1Number, savingProduct1);
    final AccountNumber accountNumber2 = setUpAccountNumber(account2Number, savingProduct2);
    final AccountNumber accountNumber3 = setUpAccountNumber(account3Number, savingProduct3);

    setupSavingAccount(
        account3Number,
        ACCOUNT2_OPENED_DATE_TIME,
        null,
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setupSavingAccount(
        account1Number,
        ACCOUNT1_OPENED_DATE_TIME,
        LocalDateTime.now(clock).minusDays(1),
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    setupSavingAccount(
        account2Number,
        ACCOUNT2_OPENED_DATE_TIME,
        null,
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));

    setUpAispAndPispActivityPlayers(account1Number, account2Number, account3Number);

    setUpAccountsWithPendingIsaDeclaration(account1Number, today, today);
    setUpAccountsWithPendingIsaDeclaration(account2Number, today, today);
    setUpAccountsWithPendingIsaDeclaration(account3Number, today, today);

    final RestrictionType restrictionType1 = setUpRestrictionType("NOREC", 1001L, 2001L, 2002L);
    final RestrictionType restrictionType2 =
        setUpRestrictionTypeRuleWithRestrictionType(RTYPE, 1002L, 2003L, "RULE");
    setupAccountWarning(1L, accountNumber1, restrictionType1);
    setupAccountWarning(2L, accountNumber2, restrictionType1);
    setupAccountWarning(3L, accountNumber3, restrictionType1);
    setupAccountWarning(4L, accountNumber3, restrictionType2);

    stubMockProductServiceResponse(isaProductInfoPageResponse);
    stubMockAuditServiceResponse();

    if (usePrivate) {
      signingWebClientPrivate
          .get()
          .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(createGroupedAccountListResponse(eggIsaProduct(), true, true, false));

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
    } else {
      signingWebClientPublic
          .get()
          .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .isOk()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(GroupedAccountListResponse.class)
          .isEqualTo(createGroupedAccountListResponse(eggIsaProduct(), true, true, false));

      assertProductServiceCall(
          requestId, jwt, "/product/private/product?productIdentifiers=EGG302A&page=0&size=1");
      assertAuditAccountList(requestId, jwt);
    }
  }

  @Test
  void getTransactionsShouldReturnTransactionsResponseWhenRequestIsValid()
      throws IOException, InterruptedException {
    getTransactionsShouldReturnTransactionsResponseWhenRequestIsValid(
        BASE_PATH_PUBLIC, signingWebClientPublic, true);
  }

  @Test
  void privateGetTransactionsShouldReturnTransactionsResponseWhenRequestIsValid()
      throws IOException, InterruptedException {
    getTransactionsShouldReturnTransactionsResponseWhenRequestIsValid(
        BASE_PATH_PRIVATE, signingWebClientPrivate, false);
  }

  private void getTransactionsShouldReturnTransactionsResponseWhenRequestIsValid(
      final String basePath, final WebTestClient webTestClient, final boolean expectAudit)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final LocalDateTime transactionDate = LocalDateTime.parse("2018-09-29T00:00:00");
    final Instant nowInstant = transactionDate.atZone(ZoneId.of(GMT)).toInstant();
    final TransactionDates transactionDates = TransactionDates.builder().build();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    stubAuthenticGetTransactionsCall(AUTHENTIC_TRANSACTION_RESPONSE_2);

    final StatementTransactions transactions = createStatementTransactions(transactionDate);

    when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
        .thenReturn(Collections.singletonList(createSavingAccountDetails(null)));

    when(savingAccountTransactionsService.getTransactions(
            ACCOUNT_NUMBER_LONG, 1, TransactionService.ADG_BUFFER_SIZE, transactionDates))
        .thenReturn(transactions);

    final StatementTransactions transactions2 =
        createStatementTransactionsMultiple(transactionDate);
    when(savingAccountTransactionsService.getTransactions(
            ACCOUNT_NUMBER_LONG, 1, 2, transactionDates))
        .thenReturn(transactions2);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_TRANSACTIONS_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountTransactionsResponse.class)
        .isEqualTo(TestHelper.createAccountTransactionsResponse(nowInstant));

    if (expectAudit) {
      assertAuditAccountTransactions(
          requestId, jwt, "2018-09-29T00:00:00Z", "2018-09-29T00:00:00Z"); // NOPMD
    }
  }

  @ParameterizedTest
  @ValueSource(strings = {"2018-09-29T00:00:00", "2018-01-01T00:00:00"})
  void getTransactionsShouldReturnTransactionsForClosedAccount(final String dateTime)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final LocalDateTime transactionDate = LocalDateTime.parse(dateTime);
    final Instant nowInstant = transactionDate.atZone(ZoneId.of(GMT)).toInstant();
    final TransactionDates transactionDates = TransactionDates.builder().build();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
        .thenReturn(
            Collections.singletonList(
                createSavingAccountDetails(LocalDate.now(clock).minusDays(1L))));

    final StatementTransactions transactions = createStatementTransactionsMultiple(transactionDate);

    when(savingAccountTransactionsService.getTransactions(
            ACCOUNT_NUMBER_LONG, 1, 10, transactionDates))
        .thenReturn(transactions);

    stubMockAuditServiceResponse();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_TRANSACTIONS_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountTransactionsResponse.class)
        .isEqualTo(TestHelper.createAccountTransactionsResponse(nowInstant));

    assertAuditAccountTransactions(requestId, jwt, dateTime + "Z", dateTime + "Z");
  }

  @Test
  void
      getTransactionsShouldReturnTransactionsResponseWhenRequestHasValidTransactionDatesAndAuthenticCallIsRequired()
          throws IOException, InterruptedException {
    getTransactionsShouldReturnTransactionsResponseWhenRequestHasValidTransactionDatesAndAuthenticCallIsRequired(
        BASE_PATH_PUBLIC, signingWebClientPublic, true);
  }

  @Test
  void
      privateGetTransactionsShouldReturnTransactionsResponseWhenRequestHasValidTransactionDatesAndAuthenticCallIsRequired()
          throws IOException, InterruptedException {
    getTransactionsShouldReturnTransactionsResponseWhenRequestHasValidTransactionDatesAndAuthenticCallIsRequired(
        BASE_PATH_PRIVATE, signingWebClientPrivate, false);
  }

  private void
      getTransactionsShouldReturnTransactionsResponseWhenRequestHasValidTransactionDatesAndAuthenticCallIsRequired(
          final String basePath, final WebTestClient webTestClient, final boolean expectAudit)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final LocalDateTime transactionDate = LocalDateTime.parse("2020-04-23T13:56:15");
    final Instant nowInstant = transactionDate.atZone(ZoneId.of(GMT)).toInstant();

    final LocalDateTime startDate = LocalDateTime.parse("2020-03-01T00:00:00");
    final LocalDateTime endDate = LocalDateTime.parse("2020-09-30T23:59:59");
    final TransactionDates transactionDates =
        TransactionDates.builder().startDate(startDate).endDate(endDate).build();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    stubAuthenticGetTransactionsCall(AUTHENTIC_TRANSACTION_RESPONSE_2);

    final StatementTransactions transactions = createStatementTransactions(transactionDate);

    when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
        .thenReturn(Collections.singletonList(createSavingAccountDetails(null)));

    when(savingAccountTransactionsService.getTransactions(
            ACCOUNT_NUMBER_LONG,
            1,
            TransactionService.ADG_BUFFER_SIZE,
            TransactionDates.builder().build()))
        .thenReturn(transactions);

    final StatementTransactions transactions2 =
        createStatementTransactionsMultiple(transactionDate);
    when(savingAccountTransactionsService.getTransactions(
            ACCOUNT_NUMBER_LONG, 1, 2, transactionDates))
        .thenReturn(transactions2);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    webTestClient
        .get()
        .uri(
            getURI(
                basePath, ACCOUNT_TRANSACTIONS_PATH, "?startMonth=2020-03&endMonth=2020-09", port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountTransactionsResponse.class)
        .isEqualTo(TestHelper.createAccountTransactionsResponse(nowInstant));

    if (expectAudit) {
      assertAuditAccountTransactions(
          requestId, jwt, "2020-04-23T13:56:15Z", "2020-04-23T13:56:15Z");
    }
  }

  @ParameterizedTest
  @ValueSource(ints = {5, 10, 19, 20, 21})
  void privateGetTransactionsShouldReturnAllTransactionsWithNumberOfTransactionsParameter(
      final int numberOfTransactions) throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final LocalDateTime transactionDate = LocalDateTime.parse("2020-04-23T13:56:15");
    final Instant nowInstant = transactionDate.atZone(ZoneId.of(GMT)).toInstant();
    final TransactionDates transactionDates = TransactionDates.builder().build();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    stubAuthenticGetTransactionsCall(AUTHENTIC_TRANSACTION_RESPONSE_2);

    final StatementTransactions transactions =
        createBufferStatementTransactionWithMultipleTransactions(
            transactionDate, numberOfTransactions);

    when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
        .thenReturn(Collections.singletonList(createSavingAccountDetails(null)));

    when(savingAccountTransactionsService.getTransactions(
            ACCOUNT_NUMBER_LONG,
            1,
            TransactionService.ADG_BUFFER_SIZE,
            TransactionDates.builder().build()))
        .thenReturn(transactions);

    final StatementTransactions transactions2 =
        createStatementTransactions(transactionDate, numberOfTransactions);

    when(savingAccountTransactionsService.getTransactions(
            ACCOUNT_NUMBER_LONG, 1, numberOfTransactions, transactionDates))
        .thenReturn(transactions2);

    when(transactionInterestMapper.mapInterestRateForTransactions(any()))
        .thenReturn(
            IntStream.range(0, numberOfTransactions)
                .mapToObj(i -> TestHelper.buildAccountTransaction(nowInstant, i))
                .collect(Collectors.toList()));

    signingWebClientPrivate
        .get()
        .uri(
            getURI(
                BASE_PATH_PRIVATE,
                ACCOUNT_TRANSACTIONS_PATH,
                "?numberOfTransactions=" + numberOfTransactions,
                port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountTransactionsResponse.class)
        .isEqualTo(
            TestHelper.createAccountTransactionsResponseWithMoreThanTenTransactions(
                nowInstant, numberOfTransactions));
  }

  @Test
  void
      getTransactionsShouldReturnTransactionsResponseWhenRequestHasValidStartMonthAndValidEndMonth()
          throws IOException, InterruptedException {
    getTransactionsShouldReturnTransactionsResponseWhenRequestHasValidStartMonthAndValidEndMonth(
        BASE_PATH_PUBLIC, signingWebClientPublic, true);
  }

  @Test
  void
      privateGetTransactionsShouldReturnTransactionsResponseWhenRequestHasValidStartMonthAndValidEndMonth()
          throws IOException, InterruptedException {
    getTransactionsShouldReturnTransactionsResponseWhenRequestHasValidStartMonthAndValidEndMonth(
        BASE_PATH_PRIVATE, signingWebClientPrivate, false);
  }

  private void
      getTransactionsShouldReturnTransactionsResponseWhenRequestHasValidStartMonthAndValidEndMonth(
          final String basePath, final WebTestClient webTestClient, final boolean expectAudit)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final LocalDateTime transactionDate = LocalDateTime.parse("2018-09-29T00:00:00");
    final Instant nowInstant = transactionDate.atZone(ZoneId.of(GMT)).toInstant();

    final LocalDateTime startDate = LocalDateTime.parse("2018-08-01T00:00:00");
    final LocalDateTime endDate = LocalDateTime.parse("2018-09-30T23:59:59");
    final TransactionDates transactionDates =
        TransactionDates.builder().startDate(startDate).endDate(endDate).build();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    stubAuthenticGetTransactionsCall(AUTHENTIC_TRANSACTION_RESPONSE_2);

    final StatementTransactions transactions = createStatementTransactionsMultiple(transactionDate);

    when(savingAccountTransactionsService.getTransactions(
            ACCOUNT_NUMBER_LONG, 1, 10, transactionDates))
        .thenReturn(transactions);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    webTestClient
        .get()
        .uri(
            getURI(
                basePath, ACCOUNT_TRANSACTIONS_PATH, "?startMonth=2018-08&endMonth=2018-09", port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountTransactionsResponse.class)
        .isEqualTo(TestHelper.createAccountTransactionsResponse(nowInstant));

    if (expectAudit) {
      assertAuditAccountTransactions(
          requestId, jwt, "2018-09-29T00:00:00Z", "2018-09-29T00:00:00Z");
    }
  }

  @Test
  void privateGetWithdrawalInterestPenaltyShouldReturnPenalty()
      throws IOException, InterruptedException {
    final LocalDateTime now = LocalDateTime.now(clock);
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    stubMockProductServiceResponse(
        new ClassPathResource("/it/productInfoWithdrawalInterestPenalty.json"));

    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");

    final WithdrawalInterestPenalty expectedResponse =
        new WithdrawalInterestPenalty(new BigDecimal("1.76"));

    when(withdrawalInterestPenaltyRepository.calculateWithdrawalInterestPenalty(
            eq(Long.parseLong(ACCOUNT_NUMBER)),
            equalsOrWithinFiveSeconds(now),
            eq("0073"),
            eq("FPT"),
            eq("P"),
            eq(new BigDecimal("123.45")),
            eq(new BigDecimal("57.76")),
            equalsOrWithinFiveSeconds(now),
            eq(2),
            eq(new BigDecimal("0.750")),
            equalsOrWithinFiveSeconds(now),
            eq(LocalDateTime.parse("2021-08-31T00:00:00")),
            eq(366),
            eq(LocalDateTime.parse("2020-07-11T00:00:00")),
            eq(365),
            eq(30),
            eq(new BigDecimal("999999999.99"))))
        .thenReturn(new BigDecimal("-1.76"));

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WITHDRAWAL_INTEREST_PENALTY, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(WithdrawalInterestPenalty.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(false, requestId, jwt);
  }

  @Test
  void privateGetWithdrawalInterestPenaltyShouldReturnNotFoundWhenNoPenaltyExists()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    stubMockProductServiceResponse(new ClassPathResource("/it/productInfo.json"));

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WITHDRAWAL_INTEREST_PENALTY, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));

    assertAccountDetails(false, requestId, jwt);
  }

  @ParameterizedTest
  @MethodSource("pathsForInvalidRequestSigningKey")
  public void endpointShouldReturnForbiddenForInvalidRequestSigningKey(
      final String basePath, final String endpoint) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    WebTestClient webTestClient = signingWebClientPrivate;
    if (BASE_PATH_PRIVATE.equals(basePath)) {
      webTestClient = signingWebClientPublic; // Set invalid signing client
    }

    webTestClient
        .get()
        .uri(getURI(basePath, endpoint, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSignature(requestId));
  }

  @ParameterizedTest
  @ValueSource(booleans = {false, true})
  void
      getAccountsByGroupShouldReturnInternalServerErrorWhenSavingsAccountDetailsListServiceReturnsException(
          final boolean usePrivate) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    when(savingAccountDetailsListService.getSavingsAccountList(any(), eq(false)))
        .thenThrow(new SoaSavingsAccountListException("details"));

    if (usePrivate) {
      signingWebClientPrivate
          .get()
          .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .is5xxServerError()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(ErrorResponse.class)
          .isEqualTo(TestHelper.internalServerError(requestId));
    } else {
      signingWebClientPublic
          .get()
          .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_GROUP_PATH, port))
          .headers(standardHeaders(requestId, jwt))
          .exchange()
          .expectStatus()
          .is5xxServerError()
          .expectHeader()
          .contentType(MediaType.APPLICATION_JSON)
          .expectBody(ErrorResponse.class)
          .isEqualTo(TestHelper.internalServerError(requestId));
    }
  }

  @Test
  void getTransactionsShouldReturnEmptyTransactionResponseWhenPageIsNotValid()
      throws IOException, InterruptedException {
    getTransactionsShouldReturnEmptyTransactionResponseWhenPageIsNotValid(
        BASE_PATH_PUBLIC, signingWebClientPublic, true);
  }

  @Test
  void privateGetTransactionsShouldReturnEmptyTransactionResponseWhenPageIsNotValid()
      throws IOException, InterruptedException {
    getTransactionsShouldReturnEmptyTransactionResponseWhenPageIsNotValid(
        BASE_PATH_PRIVATE, signingWebClientPrivate, false);
  }

  private void getTransactionsShouldReturnEmptyTransactionResponseWhenPageIsNotValid(
      final String basePath, final WebTestClient webTestClient, final boolean expectAudit)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_TRANSACTIONS_PATH, port) + "?page=0")
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountTransactionsResponse.class)
        .isEqualTo(TestHelper.createEmptyAccountTransactionResponse());

    if (expectAudit) {
      assertAuditAccountTransactions(requestId, jwt, null, null);
    }
  }

  @Test
  void getTransactionsShouldReturnInternalServerErrorWhenReturnsFault() throws IOException {
    getTransactionsShouldReturnInternalServerErrorWhenReturnsFault(
        BASE_PATH_PUBLIC, signingWebClientPublic);
  }

  @Test
  void privateGetTransactionsShouldReturnInternalServerErrorWhenReturnsFault() throws IOException {
    getTransactionsShouldReturnInternalServerErrorWhenReturnsFault(
        BASE_PATH_PRIVATE, signingWebClientPrivate);
  }

  private void getTransactionsShouldReturnInternalServerErrorWhenReturnsFault(
      final String basePath, final WebTestClient webTestClient) throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    stubAuthenticGetTransactionsCall("/it/AuthenticTransactionsResponse#1.xml");

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_TRANSACTIONS_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.internalServerError(requestId));
  }

  @Test
  void getTransactionsShouldReturnBadRequestWhenStartMonthIsAfterEndMonth() {
    getTransactionsShouldReturnBadRequestWhenStartMonthIsAfterEndMonth(
        BASE_PATH_PUBLIC, signingWebClientPublic);
  }

  @Test
  void privateGetTransactionsShouldReturnBadRequestWhenStartMonthIsAfterEndMonth() {
    getTransactionsShouldReturnBadRequestWhenStartMonthIsAfterEndMonth(
        BASE_PATH_PRIVATE, signingWebClientPrivate);
  }

  private void getTransactionsShouldReturnBadRequestWhenStartMonthIsAfterEndMonth(
      final String basePath, final WebTestClient webTestClient) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final ErrorResponse errorResponse =
        ErrorResponse.builder()
            .code("400 Bad Request")
            .id(requestId)
            .message("Bad Request")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Date.Invalid")
                    .message("Invalid date range")
                    .build())
            .build();

    webTestClient
        .get()
        .uri(
            getURI(
                basePath, ACCOUNT_TRANSACTIONS_PATH, "?startMonth=2018-10&endMonth=2018-09", port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(errorResponse);
  }

  @ParameterizedTest
  @MethodSource("requestPathsAndInvalidScopes") // NOPMD
  void shouldReturnUnauthorisedWhenBearerTokenIsNotValidJwt(
      final HttpMethod method, final String basePath, final String path, final String queryParams) {
    final UUID requestId = UUID.randomUUID();
    WebTestClient webClient = signingWebClientPublic;
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    if (BASE_PATH_PRIVATE.equals(basePath)) {
      webClient = signingWebClientPrivate;
    }
    final URI formattedURI =
        queryParams == null
            ? getURI(basePath, path, port)
            : getURI(basePath, path, queryParams, port);
    webClient
        .method(method)
        .uri(formattedURI)
        .headers(standardHeaders(requestId, "invalid.bearer.token"))
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @MethodSource("requestPathsAndInvalidScopes") // NOPMD
  void shouldReturnUnauthorisedWhenBearerTokenIsMissing(
      final HttpMethod method, final String basePath, final String path, final String queryParams) {
    final UUID requestId = UUID.randomUUID();
    WebTestClient webClient = signingWebClientPublic;
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    if (BASE_PATH_PRIVATE.equals(basePath)) {
      webClient = signingWebClientPrivate;
    }
    final URI formattedURI =
        queryParams == null
            ? getURI(basePath, path, port)
            : getURI(basePath, path, queryParams, port);
    webClient
        .method(method)
        .uri(formattedURI)
        .headers(standardHeaders(requestId))
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @MethodSource("requestPathsAndInvalidScopes") // NOPMD
  void shouldReturnForbiddenWhenJwtLacksRequiredScope(
      final HttpMethod method,
      final String basePath,
      final String path,
      final String queryParams,
      final String invalidScope) {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithoutRequiredScope = createYbsJwtWithScope(invalidScope);
    WebTestClient webClient = signingWebClientPublic;

    final ErrorResponse expectedResponse =
        TestHelper.accessDeniedErrorResponse(requestId, ErrorResponse.ErrorItem.ACCESS_DENIED);

    if (BASE_PATH_PRIVATE.equals(basePath)) {
      webClient = signingWebClientPrivate;
    }
    final URI formattedURI =
        queryParams == null
            ? getURI(basePath, path, port)
            : getURI(basePath, path, queryParams, port);
    webClient
        .method(method)
        .uri(formattedURI)
        .headers(standardHeaders(requestId, jwtWithoutRequiredScope))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @MethodSource("requestPathsAndInvalidScopes") // NOPMD
  void shouldReturnBadRequestWhenJwtSessionIdClaimIsNotAUUID(
      final HttpMethod method, final String basePath, final String path, final String queryParams) {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithInvalidSessionId = createYbsJwtWithSessionId("invalid_session_id");
    WebTestClient webClient = signingWebClientPublic;

    final ErrorResponse expectedResponse = TestHelper.invalidSessionIdErrorResponse(requestId);

    if (BASE_PATH_PRIVATE.equals(basePath)) {
      webClient = signingWebClientPrivate;
    }
    final URI formattedURI =
        queryParams == null
            ? getURI(basePath, path, port)
            : getURI(basePath, path, queryParams, port);
    webClient
        .method(method)
        .uri(formattedURI)
        .headers(standardHeaders(requestId, jwtWithInvalidSessionId))
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @MethodSource("requestPathsAndInvalidScopes") // NOPMD
  void shouldReturnBadRequestWhenJwtSessionIdClaimIsMissing(
      final HttpMethod method, final String basePath, final String path, final String queryParams) {
    final UUID requestId = UUID.randomUUID();
    final String jwtWithoutSessionId = createYbsJwtWithoutSessionId();
    WebTestClient webClient = signingWebClientPublic;

    final ErrorResponse expectedResponse = TestHelper.missingSessionIdErrorResponse(requestId);

    if (BASE_PATH_PRIVATE.equals(basePath)) {
      webClient = signingWebClientPrivate;
    }
    final URI formattedURI =
        queryParams == null
            ? getURI(basePath, path, port)
            : getURI(basePath, path, queryParams, port);
    webClient
        .method(method)
        .uri(formattedURI)
        .headers(standardHeaders(requestId, jwtWithoutSessionId))
        .exchange()
        .expectStatus()
        .isBadRequest()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        IntegrationTestJwtFactory.CLAIM_AUD,
        IntegrationTestJwtFactory.CLAIM_SUB,
        IntegrationTestJwtFactory.CLAIM_BRAND_CODE
      })
  void shouldReturnUnauthorisedWhenRequiredClaimMissing(final String missingClaim) {
    final UUID requestId = UUID.randomUUID();
    final ErrorResponse expectedResponse = TestHelper.unauthorizedErrorResponse(requestId);

    final Map<String, Object> claims =
        IntegrationTestJwtFactory.customerClaimsMap(PARTY_ID, ACCOUNT_READ_SCOPE, BRAND_CODE_YBS);
    claims.remove(missingClaim);

    final String jwt = createJwt(claims);

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isUnauthorized()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectHeader()
        .exists(HttpHeaders.WWW_AUTHENTICATE)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void shouldReturnForbiddenWhenSignatureIsInvalid() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    nonSigningWebClient
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, "request-signature-key-id-public")
        .header(HEADER_REQUEST_SIGNATURE, "invalid-signature")
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.invalidSignature(requestId));
  }

  @Test
  void getTransactionsShouldReturnNotFoundWhenAccountDoesNotExist() {
    getTransactionsShouldReturnNotFoundWhenAccountDoesNotExist(
        BASE_PATH_PUBLIC, signingWebClientPublic);
  }

  @Test
  void privateGetTransactionsShouldReturnNotFoundWhenAccountDoesNotExist() {
    getTransactionsShouldReturnNotFoundWhenAccountDoesNotExist(
        BASE_PATH_PRIVATE, signingWebClientPrivate);
  }

  private void getTransactionsShouldReturnNotFoundWhenAccountDoesNotExist(
      final String basePath, final WebTestClient webTestClient) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_TRANSACTIONS_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));
  }

  @Test
  void privateGetWithdrawalInterestPenaltyShouldReturnNotFoundWhenAccountDoesNotExist() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WITHDRAWAL_INTEREST_PENALTY, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));
  }

  @Test
  void postIsaDeclarationShouldSubmitAIsaDeclarationWhenRequestIsValid() throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);
    final LocalDateTime today = LocalDateTime.now(clock);

    final SavingProduct savingProduct = setUpSavingProduct(1L);
    final RestrictionType restrictionType = setUpRestrictionType(NOSUBS, 1L, 2L, 3L);
    final AccountNumber accountNumber = setUpAccountNumber(ACCOUNT_NUMBER_LONG, savingProduct);
    setupAccountWarning(1L, accountNumber, restrictionType);
    stubMockProductServiceResponse(new ClassPathResource("/it/isaProductInfo.json")); // NOPMD

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, ISA_DECLARATION, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isAccepted();

    assertWorkLogsWithCount(
        1, workLogMatching(buildWorkLog(requestId, jwt, Operation.SUBMIT_ISA_DEC, Status.PENDING)));

    assertSavingsTransactionLogsWithCount(
        1,
        savingsTransactionLogMatching(
            buildSavingsTransactionLog(
                Long.valueOf(ACCOUNT_NUMBER),
                null,
                today,
                today,
                SavingsTransactionLogEntry.STATUS_ISA_DECLARATION,
                BigDecimal.ZERO,
                12462951L)));
  }

  @Test
  void postIsaDeclarationShouldSubmitAIsaDeclarationHasOutOfDateInProcessRecord()
      throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);
    final LocalDateTime today = LocalDateTime.now(clock);
    final LocalDateTime threeDaysAgo = today.minusDays(3);
    final SavingProduct savingProduct = setUpSavingProduct(1L);
    final RestrictionType restrictionType = setUpRestrictionType(NOSUBS, 1L, 2L, 3L);
    final AccountNumber accountNumber = setUpAccountNumber(ACCOUNT_NUMBER_LONG, savingProduct);
    setupAccountWarning(1L, accountNumber, restrictionType);
    stubMockProductServiceResponse(new ClassPathResource("/it/isaProductInfo.json"));
    setUpAccountsWithPendingIsaDeclaration(ACCOUNT_NUMBER_LONG, threeDaysAgo, threeDaysAgo);

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, ISA_DECLARATION, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isAccepted();

    assertWorkLogsWithCount(
        1, workLogMatching(buildWorkLog(requestId, jwt, Operation.SUBMIT_ISA_DEC, Status.PENDING)));

    assertSavingsTransactionLogsWithCount(
        2,
        savingsTransactionLogMatching(
            buildSavingsTransactionLog(
                Long.valueOf(ACCOUNT_NUMBER),
                null,
                today,
                today,
                SavingsTransactionLogEntry.STATUS_ISA_DECLARATION,
                BigDecimal.ZERO,
                12462951L)));
  }

  @Test
  void postIsaDeclarationShouldNotSubmitAIsaDeclarationWhenHasAlreadyBeenSubmitted()
      throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);
    final LocalDateTime today = LocalDateTime.now(clock);
    final SavingProduct savingProduct = setUpSavingProduct(1L);
    final RestrictionType restrictionType = setUpRestrictionType(NOSUBS, 1L, 2L, 3L);
    final AccountNumber accountNumber = setUpAccountNumber(ACCOUNT_NUMBER_LONG, savingProduct);
    setupAccountWarning(1L, accountNumber, restrictionType);
    stubMockProductServiceResponse(new ClassPathResource("/it/isaProductInfo.json"));
    setUpAccountsWithPendingIsaDeclaration(ACCOUNT_NUMBER_LONG, today, today);

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, ISA_DECLARATION, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT);

    assertNoWorkLogs();

    final Matcher<SavingsTransactionLogEntry> existingRecordMatchers =
        savingsTransactionLogMatching(
            buildSavingsTransactionLog(
                Long.valueOf(ACCOUNT_NUMBER),
                null,
                today,
                today,
                SavingsTransactionLogEntry.STATUS_ISA_DECLARATION,
                BigDecimal.TEN,
                12345L));

    assertSavingsTransactionLogsWithCount(1, existingRecordMatchers);
  }

  @Test
  void postIsaDeclarationShouldReturnInternalServerErrorWhenNoProductTypeIsFoundAccount() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, ISA_DECLARATION, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);

    assertNoWorkLogs();
    assertNoSavingsTransactionsLogs();
  }

  @Test
  void postIsaDeclarationShouldReturnConflictWhenAccountProductIsNotAnIsa() throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);
    final SavingProduct savingProduct = setUpSavingProduct(1L);
    setUpAccountNumber(ACCOUNT_NUMBER_LONG, savingProduct);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfo.json"));

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, ISA_DECLARATION, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT);

    assertNoWorkLogs();
    assertNoSavingsTransactionsLogs();
  }

  @Test
  void postIsaDeclarationShouldReturnConflictWhenAccountHasNoDepositWarnings() throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);

    final SavingProduct savingProduct = setUpSavingProduct(1L);
    setUpRestrictionType(NOSUBS, 1L, 2L, 3L);
    setUpAccountNumber(ACCOUNT_NUMBER_LONG, savingProduct);
    stubMockProductServiceResponse(new ClassPathResource("/it/isaProductInfo.json"));

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, ISA_DECLARATION, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT);

    assertNoWorkLogs();
    assertNoSavingsTransactionsLogs();
  }

  @Test
  void postIsaDeclarationShouldReturnAccessDeniedResponseWhenInvalidScope() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(OTHER_SCOPE);
    final ErrorResponse expectedResponse =
        TestHelper.accessDeniedErrorResponse(requestId, ErrorResponse.ErrorItem.ACCESS_DENIED);

    signingWebClientPublic
        .post()
        .uri(getURI(BASE_PATH_PUBLIC, ISA_DECLARATION, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void getPrivateRecentSavingsAccountsShouldReturnNoContentWhenOpenAccountsAreFound() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidSystemYbsJwt();

    setUpAccountAccessRequiredEntities(PARTY_ID, ACCOUNT_NUMBER_LONG, ACTIVITY_GROUP_CODE_AISP);
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);

    signingWebClientPrivate
        .get()
        .uri(
            getURI(
                BASE_PATH_PRIVATE,
                RECENT_SAVINGS_ACCOUNTS_PATH,
                PARTY_ID_QUERY_PARAM + PARTY_ID,
                port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  void getPrivateRecentSavingsAccountsShouldReturnNoContentWhenClosedAccountsAreFound() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidSystemYbsJwt();
    setUpAccountAccessRequiredEntities(PARTY_ID, ACCOUNT_NUMBER_LONG, ACTIVITY_GROUP_CODE_AISP);
    setupSavingAccount(
        ACCOUNT_NUMBER_LONG,
        ACCOUNT1_OPENED_DATE_TIME,
        LocalDateTime.now(clock).minusDays(1),
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));

    signingWebClientPrivate
        .get()
        .uri(
            getURI(
                BASE_PATH_PRIVATE,
                RECENT_SAVINGS_ACCOUNTS_PATH,
                PARTY_ID_QUERY_PARAM + Long.valueOf(PARTY_ID),
                port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNoContent();
  }

  @Test
  void getPrivateRecentSavingsAccountsShouldReturnNotFoundWhenNoAccountsAreFound() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidSystemYbsJwt();

    setUpAccountAccessRequiredEntities(PARTY_ID, ACCOUNT_NUMBER_LONG, ACTIVITY_GROUP_CODE_AISP);
    setupSavingAccount(
        ACCOUNT_NUMBER_LONG,
        ACCOUNT1_OPENED_DATE_TIME,
        LocalDateTime.now(clock).minusYears(3),
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));

    signingWebClientPrivate
        .get()
        .uri(
            getURI(
                BASE_PATH_PRIVATE,
                RECENT_SAVINGS_ACCOUNTS_PATH,
                PARTY_ID_QUERY_PARAM + PARTY_ID,
                port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound();
  }

  @Test
  public void getAccountWarningsShouldSucceed() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    final AccountAccessRequiredEntities accountAccessRequiredEntities =
        setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final RestrictionType restrictionType1 =
        setUpRestrictionTypeRuleWithRestrictionType(WARNING_CODE_VALID, 1001L, 2001L, WEBREC);
    final RestrictionType restrictionType2 =
        setUpRestrictionTypeRuleWithRestrictionType("PA", 1002L, 2003L, "RULE1");
    setupAccountWarning(1L, accountAccessRequiredEntities.getAccountNumber(), restrictionType1);
    setupAccountWarning(2L, accountAccessRequiredEntities.getAccountNumber(), restrictionType2);

    final Collection<Warning> warnings = TestHelper.buildWarningsResponse();

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBodyList(Warning.class)
        .hasSize(2)
        .consumeWith(
            result -> assertThat(result.getResponseBody(), containsInAnyOrder(warnings.toArray())));
  }

  @Test
  public void createAccountWarningShouldSucceed() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    final WarningCode warningCode = WarningCode.builder().code(WARNING_CODE_VALID).build();

    setUpRestrictionTypeRuleWithRestrictionType(WARNING_CODE_VALID, 1001L, 2001L, WEBREC);
    setUpRestrictionTypeCore(WARNING_CODE_VALID, 1001L);

    final SavingProduct savingProduct = setUpSavingProduct(PRODUCT_SYS_ID);
    final uk.co.ybs.digital.account.model.core.SavingProduct savingProductCore =
        setUpSavingProductCore(PRODUCT_SYS_ID);

    setUpAccountNumber(accountNumber, savingProduct);
    setUpAccountNumberCore(accountNumber, savingProductCore);

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isAccepted()
        .expectHeader();

    assertWorkLogsWithCount(
        1,
        workLogMatching(
            buildWorkLog(requestId, jwt, Operation.INS_ACCOUNT_WARNING, Status.PENDING)));
  }

  @Test
  public void createDuplicateAccountWarningShouldSucceedWithCreating() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    final WarningCode warningCode = WarningCode.builder().code(WARNING_CODE_VALID).build();

    setUpRestrictionTypeRuleWithRestrictionType(WARNING_CODE_VALID, 1001L, 2001L, WEBREC);
    setUpRestrictionTypeCore(WARNING_CODE_VALID, 1001L);

    final SavingProduct savingProduct = setUpSavingProduct(PRODUCT_SYS_ID);
    setUpSavingProductCore(PRODUCT_SYS_ID);

    setUpAccountNumber(accountNumber, savingProduct);

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isAccepted()
        .expectHeader();

    assertWorkLogsWithCount(
        1,
        workLogMatching(
            buildWorkLog(requestId, jwt, Operation.INS_ACCOUNT_WARNING, Status.PENDING)));
  }

  @Test
  public void createAccountWarningWithWarningNotesShouldSucceed() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    final WarningCode warningCode =
        WarningCode.builder()
            .code(WARNING_CODE_VALID)
            .serviceSchemaUser("PROSRV")
            .notes("some notes")
            .partyId(12345678L)
            .build();

    setUpRestrictionTypeRuleWithRestrictionType(WARNING_CODE_VALID, 1001L, 2001L, WEBREC);
    setUpRestrictionTypeCore(WARNING_CODE_VALID, 1001L);

    final SavingProduct savingProduct = setUpSavingProduct(PRODUCT_SYS_ID);
    final uk.co.ybs.digital.account.model.core.SavingProduct savingProductCore =
        setUpSavingProductCore(PRODUCT_SYS_ID);

    setUpAccountNumber(accountNumber, savingProduct);
    setUpAccountNumberCore(accountNumber, savingProductCore);

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isAccepted()
        .expectHeader();

    assertWorkLogsWithCount(
        1,
        workLogMatching(
            buildWorkLog(requestId, jwt, Operation.INS_ACCOUNT_WARNING, Status.PENDING)));
  }

  @Test
  public void createAccountWarningShouldReturnInternalServerErrorWhenRestrictionCodeDoesNotExist() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final WarningCode warningCode = WarningCode.builder().code("T").build();

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @Test
  public void createAccountWarningShouldReturnBadRequestWhenNotesTooLong() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    // Notes should be 241 characters long
    final WarningCode warningCode =
        WarningCode.builder()
            .code(WARNING_CODE_VALID)
            .notes(
                "a6RIWXZw6j13OHRZKotEd8xKCiDLqLJNZnNMtmxIeIUwwP2ufTk6qTgGI8zWTMoVRHKFqpF3Z1NgBrqWLVwCHAh4DVd3y8thoFTIc8V2OHj4uNza6Q2s5BJ8SF3KLLlFAOzfRODa7LyvzihMNj1lfshEPOAVeUEgGjGmZH7AwHSxpCqRhqzMmdU9FzLsFqHDgsSdcigKikU74WA11KsuaMefIpxSXfUPLlwIzHtMS98VTWWXw")
            .build();

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.BAD_REQUEST);
  }

  @Test
  public void createAccountWarningShouldReturnBadRequestWhenWarningTypeMissing() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    // Notes should be 241 characters long
    final WarningCode warningCode = WarningCode.builder().notes("notes").build();

    signingWebClientPrivate
        .post()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.BAD_REQUEST);
  }

  @Test
  public void deleteAccountWarningShouldSucceed() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createSystemYbsJwtWithScope(ACCOUNT_WRITE_SCOPE);
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    final WarningCode warningCode = WarningCode.builder().code(WARNING_CODE_VALID).build();

    final RestrictionType restrictionType =
        setUpRestrictionTypeRuleWithRestrictionType(WARNING_CODE_VALID, 1001L, 2001L, WEBREC);
    setUpRestrictionTypeCore(WARNING_CODE_VALID, 1001L);

    final SavingProduct savingProduct = setUpSavingProduct(PRODUCT_SYS_ID);
    final uk.co.ybs.digital.account.model.core.SavingProduct savingProductCore =
        setUpSavingProductCore(PRODUCT_SYS_ID);

    final AccountNumber accountNumberObj = setUpAccountNumber(accountNumber, savingProduct);
    setUpAccountNumberCore(accountNumber, savingProductCore);
    setupAccountWarning(1L, accountNumberObj, restrictionType);

    signingWebClientPrivate
        .method(HttpMethod.DELETE)
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isAccepted()
        .expectHeader();

    assertWorkLogsWithCount(
        1,
        workLogMatching(
            buildWorkLog(requestId, jwt, Operation.DEL_ACCOUNT_WARNING, Status.PENDING)));
  }

  @Test
  public void deleteAccountWarningShouldReturnInternalServerErrorWhenRestrictionCodeDoesNotExist() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createSystemYbsJwtWithScope(ACCOUNT_WRITE_SCOPE);
    final WarningCode warningCode = WarningCode.builder().code("T").build();

    signingWebClientPrivate
        .method(HttpMethod.DELETE)
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @Test
  public void deleteAccountWarningShouldReturnBadRequestWhenWarningTypeMissing() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createSystemYbsJwtWithScope(ACCOUNT_WRITE_SCOPE);

    // Notes should be 241 characters long
    final WarningCode warningCode = WarningCode.builder().notes("notes").build();

    signingWebClientPrivate
        .method(HttpMethod.DELETE)
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_WARNINGS_PATH, port))
        .bodyValue(warningCode)
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.BAD_REQUEST);
  }

  @Test
  public void deleteAccountShouldSucceed() {

    final UUID requestId = UUID.randomUUID();
    final String jwt = createSystemYbsJwtWithScope(ACCOUNT_WRITE_SCOPE);
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    setUpSavingProduct(PRODUCT_SYS_ID);
    final uk.co.ybs.digital.account.model.core.SavingProduct savingProductCore =
        setUpSavingProductCore(PRODUCT_SYS_ID);

    setUpAccountNumberCore(accountNumber, savingProductCore);
    setUpSavingAccountCore(accountNumber);

    signingWebClientPrivate
        .delete()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_DELETE_ENDPOINT, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isAccepted()
        .expectHeader();

    assertWorkLogsWithCount(
        1, workLogMatching(buildWorkLog(requestId, jwt, Operation.DELETE_ACCOUNT, Status.PENDING)));
  }

  @ParameterizedTest
  @ValueSource(strings = {"?includeShareplanAccounts=true", "?includeShareplanAccounts=false"})
  @EmptySource
  public void getAccountWarningsForGivenPartyIdShouldSucceed(final String uri) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final AccountAccessRequiredEntities accountAccessRequiredEntities1 =
        setUpAccountAccessRequiredEntitiesParties(accountNumber, ACTIVITY_GROUP_CODE_PISP);
    final RestrictionType restrictionType1 =
        setUpRestrictionTypeRuleWithRestrictionType(WARNING_CODE_VALID, 1001L, 2001L, WEBREC);
    final RestrictionType restrictionType2 =
        setUpRestrictionTypeRuleWithRestrictionType("PA", 1002L, 2003L, "RULE1");
    setupAccountWarning(1L, accountAccessRequiredEntities1.getAccountNumber(), restrictionType1);
    setupAccountWarning(2L, accountAccessRequiredEntities1.getAccountNumber(), restrictionType2);
    setupOpenSavingAccount(accountNumber);
    signingWebClientPrivate
        .get()
        .uri(
            getURI(
                BASE_PATH_PRIVATE,
                ACCOUNTS_PATH
                    + "/warnings"
                    + ("".equals(uri) ? PARTY_ID_QUERY_PARAM : uri + "&partyId=")
                    + PARTY_ID_ACCOUNT_WARNINGS,
                port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountWarningsResponse.class)
        .consumeWith(
            result -> {
              final AccountWarningSummary accountWarningSummary =
                  Objects.requireNonNull(result.getResponseBody()).getSavings().getAccount()
                      .stream()
                      .findFirst()
                      .orElse(null);
              assert accountWarningSummary != null;
              assertThat(accountWarningSummary.getAccountNumber(), is(accountNumber.toString()));
              assertThat(
                  accountWarningSummary.getOpenedDate().toLocalDate(),
                  is(LocalDate.of(2019, Month.MAY, 25)));
            });
  }
}
