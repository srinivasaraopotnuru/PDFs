package uk.co.ybs.digital.account.repository.core;

import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.core.AccountNumber;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.RestrictionType;
import uk.co.ybs.digital.account.model.core.SavingProduct;
import uk.co.ybs.digital.account.model.core.WarningNote;

@AllArgsConstructor
public class TestHelper {
  @NonNull private TestEntityManager coreTestEntityManager;

  public AccountWarning buildAccountWarning(
      final AccountNumber accountNumber,
      final RestrictionType restrictionType,
      final LocalDateTime startDate,
      final LocalDate endDate) {
    return AccountWarning.builder()
        .accountNumber(accountNumber)
        .restrictionType(restrictionType)
        .createdBy("SAPP")
        .createdAt("SAPP")
        .createdDate(startDate)
        .startDate(startDate)
        .endDate(endDate)
        .build();
  }

  AccountWarning persistAccountWarning(final AccountWarning accountWarning) {
    return coreTestEntityManager.persistAndFlush(accountWarning);
  }

  WarningNote buildWarningNote(
      final Long accountWarningSysId,
      final LocalDateTime startDate,
      final String createdAt,
      final LocalDateTime createdDate,
      final String createdBy,
      final String notes) {
    return WarningNote.builder()
        .accountWarningSysId(accountWarningSysId)
        .startDate(startDate)
        .createdAt(createdAt)
        .createdDate(createdDate)
        .createdBy(createdBy)
        .notes(notes)
        .build();
  }

  WarningNote persistWarningNote(final WarningNote warningNote) {
    return coreTestEntityManager.persistAndFlush(warningNote);
  }

  public AccountNumber buildAccountNumber(final Long accountNumber, final Long productId) {
    return AccountNumber.builder()
        .accountNumber(accountNumber)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .savingProductSysId(productId)
        .build();
  }

  AccountNumber persistAccountNumber(final Long accountNumber, final Long productId) {
    return coreTestEntityManager.persistAndFlush(buildAccountNumber(accountNumber, productId));
  }

  public RestrictionType buildRestrictionType(
      final Long sysId, final String restrictionTypeCode, final LocalDateTime startDate) {
    return RestrictionType.builder()
        .sysId(sysId)
        .code(restrictionTypeCode)
        .startDate(startDate)
        .build();
  }

  RestrictionType persistRestrictionType(final RestrictionType restrictionType) {
    return coreTestEntityManager.persistAndFlush(restrictionType);
  }

  void persistSavingProduct(final Long savingProductSysId) {
    coreTestEntityManager.persistAndFlush(new SavingProduct(savingProductSysId, "YBS"));
  }
}
