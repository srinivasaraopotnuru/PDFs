package uk.co.ybs.digital.account.config;

import javax.persistence.EntityManagerFactory;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

@TestConfiguration
public class TestDatabaseConfiguration {
  @Bean
  public TransactionTemplate transactionTemplate(
      final PlatformTransactionManager adgCoreTransactionManager,
      final PlatformTransactionManager coreTransactionManager,
      final PlatformTransactionManager copyTransactionManager,
      final PlatformTransactionManager frontOfficeTransactionManager,
      final PlatformTransactionManager digitalAccountTransactionManager) {
    final ChainedTransactionManager chainedTransactionManager =
        new ChainedTransactionManager(
            adgCoreTransactionManager,
            coreTransactionManager,
            copyTransactionManager,
            frontOfficeTransactionManager,
            digitalAccountTransactionManager);
    return new TransactionTemplate(chainedTransactionManager);
  }

  @Bean
  public TestEntityManager adgCoreTestEntityManager(
      final EntityManagerFactory adgCoreEntityManagerFactory) {
    return new TestEntityManager(adgCoreEntityManagerFactory);
  }

  @Bean
  public TestEntityManager frontOfficeTestEntityManager(
      final EntityManagerFactory frontOfficeEntityManagerFactory) {
    return new TestEntityManager(frontOfficeEntityManagerFactory);
  }

  @Bean
  public TestEntityManager digitalAccountTestEntityManager(
      final EntityManagerFactory digitalAccountEntityManagerFactory) {
    return new TestEntityManager(digitalAccountEntityManagerFactory);
  }

  @Bean
  public TestEntityManager coreTestEntityManager(
      final EntityManagerFactory coreEntityManagerFactory) {
    return new TestEntityManager(coreEntityManagerFactory);
  }

  @Bean
  public TestEntityManager copyTestEntityManager(
      final EntityManagerFactory copyEntityManagerFactory) {
    return new TestEntityManager(copyEntityManagerFactory);
  }
}
