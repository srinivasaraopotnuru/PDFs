package uk.co.ybs.digital.account.integration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.hamcrest.beans.HasPropertyWithValue.hasPropertyAtPath;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.account.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.net.URI;
import java.security.PrivateKey;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.regex.Pattern;
import java.util.stream.IntStream;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.ArgumentMatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.account.integration.IntegrationTestJwtFactory;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.AccountWarning;
import uk.co.ybs.digital.account.model.adgcore.ActivityPlayer;
import uk.co.ybs.digital.account.model.adgcore.ActivityType;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.model.adgcore.AddressUsage;
import uk.co.ybs.digital.account.model.adgcore.Country;
import uk.co.ybs.digital.account.model.adgcore.Party;
import uk.co.ybs.digital.account.model.adgcore.PostalAddress;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;
import uk.co.ybs.digital.account.model.adgcore.SavingAccount;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.model.adgcore.SavingTransaction;
import uk.co.ybs.digital.account.model.adgcore.TessaDetails;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransaction;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactions;
import uk.co.ybs.digital.account.model.copy.Metadata;
import uk.co.ybs.digital.account.model.digitalaccount.SubmitIsaDeclarationRequest;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogRequest;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.account.service.SavingAccountDetailsListService;
import uk.co.ybs.digital.account.service.SavingAccountDetailsService;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountListRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountTransactionsRequest;
import uk.co.ybs.digital.account.utils.AccountAccessRequiredEntities;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.AccountSummary;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.DepositLimit;
import uk.co.ybs.digital.account.web.dto.Deposits;
import uk.co.ybs.digital.account.web.dto.DepositsSummary;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.Isa;
import uk.co.ybs.digital.account.web.dto.Product;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.Restriction;
import uk.co.ybs.digital.account.web.dto.RestrictionCategory;
import uk.co.ybs.digital.account.web.dto.WithdrawalsSummary;

@SuppressWarnings({"SameParameterValue", "deprecation"})
public class AccountServiceITBase {

  static final String NOSUBS = "NOSUBS";
  static final int WITHDRAWAL_LIMIT = 5;
  static final int WITHDRAWAL_LIMIT_NOT_REACHED = WITHDRAWAL_LIMIT - 1;
  static final String INTERIM_BOOKED = "InterimBooked";
  static final String INTERIM_AVAILABLE = "InterimAvailable";
  static final String EGG302A = "EGG302A";
  static final String GBP = "GBP";
  static final LocalDate WITHDRAWAL_LIMIT_START_DATE = LocalDate.of(2020, Month.JANUARY, 3);
  static final LocalDate WITHDRAWAL_LIMIT_PERIOD_END = LocalDate.of(2021, Month.JANUARY, 3);
  static final LocalDate ACCOUNT_CLOSED_DATE = LocalDate.of(2016, Month.JANUARY, 3);
  static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";

  static final String ACCOUNT_READ_SCOPE = "ACCOUNT_READ";
  static final String ACCOUNT_WRITE_SCOPE = "ACCOUNT_WRITE";
  static final String OTHER_SCOPE = "PAYMENT";
  static final String BRAND_CODE_YBS = "YBS";
  static final String BRAND_CODE_CHELSEA = "CHE";
  static final String PARTY_ID = "12462951";
  static final String PARTY_ID_ACCOUNT_WARNINGS = "0012462951";
  static final String PARTY_ID_ACCOUNTS = "4567890127";
  static final String PARTY_ID_OTHER = "22462951";
  static final Long PRODUCT_SYS_ID = 2000L;
  static final Long ISA_PRODUCT_SYS_ID = 4000L;
  static final String BASE_PATH = "/account";
  static final String BASE_PATH_PUBLIC = "";
  static final String BASE_PATH_PRIVATE = "/private";
  static final String ACCOUNTS_PATH = "/accounts";
  static final String ACCOUNT_GROUP_PATH = ACCOUNTS_PATH + "/grouped";
  static final String ACCOUNT_NUMBER = "1234567890";
  static final String ACCOUNT_NUMBER_2 = "2010304057";
  static final Long ACCOUNT_NUMBER_LONG = Long.valueOf(ACCOUNT_NUMBER);
  static final Long ACCOUNT_NUMBER_2_LONG = Long.valueOf(ACCOUNT_NUMBER_2);
  static final String ISA_DECLARATION =
      ACCOUNTS_PATH + "/" + ACCOUNT_NUMBER + "/" + "isa-declaration";
  static final String ACCOUNT_WARNINGS_PATH =
      ACCOUNTS_PATH + "/" + ACCOUNT_NUMBER + "/" + "warnings";
  static final String ACCOUNT_DETAIL_PATH = ACCOUNTS_PATH + "/" + ACCOUNT_NUMBER;
  static final String ACCOUNT_TRANSACTIONS_PATH = ACCOUNT_DETAIL_PATH + "/transactions";
  static final String ACCOUNT_WITHDRAWAL_INTEREST_PENALTY =
      ACCOUNT_DETAIL_PATH + "/withdrawal-interest-penalty?withdrawalAmount=123.45";
  static final String ACCOUNT_DELETE_ENDPOINT = ACCOUNTS_PATH + "/" + ACCOUNT_NUMBER;
  static final String ACCOUNT_NAME = "NewAccountNickName";
  static final String ACCOUNT_DETAIL_WITH_FILTERS = "?include=availableDepositLimit,otherAccount";
  static final String ACCOUNT_DETAIL_WITH_OTHER_ACCOUNT_FILTERS = "?include=otherAccount";
  static final String ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS =
      "?include=availableDepositLimit";
  static final String RECENT_SAVINGS_ACCOUNTS_PATH = ACCOUNTS_PATH + "/savings/recent";
  static final String ACTIVITY_PLAYER_TABLE_ID = "ACCNUM";
  static final String ACTIVITY_TYPE_CODE_MHLDRS = "MHLDRS";
  static final String ACTIVITY_TYPE_CODE_BENOWN = "BENOWN";
  static final String ACTIVITY_TYPE_CODE_SIGNATORY = "SIG";
  static final String ACTIVITY_GROUP_CODE_PISP = "PISP";
  static final String ACTIVITY_GROUP_CODE_AISP = "AISP";
  static final String RESTRICTION_TYPE_DESCRIPTION = "Test description";
  static final String ZERO_BALANCE = "0.00";
  static final String WARNING_CODE_VALID = "CA";
  static final LocalDateTime ACCOUNT1_OPENED_DATE_TIME = LocalDateTime.parse("2019-05-25T14:27:44");
  static final LocalDateTime ACCOUNT2_OPENED_DATE_TIME = LocalDateTime.parse("2020-05-24T14:45:01");
  static final long SAVING_TRANSACTION_SYSID_SYNCED_WITH_AUTHENTIC = 1032322191L;
  static final String LOCALHOST = "127.0.0.1";
  static final String WEB_SAVER = "Web Saver";
  static final String PARTY_ID_QUERY_PARAM = "?partyId=";
  static final String EUROPE_LONDON = "Europe/London";
  static final String RTYPE = "RTYPE";
  static final String MONTHLY_FREQUENCY = "Monthly";
  static final String WEBREC = "WEBREC";
  static final String WEBWDL = "WEBWDL";
  static final String TRANSACTION_ID = "917992000";
  static final String TRANSACTION_REFERENCE = "5000000003236732753020171220";
  static final String CREDIT = "Credit";
  static final String TRANSACTION_AMOUNT = "15.01";
  static final String AVAILABLE_BALANCE = "56.76";
  static final String LEDGER_BALANCE = "156.41";
  static final String VALID_WIT_CODE = "ROTS";
  static final String BALANCE_606_02 = "606.02";

  static final Country NON_UK_COUNTRY = Country.builder().code("SPA").isoCode("ES").build();
  static final Country UK_COUNTRY = Country.builder().code("UK").isoCode("GB").build();

  @Autowired private Clock clock;

  @Autowired private TransactionTemplate transactionTemplate;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  @Autowired private TestEntityManager coreTestEntityManager;

  @Autowired private TestEntityManager frontOfficeTestEntityManager;

  @Autowired private TestEntityManager copyTestEntityManager;

  @Autowired private TestEntityManager digitalAccountTestEntityManager;

  @Autowired private ObjectMapper objectMapper;

  @Autowired private PrivateKey jwtSigningPrivateKey;

  @Value("${spring.security.ybs.request-signature.signing.key-id}")
  private String requestSignatureSigningKeyId;

  private MockWebServer mockProductService;

  @Value("${uk.co.ybs.digital.product-test-port}")
  private int productTestPort;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  @Value("${uk.co.ybs.digital.authentic.banking.port}")
  private int authenticBankingTestPort;

  @Value("${uk.co.ybs.digital.authentic.webauth.port}")
  private int authenticWebAuthTestPort;

  private MockWebServer mockAuditService;

  private MockWebServer mockAuthenticBanking;

  private MockWebServer mockAuthenticWebAuth;

  static SavingAccountDetails createSavingAccountDetails(final LocalDate closedDate) {
    return createSavingAccountDetails(closedDate, "INTSAV");
  }

  static SavingAccountDetails createSavingAccountDetails(
      final LocalDate closedDate, final String productIdentifier) {
    return SavingAccountDetails.builder()
        .accountNumber(ACCOUNT_NUMBER_LONG)
        .currencyCode(GBP)
        .accountName("ACC_NAME1")
        .sortCode(123456)
        .productIdentifier(productIdentifier)
        .productType("SAVER")
        .productName("Internet Saver")
        .isPaymentAccount(true)
        .closedDate(closedDate)
        .brandCode(BRAND_CODE_YBS)
        .interestInstruction("Payaway")
        .nextInterestDate(LocalDate.of(2018, 9, 29))
        .interestFrequency(MONTHLY_FREQUENCY)
        .accountInterestFrequency(MONTHLY_FREQUENCY)
        .annualEquivalentRate("3.12")
        .interestRate("3.11")
        .build();
  }

  static Deposits createDeposits(
      final boolean permittedOverApi, final BigDecimal maxProductBalRemaining) {
    return createDeposits(permittedOverApi, null, maxProductBalRemaining, false);
  }

  static Deposits createDeposits(
      final boolean permittedOverApi,
      final BigDecimal availableDepositLimit,
      final BigDecimal maxProductBalRemaining,
      final boolean withRestrictions) {
    return createDeposits(
        permittedOverApi,
        false,
        availableDepositLimit,
        maxProductBalRemaining,
        withRestrictions,
        true,
        false,
        false);
  }

  @SuppressWarnings({"PMD.ExcessiveParameterList"}) // NOPMD
  static Deposits createDeposits(
      final boolean permittedOverApi,
      final boolean permittedByCard,
      final BigDecimal availableDepositLimit,
      final BigDecimal maxProductBalRemaining,
      final boolean withRestrictions,
      final boolean productAllowsInternalDeposits,
      final boolean productMigrationInProgress,
      final boolean accountClosed) {
    final Deposits.DepositsBuilder builder =
        Deposits.builder()
            .permittedOverApi(permittedOverApi)
            .permittedByCard(permittedByCard)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsInternalDeposits,
                    productMigrationInProgress,
                    withRestrictions,
                    accountClosed));

    if (withRestrictions) {
      builder.restrictions(
          Collections.singletonList(
              Restriction.builder()
                  .code(RestrictionCategory.DEPOSIT_DEFAULT)
                  .restrictionTypes(Collections.singleton(RTYPE))
                  .build()));
    }

    if (availableDepositLimit != null) {
      if (maxProductBalRemaining != null) {
        builder.limit(
            DepositLimit.builder()
                .available(availableDepositLimit)
                .maxProductBalRemaining(maxProductBalRemaining)
                .build());
      } else {
        builder.limit(DepositLimit.builder().available(availableDepositLimit).build());
      }
    } else if (maxProductBalRemaining != null) {
      builder.limit(DepositLimit.builder().maxProductBalRemaining(maxProductBalRemaining).build());
    }

    return builder.build();
  }

  static URI getURI(final String basePath, final String path, final int port) {
    return URI.create("http://localhost:" + port + BASE_PATH + basePath + path);
  }

  static URI getURI(
      final String basePath, final String path, final String queryParams, final int port) {
    return URI.create("http://localhost:" + port + BASE_PATH + basePath + path + queryParams);
  }

  static Consumer<HttpHeaders> standardHeaders(final UUID requestId, final String jwt) {
    return headers -> {
      standardHeaders(requestId).accept(headers);
      headers.setBearerAuth(jwt);
    };
  }

  static Consumer<HttpHeaders> standardHeaders(final UUID requestId) {
    return headers -> {
      headers.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON));
      headers.setHost(new InetSocketAddress("localhost", 0));
      headers.add(HEADER_REQUEST_ID, requestId.toString());
    };
  }

  @SuppressWarnings("PMD.ExcessiveParameterList") // NOPMD
  static SavingsTransactionLogEntry buildSavingsTransactionLog(
      final Long accountNumber,
      final String accountName,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final String status,
      final BigDecimal amount,
      final Long partyId) {
    return SavingsTransactionLogEntry.builder()
        .accountNumber(accountNumber)
        .targetAccountNumber(0L)
        .amount(amount)
        .transferIndicator(SavingsTransactionLogEntry.TRANSFER_INDICATOR_INTERNAL)
        .closure(SavingsTransactionLogEntry.CLOSURE_NO)
        .partySysId(partyId)
        .startTime(startDate)
        .endTime(endDate)
        .accountName(accountName)
        .status(status)
        .build();
  }

  static Product getProduct(
      final String identifier,
      final String description,
      final String type,
      final boolean smartTiered) {
    return Product.builder()
        .identifier(identifier)
        .description(description)
        .type(type)
        .smartTiered(smartTiered)
        .build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  static Matcher<WorkLog> workLogMatching(final WorkLog expected) {
    return allOf(
        samePropertyValuesAs(expected, "sysId", "message", "createdDate", "updatedDate"),
        hasProperty("sysId", notNullValue()),
        hasProperty("createdDate", notNullValue()),
        hasPropertyAtPath(
            "message.metadata",
            samePropertyValuesAs((Object) expected.getMessage().getMetadata(), "host")));
  }

  static WorkLog buildWorkLog(
      final UUID requestId,
      final String jwt,
      final WorkLog.Operation operation,
      final WorkLog.Status status) {
    final RequestMetadata requestMetadata =
        RequestMetadata.builder()
            .requestId(requestId)
            .ipAddress(LOCALHOST)
            .brandCode(BRAND_CODE_YBS)
            .partyId("12462951")
            .host(InetSocketAddress.createUnresolved("localhost/127.0.0.1", 0))
            .forwardingAuth(jwt)
            .build();
    return WorkLog.builder()
        .accountNumber(Long.valueOf(ACCOUNT_NUMBER))
        .operation(operation)
        .status(status)
        .createdBy("987654321")
        .updatedBy("987654321")
        .message(
            WorkLogRequest.builder()
                .workLogPayload(SubmitIsaDeclarationRequest.builder().build())
                .metadata(requestMetadata)
                .build())
        .build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  static Matcher<SavingsTransactionLogEntry> savingsTransactionLogMatching(
      final SavingsTransactionLogEntry expected) {
    return allOf(
        samePropertyValuesAs(expected, "sysId", "dailySequenceNumber", "startTime", "endTime"),
        hasProperty("sysId", notNullValue()),
        hasProperty("dailySequenceNumber", notNullValue()),
        hasProperty("startTime", notNullValue()));
  }

  static void stubGetSavingsAccountList(
      final SavingAccountDetailsListService savingAccountDetailsListService,
      final SavingAccountDetailsService savingAccountDetailsService) {

    final SavingAccountDetails accountDetails1 =
        SavingAccountDetails.builder()
            .accountNumber(2372146519L)
            .currencyCode(GBP)
            .accountName("CASSIDY")
            .sortCode(609204)
            .productIdentifier(EGG302A)
            .productName(WEB_SAVER)
            .isPaymentAccount(false)
            .brandCode(BRAND_CODE_YBS)
            .build();

    final SavingAccountDetails accountDetails2 =
        SavingAccountDetails.builder()
            .accountNumber(1234567890L)
            .currencyCode(GBP)
            .accountName("Holiday")
            .sortCode(123456)
            .productIdentifier(EGG302A)
            .productName(WEB_SAVER)
            .isPaymentAccount(false)
            .brandCode(BRAND_CODE_YBS)
            .build();

    final SavingAccountDetails accountDetails3 =
        SavingAccountDetails.builder()
            .accountNumber(2514552619L)
            .currencyCode(GBP)
            .accountName("HODGSON")
            .sortCode(609204)
            .productIdentifier(EGG302A)
            .productName(WEB_SAVER)
            .isPaymentAccount(false)
            .brandCode(BRAND_CODE_YBS)
            .build();

    final List<Long> accountNumbers =
        Arrays.asList(
            accountDetails1.getAccountNumber(),
            accountDetails2.getAccountNumber(),
            accountDetails3.getAccountNumber());

    when(savingAccountDetailsListService.getSavingsAccountList(any(), eq(false)))
        .thenReturn(accountNumbers);

    when(savingAccountDetailsService.getSavingAccountDetails(accountNumbers))
        .thenReturn(Arrays.asList(accountDetails1, accountDetails2, accountDetails3));
  }

  static void stubGetSavingsAccountListWithClosedAccount(
      final SavingAccountDetailsListService savingAccountDetailsListService,
      final SavingAccountDetailsService savingAccountDetailsService) {

    final SavingAccountDetails openAccount =
        SavingAccountDetails.builder()
            .accountNumber(2372146519L)
            .currencyCode(GBP)
            .accountName("CASSIDY")
            .sortCode(609204)
            .productIdentifier(EGG302A)
            .productName(WEB_SAVER)
            .isPaymentAccount(false)
            .brandCode(BRAND_CODE_YBS)
            .build();

    final SavingAccountDetails closedAccount =
        SavingAccountDetails.builder()
            .accountNumber(1234567890L)
            .currencyCode(GBP)
            .accountName("Holiday")
            .sortCode(123456)
            .productIdentifier(EGG302A)
            .productName(WEB_SAVER)
            .isPaymentAccount(false)
            .closedDate(LocalDate.of(2019, 11, 4))
            .brandCode(BRAND_CODE_YBS)
            .build();

    final List<Long> accountNumbers =
        Arrays.asList(openAccount.getAccountNumber(), closedAccount.getAccountNumber());

    when(savingAccountDetailsListService.getSavingsAccountList(any(), eq(true)))
        .thenReturn(accountNumbers);

    when(savingAccountDetailsService.getSavingAccountDetails(accountNumbers))
        .thenReturn(Arrays.asList(openAccount, closedAccount));
  }

  static Isa createIsa(final boolean subscribed) {
    return Isa.builder().flexible(false).helpToBuy(true).subscribed(subscribed).build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  static Product eggSavProduct() {
    return getProduct(EGG302A, "Internet Saver", "SAVER", false);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  static Product eggIsaProduct() {
    return getProduct(EGG302A, "ISA 1.20% FIXED RATE TO 29/02/2020 ANN", "ISA", false);
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  static Product intSavProduct() {
    return getProduct("INTSAV", "Internet Saver", "SAVER", false);
  }

  static LocalDateTime equalsOrWithinFiveSeconds(final LocalDateTime time) {
    final LocalDateTime maximumTime = time.plusSeconds(5);
    final ArgumentMatcher<LocalDateTime> argumentMatcher =
        argument -> !argument.isBefore(time) && !argument.isAfter(maximumTime);
    return argThat(argumentMatcher);
  }

  @SuppressWarnings("PMD.ExcessiveParameterList") // NOPMD
  static StatementTransaction buildStatementTransaction(
      final String transactionId,
      final String transactionReference,
      final String creditDebitIndicator,
      final LocalDateTime transactionDate,
      final String amount,
      final String availableBalance,
      final String ledgerBalance) {
    return StatementTransaction.builder()
        .accountNumber(Long.valueOf(ACCOUNT_NUMBER))
        .transactionId(Long.valueOf(transactionId))
        .transactionRef(transactionReference)
        .transactionIndicator(creditDebitIndicator)
        .status("Booked")
        .bookingDate(transactionDate)
        .valueDate(transactionDate)
        .transactionAmount(new BigDecimal(amount))
        .availableBalanceAfterTxn(new BigDecimal(availableBalance))
        .ledgerBalanceAfterTxn(new BigDecimal(ledgerBalance))
        .transactionMethod("DDIN")
        .transactionTypeCode("0010")
        .information("DIRECT DEBIT IN")
        .build();
  }

  static StatementTransactions createStatementTransactions(final LocalDateTime now) {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(2)
        .transactionList(
            Collections.singletonList(
                buildStatementTransaction(
                    TRANSACTION_ID,
                    TRANSACTION_REFERENCE,
                    CREDIT,
                    now,
                    TRANSACTION_AMOUNT,
                    AVAILABLE_BALANCE,
                    LEDGER_BALANCE)))
        .build();
  }

  static StatementTransactions createBufferStatementTransactionWithMultipleTransactions(
      final LocalDateTime now, final int numberOfTransactions) {
    return StatementTransactions.builder()
        .totalNumberOfPages((int) Math.ceil((double) numberOfTransactions / 10))
        .totalNumberOfTransactions(numberOfTransactions)
        .transactionList(
            Collections.singletonList(
                buildStatementTransaction(
                    TRANSACTION_ID,
                    TRANSACTION_REFERENCE,
                    CREDIT,
                    now,
                    TRANSACTION_AMOUNT,
                    AVAILABLE_BALANCE,
                    LEDGER_BALANCE)))
        .build();
  }

  static StatementTransactions createStatementTransactionsMultiple(final LocalDateTime now) {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(2)
        .transactionList(
            Arrays.asList(
                buildStatementTransaction(
                    TRANSACTION_ID,
                    TRANSACTION_REFERENCE,
                    CREDIT,
                    now,
                    TRANSACTION_AMOUNT,
                    AVAILABLE_BALANCE,
                    LEDGER_BALANCE),
                buildStatementTransaction(
                    "915388845",
                    "6000000003236732753020112345",
                    CREDIT,
                    now,
                    "20.01",
                    "200.50", // NOPMD
                    "150.20")))
        .build();
  }

  static StatementTransactions createStatementTransactions(
      final LocalDateTime now, final int numberOfTransactions) {
    List<StatementTransaction> statementTransactions = new ArrayList<>();
    IntStream.range(0, numberOfTransactions)
        .forEach(
            i ->
                statementTransactions.add(
                    buildStatementTransaction(
                        TRANSACTION_ID + i,
                        TRANSACTION_REFERENCE + i,
                        CREDIT,
                        now,
                        TRANSACTION_AMOUNT,
                        LEDGER_BALANCE,
                        LEDGER_BALANCE)));

    return StatementTransactions.builder()
        .totalNumberOfPages((int) Math.ceil((double) numberOfTransactions / 10))
        .totalNumberOfTransactions(numberOfTransactions)
        .transactionList(statementTransactions)
        .build();
  }

  static GroupedAccountListResponse createGroupedAccountListResponse(
      final Product productInfo,
      final boolean depositsPermitted,
      final boolean withdrawalsPermitted,
      final boolean amendmentRestriction) {
    final AccountSummary account1 =
        createGroupedAccountListResponseAccount3(
            productInfo, depositsPermitted, withdrawalsPermitted, amendmentRestriction);
    final AccountSummary account2 =
        createGroupedAccountListResponseAccount1(
            productInfo, depositsPermitted, withdrawalsPermitted, amendmentRestriction);
    final AccountSummary account3 =
        createGroupedAccountListResponseAccount2(
            productInfo, depositsPermitted, withdrawalsPermitted, amendmentRestriction);

    final List<AccountSummary> accountList = Arrays.asList(account1, account3, account2);

    final List<Balance> balances;
    if (withdrawalsPermitted) {
      balances =
          Arrays.asList(
              Balance.builder().type(INTERIM_AVAILABLE).amount(new BigDecimal("558.02")).build(),
              Balance.builder()
                  .type(INTERIM_BOOKED)
                  .amount(new BigDecimal(BALANCE_606_02))
                  .build());
    } else {
      balances =
          Collections.singletonList(
              Balance.builder()
                  .type(INTERIM_BOOKED)
                  .amount(new BigDecimal(BALANCE_606_02))
                  .build());
    }

    final GroupedAccountListResponse.AccountGroup other =
        GroupedAccountListResponse.AccountGroup.builder()
            .accounts(accountList)
            .balances(balances)
            .build();

    return GroupedAccountListResponse.builder().other(other).build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList") // NOPMD
  static GroupedAccountListResponse createGroupedAccountListResponse(
      final Product productInfo,
      final boolean depositsPermitted,
      final boolean withdrawalsPermitted,
      final boolean amendmentRestriction,
      final boolean productAllowsDepositOrWithdrawals,
      final boolean productMigrationInProgress,
      final boolean accountClosed,
      final boolean hasAccountWarnings) {
    final AccountSummary account1 =
        createGroupedAccountListResponseAccount3(
            productInfo,
            depositsPermitted,
            withdrawalsPermitted,
            amendmentRestriction,
            productAllowsDepositOrWithdrawals,
            productMigrationInProgress,
            accountClosed,
            hasAccountWarnings);
    final AccountSummary account2 =
        createGroupedAccountListResponseAccount1(
            productInfo,
            depositsPermitted,
            withdrawalsPermitted,
            amendmentRestriction,
            productAllowsDepositOrWithdrawals,
            productMigrationInProgress,
            accountClosed,
            hasAccountWarnings);
    final AccountSummary account3 =
        createGroupedAccountListResponseAccount2(
            productInfo,
            depositsPermitted,
            withdrawalsPermitted,
            amendmentRestriction,
            productAllowsDepositOrWithdrawals,
            productMigrationInProgress,
            accountClosed,
            hasAccountWarnings);
    final List<AccountSummary> accountList = Arrays.asList(account1, account3, account2);

    final List<Balance> balances;
    if (withdrawalsPermitted) {
      balances =
          Arrays.asList(
              Balance.builder().type(INTERIM_AVAILABLE).amount(new BigDecimal("558.02")).build(),
              Balance.builder()
                  .type(INTERIM_BOOKED)
                  .amount(new BigDecimal(BALANCE_606_02))
                  .build());
    } else {
      balances =
          Collections.singletonList(
              Balance.builder()
                  .type(INTERIM_BOOKED)
                  .amount(new BigDecimal(BALANCE_606_02))
                  .build());
    }

    final GroupedAccountListResponse.AccountGroup other =
        GroupedAccountListResponse.AccountGroup.builder()
            .accounts(accountList)
            .balances(balances)
            .build();

    return GroupedAccountListResponse.builder().other(other).build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList") // NOPMD
  static AccountSummary createGroupedAccountListResponseAccount1(
      final Product productInfo,
      final boolean depositsPermitted,
      final boolean withdrawalsPermitted,
      final boolean amendmentRestriction,
      final boolean productAllowsDepositOrWithdrawals,
      final boolean productMigrationInProgress,
      final boolean accountClosed,
      final boolean hasAccountWarnings) {
    return AccountSummary.builder()
        .accountNumber("2372146519")
        .accountName("CASSIDY")
        .amendmentRestriction(amendmentRestriction)
        .accountSortCode("609204")
        .externalAccountNumber("23721465")
        .currency(GBP)
        .openedDate(ACCOUNT1_OPENED_DATE_TIME.toLocalDate())
        .productIdentifier(productInfo.getIdentifier())
        .productDescription(productInfo.getDescription())
        .product(
            Product.builder()
                .identifier(productInfo.getIdentifier())
                .description(productInfo.getDescription())
                .type(productInfo.getType())
                .smartTiered(false)
                .build())
        .balances(
            withdrawalsPermitted
                ? Arrays.asList(
                    Balance.builder()
                        .amount(new BigDecimal("200.50")) // NOPMD
                        .type(INTERIM_AVAILABLE)
                        .build(),
                    Balance.builder()
                        .amount(new BigDecimal("150.20")) // NOPMD
                        .type(INTERIM_BOOKED)
                        .build())
                : Collections.singletonList(
                    Balance.builder()
                        .amount(new BigDecimal("150.20")) // NOPMD
                        .type(INTERIM_BOOKED)
                        .build()))
        .deposits(
            DepositsSummary.builder()
                .permittedOverApi(depositsPermitted)
                .permittedRules(
                    TestHelper.buildPermittedRules(
                        productAllowsDepositOrWithdrawals,
                        productMigrationInProgress,
                        hasAccountWarnings,
                        accountClosed))
                .build())
        .withdrawals(
            WithdrawalsSummary.builder()
                .permittedOverApi(withdrawalsPermitted)
                .permittedRules(
                    TestHelper.buildPermittedRules(
                        productAllowsDepositOrWithdrawals,
                        productMigrationInProgress,
                        hasAccountWarnings,
                        accountClosed))
                .build())
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList") // NOPMD
  static AccountSummary createGroupedAccountListResponseAccount2(
      final Product productInfo,
      final boolean depositsPermitted,
      final boolean withdrawalsPermitted,
      final boolean amendmentRestriction,
      final boolean productAllowsDepositOrWithdrawals,
      final boolean productMigrationInProgress,
      final boolean accountClosed,
      final boolean hasAccountWarnings) {
    return AccountSummary.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .accountName("Holiday")
        .amendmentRestriction(amendmentRestriction)
        .accountSortCode("123456")
        .externalAccountNumber("12345678")
        .currency(GBP)
        .openedDate(LocalDateTime.parse("2020-05-24T14:45:01").toLocalDate())
        .productIdentifier(productInfo.getIdentifier())
        .productDescription(productInfo.getDescription())
        .product(
            Product.builder()
                .identifier(productInfo.getIdentifier())
                .description(productInfo.getDescription())
                .type(productInfo.getType())
                .smartTiered(false)
                .build())
        .balances(
            withdrawalsPermitted
                ? Arrays.asList(
                    Balance.builder()
                        .amount(new BigDecimal("300.76"))
                        .type(INTERIM_AVAILABLE)
                        .build(),
                    Balance.builder().amount(new BigDecimal("299.41")).type(INTERIM_BOOKED).build())
                : Collections.singletonList(
                    Balance.builder()
                        .amount(new BigDecimal("299.41"))
                        .type(INTERIM_BOOKED)
                        .build()))
        .deposits(
            DepositsSummary.builder()
                .permittedOverApi(depositsPermitted)
                .permittedRules(
                    TestHelper.buildPermittedRules(
                        productAllowsDepositOrWithdrawals,
                        productMigrationInProgress,
                        hasAccountWarnings,
                        accountClosed))
                .build())
        .withdrawals(
            WithdrawalsSummary.builder()
                .permittedOverApi(withdrawalsPermitted)
                .permittedRules(
                    TestHelper.buildPermittedRules(
                        productAllowsDepositOrWithdrawals,
                        productMigrationInProgress,
                        hasAccountWarnings,
                        accountClosed))
                .build())
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList") // NOPMD
  static AccountSummary createGroupedAccountListResponseAccount3(
      final Product productInfo,
      final boolean depositsPermitted,
      final boolean withdrawalsPermitted,
      final boolean amendmentRestriction,
      final boolean productAllowsDepositOrWithdrawals,
      final boolean productMigrationInProgress,
      final boolean accountClosed,
      final boolean hasAccountWarnings) {
    return AccountSummary.builder()
        .accountNumber("2514552619")
        .accountName("HODGSON")
        .amendmentRestriction(amendmentRestriction)
        .accountSortCode("609204")
        .externalAccountNumber("25145526")
        .currency(GBP)
        .openedDate(LocalDateTime.parse("2020-05-24T14:45:01").toLocalDate())
        .productIdentifier(productInfo.getIdentifier())
        .productDescription(productInfo.getDescription())
        .product(
            Product.builder()
                .identifier(productInfo.getIdentifier())
                .description(productInfo.getDescription())
                .type(productInfo.getType())
                .smartTiered(false)
                .build())
        .balances(
            withdrawalsPermitted
                ? Arrays.asList(
                    Balance.builder()
                        .amount(new BigDecimal(AVAILABLE_BALANCE))
                        .type(INTERIM_AVAILABLE)
                        .build(),
                    Balance.builder()
                        .amount(new BigDecimal(LEDGER_BALANCE))
                        .type(INTERIM_BOOKED)
                        .build())
                : Collections.singletonList(
                    Balance.builder()
                        .amount(new BigDecimal(LEDGER_BALANCE))
                        .type(INTERIM_BOOKED)
                        .build()))
        .deposits(
            DepositsSummary.builder()
                .permittedOverApi(depositsPermitted)
                .permittedRules(
                    TestHelper.buildPermittedRules(
                        productAllowsDepositOrWithdrawals,
                        productMigrationInProgress,
                        hasAccountWarnings,
                        accountClosed))
                .build())
        .withdrawals(
            WithdrawalsSummary.builder()
                .permittedOverApi(withdrawalsPermitted)
                .permittedRules(
                    TestHelper.buildPermittedRules(
                        productAllowsDepositOrWithdrawals,
                        productMigrationInProgress,
                        hasAccountWarnings,
                        accountClosed))
                .build())
        .build();
  }

  static AccountSummary createGroupedAccountListResponseAccount1(
      final Product productInfo,
      final boolean depositsPermitted,
      final boolean withdrawalsPermitted,
      final boolean amendmentRestriction) {
    return createGroupedAccountListResponseAccount1(
        productInfo,
        depositsPermitted,
        withdrawalsPermitted,
        amendmentRestriction,
        true,
        false,
        false,
        false);
  }

  static AccountSummary createGroupedAccountListResponseAccount2(
      final Product productInfo,
      final boolean depositsPermitted,
      final boolean withdrawalsPermitted,
      final boolean amendmentRestriction) {
    return createGroupedAccountListResponseAccount2(
        productInfo,
        depositsPermitted,
        withdrawalsPermitted,
        amendmentRestriction,
        true,
        false,
        false,
        false);
  }

  static AccountSummary createGroupedAccountListResponseAccount3(
      final Product productInfo,
      final boolean depositsPermitted,
      final boolean withdrawalsPermitted,
      final boolean amendmentRestriction) {
    return createGroupedAccountListResponseAccount3(
        productInfo,
        depositsPermitted,
        withdrawalsPermitted,
        amendmentRestriction,
        true,
        false,
        false,
        false);
  }

  @BeforeEach
  void setUp() throws IOException {
    mockProductService = new MockWebServer();
    mockProductService.start(productTestPort);
    mockAuditService = new MockWebServer();
    mockAuditService.start(auditTestPort);
    mockAuthenticBanking = new MockWebServer();
    mockAuthenticBanking.start(authenticBankingTestPort);
    mockAuthenticWebAuth = new MockWebServer();
    mockAuthenticWebAuth.start(authenticWebAuthTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockProductService.shutdown();
    mockAuditService.shutdown();
    mockAuthenticBanking.shutdown();
    mockAuthenticWebAuth.shutdown();
    tearDownDb();
  }

  RestrictionType setUpRestrictionType(
      final String code,
      final Long rTypSysId,
      final Long rTypRule1SysId,
      final Long rTypRule2SysId) {
    return transactionTemplate.execute(
        status -> {
          final RestrictionType restrictionType =
              adgCoreTestEntityManager.persist(
                  RestrictionType.builder()
                      .sysId(rTypSysId)
                      .code(code)
                      .description(RESTRICTION_TYPE_DESCRIPTION)
                      .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                      .build());

          adgCoreTestEntityManager.persist(
              RestrictionTypeRule.builder()
                  .sysId(rTypRule1SysId)
                  .code(WEBREC)
                  .restrictionType(restrictionType)
                  .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                  .build());
          adgCoreTestEntityManager.persist(
              RestrictionTypeRule.builder()
                  .sysId(rTypRule2SysId)
                  .code(WEBWDL)
                  .restrictionType(restrictionType)
                  .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                  .build());
          return restrictionType;
        });
  }

  RestrictionType setUpRestrictionType(
      final String code, final Long rTypSysId, final Long rTypRuleSysId, final String ruleCode) {
    return transactionTemplate.execute(
        status -> {
          final RestrictionType restrictionType =
              adgCoreTestEntityManager.persist(
                  RestrictionType.builder()
                      .sysId(rTypSysId)
                      .code(code)
                      .description(RESTRICTION_TYPE_DESCRIPTION)
                      .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                      .build());

          adgCoreTestEntityManager.persist(
              RestrictionTypeRule.builder()
                  .sysId(rTypRuleSysId)
                  .code(ruleCode)
                  .restrictionType(restrictionType)
                  .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                  .build());
          return restrictionType;
        });
  }

  AccountAccessRequiredEntities setUpAccountAccessRequiredEntities(
      final Long accountNumberRequired, final String... activityTypeGroupCodes) {
    return setUpAccountAccessRequiredEntities(
        PARTY_ID, accountNumberRequired, activityTypeGroupCodes);
  }

  void setUpAccountAccessRequiredEntitiesForOtherActivityPlayer(
      final Long accountNumberRequired, final String... activityTypeGroupCodes) {

    final Set<String> allActivityTypeGroupCodes =
        new HashSet<>(Arrays.asList(activityTypeGroupCodes));
    allActivityTypeGroupCodes.add(ACTIVITY_GROUP_CODE_AISP);

    final ActivityType activityType =
        setUpActivityType(
            ACTIVITY_TYPE_CODE_SIGNATORY, allActivityTypeGroupCodes.toArray(new String[] {}));
    setUpActivityPlayer(activityType, 3L, accountNumberRequired, Long.valueOf(PARTY_ID_OTHER));
  }

  AccountAccessRequiredEntities setUpAccountAccessRequiredEntities(
      final String partyId,
      final Long accountNumberRequired,
      final String... activityTypeGroupCodes) {
    final SavingProduct savingProduct = setUpSavingProduct(PRODUCT_SYS_ID);
    final AccountNumber accountNumber = setUpAccountNumber(accountNumberRequired, savingProduct);

    final Set<String> allActivityTypeGroupCodes =
        new HashSet<>(Arrays.asList(activityTypeGroupCodes));
    allActivityTypeGroupCodes.add(ACTIVITY_GROUP_CODE_AISP);

    final ActivityType activityType =
        setUpActivityType(
            ACTIVITY_TYPE_CODE_MHLDRS, allActivityTypeGroupCodes.toArray(new String[] {}));
    setUpActivityPlayer(activityType, 1L, accountNumberRequired, Long.valueOf(partyId));

    return new AccountAccessRequiredEntities(savingProduct, accountNumber);
  }

  AccountAccessRequiredEntities setUpAccountAccessRequiredEntitiesForSubscriptionToOtherIsa(
      final String partyId,
      final Long accountNumberRequired,
      final String... activityTypeGroupCodes) {
    final SavingProduct savingProduct = setUpSavingProduct(ISA_PRODUCT_SYS_ID);
    final AccountNumber accountNumber = setUpAccountNumber(accountNumberRequired, savingProduct);

    final Set<String> allActivityTypeGroupCodes =
        new HashSet<>(Arrays.asList(activityTypeGroupCodes));
    allActivityTypeGroupCodes.add(ACTIVITY_GROUP_CODE_AISP);

    final ActivityType activityType =
        setUpActivityType(
            ACTIVITY_TYPE_CODE_BENOWN, allActivityTypeGroupCodes.toArray(new String[] {}));
    setUpActivityPlayer(activityType, 2L, accountNumberRequired, Long.valueOf(partyId));

    setupTessaDetailsWithDateFirstSub(accountNumberRequired);

    return new AccountAccessRequiredEntities(savingProduct, accountNumber);
  }

  SavingProduct setUpSavingProduct(final Long productSysId) {
    return transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                new SavingProduct(productSysId, BRAND_CODE_YBS, "PROD_IDENT")));
  }

  AccountNumber setUpAccountNumber(final Long accountNumber, final SavingProduct savingProduct) {
    return transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                new AccountNumber(
                    accountNumber, AccountNumber.TABLE_ID_SAVACC, savingProduct.getSysid())));
  }

  void setUpActivityPlayer(
      final ActivityType activityType,
      final Long sysId,
      final Long accountNumber,
      final Long partyId) {
    transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                new ActivityPlayer(
                    sysId,
                    ACTIVITY_PLAYER_TABLE_ID,
                    accountNumber,
                    partyId,
                    activityType,
                    LocalDateTime.now(clock).truncatedTo(ChronoUnit.SECONDS),
                    null)));
  }

  @SuppressWarnings("PMD.AvoidInstantiatingObjectsInLoops")
  ActivityType setUpActivityType(
      final String activityType, final String... activityTypeGroupCodes) {
    return transactionTemplate.execute(
        status -> {
          final ActivityType type =
              adgCoreTestEntityManager.persist(
                  new ActivityType(
                      activityType,
                      LocalDateTime.now(clock).truncatedTo(ChronoUnit.SECONDS),
                      null));
          for (final String code : activityTypeGroupCodes) {
            adgCoreTestEntityManager.persist(
                new ActivityTypeGroup(
                    code, type, LocalDateTime.now(clock).truncatedTo(ChronoUnit.SECONDS), null));
          }
          adgCoreTestEntityManager.flush();
          return type;
        });
  }

  Metadata setupCopyDbMetadata(final LocalDateTime copyDbUpdateTime) {
    return transactionTemplate.execute(
        status ->
            copyTestEntityManager.persistAndFlush(
                Metadata.builder().sysId(1234567890L).created(copyDbUpdateTime).build()));
  }

  void stubAuthenticGetBalanceCall(final String response) throws IOException {
    mockAuthenticBanking.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(readClassPathResource(response)));
  }

  void setupAccountWarning(
      final Long sysId, final AccountNumber accountNumber, final RestrictionType restrictionType) {
    transactionTemplate.executeWithoutResult(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                AccountWarning.builder()
                    .sysId(sysId)
                    .accountNumber(accountNumber)
                    .restrictionType(restrictionType)
                    .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                    .build()));
  }

  void setupPartyAddress(final Long sysId, final Long partyId, final Country country) {
    final Party party = Party.builder().sysId(partyId).build();
    final AddressUsage addressUsage =
        AddressUsage.builder()
            .sysId(sysId)
            .postalAddress(PostalAddress.builder().sysId(sysId).country(country).build())
            .party(party)
            .preferredContactMethod(true)
            .startDate(LocalDateTime.now(clock))
            .build();
    transactionTemplate.executeWithoutResult(
        status -> {
          adgCoreTestEntityManager.persist(party);
          adgCoreTestEntityManager.persist(addressUsage.getPostalAddress().getCountry());
          adgCoreTestEntityManager.persist(addressUsage.getPostalAddress());
          adgCoreTestEntityManager.persist(addressUsage);
        });
  };

  void setupOpenSavingAccount(final Long accountNumber) {
    setupSavingAccount(
        accountNumber,
        ACCOUNT1_OPENED_DATE_TIME,
        null,
        new BigDecimal("201.98"),
        new BigDecimal("147"));
  }

  void setupSavingAccountRefersToSignatureCard(final Long accountNumber) {
    setupOpenSavingAccountWithWitCode(accountNumber, "CONV");
  }

  void setupOpenSavingAccountWithWitCode(final Long accountNumber, final String witCode) {
    transactionTemplate.executeWithoutResult(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                new SavingAccount(
                    accountNumber,
                    ACCOUNT1_OPENED_DATE_TIME,
                    null,
                    new BigDecimal("201.98"),
                    new BigDecimal("147"),
                    witCode)));
  }

  void setupSavingAccount(
      final Long accountNumber,
      final LocalDateTime openedDate,
      final LocalDateTime closedDate,
      final BigDecimal interimAvailable,
      final BigDecimal interimBooked) {
    transactionTemplate.executeWithoutResult(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                new SavingAccount(
                    accountNumber, openedDate, closedDate, interimAvailable, interimBooked, "ED")));
  }

  void setupSavingAccount(
      final Long accountNumber,
      final LocalDateTime openedDate,
      final LocalDateTime closedDate,
      final BigDecimal interimAvailable,
      final BigDecimal interimBooked,
      final String witCode) {
    transactionTemplate.executeWithoutResult(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                new SavingAccount(
                    accountNumber, openedDate, closedDate, interimAvailable, interimBooked, "ED")));
  }

  void stubMockProductServiceResponse(final Resource resource) throws IOException {
    mockProductService.enqueue(
        new MockResponse()
            .setHeader("Content-Type", "application/json")
            .setBody(readClassPathResource(resource)));
  }

  void stubMockAuditServiceResponse() {
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }

  void assertAccountDetails(final boolean expectAudit, final UUID requestId, final String jwt)
      throws InterruptedException, JsonProcessingException {
    assertAccountDetails(expectAudit, requestId, jwt, "INTSAV");
  }

  void assertAccountDetails(
      final boolean expectAudit,
      final UUID requestId,
      final String jwt,
      final String productIdentifier)
      throws InterruptedException, JsonProcessingException {
    assertProductServiceCall(requestId, jwt, "/product/private/product/" + productIdentifier);
    if (expectAudit) {
      assertAuditAccountDetails(requestId, jwt);
    }
  }

  void assertProductServiceCall(final UUID requestId, final String jwt, final String path)
      throws InterruptedException {
    final RecordedRequest request = mockProductService.takeRequest();
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.AUTHORIZATION), endsWith(jwt));
    assertThat(request.getHeader(HttpHeaders.HOST), equalTo("localhost:" + productTestPort));
    assertThat(request.getHeader(HEADER_REQUEST_ID), equalTo(requestId.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(
        request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID),
        is(equalTo(requestSignatureSigningKeyId)));
  }

  void assertAuditAccountDetails(final UUID requestId, final String jwt)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is("/audit/account/detail"));
    assertThat(request.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditAccountDetailsRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditAccountDetailsRequest.class);
    assertThat(
        actual,
        is(
            AuditAccountDetailsRequest.builder()
                .ipAddress(LOCALHOST)
                .accountInformation(
                    AuditAccountDetailsRequest.AccountInformation.builder()
                        .accountNumber(ACCOUNT_NUMBER)
                        .build())
                .build()));
  }

  RestrictionType setUpRestrictionTypeRuleWithRestrictionType(
      final String code, final Long rTypSysId, final Long rTypRuleSysId, final String ruleCode) {
    return transactionTemplate.execute(
        status -> {
          final RestrictionType restrictionType =
              adgCoreTestEntityManager.persist(
                  RestrictionType.builder()
                      .sysId(rTypSysId)
                      .code(code)
                      .description(RESTRICTION_TYPE_DESCRIPTION)
                      .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                      .build());

          adgCoreTestEntityManager.persist(
              RestrictionTypeRule.builder()
                  .sysId(rTypRuleSysId)
                  .code(ruleCode)
                  .restrictionType(restrictionType)
                  .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                  .build());

          return restrictionType;
        });
  }

  @SuppressWarnings("UnusedReturnValue")
  uk.co.ybs.digital.account.model.core.RestrictionType setUpRestrictionTypeCore(
      final String code, final Long rTypSysId) {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persist(
                uk.co.ybs.digital.account.model.core.RestrictionType.builder()
                    .sysId(rTypSysId)
                    .code(code)
                    .startDate(LocalDateTime.now(clock).plusSeconds(-1))
                    .build()));
  }

  void setUpAccountsWithPendingIsaDeclaration(
      final Long accountNumber, final LocalDateTime startTime, final LocalDateTime endTime) {
    transactionTemplate.executeWithoutResult(
        status ->
            frontOfficeTestEntityManager.persistAndFlush(
                buildSavingsTransactionLog(
                    accountNumber,
                    null,
                    startTime,
                    endTime,
                    SavingsTransactionLogEntry.STATUS_ISA_DECLARATION,
                    BigDecimal.TEN,
                    12345L)));
  }

  void setUpSavingsTransactionLog(final SavingsTransactionLogEntry savingsTransactionLogEntry) {
    transactionTemplate.executeWithoutResult(
        status -> frontOfficeTestEntityManager.persistAndFlush(savingsTransactionLogEntry));
  }

  void stubAuthenticGetTransactionsCall(final String response) throws IOException {
    mockAuthenticWebAuth.enqueue(
        new MockResponse()
            .setResponseCode(HttpStatus.OK.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML)
            .setBody(
                readClassPathResource(response)
                    .replaceAll(
                        Pattern.quote("{transaction.date.placeholder}"),
                        LocalDateTime.now(clock)
                            .plusSeconds(1L)
                            .truncatedTo(ChronoUnit.SECONDS)
                            .toString())));
  }

  void setUpProductMigrationInProgress(final Long accountNumber) {
    transactionTemplate.executeWithoutResult(
        status -> {
          final LocalDateTime yesterday = LocalDateTime.now(clock).minusDays(1);
          frontOfficeTestEntityManager.persistAndFlush(
              buildSavingsTransactionLog(
                  accountNumber,
                  null,
                  yesterday,
                  yesterday,
                  SavingsTransactionLogEntry.STATUS_PRODUCT_TRANSFER_START,
                  BigDecimal.TEN,
                  12345L));
        });
  }

  void setUpAnnualWithdrawalLimits(
      final Long sysId,
      final int withdrawalsMade,
      final AccountNumber accountNumber,
      final SavingProduct savingProduct) {
    transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                new SavingAccountAnnualWithdrawalLimit(
                    sysId,
                    accountNumber,
                    savingProduct.getSysid(),
                    WITHDRAWAL_LIMIT,
                    withdrawalsMade,
                    WITHDRAWAL_LIMIT_START_DATE)));
  }

  void assertNoWorkLogs() {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              digitalAccountTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from WorkLog e");
          @SuppressWarnings("unchecked") // NOPMD
          final List<WorkLog> actual = query.getResultList();
          assertThat(actual.isEmpty(), is(true));
        });
  }

  void assertWorkLogsWithCount(final Integer logCount, final Matcher<WorkLog> expected) {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              digitalAccountTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from WorkLog e");
          @SuppressWarnings("unchecked") // NOPMD
          final List<WorkLog> actual = query.getResultList();
          assertThat(actual.size(), is(logCount));
          assertThat(actual, hasItems(expected));
        });
  }

  void assertSavingsTransactionLogsWithCount(
      final Integer logCount, final Matcher<SavingsTransactionLogEntry> expected) {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              frontOfficeTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from SavingsTransactionLogEntry e");
          @SuppressWarnings("unchecked")
          final List<SavingsTransactionLogEntry> actual = query.getResultList();
          assertThat(actual.size(), is(logCount));
          assertThat(actual, hasItems(expected));
        });
  }

  void assertNoSavingsTransactionsLogs() {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              frontOfficeTestEntityManager
                  .getEntityManager()
                  .createQuery("select e from SavingsTransactionLogEntry e");
          @SuppressWarnings("unchecked")
          final List<SavingsTransactionLogEntry> actual = query.getResultList();
          assertThat(actual.isEmpty(), is(true));
        });
  }

  AccountAccessRequiredEntities setUpAccountAccessRequiredEntitiesParties(
      final Long accountNumberRequired, final String... activityTypeGroupCodes) {
    return setUpAccountAccessRequiredEntities(
        PARTY_ID_ACCOUNTS, accountNumberRequired, activityTypeGroupCodes);
  }

  void setUpAispAndPispActivityPlayers(final Long... accountNumbers) {
    final ActivityType activityType =
        setUpActivityType(
            ACTIVITY_TYPE_CODE_MHLDRS, ACTIVITY_GROUP_CODE_AISP, ACTIVITY_GROUP_CODE_PISP);
    for (int index = 0; index < accountNumbers.length; index++) {
      setUpActivityPlayer(
          activityType, (long) (index + 1), accountNumbers[index], Long.valueOf(PARTY_ID));
    }
  }

  @SuppressWarnings("UnusedReturnValue")
  uk.co.ybs.digital.account.model.core.SavingAccount setUpSavingAccountCore(
      final Long accountNumber) {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                uk.co.ybs.digital.account.model.core.SavingAccount.builder()
                    .accountNumber(accountNumber)
                    .build()));
  }

  @SuppressWarnings("UnusedReturnValue")
  uk.co.ybs.digital.account.model.core.AccountNumber setUpAccountNumberCore(
      final Long accountNumber,
      final uk.co.ybs.digital.account.model.core.SavingProduct savingProduct) {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                new uk.co.ybs.digital.account.model.core.AccountNumber(
                    accountNumber, AccountNumber.TABLE_ID_SAVACC, savingProduct.getSysid())));
  }

  uk.co.ybs.digital.account.model.core.SavingProduct setUpSavingProductCore(
      final Long productSysId) {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                new uk.co.ybs.digital.account.model.core.SavingProduct(
                    productSysId, BRAND_CODE_YBS)));
  }

  void tearDownDb() {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager adgCoreEntityManager = adgCoreTestEntityManager.getEntityManager();
          final EntityManager coreEntityManager = coreTestEntityManager.getEntityManager();

          coreEntityManager.createQuery("delete from WarningNote").executeUpdate();
          coreEntityManager.createQuery("delete from AccountWarning").executeUpdate();
          coreEntityManager.createQuery("delete from RestrictionType").executeUpdate();
          coreEntityManager.createQuery("delete from SavingAccount").executeUpdate();
          coreEntityManager.createQuery("delete from AccountNumber").executeUpdate();
          coreEntityManager.createQuery("delete from SavingProduct").executeUpdate();
          coreEntityManager.createQuery("delete from SavingAccountHistory").executeUpdate();

          adgCoreEntityManager.createQuery("delete from ActivityPlayer").executeUpdate();
          adgCoreEntityManager.createQuery("delete from ActivityTypeGroup").executeUpdate();
          adgCoreEntityManager.createQuery("delete from ActivityType").executeUpdate();
          adgCoreEntityManager
              .createQuery("delete from SavingAccountAnnualWithdrawalLimit")
              .executeUpdate();
          adgCoreEntityManager.createQuery("delete from SavingTransaction").executeUpdate();
          adgCoreEntityManager.createQuery("delete from AccountWarning").executeUpdate();
          adgCoreEntityManager.createQuery("delete from RestrictionTypeRule").executeUpdate();
          adgCoreEntityManager.createQuery("delete from RestrictionType").executeUpdate();
          adgCoreEntityManager.createQuery("delete from TessaDetails").executeUpdate();
          adgCoreEntityManager.createQuery("delete from SavingAccount").executeUpdate();
          adgCoreEntityManager.createQuery("delete from AccountNumber").executeUpdate();
          adgCoreEntityManager.createQuery("delete from SavingProduct").executeUpdate();

          adgCoreEntityManager.createQuery("delete from PostalAddress").executeUpdate();
          adgCoreEntityManager.createQuery("delete from AddressUsage").executeUpdate();
          adgCoreEntityManager.createQuery("delete from Country").executeUpdate();

          final EntityManager frontOfficeEntityManager =
              frontOfficeTestEntityManager.getEntityManager();
          frontOfficeEntityManager
              .createQuery("delete from SavingsTransactionLogEntry")
              .executeUpdate();

          final EntityManager copyEntityManager = copyTestEntityManager.getEntityManager();
          copyEntityManager.createQuery("delete from Metadata").executeUpdate();

          final EntityManager digitalAccountEntityManager =
              digitalAccountTestEntityManager.getEntityManager();
          digitalAccountEntityManager.createQuery("delete from WorkLog").executeUpdate();
        });
  }

  void setupSavingTransaction(
      final Long sysId,
      final Long accountNumber,
      final LocalDateTime today,
      final BigDecimal amount) {
    transactionTemplate.executeWithoutResult(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                new SavingTransaction(
                    sysId,
                    accountNumber,
                    "R",
                    "0001",
                    today,
                    today,
                    amount,
                    new BigDecimal("0.155"),
                    new BigDecimal("0.155"))));
  }

  void setupTessaDetailsWithDateFirstSub(final Long accountNumber) {
    transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                TessaDetails.builder()
                    .sysid(1L)
                    .accountNumber(accountNumber)
                    .tessaYear(22)
                    .dateFirstSub(LocalDateTime.now(clock).minusDays(2))
                    .amountInvested(new BigDecimal(2))
                    .createdDate(
                        LocalDateTime.now(clock)
                            .minusSeconds(20)) // Will cause tests to fail for ~20 seconds a year
                    .build()));
  }

  void setupTessaDetails(final Long accountNumber) {
    transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                TessaDetails.builder()
                    .sysid(1L)
                    .accountNumber(accountNumber)
                    .tessaYear(22)
                    .amountInvested(new BigDecimal(2))
                    .createdDate(
                        LocalDateTime.now(clock)
                            .minusSeconds(20)) // Will cause tests to fail for ~20 seconds a year
                    .build()));
  }

  String createValidYbsJwt() {
    return createYbsJwtWithScope(ACCOUNT_READ_SCOPE);
  }

  String createYbsJwtWithScope(final String scope) {
    return createJwt(PARTY_ID, scope, BRAND_CODE_YBS);
  }

  String createValidSystemYbsJwt() {
    return createSystemYbsJwtWithScope(ACCOUNT_READ_SCOPE);
  }

  String createSystemYbsJwtWithScope(final String scope) {
    return createJwt(IntegrationTestJwtFactory.systemClaimsMap(PARTY_ID, scope, BRAND_CODE_YBS));
  }

  String createYbsJwtWithSessionId(final String sessionId) {
    return createJwt(
        IntegrationTestJwtFactory.claimsMap(
            IntegrationTestJwtFactory.SUBTYPE_CUSTOMER,
            PARTY_ID,
            ACCOUNT_READ_SCOPE,
            BRAND_CODE_YBS,
            sessionId));
  }

  String createYbsJwtWithoutSessionId() {
    return createJwt(
        IntegrationTestJwtFactory.invalidCustomerClaimsMap(
            PARTY_ID, ACCOUNT_READ_SCOPE, BRAND_CODE_YBS));
  }

  String createJwt(final String partyId, final String scope, final String brandCode) {
    return createJwt(IntegrationTestJwtFactory.customerClaimsMap(partyId, scope, brandCode));
  }

  String createJwt(final Map<String, Object> claims) {
    return IntegrationTestJwtFactory.createJwt(claims, jwtSigningPrivateKey);
  }

  void assertAuditAccountList(final UUID requestId, final String jwt)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is("/audit/account/list"));
    assertThat(request.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditAccountListRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditAccountListRequest.class);
    assertThat(actual, is(AuditAccountListRequest.builder().ipAddress(LOCALHOST).build()));
  }

  void assertAuditAccountTransactions(
      final UUID requestId, final String jwt, final String startDate, final String endDate)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is("/audit/account/transactions"));
    assertThat(request.getHeader(HttpHeaders.AUTHORIZATION), is("Bearer " + jwt));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditAccountTransactionsRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditAccountTransactionsRequest.class);
    assertThat(
        actual,
        is(
            AuditAccountTransactionsRequest.builder()
                .ipAddress(LOCALHOST)
                .accountInformation(
                    AuditAccountTransactionsRequest.AccountInformation.builder()
                        .accountNumber(ACCOUNT_NUMBER)
                        .startDate(startDate)
                        .endDate(endDate)
                        .build())
                .build()));
  }

  void mockProductServiceInternalServerError() {
    mockProductService.enqueue(new MockResponse().setResponseCode(500));
  }
}
