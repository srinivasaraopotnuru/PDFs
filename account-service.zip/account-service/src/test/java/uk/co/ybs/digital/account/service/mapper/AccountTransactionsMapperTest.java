package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AccountTransactionMapperException;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransaction;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactions;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType.BalanceConstants;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransaction;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransactions;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse.TransactionCode;
import uk.co.ybs.digital.account.web.dto.Balance;

@ExtendWith(MockitoExtension.class)
class AccountTransactionsMapperTest {

  private AccountTransactionsMapper mapper;

  @Mock private BalanceMapper balanceMapper;

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-05-26T13:45:01Z"), ZoneId.of("GMT"));
  private static final String ACCOUNT_NUMBER = "1234567890";
  private static final String CREDIT_INDICATOR = "Credit";
  private static final String DEBIT_INDICATOR = "Debit";
  private static final String STATEMENT_CREDIT_INDICATOR = "R";
  private static final String STATUS_BOOKED = "Booked";
  private static final String TRANSACTION_INFORMATION = "TransactionInformation";

  @BeforeEach
  void beforeEach() {
    mapper = new AccountTransactionsMapper(balanceMapper);
  }

  @ParameterizedTest
  @MethodSource("mapsOnlyStatementTransactionsToAccountTransactionsResponse")
  void mapsStatementTransactionsAndEmptyAuthenticTransactionsToAccountTransactionsResponse(
      final StatementTransactions statementTransactions,
      final AccountTransactionsResponse expectedAccountTransactionsResponse) {
    when(balanceMapper.filterAndMapAccountBalanceTypeList(createTransactionBalances()))
        .thenReturn(createExpectedBalances());
    when(balanceMapper.filterAndMapAccountBalanceTypeList(createTransactionBalances2()))
        .thenReturn(createExpectedBalances2());

    final AccountTransactionsResponse mapped =
        mapper.getTransactionsToResponse(
            AuthenticTransactions.builder()
                .totalNumberOfRecords(0)
                .transactionList(Collections.emptyList())
                .build(),
            statementTransactions);

    assertThat(expectedAccountTransactionsResponse, is(mapped));
  }

  @ParameterizedTest
  @MethodSource("mapsOnlyStatementTransactionsToAccountTransactionsResponse")
  void mapsOnlyStatementTransactionsToAccountTransactionsResponse(
      final StatementTransactions statementTransactions,
      final AccountTransactionsResponse expectedAccountTransactionsResponse) {
    when(balanceMapper.filterAndMapAccountBalanceTypeList(createTransactionBalances()))
        .thenReturn(createExpectedBalances());
    when(balanceMapper.filterAndMapAccountBalanceTypeList(createTransactionBalances2()))
        .thenReturn(createExpectedBalances2());

    final AccountTransactionsResponse mapped =
        mapper.getTransactionsToResponse(statementTransactions);

    assertThat(expectedAccountTransactionsResponse, is(mapped));
  }

  @ParameterizedTest
  @MethodSource("mapsExtraAuthenticTransactionsToAccountTransactionsResponse")
  void mapsTransactionsToAccountTransactionsResponseWithExtraAuthenticTransactions(
      final AuthenticTransactions unlinkedTransactions,
      final StatementTransactions statementTransactions,
      final AccountTransactionsResponse expectedAccountTransactionsResponse,
      final int extraAuthenticTransactions,
      final String expectedBalanceOne,
      final String expectedBalanceTwo) {

    when(balanceMapper.filterAndMapAccountBalanceTypeList(
            createTransactionBalancesAuthentic(new BigDecimal(expectedBalanceOne))))
        .thenReturn(createExpectedBalancesAuthentic(expectedBalanceOne));

    if (extraAuthenticTransactions == 2) {
      when(balanceMapper.filterAndMapAccountBalanceTypeList(
              createTransactionBalancesAuthentic(new BigDecimal(expectedBalanceTwo))))
          .thenReturn(createExpectedBalancesAuthentic(expectedBalanceTwo));
    }

    when(balanceMapper.filterAndMapAccountBalanceTypeList(createTransactionBalances()))
        .thenReturn(createExpectedBalances());
    when(balanceMapper.filterAndMapAccountBalanceTypeList(createTransactionBalances2()))
        .thenReturn(createExpectedBalances2());

    final AccountTransactionsResponse mapped =
        mapper.getTransactionsToResponse(unlinkedTransactions, statementTransactions);

    assertThat(expectedAccountTransactionsResponse, is(mapped));
  }

  @Test
  void mapsTransactionsToAccountTransactionsResponseWithOnlyAuthenticTransactions() {

    final OffsetDateTime now = OffsetDateTime.now(CLOCK);
    final Instant nowAsInstant = Instant.from(now);

    final AuthenticTransactions authenticTransactions =
        createAuthenticTransactionsWithTwoExtraRecordsDebitLatest();
    final StatementTransactions statementTransactions =
        StatementTransactions.builder()
            .totalNumberOfPages(1)
            .totalNumberOfTransactions(0)
            .transactionList(Collections.emptyList())
            .build();
    final AccountTransactionsResponse expectedResponse =
        createAccountTransactionsResponseWithOnlyAuthenticRecords(nowAsInstant);

    expectedResponse
        .getTransactions()
        .forEach(
            txn ->
                txn.getBalances()
                    .forEach(
                        balance ->
                            when(balanceMapper.filterAndMapAccountBalanceTypeList(
                                    createTransactionBalancesAuthentic(balance.getAmount())))
                                .thenReturn(
                                    createExpectedBalancesAuthentic(
                                        balance.getAmount().toString()))));

    final AccountTransactionsResponse mapped =
        mapper.getTransactionsToResponse(authenticTransactions, statementTransactions);

    assertThat(expectedResponse, is(mapped));
  }

  @Test
  void shouldRaiseAccountTransactionsMapperExceptionWhenInvalidCreditDebitCriteria() {
    final StatementTransaction transaction =
        StatementTransaction.builder()
            .accountNumber(Long.valueOf(ACCOUNT_NUMBER))
            .transactionId(Long.valueOf("915388845")) // NOPMD
            .transactionRef("TxnDesc 915388845")
            .transactionIndicator("X")
            .status(STATUS_BOOKED)
            .bookingDate(LocalDateTime.now(CLOCK))
            .transactionAmount(new BigDecimal("0.00"))
            .availableBalanceAfterTxn(new BigDecimal("200.50")) // NOPMD
            .ledgerBalanceAfterTxn(new BigDecimal("150.20")) // NOPMD
            .transactionMethod("TxnMethod") // NOPMD
            .transactionTypeCode("TxnCode") // NOPMD
            .information(TRANSACTION_INFORMATION)
            .build();

    final StatementTransactions statementTransactions =
        StatementTransactions.builder()
            .totalNumberOfPages(1)
            .totalNumberOfTransactions(1)
            .transactionList(Collections.singletonList(transaction))
            .build();

    final AccountTransactionMapperException exception =
        Assertions.assertThrows(
            AccountTransactionMapperException.class,
            () ->
                mapper.getTransactionsToResponse(
                    AuthenticTransactions.builder()
                        .totalNumberOfRecords(0)
                        .transactionList(Collections.emptyList())
                        .build(),
                    statementTransactions));

    assertThat(exception.getMessage(), is("Unable to map credit-debit value 0.00 X"));
    assertThat(exception.getCause(), not(instanceOf(AccountTransactionMapperException.class)));
  }

  private static Stream<Arguments> mapsOnlyStatementTransactionsToAccountTransactionsResponse() {
    final OffsetDateTime now = OffsetDateTime.now(CLOCK);
    final Instant nowAsInstant = Instant.from(now);
    return Stream.of(
        Arguments.of(
            createStatementTransactions(), createAccountTransactionsResponse(nowAsInstant)),
        Arguments.of(
            createStatementTransactionsWithoutOptionalFields(),
            createAccountTransactionsResponseWithoutOptionalFields(nowAsInstant)),
        Arguments.of(
            createStatementTransactionsWithoutOptionalsPlusTransactionCode(),
            createAccountTransactionsResponseWithOptionalTransactionTypeCodeOnly(nowAsInstant)),
        Arguments.of(
            createStatementTransactionsWithoutOptionalsPlusTransactionMethod(),
            createAccountTransactionsResponseWithOptionalTransactionMethodCodeOnly(nowAsInstant)));
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> mapsExtraAuthenticTransactionsToAccountTransactionsResponse() {
    final OffsetDateTime now = OffsetDateTime.now(CLOCK);
    final Instant nowAsInstant = Instant.from(now);
    return Stream.of(
        Arguments.of(
            createAuthenticTransactionsWithOneExtraRecord(),
            createStatementTransactions(),
            createAccountTransactionsResponseWithOneExtraAuthenticRecord(nowAsInstant),
            1,
            "62.75",
            null),
        Arguments.of(
            createAuthenticTransactionsWithTwoExtraRecordsDebitLatest(),
            createStatementTransactions(),
            createAccountTransactionsResponseWithTwoExtraAuthenticRecordDebitLatest(nowAsInstant),
            2,
            "62.75",
            "61.53"),
        Arguments.of(
            createAuthenticTransactionsWithTwoExtraRecordsCreditLatest(),
            createStatementTransactions(),
            createAccountTransactionsResponseWithTwoExtraAuthenticRecordCreditLatest(nowAsInstant),
            2,
            "55.53",
            "61.52"));
  }

  private static AuthenticTransaction createAuthenticTransaction(
      final String transactionId,
      final String creditDebitIndicator,
      final String transactionAmount,
      final String balanceAmount) {
    return AuthenticTransaction.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .transactionID(transactionId)
        .transactionDesc("TxnDesc " + transactionId)
        .creditorDebitIndicator(creditDebitIndicator)
        .transactionBookingDateTime(LocalDateTime.now(CLOCK))
        .financialTransactionAmount(new BigDecimal(transactionAmount))
        .balanceType(BalanceConstants.TYPE_CAPITAL_AVAILABLE)
        .balanceAmount(new BigDecimal(balanceAmount))
        .build();
  }

  private static AuthenticTransactions createAuthenticTransactionsWithOneExtraRecord() {
    return AuthenticTransactions.builder()
        .totalNumberOfRecords(1)
        .transactionList(
            Collections.singletonList(
                createAuthenticTransaction(
                    "920000000", CREDIT_INDICATOR, "5.99", "62.75"))) // NOPMD
        .build();
  }

  private static AuthenticTransactions createAuthenticTransactionsWithTwoExtraRecordsDebitLatest() {
    return AuthenticTransactions.builder()
        .totalNumberOfRecords(2)
        .transactionList(
            Arrays.asList(
                createAuthenticTransaction("930000000", DEBIT_INDICATOR, "-1.23", "61.53"), // NOPMD
                createAuthenticTransaction(
                    "920000000", CREDIT_INDICATOR, "5.99", "62.75"))) // NOPMD
        .build();
  }

  private static AuthenticTransactions
      createAuthenticTransactionsWithTwoExtraRecordsCreditLatest() {
    return AuthenticTransactions.builder()
        .totalNumberOfRecords(2)
        .transactionList(
            Arrays.asList(
                createAuthenticTransaction("930000000", CREDIT_INDICATOR, "1.23", "61.52"), // NOPMD
                createAuthenticTransaction(
                    "920000000", DEBIT_INDICATOR, "-5.99", "55.53"))) // NOPMD
        .build();
  }

  private static StatementTransactions createStatementTransactions() {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(2)
        .transactionList(
            Arrays.asList(
                createStatementTransaction("917992000", "15.01", "56.76", "156.41"), // NOPMD
                createStatementTransaction("915388845", "20.01", "200.50", "150.20"))) // NOPMD
        .build();
  }

  private static StatementTransaction createStatementTransaction(
      final String transactionId,
      final String amount,
      final String availableBalance,
      final String ledgerBalance) {
    return StatementTransaction.builder()
        .accountNumber(Long.valueOf(ACCOUNT_NUMBER))
        .transactionId(Long.valueOf(transactionId))
        .transactionRef("TxnDesc " + transactionId)
        .transactionIndicator(STATEMENT_CREDIT_INDICATOR)
        .status(STATUS_BOOKED)
        .bookingDate(LocalDateTime.now(CLOCK))
        .transactionAmount(new BigDecimal(amount))
        .availableBalanceAfterTxn(new BigDecimal(availableBalance))
        .ledgerBalanceAfterTxn(new BigDecimal(ledgerBalance))
        .transactionMethod("TxnMethod")
        .transactionTypeCode("TxnCode")
        .information(TRANSACTION_INFORMATION)
        .build();
  }

  private static StatementTransaction createStatementTransactionWithoutOptionalFields(
      final String transactionId,
      final String amount,
      final String availableBalance,
      final String ledgerBalance,
      final String transactionCode,
      final String transactionMethod) {
    return StatementTransaction.builder()
        .accountNumber(Long.valueOf(ACCOUNT_NUMBER))
        .transactionId(Long.valueOf(transactionId))
        .transactionIndicator(STATEMENT_CREDIT_INDICATOR)
        .bookingDate(LocalDateTime.now(CLOCK))
        .transactionAmount(new BigDecimal(amount))
        .availableBalanceAfterTxn(new BigDecimal(availableBalance))
        .ledgerBalanceAfterTxn(new BigDecimal(ledgerBalance))
        .transactionTypeCode(transactionCode)
        .transactionMethod(transactionMethod)
        .status(STATUS_BOOKED)
        .build();
  }

  private static StatementTransactions createStatementTransactionsWithoutOptionalFields() {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(2)
        .transactionList(
            Arrays.asList(
                createStatementTransactionWithoutOptionalFields(
                    "917992000", "15.01", "56.76", "156.41", null, null),
                createStatementTransactionWithoutOptionalFields(
                    "915388845", "20.01", "200.50", "150.20", null, null)))
        .build();
  }

  private static StatementTransactions
      createStatementTransactionsWithoutOptionalsPlusTransactionCode() {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(2)
        .transactionList(
            Arrays.asList(
                createStatementTransactionWithoutOptionalFields(
                    "917992000", "15.01", "56.76", "156.41", "TxnCode", null),
                createStatementTransactionWithoutOptionalFields(
                    "915388845", "20.01", "200.50", "150.20", "TxnCode", null)))
        .build();
  }

  private static StatementTransactions
      createStatementTransactionsWithoutOptionalsPlusTransactionMethod() {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(2)
        .transactionList(
            Arrays.asList(
                createStatementTransactionWithoutOptionalFields(
                    "917992000", "15.01", "56.76", "156.41", null, "TxnMethod"),
                createStatementTransactionWithoutOptionalFields(
                    "915388845", "20.01", "200.50", "150.20", null, "TxnMethod")))
        .build();
  }

  private static AccountTransactionsResponse createAccountTransactionsResponse(
      @NotNull final Instant now) {
    return AccountTransactionsResponse.builder()
        .transactions(
            Arrays.asList(
                createResponseTransaction(
                    "917992000",
                    CREDIT_INDICATOR,
                    now,
                    "15.01",
                    createTransactionCode("TxnCode", "TxnMethod"),
                    TRANSACTION_INFORMATION,
                    createExpectedBalances()),
                createResponseTransaction(
                    "915388845",
                    CREDIT_INDICATOR,
                    now,
                    "20.01",
                    createTransactionCode("TxnCode", "TxnMethod"),
                    TRANSACTION_INFORMATION,
                    createExpectedBalances2())))
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).totalTransactions(2).build())
        .build();
  }

  private static AccountTransactionsResponse createAccountTransactionsResponseWithoutOptionalFields(
      @NotNull final Instant now) {
    return AccountTransactionsResponse.builder()
        .transactions(
            Arrays.asList(
                createResponseTransactionWithoutOptionals(
                    "917992000", now, "15.01", null, createExpectedBalances()),
                createResponseTransactionWithoutOptionals(
                    "915388845", now, "20.01", null, createExpectedBalances2())))
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).totalTransactions(2).build())
        .build();
  }

  private static AccountTransactionsResponse
      createAccountTransactionsResponseWithOptionalTransactionTypeCodeOnly(
          @NotNull final Instant now) {
    return AccountTransactionsResponse.builder()
        .transactions(
            Arrays.asList(
                createResponseTransactionWithoutOptionals(
                    "917992000",
                    now,
                    "15.01",
                    createTransactionCode("TxnCode", null),
                    createExpectedBalances()),
                createResponseTransactionWithoutOptionals(
                    "915388845",
                    now,
                    "20.01",
                    createTransactionCode("TxnCode", null),
                    createExpectedBalances2())))
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).totalTransactions(2).build())
        .build();
  }

  private static AccountTransactionsResponse
      createAccountTransactionsResponseWithOptionalTransactionMethodCodeOnly(
          @NotNull final Instant now) {
    return AccountTransactionsResponse.builder()
        .transactions(
            Arrays.asList(
                createResponseTransactionWithoutOptionals(
                    "917992000",
                    now,
                    "15.01",
                    createTransactionCode(null, "TxnMethod"),
                    createExpectedBalances()),
                createResponseTransactionWithoutOptionals(
                    "915388845",
                    now,
                    "20.01",
                    createTransactionCode(null, "TxnMethod"),
                    createExpectedBalances2())))
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).totalTransactions(2).build())
        .build();
  }

  private static AccountTransactionsResponse
      createAccountTransactionsResponseWithOneExtraAuthenticRecord(@NotNull final Instant now) {
    return AccountTransactionsResponse.builder()
        .transactions(
            Arrays.asList(
                createResponseTransaction(
                    "920000000",
                    CREDIT_INDICATOR,
                    now,
                    "5.99",
                    null,
                    "TxnDesc 920000000", // NOPMD
                    createExpectedBalancesAuthentic("62.75")),
                createResponseTransaction(
                    "917992000",
                    CREDIT_INDICATOR,
                    now,
                    "15.01",
                    createTransactionCode("TxnCode", "TxnMethod"),
                    TRANSACTION_INFORMATION,
                    createExpectedBalances()),
                createResponseTransaction(
                    "915388845",
                    CREDIT_INDICATOR,
                    now,
                    "20.01",
                    createTransactionCode("TxnCode", "TxnMethod"),
                    TRANSACTION_INFORMATION,
                    createExpectedBalances2())))
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).totalTransactions(3).build())
        .build();
  }

  private static AccountTransactionsResponse
      createAccountTransactionsResponseWithTwoExtraAuthenticRecordDebitLatest(
          @NotNull final Instant now) {
    return AccountTransactionsResponse.builder()
        .transactions(
            Arrays.asList(
                createResponseTransaction(
                    "930000000",
                    DEBIT_INDICATOR,
                    now,
                    "1.23",
                    null,
                    "TxnDesc 930000000",
                    createExpectedBalancesAuthentic("61.53")),
                createResponseTransaction(
                    "920000000",
                    CREDIT_INDICATOR,
                    now,
                    "5.99",
                    null,
                    "TxnDesc 920000000",
                    createExpectedBalancesAuthentic("62.75")),
                createResponseTransaction(
                    "917992000",
                    CREDIT_INDICATOR,
                    now,
                    "15.01",
                    createTransactionCode("TxnCode", "TxnMethod"),
                    TRANSACTION_INFORMATION,
                    createExpectedBalances()),
                createResponseTransaction(
                    "915388845",
                    CREDIT_INDICATOR,
                    now,
                    "20.01",
                    createTransactionCode("TxnCode", "TxnMethod"),
                    TRANSACTION_INFORMATION,
                    createExpectedBalances2())))
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).totalTransactions(4).build())
        .build();
  }

  private static AccountTransactionsResponse
      createAccountTransactionsResponseWithTwoExtraAuthenticRecordCreditLatest(
          @NotNull final Instant now) {
    return AccountTransactionsResponse.builder()
        .transactions(
            Arrays.asList(
                createResponseTransaction(
                    "930000000",
                    CREDIT_INDICATOR,
                    now,
                    "1.23",
                    null,
                    "TxnDesc 930000000",
                    createExpectedBalancesAuthentic("61.52")),
                createResponseTransaction(
                    "920000000",
                    DEBIT_INDICATOR,
                    now,
                    "5.99",
                    null,
                    "TxnDesc 920000000",
                    createExpectedBalancesAuthentic("55.53")),
                createResponseTransaction(
                    "917992000",
                    CREDIT_INDICATOR,
                    now,
                    "15.01",
                    createTransactionCode("TxnCode", "TxnMethod"),
                    TRANSACTION_INFORMATION,
                    createExpectedBalances()),
                createResponseTransaction(
                    "915388845",
                    CREDIT_INDICATOR,
                    now,
                    "20.01",
                    createTransactionCode("TxnCode", "TxnMethod"),
                    TRANSACTION_INFORMATION,
                    createExpectedBalances2())))
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).totalTransactions(4).build())
        .build();
  }

  private static AccountTransactionsResponse
      createAccountTransactionsResponseWithOnlyAuthenticRecords(@NotNull final Instant now) {
    return AccountTransactionsResponse.builder()
        .transactions(
            Arrays.asList(
                createResponseTransaction(
                    "930000000",
                    DEBIT_INDICATOR,
                    now,
                    "1.23",
                    null,
                    "TxnDesc 930000000",
                    createExpectedBalancesAuthentic("61.53")),
                createResponseTransaction(
                    "920000000",
                    CREDIT_INDICATOR,
                    now,
                    "5.99",
                    null,
                    "TxnDesc 920000000",
                    createExpectedBalancesAuthentic("62.75"))))
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).totalTransactions(2).build())
        .build();
  }

  @SuppressWarnings("PMD.ExcessiveParameterList")
  private static AccountTransactionsResponse.Transaction createResponseTransaction(
      final String transactionId,
      final String creditDebitIndicator,
      final Instant dateTime,
      final String amount,
      final TransactionCode transactionCode,
      final String transactionInformation,
      final List<Balance> balances) {
    return AccountTransactionsResponse.Transaction.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .transactionId(transactionId)
        .transactionReference("TxnDesc " + transactionId)
        .creditDebitIndicator(creditDebitIndicator)
        .status(AccountTransactionsMapperTest.STATUS_BOOKED)
        .bookingDateTime(dateTime)
        .amount(AccountTransactionsResponse.Amount.builder().amount(amount).currency("GBP").build())
        .transactionCode(transactionCode)
        .transactionInformation(transactionInformation)
        .balances(balances)
        .build();
  }

  private static AccountTransactionsResponse.Transaction createResponseTransactionWithoutOptionals(
      final String transactionId,
      final Instant dateTime,
      final String amount,
      final TransactionCode transactionCode,
      final List<Balance> balances) {
    return AccountTransactionsResponse.Transaction.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .transactionId(transactionId)
        .creditDebitIndicator(CREDIT_INDICATOR)
        .bookingDateTime(dateTime)
        .amount(AccountTransactionsResponse.Amount.builder().amount(amount).currency("GBP").build())
        .transactionCode(transactionCode)
        .balances(balances)
        .status(STATUS_BOOKED)
        .build();
  }

  private static AccountTransactionsResponse.TransactionCode createTransactionCode(
      final String code, final String method) {
    return AccountTransactionsResponse.TransactionCode.builder().code(code).method(method).build();
  }

  private static List<AccountBalanceType> createTransactionBalances() {
    return Arrays.asList(
        AccountBalanceType.builder()
            .balanceType("CapitalAvailable")
            .balanceAmount(new BigDecimal("56.76"))
            .build(),
        AccountBalanceType.builder()
            .balanceType("CapitalLedger")
            .balanceAmount(new BigDecimal("156.41"))
            .build());
  }

  private static List<AccountBalanceType> createTransactionBalances2() {
    return Arrays.asList(
        AccountBalanceType.builder()
            .balanceType("CapitalAvailable")
            .balanceAmount(new BigDecimal("200.50"))
            .build(),
        AccountBalanceType.builder()
            .balanceType("CapitalLedger")
            .balanceAmount(new BigDecimal("150.20"))
            .build());
  }

  private static List<AccountBalanceType> createTransactionBalancesAuthentic(
      final BigDecimal amount) {
    return Collections.singletonList(
        AccountBalanceType.builder().balanceType("CapitalLedger").balanceAmount(amount).build());
  }

  private static List<Balance> createExpectedBalances() {
    return Arrays.asList(
        Balance.builder().type("InterimAvailable").amount(new BigDecimal("56.76")).build(),
        Balance.builder().type("InterimBooked").amount(new BigDecimal("156.41")).build());
  }

  private static List<Balance> createExpectedBalances2() {
    return Arrays.asList(
        Balance.builder().type("InterimAvailable").amount(new BigDecimal("200.50")).build(),
        Balance.builder().type("InterimBooked").amount(new BigDecimal("150.20")).build());
  }

  private static List<Balance> createExpectedBalancesAuthentic(final String amount) {
    return Collections.singletonList(
        Balance.builder().type("InterimBooked").amount(new BigDecimal(amount)).build());
  }
}
