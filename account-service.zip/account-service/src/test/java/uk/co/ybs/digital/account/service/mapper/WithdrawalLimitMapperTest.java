package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.web.dto.WithdrawalLimit;

@ExtendWith(MockitoExtension.class)
class WithdrawalLimitMapperTest {

  private static final String INTERNAL_ACCOUNT_NUMBER = "1234567890";
  private static final Long PRODUCT_SYS_ID = 2000L;
  private static final String EUROPE_LONDON = "Europe/London";

  @ParameterizedTest
  @MethodSource("withdrawalLimitArgs")
  void shouldMapWithdrawals(
      final String label,
      final SavingAccountAnnualWithdrawalLimit annualWithdrawalLimit,
      final Clock clock,
      final WithdrawalLimit expected) {
    final WithdrawalLimitMapper mapper = new WithdrawalLimitMapper(clock);
    final WithdrawalLimit mapped = mapper.mapWithdrawalLimit(annualWithdrawalLimit);
    assertThat(mapped, is(expected));
  }

  private static Stream<Arguments> withdrawalLimitArgs() {
    return Stream.of(
        Arguments.of(
            "zero withdrawals allowed",
            createSavingAccountAnnualWithdrawalLimit(0, 0, LocalDate.of(2019, Month.FEBRUARY, 1)),
            Clock.fixed(Instant.parse("2020-01-31T00:00:00Z"), ZoneId.of(EUROPE_LONDON)),
            null),
        Arguments.of(
            "account limit record date start of month",
            createSavingAccountAnnualWithdrawalLimit(5, 3, LocalDate.of(2019, Month.FEBRUARY, 1)),
            Clock.fixed(Instant.parse("2020-01-01T00:00:00Z"), ZoneId.of(EUROPE_LONDON)),
            WithdrawalLimit.builder()
                .permitted(5)
                .available(2)
                .periodEnd(LocalDate.of(2020, Month.FEBRUARY, 1))
                .build()),
        Arguments.of(
            "account limit record date start of month with fewer days in limit period remaining",
            createSavingAccountAnnualWithdrawalLimit(5, 3, LocalDate.of(2019, Month.FEBRUARY, 1)),
            Clock.fixed(Instant.parse("2020-01-31T00:00:00Z"), ZoneId.of(EUROPE_LONDON)),
            WithdrawalLimit.builder()
                .permitted(5)
                .available(1)
                .periodEnd(LocalDate.of(2020, Month.FEBRUARY, 1))
                .build()),
        Arguments.of(
            "account limit record date middle of month",
            createSavingAccountAnnualWithdrawalLimit(5, 3, LocalDate.of(2019, Month.FEBRUARY, 15)),
            Clock.fixed(Instant.parse("2020-02-01T00:00:00Z"), ZoneId.of(EUROPE_LONDON)),
            WithdrawalLimit.builder()
                .permitted(5)
                .available(2)
                .periodEnd(LocalDate.of(2020, Month.FEBRUARY, 15))
                .build()),
        Arguments.of(
            "account limit record date end of month",
            createSavingAccountAnnualWithdrawalLimit(5, 3, LocalDate.of(2019, Month.FEBRUARY, 28)),
            Clock.fixed(Instant.parse("2020-02-01T00:00:00Z"), ZoneId.of(EUROPE_LONDON)),
            WithdrawalLimit.builder()
                .permitted(5)
                .available(2)
                .periodEnd(LocalDate.of(2020, Month.FEBRUARY, 28))
                .build()),
        Arguments.of(
            "account limit record date end of feb leap year",
            createSavingAccountAnnualWithdrawalLimit(5, 3, LocalDate.of(2020, Month.FEBRUARY, 29)),
            Clock.fixed(Instant.parse("2021-02-01T00:00:00Z"), ZoneId.of(EUROPE_LONDON)),
            WithdrawalLimit.builder()
                .permitted(5)
                .available(2)
                .periodEnd(LocalDate.of(2021, Month.FEBRUARY, 28))
                .build()));
  }

  private static SavingAccountAnnualWithdrawalLimit createSavingAccountAnnualWithdrawalLimit(
      final int allowed, final int made, final LocalDate yearStartDate) {
    return SavingAccountAnnualWithdrawalLimit.builder()
        .sysId(1L)
        .accountNumber(
            AccountNumber.builder()
                .accountNumber(Long.parseLong(INTERNAL_ACCOUNT_NUMBER))
                .tableId(AccountNumber.TABLE_ID_SAVACC)
                .savingProductSysId(PRODUCT_SYS_ID)
                .build())
        .savingProductSysId(PRODUCT_SYS_ID)
        .withdrawalsAllowed(allowed)
        .withdrawalsMade(made)
        .yearStart(yearStartDate)
        .build();
  }
}
