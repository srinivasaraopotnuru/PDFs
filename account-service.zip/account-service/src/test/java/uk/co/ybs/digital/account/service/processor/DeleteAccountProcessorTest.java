package uk.co.ybs.digital.account.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.core.SavingAccount;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.core.SavingAccountCoreRepository;
import uk.co.ybs.digital.account.service.AuthenticMessageService;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class DeleteAccountProcessorTest {

  private static final Long ACCOUNT_NUMBER = 1L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  @Mock private SavingAccountCoreRepository savingAccountCoreRepository;
  @Mock private AccountNumberRepository accountNumberRepository;
  @Mock private AuthenticMessageService authenticMessageService;

  @InjectMocks private DeleteAccountProcessor testSubject;

  private static SavingAccount buildSavingAccount() {
    return SavingAccount.builder().accountNumber(ACCOUNT_NUMBER).build();
  }

  private static DeleteAccountRequestArguments buildRequestArguments() {
    return buildRequestArguments(TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234));
  }

  private static DeleteAccountRequestArguments buildRequestArguments(
      final RequestMetadata metadata) {
    return DeleteAccountRequestArguments.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .processTime(PROCESS_TIME)
        .requestMetadata(metadata)
        .build();
  }

  private static AccountNumber buildAccountNumber() {
    return AccountNumber.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .savingProductSysId(1L)
        .build();
  }

  @Test
  void resolveShouldReturnAccount() {

    final DeleteAccountRequestArguments arguments = buildRequestArguments();

    final SavingAccount savingAccount = buildSavingAccount();
    when(savingAccountCoreRepository.findById(ACCOUNT_NUMBER))
        .thenReturn(Optional.of(savingAccount));

    final SavingAccount resolvedAccount = testSubject.resolve(arguments);

    assertThat(resolvedAccount, is(savingAccount));
  }

  @Test
  void resolveShouldThrowAccountNotFoundExceptionWhenAccountIsEmpty() {

    final DeleteAccountRequestArguments arguments = buildRequestArguments();

    when(savingAccountCoreRepository.findById(ACCOUNT_NUMBER)).thenReturn(Optional.empty());

    final AccountNotFoundException exception =
        assertThrows(AccountNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(
        exception.getMessage(),
        is(
            "Failed to find account "
                + ACCOUNT_NUMBER
                + " for request ID: "
                + arguments.getRequestMetadata().getRequestId()));
  }

  @Test
  void executeShouldUpdateSavingAccountEndDate() {
    final DeleteAccountRequestArguments arguments = buildRequestArguments();
    final String schemaUser = SavingAccount.SCHEMA_USER;
    final SavingAccount savingAccount = buildSavingAccount();
    final AccountNumber accountNumber = buildAccountNumber();

    when(accountNumberRepository.findById(ACCOUNT_NUMBER)).thenReturn(Optional.of(accountNumber));

    final SavingAccount expected =
        SavingAccount.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .endedDate(arguments.getProcessTime())
            .closedDate(arguments.getProcessTime())
            .endedAt(schemaUser)
            .endedBy(schemaUser)
            .build();

    testSubject.execute(arguments, savingAccount);
    verify(savingAccountCoreRepository).saveAndFlush(expected);
  }
}
