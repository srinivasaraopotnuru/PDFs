package uk.co.ybs.digital.account.config;

import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.test.context.ActiveProfiles;

@JsonTest
@ActiveProfiles("test")
class BigDecimalSerializerTest {

  @Autowired ObjectMapper objectMapper;

  @Test
  void roundUnnecessaryThrowsException() throws JsonProcessingException {
    assertThrows(
        JsonMappingException.class,
        () -> objectMapper.writeValueAsString(new BigDecimal("55.987")));
  }
}
