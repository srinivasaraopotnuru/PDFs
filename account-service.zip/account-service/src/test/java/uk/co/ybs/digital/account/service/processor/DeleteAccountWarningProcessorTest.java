package uk.co.ybs.digital.account.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException.Reason;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.RestrictionType;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.copy.AccountWarningCopyRepository;
import uk.co.ybs.digital.account.repository.core.AccountWarningCoreRepository;
import uk.co.ybs.digital.account.repository.core.RestrictionTypeCoreRepository;
import uk.co.ybs.digital.account.repository.core.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class DeleteAccountWarningProcessorTest {

  private static final Long ACCOUNT_NUMBER = 1L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final Long SAVING_PRODUCT_SYSID = 1L;
  private static final Long WARNING_SYSID = 100L;
  private static final String ENDED_AT = "SACCSRV";
  private static final String ENDED_BY = "SACCSRV";
  private static final String RESTRICTION_TYPE_CODE = "ABC";

  @Mock private AccountWarningCoreRepository accountWarningCoreRepository;
  @Mock private AccountWarningCopyRepository accountWarningCopyRepository;
  @Mock private AccountNumberRepository accountNumberRepository;
  @Mock private RestrictionTypeCoreRepository restrictionTypeRepository;
  @Mock private Clock clock;
  @InjectMocks private DeleteAccountWarningProcessor testSubject;

  @Captor private ArgumentCaptor<List<AccountWarning>> savedAccountWarningListCore;

  @Captor
  private ArgumentCaptor<List<uk.co.ybs.digital.account.model.copy.AccountWarning>>
      savedAccountWarningListCopy;

  @Mock TestEntityManager coreTestEntityManager;
  private TestHelper testHelperCore;
  @Mock TestEntityManager copyTestEntityManager;
  private uk.co.ybs.digital.account.repository.copy.TestHelper testHelperCopy;

  private static AccountNumber buildAdgCoreAccountNumber() {
    return AccountNumber.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .savingProductSysId(SAVING_PRODUCT_SYSID)
        .build();
  }

  private static DeleteAccountWarningRequestArguments buildRequestArguments() {
    return buildRequestArguments(
        uk.co.ybs.digital.account.utils.TestHelper.buildValidRequestMetadata(
            UUID.randomUUID(), 1234));
  }

  private static DeleteAccountWarningRequestArguments buildRequestArguments(
      final RequestMetadata metadata) {
    return DeleteAccountWarningRequestArguments.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .processTime(PROCESS_TIME)
        .warningCode("ABC")
        .endBy(ENDED_BY)
        .endAt(ENDED_AT)
        .requestMetadata(metadata)
        .build();
  }

  @Test
  void resolveShouldReturnAccount() {

    final DeleteAccountWarningRequestArguments arguments = buildRequestArguments();

    final AccountNumber account = buildAdgCoreAccountNumber();

    when(accountNumberRepository.findById(ACCOUNT_NUMBER)).thenReturn(Optional.of(account));

    final AccountNumber resolvedAccount = testSubject.resolve(arguments);

    assertThat(resolvedAccount, is(account));
  }

  @Test
  void resolveShouldThrowAccountNotFoundExceptionWhenAccountIsEmpty() {

    final DeleteAccountWarningRequestArguments arguments = buildRequestArguments();
    when(accountNumberRepository.findById(ACCOUNT_NUMBER)).thenReturn(Optional.empty());

    final AccountNotFoundException exception =
        assertThrows(AccountNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(
        exception.getMessage(),
        is("Failed to find account " + ACCOUNT_NUMBER + " in the database"));
    verifyNoInteractions(accountWarningCoreRepository);
  }

  @Test
  void executeShouldDeleteWarning() {
    final DeleteAccountWarningRequestArguments arguments = buildRequestArguments();
    testHelperCore = new TestHelper(coreTestEntityManager);
    testHelperCopy =
        new uk.co.ybs.digital.account.repository.copy.TestHelper(copyTestEntityManager);

    final AccountWarning warningCore =
        testHelperCore.buildAccountWarning(
            testHelperCore.buildAccountNumber(ACCOUNT_NUMBER, SAVING_PRODUCT_SYSID),
            testHelperCore.buildRestrictionType(WARNING_SYSID, RESTRICTION_TYPE_CODE, PROCESS_TIME),
            PROCESS_TIME,
            null);

    final uk.co.ybs.digital.account.model.copy.AccountWarning warningCopy =
        testHelperCopy.buildAccountWarning(
            testHelperCopy.buildAccountNumber(ACCOUNT_NUMBER, SAVING_PRODUCT_SYSID),
            testHelperCopy.buildRestrictionType(WARNING_SYSID, RESTRICTION_TYPE_CODE, PROCESS_TIME),
            PROCESS_TIME,
            null);

    final AccountNumber account =
        AccountNumber.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .tableId(AccountNumber.TABLE_ID_SAVACC)
            .savingProductSysId(SAVING_PRODUCT_SYSID)
            .build();
    final RestrictionType restrictionType =
        RestrictionType.builder().code(RESTRICTION_TYPE_CODE).startDate(PROCESS_TIME).build();

    final Clock fixedClock =
        Clock.fixed(Instant.parse("2020-05-26T13:45:01Z"), ZoneId.of("Europe/London"));
    doReturn(fixedClock.instant()).when(clock).instant();
    doReturn(fixedClock.getZone()).when(clock).getZone();

    when(restrictionTypeRepository.findByCode(RESTRICTION_TYPE_CODE))
        .thenReturn(Optional.of(restrictionType));

    when(accountWarningCoreRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            any(), any(), any()))
        .thenReturn(Collections.singletonList(warningCore));

    when(accountWarningCopyRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            any(), any(), any()))
        .thenReturn(Collections.singletonList(warningCopy));

    testSubject.execute(arguments, account);

    verify(accountWarningCoreRepository).saveAllAndFlush(savedAccountWarningListCore.capture());
    verify(accountWarningCopyRepository).saveAllAndFlush(savedAccountWarningListCopy.capture());

    savedAccountWarningListCore.getValue().stream()
        .forEach(
            savedWarning ->
                assertThat(
                    savedWarning,
                    is(
                        accountWarningMatcherCore(
                            ACCOUNT_NUMBER,
                            PROCESS_TIME,
                            PROCESS_TIME.toLocalDate(),
                            ENDED_AT,
                            ENDED_BY))));
    savedAccountWarningListCopy.getValue().stream()
        .forEach(
            savedWarning ->
                assertThat(
                    savedWarning,
                    is(
                        accountWarningMatcherCopy(
                            ACCOUNT_NUMBER,
                            PROCESS_TIME,
                            PROCESS_TIME.toLocalDate(),
                            ENDED_AT,
                            ENDED_BY))));
  }

  @Test
  void executeShouldThrowAccountRequestProcessingExceptionWhenRestrictionTypeNotFound() {
    final DeleteAccountWarningRequestArguments arguments = buildRequestArguments();
    final AccountNumber account =
        AccountNumber.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .tableId(AccountNumber.TABLE_ID_SAVACC)
            .savingProductSysId(SAVING_PRODUCT_SYSID)
            .build();

    when(restrictionTypeRepository.findByCode(RESTRICTION_TYPE_CODE)).thenReturn(Optional.empty());

    final AccountRequestProcessingException exception =
        assertThrows(
            AccountRequestProcessingException.class, () -> testSubject.execute(arguments, account));

    assertThat(exception.getMessage(), is(Reason.WARNING_NOT_FOUND.getDescription()));
    verifyNoInteractions(accountWarningCoreRepository);
  }

  private Matcher<AccountWarning> accountWarningMatcherCore(
      final Long accountNumber,
      final LocalDateTime endedDate,
      final LocalDate endDate,
      final String endedAt,
      final String endedBy) {
    final Matcher<uk.co.ybs.digital.account.model.core.AccountNumber> accountNumberMatcher =
        accountNumberMatcherCore(
            accountNumber,
            uk.co.ybs.digital.account.model.core.AccountNumber.TABLE_ID_SAVACC,
            SAVING_PRODUCT_SYSID);

    return allOf(
        hasProperty("accountNumber", is(accountNumberMatcher)), // NOPMD
        hasProperty("endDate", is(endDate)),
        hasProperty("endedDate", is(endedDate)),
        hasProperty("endedAt", is(endedAt)),
        hasProperty("endedBy", is(endedBy)));
  }

  private Matcher<uk.co.ybs.digital.account.model.copy.AccountWarning> accountWarningMatcherCopy(
      final Long accountNumber,
      final LocalDateTime endedDate,
      final LocalDate endDate,
      final String endedAt,
      final String endedBy) {
    final Matcher<uk.co.ybs.digital.account.model.copy.AccountNumber> accountNumberMatcher =
        accountNumberMatcherCopy(
            accountNumber,
            uk.co.ybs.digital.account.model.core.AccountNumber.TABLE_ID_SAVACC,
            SAVING_PRODUCT_SYSID);

    return allOf(
        hasProperty("accountNumber", is(accountNumberMatcher)),
        hasProperty("endDate", is(endDate)),
        hasProperty("endedDate", is(endedDate)),
        hasProperty("endedAt", is(endedAt)),
        hasProperty("endedBy", is(endedBy)));
  }

  private Matcher<uk.co.ybs.digital.account.model.core.AccountNumber> accountNumberMatcherCore(
      final Long accountNumber, final String tableId, final Long savingProductSysId) {

    return allOf(
        hasProperty("accountNumber", is(accountNumber)), // NOPMD
        hasProperty("tableId", is(tableId)),
        hasProperty("savingProductSysId", is(savingProductSysId)));
  }

  private Matcher<uk.co.ybs.digital.account.model.copy.AccountNumber> accountNumberMatcherCopy(
      final Long accountNumber, final String tableId, final Long savingProductSysId) {

    return allOf(
        hasProperty("accountNumber", is(accountNumber)), // NOPMD
        hasProperty("tableId", is(tableId)),
        hasProperty("savingProductSysId", is(savingProductSysId)));
  }
}
