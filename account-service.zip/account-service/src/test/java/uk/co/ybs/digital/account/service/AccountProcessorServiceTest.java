package uk.co.ybs.digital.account.service;

import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;

import com.google.common.collect.ImmutableMap;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Stream;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.transaction.CannotCreateTransactionException;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException.Reason;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Operation;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Status;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogPayload;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogRequest;
import uk.co.ybs.digital.account.repository.core.MetadataCoreRepository;
import uk.co.ybs.digital.account.repository.digitalaccount.WorkLogRepository;
import uk.co.ybs.digital.account.service.audit.AuditServiceException;
import uk.co.ybs.digital.account.service.processor.AccountRequest;
import uk.co.ybs.digital.account.service.processor.AccountRequestFactory;
import uk.co.ybs.digital.account.service.processor.ResolvedAccountRequest;
import uk.co.ybs.digital.account.service.utilities.WorkLogMetrics;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class AccountProcessorServiceTest {

  private static final long ACCOUNT_NUMBER = 1L;

  private AccountProcessorService testSubject;

  @Mock private WorkLogRepository workLogRepository;

  @Mock private MetadataCoreRepository metadataRepository;

  @Mock private AccountRequestFactory accountRequestFactory;

  @Mock private AccountRequest accountRequest;

  @Mock private ResolvedAccountRequest resolvedAccountRequest;

  @Mock private WorkLogMetrics workLogMetrics;

  private LocalDateTime now;

  private static WorkLog createWorkLog(
      final WorkLog.Operation operation,
      final RequestMetadata metadata,
      final WorkLogPayload payload) {
    return WorkLog.builder()
        .status(WorkLog.Status.PENDING)
        .accountNumber(ACCOUNT_NUMBER)
        .operation(operation)
        .message(WorkLogRequest.builder().workLogPayload(payload).metadata(metadata).build())
        .build();
  }

  private static RequestMetadata createRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(
        UUID.fromString("8e112ed4-0374-47d0-aa82-427049d2dab4"), 1234);
  }

  private static Stream<Arguments> workLogArguments() {
    return Stream.of(
        Arguments.of(TestHelper.buildSubmitIsaDeclarationRequest(), Operation.SUBMIT_ISA_DEC),
        Arguments.of(TestHelper.buildUpdateAccountDetailsRequest(), Operation.UPDATE_ACCOUNT_DET),
        Arguments.of(TestHelper.buildAccountWarningRequest(), Operation.INS_ACCOUNT_WARNING),
        Arguments.of(TestHelper.buildDeleteAccountRequest(), Operation.DELETE_ACCOUNT),
        Arguments.of(TestHelper.buildDeleteAccountWarningRequest(), Operation.DEL_ACCOUNT_WARNING));
  }

  private static Stream<Arguments> workLogWithExceptionArguments() {
    return Stream.of(
        Arguments.of(
            TestHelper.buildSubmitIsaDeclarationRequest(),
            Operation.SUBMIT_ISA_DEC,
            DataAccessResourceFailureException.class),
        Arguments.of(
            TestHelper.buildUpdateAccountDetailsRequest(),
            Operation.UPDATE_ACCOUNT_DET,
            DataAccessResourceFailureException.class),
        Arguments.of(
            TestHelper.buildSubmitIsaDeclarationRequest(),
            Operation.SUBMIT_ISA_DEC,
            CannotCreateTransactionException.class),
        Arguments.of(
            TestHelper.buildUpdateAccountDetailsRequest(),
            Operation.UPDATE_ACCOUNT_DET,
            CannotCreateTransactionException.class),
        Arguments.of(
            TestHelper.buildAccountWarningRequest(),
            Operation.INS_ACCOUNT_WARNING,
            DataAccessResourceFailureException.class),
        Arguments.of(
            TestHelper.buildAccountWarningRequest(),
            Operation.INS_ACCOUNT_WARNING,
            CannotCreateTransactionException.class),
        Arguments.of(
            TestHelper.buildDeleteAccountRequest(),
            Operation.DELETE_ACCOUNT,
            DataAccessResourceFailureException.class),
        Arguments.of(
            TestHelper.buildDeleteAccountRequest(),
            Operation.DELETE_ACCOUNT,
            CannotCreateTransactionException.class),
        Arguments.of(
            TestHelper.buildDeleteAccountWarningRequest(),
            Operation.DEL_ACCOUNT_WARNING,
            DataAccessResourceFailureException.class),
        Arguments.of(
            TestHelper.buildDeleteAccountWarningRequest(),
            Operation.DEL_ACCOUNT_WARNING,
            CannotCreateTransactionException.class));
  }

  @BeforeEach
  void setUp() {
    final Clock clock =
        Clock.fixed(Instant.parse("2020-05-26T13:45:01Z"), ZoneId.of("Europe/London"));

    now = LocalDateTime.now(clock);

    testSubject =
        new AccountProcessorService(
            workLogRepository, metadataRepository, accountRequestFactory, workLogMetrics, clock);
  }

  @Test
  void processShouldDoNothingWhenThereAreNoPendingRequests() {
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(Collections.emptyList());

    final List<WorkLog> pendingRequests = Collections.emptyList();
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    testSubject.process();

    verify(workLogMetrics).setValues(Collections.emptyMap());
    verifyNoInteractions(accountRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void processShouldUpdateMetricsWhenNoPendingRequests() {
    final List<ImmutablePair<WorkLog.Status, Long>> requestStates =
        Arrays.asList(
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 3L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 2L));
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(requestStates);

    final List<WorkLog> pendingRequests = Collections.emptyList();
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    final Map<WorkLog.Status, Long> expectedStatusCounts =
        ImmutableMap.of(WorkLog.Status.COMPLETE, 3L, WorkLog.Status.FAILED, 2L);

    testSubject.process();

    verify(workLogMetrics).setValues(expectedStatusCounts);
    verifyNoInteractions(accountRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @Test
  void processShouldHandleUnexpectedExceptions() {
    doThrow(RuntimeException.class).when(workLogRepository).findCountOfRequestsInState();

    testSubject.process();

    verifyNoInteractions(accountRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @ParameterizedTest
  @MethodSource("workLogWithExceptionArguments")
  void processShouldHandleFailedLivenessCheckWhenDBUnavailable(
      final WorkLogPayload workLogPayload,
      final WorkLog.Operation operation,
      final Class<Exception> exception) {
    final RequestMetadata requestMetadata = createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);

    final List<ImmutablePair<WorkLog.Status, Long>> requestStates =
        Arrays.asList(
            new ImmutablePair<>(WorkLog.Status.PENDING, 1L),
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 3L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 2L));
    when(workLogRepository.findCountOfRequestsInState()).thenReturn(requestStates);

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    doThrow(exception).when(metadataRepository).count();

    final Map<WorkLog.Status, Long> expectedMap =
        ImmutableMap.of(
            WorkLog.Status.PENDING, 1L, WorkLog.Status.COMPLETE, 3L, WorkLog.Status.FAILED, 2L);

    testSubject.process();

    verify(workLogMetrics).setValues(expectedMap);
    verifyNoInteractions(accountRequestFactory);
    verifyNoMoreInteractions(workLogRepository);
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processWorkLogShouldExecuteRequest(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(Status.COMPLETE).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(accountRequestFactory.build(workLog, now)).thenReturn(accountRequest);

    when(accountRequest.resolve()).thenReturn(resolvedAccountRequest);

    testSubject.process();

    verify(resolvedAccountRequest).execute();
    verify(resolvedAccountRequest).auditSuccess();
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processWorkLogShouldHandleSuccessAuditErrorWhenExecutingRequest(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(Status.COMPLETE).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(accountRequestFactory.build(workLog, now)).thenReturn(accountRequest);
    when(accountRequest.resolve()).thenReturn(resolvedAccountRequest);

    doThrow(new AuditServiceException("Audit Failure")).when(resolvedAccountRequest).auditSuccess();

    testSubject.process();

    verify(resolvedAccountRequest).execute();
    verify(resolvedAccountRequest).auditSuccess();
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processWorkLogShouldHandleAccountRequestProcessingExceptions(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(accountRequestFactory.build(workLog, now)).thenReturn(accountRequest);
    doThrow(new AccountRequestProcessingException(Reason.UNEXPECTED))
        .when(accountRequest)
        .resolve();

    testSubject.process();

    verify(accountRequest).auditFailure(Reason.UNEXPECTED.getDescription());
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processWorkLogShouldHandleUnexpectedExceptions(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(accountRequestFactory.build(workLog, now)).thenReturn(accountRequest);
    doThrow(RuntimeException.class).when(accountRequest).resolve();

    testSubject.process();

    verify(accountRequest).auditFailure(Reason.UNEXPECTED.getDescription());
    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processShouldHandleResolveAccountNotFoundExceptions(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(accountRequestFactory.build(workLog, now)).thenReturn(accountRequest);

    when(accountRequest.resolve()).thenThrow(new AccountNotFoundException("Account Not Found"));

    testSubject.process();

    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));

    verify(accountRequest).auditFailure("Account Not Found");
  }

  @ParameterizedTest
  @MethodSource("workLogArguments") // NOPMD
  void processShouldHandleResolveExceptions(
      final WorkLogPayload workLogPayload, final WorkLog.Operation operation) {
    final RequestMetadata requestMetadata = createRequestMetadata();
    final WorkLog workLog = createWorkLog(operation, requestMetadata, workLogPayload);
    final WorkLog expectedWorkLog = workLog.toBuilder().status(WorkLog.Status.FAILED).build();

    final List<WorkLog> pendingRequests = Collections.singletonList(workLog);
    when(workLogRepository.findRequestsInState(WorkLog.Status.PENDING)).thenReturn(pendingRequests);

    when(accountRequestFactory.build(workLog, now)).thenReturn(accountRequest);

    when(accountRequest.resolve()).thenThrow(new RuntimeException());

    testSubject.process();

    verify(workLogRepository).save(argThat(samePropertyValuesAs(expectedWorkLog)));

    verify(accountRequest).auditFailure(Reason.UNEXPECTED.getDescription());
  }
}
