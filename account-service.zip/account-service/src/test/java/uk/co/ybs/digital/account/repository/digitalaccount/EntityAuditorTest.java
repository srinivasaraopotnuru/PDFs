package uk.co.ybs.digital.account.repository.digitalaccount;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.account.model.digitalaccount.EntityAuditor;

class EntityAuditorTest {
  private static final String DEFAULT_AUDITOR = "default";

  private EntityAuditor testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new EntityAuditor(DEFAULT_AUDITOR);
  }

  @Test
  void getCurrentAuditorShouldReturnDefaultWhenNotLoggedIn() {
    assertThat(testSubject.getCurrentAuditor(), is(Optional.of(DEFAULT_AUDITOR)));
  }
}
