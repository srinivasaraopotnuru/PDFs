package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import lombok.Builder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.AccountSummaryMappingBundle;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.AccountSummary;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse.AccountGroup;

@ExtendWith(MockitoExtension.class)
class GroupedAccountListMapperTest {

  private static final String PRODUCT_IDENTIFIER = "PRODUCT_IDEN1";
  private static final Long PRODUCT_SYS_ID = 2000L;

  private GroupedAccountListMapper mapper;

  @Mock private AccountSummaryMapper accountSummaryMapper;

  static final String ACCOUNT1_NUMBER = "1234567890";
  static final String ACCOUNT1_BALANCE = "123.45";

  static final String ACCOUNT2_NUMBER = "1234567891";
  static final String ACCOUNT2_BALANCE = "12.34";
  static final String ACCOUNT3_NUMBER = "1234567892";
  static final String ACCOUNT3_BALANCE = "121.34";

  private static final LocalDateTime ACCOUNT_OPENED_DATE_TIME1 =
      LocalDateTime.parse("2018-11-21T17:25:02");
  private static final LocalDateTime ACCOUNT_OPENED_DATE_TIME2 =
      LocalDateTime.parse("2020-05-24T14:45:01");

  @BeforeEach
  void setUp() {
    mapper = new GroupedAccountListMapper(accountSummaryMapper);
  }

  @ParameterizedTest
  @MethodSource("accounts")
  void mapsAccounts(
      final String label,
      final AccountBits account1,
      final AccountBits account2,
      final GroupedAccountListResponse expected,
      final boolean showClosedAccounts) {

    when(accountSummaryMapper.mapAccountSummary(account1.accountSummaryMappingBundle))
        .thenReturn(account1.mappedAccountSummary);
    when(accountSummaryMapper.mapAccountSummary(account2.accountSummaryMappingBundle))
        .thenReturn(account2.mappedAccountSummary);

    final GroupedAccountListResponse mapped =
        mapper.mapToAccountGroups(
            Arrays.asList(
                account1.accountSummaryMappingBundle, account2.accountSummaryMappingBundle),
            showClosedAccounts);

    assertThat(mapped, is(expected));
  }

  @ParameterizedTest
  @MethodSource("threeAccounts")
  void mapsAccountsAndOrdersByOpenedDateDescendingThenAccountNumberDescending(
      final String label,
      final AccountBits account1,
      final AccountBits account2,
      final AccountBits account3,
      final GroupedAccountListResponse expected,
      final boolean showClosedAccounts) {

    when(accountSummaryMapper.mapAccountSummary(account1.accountSummaryMappingBundle))
        .thenReturn(account1.mappedAccountSummary);
    when(accountSummaryMapper.mapAccountSummary(account2.accountSummaryMappingBundle))
        .thenReturn(account2.mappedAccountSummary);
    when(accountSummaryMapper.mapAccountSummary(account3.accountSummaryMappingBundle))
        .thenReturn(account3.mappedAccountSummary);

    final GroupedAccountListResponse mapped =
        mapper.mapToAccountGroups(
            Arrays.asList(
                account1.accountSummaryMappingBundle,
                account2.accountSummaryMappingBundle,
                account3.accountSummaryMappingBundle),
            showClosedAccounts);

    assertThat(mapped, is(expected));
  }

  @Test
  void doesNotMapClosedAccountsWhenShowClosedAccountsIsFalse() {
    final ProductInfo productInfo = TestHelper.createFullProductInfo();

    final AccountBits account1 =
        AccountBits.builder()
            .accountSummaryMappingBundle(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                    .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                    .productInfo(productInfo)
                    .accountWarningRestrictionRules(Collections.emptyList())
                    .activityGroupCodes(
                        ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                    .anniversaryWithdrawalLimit(
                        createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                    .build())
            .mappedAccountSummary(
                createMappedAccountSummary(
                    ACCOUNT1_NUMBER,
                    createMappedBalanceList(ACCOUNT1_BALANCE),
                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
            .build();

    final AccountBits account2 =
        AccountBits.builder()
            .accountSummaryMappingBundle(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                    .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                    .productInfo(productInfo)
                    .accountWarningRestrictionRules(Collections.emptyList())
                    .activityGroupCodes(ImmutableSet.of())
                    .closed(true)
                    .anniversaryWithdrawalLimit(
                        createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                    .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                    .build())
            .mappedAccountSummary(
                createMappedAccountSummary(
                    ACCOUNT2_NUMBER,
                    createMappedBalanceList(ACCOUNT2_BALANCE),
                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
            .build();

    final GroupedAccountListResponse expected =
        GroupedAccountListResponse.builder()
            .owned(
                AccountGroup.builder()
                    .accounts(
                        ImmutableList.of(
                            createMappedAccountSummary(
                                ACCOUNT1_NUMBER,
                                createMappedBalanceList(ACCOUNT1_BALANCE),
                                ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                    .balances(createMappedBalanceList(ACCOUNT1_BALANCE))
                    .build())
            .build();

    when(accountSummaryMapper.mapAccountSummary(account1.accountSummaryMappingBundle))
        .thenReturn(account1.mappedAccountSummary);

    final GroupedAccountListResponse mapped =
        mapper.mapToAccountGroups(
            Arrays.asList(
                account1.accountSummaryMappingBundle, account2.accountSummaryMappingBundle),
            false);

    assertThat(mapped, is(expected));
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  private static Stream<Arguments> accounts() {
    final ProductInfo productInfo = TestHelper.createFullProductInfo();
    return Stream.of(
        Arguments.of(
            "two owned accounts",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .owned(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList("135.79"))
                        .build())
                .build(),
            false),
        Arguments.of(
            "two other accounts",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .other(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList("135.79"))
                        .build())
                .build(),
            false),
        Arguments.of(
            "one own and one other account",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .owned(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList(ACCOUNT1_BALANCE))
                        .build())
                .other(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate())))
                        .balances(createMappedBalanceList(ACCOUNT2_BALANCE))
                        .build())
                .build(),
            false),
        Arguments.of(
            "one own and one closed account",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .closed(true)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .owned(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList(ACCOUNT1_BALANCE))
                        .build())
                .closed(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate())))
                        .balances(createMappedBalanceList(ACCOUNT2_BALANCE))
                        .build())
                .build(),
            true),
        Arguments.of(
            "owned accounts with no balances",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(Collections.emptyList())
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        Collections.emptyList(),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(Collections.emptyList())
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        Collections.emptyList(),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .owned(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    Collections.emptyList(),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    Collections.emptyList(),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(Collections.emptyList())
                        .build())
                .build(),
            false));
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  private static Stream<Arguments> threeAccounts() {
    final ProductInfo productInfo = TestHelper.createFullProductInfo();
    return Stream.of(
        Arguments.of(
            "three owned accounts,two accounts with same open date",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT3_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT3_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT3_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT3_NUMBER,
                        createMappedBalanceList(ACCOUNT3_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .owned(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT3_NUMBER,
                                    createMappedBalanceList(ACCOUNT3_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList("257.13"))
                        .build())
                .build(),
            false),
        Arguments.of(
            "three other accounts,two accounts with same open date ",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT3_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT3_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT3_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT3_NUMBER,
                        createMappedBalanceList(ACCOUNT3_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .other(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT3_NUMBER,
                                    createMappedBalanceList(ACCOUNT3_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList("257.13"))
                        .build())
                .build(),
            false),
        Arguments.of(
            "three closed accounts,two accounts with same open date",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .closed(true)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT3_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT3_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .closed(true)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT3_NUMBER,
                        createMappedBalanceList(ACCOUNT3_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .closed(true)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .closed(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT3_NUMBER,
                                    createMappedBalanceList(ACCOUNT3_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList("257.13"))
                        .build())
                .build(),
            true),
        Arguments.of(
            "three accounts,two owned with same open date and one other account",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT3_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT3_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT3_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT3_NUMBER,
                        createMappedBalanceList(ACCOUNT3_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .owned(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT3_NUMBER,
                                    createMappedBalanceList(ACCOUNT3_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList("244.79"))
                        .build())
                .other(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate())))
                        .balances(createMappedBalanceList(ACCOUNT2_BALANCE))
                        .build())
                .build(),
            false),
        Arguments.of(
            "three accounts ,one own and two closed account with same open date",
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT1_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT1_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(
                            ImmutableSet.of(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS))
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT1_NUMBER))
                        .closed(false)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME1.toLocalDate())
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT1_NUMBER,
                        createMappedBalanceList(ACCOUNT1_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME1.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT2_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT2_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .closed(true)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT2_NUMBER))
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT2_NUMBER,
                        createMappedBalanceList(ACCOUNT2_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            AccountBits.builder()
                .accountSummaryMappingBundle(
                    AccountSummaryMappingBundle.builder()
                        .savingAccountDetails(createSavingAccountDetails(ACCOUNT3_NUMBER))
                        .balances(createAccountBalanceTypeList(ACCOUNT3_BALANCE))
                        .productInfo(productInfo)
                        .accountWarningRestrictionRules(Collections.emptyList())
                        .activityGroupCodes(ImmutableSet.of())
                        .closed(true)
                        .openedDate(ACCOUNT_OPENED_DATE_TIME2.toLocalDate())
                        .anniversaryWithdrawalLimit(
                            createSavingAccountAnnualWithdrawalLimit(ACCOUNT3_NUMBER))
                        .build())
                .mappedAccountSummary(
                    createMappedAccountSummary(
                        ACCOUNT3_NUMBER,
                        createMappedBalanceList(ACCOUNT3_BALANCE),
                        ACCOUNT_OPENED_DATE_TIME2.toLocalDate()))
                .build(),
            GroupedAccountListResponse.builder()
                .owned(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT1_NUMBER,
                                    createMappedBalanceList(ACCOUNT1_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME1.toLocalDate())))
                        .balances(createMappedBalanceList(ACCOUNT1_BALANCE))
                        .build())
                .closed(
                    AccountGroup.builder()
                        .accounts(
                            ImmutableList.of(
                                createMappedAccountSummary(
                                    ACCOUNT3_NUMBER,
                                    createMappedBalanceList(ACCOUNT3_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate()),
                                createMappedAccountSummary(
                                    ACCOUNT2_NUMBER,
                                    createMappedBalanceList(ACCOUNT2_BALANCE),
                                    ACCOUNT_OPENED_DATE_TIME2.toLocalDate())))
                        .balances(createMappedBalanceList("133.68"))
                        .build())
                .build(),
            true));
  }

  private static SavingAccountDetails createSavingAccountDetails(final String accountNumber) {

    return SavingAccountDetails.builder()
        .accountNumber(Long.valueOf(accountNumber))
        .currencyCode("GBP")
        .accountName("ACC_NAME1")
        .sortCode(112233)
        .productIdentifier(PRODUCT_IDENTIFIER)
        .productType("TYPE1")
        .productName("PRODUCT_NAME1")
        .isPaymentAccount(true)
        .brandCode("YBS")
        .accountHolderName("ACC_NAME1")
        .build();
  }

  private static List<AccountBalanceType> createAccountBalanceTypeList(final String balanceAmount) {
    return Collections.singletonList(
        AccountBalanceType.builder()
            .balanceType("CapitalAvailable")
            .balanceAmount(new BigDecimal(balanceAmount))
            .build());
  }

  private static AccountSummary createMappedAccountSummary(
      final String accountNumber, final List<Balance> balances, final LocalDate accountOpenedDate) {
    return AccountSummary.builder()
        .accountNumber(accountNumber)
        .accountName("ACC_NAME1")
        .balances(balances)
        .openedDate(accountOpenedDate)
        .build();
  }

  private static List<Balance> createMappedBalanceList(final String balanceAmount) {
    return Collections.singletonList(
        Balance.builder().type("InterimAvailable").amount(new BigDecimal(balanceAmount)).build());
  }

  private static SavingAccountAnnualWithdrawalLimit createSavingAccountAnnualWithdrawalLimit(
      final String accountNumber) {
    return SavingAccountAnnualWithdrawalLimit.builder()
        .sysId(1L)
        .accountNumber(
            AccountNumber.builder()
                .accountNumber(Long.parseLong(accountNumber))
                .tableId(AccountNumber.TABLE_ID_SAVACC)
                .savingProductSysId(PRODUCT_SYS_ID)
                .build())
        .savingProductSysId(PRODUCT_SYS_ID)
        .withdrawalsAllowed(10)
        .withdrawalsMade(5)
        .yearStart(LocalDate.of(2020, Month.JANUARY, 3))
        .build();
  }

  @Builder
  private static class AccountBits {
    private final AccountSummaryMappingBundle accountSummaryMappingBundle;
    private final AccountSummary mappedAccountSummary;
  }
}
