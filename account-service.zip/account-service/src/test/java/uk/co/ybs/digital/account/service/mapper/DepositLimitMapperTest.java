package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

import java.math.BigDecimal;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.web.dto.DepositLimit;

@ExtendWith(MockitoExtension.class)
class DepositLimitMapperTest {

  private DepositLimitMapper mapper;
  private static final BigDecimal AMOUNT = BigDecimal.TEN;

  @BeforeEach
  void setUp() {
    mapper = new DepositLimitMapper();
  }

  @Test
  public void shouldMapDepositLimit() {
    final BigDecimal usedLimit = new BigDecimal("10.00");
    final BigDecimal maxProductBalRemaining = new BigDecimal("20.00");
    final DepositLimit expected =
        DepositLimit.builder()
            .available(usedLimit)
            .maxProductBalRemaining(maxProductBalRemaining)
            .build();

    final DepositLimit mapped = mapper.mapDepositLimit(usedLimit, maxProductBalRemaining);

    assertThat(mapped, is(expected));
  }

  @ParameterizedTest
  @MethodSource("shouldMapDepositLimitWhenNullValuesExist")
  public void shouldMapDepositLimitWhenNullValuesExist(
      final BigDecimal available,
      final BigDecimal maxProductBalRemaining,
      final BigDecimal expectedAvailable,
      final BigDecimal expectedMaxProductBalRemaining) {
    final DepositLimit mapped = mapper.mapDepositLimit(available, maxProductBalRemaining);
    if (available == null && maxProductBalRemaining == null) {
      // no values entire return should be null
      assertThat(mapped, is(nullValue()));
    } else {
      // if something is defined a non result should be returned
      assertThat(mapped, is(notNullValue()));
      assertThat(mapped.getMaxProductBalRemaining(), is(expectedMaxProductBalRemaining));
      assertThat(mapped.getAvailable(), is(expectedAvailable));
    }
  }

  private static Stream<Arguments> shouldMapDepositLimitWhenNullValuesExist() {
    return Stream.of(
        Arguments.of(null, null, null, null),
        Arguments.of(null, AMOUNT, null, AMOUNT),
        Arguments.of(AMOUNT, null, AMOUNT, null),
        Arguments.of(AMOUNT, AMOUNT, AMOUNT, AMOUNT));
  }
}
