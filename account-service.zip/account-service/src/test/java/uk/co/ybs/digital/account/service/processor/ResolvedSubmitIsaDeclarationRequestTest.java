package uk.co.ybs.digital.account.service.processor;

import static org.mockito.Mockito.verify;

import java.time.LocalDateTime;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EnumSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class ResolvedSubmitIsaDeclarationRequestTest {
  private ResolvedSubmitIsaDeclarationRequest testSubject;
  private SubmitIsaDeclarationRequestArguments arguments;
  private AccountNumber accountNumber;
  @Mock SubmitIsaDeclarationProcessor submitIsaDeclarationProcessor;

  private static final Long ACCOUNT_NUMBER = 1L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");

  @BeforeEach
  void setUp() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);

    arguments =
        SubmitIsaDeclarationRequestArguments.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .requestMetadata(requestMetadata)
            .processTime(PROCESS_TIME)
            .build();

    accountNumber =
        AccountNumber.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .savingProductSysId(1L)
            .savingProductSysId(1L)
            .build();

    testSubject =
        new ResolvedSubmitIsaDeclarationRequest(
            arguments, submitIsaDeclarationProcessor, accountNumber);
  }

  @Test
  void executeShouldCallProcessor() {
    testSubject.execute();
    verify(submitIsaDeclarationProcessor).execute(arguments);
  }

  @Test
  void auditSuccessShouldCallProcessor() {
    testSubject.auditSuccess();
    verify(submitIsaDeclarationProcessor).auditSuccess(arguments);
  }

  @ParameterizedTest(name = "auditFailureShouldCallProcessor: message={0}")
  @EnumSource(
      value = AccountRequestProcessingException.Reason.class,
      names = {"ISA_DECLARATION_WARNINGS_NOT_FOUND", "UNEXPECTED"})
  void auditFailureShouldCallProcessor(final AccountRequestProcessingException.Reason message) {
    testSubject.auditFailure(message.getDescription());
    verify(submitIsaDeclarationProcessor).auditFailure(arguments, message.getDescription());
  }
}
