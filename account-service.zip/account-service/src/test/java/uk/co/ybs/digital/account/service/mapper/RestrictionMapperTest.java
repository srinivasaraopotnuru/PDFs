package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.emptyCollectionOf;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.account.model.adgcore.RestrictionType.ISA_TRANSFERRED_OUT;
import static uk.co.ybs.digital.account.model.adgcore.RestrictionType.NEW_ACCOUNT_14_DAYS;
import static uk.co.ybs.digital.account.model.adgcore.RestrictionType.NO_RECEIPTS;
import static uk.co.ybs.digital.account.model.adgcore.RestrictionType.NO_SUBSCRIPTIONS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.web.dto.Restriction;
import uk.co.ybs.digital.account.web.dto.RestrictionCategory;

@ExtendWith(MockitoExtension.class)
class RestrictionMapperTest {

  private static final String RESTRICTION_RULE_CODE_WEBREC = "WEBREC";
  private static final String RESTRICTION_RULE_CODE_WEBWDL = "WEBWDL";
  private static final String RESTRICTION_RULE_CODE_WEBTXT = "WEBTXT";
  private static final String RESTRICTION_RULE_VALUE_Y = "Y";
  private static final String RESTRICTION_NOSUBS_WEBTXT = "NOSUBS_WEBTXT";
  private static final String RESTRICTION_NOREC_WEBTXT = "NOREC_WEBTXT";
  private static final String RESTRICTION_WEBDCF_WEBTXT = "WEBDCF_WEBTXT";
  private static final String RESTRICTION_OTHER_WEBTXT = "OTHER_WEBTXT";
  private static final String RESTRICTION_OSR_WEBTXT = "OSR_WEBTXT";
  private static final String RESTRICTION_TYPE_CODE_OSR = "OSR";
  private static final String RESTRICTION_TYPE_CODE_OTHER = "RESTYP";
  private static final String RESTRICTION_TYPE_CODE_OTHER2 = "RESTYP2";
  private static final String RESTRICTION_TYPE_CODE_OTHER3 = "RESTYP3";
  private static final String OTHER_RESTRICTION_RULE_CODE_OTHER = "OTHER";

  private RestrictionMapper mapper;

  @BeforeEach
  void setUp() {
    mapper = new RestrictionMapper();
  }

  @ParameterizedTest
  @ValueSource(strings = {RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_CODE_WEBWDL})
  public void shouldMapWhenNoRestrictions(final String restrictionType) {
    final List<Restriction> mapped = mapper.map(Collections.emptyList(), restrictionType);

    assertThat(mapped, is(emptyCollectionOf(Restriction.class)));
  }

  @Test
  public void shouldMapMultiRestriction() {

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Arrays.asList(
            new AccountWarningRestrictionRule(
                1L,
                RESTRICTION_TYPE_CODE_OSR,
                RESTRICTION_RULE_CODE_WEBREC,
                RESTRICTION_RULE_VALUE_Y),
            new AccountWarningRestrictionRule(
                1L,
                RESTRICTION_TYPE_CODE_OSR,
                RESTRICTION_RULE_CODE_WEBTXT,
                RESTRICTION_OSR_WEBTXT),
            new AccountWarningRestrictionRule(
                1L,
                RESTRICTION_TYPE_CODE_OTHER,
                RESTRICTION_RULE_CODE_WEBREC,
                RESTRICTION_RULE_VALUE_Y),
            new AccountWarningRestrictionRule(
                1L,
                RESTRICTION_TYPE_CODE_OTHER,
                RESTRICTION_RULE_CODE_WEBTXT,
                RESTRICTION_OTHER_WEBTXT),
            new AccountWarningRestrictionRule(
                1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_VALUE_Y),
            new AccountWarningRestrictionRule(
                1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBTXT, RESTRICTION_NOSUBS_WEBTXT),
            new AccountWarningRestrictionRule(
                1L, NO_RECEIPTS, RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_VALUE_Y),
            new AccountWarningRestrictionRule(
                1L, NO_RECEIPTS, RESTRICTION_RULE_CODE_WEBTXT, RESTRICTION_NOREC_WEBTXT),
            new AccountWarningRestrictionRule(
                1L,
                RESTRICTION_TYPE_CODE_OTHER2,
                RESTRICTION_RULE_CODE_WEBREC,
                RESTRICTION_RULE_VALUE_Y),
            new AccountWarningRestrictionRule(
                1L,
                RESTRICTION_TYPE_CODE_OTHER3,
                RESTRICTION_RULE_CODE_WEBREC,
                RESTRICTION_RULE_VALUE_Y));

    final List<Restriction> expected = new ArrayList<Restriction>();
    Collections.addAll(
        expected,
        Restriction.builder()
            .code(RestrictionCategory.DEPOSIT_DEFAULT)
            .message(RESTRICTION_OSR_WEBTXT)
            .restrictionTypes(Collections.singleton(RESTRICTION_TYPE_CODE_OSR))
            .build(),
        Restriction.builder()
            .code(RestrictionCategory.DEPOSIT_DEFAULT)
            .message(RESTRICTION_OTHER_WEBTXT)
            .restrictionTypes(Collections.singleton(RESTRICTION_TYPE_CODE_OTHER))
            .build(),
        Restriction.builder()
            .code(RestrictionCategory.DEPOSIT_ISA_DECLARATION)
            .message(RESTRICTION_NOSUBS_WEBTXT)
            .restrictionTypes(new LinkedHashSet<>(Arrays.asList(NO_SUBSCRIPTIONS, NO_RECEIPTS)))
            .build(),
        Restriction.builder()
            .code(RestrictionCategory.DEPOSIT_DEFAULT)
            .restrictionTypes(
                new LinkedHashSet<>(
                    Arrays.asList(RESTRICTION_TYPE_CODE_OTHER2, RESTRICTION_TYPE_CODE_OTHER3)))
            .build());

    final List<Restriction> mapped =
        mapper.map(accountWarningRestrictionRules, RESTRICTION_RULE_CODE_WEBREC);

    assertThat(mapped.toArray(), is(expected.toArray()));
  }

  @ParameterizedTest
  @MethodSource("mapRestrictionArguments")
  public void shouldMapSingleRestriction(
      final String label,
      final RestrictionCategory expectedRestrictionCategory,
      final String expectedMessage,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final String restrictionType) {
    final List<Restriction> expected =
        Collections.singletonList(
            Restriction.builder()
                .code(expectedRestrictionCategory)
                .message(expectedMessage)
                .restrictionTypes(
                    accountWarningRestrictionRules.stream()
                        .filter(rule -> rule.isRestrictionTypeRuleCode(restrictionType))
                        .map(rule -> rule.getRestrictionTypeCode())
                        .collect(Collectors.toSet()))
                .build());

    final List<Restriction> mapped = mapper.map(accountWarningRestrictionRules, restrictionType);

    assertThat(mapped, is(expected));
  }

  @SuppressWarnings("PMD.ExcessiveMethodLength")
  private static Stream<Arguments> mapRestrictionArguments() {
    return Stream.of(
        Arguments.of(
            "default deposit warning",
            RestrictionCategory.DEPOSIT_DEFAULT,
            RESTRICTION_OTHER_WEBTXT,
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE_OTHER,
                    RESTRICTION_RULE_CODE_WEBREC,
                    RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE_OTHER,
                    RESTRICTION_RULE_CODE_WEBTXT,
                    RESTRICTION_OTHER_WEBTXT)),
            RESTRICTION_RULE_CODE_WEBREC),
        Arguments.of(
            "isa deposit warning",
            RestrictionCategory.DEPOSIT_ISA_DECLARATION,
            RESTRICTION_NOSUBS_WEBTXT,
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBTXT, RESTRICTION_NOSUBS_WEBTXT)),
            RESTRICTION_RULE_CODE_WEBREC),
        Arguments.of(
            "isa deposit warning",
            RestrictionCategory.DEPOSIT_ISA_DECLARATION,
            RESTRICTION_NOREC_WEBTXT,
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L, NO_RECEIPTS, RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L, NO_RECEIPTS, RESTRICTION_RULE_CODE_WEBTXT, RESTRICTION_NOREC_WEBTXT)),
            RESTRICTION_RULE_CODE_WEBREC),
        Arguments.of(
            "isa transferred warning",
            RestrictionCategory.DEPOSIT_ISA_TRANSFERRED,
            null,
            Collections.singletonList(
                new AccountWarningRestrictionRule(
                    1L,
                    ISA_TRANSFERRED_OUT,
                    RESTRICTION_RULE_CODE_WEBREC,
                    RESTRICTION_RULE_VALUE_Y)),
            RESTRICTION_RULE_CODE_WEBREC),
        Arguments.of(
            "single isa deposit warning if account has receipt and subscription warnings",
            RestrictionCategory.DEPOSIT_ISA_DECLARATION,
            RESTRICTION_NOSUBS_WEBTXT,
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBTXT, RESTRICTION_NOSUBS_WEBTXT),
                new AccountWarningRestrictionRule(
                    1L, NO_RECEIPTS, RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L, NO_RECEIPTS, RESTRICTION_RULE_CODE_WEBTXT, RESTRICTION_NOREC_WEBTXT)),
            RESTRICTION_RULE_CODE_WEBREC),
        Arguments.of(
            "filter out non deposit warnings",
            RestrictionCategory.DEPOSIT_ISA_DECLARATION,
            RESTRICTION_NOSUBS_WEBTXT,
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBTXT, RESTRICTION_NOSUBS_WEBTXT),
                new AccountWarningRestrictionRule(
                    1L,
                    NEW_ACCOUNT_14_DAYS,
                    RESTRICTION_RULE_CODE_WEBWDL,
                    RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L,
                    NEW_ACCOUNT_14_DAYS,
                    RESTRICTION_RULE_CODE_WEBTXT,
                    RESTRICTION_WEBDCF_WEBTXT),
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE_OTHER,
                    OTHER_RESTRICTION_RULE_CODE_OTHER,
                    RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE_OTHER,
                    RESTRICTION_RULE_CODE_WEBTXT,
                    RESTRICTION_OTHER_WEBTXT)),
            RESTRICTION_RULE_CODE_WEBREC),
        Arguments.of(
            "default withdrawal warning",
            RestrictionCategory.WITHDRAWAL_DEFAULT,
            RESTRICTION_OTHER_WEBTXT,
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE_OTHER,
                    RESTRICTION_RULE_CODE_WEBWDL,
                    RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE_OTHER,
                    RESTRICTION_RULE_CODE_WEBTXT,
                    RESTRICTION_OTHER_WEBTXT)),
            RESTRICTION_RULE_CODE_WEBWDL),
        Arguments.of(
            "new 14 day account withdrawal warning",
            RestrictionCategory.WITHDRAWAL_NEW_ACCOUNT,
            RESTRICTION_WEBDCF_WEBTXT,
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L,
                    NEW_ACCOUNT_14_DAYS,
                    RESTRICTION_RULE_CODE_WEBWDL,
                    RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L,
                    NEW_ACCOUNT_14_DAYS,
                    RESTRICTION_RULE_CODE_WEBTXT,
                    RESTRICTION_WEBDCF_WEBTXT)),
            RESTRICTION_RULE_CODE_WEBWDL),
        Arguments.of(
            "filter out none withdrawal warnings",
            RestrictionCategory.WITHDRAWAL_NEW_ACCOUNT,
            RESTRICTION_WEBDCF_WEBTXT,
            Arrays.asList(
                new AccountWarningRestrictionRule(
                    1L,
                    NEW_ACCOUNT_14_DAYS,
                    RESTRICTION_RULE_CODE_WEBWDL,
                    RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L,
                    NEW_ACCOUNT_14_DAYS,
                    RESTRICTION_RULE_CODE_WEBTXT,
                    RESTRICTION_WEBDCF_WEBTXT),
                new AccountWarningRestrictionRule(
                    1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBREC, RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L, NO_SUBSCRIPTIONS, RESTRICTION_RULE_CODE_WEBTXT, RESTRICTION_NOSUBS_WEBTXT),
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE_OTHER,
                    OTHER_RESTRICTION_RULE_CODE_OTHER,
                    RESTRICTION_RULE_VALUE_Y),
                new AccountWarningRestrictionRule(
                    1L,
                    RESTRICTION_TYPE_CODE_OTHER,
                    RESTRICTION_RULE_CODE_WEBTXT,
                    RESTRICTION_OTHER_WEBTXT)),
            RESTRICTION_RULE_CODE_WEBWDL));
  }
}
