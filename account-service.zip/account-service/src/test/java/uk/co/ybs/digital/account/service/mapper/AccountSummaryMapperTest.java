package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.AccountSummaryMappingBundle;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.AccountSummary;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.DepositsSummary;
import uk.co.ybs.digital.account.web.dto.Isa;
import uk.co.ybs.digital.account.web.dto.Product;
import uk.co.ybs.digital.account.web.dto.WithdrawalsSummary;

@ExtendWith(MockitoExtension.class)
class AccountSummaryMapperTest {

  private static final String INTERNAL_ACCOUNT_NUMBER = "1234567890";
  private static final int SORT_CODE_INTEGER = 1234;
  private static final Long PRODUCT_SYS_ID = 2000L;
  private static final LocalDateTime ACCOUNT_OPENED_DATE_TIME =
      LocalDateTime.parse("2018-11-21T17:25:02");

  private AccountSummaryMapper mapper;

  @Mock private CommonAccountMapper commonAccountMapper;

  @Mock private BalanceMapper balanceMapper;

  @Mock private WithdrawalsMapper withdrawalsMapper;

  @Mock private DepositsMapper depositsMapper;

  @Mock private IsaMapper isaMapper;

  @Mock private AmendmentRestrictionMapper amendmentRestrictionMapper;

  @Mock private ProductMapper productMapper;

  @BeforeEach
  void setUp() {
    mapper =
        new AccountSummaryMapper(
            commonAccountMapper,
            balanceMapper,
            withdrawalsMapper,
            depositsMapper,
            isaMapper,
            amendmentRestrictionMapper,
            productMapper);
  }

  @Test
  void mapsAccountSummary() {
    final SavingAccountDetails accountDetails = createSavingAccountDetails();
    final List<AccountBalanceType> accountBalanceTypeList = createAccountBalanceTypeList();
    final ProductInfo productInfo = TestHelper.createFullProductInfo();
    final boolean productMigrationInProgress = true;
    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        createAccountWarningRestrictionRules();

    final String mappedSortCode = "001234";
    when(commonAccountMapper.convertAndPadSortCode(SORT_CODE_INTEGER)).thenReturn(mappedSortCode);

    final String mappedExternalAccountNumber = "12345678";
    when(commonAccountMapper.internalToExternalAccountNumber(INTERNAL_ACCOUNT_NUMBER))
        .thenReturn(mappedExternalAccountNumber);

    final Set<String> activityGroups = Collections.singleton("PISP");
    final SavingAccountAnnualWithdrawalLimit annualWithdrawalLimit =
        createSavingAccountAnnualWithdrawalLimit();
    final boolean accountClosed = false;

    final WithdrawalsSummary mappedWithdrawals =
        WithdrawalsSummary.builder().permittedOverApi(true).build();
    when(withdrawalsMapper.mapSummary(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroups,
            annualWithdrawalLimit,
            accountClosed))
        .thenReturn(mappedWithdrawals);

    when(withdrawalsMapper.isPermittedOverApi(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            activityGroups,
            annualWithdrawalLimit,
            accountClosed))
        .thenReturn(true);

    final DepositsSummary mappedDeposits = DepositsSummary.builder().permittedOverApi(true).build();
    when(depositsMapper.mapSummary(
            INTERNAL_ACCOUNT_NUMBER,
            productInfo,
            productMigrationInProgress,
            accountWarningRestrictionRules,
            accountClosed))
        .thenReturn(mappedDeposits);

    final List<Balance> mappedBalances =
        Collections.singletonList(
            Balance.builder().type("InterimAvailable").amount(new BigDecimal("56.76")).build());
    when(balanceMapper.filterAndMapAccountBalanceTypeList(accountBalanceTypeList, true))
        .thenReturn(mappedBalances);

    when(isaMapper.mapIsa(productInfo, INTERNAL_ACCOUNT_NUMBER)).thenReturn(mappedIsa());

    when(amendmentRestrictionMapper.amendmentRestricted(accountWarningRestrictionRules))
        .thenReturn(false);

    final Product mappedProduct = createProduct();
    when(productMapper.map(productInfo)).thenReturn(mappedProduct);

    final AccountSummaryMappingBundle bundle =
        AccountSummaryMappingBundle.builder()
            .savingAccountDetails(accountDetails)
            .balances(accountBalanceTypeList)
            .productInfo(productInfo)
            .productMigrationInProgress(productMigrationInProgress)
            .accountWarningRestrictionRules(accountWarningRestrictionRules)
            .activityGroupCodes(activityGroups)
            .anniversaryWithdrawalLimit(annualWithdrawalLimit)
            .closed(accountClosed)
            .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
            .build();
    final AccountSummary mapped = mapper.mapAccountSummary(bundle);

    final AccountSummary expected =
        AccountSummary.builder()
            .accountNumber(INTERNAL_ACCOUNT_NUMBER)
            .accountName("ACC_NAME1")
            .accountSortCode(mappedSortCode)
            .balances(mappedBalances)
            .currency("GBP")
            .externalAccountNumber(mappedExternalAccountNumber)
            .productIdentifier("EGG302A")
            .productDescription("Customer Description")
            .product(
                Product.builder()
                    .identifier("EGG302A")
                    .description("Customer Description")
                    .type("Product Type")
                    .build())
            .deposits(mappedDeposits)
            .withdrawals(mappedWithdrawals)
            .isa(mappedIsa())
            .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
            .build();
    assertThat(mapped, is(expected));
  }

  private static SavingAccountDetails createSavingAccountDetails() {

    return SavingAccountDetails.builder()
        .accountNumber(Long.valueOf(INTERNAL_ACCOUNT_NUMBER))
        .currencyCode("GBP")
        .accountName("ACC_NAME1")
        .sortCode(SORT_CODE_INTEGER)
        .productIdentifier("PRODUCT_IDEN1")
        .productType("TYPE1")
        .productName("PRODUCT_NAME1")
        .isPaymentAccount(true)
        .brandCode("YBS")
        .accountHolderName("ACC_NAME1")
        .build();
  }

  private static List<AccountBalanceType> createAccountBalanceTypeList() {
    return Collections.singletonList(
        AccountBalanceType.builder()
            .balanceType("CapitalAvailable")
            .balanceAmount(new BigDecimal("56.76"))
            .build());
  }

  private static SavingAccountAnnualWithdrawalLimit createSavingAccountAnnualWithdrawalLimit() {
    return SavingAccountAnnualWithdrawalLimit.builder()
        .sysId(1L)
        .accountNumber(
            AccountNumber.builder()
                .accountNumber(Long.parseLong(INTERNAL_ACCOUNT_NUMBER))
                .tableId(AccountNumber.TABLE_ID_SAVACC)
                .savingProductSysId(PRODUCT_SYS_ID)
                .build())
        .savingProductSysId(PRODUCT_SYS_ID)
        .withdrawalsAllowed(10)
        .withdrawalsMade(5)
        .yearStart(LocalDate.of(2020, Month.JANUARY, 3))
        .build();
  }

  private static List<AccountWarningRestrictionRule> createAccountWarningRestrictionRules() {
    return Collections.singletonList(
        new AccountWarningRestrictionRule(1L, "RESTYP", "RULE", "RESTYP_WEBTXT"));
  }

  private static Isa mappedIsa() {
    return Isa.builder().flexible(false).helpToBuy(true).build();
  }

  private Product createProduct() {
    return Product.builder()
        .identifier("EGG302A")
        .description("Customer Description")
        .type("Product Type")
        .build();
  }
}
