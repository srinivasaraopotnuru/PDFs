package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.web.dto.WithdrawalLimit;

@ExtendWith(MockitoExtension.class)
class WithdrawalsPermittedOverApiMapperTest {
  private static final String ACCOUNT_NUMBER = "12345678";
  private static final Set<String> ACTIVITY_GROUPS_WITH_PISP =
      Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP);
  private static final Set<String> ACTIVTIY_GROUPS_WITHOUT_PISP =
      Collections.singleton(ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS);
  private static final boolean ACCOUNT_CLOSED = true;
  private static final boolean ACCOUNT_NOT_CLOSED = false;

  private WithdrawalsPermittedOverApiMapper testSubject;

  @BeforeEach
  void setUp() {
    testSubject = new WithdrawalsPermittedOverApiMapper();
  }

  @ParameterizedTest
  @MethodSource("withdrawalPermittedOverApiArgs")
  @SuppressWarnings("PMD.ExcessiveParameterList")
  void shouldMapWithdrawals(
      final String label,
      final ProductInfo productInfo,
      final boolean productMigrationInProgress,
      final List<AccountWarningRestrictionRule> accountWarningRestrictionRules,
      final Set<String> activityGroupCodes,
      final boolean accountClosed,
      final WithdrawalLimit withdrawalLimit,
      final boolean expected) {

    final boolean mapped =
        testSubject.withdrawalPermittedOverApi(
            ACCOUNT_NUMBER,
            productInfo.getWithdrawals().isPermittedOverWeb(),
            productMigrationInProgress,
            false,
            activityGroupCodes,
            withdrawalLimit,
            accountClosed);

    assertThat(mapped, is(expected));
  }

  private static Stream<Arguments> withdrawalPermittedOverApiArgs() {
    return Stream.of(
        Arguments.of(
            "permitted",
            productWithWithdrawalsPermittedOverWeb(true),
            false,
            Collections.emptyList(),
            ACTIVITY_GROUPS_WITH_PISP,
            ACCOUNT_NOT_CLOSED,
            null,
            true),
        Arguments.of(
            "permitted - annual withdrawal limit not reach",
            productWithWithdrawalsPermittedOverWeb(true),
            false,
            Collections.emptyList(),
            ACTIVITY_GROUPS_WITH_PISP,
            ACCOUNT_NOT_CLOSED,
            withdrawalLimitNotReached(),
            true),
        Arguments.of(
            "not permitted - annual withdrawal limit reached",
            productWithWithdrawalsPermittedOverWeb(true),
            false,
            Collections.emptyList(),
            ACTIVITY_GROUPS_WITH_PISP,
            ACCOUNT_NOT_CLOSED,
            withdrawalLimitReached(),
            false),
        Arguments.of(
            "not permitted - product migration in progress",
            productWithWithdrawalsPermittedOverWeb(true),
            true,
            Collections.emptyList(),
            ACTIVITY_GROUPS_WITH_PISP,
            ACCOUNT_NOT_CLOSED,
            null,
            false),
        Arguments.of(
            "not permitted - product withdrawals not permitted over web",
            productWithWithdrawalsPermittedOverWeb(false),
            false,
            Collections.emptyList(),
            ACTIVITY_GROUPS_WITH_PISP,
            ACCOUNT_NOT_CLOSED,
            null,
            false),
        Arguments.of(
            "not permitted - not pisp activity player",
            productWithWithdrawalsPermittedOverWeb(true),
            false,
            Collections.emptyList(),
            ACTIVTIY_GROUPS_WITHOUT_PISP,
            ACCOUNT_NOT_CLOSED,
            null,
            false),
        Arguments.of(
            "not permitted - account closed",
            productWithWithdrawalsPermittedOverWeb(true),
            false,
            Collections.emptyList(),
            ACTIVITY_GROUPS_WITH_PISP,
            ACCOUNT_CLOSED,
            null,
            false));
  }

  private static ProductInfo productWithWithdrawalsPermittedOverWeb(
      final boolean permittedOverWeb) {
    return ProductInfo.builder()
        .withdrawals(ProductInfo.Withdrawals.builder().permittedOverWeb(permittedOverWeb).build())
        .build();
  }

  private static WithdrawalLimit withdrawalLimitNotReached() {
    return WithdrawalLimit.builder().permitted(5).available(2).build();
  }

  private static WithdrawalLimit withdrawalLimitReached() {
    return WithdrawalLimit.builder().permitted(5).available(0).build();
  }
}
