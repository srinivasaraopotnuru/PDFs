package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.web.dto.Balance;

class BalanceMapperTest {

  private static final String BALANCE_156_41 = "156.41";
  private static final String PROPERTY_TYPE = "type";
  private static final String PROPERTY_AMOUNT = "amount";
  private BalanceMapper mapper;

  private final List<AccountBalanceType> accountBalanceTypeList =
      Arrays.asList(
          AccountBalanceType.builder()
              .balanceType("CapitalAvailable")
              .balanceAmount(new BigDecimal("56.76"))
              .build(),
          AccountBalanceType.builder()
              .balanceType("CapitalLedger")
              .balanceAmount(new BigDecimal(BALANCE_156_41))
              .build(),
          // Additional balance types which will get filtered when mapping
          AccountBalanceType.builder().balanceType("").balanceAmount(new BigDecimal("123")).build(),
          AccountBalanceType.builder()
              .balanceType("abc")
              .balanceAmount(new BigDecimal("123"))
              .build());

  @BeforeEach
  void beforeEach() {
    mapper = new BalanceMapper();
  }

  @Test
  void mapsAccountSummaryTypeToAccountListResponse() {
    final List<Balance> mapped = mapper.filterAndMapAccountBalanceTypeList(accountBalanceTypeList);

    assertThat(mapped, hasSize(2));

    assertThat(
        mapped.get(0),
        allOf(
            hasProperty(PROPERTY_TYPE, is("InterimAvailable")),
            hasProperty(PROPERTY_AMOUNT, is(new BigDecimal("56.76")))));
    assertThat(
        mapped.get(1),
        allOf(
            hasProperty(PROPERTY_TYPE, is("InterimBooked")),
            hasProperty(PROPERTY_AMOUNT, is(new BigDecimal(BALANCE_156_41)))));
  }

  @Test
  void mapsAvailableBalanceWhenWithdrawalsPermittedOverApi() {
    final List<Balance> mapped =
        mapper.filterAndMapAccountBalanceTypeList(accountBalanceTypeList, true);

    assertThat(mapped, hasSize(2));

    assertThat(
        mapped.get(0),
        allOf(
            hasProperty(PROPERTY_TYPE, is("InterimAvailable")),
            hasProperty(PROPERTY_AMOUNT, is(new BigDecimal("56.76")))));
    assertThat(
        mapped.get(1),
        allOf(
            hasProperty(PROPERTY_TYPE, is("InterimBooked")),
            hasProperty(PROPERTY_AMOUNT, is(new BigDecimal(BALANCE_156_41)))));
  }

  @Test
  void noAvailableBalanceWhenWithdrawalsNotPermittedOverApi() {
    final List<Balance> mapped =
        mapper.filterAndMapAccountBalanceTypeList(accountBalanceTypeList, false);

    assertThat(mapped, hasSize(1));

    assertThat(
        mapped.get(0),
        allOf(
            hasProperty(PROPERTY_TYPE, is("InterimBooked")),
            hasProperty(PROPERTY_AMOUNT, is(new BigDecimal(BALANCE_156_41)))));
  }
}
