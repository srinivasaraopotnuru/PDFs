package uk.co.ybs.digital.account.repository.copy;

import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.copy.AccountNumber;
import uk.co.ybs.digital.account.model.copy.AccountWarning;
import uk.co.ybs.digital.account.model.copy.RestrictionType;

@AllArgsConstructor
public class TestHelper {
  @NonNull private TestEntityManager copyTestEntityManager;

  public AccountWarning buildAccountWarning(
      final AccountNumber accountNumber,
      final RestrictionType restrictionType,
      final LocalDateTime startDate,
      final LocalDate endDate) {
    return AccountWarning.builder()
        .accountNumber(accountNumber)
        .restrictionType(restrictionType)
        .createdBy("SAPP")
        .createdAt("SAPP")
        .createdDate(startDate)
        .startDate(startDate)
        .endDate(endDate)
        .build();
  }

  public AccountNumber buildAccountNumber(final Long accountNumber, final Long productId) {
    return AccountNumber.builder()
        .accountNumber(accountNumber)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .savingProductSysId(productId)
        .build();
  }

  public RestrictionType buildRestrictionType(
      final Long sysId, final String restrictionTypeCode, final LocalDateTime startDate) {
    return RestrictionType.builder()
        .sysId(sysId)
        .code(restrictionTypeCode)
        .startDate(startDate)
        .build();
  }
}
