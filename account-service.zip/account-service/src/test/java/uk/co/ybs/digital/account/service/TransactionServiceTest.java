package uk.co.ybs.digital.account.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import static org.mockito.Mockito.anyLong;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.net.InetSocketAddress;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AccountTransactionMapperException;
import uk.co.ybs.digital.account.exception.TransactionServiceException;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransaction;
import uk.co.ybs.digital.account.model.adgcore.db.StatementTransactions;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AuthenticService;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransaction;
import uk.co.ybs.digital.account.service.authentic.AuthenticTransactions;
import uk.co.ybs.digital.account.service.mapper.AccountTransactionsMapper;
import uk.co.ybs.digital.account.service.mapper.TransactionInterestMapper;
import uk.co.ybs.digital.account.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.TransactionDates;

@Slf4j
@ExtendWith(MockitoExtension.class)
class TransactionServiceTest {

  private static final String ACCOUNT_NUMBER = "123";

  private static final String PARTY_ID = "123456";

  private static final String BRAND_YBS = "YBS";

  private static final Integer DEFAULT_PAGE_NUMBER = 1;
  private static final Integer DEFAULT_PAGE_SIZE = 10;

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2020-05-26T13:45:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);
  private static final LocalDateTime NOW_MINUS_ONE_SECOND =
      LocalDateTime.now(CLOCK).minusSeconds(1L);
  private static final LocalDateTime NOW_MINUS_TWO_SECONDS =
      LocalDateTime.now(CLOCK).minusSeconds(2L);
  private static final LocalDateTime NOW_PLUS_ONE_SECOND = LocalDateTime.now(CLOCK).plusSeconds(1L);
  private static final String TXN_DESC = "TxnDesc ";
  private static final String CREDIT = "Credit";
  private static final String DEBIT = "Debit";
  private static final String BALANCE = "4.00";

  private TransactionService transactionService;

  @Mock private AccountAccessValidator accountAccessValidator;

  @Mock private AuthenticService authenticService;

  @Mock private SavingAccountTransactionsService savingAccountTransactionsService;

  @Mock private SavingAccountDetailsService savingAccountDetailsService;

  @Mock private AccountTransactionsMapper transactionsMapper;

  @Mock private TransactionInterestMapper transactionInterestMapper;

  @BeforeEach
  void setUp() {
    transactionService =
        new TransactionService(
            accountAccessValidator,
            authenticService,
            savingAccountTransactionsService,
            savingAccountDetailsService,
            transactionsMapper,
            transactionInterestMapper,
            CLOCK);
  }

  @Test
  void getTransactionsShouldNotCallAuthenticWhenAccountIsClosed() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(requestId);
    final TransactionDates transactionDates = TransactionDates.builder().build();
    final StatementTransactions statementTransactions =
        StatementTransactions.builder()
            .transactionList(Collections.singletonList(StatementTransaction.builder().build()))
            .build();

    when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
        .thenReturn(Collections.singletonList(createSavingAccountDetails(NOW.toLocalDate())));

    when(savingAccountTransactionsService.getTransactions(
            anyLong(), anyInt(), anyInt(), any(TransactionDates.class)))
        .thenReturn(statementTransactions);

    transactionService.getTransactions(ACCOUNT_NUMBER, 1, transactionDates, requestMetadata);

    verifyNoInteractions(authenticService);
    verify(savingAccountTransactionsService)
        .getTransactions(Long.valueOf(ACCOUNT_NUMBER), 1, 10, transactionDates);
    verifyNoMoreInteractions(savingAccountTransactionsService);
    verify(transactionsMapper).getTransactionsToResponse(statementTransactions);
  }

  @Test
  void getTransactionsWhenNowIsNotInFilterRangeWithNoStartDate() {
    getTransactionsWhenRecentAuthenticTransactionsAreNotRequired(null);
  }

  @Test
  void getTransactionsWhenNowIsNotInFilterRangeWithValidStartDate() {
    getTransactionsWhenRecentAuthenticTransactionsAreNotRequired(NOW.minusMonths(1));
  }

  void getTransactionsWhenRecentAuthenticTransactionsAreNotRequired(final LocalDateTime startDate) {
    final TransactionDates transactionDates = buildTransactionDates(startDate, NOW.minusDays(1L));
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(requestId);

    final StatementTransaction statementTransaction =
        StatementTransaction.builder().accountNumber(Long.parseLong(ACCOUNT_NUMBER)).build();

    when(savingAccountTransactionsService.getTransactions(anyLong(), anyInt(), anyInt(), any()))
        .thenReturn(
            StatementTransactions.builder()
                .transactionList(Collections.singletonList(StatementTransaction.builder().build()))
                .build());

    transactionService.getTransactions(ACCOUNT_NUMBER, 1, transactionDates, requestMetadata);

    verify(transactionsMapper)
        .getTransactionsToResponse(
            StatementTransactions.builder()
                .transactionList(Collections.singletonList(statementTransaction))
                .build());

    verify(savingAccountTransactionsService)
        .getTransactions(Long.valueOf(ACCOUNT_NUMBER), 1, 10, transactionDates);
    verifyNoMoreInteractions(savingAccountTransactionsService);
    verifyNoInteractions(authenticService);
  }

  @ParameterizedTest
  @MethodSource("mapsTransactionsToResponse")
  @SuppressWarnings("PMD.ExcessiveParameterList")
  void getTransactionsShouldGetTransactionsAndMapResponseEdgeCases(
      final AuthenticTransactions authenticTransactions,
      final AuthenticTransactions unlinkedAuthenticTransactions,
      final StatementTransactions latestAdgTransaction,
      final StatementTransactions statementTransactions,
      final AccountTransactionsResponse expectedResponse,
      final int pageNumber,
      final int unlinkedCount,
      final String authenticBalance,
      final TransactionDates transactionDates) {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(requestId);
    final TransactionDates dummyTransactionDates = TransactionDates.builder().build();

    if (pageNumber > 0) {

      when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
          .thenReturn(Collections.singletonList(createSavingAccountDetails(null)));

      when(authenticService.getTransactions(
              ACCOUNT_NUMBER, NOW.minusDays(1L), NOW, true, true, null, null))
          .thenReturn(authenticTransactions);

      when(savingAccountTransactionsService.getTransactions(
              Long.valueOf(ACCOUNT_NUMBER),
              1,
              TransactionService.ADG_BUFFER_SIZE,
              dummyTransactionDates))
          .thenReturn(latestAdgTransaction);

      if (unlinkedCount > 0 && unlinkedCount == authenticTransactions.getTransactionList().size()) {
        when(authenticService.getBalance(ACCOUNT_NUMBER))
            .thenReturn(buildTransactionBalancesAuthentic(new BigDecimal(authenticBalance)));
      }

      if (statementTransactions.getTotalNumberOfTransactions() > 1
          || (latestAdgTransaction.getTotalNumberOfTransactions() == 1
              && !transactionDateWithinRange(
                  latestAdgTransaction.getTransactionList().get(0).getBookingDate(),
                  transactionDates))) {
        int recordTo = pageNumber * DEFAULT_PAGE_SIZE;
        int recordFrom = (recordTo - DEFAULT_PAGE_SIZE + 1);

        recordFrom = recordFrom - unlinkedCount;
        recordTo = recordTo - unlinkedCount;

        if (recordFrom < 1) {
          recordFrom = 1;
        }

        if (recordTo > latestAdgTransaction.getTotalNumberOfTransactions()) {
          recordTo = latestAdgTransaction.getTotalNumberOfTransactions();
        }

        log.info(recordFrom + " - " + recordTo);

        final int totalAdgTransactions = statementTransactions.getTotalNumberOfTransactions();
        if (pageNumber > 1 && totalAdgTransactions == recordFrom
            || totalAdgTransactions > recordFrom && recordTo > 1
            || (!(recordTo <= totalAdgTransactions
                && transactionDateWithinRange(
                    latestAdgTransaction.getTransactionList().get(0).getBookingDate(),
                    transactionDates)))) {
          when(savingAccountTransactionsService.getTransactions(
                  Long.valueOf(ACCOUNT_NUMBER), recordFrom, recordTo, transactionDates))
              .thenReturn(statementTransactions);
        }
      }

      when(transactionsMapper.getTransactionsToResponse(
              unlinkedAuthenticTransactions, statementTransactions))
          .thenReturn(expectedResponse);
    }

    final AccountTransactionsResponse transactionsResponse =
        transactionService.getTransactions(
            ACCOUNT_NUMBER, pageNumber, transactionDates, requestMetadata);

    assertThat(transactionsResponse, is(expectedResponse));
    verify(accountAccessValidator)
        .validateOwnAccountAccess(ACCOUNT_NUMBER, requestMetadata, Collections.emptySet(), NOW);
  }

  @Test
  void
      getTransactionsShouldThrowTransactionServiceExceptionWhenValidateBalanceFailsWithInvalidType() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(requestId);
    final TransactionDates transactionDates = TransactionDates.builder().build();
    final AuthenticTransactions authenticTransactions = createAuthenticTransactions("2");
    final StatementTransactions statementTransactions =
        StatementTransactions.builder()
            .totalNumberOfPages(1)
            .totalNumberOfTransactions(1)
            .transactionList(
                Collections.singletonList(
                    buildStatementTransaction("1", "X", "2.00", "2.00"))) // NOPMD
            .build();

    when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
        .thenReturn(Collections.singletonList(createSavingAccountDetails(null)));

    when(authenticService.getTransactions(
            ACCOUNT_NUMBER, NOW.minusDays(1L), NOW, true, true, null, null))
        .thenReturn(authenticTransactions);

    when(savingAccountTransactionsService.getTransactions(
            Long.valueOf(ACCOUNT_NUMBER), 1, TransactionService.ADG_BUFFER_SIZE, transactionDates))
        .thenReturn(statementTransactions);

    when(authenticService.getBalance(ACCOUNT_NUMBER))
        .thenReturn(
            Collections.singletonList(
                AccountBalanceType.builder()
                    .balanceType("CapitalAvailable")
                    .balanceAmount(new BigDecimal("2.00"))
                    .build()));

    final TransactionServiceException exception =
        Assertions.assertThrows(
            TransactionServiceException.class,
            () ->
                transactionService.getTransactions(
                    ACCOUNT_NUMBER, DEFAULT_PAGE_NUMBER, transactionDates, requestMetadata));
    assertThat(
        exception.getMessage(),
        is("Error getting ledger authentic balance for account: " + ACCOUNT_NUMBER));
    assertThat(exception.getCause(), not(instanceOf(TransactionServiceException.class)));
  }

  @Test
  void
      getTransactionsShouldThrowTransactionServiceExceptionWhenValidateBalanceFailsWithDifferentBalances() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(requestId);
    final TransactionDates transactionDates = TransactionDates.builder().build();
    final AuthenticTransactions authenticTransactions = createAuthenticTransactions("2");
    final StatementTransactions statementTransactions =
        StatementTransactions.builder()
            .totalNumberOfPages(1)
            .totalNumberOfTransactions(1)
            .transactionList(
                Collections.singletonList(buildStatementTransaction("1", "X", "2.00", "2.00")))
            .build();

    when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
        .thenReturn(Collections.singletonList(createSavingAccountDetails(null)));

    when(authenticService.getTransactions(
            ACCOUNT_NUMBER, NOW.minusDays(1L), NOW, true, true, null, null))
        .thenReturn(authenticTransactions);

    when(savingAccountTransactionsService.getTransactions(
            Long.valueOf(ACCOUNT_NUMBER), 1, TransactionService.ADG_BUFFER_SIZE, transactionDates))
        .thenReturn(statementTransactions);

    when(authenticService.getBalance(ACCOUNT_NUMBER))
        .thenReturn(buildTransactionBalancesAuthentic(new BigDecimal("10.00")));

    final TransactionServiceException exception =
        Assertions.assertThrows(
            TransactionServiceException.class,
            () ->
                transactionService.getTransactions(
                    ACCOUNT_NUMBER, DEFAULT_PAGE_NUMBER, transactionDates, requestMetadata));
    assertThat(
        exception.getMessage(),
        is(
            "Error calculating balance for account "
                + ACCOUNT_NUMBER
                + ", calculatedBalance: 4.00, authenticBalance: 10.00"));
    assertThat(exception.getCause(), not(instanceOf(TransactionServiceException.class)));
  }

  @Test
  void getTransactionsShouldThrowAccountTransactionMapperExceptionWhenMapperFails() {
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(requestId);
    final TransactionDates transactionDates = TransactionDates.builder().build();
    final AuthenticTransactions authenticTransactions = createAuthenticTransactions("1");
    final StatementTransactions statementTransactions =
        StatementTransactions.builder()
            .totalNumberOfPages(1)
            .totalNumberOfTransactions(1)
            .transactionList(
                Collections.singletonList(buildStatementTransaction("1", "X", "2.00", "2.00")))
            .build();

    when(savingAccountDetailsService.getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER)))
        .thenReturn(Collections.singletonList(createSavingAccountDetails(null)));

    when(authenticService.getTransactions(
            ACCOUNT_NUMBER, NOW.minusDays(1L), NOW, true, true, null, null))
        .thenReturn(authenticTransactions);

    when(savingAccountTransactionsService.getTransactions(
            Long.valueOf(ACCOUNT_NUMBER), 1, TransactionService.ADG_BUFFER_SIZE, transactionDates))
        .thenReturn(statementTransactions);

    when(transactionsMapper.getTransactionsToResponse(
            buildEmptyAuthenticTransactions(0), statementTransactions))
        .thenThrow(new AccountTransactionMapperException("Unable to map credit-debit value"));

    final AccountTransactionMapperException exception =
        Assertions.assertThrows(
            AccountTransactionMapperException.class,
            () ->
                transactionService.getTransactions(
                    ACCOUNT_NUMBER, DEFAULT_PAGE_NUMBER, transactionDates, requestMetadata));
    assertThat(exception.getMessage(), is("Unable to map credit-debit value"));
    assertThat(exception.getCause(), not(instanceOf(AccountTransactionMapperException.class)));
  }

  @Test
  void
      getAllTransactionsInDateRangeShouldRetrieveAllTransactionsWithNumberOfTransactionsParameter() {
    final TransactionDates transactionDates = TransactionDates.builder().build();
    final UUID requestId = UUID.randomUUID();
    final RequestMetadata requestMetadata = buildValidRequestMetadata(requestId);
    final AuthenticTransactions authenticTransactions =
        createMultipleAuthenticTransactions(2, 2, 2);
    final StatementTransactions latestAdgTransaction =
        buildStatementTransactions(2, 15, "2", BALANCE);
    final StatementTransactions statementTransactions =
        buildMultipleStatementTransactions(2, 15, 15, 2);

    when(savingAccountDetailsService.getSavingAccountDetails(any(Long.class)))
        .thenReturn(Collections.singletonList(createSavingAccountDetails(null)));

    when(authenticService.getTransactions(any(), any(), any(), any(), any(), any(), any()))
        .thenReturn(authenticTransactions);

    when(savingAccountTransactionsService.getTransactions(
            Long.valueOf(ACCOUNT_NUMBER), 1, TransactionService.ADG_BUFFER_SIZE, transactionDates))
        .thenReturn(latestAdgTransaction);

    when(savingAccountTransactionsService.getTransactions(
            Long.valueOf(ACCOUNT_NUMBER), 1, 15, transactionDates))
        .thenReturn(statementTransactions);

    when(transactionsMapper.getTransactionsToResponse(any(), any()))
        .thenReturn(AccountTransactionsResponse.builder().build());

    transactionService.getAllTransactionsInDateRange(
        ACCOUNT_NUMBER, 15, transactionDates, requestMetadata);

    verify(accountAccessValidator)
        .validateOwnAccountAccess(ACCOUNT_NUMBER, requestMetadata, Collections.emptySet(), NOW);
    verify(savingAccountDetailsService).getSavingAccountDetails(Long.valueOf(ACCOUNT_NUMBER));
    verify(authenticService)
        .getTransactions(ACCOUNT_NUMBER, NOW.minusDays(1L), NOW, true, true, null, null);
    verify(savingAccountTransactionsService)
        .getTransactions(
            Long.valueOf(ACCOUNT_NUMBER), 1, TransactionService.ADG_BUFFER_SIZE, transactionDates);
    verify(savingAccountTransactionsService)
        .getTransactions(Long.valueOf(ACCOUNT_NUMBER), 1, 15, transactionDates);
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals", "PMD.ExcessiveMethodLength"})
  private static Stream<Arguments> mapsTransactionsToResponse() {
    return Stream.of(
        // #1 Check that it handles no transactions returned from both ADG and Authentic
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildEmptyExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "0.00",
            buildEmptyTransactionDates()),
        // #2 Check that it handles one transaction returned from ADG but none from Authentic
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildEmptyTransactionDates()),
        // #3 Check that it handles multiple transactions returned from ADG but none from Authentic
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 2, "2", BALANCE),
            buildMultipleStatementTransactions(1, 2, 2, 2),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            BALANCE,
            buildEmptyTransactionDates()),
        // #4 Check that it handles no transactions returned from ADG but one from Authentic
        Arguments.of(
            createAuthenticTransactions("1"),
            createAuthenticTransactions("1"),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            1,
            "2.00",
            buildEmptyTransactionDates()),
        // #5 Match on only transaction returned from both
        Arguments.of(
            createAuthenticTransactions("1"),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildEmptyTransactionDates()),
        // #6 Match on both transactions
        Arguments.of(
            createMultipleAuthenticTransactions(2, 2, 2),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 2, "2", BALANCE),
            buildMultipleStatementTransactions(1, 2, 2, 2),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            BALANCE,
            buildEmptyTransactionDates()),
        // #7 Match on first transaction, second is authentic-only
        Arguments.of(
            createMultipleAuthenticTransactions(2, 2, 2),
            createAuthenticTransactions("2"),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            1,
            BALANCE,
            buildEmptyTransactionDates()),
        // #8 No link found between transactions (latest ADG record more than 24 hours old)
        Arguments.of(
            createAuthenticTransactions("2"),
            createAuthenticTransactions("2"),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            1,
            BALANCE,
            buildEmptyTransactionDates()),
        // #9 Check on just under the page size limit
        Arguments.of(
            createMultipleAuthenticTransactions(9, 9, 9),
            createMultipleAuthenticTransactions(8, 8, 9),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            8,
            "18.00",
            buildEmptyTransactionDates()),
        // #10 Check on page size limit
        Arguments.of(
            createMultipleAuthenticTransactions(10, 10, 10),
            createMultipleAuthenticTransactions(9, 9, 10),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            9,
            "20.00",
            buildEmptyTransactionDates()),
        // #11 Next two cases check the transactions cover two pages when
        // an ADG record is found on the first transaction
        Arguments.of(
            createMultipleAuthenticTransactions(11, 11, 11),
            createMultipleAuthenticTransactions(10, 10, 11),
            buildStatementTransactions(),
            buildEmptyStatementTransactions(1),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            10,
            "22.00",
            buildEmptyTransactionDates()),
        // #12
        Arguments.of(
            createMultipleAuthenticTransactions(11, 11, 11),
            buildEmptyAuthenticTransactions(10),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            2,
            10,
            "22.00",
            buildEmptyTransactionDates()),
        // #13 Next two cases check the transactions cover two pages when
        // all transactions are from authentic
        Arguments.of(
            createMultipleAuthenticTransactions(11, 11, 11),
            createMultipleAuthenticTransactions(11, 10, 11),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            11,
            "22.00",
            buildEmptyTransactionDates()),
        // #14
        Arguments.of(
            createMultipleAuthenticTransactions(11, 11, 11),
            createMultipleAuthenticTransactions(11, 1, 1),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildExpectedAccountTransactionsResponse(),
            2,
            11,
            "22.00",
            buildEmptyTransactionDates()),
        // #15 Next two cases checks it can handle a request for page two when only
        // enough authentic transactions exists for one page
        Arguments.of(
            createMultipleAuthenticTransactions(10, 10, 10),
            createMultipleAuthenticTransactions(10, 10, 10),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            10,
            "20.00",
            buildEmptyTransactionDates()),
        // #16
        Arguments.of(
            createMultipleAuthenticTransactions(10, 10, 10),
            buildEmptyAuthenticTransactions(10),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildExpectedAccountTransactionsResponse(),
            2,
            10,
            "20.00",
            buildEmptyTransactionDates()),
        // #17 Next two cases checks it can handle a request for page two when only
        // enough linked transactions exists for one page
        Arguments.of(
            createMultipleAuthenticTransactions(10, 10, 10),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 10, "10", "20.00"),
            buildMultipleStatementTransactions(1, 10, 10, 10),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "20.00",
            buildEmptyTransactionDates()),
        // #18
        Arguments.of(
            createMultipleAuthenticTransactions(10, 10, 10),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 10, "10", "20.00"),
            buildEmptyStatementTransactions(10),
            buildExpectedAccountTransactionsResponse(),
            2,
            0,
            "20.00",
            buildEmptyTransactionDates()),
        // #19 Next two cases checks it can handle a request for page two when only
        // enough ADG transactions exists for one page
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 10, "10", "20.00"),
            buildMultipleStatementTransactions(1, 10, 10, 10),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "20.00",
            buildEmptyTransactionDates()),
        // #20
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 10, "10", "20.00"),
            buildEmptyStatementTransactions(10),
            buildEmptyExpectedAccountTransactionsResponse(),
            2,
            0,
            "20.00",
            buildEmptyTransactionDates()),
        // #21 Next two cases checks it doesn't make another call to ADG when it knows
        // there's only one record to find, which we already have
        Arguments.of(
            createMultipleAuthenticTransactions(20, 20, 20),
            createMultipleAuthenticTransactions(19, 10, 20),
            buildStatementTransactions(),
            buildEmptyStatementTransactions(1),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            19,
            "40.00",
            buildEmptyTransactionDates()),
        // #22
        Arguments.of(
            createMultipleAuthenticTransactions(20, 20, 20),
            createMultipleAuthenticTransactions(19, 9, 10),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            2,
            19,
            "40.00",
            buildEmptyTransactionDates()),
        // #23 Next case checks it combines all authentic and ADG together with no issues
        Arguments.of(
            createMultipleAuthenticTransactions(10, 10, 10),
            createMultipleAuthenticTransactions(5, 5, 10),
            buildStatementTransactions(1, 5, "5", "10.00"),
            buildMultipleStatementTransactions(1, 5, 5, 5),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            5,
            "20.00",
            buildEmptyTransactionDates()),
        // #24 Next two cases checks it handles one unlinked authentic transaction but overlaps
        // into two pages
        Arguments.of(
            createMultipleAuthenticTransactions(11, 11, 11),
            createAuthenticTransactions("11"),
            buildStatementTransactions(1, 10, "10", "20.00"),
            buildMultipleStatementTransactions(1, 10, 9, 10),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            1,
            "22.00",
            buildEmptyTransactionDates()),
        // #25
        Arguments.of(
            createMultipleAuthenticTransactions(11, 11, 11),
            buildEmptyAuthenticTransactions(1),
            buildStatementTransactions(1, 10, "10", "20.00"),
            buildMultipleStatementTransactions(1, 10, 1, 1),
            buildExpectedAccountTransactionsResponse(),
            2,
            1,
            "22.00",
            buildEmptyTransactionDates()),
        // #26 Next two cases checks all records are linked and overlaps into two pages
        Arguments.of(
            createMultipleAuthenticTransactions(15, 15, 15),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(2, 15, "15", "30.00"),
            buildMultipleStatementTransactions(2, 15, 10, 15),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "30.00",
            buildEmptyTransactionDates()),
        // #27
        Arguments.of(
            createMultipleAuthenticTransactions(15, 15, 15),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(2, 15, "15", "30.00"),
            buildMultipleStatementTransactions(2, 15, 5, 5),
            buildExpectedAccountTransactionsResponse(),
            2,
            0,
            "30.00",
            buildEmptyTransactionDates()),
        // #28 Page zero should return nothing
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildEmptyExpectedAccountTransactionsResponse(),
            0,
            0,
            "0.00",
            buildEmptyTransactionDates()),
        // #29 Matches on AuthUID/SourceTransactionId combination
        Arguments.of(
            buildAuthenticTransactions(buildAuthenticTransactionWithAuthUid()),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(buildStatementTransactionWithSourceTransactionId()),
            buildStatementTransactions(buildStatementTransactionWithSourceTransactionId()),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildEmptyTransactionDates()),
        // #30 Sets balance correctly when debit transactions are involved
        Arguments.of(
            buildAuthenticTransactionsCreditAndDebit(),
            buildAuthenticTransactionsCreditAndDebit(),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            5,
            "2.00",
            buildEmptyTransactionDates()),
        // #31 Tests when transaction date within range
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildTransactionDates(NOW_MINUS_ONE_SECOND, NOW)),
        // #32
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildTransactionDates(NOW, NOW_PLUS_ONE_SECOND)),
        // #33
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildTransactionDates(NOW, null)),
        // #34
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildTransactionDates(NOW_MINUS_ONE_SECOND, null)),
        // #35
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildTransactionDates(null, NOW)),
        // #36
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildTransactionDates(null, NOW_PLUS_ONE_SECOND)),
        // #37 Test transactions found but out of date range
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 1, "1", "2.00"),
            buildEmptyStatementTransactions(0),
            buildEmptyExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildTransactionDates(NOW_MINUS_TWO_SECONDS, NOW_MINUS_ONE_SECOND)),
        // #38 Test multiple transactions found in date range
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 10, "10", "20.00"),
            buildMultipleStatementTransactions(1, 10, 10, 10),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "20.00",
            buildTransactionDates(NOW_MINUS_TWO_SECONDS, NOW)),
        // #39 Test call to package again as more transactions required
        Arguments.of(
            buildEmptyAuthenticTransactions(0),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 2, "2", BALANCE),
            buildMultipleStatementTransactions(1, 2, 2, 2),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            BALANCE,
            buildTransactionDates(NOW_MINUS_TWO_SECONDS, NOW)),
        // #40 Check that it handles no transactions returned from ADG but one from Authentic
        Arguments.of(
            createAuthenticTransactions("1"),
            createAuthenticTransactions("1"),
            buildEmptyStatementTransactions(0),
            buildEmptyStatementTransactions(0),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            1,
            "2.00",
            buildTransactionDates(NOW_MINUS_TWO_SECONDS, NOW)),
        // #41 Match on only transaction returned from both
        Arguments.of(
            createAuthenticTransactions("1"),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            "2.00",
            buildTransactionDates(NOW_MINUS_TWO_SECONDS, NOW)),
        // #42 Match on both transactions
        Arguments.of(
            createMultipleAuthenticTransactions(2, 2, 2),
            buildEmptyAuthenticTransactions(0),
            buildStatementTransactions(1, 2, "2", BALANCE),
            buildMultipleStatementTransactions(1, 2, 2, 2),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            0,
            BALANCE,
            buildTransactionDates(NOW_MINUS_TWO_SECONDS, NOW)),
        // #43 Match on first transaction, second is authentic-only
        Arguments.of(
            createMultipleAuthenticTransactions(2, 2, 2),
            createAuthenticTransactions("2"),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            1,
            BALANCE,
            buildTransactionDates(NOW_MINUS_TWO_SECONDS, NOW)),
        // #44 No link found between transactions (latest ADG record more than 24 hours old)
        Arguments.of(
            createAuthenticTransactions("2"),
            createAuthenticTransactions("2"),
            buildStatementTransactions(),
            buildStatementTransactions(),
            buildExpectedAccountTransactionsResponse(),
            DEFAULT_PAGE_NUMBER,
            1,
            BALANCE,
            buildTransactionDates(NOW_MINUS_TWO_SECONDS, NOW)));
  }

  private static RequestMetadata buildValidRequestMetadata(final UUID requestId) {
    return RequestMetadata.builder()
        .host(InetSocketAddress.createUnresolved("accountservice.ybs.co.uk", 443))
        .requestId(requestId)
        .brandCode(BRAND_YBS)
        .partyId(PARTY_ID)
        .forwardingAuth("<jwt>")
        .ipAddress("12.66.53.145")
        .build();
  }

  private static AuthenticTransactions createAuthenticTransactions(final String transactionId) {
    return AuthenticTransactions.builder()
        .totalNumberOfRecords(1)
        .transactionList(
            Collections.singletonList(buildAuthenticTransaction(transactionId, CREDIT)))
        .build();
  }

  private static AuthenticTransactions createMultipleAuthenticTransactions(
      final int totalTransactions, final int noOfTransactions, final int startTransactionId) {
    final List<AuthenticTransaction> transactions = new ArrayList<>();

    final int loopEnd = startTransactionId - noOfTransactions;

    // Count down so the transactions are in the correct order
    for (int i = startTransactionId; i > loopEnd; i--) {
      transactions.add(buildAuthenticTransaction(String.valueOf(i), CREDIT));
    }

    return AuthenticTransactions.builder()
        .totalNumberOfRecords(totalTransactions)
        .transactionList(transactions)
        .build();
  }

  private static AuthenticTransactions buildEmptyAuthenticTransactions(final int totalRecords) {
    return AuthenticTransactions.builder()
        .totalNumberOfRecords(totalRecords)
        .transactionList(Collections.emptyList())
        .build();
  }

  private static AuthenticTransaction buildAuthenticTransaction(
      final String transactionId, final String creditDebitIndicator) {
    return AuthenticTransaction.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .transactionID(transactionId)
        .transactionDesc(TXN_DESC + transactionId)
        .creditorDebitIndicator(creditDebitIndicator)
        .transactionBookingDateTime(LocalDateTime.now(CLOCK))
        .financialTransactionAmount(new BigDecimal("2.00"))
        .build();
  }

  private static AuthenticTransaction buildAuthenticTransactionWithAuthUid() {
    return AuthenticTransaction.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .transactionID("1")
        .transactionDesc(TXN_DESC + "1")
        .creditorDebitIndicator(CREDIT)
        .transactionBookingDateTime(LocalDateTime.now(CLOCK))
        .financialTransactionAmount(new BigDecimal("2.00"))
        .authUid("A1")
        .build();
  }

  private static AuthenticTransactions buildAuthenticTransactions(
      final AuthenticTransaction authenticTransaction) {
    return AuthenticTransactions.builder()
        .totalNumberOfRecords(1)
        .transactionList(Collections.singletonList(authenticTransaction))
        .build();
  }

  private static AuthenticTransactions buildAuthenticTransactionsCreditAndDebit() {
    final List<AuthenticTransaction> transactions =
        Arrays.asList(
            buildAuthenticTransaction("5", DEBIT),
            buildAuthenticTransaction("4", CREDIT),
            buildAuthenticTransaction("3", DEBIT),
            buildAuthenticTransaction("2", CREDIT),
            buildAuthenticTransaction("1", CREDIT));

    return AuthenticTransactions.builder()
        .totalNumberOfRecords(5)
        .transactionList(transactions)
        .build();
  }

  private static StatementTransactions buildEmptyStatementTransactions(
      final int totalTransactions) {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(totalTransactions)
        .transactionList(Collections.emptyList())
        .build();
  }

  private static StatementTransactions buildStatementTransactions() {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(1)
        .transactionList(
            Collections.singletonList(buildStatementTransaction("1", CREDIT, "2.00", "2.00")))
        .build();
  }

  private static StatementTransactions buildStatementTransactions(
      final int totalPages,
      final int noOfTransactions,
      final String transactionId,
      final String balance) {
    return StatementTransactions.builder()
        .totalNumberOfPages(totalPages)
        .totalNumberOfTransactions(noOfTransactions)
        .transactionList(
            Collections.singletonList(
                buildStatementTransaction(transactionId, CREDIT, balance, balance)))
        .build();
  }

  private static StatementTransactions buildMultipleStatementTransactions(
      final int totalPages,
      final int totalTransactions,
      final int noOfTransactions,
      final int startTransactionId) {
    final List<StatementTransaction> transactions = new ArrayList<>();

    final int loopEnd = startTransactionId - noOfTransactions;

    final BigDecimal transactionAmount = new BigDecimal("2.00");
    BigDecimal balance = transactionAmount.multiply(new BigDecimal(startTransactionId));

    // Count down so the transactions are in the correct order
    for (int i = startTransactionId; i > loopEnd; i--) {
      transactions.add(
          buildStatementTransaction(
              String.valueOf(i), CREDIT, balance.toString(), balance.toString()));

      balance = balance.subtract(transactionAmount);
    }

    return StatementTransactions.builder()
        .totalNumberOfPages(totalPages)
        .totalNumberOfTransactions(totalTransactions)
        .transactionList(transactions)
        .build();
  }

  private static StatementTransaction buildStatementTransaction(
      final String transactionId,
      final String creditDebitIndicator,
      final String availableBalance,
      final String ledgerBalance) {
    return StatementTransaction.builder()
        .accountNumber(Long.valueOf(ACCOUNT_NUMBER))
        .transactionId(Long.valueOf(transactionId))
        .transactionRef(TXN_DESC + transactionId)
        .transactionIndicator(creditDebitIndicator)
        .status("Booked")
        .bookingDate(LocalDateTime.now(CLOCK))
        .valueDate(LocalDateTime.now(CLOCK))
        .transactionAmount(new BigDecimal("2.00"))
        .availableBalanceAfterTxn(new BigDecimal(availableBalance))
        .ledgerBalanceAfterTxn(new BigDecimal(ledgerBalance))
        .transactionMethod("TxnMethod")
        .transactionTypeCode("TxnCode")
        .information("TransactionInformation")
        .build();
  }

  private static StatementTransaction buildStatementTransactionWithSourceTransactionId() {
    return StatementTransaction.builder()
        .accountNumber(Long.valueOf(ACCOUNT_NUMBER))
        .transactionId(2L)
        .transactionRef("TxnDesc 2")
        .transactionIndicator(CREDIT)
        .status("Booked")
        .bookingDate(LocalDateTime.now(CLOCK))
        .valueDate(LocalDateTime.now(CLOCK))
        .transactionAmount(new BigDecimal("2.00"))
        .availableBalanceAfterTxn(new BigDecimal("2.00"))
        .ledgerBalanceAfterTxn(new BigDecimal("2.00"))
        .transactionMethod("TxnMethod")
        .transactionTypeCode("TxnCode")
        .information("TransactionInformation")
        .sourceTransactionId("A1")
        .build();
  }

  private static StatementTransactions buildStatementTransactions(
      final StatementTransaction statementTransaction) {
    return StatementTransactions.builder()
        .totalNumberOfPages(1)
        .totalNumberOfTransactions(1)
        .transactionList(Collections.singletonList(statementTransaction))
        .build();
  }

  private static List<AccountBalanceType> buildTransactionBalancesAuthentic(
      final BigDecimal amount) {
    return Collections.singletonList(
        AccountBalanceType.builder().balanceType("CapitalLedger").balanceAmount(amount).build());
  }

  private static AccountTransactionsResponse.Transaction createResponseTransaction(
      final Instant dateTime, final BigDecimal amount, final List<Balance> balances) {
    return AccountTransactionsResponse.Transaction.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .transactionId("1")
        .transactionReference(TXN_DESC + "1")
        .creditDebitIndicator(CREDIT)
        .status("Booked")
        .bookingDateTime(dateTime)
        .valueDateTime(dateTime)
        .amount(
            AccountTransactionsResponse.Amount.builder()
                .amount(amount.toString())
                .currency("GBP")
                .build())
        .transactionCode(null)
        .transactionInformation("TxnDesc 1")
        .balances(balances)
        .build();
  }

  private static List<Balance> createExpectedBalancesAuthentic() {
    return Collections.singletonList(
        Balance.builder().type("InterimAvailable").amount(new BigDecimal("2.00")).build());
  }

  private static SavingAccountDetails createSavingAccountDetails(final LocalDate closedDate) {
    return SavingAccountDetails.builder()
        .accountNumber(Long.valueOf(ACCOUNT_NUMBER))
        .currencyCode("GBP")
        .accountName("ACC_NAME1")
        .sortCode(123456)
        .productIdentifier("INTSAV")
        .productType("SAVER")
        .productName("Internet Saver")
        .isPaymentAccount(true)
        .closedDate(closedDate)
        .brandCode("YBS")
        .interestInstruction("Payaway")
        .nextInterestDate(LocalDate.of(2018, 9, 29))
        .interestFrequency("Monthly")
        .accountInterestFrequency("Monthly")
        .annualEquivalentRate("3.12")
        .interestRate("3.11")
        .build();
  }

  private static AccountTransactionsResponse buildExpectedAccountTransactionsResponse() {
    final List<AccountTransactionsResponse.Transaction> transactions =
        Collections.singletonList(
            createResponseTransaction(
                Instant.now(CLOCK), new BigDecimal("2.00"), createExpectedBalancesAuthentic()));

    return AccountTransactionsResponse.builder()
        .transactions(transactions)
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).build())
        .build();
  }

  private static AccountTransactionsResponse buildEmptyExpectedAccountTransactionsResponse() {
    return AccountTransactionsResponse.builder()
        .transactions(Collections.emptyList())
        .meta(AccountTransactionsResponse.Meta.builder().totalPages(1).build())
        .build();
  }

  private static TransactionDates buildEmptyTransactionDates() {
    return TransactionDates.builder().build();
  }

  private static TransactionDates buildTransactionDates(
      final LocalDateTime startDate, final LocalDateTime endDate) {
    return TransactionDates.builder().startDate(startDate).endDate(endDate).build();
  }

  private boolean transactionDateWithinRange(
      final LocalDateTime transactionDate, final TransactionDates transactionDates) {

    if (transactionDates.getStartDate() != null) {
      if (transactionDate.compareTo(transactionDates.getStartDate()) < 0) {
        return false;
      }
    }

    if (transactionDates.getEndDate() != null) {
      return transactionDate.compareTo(transactionDates.getEndDate()) <= 0;
    }
    return true;
  }
}
