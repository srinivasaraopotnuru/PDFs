package uk.co.ybs.digital.account.repository.core;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.model.core.AccountNumber;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.RestrictionType;
import uk.co.ybs.digital.account.model.core.WarningNote;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("accountProcessorTransactionManager")
class WarningNotesCoreRepositoryTest {
  private static final String NOTES = "SOME NOTES";
  private static final Long PRODUCT_ID = 1001L;
  private static final Long ACCOUNT_NUMBER_1 = 2001L;
  private static final String RESTRICTION_TYPE_CODE_1 = "RTYP1";
  private static final String CREATED_AT = "PROSRV";
  private static final String CREATED_BY = "0000123456";

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");

  @Autowired WarningNoteCoreRepository testSubject;

  @Autowired TestEntityManager coreTestEntityManager;

  private TestHelper helper;

  @BeforeEach
  void beforeEach() {
    helper = new TestHelper(coreTestEntityManager);
    helper.persistSavingProduct(PRODUCT_ID);
  }

  @Test
  void shouldFindById() {
    final WarningNote warningNote = persistAndFlushWarningNoteAndDefaultDependencies();
    final Optional<WarningNote> found = testSubject.findById(warningNote.getSysId());

    assertTrue(found.isPresent());
    assertThat(found.get(), samePropertyValuesAs(warningNote));
  }

  @Test
  void shouldUpdateWarningNote() {
    final WarningNote warningNote = persistAndFlushWarningNoteAndDefaultDependencies();
    final Optional<WarningNote> found = testSubject.findById(warningNote.getSysId());
    assertTrue(found.isPresent());

    final WarningNote updatedWarningNote =
        found.get().toBuilder().endDate(NOW.toLocalDate()).endedAt("1234").endedBy("SAPP").build();
    updateWarningNote(updatedWarningNote);

    final Optional<WarningNote> foundUpdated = testSubject.findById(warningNote.getSysId());

    assertTrue(foundUpdated.isPresent());
    assertThat(foundUpdated.get(), samePropertyValuesAs(updatedWarningNote));
  }

  @ParameterizedTest
  @MethodSource("startDateAndExpectedFoundWarningNoteStatus")
  void shouldOnlyFindWarningNoteWhenWarningNoteHasStarted(
      final LocalDateTime startDate, final Boolean expectedFound) {
    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        helper.persistRestrictionType(
            helper.buildRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW));
    final AccountWarning accountWarning =
        helper.persistAccountWarning(
            helper.buildAccountWarning(accountNumber, restrictionType, NOW, null));
    helper.persistWarningNote(
        helper.buildWarningNote(
            accountWarning.getSysId(), startDate, CREATED_AT, NOW, CREATED_BY, NOTES));

    final Collection<WarningNote> accountWarnings =
        testSubject.findWarningNoteByAccountWarningSysId(accountWarning.getSysId(), NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @ParameterizedTest
  @MethodSource("endDateAndExpectedFoundWarningNoteStatus")
  void shouldOnlyFindWarningNoteWhenWarningNoteHasNotEnded(
      final LocalDate endDate, final Boolean expectedFound) {
    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        helper.persistRestrictionType(
            helper.buildRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW));
    final AccountWarning accountWarning =
        helper.persistAccountWarning(
            helper.buildAccountWarning(accountNumber, restrictionType, NOW, null));
    helper.persistWarningNote(
        WarningNote.builder()
            .accountWarningSysId(accountWarning.getSysId())
            .startDate(NOW)
            .endDate(endDate)
            .createdAt(CREATED_AT)
            .createdDate(NOW)
            .createdBy(CREATED_BY)
            .notes(NOTES)
            .build());
    coreTestEntityManager.clear();

    final Collection<WarningNote> accountWarnings =
        testSubject.findWarningNoteByAccountWarningSysId(accountWarning.getSysId(), NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @Test
  void shouldOnlyFindWarningNoteWhenAccountWarningSysIdMatches() {
    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        helper.persistRestrictionType(
            helper.buildRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW));
    final AccountWarning accountWarning =
        helper.persistAccountWarning(
            helper.buildAccountWarning(accountNumber, restrictionType, NOW, null));
    helper.persistWarningNote(
        helper.buildWarningNote(
            accountWarning.getSysId(), NOW, CREATED_AT, NOW, CREATED_BY, NOTES));

    final Collection<WarningNote> accountWarningsInvalidId =
        testSubject.findWarningNoteByAccountWarningSysId(9999L, NOW);
    assertTrue(accountWarningsInvalidId.isEmpty());

    final Collection<WarningNote> accountWarningsWithValidId =
        testSubject.findWarningNoteByAccountWarningSysId(accountWarning.getSysId(), NOW);

    assertThat(accountWarningsWithValidId, is(accountWarningsWithValidId));
  }

  private WarningNote persistAndFlushWarningNoteAndDefaultDependencies() {
    final AccountNumber accountNumber = helper.persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        helper.persistRestrictionType(
            helper.buildRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW));
    final AccountWarning accountWarning =
        helper.persistAccountWarning(
            helper.buildAccountWarning(accountNumber, restrictionType, NOW, null));
    final WarningNote warningNote =
        helper.persistWarningNote(
            helper.buildWarningNote(
                accountWarning.getSysId(), NOW, CREATED_AT, NOW, CREATED_BY, NOTES));
    return warningNote;
  }

  private void updateWarningNote(final WarningNote warningNote) {
    coreTestEntityManager.merge(warningNote);
    coreTestEntityManager.flush();
    coreTestEntityManager.clear();
  }

  private static Stream<Arguments> endDateAndExpectedFoundWarningNoteStatus() {
    return Stream.of(
        Arguments.of(NOW.minusDays(1).toLocalDate(), false),
        Arguments.of(NOW.toLocalDate(), false),
        Arguments.of(NOW.plusDays(1).toLocalDate(), true),
        Arguments.of(null, true));
  }

  private static Stream<Arguments> startDateAndExpectedFoundWarningNoteStatus() {
    return Stream.of(
        Arguments.of(NOW.minusDays(1), true),
        Arguments.of(NOW, true),
        Arguments.of(NOW.plusDays(1), false));
  }
}
