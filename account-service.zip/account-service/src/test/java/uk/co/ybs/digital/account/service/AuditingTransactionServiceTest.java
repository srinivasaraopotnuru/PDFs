package uk.co.ybs.digital.account.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.sameInstance;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.TransactionDates;

@ExtendWith(MockitoExtension.class)
class AuditingTransactionServiceTest {
  private static final String ACCOUNT_NUMBER = "1234567891";
  private static final int PAGE_NUMBER = 1;

  @InjectMocks private AuditingTransactionService testSubject;

  @Mock private TransactionService transactionService;

  @Mock private AccountAuditor accountAuditor;

  @Test
  void shouldGetTransactions() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final TransactionDates transactionDates = TransactionDates.builder().build();
    final AccountTransactionsResponse expectedResponse =
        AccountTransactionsResponse.builder().build();
    when(transactionService.getTransactions(
            ACCOUNT_NUMBER, PAGE_NUMBER, transactionDates, requestMetadata))
        .thenReturn(expectedResponse);

    final AccountTransactionsResponse response =
        testSubject.getTransactions(ACCOUNT_NUMBER, PAGE_NUMBER, transactionDates, requestMetadata);
    assertThat(response, sameInstance(expectedResponse));

    verify(accountAuditor)
        .auditAccountTransactions(
            same(ACCOUNT_NUMBER), same(requestMetadata), same(expectedResponse));
    verifyNoMoreInteractions(accountAuditor);
  }

  private RequestMetadata buildRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 80);
  }
}
