package uk.co.ybs.digital.account.model.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Optional;
import org.junit.jupiter.api.Test;

class SavingAccountAnnualWithdrawalLimitTest {

  private static final long PRODUCT_SYS_ID = 3000L;

  @Test
  void getNonZeroWithdrawalsAllowedShouldReturnEmptyOptionalWhenWithdrawalsAllowedIsZero() {
    assertThat(
        savingAccountAnnualWithdrawalLimit(0, 0).getNonZeroWithdrawalsAllowed(),
        is(Optional.empty()));
  }

  @Test
  void getNonZeroWithdrawalsAllowedShouldReturnWithdrawalsAllowed() {
    assertThat(
        savingAccountAnnualWithdrawalLimit(10, 0).getNonZeroWithdrawalsAllowed(),
        is(Optional.of(10)));
  }

  @Test
  void getAvailableWithdrawalsShouldReturnEmptyOptionalWhenWithdrawalsAllowedIsZero() {
    assertThat(
        savingAccountAnnualWithdrawalLimit(0, 5).getAvailableWithdrawals(), is(Optional.empty()));
  }

  @Test
  void getAvailableWithdrawalsShouldReturnAvailableWithdrawals() {
    assertThat(
        savingAccountAnnualWithdrawalLimit(10, 2).getAvailableWithdrawals(), is(Optional.of(8)));
  }

  @Test
  void
      getAvailableWithdrawalsShouldReturnAvailableWithdrawalsWhenAmountMadeIsMoreThanAmountAllowed() {
    assertThat(
        savingAccountAnnualWithdrawalLimit(10, 12).getAvailableWithdrawals(), is(Optional.of(0)));
  }

  private static SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit(
      final int allowed, final int made) {
    return SavingAccountAnnualWithdrawalLimit.builder()
        .sysId(1000L)
        .accountNumber(new AccountNumber(2000L, AccountNumber.TABLE_ID_SAVACC, PRODUCT_SYS_ID))
        .savingProductSysId(PRODUCT_SYS_ID)
        .withdrawalsAllowed(allowed)
        .withdrawalsMade(made)
        .yearStart(null)
        .build();
  }
}
