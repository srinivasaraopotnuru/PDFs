package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class DepositsPermittedOverApiMapperTest {
  private static final String ACCOUNT_NUMBER = "12345678";

  private static final boolean MIGRATING_PRODUCT = true;
  private static final boolean NOT_MIGRATING_PRODUCT = false;
  private static final boolean ACCOUNT_CLOSED = true;
  private static final boolean ACCOUNT_NOT_CLOSED = false;

  private DepositsPermittedOverApiMapper testSubject;

  @BeforeEach
  void setUp() {
    testSubject = new DepositsPermittedOverApiMapper();
  }

  @ParameterizedTest
  @MethodSource("depositsPermittedOverApiArgs")
  void shouldMapDeposits(
      final String label,
      final boolean productAllowsInternalDeposits,
      final boolean productMigrationInProgress,
      final boolean depositsBlockedByAccountWarnings,
      final boolean accountClosed,
      final boolean expected) {

    final boolean mapped =
        testSubject.depositsPermittedOverApi(
            ACCOUNT_NUMBER,
            productAllowsInternalDeposits,
            productMigrationInProgress,
            depositsBlockedByAccountWarnings,
            accountClosed);

    assertThat(mapped, is(expected));
  }

  private static Stream<Arguments> depositsPermittedOverApiArgs() {
    return Stream.of(
        Arguments.of("permitted", true, NOT_MIGRATING_PRODUCT, false, ACCOUNT_NOT_CLOSED, true),
        Arguments.of(
            "product deposits not permitted internal",
            false,
            NOT_MIGRATING_PRODUCT,
            false,
            ACCOUNT_NOT_CLOSED,
            false),
        Arguments.of("account closed", true, NOT_MIGRATING_PRODUCT, false, ACCOUNT_CLOSED, false),
        Arguments.of(
            "account migrating product", true, MIGRATING_PRODUCT, false, ACCOUNT_NOT_CLOSED, false),
        Arguments.of(
            " account warning", true, NOT_MIGRATING_PRODUCT, true, ACCOUNT_NOT_CLOSED, false));
  }
}
