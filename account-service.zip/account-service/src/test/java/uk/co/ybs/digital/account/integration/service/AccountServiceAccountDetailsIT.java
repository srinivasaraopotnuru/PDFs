package uk.co.ybs.digital.account.integration.service;

import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_ADD_REGULAR_INTERNAL_TRANSFER;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMMENCE;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_DEPOSIT_COMMENCE;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.reactive.server.WebTestClient;
import uk.co.ybs.digital.account.config.TestClockConfig;
import uk.co.ybs.digital.account.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.account.integration.IntegrationTestConfig;
import uk.co.ybs.digital.account.model.adgcore.Country;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Operation;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Status;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.account.repository.adgcore.WithdrawalInterestPenaltyRepository;
import uk.co.ybs.digital.account.service.SavingAccountDetailsListService;
import uk.co.ybs.digital.account.service.SavingAccountDetailsService;
import uk.co.ybs.digital.account.service.SavingAccountTransactionsService;
import uk.co.ybs.digital.account.utils.AccountAccessRequiredEntities;
import uk.co.ybs.digital.account.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.ErrorResponse;
import uk.co.ybs.digital.account.web.dto.AccountDetails;
import uk.co.ybs.digital.account.web.dto.AccountDetailsResponse;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.Closure;
import uk.co.ybs.digital.account.web.dto.Deposits;
import uk.co.ybs.digital.account.web.dto.Interest;
import uk.co.ybs.digital.account.web.dto.InterestTier;
import uk.co.ybs.digital.account.web.dto.Isa;
import uk.co.ybs.digital.account.web.dto.Product;
import uk.co.ybs.digital.account.web.dto.Reinvestment;
import uk.co.ybs.digital.account.web.dto.Restriction;
import uk.co.ybs.digital.account.web.dto.RestrictionCategory;
import uk.co.ybs.digital.account.web.dto.UpdateAccountDetails;
import uk.co.ybs.digital.account.web.dto.WithdrawalLimit;
import uk.co.ybs.digital.account.web.dto.Withdrawals;

@SuppressWarnings({"SameParameterValue", "deprecation"})
@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class, TestClockConfig.class},
    properties = "spring.main.allow-bean-definition-overriding=true")
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AccountServiceAccountDetailsIT extends AccountServiceITBase {

  public static final BigDecimal DEPOSIT_AMOUNT = new BigDecimal("45.00");
  @LocalServerPort private int port;

  @Autowired private WebTestClient signingWebClientPublic;

  @Autowired private WebTestClient signingWebClientPrivate;
  @Autowired private Clock clock;
  private static final String PRODUCT_ID_CODE = "INTSAV";
  private static final String PRODUCT_ID_CODE_BOND = "FIXEDBOND";
  private static final BigDecimal MAX_PRODUCT_BAL_REMAINING = BigDecimal.valueOf(99843.59);
  private static final LocalDateTime COPY_DB_UPDATE_TIME =
      LocalDateTime.parse("2020-04-06T12:34:56");

  private static final String ISA_PRODUCT_ID_CODE = "EGG302A";

  private static final String SINGLE_SIGNATURE_WIT_CODE = "SSIGN";

  /*
   * See comment in WithdrawalInterestPenaltyRepository on why a mock is being used
   */
  @MockBean private WithdrawalInterestPenaltyRepository withdrawalInterestPenaltyRepository;
  @MockBean private SavingAccountDetailsService savingAccountDetailsService;
  @MockBean private SavingAccountDetailsListService savingAccountDetailsListService;
  @MockBean private SavingAccountTransactionsService savingAccountTransactionsService;

  private static Stream<Arguments> queryParamsAndWithdrawalsPermittedFlag() {
    return Stream.of(
        Arguments.of(ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS, true),
        Arguments.of(ACCOUNT_DETAIL_WITH_FILTERS, false));
  }

  @SuppressWarnings({"PMD.ExcessiveParameterList", "PMD.AvoidDuplicateLiterals"})
  static AccountDetails createAccountDetailsResponse(
      final LocalDate closedDate,
      final Product productInfo,
      final Deposits deposits,
      final Withdrawals withdrawals,
      final Isa isa,
      final boolean amendmentRestriction,
      final boolean smartTiered,
      final boolean reinvestmentPermitted,
      final boolean manageInterestPermitted,
      final boolean closurePermitted) {
    final List<Balance> balances =
        closedDate == null
            ? new ArrayList<>(
                Arrays.asList(
                    Balance.builder()
                        .type("InterimAvailable")
                        .amount(new BigDecimal("56.76"))
                        .build(),
                    Balance.builder()
                        .type("InterimBooked")
                        .amount(new BigDecimal("156.41"))
                        .build()))
            : new ArrayList<>(
                Arrays.asList(
                    Balance.builder()
                        .type("InterimAvailable")
                        .amount(new BigDecimal(ZERO_BALANCE))
                        .build(),
                    Balance.builder()
                        .type("InterimBooked")
                        .amount(new BigDecimal(ZERO_BALANCE))
                        .build()));

    if (!withdrawals.isPermittedOverApi()) {
      balances.removeIf(balance -> "InterimAvailable".equals(balance.getType()));
    }

    final Reinvestment reinvestment =
        Reinvestment.builder().permittedOverApi(reinvestmentPermitted).build();

    final Closure closure = Closure.builder().permittedOverApi(closurePermitted).build();

    return AccountDetails.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .accountName("ACC_NAME1")
        .amendmentRestriction(amendmentRestriction)
        .accountSortCode("123456")
        .currency("GBP")
        .externalAccountNumber("12345678")
        .productIdentifier(productInfo.getIdentifier())
        .productDescription(productInfo.getDescription())
        .product(productInfo)
        .balances(balances)
        .openedDate(ACCOUNT1_OPENED_DATE_TIME.toLocalDate())
        .closedDate(closedDate)
        .interest(buildInterests(smartTiered, manageInterestPermitted))
        .deposits(deposits)
        .withdrawals(withdrawals)
        .isa(isa)
        .reinvestment(reinvestment)
        .closure(closure)
        .build();
  }

  private static Interest buildInterests(
      final boolean smartTiered, final boolean interestOptionsPermitted) {
    final Interest interests;
    if (!smartTiered) {
      interests =
          Interest.builder()
              .interestInstruction("Payaway")
              .nextPaymentDate(LocalDate.of(2018, 9, 29))
              .calculationFrequency(MONTHLY_FREQUENCY)
              .applicationFrequency(MONTHLY_FREQUENCY)
              .interestOptionsPermitted(interestOptionsPermitted)
              .interestTiers(
                  Collections.singletonList(
                      InterestTier.builder()
                          .interestRate("3.11")
                          .annualEquivalentRate("3.12")
                          .build()))
              .build();

    } else {
      interests =
          Interest.builder()
              .interestInstruction("Payaway")
              .nextPaymentDate(LocalDate.of(2018, 9, 29))
              .calculationFrequency(MONTHLY_FREQUENCY)
              .applicationFrequency(MONTHLY_FREQUENCY)
              .interestOptionsPermitted(interestOptionsPermitted)
              .interestTiers(
                  Arrays.asList(
                      InterestTier.builder()
                          .annualEquivalentRate("0.75")
                          .interestRate("0.75")
                          .rangeLow(new BigDecimal("0.00"))
                          .rangeHigh(new BigDecimal("999.99"))
                          .build(),
                      InterestTier.builder()
                          .annualEquivalentRate("1.00")
                          .interestRate("1.00")
                          .rangeLow(new BigDecimal("1000.00"))
                          .rangeHigh(new BigDecimal("9999.99"))
                          .build()))
              .build();
    }
    return interests;
  }

  private static WithdrawalLimit withdrawalLimit(final int withdrawalsMade) {
    return WithdrawalLimit.builder()
        .permitted(WITHDRAWAL_LIMIT)
        .available(WITHDRAWAL_LIMIT - withdrawalsMade)
        .periodEnd(WITHDRAWAL_LIMIT_PERIOD_END)
        .build();
  }

  private static Withdrawals createWithdrawals(
      final boolean withdrawalsPermittedOverApi, final boolean withRestrictions) {
    return createWithdrawals(withdrawalsPermittedOverApi, null, withRestrictions);
  }

  private static Withdrawals createWithdrawalsWithLimit(final int withdrawalsMade) {
    final boolean withdrawalsPermittedOverApi = withdrawalsMade < WITHDRAWAL_LIMIT;
    return createWithdrawals(withdrawalsPermittedOverApi, withdrawalLimit(withdrawalsMade), false);
  }

  private static Withdrawals createWithdrawals(
      final boolean withdrawalsPermittedOverApi,
      final WithdrawalLimit withdrawalLimit,
      final boolean withRestrictions) {

    return createWithdrawals(
        withdrawalsPermittedOverApi, withdrawalLimit, withRestrictions, true, false, false);
  }

  private static Withdrawals createWithdrawals(
      final boolean withdrawalsPermittedOverApi,
      final WithdrawalLimit withdrawalLimit,
      final boolean withRestrictions,
      final boolean productAllowsWithdrawals,
      final boolean productMigrationInProgress,
      final boolean accountClosed) {

    final Withdrawals.WithdrawalsBuilder builder =
        Withdrawals.builder()
            .permittedOverApi(withdrawalsPermittedOverApi)
            .permittedRules(
                TestHelper.buildPermittedRules(
                    productAllowsWithdrawals,
                    productMigrationInProgress,
                    withRestrictions,
                    accountClosed))
            .limit(withdrawalLimit);

    if (withRestrictions) {
      builder.restrictions(
          Collections.singletonList(
              Restriction.builder()
                  .code(RestrictionCategory.WITHDRAWAL_DEFAULT)
                  .restrictionTypes(Collections.singleton(RTYPE))
                  .build()));
    }
    return builder.build();
  }

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Product isaProduct() {
    return getProduct(ISA_PRODUCT_ID_CODE, "ISA 1.20% FIXED RATE TO 29/02/2020 ANN", "ISA", false);
  }

  private static Product tieredProduct() {
    return getProduct(PRODUCT_ID_CODE, "Internet Tiered", "SAVER", true);
  }

  @Test
  void getAccountDetailsShouldReturnAccountDetailsForAccountWithAccountRestrictions()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithAccountRestrictions(
        BASE_PATH_PUBLIC, signingWebClientPublic, true, "");
  }

  @Test
  void privateGetAccountDetailsShouldReturnAccountDetailsForAccountWithAccountRestrictions()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithAccountRestrictions(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  private void getAccountDetailsShouldReturnAccountDetailsForAccountWithAccountRestrictions(
      final String basePath,
      final WebTestClient webTestClient,
      final boolean expectAudit,
      final String queryParams)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final AccountAccessRequiredEntities accountAccessRequiredEntities =
        setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml"); // NOPMD

    final RestrictionType restrictionType = setUpRestrictionType(RTYPE, 1001L, 2001L, 2002L);
    setupAccountWarning(1L, accountAccessRequiredEntities.getAccountNumber(), restrictionType);
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfo.json")); // NOPMD

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(
                        false, false, null, MAX_PRODUCT_BAL_REMAINING, true, true, false, false),
                    createWithdrawals(false, null, true, true, false, false),
                    null,
                    true,
                    false,
                    false,
                    false,
                    false))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @Test
  void getAccountDetailsShouldReturnAccountDetailsForAccountWithMonthlyDepositLimit()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithMonthlyDepositLimit(
        BASE_PATH_PUBLIC, signingWebClientPublic, true, "", true);
  }

  @ParameterizedTest
  @MethodSource("queryParamsAndWithdrawalsPermittedFlag")
  void privateGetAccountDetailsShouldReturnAccountDetailsForAccountWithMonthlyDepositLimit(
      final String queryParams, final boolean withdrawalsPermitted)
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithMonthlyDepositLimit(
        BASE_PATH_PRIVATE, signingWebClientPrivate, false, queryParams, withdrawalsPermitted);
  }

  private void getAccountDetailsShouldReturnAccountDetailsForAccountWithMonthlyDepositLimit(
      final String basePath,
      final WebTestClient webTestClient,
      final boolean expectAudit,
      final String queryParams,
      final boolean withdrawalsPermitted)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final LocalDateTime today = LocalDateTime.now(clock);

    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    stubMockProductServiceResponse(
        new ClassPathResource("/it/productInfoMonthlyDepositLimit.json"));
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    setupSavingTransaction(
        SAVING_TRANSACTION_SYSID_SYNCED_WITH_AUTHENTIC,
        accountNumber,
        today,
        new BigDecimal("2.00"));

    stubAuthenticGetTransactionsCall("/it/AuthenticTransactionsResponse#1.xml"); // NOPMD

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(true, DEPOSIT_AMOUNT, MAX_PRODUCT_BAL_REMAINING, false),
                    createWithdrawals(withdrawalsPermitted, false),
                    null,
                    false,
                    false,
                    false,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @Test
  void getAccountDetailsShouldReturnAccountDetailsForAccountWithTaxYearDepositLimit()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithTaxYearDepositLimit(
        BASE_PATH_PUBLIC, signingWebClientPublic, true, "");
  }

  @Test
  void getAccountDetailsShouldReturnAccountDetailsForAccountWithIsaSubscriptionFlag()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithIsaSubscriptionFlag(
        BASE_PATH_PUBLIC, signingWebClientPublic, true, "");
  }

  @Test
  void privateGetAccountDetailsShouldReturnAccountDetailsForAccountWithIsaSubscriptionFlag()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithIsaSubscriptionFlag(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @Test
  void privateGetAccountDetailsShouldReturnAccountDetailsForAccountWithTaxYearDepositLimit()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithTaxYearDepositLimit(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals"})
  private void getAccountDetailsShouldReturnAccountDetailsForAccountWithTaxYearDepositLimit(
      final String basePath,
      final WebTestClient webTestClient,
      final boolean expectAudit,
      final String queryParams)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final LocalDateTime today = LocalDateTime.now(clock);

    setupCopyDbMetadata(COPY_DB_UPDATE_TIME);
    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(accountNumber))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    stubMockProductServiceResponse(
        new ClassPathResource("/it/productInfoTaxYearDepositLimit.json"));
    stubMockProductServiceResponse(new ClassPathResource("/it/reinvestmentProducts.json"));
    setupOpenSavingAccount(accountNumber);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    setupTessaDetails(accountNumber);

    setupSavingTransaction(
        SAVING_TRANSACTION_SYSID_SYNCED_WITH_AUTHENTIC, accountNumber, today, new BigDecimal(2));

    stubAuthenticGetTransactionsCall("/it/AuthenticTransactionsResponse#1.xml");

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    getProduct(PRODUCT_ID_CODE, "Internet Saver", "ISA", false),
                    createDeposits(true, DEPOSIT_AMOUNT, MAX_PRODUCT_BAL_REMAINING, false),
                    createWithdrawals(true, false),
                    createIsa(false),
                    false,
                    false,
                    true,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  private void getAccountDetailsShouldReturnAccountDetailsForAccountWithIsaSubscriptionFlag(
      final String basePath,
      final WebTestClient webTestClient,
      final boolean expectAudit,
      final String queryParams)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoWithIsa.json"));
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    setupTessaDetailsWithDateFirstSub(accountNumber);

    stubAuthenticGetTransactionsCall("/it/AuthenticTransactionsResponse#1.xml");

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(true, null, MAX_PRODUCT_BAL_REMAINING, false),
                    createWithdrawals(true, false),
                    createIsa(true),
                    false,
                    false,
                    false,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @Test
  void getAccountDetailsShouldReturnAccountDetailsForAccountWithPendingIsaDeclaration()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithPendingIsaDeclaration(
        BASE_PATH_PUBLIC, signingWebClientPublic, true, "");
  }

  @Test
  void privateGetAccountDetailsShouldReturnAccountDetailsForAccountWithPendingIsaDeclaration()
      throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithPendingIsaDeclaration(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals"})
  private void getAccountDetailsShouldReturnAccountDetailsForAccountWithPendingIsaDeclaration(
      final String basePath,
      final WebTestClient webTestClient,
      final boolean expectAudit,
      final String queryParams)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final LocalDateTime today = LocalDateTime.now(clock);

    setupCopyDbMetadata(COPY_DB_UPDATE_TIME);
    final AccountAccessRequiredEntities accountAccessRequiredEntities =
        setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails =
        createSavingAccountDetails(null, ISA_PRODUCT_ID_CODE);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");

    final RestrictionType restrictionType1 =
        setUpRestrictionTypeRuleWithRestrictionType(NOSUBS, 1001L, 2001L, WEBREC);
    final RestrictionType restrictionType2 =
        setUpRestrictionTypeRuleWithRestrictionType(RTYPE, 1002L, 2003L, "RULE1");
    setupAccountWarning(1L, accountAccessRequiredEntities.getAccountNumber(), restrictionType1);
    setupAccountWarning(2L, accountAccessRequiredEntities.getAccountNumber(), restrictionType2);

    setUpAccountsWithPendingIsaDeclaration(accountNumber, today, today);
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);
    stubMockProductServiceResponse(new ClassPathResource("/it/isaProductInfo.json")); // NOPMD
    stubMockProductServiceResponse(new ClassPathResource("/it/reinvestmentProducts.json"));

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    isaProduct(),
                    createDeposits(true, null, MAX_PRODUCT_BAL_REMAINING, false),
                    createWithdrawals(true, false),
                    Isa.builder().flexible(false).helpToBuy(false).subscribed(false).build(),
                    false,
                    false,
                    true,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt, ISA_PRODUCT_ID_CODE);
  }

  @Test
  void getAccountDetailsShouldReturnAccountDetailsForAccountWithProductMigration()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    setUpProductMigrationInProgress(accountNumber);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfo.json")); // NOPMD
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);

    stubMockAuditServiceResponse();

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(false, false, null, null, false, true, true, false),
                    createWithdrawals(false, null, false, true, true, false),
                    null,
                    false,
                    false,
                    false,
                    false,
                    true))
            .build();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(true, requestId, jwt);
  }

  @ParameterizedTest
  @ValueSource(ints = {WITHDRAWAL_LIMIT, WITHDRAWAL_LIMIT_NOT_REACHED})
  void getAccountDetailsShouldReturnAccountDetailsForAccountWithWithdrawalLimit(
      final int withdrawalsMade) throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithWithdrawalLimit(
        BASE_PATH_PUBLIC, signingWebClientPublic, withdrawalsMade, true, "");
  }

  @ParameterizedTest
  @ValueSource(ints = {WITHDRAWAL_LIMIT, WITHDRAWAL_LIMIT_NOT_REACHED})
  void privateGetAccountDetailsShouldReturnAccountDetailsForAccountWithWithdrawalLimit(
      final int withdrawalsMade) throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsForAccountWithWithdrawalLimit(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        withdrawalsMade,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  private void getAccountDetailsShouldReturnAccountDetailsForAccountWithWithdrawalLimit(
      final String basePath,
      final WebTestClient webTestClient,
      final int withdrawalsMade,
      final boolean expectAudit,
      final String queryParams)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final AccountAccessRequiredEntities accessEntities =
        setUpAccountAccessRequiredEntities(ACCOUNT_NUMBER_LONG, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml"); // NOPMD
    setUpAnnualWithdrawalLimits(
        1L, withdrawalsMade, accessEntities.getAccountNumber(), accessEntities.getSavingProduct());
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoWithdrawalLimit.json"));

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(true, MAX_PRODUCT_BAL_REMAINING),
                    createWithdrawalsWithLimit(withdrawalsMade),
                    null,
                    false,
                    false,
                    false,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @Test
  void getAccountDetailsShouldReturnAccountDetailsResponseWhenRequestIsValidForClosedAccount()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    final LocalDate closedDate = LocalDate.of(2020, 1, 1);
    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    closedDate,
                    intSavProduct(),
                    createDeposits(false, false, null, null, false, true, false, true),
                    createWithdrawals(false, null, false, true, false, true),
                    null,
                    false,
                    false,
                    false,
                    false,
                    false))
            .build();

    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final AccountAccessRequiredEntities accessEntities =
        setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails =
        createSavingAccountDetails(LocalDate.of(2020, 1, 1));
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    setUpAnnualWithdrawalLimits(
        1L,
        WITHDRAWAL_LIMIT_NOT_REACHED,
        accessEntities.getAccountNumber(),
        accessEntities.getSavingProduct());
    setupSavingAccount(
        ACCOUNT_NUMBER_LONG,
        ACCOUNT1_OPENED_DATE_TIME,
        closedDate.atStartOfDay(),
        new BigDecimal(ZERO_BALANCE),
        new BigDecimal(ZERO_BALANCE));
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfo.json"));
    stubMockAuditServiceResponse();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertProductServiceCall(requestId, jwt, "/product/private/product/INTSAV");
    assertAuditAccountDetails(requestId, jwt);
  }

  @Test
  void privateGetAccountDetailsShouldReturnAccountDetailsForAccountWithDepositLimitFiltered()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    stubMockProductServiceResponse(
        new ClassPathResource("/it/productInfoMonthlyDepositLimit.json"));
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(true, null, null, false),
                    createWithdrawals(true, false),
                    null,
                    false,
                    false,
                    false,
                    false,
                    true))
            .build();

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(false, requestId, jwt);
  }

  @Test
  void privateGetAccountDetailsShouldReturnAccountDetailsWhenOtherFilterIsPresent()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    setUpAccountAccessRequiredEntities(PARTY_ID_OTHER, accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    setUpProductMigrationInProgress(accountNumber);
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfo.json"));

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(false, false, null, null, false, true, true, false),
                    createWithdrawals(false, null, false, true, true, false),
                    null,
                    false,
                    false,
                    false,
                    false,
                    true))
            .build();

    signingWebClientPrivate
        .get()
        .uri(
            getURI(
                BASE_PATH_PRIVATE,
                ACCOUNT_DETAIL_PATH,
                ACCOUNT_DETAIL_WITH_OTHER_ACCOUNT_FILTERS,
                port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(false, requestId, jwt);
  }

  @ParameterizedTest
  @ValueSource(ints = {WITHDRAWAL_LIMIT, WITHDRAWAL_LIMIT_NOT_REACHED})
  void getAccountDetailsShouldReturnAccountDetailsWhenValidSessionIdPresent(
      final int withdrawalsMade) throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsWhenValidSessionIdPresent(
        BASE_PATH_PUBLIC, signingWebClientPublic, withdrawalsMade, true, "");
  }

  @ParameterizedTest
  @ValueSource(ints = {WITHDRAWAL_LIMIT, WITHDRAWAL_LIMIT_NOT_REACHED})
  void privateGetAccountDetailsShouldReturnAccountDetailsWhenValidSessionIdPresent(
      final int withdrawalsMade) throws IOException, InterruptedException {
    getAccountDetailsShouldReturnAccountDetailsWhenValidSessionIdPresent(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        withdrawalsMade,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  private void getAccountDetailsShouldReturnAccountDetailsWhenValidSessionIdPresent(
      final String basePath,
      final WebTestClient webTestClient,
      final int withdrawalsMade,
      final boolean expectAudit,
      final String queryParams)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithSessionId(UUID.randomUUID().toString());
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final AccountAccessRequiredEntities accessEntities =
        setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    setUpAnnualWithdrawalLimits(
        1L, withdrawalsMade, accessEntities.getAccountNumber(), accessEntities.getSavingProduct());
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoWithdrawalLimit.json"));

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(true, MAX_PRODUCT_BAL_REMAINING),
                    createWithdrawalsWithLimit(withdrawalsMade),
                    null,
                    false,
                    false,
                    false,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @ParameterizedTest
  @MethodSource("savingsTransactionLogEntries")
  void
      getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenAccountNotInValidStateForReinvestment(
          final String label, final SavingsTransactionLogEntry savingsTransactionLogEntry)
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenAccountNotInValidStateForReinvestment(
        BASE_PATH_PUBLIC,
        signingWebClientPublic,
        true,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS,
        savingsTransactionLogEntry);
  }

  @ParameterizedTest
  @MethodSource("savingsTransactionLogEntries")
  void
      privateGetAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenAccountNotInValidStateForReinvestment(
          final String label, final SavingsTransactionLogEntry savingsTransactionLogEntry)
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenAccountNotInValidStateForReinvestment(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS,
        savingsTransactionLogEntry);
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals"})
  private void
      getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenAccountNotInValidStateForReinvestment(
          final String basePath,
          final WebTestClient webTestClient,
          final boolean expectAudit,
          final String queryParams,
          final SavingsTransactionLogEntry savingsTransactionLogEntry)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final LocalDateTime today = LocalDateTime.now(clock);

    setupCopyDbMetadata(COPY_DB_UPDATE_TIME);
    setUpSavingsTransactionLog(savingsTransactionLogEntry);
    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(accountNumber))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    stubMockProductServiceResponse(
        new ClassPathResource("/it/productInfoTaxYearDepositLimit.json"));
    stubMockProductServiceResponse(new ClassPathResource("/it/reinvestmentProducts.json"));
    setupOpenSavingAccount(accountNumber);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    setupTessaDetails(accountNumber);

    setupSavingTransaction(
        SAVING_TRANSACTION_SYSID_SYNCED_WITH_AUTHENTIC, accountNumber, today, new BigDecimal(2));

    stubAuthenticGetTransactionsCall("/it/AuthenticTransactionsResponse#1.xml");

    final boolean closurePermitted =
        !STATUS_CLOSE_COMMENCE.equals(savingsTransactionLogEntry.getStatus());

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    getProduct(PRODUCT_ID_CODE, "Internet Saver", "ISA", false),
                    createDeposits(true, DEPOSIT_AMOUNT, MAX_PRODUCT_BAL_REMAINING, false),
                    createWithdrawals(true, false),
                    createIsa(false),
                    false,
                    false,
                    false,
                    false,
                    closurePermitted))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @Test
  void
      getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenNoEligibleProductsAvailable()
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenNoEligibleProductsAvailable(
        BASE_PATH_PUBLIC,
        signingWebClientPublic,
        true,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @Test
  void
      privateGetAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenNoEligibleProductsAvailable()
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenNoEligibleProductsAvailable(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals"})
  private void
      getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiFalseWhenNoEligibleProductsAvailable(
          final String basePath,
          final WebTestClient webTestClient,
          final boolean expectAudit,
          final String queryParams)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final LocalDateTime today = LocalDateTime.now(clock);

    setupCopyDbMetadata(COPY_DB_UPDATE_TIME);
    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(accountNumber))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    stubMockProductServiceResponse(
        new ClassPathResource("/it/productInfoTaxYearDepositLimit.json"));
    stubMockProductServiceResponse(new ClassPathResource("/it/noReinvestmentProducts.json"));
    setupOpenSavingAccount(accountNumber);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    setupTessaDetails(accountNumber);

    setupSavingTransaction(
        SAVING_TRANSACTION_SYSID_SYNCED_WITH_AUTHENTIC, accountNumber, today, new BigDecimal(2));

    stubAuthenticGetTransactionsCall("/it/AuthenticTransactionsResponse#1.xml");

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    getProduct(PRODUCT_ID_CODE, "Internet Saver", "ISA", false),
                    createDeposits(true, DEPOSIT_AMOUNT, MAX_PRODUCT_BAL_REMAINING, false),
                    createWithdrawals(true, false),
                    createIsa(false),
                    false,
                    false,
                    false,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @Test
  void
      getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiTrueWhenReinvestmentAllowed()
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiTrueWhenReinvestmentAllowed(
        BASE_PATH_PUBLIC,
        signingWebClientPublic,
        true,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @Test
  void
      privateGetAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiTrueWhenReinvestmentAllowed()
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiTrueWhenReinvestmentAllowed(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals"})
  private void
      getAccountDetailsShouldReturnResponseWithReinvestmentPermittedOverApiTrueWhenReinvestmentAllowed(
          final String basePath,
          final WebTestClient webTestClient,
          final boolean expectAudit,
          final String queryParams)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final LocalDateTime today = LocalDateTime.now(clock);

    setupCopyDbMetadata(COPY_DB_UPDATE_TIME);
    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(accountNumber))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoFBOND.json"));
    stubMockProductServiceResponse(new ClassPathResource("/it/reinvestmentProducts.json"));
    setupOpenSavingAccount(accountNumber);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    setupTessaDetails(accountNumber);

    setupSavingTransaction(
        SAVING_TRANSACTION_SYSID_SYNCED_WITH_AUTHENTIC, accountNumber, today, new BigDecimal(2));

    stubAuthenticGetTransactionsCall("/it/AuthenticTransactionsResponse#1.xml");

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    getProduct(
                        PRODUCT_ID_CODE_BOND, "Fixed Rate eBond to 31/11/2022", "FBOND", false),
                    createDeposits(true, null, MAX_PRODUCT_BAL_REMAINING, false),
                    createWithdrawals(true, false),
                    null,
                    false,
                    false,
                    true,
                    true,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @Test
  void
      getAccountDetailsShouldReturnResponseWithDepositsPermittedByCardTrueWhenDepositsByCardAllowed()
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithDepositsPermittedByCardTrueWhenDepositsByCardAllowed(
        BASE_PATH_PUBLIC,
        signingWebClientPublic,
        true,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @Test
  void
      getAccountDetailsShouldReturnResponseWithAccountClosureFalseWhenWitCodeRefersToSignatureCard()
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithAccountClosureFalseWhenWitCodeRefersToSignatureCard(
        BASE_PATH_PUBLIC,
        signingWebClientPublic,
        true,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @Test
  void
      privateGetAccountDetailsShouldReturnResponseWithDepositsPermittedByCardTrueWhenDepositsByCardAllowed()
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithDepositsPermittedByCardTrueWhenDepositsByCardAllowed(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @Test
  void
      privateGetAccountDetailsShouldReturnResponseWithAccountClosureFalseWhenWitCodeRefersToSignatureCard()
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithAccountClosureFalseWhenWitCodeRefersToSignatureCard(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals"})
  private void
      getAccountDetailsShouldReturnResponseWithDepositsPermittedByCardTrueWhenDepositsByCardAllowed(
          final String basePath,
          final WebTestClient webTestClient,
          final boolean expectAudit,
          final String queryParams)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final AccountAccessRequiredEntities accountAccessRequiredEntities =
        setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml"); // NOPMD

    final RestrictionType restrictionType = setUpRestrictionType(RTYPE, 1001L, 2001L, WEBWDL);
    setupAccountWarning(1L, accountAccessRequiredEntities.getAccountNumber(), restrictionType);
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);
    setupPartyAddress(
        2L, Long.valueOf(PARTY_ID), Country.builder().code("UK").isoCode("GB").build());
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfo.json")); // NOPMD

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(
                        true, true, null, MAX_PRODUCT_BAL_REMAINING, false, true, false, false),
                    createWithdrawals(false, null, true, true, false, false),
                    null,
                    true,
                    false,
                    false,
                    false,
                    false))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  @ParameterizedTest
  @MethodSource("depositsByCardNotAllowedParams")
  void
      getAccountDetailsShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
          final Country country,
          final String productServiceResponse,
          final boolean warningsBlockDeposits,
          final String witCode)
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
        BASE_PATH_PUBLIC,
        signingWebClientPublic,
        true,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS,
        country,
        productServiceResponse,
        warningsBlockDeposits,
        witCode);
  }

  @ParameterizedTest
  @MethodSource("depositsByCardNotAllowedParams")
  void
      privateGetAccountDetailsShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
          final Country country,
          final String productServiceResponse,
          final boolean warningsBlockDeposits,
          final String witCode)
          throws IOException, InterruptedException {
    getAccountDetailsShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS,
        country,
        productServiceResponse,
        warningsBlockDeposits,
        witCode);
  }

  @SuppressWarnings({"PMD.ExcessiveParameterList", "PMD.AvoidDuplicateLiterals"})
  private void
      getAccountDetailsShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
          final String basePath,
          final WebTestClient webTestClient,
          final boolean expectAudit,
          final String queryParams,
          final Country country,
          final String productServiceResponse,
          final boolean warningsBlockDeposits,
          final String witCode)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    setupCopyDbMetadata(COPY_DB_UPDATE_TIME);
    final AccountAccessRequiredEntities accountAccessRequiredEntities =
        setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml"); // NOPMD

    if (warningsBlockDeposits) {
      final RestrictionType restrictionType = setUpRestrictionType(RTYPE, 1001L, 1001L, WEBREC);
      setupAccountWarning(1L, accountAccessRequiredEntities.getAccountNumber(), restrictionType);
    }

    setupOpenSavingAccountWithWitCode(ACCOUNT_NUMBER_LONG, witCode);

    setupPartyAddress(2L, Long.valueOf(PARTY_ID), country);
    stubMockProductServiceResponse(new ClassPathResource(productServiceResponse)); // NOPMD

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    intSavProduct(),
                    createDeposits(
                        !warningsBlockDeposits,
                        false,
                        null,
                        MAX_PRODUCT_BAL_REMAINING,
                        warningsBlockDeposits,
                        true,
                        false,
                        false),
                    createWithdrawals(true, null, false, true, false, false),
                    null,
                    warningsBlockDeposits,
                    false,
                    false,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  private static Stream<Arguments> depositsByCardNotAllowedParams() {
    return Stream.of(
        Arguments.of(
            NON_UK_COUNTRY,
            "/it/productInfo.json",
            false,
            SINGLE_SIGNATURE_WIT_CODE), // Not allowed as non-uk country
        Arguments.of(
            UK_COUNTRY,
            "/it/productInfoDoesNotAllowDepositByCard.json",
            false,
            SINGLE_SIGNATURE_WIT_CODE), // Not allowed by product
        Arguments.of(
            UK_COUNTRY,
            "/it/productInfo.json",
            true,
            SINGLE_SIGNATURE_WIT_CODE), // Not allowed as warnings block deposits
        Arguments.of(
            UK_COUNTRY,
            "/it/productInfo.json",
            false,
            "A_CODE") // Not allowed as wit code does not allow deposits for non ISA
        );
  }

  @ParameterizedTest
  @MethodSource("depositsByCardForIsaNotAllowedParams")
  void
      getAccountDetailsForIsaShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
          final Country country,
          final String productServiceResponse,
          final boolean isSubscribedToOtherIsa,
          final String witCode,
          final boolean accountHasOtherActivityPlayers)
          throws IOException, InterruptedException {
    getAccountDetailsForIsaShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
        BASE_PATH_PUBLIC,
        signingWebClientPublic,
        true,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS,
        country,
        productServiceResponse,
        isSubscribedToOtherIsa,
        witCode,
        accountHasOtherActivityPlayers);
  }

  @ParameterizedTest
  @MethodSource("depositsByCardForIsaNotAllowedParams")
  void
      privateGetAccountDetailsForIsaShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
          final Country country,
          final String productServiceResponse,
          final boolean isSubscribedToOtherIsa,
          final String witCode,
          final boolean accountHasOtherActivityPlayers)
          throws IOException, InterruptedException {
    getAccountDetailsForIsaShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS,
        country,
        productServiceResponse,
        isSubscribedToOtherIsa,
        witCode,
        accountHasOtherActivityPlayers);
  }

  @SuppressWarnings({"PMD.ExcessiveParameterList", "PMD.AvoidDuplicateLiterals"})
  private void
      getAccountDetailsForIsaShouldReturnResponseWithDepositsPermittedByCardFalseWhenDepositsByCardNotAllowed(
          final String basePath,
          final WebTestClient webTestClient,
          final boolean expectAudit,
          final String queryParams,
          final Country country,
          final String productServiceResponse,
          final boolean isSubscribedToOtherIsa,
          final String witCode,
          final boolean accountHasOtherActivityPlayers)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    setupCopyDbMetadata(COPY_DB_UPDATE_TIME);
    final AccountAccessRequiredEntities accountAccessRequiredEntities =
        setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);
    if (accountHasOtherActivityPlayers) {
      setUpAccountAccessRequiredEntitiesForOtherActivityPlayer(
          accountNumber, ACTIVITY_GROUP_CODE_PISP);
    }

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml"); // NOPMD

    setupOpenSavingAccountWithWitCode(ACCOUNT_NUMBER_LONG, witCode);
    if (isSubscribedToOtherIsa) {
      setUpAccountAccessRequiredEntitiesForSubscriptionToOtherIsa(
          PARTY_ID, ACCOUNT_NUMBER_2_LONG, ACTIVITY_GROUP_CODE_PISP);
      setupOpenSavingAccount(ACCOUNT_NUMBER_2_LONG);
    }
    setupPartyAddress(2L, Long.valueOf(PARTY_ID), country);
    stubMockProductServiceResponse(new ClassPathResource(productServiceResponse)); // NOPMD
    stubMockProductServiceResponse(new ClassPathResource("/it/noReinvestmentProducts.json"));

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    eggIsaProduct(),
                    createDeposits(
                        true, false, null, MAX_PRODUCT_BAL_REMAINING, false, true, false, false),
                    createWithdrawals(true, null, false, true, false, false),
                    Isa.builder().flexible(false).helpToBuy(false).subscribed(false).build(),
                    false,
                    false,
                    false,
                    false,
                    "CONV".equals(witCode) || accountHasOtherActivityPlayers ? false : true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  private static Stream<Arguments> depositsByCardForIsaNotAllowedParams() {
    return Stream.of(
        Arguments.of(
            UK_COUNTRY,
            "/it/isaProductInfo.json",
            true,
            SINGLE_SIGNATURE_WIT_CODE,
            false), // Not allowed as ISA and subscribed to other ISA
        Arguments.of(
            UK_COUNTRY,
            "/it/isaProductInfo.json",
            false,
            "CONV",
            false), // Not allowed as ISA and wit code refers to signature card
        Arguments.of(
            UK_COUNTRY,
            "/it/isaProductInfo.json",
            false,
            "A_CODE",
            true) // Not allowed as is ISA and has other activity players and not a single signature
        // wit code
        );
  }

  @SuppressWarnings({"PMD.AvoidDuplicateLiterals"})
  private void
      getAccountDetailsShouldReturnResponseWithAccountClosureFalseWhenWitCodeRefersToSignatureCard(
          final String basePath,
          final WebTestClient webTestClient,
          final boolean expectAudit,
          final String queryParams)
          throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    final LocalDateTime today = LocalDateTime.now(clock);

    setupCopyDbMetadata(COPY_DB_UPDATE_TIME);
    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(accountNumber))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
    stubMockProductServiceResponse(new ClassPathResource("/it/productInfoFBOND.json"));
    stubMockProductServiceResponse(new ClassPathResource("/it/reinvestmentProducts.json"));
    setupSavingAccountRefersToSignatureCard(accountNumber);

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    setupTessaDetails(accountNumber);

    setupSavingTransaction(
        SAVING_TRANSACTION_SYSID_SYNCED_WITH_AUTHENTIC, accountNumber, today, new BigDecimal(2));

    stubAuthenticGetTransactionsCall("/it/AuthenticTransactionsResponse#1.xml");

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    getProduct(
                        PRODUCT_ID_CODE_BOND, "Fixed Rate eBond to 31/11/2022", "FBOND", false),
                    createDeposits(true, null, MAX_PRODUCT_BAL_REMAINING, false),
                    createWithdrawals(true, false),
                    null,
                    false,
                    false,
                    true,
                    false,
                    false))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  private static Stream<Arguments> savingsTransactionLogEntries() {
    return Stream.of(
        Arguments.of(
            "has pending transactions",
            buildSavingsTransactionLog(
                Long.parseLong(ACCOUNT_NUMBER),
                null,
                COPY_DB_UPDATE_TIME.minusSeconds(1),
                COPY_DB_UPDATE_TIME,
                STATUS_DEPOSIT_COMMENCE,
                BigDecimal.valueOf(10),
                Long.parseLong(PARTY_ID))),
        Arguments.of(
            "has regular transfers in progress",
            buildSavingsTransactionLog(
                Long.parseLong(ACCOUNT_NUMBER),
                null,
                COPY_DB_UPDATE_TIME,
                COPY_DB_UPDATE_TIME.plusSeconds(1),
                STATUS_ADD_REGULAR_INTERNAL_TRANSFER,
                BigDecimal.valueOf(10),
                Long.parseLong(PARTY_ID))),
        Arguments.of(
            "is in closure process",
            buildSavingsTransactionLog(
                Long.parseLong(ACCOUNT_NUMBER),
                null,
                COPY_DB_UPDATE_TIME,
                COPY_DB_UPDATE_TIME.plusSeconds(1),
                STATUS_CLOSE_COMMENCE,
                BigDecimal.valueOf(10),
                Long.parseLong(PARTY_ID))));
  }

  @Test
  void getAccountDetailsShouldReturnForbiddenWhenAccountBrandDoesNotMatchJwtBrand() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createJwt(PARTY_ID, ACCOUNT_READ_SCOPE, BRAND_CODE_CHELSEA);

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(
            TestHelper.accessDeniedErrorResponse(requestId, ErrorResponse.ErrorItem.ACCESS_DENIED));
  }

  @Test
  void getAccountDetailsShouldReturnForbiddenWhenAccountPartyIdDoesntMatchJwtPartyId() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createJwt(PARTY_ID_OTHER, ACCOUNT_READ_SCOPE, BRAND_CODE_YBS);

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(
            TestHelper.accessDeniedErrorResponse(
                requestId, ErrorResponse.ErrorItem.NO_CUSTOMER_RELATIONSHIP));
  }

  @ParameterizedTest
  @ValueSource(strings = {"", ACCOUNT_DETAIL_WITH_OTHER_ACCOUNT_FILTERS})
  void privateGetAccountDetailsShouldReturnNotFoundWhenAccountDoesNotExist(
      final String queryParameters) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    signingWebClientPrivate
        .get()
        .uri(getURI(BASE_PATH_PRIVATE, ACCOUNT_DETAIL_PATH, queryParameters, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));
  }

  @Test
  void getAccountDetailsShouldReturnNotFoundWhenAccountDoesNotExistInDatabase() throws IOException {
    getAccountDetailsShouldReturnNotFoundWhenAccountDoesNotExistInDatabase(
        BASE_PATH_PUBLIC, signingWebClientPublic, true);
  }

  @Test
  void privateGetAccountDetailsShouldReturnNotFoundWhenAccountDoesNotExistInDatabase()
      throws IOException {
    getAccountDetailsShouldReturnNotFoundWhenAccountDoesNotExistInDatabase(
        BASE_PATH_PRIVATE, signingWebClientPrivate, false);
  }

  private void getAccountDetailsShouldReturnNotFoundWhenAccountDoesNotExistInDatabase(
      final String basePath, final WebTestClient webTestClient, final boolean expectAudit)
      throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();
    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);
    final LocalDateTime today = LocalDateTime.now(clock);

    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");

    setUpAccountsWithPendingIsaDeclaration(accountNumber, today, today);
    stubMockProductServiceResponse(new ClassPathResource("/it/isaProductInfo.json"));

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        "/api/authentic/getbalance/AccNotFoundResponse.xml",
        "/api/authentic/getbalance/AccClosedResponse.xml"
      })
  void getAccountDetailsShouldReturnInternalServerErrorWhenAuthenticGetBalanceAccountDoesNotExist(
      final String authenticResponse) throws IOException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));
    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    stubAuthenticGetBalanceCall(authenticResponse);

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.internalServerError(requestId));
  }

  @Test
  void shouldReturnInternalServerErrorWhenProductServiceDoesntReturn200()
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    setUpAccountAccessRequiredEntities(Long.parseLong(ACCOUNT_NUMBER));

    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#1.xml");

    mockProductServiceInternalServerError();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .is5xxServerError()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.internalServerError(requestId));

    assertProductServiceCall(requestId, jwt, "/product/private/product/INTSAV");
  }

  /*
   * Standard endpoint validation tests
   */
  @Test
  void getAccountDetailsShouldReturnNotFoundWhenAccountDoesNotExist() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createValidYbsJwt();

    signingWebClientPublic
        .get()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(TestHelper.notFound(requestId));
  }

  @Test
  void patchAccountDetailsShouldReturnConflictWhenAccountIsClosed() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(ACCOUNT_NAME).build();

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    accountDetails.setClosedDate(ACCOUNT_CLOSED_DATE);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    signingWebClientPublic
        .patch()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(updateAccountDetails)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.FORBIDDEN);

    assertNoWorkLogs();
    assertNoSavingsTransactionsLogs();
  }

  @Test
  void patchAccountDetailsWhenInvalidScope() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(OTHER_SCOPE);
    final ErrorResponse expectedResponse =
        TestHelper.accessDeniedErrorResponse(requestId, ErrorResponse.ErrorItem.ACCESS_DENIED);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(ACCOUNT_NAME).build();

    signingWebClientPublic
        .patch()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(updateAccountDetails)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentTypeCompatibleWith(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(expectedResponse);
  }

  @Test
  void patchAccountDetailsShouldReturnConflictWhenAccountNameNotChanged() {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(ACCOUNT_NAME).build();

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    accountDetails.setAccountName(ACCOUNT_NAME);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    signingWebClientPublic
        .patch()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(updateAccountDetails)
        .exchange()
        .expectStatus()
        .isEqualTo(HttpStatus.CONFLICT);

    assertNoWorkLogs();
    assertNoSavingsTransactionsLogs();
  }

  @ParameterizedTest
  @CsvSource(
      value = {"'', null", "NewAccountName, NewAccountName"},
      nullValues = {"null"})
  void patchAccountDetailsWhenRequestIsValid(
      final String accountName, final String savedAccountName) {
    final UUID requestId = UUID.randomUUID();
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);
    final LocalDateTime today = LocalDateTime.now(clock);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(accountName).build();

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    signingWebClientPublic
        .patch()
        .uri(getURI(BASE_PATH_PUBLIC, ACCOUNT_DETAIL_PATH, port))
        .headers(standardHeaders(requestId, jwt))
        .bodyValue(updateAccountDetails)
        .exchange()
        .expectStatus()
        .isAccepted()
        .expectBody(UpdateAccountDetails.class)
        .isEqualTo(updateAccountDetails);

    assertWorkLogsWithCount(
        1,
        workLogMatching(
            buildWorkLog(requestId, jwt, Operation.UPDATE_ACCOUNT_DET, Status.PENDING)));

    assertSavingsTransactionLogsWithCount(
        1,
        savingsTransactionLogMatching(
            buildSavingsTransactionLog(
                Long.valueOf(ACCOUNT_NUMBER),
                savedAccountName,
                today,
                today,
                SavingsTransactionLogEntry.STATUS_ACCOUNT_NAME_CHANGE_COMPLETE,
                BigDecimal.ZERO,
                12462951L)));
  }

  @Test
  void publicGetAccountDetailsShouldReturnAccountDetailsForSmartTieredAccount()
      throws IOException, InterruptedException {
    final String jwt = createYbsJwtWithScope(ACCOUNT_READ_SCOPE);
    getAccountDetailsShouldReturnAccountDetailsForSmartTieredAccount(
        BASE_PATH_PUBLIC, signingWebClientPublic, jwt, true, "");
  }

  @Test
  void privateGetAccountDetailsShouldReturnAccountDetailsForSmartTieredAccount()
      throws IOException, InterruptedException {
    final String jwt = createValidYbsJwt();
    getAccountDetailsShouldReturnAccountDetailsForSmartTieredAccount(
        BASE_PATH_PRIVATE,
        signingWebClientPrivate,
        jwt,
        false,
        ACCOUNT_DETAIL_WITH_AVAILABLE_DEPOSIT_LIMIT_FILTERS);
  }

  private void getAccountDetailsShouldReturnAccountDetailsForSmartTieredAccount(
      final String basePath,
      final WebTestClient webTestClient,
      final String jwt,
      final boolean expectAudit,
      final String queryParams)
      throws IOException, InterruptedException {
    final UUID requestId = UUID.randomUUID();

    final Long accountNumber = Long.valueOf(ACCOUNT_NUMBER);

    // IMPORTANT NOTE, do not remove as this call inserts something in the test database,
    // if removed the test fails with an FK exception.

    setUpAccountAccessRequiredEntities(accountNumber, ACTIVITY_GROUP_CODE_PISP);

    final SavingAccountDetails accountDetails = createSavingAccountDetails(null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    expectedAccountDetailsSoaCalls();
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");

    setupOpenSavingAccount(ACCOUNT_NUMBER_LONG);
    // note the json requests structures must match the decimal place, a leading zero is important
    stubMockProductServiceResponse(new ClassPathResource("/it/tieredProductInfo.json"));

    if (expectAudit) {
      stubMockAuditServiceResponse();
    }

    final AccountDetailsResponse expectedResponse =
        AccountDetailsResponse.builder()
            .account(
                createAccountDetailsResponse(
                    null,
                    tieredProduct(),
                    createDeposits(true, MAX_PRODUCT_BAL_REMAINING),
                    createWithdrawals(true, false),
                    null,
                    false,
                    true,
                    false,
                    false,
                    true))
            .build();

    webTestClient
        .get()
        .uri(getURI(basePath, ACCOUNT_DETAIL_PATH, queryParams, port))
        .headers(standardHeaders(requestId, jwt))
        .exchange()
        .expectStatus()
        .isOk()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(AccountDetailsResponse.class)
        .isEqualTo(expectedResponse);

    assertAccountDetails(expectAudit, requestId, jwt);
  }

  private void expectedAccountDetailsSoaCalls() throws IOException {
    stubAuthenticGetBalanceCall("/it/AuthenticSuccessResponse#3.xml");
  }
}
