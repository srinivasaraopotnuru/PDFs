package uk.co.ybs.digital.account.service.audit.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
public class AuditAccountDetailsUpdateSuccessRequestJsonTest {
  @Autowired private JacksonTester<AuditAccountDetailsUpdateSuccessRequest> tester;

  @Value("classpath:api/auditService/request/auditAccountDetailsUpdate/successRequest.json")
  private Resource requestFile;

  private AuditAccountDetailsUpdateSuccessRequest request;

  @BeforeEach
  void setUp() {
    request =
        AuditAccountDetailsUpdateSuccessRequest.builder()
            .ipAddress("12.66.53.145")
            .accountName("new name")
            .accountInformation(
                AuditAccountDetailsUpdateSuccessRequest.AccountInformation.builder()
                    .accountNumber("2372146519")
                    .build())
            .build();
  }

  @Test
  void serializes() throws IOException {
    assertThat(tester.write(request)).isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    assertThat(tester.read(requestFile)).isEqualTo(request);
  }
}
