package uk.co.ybs.digital.account.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.sameInstance;
import static org.mockito.ArgumentMatchers.same;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.AccountDetailsFilter;
import uk.co.ybs.digital.account.web.dto.AccountDetailsResponse;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class AuditingAccountServiceTest {
  private static final String ACCOUNT_NUMBER = "1234567891";
  private static final List<AccountDetailsFilter> FILTERS =
      Collections.singletonList(AccountDetailsFilter.AVAILABLE_DEPOSIT_LIMIT);

  @InjectMocks private AuditingAccountService testSubject;

  @Mock private AccountService accountService;

  @Mock private AccountAuditor accountAuditor;

  @Test
  void shouldGetAccountDetails() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final AccountDetailsResponse expectedResponse = AccountDetailsResponse.builder().build();
    when(accountService.getAccountDetails(ACCOUNT_NUMBER, FILTERS, requestMetadata))
        .thenReturn(expectedResponse);

    final AccountDetailsResponse response =
        testSubject.getAccountDetails(ACCOUNT_NUMBER, FILTERS, requestMetadata);
    assertThat(response, sameInstance(expectedResponse));

    verify(accountAuditor).auditAccountDetails(same(ACCOUNT_NUMBER), same(requestMetadata));
    verifyNoMoreInteractions(accountAuditor);
  }

  @Test
  void getAccountsByGroup() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final GroupedAccountListResponse expectedResponse =
        GroupedAccountListResponse.builder().build();
    when(accountService.getAccountGroups(requestMetadata, false)).thenReturn(expectedResponse);

    final GroupedAccountListResponse response =
        testSubject.getAccountsByGroup(requestMetadata, false);
    assertThat(response, sameInstance(expectedResponse));

    verify(accountAuditor).auditAccountList(same(requestMetadata));
    verifyNoMoreInteractions(accountAuditor);
  }

  private RequestMetadata buildRequestMetadata() {
    return TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 80);
  }
}
