package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.stream.Stream;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.TessaDetailsUtilities;
import uk.co.ybs.digital.account.web.dto.Isa;

@ExtendWith(MockitoExtension.class)
class IsaMapperTest {
  @InjectMocks private IsaMapper mapper;
  @Mock private TessaDetailsUtilities tessaDetailsUtilities;

  private static final String ACCOUNT_NUMBER = "12345678";

  @ParameterizedTest
  @MethodSource("expectedIsaAndProductInfo")
  void shouldMapIsa(final Isa isaExpected, final ProductInfo productInfo, final boolean found) {

    when(tessaDetailsUtilities.getTessaDetails(anyString(), anyInt())).thenReturn(found);

    final Isa mapped = mapper.mapIsa(productInfo, ACCOUNT_NUMBER);
    assertThat(mapped, is(isaExpected));
  }

  private static Stream<Arguments> expectedIsaAndProductInfo() {
    return Stream.of(
        Arguments.of(
            Isa.builder().flexible(false).helpToBuy(true).subscribed(false).build(),
            ProductInfo.builder()
                .isa(ProductInfo.Isa.builder().flexible(false).helpToBuy(true).isaYear(7).build())
                .build(),
            false),
        Arguments.of(
            Isa.builder().flexible(true).subscribed(false).build(),
            ProductInfo.builder()
                .isa(ProductInfo.Isa.builder().flexible(true).isaYear(7).build())
                .build(),
            false),
        Arguments.of(
            Isa.builder().flexible(false).helpToBuy(true).subscribed(true).build(),
            ProductInfo.builder()
                .isa(ProductInfo.Isa.builder().flexible(false).helpToBuy(true).isaYear(7).build())
                .build(),
            true),
        Arguments.of(
            Isa.builder().flexible(true).subscribed(true).build(),
            ProductInfo.builder()
                .isa(ProductInfo.Isa.builder().flexible(true).isaYear(7).build())
                .build(),
            true));
  }
}
