package uk.co.ybs.digital.account.repository.frontoffice;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMMENCE;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.STATUS_CLOSE_COMPLETE;
import static uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry.TRANSFER_INDICATOR_INTERNAL;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
class SavingsTransactionLogRepositoryTest {

  private static final Long ACCOUNT_NUMBER_1 = 2001L;
  private static final Long ACCOUNT_NUMBER_2 = 2002L;
  private static final Long ACCOUNT_NUMBER_3 = 2003L;

  private static final String STATUS_PRODUCT_TRANSFER_START = "PRODUCT_TRANSFER_START";
  private static final String STATUS_PRODUCT_TRANSFER_END = "PRODUCT_TRANSFER_END";
  private static final String STATUS_ISA_DECLARATION = "ISA_DECLARATION";

  private static final Long PARTY_ID = 1001L;

  private static final BigDecimal AMOUNT = new BigDecimal("100.00");

  private static final LocalDateTime START_TIME = LocalDateTime.parse("2020-04-06T12:34:56");
  private static final LocalDateTime END_TIME = START_TIME.plusSeconds(1);
  private static final LocalDateTime PROCESSED_TIME = START_TIME.plusSeconds(1);

  private static final LocalDateTime EARLIEST_DATE = LocalDateTime.parse("2020-04-06T12:34:56");
  private static final LocalDateTime BEFORE_EARLIEST_DATE = EARLIEST_DATE.minusSeconds(1);
  private static final LocalDateTime AFTER_EARLIEST_DATE = EARLIEST_DATE.plusSeconds(1);

  @Autowired SavingsTransactionLogRepository testSubject;

  @Autowired TestEntityManager frontOfficeTestEntityManager;

  @Test
  void shouldFindById() {
    final SavingsTransactionLogEntry persisted =
        persistLog(
            ACCOUNT_NUMBER_1,
            BEFORE_EARLIEST_DATE,
            AFTER_EARLIEST_DATE,
            PROCESSED_TIME,
            STATUS_PRODUCT_TRANSFER_START,
            TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Optional<SavingsTransactionLogEntry> found = testSubject.findById(persisted.getSysId());

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldCountByAccountNumbersAndStatusesAndEarliestTime() {
    persistLog(
        ACCOUNT_NUMBER_1,
        BEFORE_EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        PROCESSED_TIME,
        STATUS_PRODUCT_TRANSFER_START,
        TRANSFER_INDICATOR_INTERNAL);
    persistLog(
        ACCOUNT_NUMBER_2,
        BEFORE_EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        PROCESSED_TIME,
        STATUS_PRODUCT_TRANSFER_END,
        TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Set<Long> accountNumbers =
        testSubject.findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
            Arrays.asList(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2),
            Arrays.asList(STATUS_PRODUCT_TRANSFER_START, STATUS_PRODUCT_TRANSFER_END),
            EARLIEST_DATE);

    assertThat(accountNumbers, containsInAnyOrder(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2));
  }

  @ParameterizedTest
  @CsvSource({"2001,true", "2002,false"})
  void countByAccountNumbersAndStatusesAndEarliestTimeShouldFindEntriesWithMatchingAccountNumber(
      final Long accountNumber, final boolean expectedFound) {
    persistLog(
        accountNumber,
        BEFORE_EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        PROCESSED_TIME,
        STATUS_PRODUCT_TRANSFER_START,
        TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Set<Long> accountNumbers =
        testSubject.findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
            Collections.singletonList(ACCOUNT_NUMBER_1),
            Arrays.asList(STATUS_PRODUCT_TRANSFER_START, STATUS_PRODUCT_TRANSFER_END),
            EARLIEST_DATE);

    assertThat(accountNumbers.isEmpty(), not(expectedFound));
  }

  @ParameterizedTest
  @CsvSource({"PRODUCT_TRANSFER_START,true", "PRODUCT_TRANSFER_END,false"})
  void countByAccountNumbersAndStatusesAndEarliestTimeShouldFindEntriesWithMatchingStatus(
      final String status, final boolean expectedFound) {
    persistLog(
        ACCOUNT_NUMBER_1,
        BEFORE_EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        PROCESSED_TIME,
        status,
        TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Set<Long> accountNumbers =
        testSubject.findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
            Collections.singletonList(ACCOUNT_NUMBER_1),
            Collections.singletonList(STATUS_PRODUCT_TRANSFER_START),
            EARLIEST_DATE);

    assertThat(accountNumbers.isEmpty(), not(expectedFound));
  }

  @ParameterizedTest
  @CsvSource({
    "ended after earliest date,2020-04-06T12:34:50,2020-04-06T12:34:59,true",
    "ended on earliest date,2020-04-06T12:34:50,2020-04-06T12:34:56,true",
    "ended before earliest date,2020-04-06T12:34:50,2020-04-06T12:34:55,false",
    "started after earliest date,2020-04-06T12:34:59,,true",
    "started on earliest date,2020-04-06T12:34:56,,true",
    "started before earliest date,2020-04-06T12:34:55,,false"
  })
  void
      countByAccountNumbersAndStatusesAndEarliestTimeShouldFindEntriesWithStartOrEndDateGreaterThanOrEqualToEarliestDateMatchingStatus(
          final String label,
          final LocalDateTime startDate,
          final LocalDateTime endDate,
          final boolean expectedFound) {
    persistLog(
        ACCOUNT_NUMBER_1,
        startDate,
        endDate,
        PROCESSED_TIME,
        STATUS_PRODUCT_TRANSFER_START,
        TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Set<Long> accountNumbers =
        testSubject.findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
            Collections.singletonList(ACCOUNT_NUMBER_1),
            Collections.singletonList(STATUS_PRODUCT_TRANSFER_START),
            EARLIEST_DATE);

    assertThat(accountNumbers.isEmpty(), not(expectedFound));
  }

  @Test
  void shouldFindAllAccountsWithEntriesStartingAfterEarliestTimeAndStatusIsaDeclaration() {
    persistLog(
        ACCOUNT_NUMBER_1,
        EARLIEST_DATE,
        null,
        null,
        STATUS_ISA_DECLARATION,
        TRANSFER_INDICATOR_INTERNAL);
    persistLog(
        ACCOUNT_NUMBER_2,
        EARLIEST_DATE,
        null,
        null,
        STATUS_PRODUCT_TRANSFER_END,
        TRANSFER_INDICATOR_INTERNAL);
    persistLog(
        ACCOUNT_NUMBER_3,
        EARLIEST_DATE,
        null,
        null,
        STATUS_ISA_DECLARATION,
        TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Set<Long> accountNumbers =
        testSubject.findAllAccountsWithEntriesStartingAfterEarliestTime(
            Arrays.asList(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2, ACCOUNT_NUMBER_3),
            EARLIEST_DATE,
            STATUS_ISA_DECLARATION);

    assertThat(accountNumbers, containsInAnyOrder(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_3));
  }

  @Test
  void shouldNotFindAccountsWithEntriesStartingBeforeEarliestTimeAndStatusIsaDeclaration() {
    persistLog(
        ACCOUNT_NUMBER_1,
        BEFORE_EARLIEST_DATE,
        null,
        null,
        STATUS_ISA_DECLARATION,
        TRANSFER_INDICATOR_INTERNAL);
    persistLog(
        ACCOUNT_NUMBER_2,
        BEFORE_EARLIEST_DATE,
        null,
        null,
        STATUS_ISA_DECLARATION,
        TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Set<Long> accountNumbers =
        testSubject.findAllAccountsWithEntriesStartingAfterEarliestTime(
            Arrays.asList(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2),
            EARLIEST_DATE,
            STATUS_ISA_DECLARATION);

    assertThat(accountNumbers.isEmpty(), is(true));
  }

  @ParameterizedTest
  @CsvSource({"2001,true", "2002,false"})
  void shouldFindAllAccountsWithEntriesStartingAfterEarliestTimeWithMatchingAccountNumber(
      final Long accountNumber, final boolean expectedFound) {
    persistLog(
        accountNumber,
        EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        PROCESSED_TIME,
        STATUS_ISA_DECLARATION,
        TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Set<Long> accountNumbers =
        testSubject.findAllAccountsWithEntriesStartingAfterEarliestTime(
            Collections.singletonList(ACCOUNT_NUMBER_1), EARLIEST_DATE, STATUS_ISA_DECLARATION);

    assertThat(accountNumbers.isEmpty(), not(expectedFound));
  }

  @ParameterizedTest
  @CsvSource({"PRODUCT_TRANSFER_START,false", "ISA_DECLARATION,true"})
  void shouldFindAllAccountsWithEntriesStartingAfterEarliestTimeWithMatchingStatus(
      final String status, final boolean expectedFound) {
    persistLog(ACCOUNT_NUMBER_1, EARLIEST_DATE, null, null, status, TRANSFER_INDICATOR_INTERNAL);
    frontOfficeTestEntityManager.clear();

    final Set<Long> accountNumbers =
        testSubject.findAllAccountsWithEntriesStartingAfterEarliestTime(
            Collections.singletonList(ACCOUNT_NUMBER_1), EARLIEST_DATE, STATUS_ISA_DECLARATION);

    assertThat(accountNumbers.isEmpty(), not(expectedFound));
  }

  @Test
  void findEntriesEndingAtOrAfterTimeByStatusesShouldReturnExpectedEntries() {

    // Should not be found because endDate is before searched EARLIEST_DATE
    persistLog(
        ACCOUNT_NUMBER_1,
        BEFORE_EARLIEST_DATE.minusSeconds(1),
        BEFORE_EARLIEST_DATE,
        null,
        STATUS_PRODUCT_TRANSFER_START,
        TRANSFER_INDICATOR_INTERNAL);
    // Should not be found because status does not match status searched for
    persistLog(
        ACCOUNT_NUMBER_1,
        BEFORE_EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        null,
        "A_STATUS",
        TRANSFER_INDICATOR_INTERNAL);

    // entries that should be found
    final SavingsTransactionLogEntry entryAtEarliestDateWithMatchingStatusAndIndicator =
        persistLog(
            ACCOUNT_NUMBER_1,
            BEFORE_EARLIEST_DATE,
            EARLIEST_DATE,
            null,
            STATUS_PRODUCT_TRANSFER_START,
            TRANSFER_INDICATOR_INTERNAL);
    final SavingsTransactionLogEntry entryAfterEarliestDateWithMatchingStatusAndIndicator =
        persistLog(
            ACCOUNT_NUMBER_1,
            BEFORE_EARLIEST_DATE,
            AFTER_EARLIEST_DATE,
            null,
            STATUS_PRODUCT_TRANSFER_START,
            TRANSFER_INDICATOR_INTERNAL);

    frontOfficeTestEntityManager.clear();

    final List<SavingsTransactionLogEntry> entries =
        testSubject.findEntriesEndingAtOrAfterTimeByStatuses(
            ACCOUNT_NUMBER_1,
            Arrays.asList(STATUS_PRODUCT_TRANSFER_START, "ANY_STATUS"),
            EARLIEST_DATE);

    assertThat(entries.size(), is(2));
    assertThat(
        entries,
        containsInAnyOrder(
            entryAtEarliestDateWithMatchingStatusAndIndicator,
            entryAfterEarliestDateWithMatchingStatusAndIndicator));
  }

  @Test
  void
      findUnprocessedEntriesStartingAtOrAfterTimeByStatusesAndTransferIndicatorShouldReturnExpectedEntries() {

    // Should not be found because startDate is before searched EARLIEST_DATE
    persistLog(
        ACCOUNT_NUMBER_1,
        BEFORE_EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        null,
        STATUS_PRODUCT_TRANSFER_START,
        TRANSFER_INDICATOR_INTERNAL);
    // Should not be found because transferIndicator is not transferIndicator searched for
    persistLog(
        ACCOUNT_NUMBER_1,
        EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        null,
        STATUS_PRODUCT_TRANSFER_START,
        "E");
    // Should not be found because status does not match status searched for
    persistLog(
        ACCOUNT_NUMBER_1,
        EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        null,
        "A_STATUS",
        TRANSFER_INDICATOR_INTERNAL);
    // Should not be found because dateProcessed is not null
    persistLog(
        ACCOUNT_NUMBER_1,
        EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        PROCESSED_TIME,
        STATUS_PRODUCT_TRANSFER_START,
        TRANSFER_INDICATOR_INTERNAL);

    // entries that should be found
    final SavingsTransactionLogEntry entryAtEarliestDateWithMatchingStatusAndIndicator =
        persistLog(
            ACCOUNT_NUMBER_1,
            EARLIEST_DATE,
            AFTER_EARLIEST_DATE,
            null,
            STATUS_PRODUCT_TRANSFER_START,
            TRANSFER_INDICATOR_INTERNAL);
    final SavingsTransactionLogEntry entryAfterEarliestDateWithMatchingStatusAndIndicator =
        persistLog(
            ACCOUNT_NUMBER_1,
            AFTER_EARLIEST_DATE,
            AFTER_EARLIEST_DATE.plusSeconds(1),
            null,
            STATUS_PRODUCT_TRANSFER_START,
            TRANSFER_INDICATOR_INTERNAL);

    frontOfficeTestEntityManager.clear();

    final List<SavingsTransactionLogEntry> entries =
        testSubject.findUnprocessedEntriesStartingAtOrAfterTimeByStatusesAndTransferIndicator(
            ACCOUNT_NUMBER_1,
            Arrays.asList(STATUS_PRODUCT_TRANSFER_START, "ANY_STATUS"),
            TRANSFER_INDICATOR_INTERNAL,
            EARLIEST_DATE);

    assertThat(entries.size(), is(2));
    assertThat(
        entries,
        containsInAnyOrder(
            entryAtEarliestDateWithMatchingStatusAndIndicator,
            entryAfterEarliestDateWithMatchingStatusAndIndicator));
  }

  @Test
  void findEntriesByStatusShouldReturnEntriesWithAnyMatchingStatus() {

    // Should not be found because status not in searched for statuses
    persistLog(
        ACCOUNT_NUMBER_1,
        BEFORE_EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        PROCESSED_TIME,
        STATUS_PRODUCT_TRANSFER_START,
        TRANSFER_INDICATOR_INTERNAL);

    // entries that should be found
    final SavingsTransactionLogEntry entryWithSearchedStatus1 =
        persistLog(
            ACCOUNT_NUMBER_1,
            EARLIEST_DATE,
            AFTER_EARLIEST_DATE,
            PROCESSED_TIME,
            STATUS_CLOSE_COMMENCE,
            TRANSFER_INDICATOR_INTERNAL);
    final SavingsTransactionLogEntry entryWithSearchedStatus2 =
        persistLog(
            ACCOUNT_NUMBER_1,
            EARLIEST_DATE,
            AFTER_EARLIEST_DATE,
            PROCESSED_TIME,
            STATUS_CLOSE_COMPLETE,
            TRANSFER_INDICATOR_INTERNAL);

    frontOfficeTestEntityManager.clear();

    final List<SavingsTransactionLogEntry> entries =
        testSubject.findEntriesByStatus(
            ACCOUNT_NUMBER_1, Arrays.asList(STATUS_CLOSE_COMMENCE, STATUS_CLOSE_COMPLETE));

    assertThat(entries.size(), is(2));
    assertThat(entries, containsInAnyOrder(entryWithSearchedStatus1, entryWithSearchedStatus2));
  }

  @Test
  void findEntriesByStatusShouldReturnEmptyListIfNoEntriesWithMatchingStatus() {

    persistLog(
        ACCOUNT_NUMBER_1,
        EARLIEST_DATE,
        AFTER_EARLIEST_DATE,
        PROCESSED_TIME,
        STATUS_PRODUCT_TRANSFER_START,
        TRANSFER_INDICATOR_INTERNAL);

    frontOfficeTestEntityManager.clear();

    final List<SavingsTransactionLogEntry> entries =
        testSubject.findEntriesByStatus(
            ACCOUNT_NUMBER_1, Arrays.asList(STATUS_CLOSE_COMMENCE, STATUS_CLOSE_COMPLETE));

    assertThat(entries.size(), is(0));
  }

  @Test
  void shouldSave() {
    final SavingsTransactionLogEntry record =
        persistLog(
            ACCOUNT_NUMBER_1,
            START_TIME,
            END_TIME,
            PROCESSED_TIME,
            STATUS_ISA_DECLARATION,
            TRANSFER_INDICATOR_INTERNAL);

    final SavingsTransactionLogEntry persisted = testSubject.save(record);

    frontOfficeTestEntityManager.flush();
    frontOfficeTestEntityManager.clear();

    final Long sysId = persisted.getSysId();
    assertThat(sysId, notNullValue());

    final Long dailySequenceNumber = persisted.getDailySequenceNumber();
    assertThat(dailySequenceNumber, notNullValue());

    final Optional<SavingsTransactionLogEntry> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(
        found.get(),
        allOf(
            samePropertyValuesAs(record, "sysId", "dailySequenceNumber"),
            hasProperty("sysId", is(sysId)),
            hasProperty("dailySequenceNumber", is(dailySequenceNumber))));
  }

  private SavingsTransactionLogEntry persistLog(
      final Long accountNumber,
      final LocalDateTime startDate,
      final LocalDateTime endDate,
      final LocalDateTime dateProcessed,
      final String status,
      final String transferIndicator) {
    final SavingsTransactionLogEntry log =
        SavingsTransactionLogEntry.builder()
            .accountNumber(accountNumber)
            .targetAccountNumber(0L)
            .amount(AMOUNT)
            .transferIndicator(transferIndicator)
            .closure(SavingsTransactionLogEntry.CLOSURE_NO)
            .partySysId(PARTY_ID)
            .startTime(startDate)
            .endTime(endDate)
            .status(status)
            .dateProcessed(dateProcessed)
            .build();
    return frontOfficeTestEntityManager.persistAndFlush(log);
  }
}
