package uk.co.ybs.digital.account.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.core.SavingAccount;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class DeleteAccountRequestTest {
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final Long ACCOUNT_NUMBER = 1L;
  @Mock private DeleteAccountProcessor deleteAccountProcessor;
  private DeleteAccountRequest testSubject;
  private RequestMetadata requestMetadata;
  private DeleteAccountRequestArguments arguments;
  private SavingAccount account;

  @BeforeEach
  void setUp() {
    requestMetadata = TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);
    arguments =
        DeleteAccountRequestArguments.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .requestMetadata(requestMetadata)
            .processTime(PROCESS_TIME)
            .build();
    account = SavingAccount.builder().accountNumber(ACCOUNT_NUMBER).build();
    testSubject =
        DeleteAccountRequest.builder()
            .arguments(arguments)
            .processor(deleteAccountProcessor)
            .build();
  }

  @Test
  void resolveShouldCallProcessor() {
    when(deleteAccountProcessor.resolve(arguments)).thenReturn(account);

    final ResolvedAccountRequest expected =
        new ResolvedDeleteAccountRequest(arguments, deleteAccountProcessor, account);

    final ResolvedAccountRequest resolved = testSubject.resolve();

    assertThat(resolved, is(expected));
  }
}
