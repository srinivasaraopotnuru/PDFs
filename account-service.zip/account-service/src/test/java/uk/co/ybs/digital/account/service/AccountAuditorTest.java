package uk.co.ybs.digital.account.service;

import static org.mockito.Mockito.verify;

import java.net.InetSocketAddress;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.service.audit.AuditService;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsUpdateFailureRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsUpdateSuccessRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountListRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountTransactionsRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditIsaDeclarationSubmissionFailureRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditIsaDeclarationSubmissionSuccessRequest;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
class AccountAuditorTest {

  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final InetSocketAddress HOST = InetSocketAddress.createUnresolved("localhost", 80);
  private static final String PARTY_ID = "1234567890";
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String BRAND_CODE = "YBS";
  private static final String ACCOUNT_NUMBER = "1234567891";

  private static final String ACCOUNT_NAME = "nickName";
  private static final String AUDIT_MESSAGE = "audit message";

  @InjectMocks private AccountAuditor testSubject;

  @Mock private AuditService auditService;

  @Test
  void shouldAuditAccountList() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    testSubject.auditAccountList(requestMetadata);

    final AuditAccountListRequest expectedAuditRequest =
        AuditAccountListRequest.builder().ipAddress(IP_ADDRESS).build();
    verify(auditService).auditAccountList(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditAccountDetails() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    testSubject.auditAccountDetails(ACCOUNT_NUMBER, requestMetadata);

    final AuditAccountDetailsRequest expectedAuditRequest =
        AuditAccountDetailsRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountInformation(
                AuditAccountDetailsRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();
    verify(auditService).auditAccountDetails(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditAccountTransactions() {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AccountTransactionsResponse accountTransactionsResponse =
        AccountTransactionsResponse.builder()
            .transactions(
                Arrays.asList(
                    AccountTransactionsResponse.Transaction.builder()
                        .bookingDateTime(Instant.parse("2017-12-20T01:45:15Z"))
                        .build(),
                    AccountTransactionsResponse.Transaction.builder()
                        .bookingDateTime(Instant.parse("2017-12-21T13:10:21Z"))
                        .build(),
                    AccountTransactionsResponse.Transaction.builder()
                        .bookingDateTime(Instant.parse("2017-12-20T01:22:35Z"))
                        .build(),
                    AccountTransactionsResponse.Transaction.builder()
                        .bookingDateTime(Instant.parse("2017-12-21T09:40:27Z"))
                        .build()))
            .build();

    testSubject.auditAccountTransactions(
        ACCOUNT_NUMBER, requestMetadata, accountTransactionsResponse);

    final AuditAccountTransactionsRequest expectedAuditRequest =
        AuditAccountTransactionsRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountInformation(
                AuditAccountTransactionsRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .startDate("2017-12-20T01:22:35Z")
                    .endDate("2017-12-21T13:10:21Z")
                    .build())
            .build();
    verify(auditService).auditAccountTransactions(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditAccountTransactionsWithTimeDifference() {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AccountTransactionsResponse accountTransactionsResponse =
        AccountTransactionsResponse.builder()
            .transactions(
                Arrays.asList(
                    AccountTransactionsResponse.Transaction.builder()
                        .bookingDateTime(
                            Instant.from(OffsetDateTime.parse("2019-09-28T01:45:15+01:00")))
                        .build(),
                    AccountTransactionsResponse.Transaction.builder()
                        .bookingDateTime(
                            Instant.from(OffsetDateTime.parse("2019-09-29T13:10:21+01:00")))
                        .build(),
                    AccountTransactionsResponse.Transaction.builder()
                        .bookingDateTime(
                            Instant.from(OffsetDateTime.parse("2019-09-28T01:22:35+01:00")))
                        .build(),
                    AccountTransactionsResponse.Transaction.builder()
                        .bookingDateTime(
                            Instant.from(OffsetDateTime.parse("2019-09-29T09:40:27+01:00")))
                        .build()))
            .build();

    testSubject.auditAccountTransactions(
        ACCOUNT_NUMBER, requestMetadata, accountTransactionsResponse);

    final AuditAccountTransactionsRequest expectedAuditRequest =
        AuditAccountTransactionsRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountInformation(
                AuditAccountTransactionsRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .startDate("2019-09-28T00:22:35Z")
                    .endDate("2019-09-29T12:10:21Z")
                    .build())
            .build();
    verify(auditService).auditAccountTransactions(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditAccountTransactionsWithNoReturnedTransactions() {
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AccountTransactionsResponse accountTransactionsResponse =
        AccountTransactionsResponse.builder().transactions(Collections.emptyList()).build();

    testSubject.auditAccountTransactions(
        ACCOUNT_NUMBER, requestMetadata, accountTransactionsResponse);

    final AuditAccountTransactionsRequest expectedAuditRequest =
        AuditAccountTransactionsRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountInformation(
                AuditAccountTransactionsRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();
    verify(auditService).auditAccountTransactions(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditIsaDeclarationSubmissionSuccess() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    testSubject.auditIsaSubmissionDeclarationSuccess(ACCOUNT_NUMBER, requestMetadata);

    final AuditIsaDeclarationSubmissionSuccessRequest expectedAuditRequest =
        AuditIsaDeclarationSubmissionSuccessRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountInformation(
                AuditIsaDeclarationSubmissionSuccessRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();
    verify(auditService)
        .auditIsaDeclarationSubmissionSuccess(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditIsaDeclarationSubmissionFailure() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    testSubject.auditIsaSubmissionDeclarationFailure(
        ACCOUNT_NUMBER, requestMetadata, AUDIT_MESSAGE);

    final AuditIsaDeclarationSubmissionFailureRequest expectedAuditRequest =
        AuditIsaDeclarationSubmissionFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .message(AUDIT_MESSAGE)
            .accountInformation(
                AuditIsaDeclarationSubmissionFailureRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();
    verify(auditService)
        .auditIsaDeclarationSubmissionFailure(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditUpdateAccountDetailsSuccess() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    testSubject.auditAccountDetailsUpdateSuccess(ACCOUNT_NAME, ACCOUNT_NUMBER, requestMetadata);

    final AuditAccountDetailsUpdateSuccessRequest expectedAuditRequest =
        AuditAccountDetailsUpdateSuccessRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountName(ACCOUNT_NAME)
            .accountInformation(
                AuditAccountDetailsUpdateSuccessRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();
    verify(auditService).auditAccountDetailsUpdateSuccess(expectedAuditRequest, requestMetadata);
  }

  @Test
  void shouldAuditUpdateAccountDetailsFailure() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    testSubject.auditAccountDetailsUpdateFailure(
        ACCOUNT_NAME, ACCOUNT_NUMBER, AUDIT_MESSAGE, requestMetadata);

    final AuditAccountDetailsUpdateFailureRequest expectedAuditRequest =
        AuditAccountDetailsUpdateFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountName(ACCOUNT_NAME)
            .message(AUDIT_MESSAGE)
            .accountInformation(
                AuditAccountDetailsUpdateFailureRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();
    verify(auditService).auditAccountDetailsUpdateFailure(expectedAuditRequest, requestMetadata);
  }

  private RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .host(HOST)
        .partyId(PARTY_ID)
        .brandCode(BRAND_CODE)
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .build();
  }
}
