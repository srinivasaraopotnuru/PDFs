package uk.co.ybs.digital.account.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.account.exception.InvalidTransactionDateException;
import uk.co.ybs.digital.account.web.dto.TransactionDates;

public class TransactionDateServiceTest {

  private static final Clock CLOCK =
      Clock.fixed(Instant.parse("2022-04-04T13:45:01Z"), ZoneId.of("Europe/London"));
  private static final LocalDateTime NOW = LocalDateTime.now(CLOCK);
  private static final YearMonth NOW_PLUS_ONE_YEAR =
      YearMonth.of(NOW.getYear() + 1, NOW.getMonth());
  private static final YearMonth VALID_MONTH = YearMonth.of(2021, 1);
  private static final LocalDateTime VALID_START_DATE =
      LocalDateTime.parse(VALID_MONTH + "-01T00:00:00");
  private static final LocalDateTime VALID_END_DATE =
      LocalDateTime.parse(VALID_MONTH + "-31T23:59:59");

  private TransactionDateService transactionDateService;

  @BeforeEach
  void setUp() {
    transactionDateService = new TransactionDateService(CLOCK);
  }

  @Test
  public void shouldSucceedWithValidStartMonthAndValidEndMonth() {
    final TransactionDates transactionDates =
        transactionDateService.createTransactionDates(VALID_MONTH, VALID_MONTH);
    final TransactionDates expectedTransactionsDates =
        TransactionDates.builder().startDate(VALID_START_DATE).endDate(VALID_END_DATE).build();

    assertEquals(transactionDates, expectedTransactionsDates);
  }

  @Test
  public void shouldSucceedWithNullStartMonthAndValidEndMonth() {
    final TransactionDates transactionDates =
        transactionDateService.createTransactionDates(null, VALID_MONTH);
    final TransactionDates expectedTransactionsDates =
        TransactionDates.builder().endDate(VALID_END_DATE).build();

    assertEquals(transactionDates, expectedTransactionsDates);
  }

  @Test
  public void shouldSucceedWithValidStartMonthAndNullEndMonth() {
    final TransactionDates transactionDates =
        transactionDateService.createTransactionDates(VALID_MONTH, null);
    final TransactionDates expectedTransactionsDates =
        TransactionDates.builder().startDate(VALID_START_DATE).build();

    assertEquals(transactionDates, expectedTransactionsDates);
  }

  @Test
  public void shouldSucceedWithNullStartMonthAndNullEndMonth() {
    final TransactionDates transactionDates =
        transactionDateService.createTransactionDates(null, null);
    final TransactionDates expectedTransactionsDates = TransactionDates.builder().build();

    assertEquals(transactionDates, expectedTransactionsDates);
  }

  @Test
  public void shouldThrowInvalidDateExceptionWhenStartMonthIsAfterEndMonth() {
    final InvalidTransactionDateException exception =
        assertThrows(
            InvalidTransactionDateException.class,
            () ->
                transactionDateService.createTransactionDates(
                    YearMonth.of(2021, 11), YearMonth.of(2021, 10)));

    assertThat(
        exception.getMessage(),
        is(equalTo("Start date 2021-11-01T00:00 is after end date 2021-10-31T23:59:59")));
  }

  @Test
  public void shouldThrowInvalidDateExceptionWhenStartMonthIsAfterNow() {
    final InvalidTransactionDateException exception =
        assertThrows(
            InvalidTransactionDateException.class,
            () -> transactionDateService.createTransactionDates(NOW_PLUS_ONE_YEAR, null));

    assertThat(exception.getMessage(), is(equalTo("Start date 2023-04-01T00:00 is after now")));
  }
}
