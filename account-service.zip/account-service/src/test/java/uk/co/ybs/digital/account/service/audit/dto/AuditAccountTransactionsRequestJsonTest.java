package uk.co.ybs.digital.account.service.audit.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;

@JsonTest
class AuditAccountTransactionsRequestJsonTest {
  @Autowired private JacksonTester<AuditAccountTransactionsRequest> tester;

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void serializes(
      final AuditAccountTransactionsRequest request, final ClassPathResource requestFile)
      throws IOException {
    assertThat(tester.write(request)).isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void deserializes(
      final AuditAccountTransactionsRequest request, final ClassPathResource requestFile)
      throws IOException {
    assertThat(tester.read(requestFile)).isEqualTo(request);
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(
            buildRequestWithDates(),
            new ClassPathResource(
                "api/auditService/request/auditAccountTransactions/requestWithDates.json")),
        Arguments.of(
            buildRequestWithoutDates(),
            new ClassPathResource(
                "api/auditService/request/auditAccountTransactions/requestWithoutDates.json")));
  }

  private static AuditAccountTransactionsRequest buildRequestWithoutDates() {
    return AuditAccountTransactionsRequest.builder()
        .ipAddress("12.66.53.145")
        .accountInformation(
            AuditAccountTransactionsRequest.AccountInformation.builder()
                .accountNumber("2372146519")
                .build())
        .build();
  }

  private static AuditAccountTransactionsRequest buildRequestWithDates() {
    return AuditAccountTransactionsRequest.builder()
        .ipAddress("12.66.53.145")
        .accountInformation(
            AuditAccountTransactionsRequest.AccountInformation.builder()
                .accountNumber("2372146519")
                .startDate("2019-02-01T10:00:00Z")
                .endDate("2020-02-01T10:00:00Z")
                .build())
        .build();
  }
}
