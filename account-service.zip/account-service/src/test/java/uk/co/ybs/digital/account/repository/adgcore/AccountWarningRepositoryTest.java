package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.AccountWarning;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
class AccountWarningRepositoryTest {
  private static final Long PRODUCT_ID = 1001L;

  private static final Long ACCOUNT_NUMBER_1 = 2001L;
  private static final Long ACCOUNT_NUMBER_2 = 2002L;
  private static final Long ACCOUNT_NUMBER_3 = 2003L;

  private static final String RESTRICTION_TYPE_CODE_1 = "RTYP1";
  private static final String RESTRICTION_TYPE_CODE_2 = "RTYP2";

  private static final String RESTRICTION_TYPE_DESCRIPTION = "Test description";

  private static final String RULE_CODE_1 = "RUL1";
  private static final String RULE_CODE_2 = "RUL2";
  private static final String RULE_CODE_3 = "RUL3";

  private static final String RULE_1_VALUE = "RUL1_VALUE";
  private static final String RULE_2_VALUE = "RUL2_VALUE";
  private static final String RULE_3_VALUE = "RUL3_VALUE";

  private static final List<String> RULE_CODES =
      Arrays.asList(RULE_CODE_1, RULE_CODE_2, RULE_CODE_3);

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T10:15:30");
  private static final LocalDateTime ONE_DAY_AGO = NOW.minusDays(1);

  @Autowired AccountWarningRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @BeforeEach
  void beforeEach() {
    persistSavingProduct(PRODUCT_ID);
  }

  @Test
  void shouldFindById() {
    // Proves that the repo has been setup with the correct entity and pk types
    final Long accountWarningSysId = 6001L;

    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    final AccountWarning accountWarning =
        persistAccountWarning(accountWarningSysId, accountNumber, restrictionType, NOW, null);
    adgCoreTestEntityManager.clear();

    final Optional<AccountWarning> found = testSubject.findById(accountWarningSysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(accountWarning));
  }

  @Test
  void shouldFindAccountWarningRestrictionRules() {
    final AccountNumber accountNumber1 = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final AccountNumber accountNumber2 = persistAccountNumber(ACCOUNT_NUMBER_2, PRODUCT_ID);

    final RestrictionType restrictionType1 =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    final RestrictionType restrictionType2 =
        persistRestrictionType(5002L, RESTRICTION_TYPE_CODE_2, NOW, null);

    persistRestrictionTypeRule(6001L, RULE_CODE_1, RULE_1_VALUE, restrictionType1, NOW, null);
    persistRestrictionTypeRule(6002L, RULE_CODE_2, RULE_2_VALUE, restrictionType1, NOW, null);
    persistRestrictionTypeRule(7001L, RULE_CODE_1, RULE_1_VALUE, restrictionType2, NOW, null);
    persistRestrictionTypeRule(7002L, RULE_CODE_3, RULE_3_VALUE, restrictionType2, NOW, null);

    persistAccountWarning(1L, accountNumber1, restrictionType1, NOW, null);
    persistAccountWarning(2L, accountNumber2, restrictionType1, NOW, null);
    persistAccountWarning(3L, accountNumber2, restrictionType2, NOW, null);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(ACCOUNT_NUMBER_1, ACCOUNT_NUMBER_2), RULE_CODES, NOW);

    assertThat(
        restrictionRules,
        containsInAnyOrder(
            new AccountWarningRestrictionRule(
                ACCOUNT_NUMBER_1, RESTRICTION_TYPE_CODE_1, RULE_CODE_1, RULE_1_VALUE),
            new AccountWarningRestrictionRule(
                ACCOUNT_NUMBER_1, RESTRICTION_TYPE_CODE_1, RULE_CODE_2, RULE_2_VALUE),
            new AccountWarningRestrictionRule(
                ACCOUNT_NUMBER_2, RESTRICTION_TYPE_CODE_1, RULE_CODE_1, RULE_1_VALUE),
            new AccountWarningRestrictionRule(
                ACCOUNT_NUMBER_2, RESTRICTION_TYPE_CODE_1, RULE_CODE_2, RULE_2_VALUE),
            new AccountWarningRestrictionRule(
                ACCOUNT_NUMBER_2, RESTRICTION_TYPE_CODE_2, RULE_CODE_1, RULE_1_VALUE),
            new AccountWarningRestrictionRule(
                ACCOUNT_NUMBER_2, RESTRICTION_TYPE_CODE_2, RULE_CODE_3, RULE_3_VALUE)));
  }

  @ParameterizedTest
  @CsvSource({"2001,true", "2002,false"})
  void shouldOnlyFindAccountWarningRestrictionRulesWhereAccountWarningExistsForAccountNumber(
      final Long accountNumberLong, final boolean expectedFind) {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistRestrictionTypeRule(6001L, RULE_CODE_1, RULE_1_VALUE, restrictionType, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(accountNumberLong), RULE_CODES, NOW);

    assertThat(restrictionRules.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({
    "RUL1,RUL1_VALUE,true",
    "RUL2,RUL2_VALUE,true",
    "RUL3,RUL3_VALUE,true",
    "OTH1,OTH1_VALUE,false"
  })
  void shouldOnlyFindAccountWarningRestrictionRulesWhereRestrictionRuleExistsForCode(
      final String restrictionTypeRuleCode,
      final String restrictionTypeRuleValue,
      final boolean expectedFind) {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistRestrictionTypeRule(
        6001L, restrictionTypeRuleCode, restrictionTypeRuleValue, restrictionType, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(ACCOUNT_NUMBER_1), RULE_CODES, NOW);

    assertThat(restrictionRules.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"2020-05-25T10:15:29,true", "2020-05-25T10:15:30,true", "2020-05-25T10:15:31,false"})
  void shouldOnlyFindAccountWarningRestrictionRulesWhereAccountWarningHasStarted(
      final LocalDateTime accountWarningStartDate, final boolean expectedFind) {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistRestrictionTypeRule(6001L, RULE_CODE_1, RULE_1_VALUE, restrictionType, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, accountWarningStartDate, null);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(ACCOUNT_NUMBER_1), RULE_CODES, NOW);

    assertThat(restrictionRules.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({
    "2020-05-25T10:15:29,false",
    "2020-05-25T10:15:30,false",
    "2020-05-25T10:15:31,true",
    ",true"
  })
  void shouldOnlyFindAccountWarningRestrictionRulesWhereAccountWarningHasNotEnded(
      final LocalDateTime accountWarningEndDate, final boolean expectedFind) {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistRestrictionTypeRule(6001L, RULE_CODE_1, RULE_1_VALUE, restrictionType, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, accountWarningEndDate);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(ACCOUNT_NUMBER_1), RULE_CODES, NOW);

    assertThat(restrictionRules.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"2020-05-25T10:15:29,true", "2020-05-25T10:15:30,true", "2020-05-25T10:15:31,false"})
  void shouldOnlyFindAccountWarningRestrictionRulesWhereRestrictionTypeRuleHasStarted(
      final LocalDateTime restrictionTypeStartDate, final boolean expectedFind) {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistRestrictionTypeRule(
        6001L, RULE_CODE_1, RULE_1_VALUE, restrictionType, restrictionTypeStartDate, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(ACCOUNT_NUMBER_1), RULE_CODES, NOW);

    assertThat(restrictionRules.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({
    "2020-05-25T10:15:29,false",
    "2020-05-25T10:15:30,false",
    "2020-05-25T10:15:31,true",
    ",true"
  })
  void shouldOnlyFindAccountWarningRestrictionRulesWhereRestrictionTypeRuleHasNotEnded(
      final LocalDateTime restrictionTypeEndDate, final boolean expectedFind) {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistRestrictionTypeRule(
        6001L, RULE_CODE_1, RULE_1_VALUE, restrictionType, NOW, restrictionTypeEndDate);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(ACCOUNT_NUMBER_1), RULE_CODES, NOW);

    assertThat(restrictionRules.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({"2020-05-25T10:15:29,true", "2020-05-25T10:15:30,true", "2020-05-25T10:15:31,false"})
  void shouldOnlyFindAccountWarningRestrictionRulesWhereRestrictionTypeHasStarted(
      final LocalDateTime restrictionTypeRuleStartDate, final boolean expectedFind) {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, restrictionTypeRuleStartDate, null);
    persistRestrictionTypeRule(6001L, RULE_CODE_1, RULE_1_VALUE, restrictionType, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(ACCOUNT_NUMBER_1), RULE_CODES, NOW);

    assertThat(restrictionRules.isEmpty(), not(expectedFind));
  }

  @ParameterizedTest
  @CsvSource({
    "2020-05-25T10:15:29,false",
    "2020-05-25T10:15:30,false",
    "2020-05-25T10:15:31,true",
    ",true"
  })
  void shouldOnlyFindAccountWarningRestrictionRulesWhereRestrictionTypeHasNotEnded(
      final LocalDateTime restrictionTypeRuleEndDate, final boolean expectedFind) {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, restrictionTypeRuleEndDate);
    persistRestrictionTypeRule(6001L, RULE_CODE_1, RULE_1_VALUE, restrictionType, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    adgCoreTestEntityManager.clear();

    final Collection<AccountWarningRestrictionRule> restrictionRules =
        testSubject.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            Arrays.asList(ACCOUNT_NUMBER_1), RULE_CODES, NOW);

    assertThat(restrictionRules.isEmpty(), not(expectedFind));
  }

  @Test
  void shouldFindActiveAccountWarningsByAccountNumberAndDateForSingleAccount() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    final AccountWarning expected =
        persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    final Collection<AccountWarning> results =
        testSubject.findActiveAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_1), NOW);

    assertThat(results.isEmpty(), is(false));
    assertThat(results, containsInAnyOrder(expected));
  }

  @Test
  void
      shouldNotFindActiveAccountWarningsByAccountNumberAndDateForSingleAccountWhenAccountNumberIsDifferent() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    final Collection<AccountWarning> results =
        testSubject.findActiveAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(23232L), NOW);

    assertThat(results.isEmpty(), is(true));
  }

  @Test
  void shouldFindActiveAccountWarningsByAccountNumberAndDateForMultipleAccounts() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final AccountNumber accountNumber2 = persistAccountNumber(ACCOUNT_NUMBER_2, PRODUCT_ID);
    final AccountNumber accountNumber3 = persistAccountNumber(ACCOUNT_NUMBER_3, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    final AccountWarning expected =
        persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    final AccountWarning expected2 =
        persistAccountWarning(2L, accountNumber2, restrictionType, NOW, null);
    final AccountWarning expected3 =
        persistAccountWarning(
            3L, accountNumber3, restrictionType, NOW.minusDays(10), NOW.minusDays(1));
    final List<AccountWarning> expectedResponse = new ArrayList<>();
    expectedResponse.add(expected);
    expectedResponse.add(expected2);
    final List<Long> accountNumbers = new ArrayList<>();
    accountNumbers.add(ACCOUNT_NUMBER_1);
    accountNumbers.add(ACCOUNT_NUMBER_2);
    accountNumbers.add(ACCOUNT_NUMBER_3);
    final Collection<AccountWarning> results =
        testSubject.findActiveAccountWarningsByAccountNumberAndDate(accountNumbers, NOW);

    assertThat(results.isEmpty(), is(false));
    assertEquals(results, expectedResponse);
    Assertions.assertFalse(results.contains(expected3));
  }

  @Test
  void
      shouldNotFindActiveAccountWarningsByAccountNumberAndDateForMultipleAccountsWhenAccountNumberIsDifferent() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final AccountNumber accountNumber2 = persistAccountNumber(ACCOUNT_NUMBER_2, PRODUCT_ID);
    final AccountNumber accountNumber3 = persistAccountNumber(ACCOUNT_NUMBER_3, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    persistAccountWarning(2L, accountNumber2, restrictionType, NOW, null);
    persistAccountWarning(3L, accountNumber3, restrictionType, NOW.minusDays(10), NOW.minusDays(1));
    final List<Long> accountNumbers = new ArrayList<>();
    accountNumbers.add(23232L);
    accountNumbers.add(23233L);
    accountNumbers.add(ACCOUNT_NUMBER_3);
    final Collection<AccountWarning> results =
        testSubject.findActiveAccountWarningsByAccountNumberAndDate(accountNumbers, NOW);
    assertThat(results.isEmpty(), is(true));
  }

  @Test
  void shouldFindAccountWarningsByAccountNumberAndDateForSingleAccount() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    final AccountWarning expected =
        persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    final Collection<AccountWarning> results =
        testSubject.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_1), NOW);

    assertThat(results.isEmpty(), is(false));
    assertThat(results, containsInAnyOrder(expected));
  }

  @Test
  void
      shouldNotFindAccountWarningsByAccountNumberAndDateForSingleAccountWhenAccountNumberIsDifferent() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    final Collection<AccountWarning> results =
        testSubject.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(23232L), NOW);

    assertThat(results.isEmpty(), is(true));
  }

  @Test
  void shouldFindAccountWarningsByAccountNumberAndDateForMultipleAccounts() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final AccountNumber accountNumber2 = persistAccountNumber(ACCOUNT_NUMBER_2, PRODUCT_ID);
    final AccountNumber accountNumber3 = persistAccountNumber(ACCOUNT_NUMBER_3, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    final AccountWarning expected =
        persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    final AccountWarning expected2 =
        persistAccountWarning(2L, accountNumber2, restrictionType, NOW, null);
    final AccountWarning expected3 =
        persistAccountWarning(
            3L, accountNumber3, restrictionType, NOW.minusDays(10), NOW.minusDays(1));
    final List<AccountWarning> expectedResponse = new ArrayList<>();
    expectedResponse.add(expected);
    expectedResponse.add(expected2);
    expectedResponse.add(expected3);
    final List<Long> accountNumbers = new ArrayList<>();
    accountNumbers.add(ACCOUNT_NUMBER_1);
    accountNumbers.add(ACCOUNT_NUMBER_2);
    accountNumbers.add(ACCOUNT_NUMBER_3);
    final Collection<AccountWarning> results =
        testSubject.findAccountWarningsByAccountNumberAndDate(accountNumbers, NOW);

    assertThat(results.isEmpty(), is(false));
    assertEquals(results, expectedResponse);
  }

  @Test
  void
      shouldNotFindAccountWarningsByAccountNumberAndDateForMultipleAccountsWhenAccountNumberIsDifferent() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final AccountNumber accountNumber2 = persistAccountNumber(ACCOUNT_NUMBER_2, PRODUCT_ID);
    final AccountNumber accountNumber3 = persistAccountNumber(ACCOUNT_NUMBER_3, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);
    persistAccountWarning(2L, accountNumber2, restrictionType, NOW, null);
    persistAccountWarning(3L, accountNumber3, restrictionType, NOW.minusDays(10), NOW.minusDays(1));
    final List<Long> accountNumbers = new ArrayList<>();
    accountNumbers.add(23232L);
    accountNumbers.add(23233L);
    accountNumbers.add(ACCOUNT_NUMBER_3);
    final Collection<AccountWarning> results =
        testSubject.findAccountWarningsByAccountNumberAndDate(accountNumbers, NOW);
    assertThat(results.isEmpty(), is(false));
  }

  @Test
  void shouldFindAccountWarningsByAccountNumberAndDateForSingleAccountWhenWarningsHaveEnded() {
    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, ONE_DAY_AGO);
    final AccountWarning expected =
        persistAccountWarning(1L, accountNumber, restrictionType, NOW, ONE_DAY_AGO);
    final Collection<AccountWarning> results =
        testSubject.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_1), NOW);

    assertThat(results.isEmpty(), is(false));
    assertThat(results, containsInAnyOrder(expected));
  }

  @ParameterizedTest
  @MethodSource("startDateAndExpectedFoundAccountWarningStatus")
  void shouldOnlyFindAccountWarningWhenAccountWarningHasStarted(
      final LocalDateTime startDate, final Boolean expectedFound) {

    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, null);
    persistAccountWarning(1L, accountNumber, restrictionType, startDate, null);

    final Collection<AccountWarning> accountWarnings =
        testSubject.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber.getAccountNumber(),
            Collections.singletonList(RESTRICTION_TYPE_CODE_1),
            NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  @ParameterizedTest
  @MethodSource("endDateAndExpectedFoundAccountWarningStatus")
  void shouldOnlyFindAccountWarningWhenRestrictionTypeHasNotEnded(
      final LocalDateTime endDate, final Boolean expectedFound) {

    final AccountNumber accountNumber = persistAccountNumber(ACCOUNT_NUMBER_1, PRODUCT_ID);
    final RestrictionType restrictionType =
        persistRestrictionType(5001L, RESTRICTION_TYPE_CODE_1, NOW, endDate);
    persistAccountWarning(1L, accountNumber, restrictionType, NOW, null);

    final Collection<AccountWarning> accountWarnings =
        testSubject.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            accountNumber.getAccountNumber(),
            Collections.singletonList(RESTRICTION_TYPE_CODE_1),
            NOW);
    final Boolean found = !accountWarnings.isEmpty();

    assertEquals(expectedFound, found);
  }

  private static Stream<Arguments> startDateAndExpectedFoundAccountWarningStatus() {
    return Stream.of(
        Arguments.of(NOW.minusDays(1), true),
        Arguments.of(NOW, true),
        Arguments.of(NOW.plusDays(1), false));
  }

  private static Stream<Arguments> endDateAndExpectedFoundAccountWarningStatus() {
    return Stream.of(
        Arguments.of(NOW.minusDays(1).toLocalDate().atTime(12, 0), false),
        Arguments.of(NOW.toLocalDate().atTime(1, 0), false),
        Arguments.of(NOW.plusDays(1).toLocalDate().atTime(9, 0), true),
        Arguments.of(null, true));
  }

  private void persistSavingProduct(final Long savingProductSysId) {
    adgCoreTestEntityManager.persistAndFlush(
        new SavingProduct(savingProductSysId, "YBS", "PROD_IDENT"));
  }

  private AccountNumber persistAccountNumber(
      final Long accountNumber, final Long savingProductSysId) {
    final AccountNumber activityType =
        AccountNumber.builder()
            .accountNumber(accountNumber)
            .tableId(AccountNumber.TABLE_ID_SAVACC)
            .savingProductSysId(savingProductSysId)
            .build();
    return adgCoreTestEntityManager.persistAndFlush(activityType);
  }

  private RestrictionType persistRestrictionType(
      final Long sysId,
      final String restrictionTypeCode,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    final RestrictionType restrictionType =
        RestrictionType.builder()
            .sysId(sysId)
            .description(RESTRICTION_TYPE_DESCRIPTION)
            .code(restrictionTypeCode)
            .startDate(startDate)
            .endDate(endDate)
            .build();
    return adgCoreTestEntityManager.persistAndFlush(restrictionType);
  }

  private RestrictionTypeRule persistRestrictionTypeRule(
      final Long sysId,
      final String restrictionTypeRuleCode,
      final String charValue,
      final RestrictionType restrictionType,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    final RestrictionTypeRule restrictionTypeRule =
        RestrictionTypeRule.builder()
            .sysId(sysId)
            .code(restrictionTypeRuleCode)
            .charValue(charValue)
            .restrictionType(restrictionType)
            .startDate(startDate)
            .endDate(endDate)
            .build();
    return adgCoreTestEntityManager.persistAndFlush(restrictionTypeRule);
  }

  private AccountWarning persistAccountWarning(
      final Long sysId,
      final AccountNumber accountNumber,
      final RestrictionType restrictionType,
      final LocalDateTime startDate,
      final LocalDateTime endDate) {
    final AccountWarning accountWarning =
        AccountWarning.builder()
            .sysId(sysId)
            .accountNumber(accountNumber)
            .restrictionType(restrictionType)
            .startDate(startDate)
            .endDate(endDate)
            .build();
    return adgCoreTestEntityManager.persistAndFlush(accountWarning);
  }
}
