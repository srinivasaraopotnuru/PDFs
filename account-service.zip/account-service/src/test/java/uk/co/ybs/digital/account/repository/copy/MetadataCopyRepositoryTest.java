package uk.co.ybs.digital.account.repository.copy;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.account.model.copy.Metadata;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
@Transactional("accountProcessorTransactionManager")
class MetadataCopyRepositoryTest {

  private static final long DB_ID = 3752281465L;
  private static final LocalDateTime CREATED = LocalDateTime.parse("2020-12-07T13:31:30");

  @Autowired MetadataCopyRepository testSubject;

  @Autowired TestEntityManager copyTestEntityManager;

  @Test
  void shouldFindById() {
    final Metadata metadata = Metadata.builder().sysId(DB_ID).created(CREATED).build();

    copyTestEntityManager.persistAndFlush(metadata);
    copyTestEntityManager.clear();

    final Optional<Metadata> found = testSubject.findById(DB_ID);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(metadata));
  }

  @Test
  void shouldFindAll() {
    final Metadata metadata = Metadata.builder().sysId(DB_ID).created(CREATED).build();

    copyTestEntityManager.persistAndFlush(metadata);
    copyTestEntityManager.clear();

    final List<Metadata> found = testSubject.findAll();

    assertThat(found.get(0), samePropertyValuesAs(metadata));
  }
}
