package uk.co.ybs.digital.account.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_CLOSED_DATE;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_NAME;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_NUMBER;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_NUMBER_LONG;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_OPENED_DATE_TIME;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES;
import static uk.co.ybs.digital.account.utils.TestHelper.ACTIVITY_GROUP_CODES_PISP_ONLY;
import static uk.co.ybs.digital.account.utils.TestHelper.AMOUNT_ONE_POUND;
import static uk.co.ybs.digital.account.utils.TestHelper.AMOUNT_TWENTY_FIVE_POUND;
import static uk.co.ybs.digital.account.utils.TestHelper.CLOCK;
import static uk.co.ybs.digital.account.utils.TestHelper.FILTER_AVAILABLE_DEPOSIT_LIMIT;
import static uk.co.ybs.digital.account.utils.TestHelper.FILTER_OTHER_ACCOUNT;
import static uk.co.ybs.digital.account.utils.TestHelper.INTSAV_PRODUCT_ID;
import static uk.co.ybs.digital.account.utils.TestHelper.MAX_PRODUCT_BALANCE;
import static uk.co.ybs.digital.account.utils.TestHelper.MAX_PRODUCT_BALANCE_REMAINING;
import static uk.co.ybs.digital.account.utils.TestHelper.NOW;
import static uk.co.ybs.digital.account.utils.TestHelper.PARTY_ID;
import static uk.co.ybs.digital.account.utils.TestHelper.PARTY_ID_LONG;
import static uk.co.ybs.digital.account.utils.TestHelper.REMAINING_DEPOSIT_LIMIT;
import static uk.co.ybs.digital.account.utils.TestHelper.SACCSRV;
import static uk.co.ybs.digital.account.utils.TestHelper.SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION;
import static uk.co.ybs.digital.account.utils.TestHelper.TWO_DAYS_AGO;
import static uk.co.ybs.digital.account.utils.TestHelper.VALID_WIT_CODE;
import static uk.co.ybs.digital.account.utils.TestHelper.ZERO_BALANCE;

import com.google.common.collect.ImmutableSet;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AccountAccessDeniedException;
import uk.co.ybs.digital.account.exception.AccountNameConflictException;
import uk.co.ybs.digital.account.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.account.exception.AccountServiceException;
import uk.co.ybs.digital.account.exception.NoUpdatedAccountDetailsSpecifiedException;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup;
import uk.co.ybs.digital.account.model.adgcore.SavingAccount;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.model.digitalaccount.DeleteAccountRequest;
import uk.co.ybs.digital.account.model.digitalaccount.UpdateAccountDetailsRequest;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Operation;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogRequest;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.adgcore.AccountWarningRepository;
import uk.co.ybs.digital.account.repository.adgcore.ActivityPlayerRepository;
import uk.co.ybs.digital.account.repository.adgcore.PartyRepository;
import uk.co.ybs.digital.account.repository.adgcore.RestrictionTypeRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingAccountAnnualWithdrawalLimitRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingAccountRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingProductRepository;
import uk.co.ybs.digital.account.repository.digitalaccount.WorkLogRepository;
import uk.co.ybs.digital.account.repository.frontoffice.SavingsTransactionLogRepository;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AuthenticService;
import uk.co.ybs.digital.account.service.mapper.AccountDetailsMapper;
import uk.co.ybs.digital.account.service.mapper.GroupedAccountListMapper;
import uk.co.ybs.digital.account.service.product.ProductService;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.account.service.utilities.AccountWarningFilter;
import uk.co.ybs.digital.account.service.utilities.AvailableDepositLimitCalculator;
import uk.co.ybs.digital.account.service.utilities.ManageInterestCalculator;
import uk.co.ybs.digital.account.service.utilities.ReinvestmentCalculator;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.AccountDetails;
import uk.co.ybs.digital.account.web.dto.AccountDetailsResponse;
import uk.co.ybs.digital.account.web.dto.Reinvestment;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.UpdateAccountDetails;

@ExtendWith(MockitoExtension.class)
class AccountServiceAccountDetailsTest {

  private AccountService accountService;
  private UUID requestId;

  @Mock private AccountAccessValidator accountAccessValidator;
  @Mock private AvailableDepositLimitCalculator availableDepositLimitCalculator;
  @Mock private AccountDetailsMapper accountDetailsMapper;
  @Mock private GroupedAccountListMapper accountListMapper;
  @Mock private ActivityPlayerRepository activityPlayerRepository;
  @Mock private AccountWarningRepository accountWarningRepository;
  @Mock private RestrictionTypeRepository restrictionTypeRepository;

  @Mock private AuthenticService authenticService;

  @Mock
  private SavingAccountAnnualWithdrawalLimitRepository savingAccountAnnualWithdrawalLimitRepository;

  @Mock private SavingsTransactionLogRepository savingsTransactionLogRepository;
  @Mock private AccountWarningFilter accountWarningFilter;
  @Mock private ProductService productService;
  @Mock private WorkLogRepository workLogRepository;
  @Mock private AccountServiceProperties accountServiceProperties;
  @Mock private SavingProductRepository savingProductRepository;
  @Mock private AccountNumberRepository accountNumberRepository;
  @Mock private SavingAccountRepository savingAccountRepository;
  @Mock private SavingAccountDetailsService savingAccountDetailsService;
  @Mock private SavingAccountDetailsListService customersSavingsAccountService;
  @Mock private PartyRepository partyRepository;
  @Mock private ReinvestmentCalculator reinvestmentCalculator;

  @Mock private ManageInterestCalculator manageInterestCalculator;

  private static final Set<String> ACTIVITY_GROUP_CODES_ACCOUNT_LIST =
      ImmutableSet.of(
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_AISP,
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP,
          ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS);

  @BeforeEach
  void setUp() {
    requestId = UUID.randomUUID();
    accountService =
        new AccountService(
            accountAccessValidator,
            productService,
            accountServiceProperties,
            authenticService,
            savingProductRepository,
            activityPlayerRepository,
            accountWarningRepository,
            restrictionTypeRepository,
            savingAccountRepository,
            savingAccountAnnualWithdrawalLimitRepository,
            savingsTransactionLogRepository,
            workLogRepository,
            accountNumberRepository,
            accountDetailsMapper,
            accountListMapper,
            availableDepositLimitCalculator,
            accountWarningFilter,
            CLOCK,
            savingAccountDetailsService,
            customersSavingsAccountService,
            partyRepository,
            reinvestmentCalculator,
            manageInterestCalculator);
  }

  @Test
  void getAccountDetailsShouldSucceed() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, productIdentifier, null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Collections.emptyList();
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final List<AccountBalanceType> accountBalanceTypeList =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(ACCOUNT_NUMBER)).thenReturn(accountBalanceTypeList);

    final ProductInfo productInfo =
        TestHelper.createProductInfo(productIdentifier, MAX_PRODUCT_BALANCE);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final ProductInfo webAmendmentsPermiitedProductInfo =
        TestHelper.createProductInfoWebPermitted(true);

    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            TestHelper.PERMITTED_WIT_CODES.get(0),
            webAmendmentsPermiitedProductInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRules))
        .thenReturn(true);

    final Reinvestment reinvestment = TestHelper.createReinvestment(true);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(true);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER, Collections.emptyList());
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionFiltered =
        Collections.emptyList();
    when(availableDepositLimitCalculator.calculateRemainingDepositLimit(
            ACCOUNT_NUMBER, false, false, productInfo, accountWarningRestrictionFiltered, NOW))
        .thenReturn(REMAINING_DEPOSIT_LIMIT);
    when(availableDepositLimitCalculator.calculateRemainingMaxProductBalance(
            ACCOUNT_NUMBER, false, false, productInfo, Optional.empty()))
        .thenReturn(MAX_PRODUCT_BALANCE_REMAINING);

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final String witCode = TestHelper.PERMITTED_WIT_CODES.get(0);

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG)))
        .thenReturn(
            Optional.of(
                TestHelper.buildSavingAccount(
                    ACCOUNT_NUMBER_LONG, new BigDecimal(AMOUNT_TWENTY_FIVE_POUND), witCode)));

    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            accountBalanceTypeList,
            productInfo,
            false,
            accountWarningRestrictionFiltered,
            ACTIVITY_GROUP_CODES_PISP_ONLY,
            null,
            false,
            REMAINING_DEPOSIT_LIMIT,
            MAX_PRODUCT_BALANCE_REMAINING,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            witCode,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(
            ACCOUNT_NUMBER, FILTER_AVAILABLE_DEPOSIT_LIMIT, requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    // Product has no anniversary limit, so we shouldn't have looked for the limit data
    verify(savingAccountAnnualWithdrawalLimitRepository, never()).findAllByAccountNumbers(any());
    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
  }

  @Test
  void getAccountDetailsShouldSucceedWhenAvailableDepositLimitFilteredOut() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, productIdentifier, null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Collections.emptyList();
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final List<AccountBalanceType> accountBalanceTypeList =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(ACCOUNT_NUMBER)).thenReturn(accountBalanceTypeList);

    final ProductInfo productInfo = TestHelper.createProductInfo(productIdentifier);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final ProductInfo webAmendmentsPermiitedProductInfo =
        TestHelper.createProductInfoWebPermitted(true);

    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            TestHelper.PERMITTED_WIT_CODES.get(3),
            webAmendmentsPermiitedProductInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRules))
        .thenReturn(true);

    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(false);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER, Collections.emptyList());
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionFiltered =
        Collections.emptyList();

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final String witCode = TestHelper.PERMITTED_WIT_CODES.get(3);

    when(savingAccountRepository.findById((Long.valueOf(ACCOUNT_NUMBER))))
        .thenReturn(
            Optional.of(
                TestHelper.buildSavingAccount(
                    ACCOUNT_NUMBER_LONG, new BigDecimal(AMOUNT_TWENTY_FIVE_POUND), witCode)));

    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            accountBalanceTypeList,
            productInfo,
            false,
            accountWarningRestrictionFiltered,
            ACTIVITY_GROUP_CODES_PISP_ONLY,
            null,
            false,
            null,
            null,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            witCode,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(ACCOUNT_NUMBER, Collections.emptyList(), requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    // Filter not set so exclude available deposit limit calculation
    verify(availableDepositLimitCalculator, never())
        .calculateRemainingDepositLimit(any(), anyBoolean(), anyBoolean(), any(), any(), any());

    // Product has no anniversary limit, so we shouldn't have looked for the limit data
    verify(savingAccountAnnualWithdrawalLimitRepository, never()).findAllByAccountNumbers(any());
    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
  }

  @Test
  void getAccountDetailsShouldSucceedWhenOtherAccountFiltersIsPresent() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, productIdentifier, null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Collections.emptyList();
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final List<AccountBalanceType> accountBalanceTypeList =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(ACCOUNT_NUMBER)).thenReturn(accountBalanceTypeList);

    final ProductInfo productInfo = TestHelper.createProductInfo(productIdentifier);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(false);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER, Collections.emptyList());
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionFiltered =
        Collections.emptyList();

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final String witCode = TestHelper.PERMITTED_WIT_CODES.get(4);

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG)))
        .thenReturn(
            Optional.of(
                TestHelper.buildSavingAccount(
                    ACCOUNT_NUMBER_LONG, new BigDecimal(AMOUNT_TWENTY_FIVE_POUND), witCode)));

    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            witCode,
            productInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionFiltered))
        .thenReturn(true);

    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            accountBalanceTypeList,
            productInfo,
            false,
            accountWarningRestrictionFiltered,
            Collections.emptySet(),
            null,
            false,
            null,
            null,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            witCode,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(ACCOUNT_NUMBER, FILTER_OTHER_ACCOUNT, requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    verify(accountAccessValidator)
        .validateAccountExistenceAndBrand(ACCOUNT_NUMBER, requestMetadata);
    verifyNoInteractions(activityPlayerRepository);
  }

  @Test
  void getAccountDetailsShouldSucceedForFutureDatedClosedAccount() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;
    final LocalDate closedDateInFuture = NOW.toLocalDate().plusDays(1);

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(
            ACCOUNT_NUMBER, productIdentifier, closedDateInFuture);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Collections.emptyList();
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final List<AccountBalanceType> accountBalanceTypeList =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(ACCOUNT_NUMBER)).thenReturn(accountBalanceTypeList);

    final ProductInfo productInfo =
        TestHelper.createProductInfo(productIdentifier, MAX_PRODUCT_BALANCE);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(false);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER, Collections.emptyList());
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionFiltered =
        Collections.emptyList();
    when(availableDepositLimitCalculator.calculateRemainingDepositLimit(
            ACCOUNT_NUMBER, false, false, productInfo, accountWarningRestrictionFiltered, NOW))
        .thenReturn(REMAINING_DEPOSIT_LIMIT);

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final String witCode = TestHelper.PERMITTED_WIT_CODES.get(7);

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG)))
        .thenReturn(
            Optional.of(
                TestHelper.buildSavingAccount(
                    ACCOUNT_NUMBER_LONG, new BigDecimal(AMOUNT_TWENTY_FIVE_POUND), witCode)));

    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            witCode,
            productInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRules))
        .thenReturn(true);

    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            accountBalanceTypeList,
            productInfo,
            false,
            accountWarningRestrictionFiltered,
            ACTIVITY_GROUP_CODES_PISP_ONLY,
            null,
            false,
            REMAINING_DEPOSIT_LIMIT,
            null,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            witCode,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(
            ACCOUNT_NUMBER, FILTER_AVAILABLE_DEPOSIT_LIMIT, requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
  }

  @Test
  void getAccountDetailsShouldSucceedForClosedAccount() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;
    final LocalDate closedDateToday = NOW.toLocalDate();

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, productIdentifier, closedDateToday);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Collections.emptyList();
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final ProductInfo productInfo =
        TestHelper.createProductInfo(productIdentifier, MAX_PRODUCT_BALANCE);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(false);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER, Collections.emptyList());
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionFiltered =
        Collections.emptyList();

    when(availableDepositLimitCalculator.calculateRemainingDepositLimit(
            ACCOUNT_NUMBER, true, false, productInfo, accountWarningRestrictionFiltered, NOW))
        .thenReturn(REMAINING_DEPOSIT_LIMIT);

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG)))
        .thenReturn(
            Optional.of(
                TestHelper.buildSavingAccount(
                    ACCOUNT_NUMBER_LONG,
                    new BigDecimal(ZERO_BALANCE),
                    TestHelper.PERMITTED_WIT_CODES.get(9))));

    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            TestHelper.PERMITTED_WIT_CODES.get(9),
            productInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRules))
        .thenReturn(true);
    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            TestHelper.createAccountBalanceTypeListForClosedAccounts(ZERO_BALANCE),
            productInfo,
            false,
            accountWarningRestrictionFiltered,
            ACTIVITY_GROUP_CODES_PISP_ONLY,
            null,
            true,
            REMAINING_DEPOSIT_LIMIT,
            null,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            VALID_WIT_CODE,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(
            ACCOUNT_NUMBER, FILTER_AVAILABLE_DEPOSIT_LIMIT, requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    verify(authenticService, never()).getBalance(any());
    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
  }

  @Test
  void
      getAccountDetailsShouldSucceedForProductWithAnniversaryWithdrawalLimitButNoLimitRecordForAccount() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, productIdentifier, null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Collections.emptyList();
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final List<AccountBalanceType> accountBalanceTypeList =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(ACCOUNT_NUMBER)).thenReturn(accountBalanceTypeList);

    final ProductInfo productInfo =
        TestHelper.createProductInfoWithAnniversaryWithdrawalLimit(productIdentifier);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(false);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER, Collections.emptyList());
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionFiltered =
        Collections.emptyList();

    when(savingAccountAnnualWithdrawalLimitRepository.findAllByAccountNumbers(accountNumberLongs))
        .thenReturn(Collections.emptyList());

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final String witCode = TestHelper.PERMITTED_WIT_CODES.get(0);

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG)))
        .thenReturn(
            Optional.of(
                TestHelper.buildSavingAccount(
                    ACCOUNT_NUMBER_LONG, new BigDecimal(AMOUNT_TWENTY_FIVE_POUND), witCode)));

    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            witCode,
            productInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRules))
        .thenReturn(true);
    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            accountBalanceTypeList,
            productInfo,
            false,
            accountWarningRestrictionFiltered,
            ACTIVITY_GROUP_CODES_PISP_ONLY,
            null,
            false,
            null,
            null,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            witCode,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(
            ACCOUNT_NUMBER, FILTER_AVAILABLE_DEPOSIT_LIMIT, requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
  }

  @Test
  void getAccountDetailsShouldSucceedForAccountWithAnniversaryWithdrawalLimit() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, productIdentifier, null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Collections.emptyList();
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final List<AccountBalanceType> accountBalanceTypeList =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(ACCOUNT_NUMBER)).thenReturn(accountBalanceTypeList);

    final ProductInfo productInfo =
        TestHelper.createProductInfoWithAnniversaryWithdrawalLimit(productIdentifier);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(false);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER, Collections.emptyList());
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionFiltered =
        Collections.emptyList();

    final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit =
        TestHelper.createSavingAccountAnnualWithdrawalLimit(ACCOUNT_NUMBER);
    when(savingAccountAnnualWithdrawalLimitRepository.findAllByAccountNumbers(accountNumberLongs))
        .thenReturn(Collections.singleton(savingAccountAnnualWithdrawalLimit));

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final String witCode = TestHelper.PERMITTED_WIT_CODES.get(2);

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG)))
        .thenReturn(
            Optional.of(
                TestHelper.buildSavingAccount(
                    ACCOUNT_NUMBER_LONG, new BigDecimal(AMOUNT_TWENTY_FIVE_POUND), witCode)));

    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            witCode,
            productInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRules))
        .thenReturn(true);

    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            accountBalanceTypeList,
            productInfo,
            false,
            accountWarningRestrictionFiltered,
            ACTIVITY_GROUP_CODES_PISP_ONLY,
            savingAccountAnnualWithdrawalLimit,
            false,
            null,
            null,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            witCode,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(
            ACCOUNT_NUMBER, FILTER_AVAILABLE_DEPOSIT_LIMIT, requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
  }

  @Test
  void getAccountDetailsShouldSucceedForAccountWithProductMigrationInProgress() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, productIdentifier, null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        Collections.emptyList();
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final List<AccountBalanceType> accountBalanceTypeList =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(ACCOUNT_NUMBER)).thenReturn(accountBalanceTypeList);

    final ProductInfo productInfo =
        TestHelper.createProductInfoWithAnniversaryWithdrawalLimit(
            productIdentifier, MAX_PRODUCT_BALANCE);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(false);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER, Collections.emptyList());
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final List<AccountWarningRestrictionRule> accountWarningRestrictionFiltered =
        Collections.emptyList();

    when(availableDepositLimitCalculator.calculateRemainingDepositLimit(
            ACCOUNT_NUMBER, false, true, productInfo, accountWarningRestrictionFiltered, NOW))
        .thenReturn(REMAINING_DEPOSIT_LIMIT);

    final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit =
        TestHelper.createSavingAccountAnnualWithdrawalLimit(ACCOUNT_NUMBER);
    when(savingAccountAnnualWithdrawalLimitRepository.findAllByAccountNumbers(accountNumberLongs))
        .thenReturn(Collections.singleton(savingAccountAnnualWithdrawalLimit));

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(accountNumberLongs);

    final String witCode = TestHelper.PERMITTED_WIT_CODES.get(5);

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG)))
        .thenReturn(
            Optional.of(
                TestHelper.buildSavingAccount(
                    ACCOUNT_NUMBER_LONG, new BigDecimal(AMOUNT_TWENTY_FIVE_POUND), witCode)));

    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            witCode,
            productInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRules))
        .thenReturn(true);

    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            accountBalanceTypeList,
            productInfo,
            true,
            accountWarningRestrictionFiltered,
            ACTIVITY_GROUP_CODES_PISP_ONLY,
            savingAccountAnnualWithdrawalLimit,
            false,
            REMAINING_DEPOSIT_LIMIT,
            null,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            witCode,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(
            ACCOUNT_NUMBER, FILTER_AVAILABLE_DEPOSIT_LIMIT, requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
  }

  @SuppressWarnings("PMD")
  @Test
  void getAccountDetailsShouldSucceedForAccountWithAccountWarningRestrictions() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier = INTSAV_PRODUCT_ID;

    final Set<Long> accountNumberLongs = Collections.singleton(ACCOUNT_NUMBER_LONG);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, productIdentifier, null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final List<AccountWarningRestrictionRule> accountWarningRestrictionRules =
        TestHelper.createAccountWarningRestrictionRule(ACCOUNT_NUMBER);
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(accountWarningRestrictionRules);

    final List<AccountBalanceType> accountBalanceTypeList =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(ACCOUNT_NUMBER)).thenReturn(accountBalanceTypeList);

    final ProductInfo productInfo =
        TestHelper.createProductInfoWithAnniversaryWithdrawalLimit(productIdentifier);
    when(productService.getProductInfo(productIdentifier, requestMetadata)).thenReturn(productInfo);

    final Reinvestment reinvestment = TestHelper.createReinvestment(false);
    when(reinvestmentCalculator.isReinvestmentPermitted(
            ACCOUNT_NUMBER,
            productIdentifier,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            requestMetadata))
        .thenReturn(false);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(ACCOUNT_NUMBER, productIdentifier);

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productInfo.getProductIdentifier(), productInfo);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesByAccountNumber.put(
        ACCOUNT_NUMBER, accountWarningRestrictionRules);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        ACCOUNT_NUMBER,
        Collections.singletonList(
            new AccountWarningRestrictionRule(
                ACCOUNT_NUMBER_LONG, "RESTYP", "RULE", "RESTYP_WEBTXT")));
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            accountWarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    final SavingAccountAnnualWithdrawalLimit savingAccountAnnualWithdrawalLimit =
        TestHelper.createSavingAccountAnnualWithdrawalLimit(ACCOUNT_NUMBER);
    when(savingAccountAnnualWithdrawalLimitRepository.findAllByAccountNumbers(accountNumberLongs))
        .thenReturn(Collections.singleton(savingAccountAnnualWithdrawalLimit));

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(accountNumberLongs);

    final String witCode = TestHelper.PERMITTED_WIT_CODES.get(6);

    SavingAccount savingAccount =
        TestHelper.buildSavingAccount(
            ACCOUNT_NUMBER_LONG, new BigDecimal(AMOUNT_TWENTY_FIVE_POUND), witCode);

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG)))
        .thenReturn(Optional.of(savingAccount));

    final AccountDetails expectedAccount = TestHelper.createAccountDetailsResponse(ACCOUNT_NUMBER);
    final Boolean interestOptionsPermitted = true;
    when(manageInterestCalculator.areInterestOptionsPermitted(
            ACCOUNT_NUMBER,
            savingAccount.getWitCode(),
            productInfo.getInterest().getWebAmendmentsPermitted(),
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            productInfo.getProductType(),
            accountDetails.getClosedDate(),
            accountWarningRestrictionRulesFilteredByAccountNumber.get(ACCOUNT_NUMBER)))
        .thenReturn(interestOptionsPermitted);

    when(accountDetailsMapper.accountSummaryResponseTypeToAccount(
            accountDetails,
            accountBalanceTypeList,
            productInfo,
            true,
            accountWarningRestrictionRulesFilteredByAccountNumber.get(ACCOUNT_NUMBER),
            ACTIVITY_GROUP_CODES_PISP_ONLY,
            savingAccountAnnualWithdrawalLimit,
            false,
            null,
            null,
            ACCOUNT_OPENED_DATE_TIME.toLocalDate(),
            reinvestment,
            interestOptionsPermitted,
            witCode,
            PARTY_ID_LONG,
            NOW))
        .thenReturn(expectedAccount);

    final AccountDetailsResponse actualAccountDetailsResponse =
        accountService.getAccountDetails(
            ACCOUNT_NUMBER, FILTER_AVAILABLE_DEPOSIT_LIMIT, requestMetadata);
    final AccountDetailsResponse expectedAccountDetailsResponse =
        AccountDetailsResponse.builder().account(expectedAccount).build();
    assertThat(actualAccountDetailsResponse, is(expectedAccountDetailsResponse));

    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
  }

  @Test
  void
      getAccountDetailsShouldThrowAccountResourceNotFoundExceptionWhenAccountIsNotFoundInDatabase() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    when(accountAccessValidator.validateOwnAccountAccess(
            ACCOUNT_NUMBER, requestMetadata, ACTIVITY_GROUP_CODES_PISP_ONLY, NOW))
        .thenReturn(ACTIVITY_GROUP_CODES_PISP_ONLY);

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, INTSAV_PRODUCT_ID, null);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    when(savingAccountRepository.findById((ACCOUNT_NUMBER_LONG))).thenReturn(Optional.empty());

    final AccountResourceNotFoundException thrown =
        assertThrows(
            AccountResourceNotFoundException.class,
            () ->
                accountService.getAccountDetails(
                    ACCOUNT_NUMBER, FILTER_AVAILABLE_DEPOSIT_LIMIT, requestMetadata));

    assertThat(thrown.getMessage(), is("Account 123 not found"));

    verify(savingAccountRepository).findById((ACCOUNT_NUMBER_LONG));
  }

  @Test
  void deleteAccountShouldNotWriteAWorkLogWhenAccountIsInBlacklist() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    when(accountServiceProperties.getAccountNumberBlacklist())
        .thenReturn(Collections.singletonList(ACCOUNT_NUMBER));

    accountService.deleteAccount(ACCOUNT_NUMBER, requestMetadata);

    verifyNoInteractions(workLogRepository);
  }

  @Test
  void deleteAccountShouldSaveAWorkLog() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    accountService.deleteAccount(ACCOUNT_NUMBER, requestMetadata);

    verify(workLogRepository)
        .save(
            WorkLog.builder()
                .accountNumber(ACCOUNT_NUMBER_LONG)
                .status(WorkLog.Status.PENDING)
                .createdBy(SACCSRV)
                .operation(Operation.DELETE_ACCOUNT)
                .message(
                    WorkLogRequest.builder()
                        .workLogPayload(DeleteAccountRequest.builder().build())
                        .metadata(requestMetadata)
                        .build())
                .build());
  }

  @Test
  void patchAccountDetailsShouldNotUpdateDatabaseIfAccountInBlackList() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, ACCOUNT_NAME, PARTY_ID);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(ACCOUNT_NAME).build();

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, INTSAV_PRODUCT_ID);

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    when(accountServiceProperties.getAccountNumberBlacklist())
        .thenReturn(Collections.singletonList(ACCOUNT_NUMBER));
    accountService.patchUpdateAccountDetails(ACCOUNT_NUMBER, updateAccountDetails, requestMetadata);

    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(savingsTransactionLogRepository);
  }

  @Test
  void patchAccountDetailsShouldThrowExceptionWhenAccountNotFound() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, ACCOUNT_NAME, PARTY_ID);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(ACCOUNT_NAME).build();
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.emptyList());

    final AccountServiceException thrown =
        assertThrows(
            AccountServiceException.class,
            () ->
                accountService.patchUpdateAccountDetails(
                    ACCOUNT_NUMBER, updateAccountDetails, requestMetadata));

    assertThat(
        thrown.getMessage(),
        is("Failed to find account " + ACCOUNT_NUMBER + " for request ID: " + requestId));
    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(savingsTransactionLogRepository);
  }

  @Test
  void patchAccountDetailsShouldSaveAWorkLogAndSavingsTransactionLog() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(ACCOUNT_NAME).build();

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, INTSAV_PRODUCT_ID);
    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    accountService.patchUpdateAccountDetails(ACCOUNT_NUMBER, updateAccountDetails, requestMetadata);

    verify(workLogRepository)
        .save(
            WorkLog.builder()
                .accountNumber(ACCOUNT_NUMBER_LONG)
                .status(WorkLog.Status.PENDING)
                .createdBy(SACCSRV)
                .operation(Operation.UPDATE_ACCOUNT_DET)
                .message(
                    WorkLogRequest.builder()
                        .workLogPayload(
                            UpdateAccountDetailsRequest.builder().accountName(ACCOUNT_NAME).build())
                        .metadata(requestMetadata)
                        .build())
                .build());

    verify(savingsTransactionLogRepository)
        .save(
            SavingsTransactionLogEntry.builder()
                .accountNumber(ACCOUNT_NUMBER_LONG)
                .startTime(NOW)
                .status(SavingsTransactionLogEntry.STATUS_ACCOUNT_NAME_CHANGE_COMPLETE)
                .accountName(ACCOUNT_NAME)
                .build());
  }

  @Test
  void patchAccountDetailsShouldThrowNoUpdatedAccountDetailsSpecifiedExceptionWhenNoneSent() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final UpdateAccountDetails updateAccountDetails = UpdateAccountDetails.builder().build();

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, INTSAV_PRODUCT_ID);

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final NoUpdatedAccountDetailsSpecifiedException thrown =
        assertThrows(
            NoUpdatedAccountDetailsSpecifiedException.class,
            () ->
                accountService.patchUpdateAccountDetails(
                    ACCOUNT_NUMBER, updateAccountDetails, requestMetadata));

    assertEquals("No updated account details specified", thrown.getMessage());
    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(savingsTransactionLogRepository);
  }

  @Test
  void patchAccountDetailsShouldThrowsConflictWhenAccountNameNotChanged() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, ACCOUNT_NAME, PARTY_ID);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(ACCOUNT_NAME).build();

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, INTSAV_PRODUCT_ID);

    accountDetails.setAccountName(ACCOUNT_NAME);

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final AccountNameConflictException thrown =
        assertThrows(
            AccountNameConflictException.class,
            () ->
                accountService.patchUpdateAccountDetails(
                    ACCOUNT_NUMBER, updateAccountDetails, requestMetadata));

    assertEquals("Account name has not changed", thrown.getMessage());
    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(savingsTransactionLogRepository);
  }

  @Test
  void patchAccountDetailsShouldThrowAccountAccessDeniedWhenAccountIsClosed() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, ACCOUNT_NAME, PARTY_ID);

    final UpdateAccountDetails updateAccountDetails =
        UpdateAccountDetails.builder().accountName(ACCOUNT_NAME).build();

    final SavingAccountDetails accountDetails =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, INTSAV_PRODUCT_ID);

    accountDetails.setClosedDate(ACCOUNT_CLOSED_DATE);

    when(savingAccountDetailsService.getSavingAccountDetails(ACCOUNT_NUMBER_LONG))
        .thenReturn(Collections.singletonList(accountDetails));

    final AccountAccessDeniedException thrown =
        assertThrows(
            AccountAccessDeniedException.class,
            () ->
                accountService.patchUpdateAccountDetails(
                    ACCOUNT_NUMBER, updateAccountDetails, requestMetadata));

    assertEquals("Account is closed", thrown.getMessage());
    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(savingsTransactionLogRepository);
  }
}
