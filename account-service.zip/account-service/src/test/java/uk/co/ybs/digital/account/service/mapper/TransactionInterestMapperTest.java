package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.adgcore.SavingTransaction;
import uk.co.ybs.digital.account.repository.adgcore.SavingTransactionRepository;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse.Amount;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse.Transaction;
import uk.co.ybs.digital.account.web.dto.AccountTransactionsResponse.TransactionCode;
import uk.co.ybs.digital.account.web.dto.Balance;

@ExtendWith(MockitoExtension.class)
class TransactionInterestMapperTest {
  private static final BigDecimal BLENDED_INTEREST_RATE = new BigDecimal("0.1555");
  private static final BigDecimal NEW_INTEREST_RATE = new BigDecimal("0.2000");
  private static final Instant TRANSACTION_DATE_INSTANT = Instant.parse("2017-12-20T01:00:00Z");

  private TransactionInterestMapper mapper;

  @Mock private SavingTransactionRepository transactionRepository;

  @BeforeEach
  void beforeEach() {
    mapper = new TransactionInterestMapper(transactionRepository);
  }

  @ParameterizedTest
  @MethodSource("interestRateArguments")
  void shouldMapCorrectInterestRateAndBlendedFlagToTransactions(
      final BigDecimal blendedRate,
      final BigDecimal newRate,
      final BigDecimal finalRate,
      final boolean blendedFlag) {
    when(transactionRepository.findById(1L))
        .thenReturn(buildSavingTransaction(1L, blendedRate, newRate));
    when(transactionRepository.findById(2L))
        .thenReturn(buildSavingTransaction(2L, blendedRate, newRate));

    final List<Transaction> transactionList =
        mapper.mapInterestRateForTransactions(buildTransactionsWithoutInterest());

    verify(transactionRepository).findById(1L);
    verify(transactionRepository).findById(2L);
    assertThat(transactionList, is(buildTransactionsWithInterest(finalRate, blendedFlag)));
  }

  @Test
  void shouldIgnoreAuthenticTransactionsNotInCore() {
    when(transactionRepository.findById(1L))
        .thenReturn(buildSavingTransaction(1L, BLENDED_INTEREST_RATE, NEW_INTEREST_RATE));
    when(transactionRepository.findById(2L)).thenReturn(Optional.empty());

    final List<Transaction> transactionList =
        mapper.mapInterestRateForTransactions(buildTransactionsWithoutInterest());

    verify(transactionRepository).findById(1L);
    verify(transactionRepository).findById(2L);
    assertThat(
        transactionList,
        is(
            Stream.of(buildTransactionWithInterest(1, BLENDED_INTEREST_RATE, true))
                .collect(Collectors.toList())));
  }

  static Stream<Arguments> interestRateArguments() {
    return Stream.of(
        // Blended and new interest rate are different
        Arguments.of(BLENDED_INTEREST_RATE, NEW_INTEREST_RATE, BLENDED_INTEREST_RATE, true),
        // No blended rate on the transaction
        Arguments.of(null, NEW_INTEREST_RATE, NEW_INTEREST_RATE, false),
        // Blended and new interest rate are the same
        Arguments.of(BLENDED_INTEREST_RATE, BLENDED_INTEREST_RATE, BLENDED_INTEREST_RATE, false));
  }

  private Optional<SavingTransaction> buildSavingTransaction(
      final long sysId, final BigDecimal blendedRate, final BigDecimal newRate) {
    return Optional.of(
        SavingTransaction.builder()
            .sysid(sysId)
            .blendedInterestRate(blendedRate)
            .newInterestRate(newRate)
            .build());
  }

  private List<Transaction> buildTransactionsWithoutInterest() {
    return Stream.of(buildTransaction(1), buildTransaction(2)).collect(Collectors.toList());
  }

  private List<Transaction> buildTransactionsWithInterest(
      final BigDecimal interest, final boolean blendedFlag) {
    return Stream.of(
            buildTransactionWithInterest(1, interest, blendedFlag),
            buildTransactionWithInterest(2, interest, blendedFlag))
        .collect(Collectors.toList());
  }

  private Transaction buildTransaction(final int transactionId) {
    return Transaction.builder()
        .transactionId(String.valueOf(transactionId))
        .accountNumber("12345678")
        .transactionReference("50000000032367")
        .creditDebitIndicator("Credit")
        .status("Booked")
        .bookingDateTime(TRANSACTION_DATE_INSTANT)
        .valueDateTime(TRANSACTION_DATE_INSTANT)
        .amount(Amount.builder().amount("100.00").currency("GBP").build())
        .transactionCode(TransactionCode.builder().code("0037").method("TFR").build())
        .transactionInformation("Direct Debit in")
        .balances(
            Stream.of(
                    Balance.builder()
                        .amount(new BigDecimal("130.00"))
                        .type("InterimAvailable")
                        .build(),
                    Balance.builder()
                        .amount(new BigDecimal("140.00"))
                        .type("InterimBooked")
                        .build())
                .collect(Collectors.toList()))
        .build();
  }

  private Transaction buildTransactionWithInterest(
      final int transactionId, final BigDecimal interest, final boolean blendedFlag) {
    return Transaction.builder()
        .transactionId(String.valueOf(transactionId))
        .accountNumber("12345678")
        .transactionReference("50000000032367")
        .creditDebitIndicator("Credit")
        .status("Booked")
        .bookingDateTime(TRANSACTION_DATE_INSTANT)
        .valueDateTime(TRANSACTION_DATE_INSTANT)
        .amount(Amount.builder().amount("100.00").currency("GBP").build())
        .transactionCode(TransactionCode.builder().code("0037").method("TFR").build())
        .transactionInformation("Direct Debit in")
        .balances(
            Stream.of(
                    Balance.builder()
                        .amount(new BigDecimal("130.00"))
                        .type("InterimAvailable")
                        .build(),
                    Balance.builder()
                        .amount(new BigDecimal("140.00"))
                        .type("InterimBooked")
                        .build())
                .collect(Collectors.toList()))
        .interestRate(String.valueOf(interest.setScale(3, RoundingMode.DOWN)))
        .blendedFlag(blendedFlag)
        .build();
  }
}
