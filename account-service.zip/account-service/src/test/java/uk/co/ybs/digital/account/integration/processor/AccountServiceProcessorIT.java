package uk.co.ybs.digital.account.integration.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static uk.co.ybs.digital.account.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.account.config.TestDatabaseConfiguration;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.integration.IntegrationTestConfig;
import uk.co.ybs.digital.account.model.core.AccountNumber;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.RestrictionType;
import uk.co.ybs.digital.account.model.core.SavingAccount;
import uk.co.ybs.digital.account.model.core.SavingAccountHistory;
import uk.co.ybs.digital.account.model.core.SavingProduct;
import uk.co.ybs.digital.account.model.core.WarningNote;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Operation;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogPayload;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogRequest;
import uk.co.ybs.digital.account.service.AccountProcessorService;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsUpdateFailureRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsUpdateSuccessRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditIsaDeclarationSubmissionFailureRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditIsaDeclarationSubmissionSuccessRequest;
import uk.co.ybs.digital.account.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@SpringBootTest(classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
@SuppressWarnings("Convert2MethodRef")
public class AccountServiceProcessorIT {

  private static final String ACCOUNT_NUMBER = "1234567890";
  private static final String ACCOUNT_NAME = "Nickname";
  private static final Long ACCOUNT_NUMBER_LONG = 1234567890L;
  private static final Long SAVING_PRODUCT_SYSID = 1L;
  private static final String AUDIT_SUCCESS_URL = "/audit/account/isa-declaration/success";

  private static final String AUDIT_UPDATE_ACCOUNT_SUCCESS_URL = "/audit/account/update/success";

  private static final String AUDIT_UPDATE_ACCOUNT_FAILURE_URL = "/audit/account/update/failure";

  private static final String AUDIT_FAILURE_URL = "/audit/account/isa-declaration/failure";
  private static final String CREATED_AT = "PROSRV";
  private static final String NOTES = "some notes";
  private static final String CREATED_BY = "0000123456";

  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String PARTY_ID = "1234567890";
  private static final String BRAND_CODE = "YBS";
  private static final InetSocketAddress HOST = InetSocketAddress.createUnresolved("host", 443);
  private static final UUID REQUEST_ID = UUID.fromString("3cfa397f-ff5d-4252-b8f0-69daac23fba4");
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  private static final String SAVINGS_APP = "SAPP";
  private static final String ABC_RESTRICTION_TYPE_CODE = "ABC";

  @Autowired private AccountProcessorService accountProcessorService;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  @Autowired private TransactionTemplate transactionTemplate;
  @Autowired private TestEntityManager coreTestEntityManager;
  @Autowired private TestEntityManager copyTestEntityManager;
  @Autowired private TestEntityManager adgCoreTestEntityManager;
  @Autowired private TestEntityManager digitalAccountTestEntityManager;
  @Autowired private Clock clock;
  @Autowired private ObjectMapper objectMapper;

  private MockWebServer mockAuditService;
  private LocalDateTime now;

  private static WorkLog createWorkLog(
      final WorkLog.Operation operation, final WorkLogPayload workLogPayload) {
    final RequestMetadata requestMetadata =
        RequestMetadata.builder()
            .requestId(REQUEST_ID)
            .ipAddress(IP_ADDRESS)
            .forwardingAuth(FORWARDING_AUTH)
            .partyId(PARTY_ID)
            .brandCode(BRAND_CODE)
            .host(HOST)
            .build();

    return WorkLog.builder()
        .accountNumber(ACCOUNT_NUMBER_LONG)
        .status(WorkLog.Status.PENDING)
        .operation(operation)
        .message(
            WorkLogRequest.builder()
                .workLogPayload(workLogPayload)
                .metadata(requestMetadata)
                .build())
        .build();
  }

  @BeforeEach
  void setup() throws Exception {
    mockAuditService = new MockWebServer();
    mockAuditService.start(auditTestPort);
    now = LocalDateTime.now(clock);
  }

  @AfterEach
  void cleanup() throws IOException {
    mockAuditService.shutdown();
    tearDownDb();
  }

  @Test
  void accountProcessorShouldDoNothingWhenNoRequestsPending() {
    accountProcessorService.process();
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void
      accountProcessorShouldSuccessfullyProcessSubmitIsaDeclarationSuccessWhenAccountWarningsAreFound(
          final Boolean auditServiceShouldFail) throws IOException {
    setUpAccountNumberAdgCore();
    final AccountNumber accountNumber = setUpAccountNumberCore();
    final RestrictionType restrictionType =
        setUpRestrictionTypeCore(RestrictionType.NO_SUBSCRIPTIONS);
    final AccountWarning accountWarning =
        setUpCoreAccountWarningThatHasNotEnded(accountNumber, restrictionType);
    final WarningNote warningNote = setUpWarningNote(accountWarning);

    final Long workLogId =
        setUpWorkLogRecord(Operation.SUBMIT_ISA_DEC, TestHelper.buildSubmitIsaDeclarationRequest());

    mockAuditServiceResponse(auditServiceShouldFail);

    accountProcessorService.process();

    assertAll(
        () -> assertWorkLog(workLogId, WorkLog.Status.COMPLETE),
        () -> assertAccountWarningEnded(accountWarning.getSysId()),
        () -> assertWarningNoteEnded(warningNote.getSysId()),
        () -> assertAuditIsaDeclarationSubmissionSuccess());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void
      accountProcessorShouldSuccessfullyProcessSubmitIsaDeclarationSuccessWhenAccountWarningsAreFoundWithNoNotes(
          final Boolean auditServiceShouldFail) throws IOException {
    setUpAccountNumberAdgCore();
    final AccountNumber accountNumber = setUpAccountNumberCore();
    final RestrictionType restrictionType =
        setUpRestrictionTypeCore(RestrictionType.NO_SUBSCRIPTIONS);
    final AccountWarning accountWarning =
        setUpCoreAccountWarningThatHasNotEnded(accountNumber, restrictionType);

    final Long workLogId =
        setUpWorkLogRecord(Operation.SUBMIT_ISA_DEC, TestHelper.buildSubmitIsaDeclarationRequest());

    mockAuditServiceResponse(auditServiceShouldFail);

    accountProcessorService.process();

    assertAll(
        () -> assertWorkLog(workLogId, WorkLog.Status.COMPLETE),
        () -> assertAccountWarningEnded(accountWarning.getSysId()),
        () -> assertAuditIsaDeclarationSubmissionSuccess());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void
      accountProcessorShouldAuditFailureWhenProcessingSubmitIsaDeclarationWhenAccountWarningsAreNotFound(
          final Boolean auditServiceShouldFail) throws IOException {
    setUpAccountNumberAdgCore();
    final AccountNumber accountNumber = setUpAccountNumberCore();
    setUpRestrictionTypeAdgCore(RestrictionType.NO_SUBSCRIPTIONS);
    final RestrictionType restrictionType =
        setUpRestrictionTypeCore(RestrictionType.NO_SUBSCRIPTIONS);
    setUpAccountWarningThatHasAlreadyEnded(accountNumber, restrictionType);

    final Long workLogId =
        setUpWorkLogRecord(Operation.SUBMIT_ISA_DEC, TestHelper.buildSubmitIsaDeclarationRequest());

    mockAuditServiceResponse(auditServiceShouldFail);

    accountProcessorService.process();

    assertAll(
        () -> assertWorkLog(workLogId, WorkLog.Status.FAILED),
        () -> assertAuditIsaDeclarationSubmissionFailure());
  }

  @ParameterizedTest
  @ValueSource(booleans = {true, false})
  void accountProcessorShouldSuccessfullyProcessUpdateAccountDetails(
      final Boolean auditServiceShouldFail) throws IOException {
    setUpAccountNumberAdgCore();

    final AccountNumber accountNumber = setUpAccountNumberCore();
    final SavingAccount savingAccount = setUpSavingAccountCore();
    final SavingAccountHistory savingAccountHistory = setUpSavingAccountHistory();
    savingAccount.setAccountName(ACCOUNT_NAME);
    savingAccountHistory.setAccountName(ACCOUNT_NAME);
    final Long sysId = savingAccountHistory.getSavingAccountSysId() + 1L;
    final RestrictionType restrictionType =
        setUpRestrictionTypeCore(RestrictionType.NO_SUBSCRIPTIONS);
    setUpAccountWarningThatHasAlreadyEnded(accountNumber, restrictionType);

    final Long workLogId =
        setUpWorkLogRecord(
            Operation.UPDATE_ACCOUNT_DET, TestHelper.buildUpdateAccountDetailsRequest());

    mockAuditServiceResponse(auditServiceShouldFail);

    accountProcessorService.process();

    assertAll(
        () -> assertWorkLog(workLogId, WorkLog.Status.COMPLETE),
        () -> assertAccountDetailsUpdated(ACCOUNT_NAME, ACCOUNT_NUMBER_LONG, sysId),
        () -> assertAuditUpdateAccountDetailsSuccess());
  }

  @Test
  void accountProcessorShouldFailAndAuditFailureWhenUpdateAccountDetailsDoesNotFindAccount()
      throws IOException {
    final Long workLogId =
        setUpWorkLogRecord(
            Operation.UPDATE_ACCOUNT_DET, TestHelper.buildUpdateAccountDetailsRequest());
    mockAuditServiceResponse(false);
    accountProcessorService.process();
    assertAll(
        () -> assertWorkLog(workLogId, WorkLog.Status.FAILED),
        () -> assertAuditUpdateAccountDetailsFailure());
  }

  @Test
  void accountProcessorShouldSuccessfullyProcessAccountWarning() {
    setUpAccountNumberAdgCore();
    setUpAccountNumberCore();
    setUpRestrictionTypeAdgCore(ABC_RESTRICTION_TYPE_CODE);
    setUpRestrictionTypeCore(ABC_RESTRICTION_TYPE_CODE);

    final Long workLogId =
        setUpWorkLogRecord(Operation.INS_ACCOUNT_WARNING, TestHelper.buildAccountWarningRequest());

    accountProcessorService.process();

    assertAll(
        () -> assertWorkLog(workLogId, WorkLog.Status.COMPLETE),
        () ->
            assertAccountWarningCreated(
                allOf(
                    hasProperty("endDate", nullValue()),
                    hasProperty("endedDate", nullValue()),
                    hasProperty("endedBy", nullValue()),
                    hasProperty("endedAt", nullValue()))),
        () ->
            assertWarningNoteCreated(
                allOf(
                    hasProperty("endDate", nullValue()),
                    hasProperty("endedDate", nullValue()),
                    hasProperty("endedBy", nullValue()),
                    hasProperty("endedAt", nullValue()))));
  }

  @Test
  void accountProcessorShouldSuccessfullyProcessDeleteAccountWarning() throws IOException {
    final LocalDateTime testStartTime = LocalDateTime.now();
    setUpAccountNumberAdgCore();
    final AccountNumber accountNumber = setUpAccountNumberCore();
    setUpRestrictionTypeAdgCore(ABC_RESTRICTION_TYPE_CODE);
    final RestrictionType restrictionType = setUpRestrictionTypeCore(ABC_RESTRICTION_TYPE_CODE);
    setUpCoreAccountWarningThatHasNotEnded(accountNumber, restrictionType);

    final uk.co.ybs.digital.account.model.copy.AccountNumber accountNumberCopy =
        setUpAccountNumberCopy();
    final uk.co.ybs.digital.account.model.copy.RestrictionType restrictionTypeCopy =
        setUpRestrictionTypeCopy(ABC_RESTRICTION_TYPE_CODE);
    setUpCopyAccountWarningThatHasNotEnded(accountNumberCopy, restrictionTypeCopy);
    final Long workLogId =
        setUpWorkLogRecord(
            Operation.DEL_ACCOUNT_WARNING, TestHelper.buildDeleteAccountWarningRequest());

    accountProcessorService.process();

    assertAll(
        () -> assertWorkLog(workLogId, WorkLog.Status.COMPLETE),
        () ->
            assertAccountWarningCreated(
                allOf(
                    hasProperty(
                        "endedDate",
                        greaterThanOrEqualTo(testStartTime.truncatedTo(ChronoUnit.SECONDS))),
                    hasProperty("endDate", is(LocalDate.now())),
                    hasProperty("endedBy", is("TEST")),
                    hasProperty("endedAt", is("TEST")))));
  }

  @Test
  void accountProcessorShouldFailWorkLogForDeleteAccountWarningWhenRestrictionTypeNotFound() {

    setUpAccountNumberAdgCore();
    final AccountNumber accountNumber = setUpAccountNumberCore();

    final Long workLogId =
        setUpWorkLogRecord(
            Operation.DEL_ACCOUNT_WARNING, TestHelper.buildDeleteAccountWarningRequest());
    accountProcessorService.process();
    assertAll(() -> assertWorkLog(workLogId, WorkLog.Status.FAILED));
  }

  @Test
  void accountProcessorShouldFailWorkLogForDeleteAccountWarningWhenAccountNotFound() {

    final Long workLogId =
        setUpWorkLogRecord(
            Operation.DEL_ACCOUNT_WARNING, TestHelper.buildDeleteAccountWarningRequest());
    accountProcessorService.process();
    assertAll(() -> assertWorkLog(workLogId, WorkLog.Status.FAILED));
  }

  @Test
  void accountProcessorShouldSuccessfullyProcessDeleteAccount() {

    setUpAccountNumberAdgCore();
    setUpAccountNumberCore();
    setUpSavingAccountCore();

    final Long workLogId =
        setUpWorkLogRecord(Operation.DELETE_ACCOUNT, TestHelper.buildDeleteAccountRequest());
    accountProcessorService.process();
    assertAll(
        () -> assertWorkLog(workLogId, WorkLog.Status.COMPLETE), () -> assertDeleteAccountEntry());
  }

  @Test
  void accountProcessorShouldFailWorkLogWhenAccountNotFound() {

    final Long workLogId =
        setUpWorkLogRecord(Operation.DELETE_ACCOUNT, TestHelper.buildDeleteAccountRequest());
    accountProcessorService.process();
    assertAll(() -> assertWorkLog(workLogId, WorkLog.Status.FAILED));
  }

  private void tearDownDb() {
    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager digitalAccountEntityManager =
              digitalAccountTestEntityManager.getEntityManager();
          digitalAccountEntityManager.createQuery("delete from WorkLog").executeUpdate();
        });

    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager coreEntityManager = coreTestEntityManager.getEntityManager();
          coreEntityManager.createQuery("delete from WarningNote").executeUpdate();
          coreEntityManager.createQuery("delete from AccountWarning").executeUpdate();
          coreEntityManager.createQuery("delete from RestrictionType").executeUpdate();
          coreEntityManager.createQuery("delete from SavingAccount").executeUpdate();
          coreEntityManager.createQuery("delete from AccountNumber").executeUpdate();
          coreEntityManager.createQuery("delete from SavingProduct").executeUpdate();
          coreEntityManager.createQuery("delete from SavingAccountHistory").executeUpdate();
        });

    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager copyEntityManager = copyTestEntityManager.getEntityManager();
          copyEntityManager.createQuery("delete from AccountWarning").executeUpdate();
          copyEntityManager.createQuery("delete from RestrictionType").executeUpdate();
          copyEntityManager.createQuery("delete from AccountNumber").executeUpdate();
          copyEntityManager.createQuery("delete from SavingProduct").executeUpdate();
        });

    transactionTemplate.executeWithoutResult(
        status -> {
          final EntityManager adgCoreEntityManager = adgCoreTestEntityManager.getEntityManager();
          adgCoreEntityManager.createQuery("delete from AccountWarning").executeUpdate();
          adgCoreEntityManager.createQuery("delete from RestrictionType").executeUpdate();
          adgCoreEntityManager.createQuery("delete from AccountNumber").executeUpdate();
          adgCoreEntityManager.createQuery("delete from SavingProduct").executeUpdate();
        });
  }

  // ASSERT HELPERS
  private void assertWorkLog(final Long workLogId, final WorkLog.Status status) {
    final WorkLog workLog =
        transactionTemplate.execute(
            s -> digitalAccountTestEntityManager.find(WorkLog.class, workLogId));
    assertThat(workLog, is(notNullValue()));
    assertThat(workLog.getStatus(), is(status));
  }

  private void assertAccountWarningEnded(final Long warningId) {
    final AccountWarning warning =
        transactionTemplate.execute(
            s -> coreTestEntityManager.find(AccountWarning.class, warningId));
    assertThat(warning, is(notNullValue()));
    assertThat(warning.getEndDate(), is(notNullValue()));
    assertThat(warning.getEndedAt(), is(notNullValue()));
    assertThat(warning.getEndedBy(), is(notNullValue()));
    assertThat(warning.getEndedDate(), is(notNullValue()));
  }

  private void assertAccountDetailsUpdated(
      final String accountName, final Long accountNumber, final Long sysID) {
    final SavingAccount savingAccount =
        transactionTemplate.execute(
            s -> coreTestEntityManager.find(SavingAccount.class, accountNumber));
    final SavingAccountHistory savingAccountHistory =
        transactionTemplate.execute(
            s -> coreTestEntityManager.find(SavingAccountHistory.class, sysID));
    assertThat(savingAccount.getAccountName(), is(accountName));
    assertThat(savingAccountHistory.getAccountName(), is(accountName));
  }

  @SuppressWarnings("unchecked")
  private void assertAccountWarningCreated(final Matcher<?>... expected) {

    final List<?> actual =
        transactionTemplate.execute(
            transactionStatus -> {
              final Query query =
                  coreTestEntityManager
                      .getEntityManager()
                      .createQuery("select e from AccountWarning e");
              return query.getResultList();
            });

    assertThat(actual, containsInAnyOrder((Matcher<Object>[]) expected));
  }

  @SuppressWarnings("unchecked")
  private void assertWarningNoteCreated(final Matcher<?>... expected) {

    final List<?> actual =
        transactionTemplate.execute(
            transactionStatus -> {
              final Query query =
                  coreTestEntityManager
                      .getEntityManager()
                      .createQuery("select e from WarningNote e");
              return query.getResultList();
            });

    assertThat(actual, containsInAnyOrder((Matcher<Object>[]) expected));
  }

  private void assertDeleteAccountEntry() {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final Query query =
              coreTestEntityManager.getEntityManager().createQuery("from SavingAccount");
          @SuppressWarnings("unchecked")
          final List<SavingAccount> actual = query.getResultList();
          assertThat(actual.get(0).getEndedDate(), is(notNullValue()));
          assertThat(actual.get(0).getClosedDate(), is(notNullValue()));
          assertThat(actual.get(0).getEndedBy(), is(SAVINGS_APP));
          assertThat(actual.get(0).getEndedAt(), is(SAVINGS_APP));
        });
  }

  private void assertWarningNoteEnded(final Long noteId) {
    final WarningNote note =
        transactionTemplate.execute(s -> coreTestEntityManager.find(WarningNote.class, noteId));
    assertThat(note, is(notNullValue()));
    assertThat(note.getEndDate(), is(notNullValue()));
    assertThat(note.getEndedAt(), is(notNullValue()));
    assertThat(note.getEndedBy(), is(notNullValue()));
    assertThat(note.getEndedDate(), is(notNullValue()));
  }

  private void assertAuditIsaDeclarationSubmissionSuccess()
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest(AUDIT_SUCCESS_URL);
    final AuditIsaDeclarationSubmissionSuccessRequest actualRequest =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditIsaDeclarationSubmissionSuccessRequest.class);

    final AuditIsaDeclarationSubmissionSuccessRequest expectedRequest =
        AuditIsaDeclarationSubmissionSuccessRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountInformation(
                AuditIsaDeclarationSubmissionSuccessRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();

    assertThat(expectedRequest, is(actualRequest));
  }

  private void assertAuditIsaDeclarationSubmissionFailure()
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest(AUDIT_FAILURE_URL);
    final AuditIsaDeclarationSubmissionFailureRequest actualRequest =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditIsaDeclarationSubmissionFailureRequest.class);

    final AuditIsaDeclarationSubmissionFailureRequest expectedRequest =
        AuditIsaDeclarationSubmissionFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .message(
                AccountRequestProcessingException.Reason.ISA_DECLARATION_WARNINGS_NOT_FOUND
                    .getDescription())
            .accountInformation(
                AuditIsaDeclarationSubmissionFailureRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();

    assertThat(expectedRequest, is(actualRequest));
  }

  private void assertAuditUpdateAccountDetailsSuccess()
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest(AUDIT_UPDATE_ACCOUNT_SUCCESS_URL);
    final AuditAccountDetailsUpdateSuccessRequest actualRequest =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditAccountDetailsUpdateSuccessRequest.class);

    final AuditAccountDetailsUpdateSuccessRequest expectedRequest =
        AuditAccountDetailsUpdateSuccessRequest.builder()
            .accountName(ACCOUNT_NAME)
            .ipAddress(IP_ADDRESS)
            .accountInformation(
                AuditAccountDetailsUpdateSuccessRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();

    assertThat(expectedRequest, is(actualRequest));
  }

  private void assertAuditUpdateAccountDetailsFailure()
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = assertAuditRequest(AUDIT_UPDATE_ACCOUNT_FAILURE_URL);
    final AuditAccountDetailsUpdateFailureRequest actualRequest =
        objectMapper.readValue(
            request.getBody().readUtf8(), AuditAccountDetailsUpdateFailureRequest.class);

    final AuditAccountDetailsUpdateFailureRequest expectedRequest =
        AuditAccountDetailsUpdateFailureRequest.builder()
            .ipAddress(IP_ADDRESS)
            .accountName(ACCOUNT_NAME)
            .message("Failed to find account 1234567890 in the database")
            .accountInformation(
                AuditAccountDetailsUpdateFailureRequest.AccountInformation.builder()
                    .accountNumber(ACCOUNT_NUMBER)
                    .build())
            .build();

    assertThat(expectedRequest, is(actualRequest));
  }

  private RecordedRequest assertAuditRequest(final String path) throws InterruptedException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is("POST"));
    assertThat(request.getPath(), is(path));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());
    return request;
  }

  // BUILDERS
  private RestrictionType setUpRestrictionTypeCore(final String restrictionTypeCode) {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                RestrictionType.builder()
                    .sysId(1L)
                    .code(restrictionTypeCode)
                    .startDate(now.plusSeconds(-1))
                    .build()));
  }

  private uk.co.ybs.digital.account.model.copy.RestrictionType setUpRestrictionTypeCopy(
      final String restrictionTypeCode) {
    return transactionTemplate.execute(
        status ->
            copyTestEntityManager.persistAndFlush(
                uk.co.ybs.digital.account.model.copy.RestrictionType.builder()
                    .sysId(1L)
                    .code(restrictionTypeCode)
                    .startDate(now.plusSeconds(-1))
                    .build()));
  }

  private void setUpRestrictionTypeAdgCore(final String restrictionTypeCode) {
    transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                uk.co.ybs.digital.account.model.adgcore.RestrictionType.builder()
                    .sysId(1L)
                    .code(restrictionTypeCode)
                    .description("Test ABC")
                    .startDate(now.plusSeconds(-1))
                    .build()));
  }

  private WarningNote setUpWarningNote(final AccountWarning accountWarning) {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                WarningNote.builder()
                    .accountWarningSysId(accountWarning.getSysId())
                    .startDate(now.plusSeconds(-1))
                    .createdAt(CREATED_AT)
                    .createdDate(now)
                    .createdBy(CREATED_BY)
                    .notes(NOTES)
                    .build()));
  }

  private AccountWarning setUpCoreAccountWarningThatHasNotEnded(
      final AccountNumber accountNumber, final RestrictionType restrictionType) {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                AccountWarning.builder()
                    .accountNumber(accountNumber)
                    .restrictionType(restrictionType)
                    .startDate(now.plusSeconds(-1))
                    .createdAt(SAVINGS_APP)
                    .createdBy(SAVINGS_APP)
                    .createdDate(now.plusSeconds(-1))
                    .build()));
  }

  private uk.co.ybs.digital.account.model.copy.AccountWarning
      setUpCopyAccountWarningThatHasNotEnded(
          final uk.co.ybs.digital.account.model.copy.AccountNumber accountNumber,
          final uk.co.ybs.digital.account.model.copy.RestrictionType restrictionType) {
    return transactionTemplate.execute(
        status ->
            copyTestEntityManager.persistAndFlush(
                uk.co.ybs.digital.account.model.copy.AccountWarning.builder()
                    .accountNumber(accountNumber)
                    .restrictionType(restrictionType)
                    .startDate(now.plusSeconds(-1))
                    .createdAt(SAVINGS_APP)
                    .createdBy(SAVINGS_APP)
                    .createdDate(now.plusSeconds(-1))
                    .build()));
  }

  private void setUpAccountWarningThatHasAlreadyEnded(
      final AccountNumber accountNumber, final RestrictionType restrictionType) {
    transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                AccountWarning.builder()
                    .accountNumber(accountNumber)
                    .restrictionType(restrictionType)
                    .startDate(now.plusDays(-2))
                    .createdAt(SAVINGS_APP)
                    .createdBy(SAVINGS_APP)
                    .createdDate(now.plusSeconds(-2))
                    .endDate(now.plusDays(-1).toLocalDate())
                    .build()));
  }

  private SavingAccount setUpSavingAccountCore() {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                SavingAccount.builder().accountNumber(ACCOUNT_NUMBER_LONG).build()));
  }

  private SavingAccountHistory setUpSavingAccountHistory() {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                SavingAccountHistory.builder().accountNumber(ACCOUNT_NUMBER_LONG).build()));
  }

  private AccountNumber setUpAccountNumberCore() {
    final SavingProduct savingProduct = setUpSavingProductCore();

    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                AccountNumber.builder()
                    .accountNumber(ACCOUNT_NUMBER_LONG)
                    .tableId(AccountNumber.TABLE_ID_SAVACC)
                    .savingProductSysId(savingProduct.getSysid())
                    .build()));
  }

  private uk.co.ybs.digital.account.model.copy.AccountNumber setUpAccountNumberCopy() {
    final uk.co.ybs.digital.account.model.copy.SavingProduct savingProduct =
        setUpSavingProductCopy();

    return transactionTemplate.execute(
        status ->
            copyTestEntityManager.persistAndFlush(
                uk.co.ybs.digital.account.model.copy.AccountNumber.builder()
                    .accountNumber(ACCOUNT_NUMBER_LONG)
                    .tableId(uk.co.ybs.digital.account.model.copy.AccountNumber.TABLE_ID_SAVACC)
                    .savingProductSysId(savingProduct.getSysid())
                    .build()));
  }

  private void setUpAccountNumberAdgCore() {
    final uk.co.ybs.digital.account.model.adgcore.SavingProduct savingProduct =
        setUpSavingProductAdgCore();

    transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                uk.co.ybs.digital.account.model.adgcore.AccountNumber.builder()
                    .accountNumber(ACCOUNT_NUMBER_LONG)
                    .tableId(AccountNumber.TABLE_ID_SAVACC)
                    .savingProductSysId(savingProduct.getSysid())
                    .build()));
  }

  private SavingProduct setUpSavingProductCore() {
    return transactionTemplate.execute(
        status ->
            coreTestEntityManager.persistAndFlush(
                SavingProduct.builder().sysid(SAVING_PRODUCT_SYSID).brandCode(BRAND_CODE).build()));
  }

  private uk.co.ybs.digital.account.model.copy.SavingProduct setUpSavingProductCopy() {
    return transactionTemplate.execute(
        status ->
            copyTestEntityManager.persistAndFlush(
                uk.co.ybs.digital.account.model.copy.SavingProduct.builder()
                    .sysid(SAVING_PRODUCT_SYSID)
                    .brandCode(BRAND_CODE)
                    .build()));
  }

  private uk.co.ybs.digital.account.model.adgcore.SavingProduct setUpSavingProductAdgCore() {
    return transactionTemplate.execute(
        status ->
            adgCoreTestEntityManager.persistAndFlush(
                uk.co.ybs.digital.account.model.adgcore.SavingProduct.builder()
                    .sysid(SAVING_PRODUCT_SYSID)
                    .brandCode(BRAND_CODE)
                    .build()));
  }

  private Long setUpWorkLogRecord(
      final WorkLog.Operation operation, final WorkLogPayload workLogPayload) {
    return transactionTemplate.execute(
        status ->
            digitalAccountTestEntityManager.persistAndGetId(
                createWorkLog(operation, workLogPayload), Long.class));
  }

  private void mockAuditServiceResponse(final Boolean shouldFail) throws IOException {
    if (shouldFail) {
      mockAuditService.enqueue(
          new MockResponse()
              .setResponseCode(HttpStatus.UNAUTHORIZED.value())
              .setBody(
                  readClassPathResource(
                      "api/auditService/response/errorResponseInvalidSignature.json")));
      return;
    }
    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));
  }
}
