package uk.co.ybs.digital.account.integration;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import java.security.Key;
import java.time.Duration;
import java.time.Instant;
import java.time.Period;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import lombok.experimental.UtilityClass;

@UtilityClass
public class IntegrationTestJwtFactory {
  public static final String CLAIM_SCOPE = "scope";
  public static final String CLAIM_BRAND_CODE = "brand_code";
  public static final String CLAIM_PARTY_ID = "party_id";
  public static final String CLAIM_AUD = "aud";
  public static final String CLAIM_SUB = "sub";
  public static final String CLAIM_SUBTYPE = "sub_type";
  public static final String CLAIM_SID = "sid";
  public static final String CLAIM_CHANNEL = "channel";

  public static final String AUDIENCE = "DIGITAL_API";
  public static final String CHANNEL = "SAPP";
  public static final String SUBTYPE_CUSTOMER = "customer";
  public static final String SUBTYPE_SYSTEM = "system";
  private static final Object SUB = "987654321";

  static String createJwt(
      final String partyId, final String scope, final String brandCode, final Key signingKey) {
    return createJwt(
        claimsMap(SUBTYPE_CUSTOMER, partyId, scope, brandCode, UUID.randomUUID().toString()),
        signingKey);
  }

  public static Map<String, Object> invalidCustomerClaimsMap(
      final String partyId, final String scope, final String brandCode) {
    return claimsMap(SUBTYPE_CUSTOMER, partyId, scope, brandCode, null);
  }

  public static Map<String, Object> customerClaimsMap(
      final String partyId, final String scope, final String brandCode) {
    return claimsMap(SUBTYPE_CUSTOMER, partyId, scope, brandCode, UUID.randomUUID().toString());
  }

  static Map<String, Object> customerClaimsMap(final String scope, final String brandCode) {
    return claimsMap(SUBTYPE_CUSTOMER, null, scope, brandCode, UUID.randomUUID().toString());
  }

  public static Map<String, Object> systemClaimsMap(
      final String partyId, final String scope, final String brandCode) {
    return claimsMap(SUBTYPE_SYSTEM, partyId, scope, brandCode, null);
  }

  public static Map<String, Object> claimsMap(
      final String subType,
      final String partyId,
      final String scope,
      final String brandCode,
      final String sessionId) {
    final Map<String, Object> map = new HashMap<>();
    map.put(CLAIM_SUB, SUB);
    map.put(CLAIM_SUBTYPE, subType);
    map.put(CLAIM_AUD, AUDIENCE);
    map.put(CLAIM_BRAND_CODE, brandCode);
    map.put(CLAIM_PARTY_ID, partyId);
    map.put(CLAIM_SCOPE, scope);
    map.put(CLAIM_SID, sessionId);
    map.put(CLAIM_CHANNEL, CHANNEL);

    return map;
  }

  public static String createJwt(final Map<String, Object> claims, final Key signingKey) {
    return Jwts.builder()
        .setHeaderParam("kid", "OPAa9voYNByjE_lpbtHanOFKiV4")
        .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(10))))
        .setIssuedAt(Date.from(Instant.now().minus(Period.ofDays(6))))
        .setId(UUID.randomUUID().toString())
        .addClaims(claims)
        .signWith(SignatureAlgorithm.RS256, signingKey)
        .compact();
  }
}
