package uk.co.ybs.digital.account.repository.digitalaccount;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import uk.co.ybs.digital.account.config.JpaAuditingConfig;
import uk.co.ybs.digital.account.config.TestClockConfig;
import uk.co.ybs.digital.account.model.digitalaccount.SubmitIsaDeclarationRequest;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Status;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogRequest;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;
import uk.co.ybs.digital.account.utils.TestHelper;

@YbsDataJpaTest
@Import({JpaAuditingConfig.class, TestClockConfig.class})
public class WorkLogRepositoryTest {

  private static final Long ACCOUNT_NUMBER = 2001L;

  private static final LocalDateTime CREATED_DATE = LocalDateTime.parse("2020-05-26T14:45:01");

  @Autowired private WorkLogRepository testSubject;

  @Autowired private TestEntityManager digitalAccountTestEntityManager;

  @Test
  void shouldPersistWorkLogAndFindById() {
    final WorkLog workLog = buildWorkLog();
    final Long sysId = digitalAccountTestEntityManager.persistAndFlush(workLog).getSysId();
    digitalAccountTestEntityManager.clear();

    final Optional<WorkLog> found = testSubject.findById(sysId);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(workLog));
  }

  @Test
  void findRequestsInStateShouldReturnEmptyListIfNoRequestsInDesiredState() {
    final WorkLog workLog = buildWorkLog(Status.COMPLETE);
    digitalAccountTestEntityManager.persistAndFlush(workLog);
    digitalAccountTestEntityManager.clear();

    final WorkLog anotherWorkLog = buildWorkLog(WorkLog.Status.FAILED);
    digitalAccountTestEntityManager.persistAndFlush(anotherWorkLog);
    digitalAccountTestEntityManager.clear();

    final List<WorkLog> found = testSubject.findRequestsInState(WorkLog.Status.PENDING);

    assertThat(found.isEmpty(), is(true));
  }

  @Test
  void findRequestsInStateShouldReturnPendingRequestsOrderedByDate() {
    final WorkLog firstWorkLog = buildWorkLog().toBuilder().createdDate(CREATED_DATE).build();
    digitalAccountTestEntityManager.persistAndFlush(firstWorkLog);
    digitalAccountTestEntityManager.clear();

    final WorkLog secondWorkLog =
        buildWorkLog().toBuilder().createdDate(CREATED_DATE.plusHours(1)).build();
    digitalAccountTestEntityManager.persistAndFlush(secondWorkLog);
    digitalAccountTestEntityManager.clear();

    final List<WorkLog> found = testSubject.findRequestsInState(WorkLog.Status.PENDING);

    assertThat(found.isEmpty(), is(not(true)));
    assertThat(
        found, contains(samePropertyValuesAs(firstWorkLog), samePropertyValuesAs(secondWorkLog)));
  }

  @Test
  void findCountOfRequestsInStateShouldReturnCountsForState() {
    final WorkLog pendingWorkLog = buildWorkLog(Status.PENDING);
    final WorkLog otherPendingWorkLog = buildWorkLog(Status.PENDING);
    final WorkLog failedWorkLog = buildWorkLog(Status.FAILED);
    final WorkLog completedWorkLog = buildWorkLog(Status.COMPLETE);
    final WorkLog otherCompletedWorkLog = buildWorkLog(Status.COMPLETE);
    final WorkLog anotherCompletedWorkLog = buildWorkLog(Status.COMPLETE);

    digitalAccountTestEntityManager.persist(pendingWorkLog);
    digitalAccountTestEntityManager.persist(otherPendingWorkLog);
    digitalAccountTestEntityManager.persist(failedWorkLog);
    digitalAccountTestEntityManager.persist(completedWorkLog);
    digitalAccountTestEntityManager.persist(otherCompletedWorkLog);
    digitalAccountTestEntityManager.persist(anotherCompletedWorkLog);
    digitalAccountTestEntityManager.flush();
    digitalAccountTestEntityManager.clear();

    final List<ImmutablePair<WorkLog.Status, Long>> statuses =
        testSubject.findCountOfRequestsInState();

    assertThat(
        statuses,
        containsInAnyOrder(
            new ImmutablePair<>(WorkLog.Status.PENDING, 2L),
            new ImmutablePair<>(WorkLog.Status.FAILED, 1L),
            new ImmutablePair<>(WorkLog.Status.COMPLETE, 3L)));
  }

  @Test
  void findCountOfRequestsShouldReturnEmptyIfNoRecords() {
    final List<ImmutablePair<WorkLog.Status, Long>> statuses =
        testSubject.findCountOfRequestsInState();

    assertThat(statuses, is(empty()));
  }

  @Test
  void findRequestsByAccountNumberAndStateAndOperationShouldReturnEmptyListIfNoStatusMatched() {
    final WorkLog workLog = buildWorkLog(Status.COMPLETE, WorkLog.Operation.INS_ACCOUNT_WARNING);
    final WorkLog anotherWorkLog =
        buildWorkLog(WorkLog.Status.FAILED, WorkLog.Operation.INS_ACCOUNT_WARNING);
    digitalAccountTestEntityManager.persist(workLog);
    digitalAccountTestEntityManager.persist(anotherWorkLog);
    digitalAccountTestEntityManager.flush();
    digitalAccountTestEntityManager.clear();

    final List<WorkLog> found =
        testSubject.findRequestsByAccountNumberAndStateAndOperation(
            WorkLog.Status.PENDING, WorkLog.Operation.INS_ACCOUNT_WARNING, ACCOUNT_NUMBER);

    assertThat(found.isEmpty(), is(true));
  }

  @Test
  void findRequestsByAccountNumberAndStateAndOperationShouldReturnEmptyListIfNoOperationMatched() {
    final WorkLog workLog1 = buildWorkLog(Status.PENDING, WorkLog.Operation.SUBMIT_ISA_DEC);
    final WorkLog workLog2 = buildWorkLog(Status.PENDING, WorkLog.Operation.DEL_ACCOUNT_WARNING);
    final WorkLog workLog3 = buildWorkLog(Status.PENDING, WorkLog.Operation.DELETE_ACCOUNT);
    final WorkLog workLog4 = buildWorkLog(Status.PENDING, WorkLog.Operation.UPDATE_ACCOUNT_DET);
    digitalAccountTestEntityManager.persist(workLog1);
    digitalAccountTestEntityManager.persist(workLog2);
    digitalAccountTestEntityManager.persist(workLog3);
    digitalAccountTestEntityManager.persist(workLog4);
    digitalAccountTestEntityManager.flush();
    digitalAccountTestEntityManager.clear();

    final List<WorkLog> found =
        testSubject.findRequestsByAccountNumberAndStateAndOperation(
            WorkLog.Status.PENDING, WorkLog.Operation.INS_ACCOUNT_WARNING, ACCOUNT_NUMBER);

    assertThat(found.isEmpty(), is(true));
  }

  @Test
  void findRequestsByAccountNumberAndStateAndOperationShouldReturnEmptyListIfAccNumberNotMatched() {
    final WorkLog workLog = buildWorkLog(Status.PENDING, WorkLog.Operation.INS_ACCOUNT_WARNING, 1L);
    digitalAccountTestEntityManager.persistAndFlush(workLog);
    digitalAccountTestEntityManager.clear();

    final List<WorkLog> found =
        testSubject.findRequestsByAccountNumberAndStateAndOperation(
            WorkLog.Status.PENDING, WorkLog.Operation.INS_ACCOUNT_WARNING, ACCOUNT_NUMBER);

    assertThat(found.isEmpty(), is(true));
  }

  @Test
  void findRequestsByAccountNumberAndStateAndOperation() {
    final WorkLog workLog1 = buildWorkLog(Status.PENDING, WorkLog.Operation.INS_ACCOUNT_WARNING);
    digitalAccountTestEntityManager.persistAndFlush(workLog1);
    digitalAccountTestEntityManager.clear();

    final List<WorkLog> found =
        testSubject.findRequestsByAccountNumberAndStateAndOperation(
            WorkLog.Status.PENDING, WorkLog.Operation.INS_ACCOUNT_WARNING, ACCOUNT_NUMBER);

    assertThat(found.size(), is(1));
    assertThat(found.get(0), is(workLog1));
  }

  private static WorkLog buildWorkLog() {
    return buildWorkLog(Status.PENDING);
  }

  private static WorkLog buildWorkLog(final WorkLog.Status status) {
    return buildWorkLog(status, WorkLog.Operation.SUBMIT_ISA_DEC, ACCOUNT_NUMBER);
  }

  private static WorkLog buildWorkLog(
      final WorkLog.Status status, final WorkLog.Operation operation) {
    return buildWorkLog(status, operation, ACCOUNT_NUMBER);
  }

  private static WorkLog buildWorkLog(
      final WorkLog.Status status, final WorkLog.Operation operation, final long accountNumber) {
    return WorkLog.builder()
        .accountNumber(accountNumber)
        .status(status)
        .operation(operation)
        .message(
            WorkLogRequest.builder()
                .workLogPayload(SubmitIsaDeclarationRequest.builder().build())
                .metadata(TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234))
                .build())
        .build();
  }
}
