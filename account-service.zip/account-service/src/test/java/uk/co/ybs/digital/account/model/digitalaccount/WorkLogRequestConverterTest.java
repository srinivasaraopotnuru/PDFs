package uk.co.ybs.digital.account.model.digitalaccount;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class WorkLogRequestConverterTest {

  private static final String PARTY_ID = "123456";
  private static final String BRAND_YBS = "YBS";
  private static final UUID REQUEST_ID = UUID.fromString("8e112ed4-0374-47d0-aa82-427049d2dab4");

  private static final String TEST_RESULT_ISA_DECLARATION_STRING =
      "{\"workLogPayload\":{\"type\":\"SubmitIsaDeclaration\"},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}";
  private static final String TEST_RESULT_ACCOUNT_WARNING_STRING =
      "{\"workLogPayload\":{\"type\":\"AccountWarning\",\"warningType\":\"ABC\",\"notes\":\"notes\",\"createdBy\":\"PROSRV\",\"createdAt\":\"SAPP\",\"endedAt\":null,\"endedBy\":null},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}";
  private static final String TEST_RESULT_ACCOUNT_WARNING_NULL_OPTIONALS_STRING =
      "{\"workLogPayload\":{\"type\":\"AccountWarning\",\"warningType\":\"ABC\",\"notes\":null,\"createdBy\":null,\"createdAt\":null,\"endedAt\":null,\"endedBy\":null},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}";

  private static final String TEST_RESULT_UPDATE_ACCOUNT_DETAILS_STRING =
      "{\"workLogPayload\":{\"type\":\"UpdateAccountDetails\",\"accountName\":\"test\"},\"metadata\":{\"requestId\":\"8e112ed4-0374-47d0-aa82-427049d2dab4\",\"host\":\"accountservice.ybs.co.uk:443\",\"partyId\":\"123456\",\"brandCode\":\"YBS\",\"forwardingAuth\":\"<jwt>\",\"ipAddress\":\"12.66.53.145\"}}";

  @InjectMocks private WorkLogRequestConverter testSubject;

  @ParameterizedTest
  @MethodSource("requestArguments")
  void shouldCreateJsonStringFromWorkLogRequestWithPayload(
      final WorkLogPayload request, final String testString) {
    final WorkLogRequest input = createWorkLogRequestWithPayload(request);

    final String result = testSubject.convertToDatabaseColumn(input);

    assertThat(result, samePropertyValuesAs(testString));
  }

  @ParameterizedTest
  @MethodSource("requestArguments")
  void shouldReturnValidWorkLogRequestWithPayload(
      final WorkLogPayload request, final String testString) {
    final WorkLogRequest result = testSubject.convertToEntityAttribute(testString);

    final WorkLogRequest expected = createWorkLogRequestWithPayload(request);
    assertThat(result, samePropertyValuesAs(expected));
  }

  @Test
  void shouldThrowErrorIfValueIsNotValidSerializedWorkLogChangeRequest() {
    assertThrows(
        WorkLogRequestConverter.DataConversionException.class,
        () -> testSubject.convertToEntityAttribute("{\"invalid\":\"entity\"}"));
  }

  private static WorkLogRequest createWorkLogRequestWithPayload(final WorkLogPayload payload) {
    return WorkLogRequest.builder()
        .workLogPayload(payload)
        .metadata(createRequestMetadata())
        .build();
  }

  private static SubmitIsaDeclarationRequest createSubmitISADec() {
    return SubmitIsaDeclarationRequest.builder().build();
  }

  private static UpdateAccountDetailsRequest updateAccountDetailsRequest() {
    return UpdateAccountDetailsRequest.builder().accountName("test").build();
  }

  private static AccountWarningRequest createAccountWarningRequest() {
    return AccountWarningRequest.builder()
        .warningType("ABC")
        .notes("notes")
        .createdBy("PROSRV")
        .createdAt("SAPP")
        .build();
  }

  private static AccountWarningRequest createAccountWarningNullOptionalsRequest() {
    return AccountWarningRequest.builder().warningType("ABC").build();
  }

  private static RequestMetadata createRequestMetadata() {
    return RequestMetadata.builder()
        .host(InetSocketAddress.createUnresolved("accountservice.ybs.co.uk", 443))
        .requestId(REQUEST_ID)
        .brandCode(BRAND_YBS)
        .partyId(PARTY_ID)
        .forwardingAuth("<jwt>")
        .ipAddress("12.66.53.145")
        .build();
  }

  private static Stream<Arguments> requestArguments() {
    return Stream.of(
        Arguments.of(createSubmitISADec(), TEST_RESULT_ISA_DECLARATION_STRING),
        Arguments.of(updateAccountDetailsRequest(), TEST_RESULT_UPDATE_ACCOUNT_DETAILS_STRING),
        Arguments.of(createAccountWarningRequest(), TEST_RESULT_ACCOUNT_WARNING_STRING),
        Arguments.of(
            createAccountWarningNullOptionalsRequest(),
            TEST_RESULT_ACCOUNT_WARNING_NULL_OPTIONALS_STRING));
  }
}
