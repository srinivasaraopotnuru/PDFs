package uk.co.ybs.digital.account.service.processor;

import static org.mockito.Mockito.verify;

import java.time.LocalDateTime;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.model.core.SavingAccount;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class ResolvedDeleteAccountRequestTest {
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final Long ACCOUNT_NUMBER = 1L;
  @Mock DeleteAccountProcessor deleteAccountProcessor;
  private ResolvedDeleteAccountRequest testSubject;
  private DeleteAccountRequestArguments arguments;
  private SavingAccount savingAccount;

  @BeforeEach
  void setUp() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234);

    arguments =
        DeleteAccountRequestArguments.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .requestMetadata(requestMetadata)
            .processTime(PROCESS_TIME)
            .build();

    savingAccount = SavingAccount.builder().accountNumber(ACCOUNT_NUMBER).build();

    testSubject =
        new ResolvedDeleteAccountRequest(arguments, deleteAccountProcessor, savingAccount);
  }

  @Test
  void executeShouldCallProcessor() {
    testSubject.execute();
    verify(deleteAccountProcessor).execute(arguments, savingAccount);
  }
}
