package uk.co.ybs.digital.account.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.mockito.hamcrest.MockitoHamcrest.argThat;
import static uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup.ACTIVITY_GROUP_CODE_AHLDRS;
import static uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup.ACTIVITY_GROUP_CODE_AISP;
import static uk.co.ybs.digital.account.model.adgcore.ActivityTypeGroup.ACTIVITY_GROUP_CODE_PISP;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_NUMBER;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_NUMBER_LONG;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_OPENED_DATE_TIME;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_OPENED_DATE_TIME_2;
import static uk.co.ybs.digital.account.utils.TestHelper.ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES;
import static uk.co.ybs.digital.account.utils.TestHelper.ACTIVITY_GROUP_CODES_ACCOUNT_LIST;
import static uk.co.ybs.digital.account.utils.TestHelper.AMOUNT_ONE_POUND;
import static uk.co.ybs.digital.account.utils.TestHelper.AMOUNT_TWO_POUND;
import static uk.co.ybs.digital.account.utils.TestHelper.BRAND_YBS;
import static uk.co.ybs.digital.account.utils.TestHelper.CAPITAL_AVAILABLE_BALANCE_TYPE;
import static uk.co.ybs.digital.account.utils.TestHelper.CAPITAL_LEDGER_BALANCE_TYPE;
import static uk.co.ybs.digital.account.utils.TestHelper.CLOCK;
import static uk.co.ybs.digital.account.utils.TestHelper.INTSAV2_PRODUCT_ID;
import static uk.co.ybs.digital.account.utils.TestHelper.INTSAV3_PRODUCT_ID;
import static uk.co.ybs.digital.account.utils.TestHelper.INTSAV_PRODUCT_ID;
import static uk.co.ybs.digital.account.utils.TestHelper.ISA;
import static uk.co.ybs.digital.account.utils.TestHelper.NOW;
import static uk.co.ybs.digital.account.utils.TestHelper.ONE_DAY_AGO;
import static uk.co.ybs.digital.account.utils.TestHelper.PARTY_ID;
import static uk.co.ybs.digital.account.utils.TestHelper.PARTY_ID_LONG;
import static uk.co.ybs.digital.account.utils.TestHelper.PRODUCT_IDENTIFIER;
import static uk.co.ybs.digital.account.utils.TestHelper.SACCSRV;
import static uk.co.ybs.digital.account.utils.TestHelper.SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION;
import static uk.co.ybs.digital.account.utils.TestHelper.SERVICE_SCHEMA_USER;
import static uk.co.ybs.digital.account.utils.TestHelper.TWO_DAYS_AGO;
import static uk.co.ybs.digital.account.utils.TestHelper.WARNING_CODE;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AccountResourceNotFoundException;
import uk.co.ybs.digital.account.exception.AccountServiceException;
import uk.co.ybs.digital.account.exception.AccountWarningsResourceNotFoundException;
import uk.co.ybs.digital.account.exception.WorkLogConflictException;
import uk.co.ybs.digital.account.model.AccountSummaryMappingBundle;
import uk.co.ybs.digital.account.model.adgcore.Account;
import uk.co.ybs.digital.account.model.adgcore.AccountActivityGroup;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.AccountWarning;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.LinkedPartyDetails;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.adgcore.SavingAccountAnnualWithdrawalLimit;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.model.adgcore.db.SavingAccountDetails;
import uk.co.ybs.digital.account.model.digitalaccount.AccountWarningRequest;
import uk.co.ybs.digital.account.model.digitalaccount.DeleteAccountWarningRequest;
import uk.co.ybs.digital.account.model.digitalaccount.SubmitIsaDeclarationRequest;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLog.Operation;
import uk.co.ybs.digital.account.model.digitalaccount.WorkLogRequest;
import uk.co.ybs.digital.account.model.frontoffice.SavingsTransactionLogEntry;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.adgcore.AccountWarningRepository;
import uk.co.ybs.digital.account.repository.adgcore.ActivityPlayerRepository;
import uk.co.ybs.digital.account.repository.adgcore.PartyRepository;
import uk.co.ybs.digital.account.repository.adgcore.RestrictionTypeRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingAccountAnnualWithdrawalLimitRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingAccountRepository;
import uk.co.ybs.digital.account.repository.adgcore.SavingProductRepository;
import uk.co.ybs.digital.account.repository.digitalaccount.WorkLogRepository;
import uk.co.ybs.digital.account.repository.frontoffice.SavingsTransactionLogRepository;
import uk.co.ybs.digital.account.service.authentic.AccountBalanceType;
import uk.co.ybs.digital.account.service.authentic.AccountNotFoundException;
import uk.co.ybs.digital.account.service.authentic.AuthenticService;
import uk.co.ybs.digital.account.service.mapper.AccountDetailsMapper;
import uk.co.ybs.digital.account.service.mapper.GroupedAccountListMapper;
import uk.co.ybs.digital.account.service.product.ProductService;
import uk.co.ybs.digital.account.service.product.dto.ProductInfo;
import uk.co.ybs.digital.account.service.utilities.AccountAccessValidator;
import uk.co.ybs.digital.account.service.utilities.AccountWarningFilter;
import uk.co.ybs.digital.account.service.utilities.AvailableDepositLimitCalculator;
import uk.co.ybs.digital.account.service.utilities.ManageInterestCalculator;
import uk.co.ybs.digital.account.service.utilities.ReinvestmentCalculator;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.AccountWarningSummary;
import uk.co.ybs.digital.account.web.dto.AccountWarnings;
import uk.co.ybs.digital.account.web.dto.AccountWarningsResponse;
import uk.co.ybs.digital.account.web.dto.Balance;
import uk.co.ybs.digital.account.web.dto.GroupedAccountListResponse;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;
import uk.co.ybs.digital.account.web.dto.Warning;
import uk.co.ybs.digital.account.web.dto.WarningCode;

@ExtendWith(MockitoExtension.class)
class AccountServiceTest {

  public static final String RESTRICTION_TYPE_RULE_CODE = "RULE";
  public static final String RESTRICTION_TYPE_CODE = "RESTYP";
  public static final String RESTRICTION_TYPE_RULE_CHAR_VALUE = "RESTYP_WEBTXT";
  public static final String WEBREC = "WEBREC";
  private AccountService accountService;
  private UUID requestId;
  @Mock private AccountAccessValidator accountAccessValidator;
  @Mock private AvailableDepositLimitCalculator availableDepositLimitCalculator;
  @Mock private AccountDetailsMapper accountDetailsMapper;
  @Mock private GroupedAccountListMapper accountListMapper;
  @Mock private ActivityPlayerRepository activityPlayerRepository;
  @Mock private AccountWarningRepository accountWarningRepository;
  @Mock private RestrictionTypeRepository restrictionTypeRepository;

  @Mock private AuthenticService authenticService;

  @Mock
  private SavingAccountAnnualWithdrawalLimitRepository savingAccountAnnualWithdrawalLimitRepository;

  @Mock private SavingsTransactionLogRepository savingsTransactionLogRepository;
  @Mock private AccountWarningFilter accountWarningFilter;
  @Mock private ProductService productService;
  @Mock private WorkLogRepository workLogRepository;
  @Mock private AccountServiceProperties accountServiceProperties;
  @Mock private SavingProductRepository savingProductRepository;
  @Mock private AccountNumberRepository accountNumberRepository;
  @Mock private SavingAccountRepository savingAccountRepository;
  @Mock private SavingAccountDetailsService savingAccountDetailsService;
  @Mock private SavingAccountDetailsListService customersSavingsAccountService;
  @Mock private PartyRepository partyRepository;
  @Mock private ReinvestmentCalculator reinvestmentCalculator;
  @Mock private ManageInterestCalculator manageInterestCalculator;

  @SuppressWarnings("PMD.AvoidDuplicateLiterals")
  private static Stream<Arguments> warningArgs() {
    return Stream.of(
        Arguments.of(WARNING_CODE, PARTY_ID, SERVICE_SCHEMA_USER, "notes"),
        Arguments.of(WARNING_CODE, PARTY_ID, SERVICE_SCHEMA_USER, null),
        Arguments.of(WARNING_CODE, null, SERVICE_SCHEMA_USER, "notes"),
        Arguments.of(WARNING_CODE, PARTY_ID, null, "notes"),
        Arguments.of(WARNING_CODE, null, null, "notes"),
        Arguments.of(WARNING_CODE, null, null, null));
  }

  @BeforeEach
  void setUp() {
    requestId = UUID.randomUUID();
    accountService =
        new AccountService(
            accountAccessValidator,
            productService,
            accountServiceProperties,
            authenticService,
            savingProductRepository,
            activityPlayerRepository,
            accountWarningRepository,
            restrictionTypeRepository,
            savingAccountRepository,
            savingAccountAnnualWithdrawalLimitRepository,
            savingsTransactionLogRepository,
            workLogRepository,
            accountNumberRepository,
            accountDetailsMapper,
            accountListMapper,
            availableDepositLimitCalculator,
            accountWarningFilter,
            CLOCK,
            savingAccountDetailsService,
            customersSavingsAccountService,
            partyRepository,
            reinvestmentCalculator,
            manageInterestCalculator);
  }

  @Test
  @SuppressWarnings("PMD.ExcessiveMethodLength")
  void getAccountGroupsShouldSucceed() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier1 = INTSAV_PRODUCT_ID;
    final String productIdentifier2 = INTSAV2_PRODUCT_ID;
    final long accountNumber1 = 1111111111L;
    final long accountNumber2 = 2222222222L;

    final SavingAccountDetails accountDetails1 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber1), productIdentifier1);
    final SavingAccountDetails accountDetails2 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber2), productIdentifier2);
    final List<SavingAccountDetails> accountDetailsFound =
        Arrays.asList(accountDetails1, accountDetails2);

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(Arrays.asList(accountNumber1, accountNumber2));

    when(savingAccountDetailsService.getSavingAccountDetails(
            Arrays.asList(accountNumber1, accountNumber2)))
        .thenReturn(accountDetailsFound);

    final ImmutableSet<Long> accountNumberLongs = ImmutableSet.of(accountNumber1, accountNumber2);
    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG, ACTIVITY_GROUP_CODES_ACCOUNT_LIST, accountNumberLongs, NOW))
        .thenReturn(
            Arrays.asList(
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AISP),
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AHLDRS),
                new AccountActivityGroup(accountNumber2, ACTIVITY_GROUP_CODE_AISP)));

    final ProductInfo product1 = TestHelper.createProductInfo(productIdentifier1);
    final ProductInfo product2 = TestHelper.createProductInfo(productIdentifier2);
    when(productService.searchProductInfo(
            ImmutableSet.of(productIdentifier1, productIdentifier2), requestMetadata))
        .thenReturn(Arrays.asList(product1, product2));

    when(savingAccountRepository.findAllById(accountNumberLongs))
        .thenReturn(TestHelper.buildSavingAccountsList(accountNumber1, accountNumber2));

    final List<AccountBalanceType> balance1 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    final List<AccountBalanceType> balance2 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_TWO_POUND);
    when(authenticService.getBalance(String.valueOf(accountNumber1))).thenReturn(balance1);
    when(authenticService.getBalance(String.valueOf(accountNumber2))).thenReturn(balance2);

    final List<AccountWarningRestrictionRule> account1RestrictionRules =
        TestHelper.createAccountWarningRestrictionRule(String.valueOf(accountNumber1));
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(account1RestrictionRules);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber1), accountDetails1.getProductIdentifier());
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber2), accountDetails2.getProductIdentifier());

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productIdentifier1, product1);
    productInfoByProductIdentifier.put(productIdentifier2, product2);

    final Map<String, List<AccountWarningRestrictionRule>>
        account1WarningRestrictionRulesByAccountNumber = new LinkedHashMap<>();
    account1WarningRestrictionRulesByAccountNumber.put(
        String.valueOf(accountNumber1), account1RestrictionRules);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        String.valueOf(accountNumber1),
        Collections.singletonList(
            new AccountWarningRestrictionRule(
                Long.parseLong(String.valueOf(accountNumber1)),
                RESTRICTION_TYPE_CODE,
                RESTRICTION_TYPE_RULE_CODE,
                RESTRICTION_TYPE_RULE_CHAR_VALUE)));
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            account1WarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final GroupedAccountListResponse mapped =
        GroupedAccountListResponse.builder()
            .owned(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber1),
                                balance1,
                                ACCOUNT_OPENED_DATE_TIME.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_ONE_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .other(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber2),
                                balance2,
                                ACCOUNT_OPENED_DATE_TIME_2.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_TWO_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .build();

    when(accountListMapper.mapToAccountGroups(
            Arrays.asList(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails1)
                    .balances(balance1)
                    .productInfo(product1)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(
                        accountWarningRestrictionRulesFilteredByAccountNumber.get(
                            String.valueOf(accountNumber1)))
                    .activityGroupCodes(
                        ImmutableSet.of(ACTIVITY_GROUP_CODE_AISP, ACTIVITY_GROUP_CODE_AHLDRS))
                    .anniversaryWithdrawalLimit(null)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
                    .build(),
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails2)
                    .balances(balance2)
                    .productInfo(product2)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(Collections.emptyList())
                    .activityGroupCodes(Collections.singleton(ACTIVITY_GROUP_CODE_AISP))
                    .anniversaryWithdrawalLimit(null)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME_2.toLocalDate())
                    .closed(false)
                    .build()),
            false))
        .thenReturn(mapped);
    verifyNoInteractions(savingAccountRepository);
    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, false);
    assertThat(actual, is(mapped));
  }

  @Test
  @SuppressWarnings("PMD.ExcessiveMethodLength")
  void getAccountGroupsShouldSucceedWithClosedAccounts() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier1 = INTSAV_PRODUCT_ID;
    final String productIdentifier2 = INTSAV2_PRODUCT_ID;
    final long accountNumber1 = 1111111111L;
    final long accountNumber2 = 2222222222L;

    final SavingAccountDetails accountDetails1 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber1), productIdentifier1);
    final SavingAccountDetails accountDetails2 =
        TestHelper.createSavingAccountDetailsWithClosedDate(
            String.valueOf(accountNumber2), productIdentifier2);
    final List<SavingAccountDetails> accountDetailsFound =
        Arrays.asList(accountDetails1, accountDetails2);

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, true))
        .thenReturn(Arrays.asList(accountNumber1, accountNumber2));

    when(savingAccountDetailsService.getSavingAccountDetails(
            Arrays.asList(accountNumber1, accountNumber2)))
        .thenReturn(accountDetailsFound);

    final ImmutableSet<Long> accountNumberLongs = ImmutableSet.of(accountNumber1, accountNumber2);
    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG, ACTIVITY_GROUP_CODES_ACCOUNT_LIST, accountNumberLongs, NOW))
        .thenReturn(
            Arrays.asList(
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AISP),
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AHLDRS),
                new AccountActivityGroup(accountNumber2, ACTIVITY_GROUP_CODE_AISP)));

    final ProductInfo product1 = TestHelper.createProductInfo(productIdentifier1);
    final ProductInfo product2 = TestHelper.createProductInfo(productIdentifier2);
    when(productService.searchProductInfo(
            ImmutableSet.of(productIdentifier1, productIdentifier2), requestMetadata))
        .thenReturn(Arrays.asList(product1, product2));

    when(savingAccountRepository.findAllById(accountNumberLongs))
        .thenReturn(
            ImmutableList.of(
                TestHelper.buildSavingAccount(
                    accountNumber1,
                    ACCOUNT_OPENED_DATE_TIME,
                    TestHelper.PERMITTED_WIT_CODES.get(0)),
                TestHelper.buildSavingAccount(
                    accountNumber2,
                    new BigDecimal(AMOUNT_TWO_POUND),
                    ACCOUNT_OPENED_DATE_TIME_2,
                    TestHelper.PERMITTED_WIT_CODES.get(1))));

    final List<AccountBalanceType> balance1 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    final List<AccountBalanceType> balance2 =
        TestHelper.createAccountBalanceTypeListForClosedAccounts(AMOUNT_TWO_POUND);
    when(authenticService.getBalance(String.valueOf(accountNumber1))).thenReturn(balance1);

    verify(authenticService, never()).getBalance(String.valueOf(accountNumber2));

    final List<AccountWarningRestrictionRule> account1RestrictionRules =
        TestHelper.createAccountWarningRestrictionRule(String.valueOf(accountNumber1));
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(account1RestrictionRules);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber1), accountDetails1.getProductIdentifier());
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber2), accountDetails2.getProductIdentifier());

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productIdentifier1, product1);
    productInfoByProductIdentifier.put(productIdentifier2, product2);

    final Map<String, List<AccountWarningRestrictionRule>>
        account1WarningRestrictionRulesByAccountNumber = new LinkedHashMap<>();
    account1WarningRestrictionRulesByAccountNumber.put(
        String.valueOf(accountNumber1), account1RestrictionRules);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        String.valueOf(accountNumber1),
        Collections.singletonList(
            new AccountWarningRestrictionRule(
                Long.parseLong(String.valueOf(accountNumber1)),
                RESTRICTION_TYPE_CODE,
                RESTRICTION_TYPE_RULE_CODE,
                RESTRICTION_TYPE_RULE_CHAR_VALUE)));
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            account1WarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final GroupedAccountListResponse mapped =
        GroupedAccountListResponse.builder()
            .owned(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber1),
                                balance1,
                                ACCOUNT_OPENED_DATE_TIME.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_ONE_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .closed(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber2),
                                balance2,
                                ACCOUNT_OPENED_DATE_TIME_2.toLocalDate())))
                    .balances(
                        Arrays.asList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_TWO_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build(),
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_TWO_POUND))
                                .type(CAPITAL_LEDGER_BALANCE_TYPE)
                                .build()))
                    .build())
            .build();

    when(accountListMapper.mapToAccountGroups(
            Arrays.asList(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails1)
                    .balances(balance1)
                    .productInfo(product1)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(
                        accountWarningRestrictionRulesFilteredByAccountNumber.get(
                            String.valueOf(accountNumber1)))
                    .activityGroupCodes(
                        ImmutableSet.of(ACTIVITY_GROUP_CODE_AISP, ACTIVITY_GROUP_CODE_AHLDRS))
                    .anniversaryWithdrawalLimit(null)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
                    .build(),
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails2)
                    .balances(balance2)
                    .productInfo(product2)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(Collections.emptyList())
                    .activityGroupCodes(Collections.singleton(ACTIVITY_GROUP_CODE_AISP))
                    .anniversaryWithdrawalLimit(null)
                    .closed(true)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME_2.toLocalDate())
                    .build()),
            true))
        .thenReturn(mapped);
    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, true);
    assertThat(actual, is(mapped));
  }

  @Test
  void getAccountGroupsShouldFilterAccountsWithoutAnAispRelationship() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier1 = INTSAV_PRODUCT_ID;
    final long accountNumber1 = 1111111111L;
    final long accountNumber2 = 2222222222L;
    final long accountNumber3 = 3333333333L;

    final SavingAccountDetails accountDetails1 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber1), productIdentifier1);
    final SavingAccountDetails accountDetails2 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber2), INTSAV2_PRODUCT_ID);
    final SavingAccountDetails accountDetails3 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber3), INTSAV3_PRODUCT_ID);
    final List<SavingAccountDetails> accountDetailsFound =
        Arrays.asList(accountDetails1, accountDetails2, accountDetails3);

    final List<Long> accountNumberList =
        accountDetailsFound.stream()
            .map(SavingAccountDetails::getAccountNumber)
            .collect(Collectors.toList());

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(accountNumberList);

    when(savingAccountDetailsService.getSavingAccountDetails(accountNumberList))
        .thenReturn(accountDetailsFound);

    final ImmutableSet<Long> accountNumberLongs =
        ImmutableSet.of(accountNumber1, accountNumber2, accountNumber3);
    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG, ACTIVITY_GROUP_CODES_ACCOUNT_LIST, accountNumberLongs, NOW))
        .thenReturn(
            Arrays.asList(
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AISP),
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AHLDRS),
                // Accounts to be filtered: Both non-AISP relationships for account 2 and none at
                // all for account 3
                new AccountActivityGroup(accountNumber2, ACTIVITY_GROUP_CODE_PISP),
                new AccountActivityGroup(accountNumber2, ACTIVITY_GROUP_CODE_AHLDRS)));

    final ProductInfo product1 = TestHelper.createProductInfo(productIdentifier1);
    when(productService.searchProductInfo(ImmutableSet.of(productIdentifier1), requestMetadata))
        .thenReturn(Collections.singletonList(product1));

    when(savingAccountRepository.findAllById(ImmutableSet.of(accountNumber1)))
        .thenReturn(
            ImmutableList.of(
                TestHelper.buildSavingAccount(
                    accountNumber1,
                    ACCOUNT_OPENED_DATE_TIME,
                    TestHelper.PERMITTED_WIT_CODES.get(2))));

    final List<AccountBalanceType> balance1 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(String.valueOf(accountNumber1))).thenReturn(balance1);

    final ImmutableSet<Long> accountNumberLongsFiltered = ImmutableSet.of(accountNumber1);
    final List<AccountWarningRestrictionRule> account1RestrictionRules =
        TestHelper.createAccountWarningRestrictionRule(String.valueOf(accountNumber1));
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongsFiltered, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(account1RestrictionRules);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber1), accountDetails1.getProductIdentifier());

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productIdentifier1, product1);

    final Map<String, List<AccountWarningRestrictionRule>>
        account1WarningRestrictionRulesByAccountNumber = new LinkedHashMap<>();
    account1WarningRestrictionRulesByAccountNumber.put(
        String.valueOf(accountNumber1), account1RestrictionRules);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        String.valueOf(accountNumber1),
        Collections.singletonList(
            new AccountWarningRestrictionRule(
                Long.parseLong(String.valueOf(accountNumber1)),
                RESTRICTION_TYPE_CODE,
                RESTRICTION_TYPE_RULE_CODE,
                RESTRICTION_TYPE_RULE_CHAR_VALUE)));
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            account1WarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongsFiltered,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final GroupedAccountListResponse mapped =
        GroupedAccountListResponse.builder()
            .owned(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber1),
                                balance1,
                                ACCOUNT_OPENED_DATE_TIME.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_ONE_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .build();

    when(accountListMapper.mapToAccountGroups(
            Collections.singletonList(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails1)
                    .balances(balance1)
                    .productInfo(product1)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(
                        accountWarningRestrictionRulesFilteredByAccountNumber.get(
                            String.valueOf(accountNumber1)))
                    .activityGroupCodes(
                        ImmutableSet.of(ACTIVITY_GROUP_CODE_AISP, ACTIVITY_GROUP_CODE_AHLDRS))
                    .anniversaryWithdrawalLimit(null)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
                    .build()),
            false))
        .thenReturn(mapped);
    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, false);
    assertThat(actual, is(mapped));
  }

  @Test
  @SuppressWarnings("PMD.ExcessiveMethodLength")
  void getAccountGroupsShouldFilterAccountsWithGetBalanceException() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier1 = INTSAV_PRODUCT_ID;
    final String productIdentifier2 = INTSAV2_PRODUCT_ID;
    final String productIdentifier3 = INTSAV3_PRODUCT_ID;
    final long accountNumber1 = 1111111111L;
    final long accountNumber2 = 2222222222L;
    final long accountNumber3 = 3333333333L;

    final SavingAccountDetails accountDetails1 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber1), productIdentifier1);
    final SavingAccountDetails accountDetails2 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber2), productIdentifier2);
    final SavingAccountDetails accountDetails3 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber3), productIdentifier3);
    final List<SavingAccountDetails> accountDetailsFound =
        Arrays.asList(accountDetails1, accountDetails2, accountDetails3);

    final List<Long> accountNumberList =
        accountDetailsFound.stream()
            .map(SavingAccountDetails::getAccountNumber)
            .collect(Collectors.toList());

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(accountNumberList);

    when(savingAccountDetailsService.getSavingAccountDetails(accountNumberList))
        .thenReturn(accountDetailsFound);

    final ImmutableSet<Long> accountNumberLongs =
        ImmutableSet.of(accountNumber1, accountNumber2, accountNumber3);
    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG, ACTIVITY_GROUP_CODES_ACCOUNT_LIST, accountNumberLongs, NOW))
        .thenReturn(
            Arrays.asList(
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AISP),
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AHLDRS),
                new AccountActivityGroup(accountNumber2, ACTIVITY_GROUP_CODE_AISP),
                new AccountActivityGroup(accountNumber3, ACTIVITY_GROUP_CODE_AISP)));

    final ProductInfo product1 = TestHelper.createProductInfo(productIdentifier1);
    final ProductInfo product2 = TestHelper.createProductInfo(productIdentifier2);
    final ProductInfo product3 = TestHelper.createProductInfo(productIdentifier3);
    when(productService.searchProductInfo(
            ImmutableSet.of(productIdentifier1, productIdentifier2, productIdentifier3),
            requestMetadata))
        .thenReturn(Arrays.asList(product1, product2, product3));

    final List<AccountBalanceType> balance1 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    final List<AccountBalanceType> balance3 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_TWO_POUND);
    when(savingAccountRepository.findAllById(accountNumberLongs))
        .thenReturn(
            ImmutableList.of(
                TestHelper.buildSavingAccount(
                    accountNumber1,
                    ACCOUNT_OPENED_DATE_TIME,
                    TestHelper.PERMITTED_WIT_CODES.get(3)),
                TestHelper.buildSavingAccount(
                    accountNumber2,
                    ACCOUNT_OPENED_DATE_TIME,
                    TestHelper.PERMITTED_WIT_CODES.get(4)),
                TestHelper.buildSavingAccount(
                    accountNumber3,
                    ACCOUNT_OPENED_DATE_TIME_2,
                    TestHelper.PERMITTED_WIT_CODES.get(5))));
    when(authenticService.getBalance(String.valueOf(accountNumber1))).thenReturn(balance1);
    when(authenticService.getBalance(String.valueOf(accountNumber2)))
        .thenThrow(new AccountNotFoundException("Error"));
    when(authenticService.getBalance(String.valueOf(accountNumber3))).thenReturn(balance3);

    final ImmutableSet<Long> accountNumberLongsFiltered =
        ImmutableSet.of(accountNumber1, accountNumber3);
    final List<AccountWarningRestrictionRule> account1RestrictionRules =
        TestHelper.createAccountWarningRestrictionRule(String.valueOf(accountNumber1));
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongsFiltered, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(account1RestrictionRules);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber1), accountDetails1.getProductIdentifier());
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber3), accountDetails3.getProductIdentifier());

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productIdentifier1, product1);
    productInfoByProductIdentifier.put(productIdentifier2, product2);
    productInfoByProductIdentifier.put(productIdentifier3, product3);

    final Map<String, List<AccountWarningRestrictionRule>>
        account1WarningRestrictionRulesByAccountNumber = new LinkedHashMap<>();
    account1WarningRestrictionRulesByAccountNumber.put(
        String.valueOf(accountNumber1), account1RestrictionRules);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        String.valueOf(accountNumber1),
        Collections.singletonList(
            new AccountWarningRestrictionRule(
                Long.parseLong(String.valueOf(accountNumber1)),
                RESTRICTION_TYPE_CODE,
                RESTRICTION_TYPE_RULE_CODE,
                RESTRICTION_TYPE_RULE_CHAR_VALUE)));
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            account1WarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongsFiltered,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final GroupedAccountListResponse mapped =
        GroupedAccountListResponse.builder()
            .owned(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber1),
                                balance1,
                                ACCOUNT_OPENED_DATE_TIME.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_ONE_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .other(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber3), balance3, NOW.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_TWO_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .build();

    when(accountListMapper.mapToAccountGroups(
            Arrays.asList(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails1)
                    .balances(balance1)
                    .productInfo(product1)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(
                        accountWarningRestrictionRulesFilteredByAccountNumber.get(
                            String.valueOf(accountNumber1)))
                    .activityGroupCodes(
                        ImmutableSet.of(ACTIVITY_GROUP_CODE_AISP, ACTIVITY_GROUP_CODE_AHLDRS))
                    .anniversaryWithdrawalLimit(null)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
                    .build(),
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails3)
                    .balances(balance3)
                    .productInfo(product3)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(Collections.emptyList())
                    .activityGroupCodes(ImmutableSet.of(ACTIVITY_GROUP_CODE_AISP))
                    .anniversaryWithdrawalLimit(null)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME_2.toLocalDate())
                    .build()),
            false))
        .thenReturn(mapped);
    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, false);
    assertThat(actual, is(mapped));
  }

  @Test
  void getAccountGroupsShouldFilterOutAccountsWhenSavingAccountNotFoundInDatabase() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier1 = INTSAV_PRODUCT_ID;
    final String productIdentifier2 = INTSAV2_PRODUCT_ID;
    final long accountNumber1 = 1111111111L;
    final long accountNumber2 = 2222222222L;

    final SavingAccountDetails accountDetails1 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber1), productIdentifier1);
    final SavingAccountDetails accountDetails2 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber2), productIdentifier2);
    final List<SavingAccountDetails> accountDetailsFound =
        Arrays.asList(accountDetails1, accountDetails2);

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(Arrays.asList(accountNumber1, accountNumber2));

    when(savingAccountDetailsService.getSavingAccountDetails(
            Arrays.asList(accountNumber1, accountNumber2)))
        .thenReturn(accountDetailsFound);

    final ImmutableSet<Long> accountNumberLongs = ImmutableSet.of(accountNumber1, accountNumber2);
    final ImmutableSet<Long> accountNumberLongsFiltered = ImmutableSet.of(accountNumber1);
    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG, ACTIVITY_GROUP_CODES_ACCOUNT_LIST, accountNumberLongs, NOW))
        .thenReturn(
            Arrays.asList(
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AISP),
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AHLDRS),
                new AccountActivityGroup(accountNumber2, ACTIVITY_GROUP_CODE_AISP)));

    final ProductInfo product1 = TestHelper.createProductInfo(productIdentifier1);
    final ProductInfo product2 = TestHelper.createProductInfo(productIdentifier2);
    when(productService.searchProductInfo(
            ImmutableSet.of(productIdentifier1, productIdentifier2), requestMetadata))
        .thenReturn(Arrays.asList(product1, product2));
    when(savingAccountRepository.findAllById(accountNumberLongs))
        .thenReturn(
            ImmutableList.of(
                TestHelper.buildSavingAccount(
                    accountNumber1,
                    ACCOUNT_OPENED_DATE_TIME,
                    TestHelper.PERMITTED_WIT_CODES.get(5))));
    final List<AccountBalanceType> balance1 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(String.valueOf(accountNumber1))).thenReturn(balance1);

    final List<AccountWarningRestrictionRule> account1RestrictionRules =
        TestHelper.createAccountWarningRestrictionRule(String.valueOf(accountNumber1));
    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongsFiltered, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(account1RestrictionRules);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber1), accountDetails1.getProductIdentifier());

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productIdentifier1, product1);
    productInfoByProductIdentifier.put(productIdentifier2, product2);

    final Map<String, List<AccountWarningRestrictionRule>>
        account1WarningRestrictionRulesByAccountNumber = new LinkedHashMap<>();
    account1WarningRestrictionRulesByAccountNumber.put(
        String.valueOf(accountNumber1), account1RestrictionRules);

    final Map<String, List<AccountWarningRestrictionRule>>
        accountWarningRestrictionRulesFilteredByAccountNumber = new LinkedHashMap<>();
    accountWarningRestrictionRulesFilteredByAccountNumber.put(
        String.valueOf(accountNumber1),
        Collections.singletonList(
            new AccountWarningRestrictionRule(
                Long.parseLong(String.valueOf(accountNumber1)),
                RESTRICTION_TYPE_CODE,
                RESTRICTION_TYPE_RULE_CODE,
                RESTRICTION_TYPE_RULE_CHAR_VALUE)));
    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            account1WarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(accountWarningRestrictionRulesFilteredByAccountNumber);

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongsFiltered,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final GroupedAccountListResponse mapped =
        GroupedAccountListResponse.builder()
            .owned(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber1),
                                balance1,
                                ACCOUNT_OPENED_DATE_TIME.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_ONE_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .build();

    when(accountListMapper.mapToAccountGroups(
            Collections.singletonList(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails1)
                    .balances(balance1)
                    .productInfo(product1)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(
                        accountWarningRestrictionRulesFilteredByAccountNumber.get(
                            String.valueOf(accountNumber1)))
                    .activityGroupCodes(
                        ImmutableSet.of(ACTIVITY_GROUP_CODE_AISP, ACTIVITY_GROUP_CODE_AHLDRS))
                    .anniversaryWithdrawalLimit(null)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
                    .build()),
            false))
        .thenReturn(mapped);
    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, false);
    assertThat(actual, is(mapped));
  }

  @Test
  void getAccountGroupsShouldSucceedWhenNoAccountsFound() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(Collections.emptyList());

    final GroupedAccountListResponse mapped = GroupedAccountListResponse.builder().build();
    when(accountListMapper.mapToAccountGroups(Collections.emptyList(), false)).thenReturn(mapped);

    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, false);
    assertThat(actual, is(mapped));

    verify(productService, never()).searchProductInfo(any(), any());
    verify(authenticService, never()).getBalance(any());
    verify(activityPlayerRepository, never())
        .findAccountsWherePartyHasActivityGroup(any(), any(), any(), any());
    verify(accountWarningRepository, never())
        .findAccountWarningRestrictionRulesByAccountNumbersAndDate(any(), any(), any());
    verify(savingAccountAnnualWithdrawalLimitRepository, never()).findAllByAccountNumbers(any());
    verify(savingsTransactionLogRepository, never())
        .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(any(), any(), any());
  }

  @Test
  void
      getAccountGroupsShouldSucceedWhenProductHasAnniversaryWithdrawalLimitButNoLimitFoundForAccount() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier1 = INTSAV_PRODUCT_ID;
    final long accountNumber1 = 1111111111L;

    final ImmutableSet<Long> accountNumberLongs = ImmutableSet.of(accountNumber1);

    final SavingAccountDetails accountDetails1 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber1), productIdentifier1);

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(Collections.singletonList(accountNumber1));

    when(savingAccountDetailsService.getSavingAccountDetails(
            Collections.singletonList(accountNumber1)))
        .thenReturn(Collections.singletonList(accountDetails1));

    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG, ACTIVITY_GROUP_CODES_ACCOUNT_LIST, accountNumberLongs, NOW))
        .thenReturn(
            Collections.singleton(
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AISP)));

    final ProductInfo product1 =
        TestHelper.createProductInfoWithAnniversaryWithdrawalLimit(productIdentifier1);
    when(productService.searchProductInfo(ImmutableSet.of(productIdentifier1), requestMetadata))
        .thenReturn(Collections.singletonList(product1));

    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(Collections.emptyList());

    when(savingAccountRepository.findAllById(accountNumberLongs))
        .thenReturn(
            ImmutableList.of(
                TestHelper.buildSavingAccount(
                    accountNumber1,
                    ACCOUNT_OPENED_DATE_TIME,
                    TestHelper.PERMITTED_WIT_CODES.get(6))));

    final List<AccountBalanceType> balance1 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(String.valueOf(accountNumber1))).thenReturn(balance1);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber1), accountDetails1.getProductIdentifier());

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productIdentifier1, product1);

    final Map<String, List<AccountWarningRestrictionRule>>
        account1WarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            account1WarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(Collections.emptyMap());

    when(savingAccountAnnualWithdrawalLimitRepository.findAllByAccountNumbers(accountNumberLongs))
        .thenReturn(Collections.emptyList());

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final GroupedAccountListResponse mapped =
        GroupedAccountListResponse.builder()
            .other(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber1),
                                balance1,
                                ACCOUNT_OPENED_DATE_TIME.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_ONE_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .build();

    when(accountListMapper.mapToAccountGroups(
            Collections.singletonList(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails1)
                    .balances(balance1)
                    .productInfo(product1)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(Collections.emptyList())
                    .activityGroupCodes(Collections.singleton(ACTIVITY_GROUP_CODE_AISP))
                    .anniversaryWithdrawalLimit(null)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
                    .build()),
            false))
        .thenReturn(mapped);
    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, false);
    assertThat(actual, is(mapped));
  }

  @Test
  void getAccountGroupsShouldSucceedWhenAccountHasAnniversaryWithdrawalLimit() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier1 = INTSAV_PRODUCT_ID;
    final long accountNumber1 = 1111111111;

    final ImmutableSet<Long> accountNumberLongs = ImmutableSet.of(accountNumber1);

    final SavingAccountDetails accountDetails1 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber1), productIdentifier1);

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(Collections.singletonList(accountNumber1));

    when(savingAccountDetailsService.getSavingAccountDetails(
            Collections.singletonList(accountNumber1)))
        .thenReturn(Collections.singletonList(accountDetails1));

    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG, ACTIVITY_GROUP_CODES_ACCOUNT_LIST, accountNumberLongs, NOW))
        .thenReturn(
            Collections.singleton(
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AISP)));

    final ProductInfo product1 =
        TestHelper.createProductInfoWithAnniversaryWithdrawalLimit(productIdentifier1);
    when(productService.searchProductInfo(ImmutableSet.of(productIdentifier1), requestMetadata))
        .thenReturn(Collections.singletonList(product1));

    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(Collections.emptyList());

    when(savingAccountRepository.findAllById(accountNumberLongs))
        .thenReturn(
            ImmutableList.of(
                TestHelper.buildSavingAccount(
                    accountNumber1,
                    ACCOUNT_OPENED_DATE_TIME,
                    TestHelper.PERMITTED_WIT_CODES.get(7))));

    final List<AccountBalanceType> balance1 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(String.valueOf(accountNumber1))).thenReturn(balance1);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber1), accountDetails1.getProductIdentifier());

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productIdentifier1, product1);

    final Map<String, List<AccountWarningRestrictionRule>>
        account1WarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            account1WarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(Collections.emptyMap());

    final SavingAccountAnnualWithdrawalLimit limit =
        TestHelper.createSavingAccountAnnualWithdrawalLimit(String.valueOf(accountNumber1));
    when(savingAccountAnnualWithdrawalLimitRepository.findAllByAccountNumbers(accountNumberLongs))
        .thenReturn(Collections.singletonList(limit));

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(Collections.emptySet());

    final GroupedAccountListResponse mapped =
        GroupedAccountListResponse.builder()
            .other(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber1),
                                balance1,
                                ACCOUNT_OPENED_DATE_TIME.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_ONE_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .build();

    when(accountListMapper.mapToAccountGroups(
            Collections.singletonList(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails1)
                    .balances(balance1)
                    .productInfo(product1)
                    .productMigrationInProgress(false)
                    .accountWarningRestrictionRules(Collections.emptyList())
                    .activityGroupCodes(Collections.singleton(ACTIVITY_GROUP_CODE_AISP))
                    .anniversaryWithdrawalLimit(limit)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
                    .build()),
            false))
        .thenReturn(mapped);
    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, false);
    assertThat(actual, is(mapped));
  }

  @Test
  void getAccountGroupsShouldSucceedWhenAccountHasProductMigrationInProgress() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final String productIdentifier1 = INTSAV_PRODUCT_ID;
    final long accountNumber1 = 1111111111L;

    final ImmutableSet<Long> accountNumberLongs = ImmutableSet.of(accountNumber1);

    final SavingAccountDetails accountDetails1 =
        TestHelper.createSavingAccountDetails(String.valueOf(accountNumber1), productIdentifier1);

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(Collections.singletonList(accountNumber1));

    when(savingAccountDetailsService.getSavingAccountDetails(
            Collections.singletonList(accountNumber1)))
        .thenReturn(Collections.singletonList(accountDetails1));

    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG, ACTIVITY_GROUP_CODES_ACCOUNT_LIST, accountNumberLongs, NOW))
        .thenReturn(
            Arrays.asList(
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AISP),
                new AccountActivityGroup(accountNumber1, ACTIVITY_GROUP_CODE_AHLDRS)));

    final ProductInfo product1 = TestHelper.createProductInfo(productIdentifier1);
    when(productService.searchProductInfo(
            Collections.singleton(productIdentifier1), requestMetadata))
        .thenReturn(Collections.singletonList(product1));

    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumberLongs, ACCOUNT_WARNING_RESTRICTION_TYPE_RULE_CODES, NOW))
        .thenReturn(Collections.emptyList());

    when(savingAccountRepository.findAllById(accountNumberLongs))
        .thenReturn(
            ImmutableList.of(
                TestHelper.buildSavingAccount(
                    accountNumber1,
                    ACCOUNT_OPENED_DATE_TIME,
                    TestHelper.PERMITTED_WIT_CODES.get(8))));
    final List<AccountBalanceType> balance1 =
        TestHelper.createAccountBalanceTypeList(AMOUNT_ONE_POUND);
    when(authenticService.getBalance(String.valueOf(accountNumber1))).thenReturn(balance1);

    final Map<String, String> productIdentifierByAccountNumber = new LinkedHashMap<>();
    productIdentifierByAccountNumber.put(
        String.valueOf(accountNumber1), accountDetails1.getProductIdentifier());

    final Map<String, ProductInfo> productInfoByProductIdentifier = new LinkedHashMap<>();
    productInfoByProductIdentifier.put(productIdentifier1, product1);

    final Map<String, List<AccountWarningRestrictionRule>>
        account1WarningRestrictionRulesByAccountNumber = Collections.emptyMap();

    when(accountWarningFilter.filter(
            productIdentifierByAccountNumber,
            productInfoByProductIdentifier,
            account1WarningRestrictionRulesByAccountNumber,
            NOW))
        .thenReturn(Collections.emptyMap());

    when(savingsTransactionLogRepository
            .findAllAccountsWithEntriesStartingOrEndingAfterEarliestTime(
                accountNumberLongs,
                SAVING_TRANSACTION_LOG_STATUSES_PRODUCT_MIGRATION,
                TWO_DAYS_AGO))
        .thenReturn(accountNumberLongs);

    final GroupedAccountListResponse mapped =
        GroupedAccountListResponse.builder()
            .owned(
                GroupedAccountListResponse.AccountGroup.builder()
                    .accounts(
                        Collections.singletonList(
                            TestHelper.createAccountSummary(
                                String.valueOf(accountNumber1),
                                balance1,
                                ACCOUNT_OPENED_DATE_TIME.toLocalDate())))
                    .balances(
                        Collections.singletonList(
                            Balance.builder()
                                .amount(new BigDecimal(AMOUNT_ONE_POUND))
                                .type(CAPITAL_AVAILABLE_BALANCE_TYPE)
                                .build()))
                    .build())
            .build();

    when(accountListMapper.mapToAccountGroups(
            Collections.singletonList(
                AccountSummaryMappingBundle.builder()
                    .savingAccountDetails(accountDetails1)
                    .balances(balance1)
                    .productInfo(product1)
                    .productMigrationInProgress(true)
                    .accountWarningRestrictionRules(Collections.emptyList())
                    .activityGroupCodes(
                        ImmutableSet.of(ACTIVITY_GROUP_CODE_AISP, ACTIVITY_GROUP_CODE_AHLDRS))
                    .anniversaryWithdrawalLimit(null)
                    .closed(false)
                    .openedDate(ACCOUNT_OPENED_DATE_TIME.toLocalDate())
                    .build()),
            false))
        .thenReturn(mapped);
    final GroupedAccountListResponse actual =
        accountService.getAccountGroups(requestMetadata, false);
    assertThat(actual, is(mapped));
  }

  @Test
  void getAccountGroupsShouldThrowAccountServiceExceptionWhenProductSearchDoesNotFindProduct() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final SavingAccountDetails accountSummary =
        TestHelper.createSavingAccountDetails(ACCOUNT_NUMBER, INTSAV_PRODUCT_ID);

    when(customersSavingsAccountService.getSavingsAccountList(requestMetadata, false))
        .thenReturn(Collections.singletonList(Long.parseLong(ACCOUNT_NUMBER)));

    when(savingAccountDetailsService.getSavingAccountDetails(
            Collections.singletonList(Long.parseLong(ACCOUNT_NUMBER))))
        .thenReturn(Collections.singletonList(accountSummary));

    when(activityPlayerRepository.findAccountsWherePartyHasActivityGroup(
            PARTY_ID_LONG,
            ACTIVITY_GROUP_CODES_ACCOUNT_LIST,
            Collections.singleton(ACCOUNT_NUMBER_LONG),
            NOW))
        .thenReturn(
            Collections.singleton(
                new AccountActivityGroup(ACCOUNT_NUMBER_LONG, ACTIVITY_GROUP_CODE_AISP)));

    when(productService.searchProductInfo(any(), any())).thenReturn(Collections.emptyList());

    final AccountServiceException thrown =
        assertThrows(
            AccountServiceException.class,
            () -> accountService.getAccountGroups(requestMetadata, false));

    assertThat(thrown.getMessage(), is("Failed to find all products.  Requested: [INTSAV]"));
  }

  @Test
  void createISADeclarationShouldSaveAWorkLogAndSavingsTransactionLog() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final List<Long> accountNumbers = Collections.singletonList(ACCOUNT_NUMBER_LONG);
    final List<String> restrictionTypes = Collections.singletonList(WEBREC);

    final List<AccountWarningRestrictionRule> rules =
        TestHelper.createAccountWarningRestrictionRule(ACCOUNT_NUMBER);

    final Optional<SavingProduct> savingProduct =
        Optional.ofNullable(
            SavingProduct.builder()
                .productIdentifier(PRODUCT_IDENTIFIER)
                .brandCode(BRAND_YBS)
                .build());

    final ProductInfo productInfo =
        ProductInfo.builder().productIdentifier(PRODUCT_IDENTIFIER).productType(ISA).build();

    when(savingsTransactionLogRepository.findAllAccountsWithEntriesStartingAfterEarliestTime(
            accountNumbers, ONE_DAY_AGO, SavingsTransactionLogEntry.STATUS_ISA_DECLARATION))
        .thenReturn(Collections.emptySet());

    when(savingProductRepository.findBySavingAccountNumber(ACCOUNT_NUMBER_LONG))
        .thenReturn(savingProduct);

    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(productInfo);

    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumbers, restrictionTypes, NOW))
        .thenReturn(rules);

    accountService.createIsaDeclaration(requestMetadata, ACCOUNT_NUMBER);

    verify(savingsTransactionLogRepository)
        .findAllAccountsWithEntriesStartingAfterEarliestTime(
            accountNumbers, ONE_DAY_AGO, SavingsTransactionLogEntry.STATUS_ISA_DECLARATION);

    verify(workLogRepository)
        .save(
            WorkLog.builder()
                .accountNumber(ACCOUNT_NUMBER_LONG)
                .status(WorkLog.Status.PENDING)
                .createdBy(SACCSRV)
                .operation(WorkLog.Operation.SUBMIT_ISA_DEC)
                .message(
                    WorkLogRequest.builder()
                        .workLogPayload(SubmitIsaDeclarationRequest.builder().build())
                        .metadata(requestMetadata)
                        .build())
                .build());

    verify(savingsTransactionLogRepository)
        .save(
            SavingsTransactionLogEntry.builder()
                .accountNumber(ACCOUNT_NUMBER_LONG)
                .startTime(NOW)
                .status(SavingsTransactionLogEntry.STATUS_ISA_DECLARATION)
                .build());
  }

  @Test
  void createISADeclarationShouldNotWriteAWorkLogOrSavingsTransactionLogWhenAccountIsInBlacklist() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final List<Long> accountNumbers = Collections.singletonList(ACCOUNT_NUMBER_LONG);
    final List<String> restrictionTypes = Collections.singletonList(WEBREC);

    final List<AccountWarningRestrictionRule> rules =
        TestHelper.createAccountWarningRestrictionRule(ACCOUNT_NUMBER);

    final Optional<SavingProduct> savingProduct =
        Optional.ofNullable(
            SavingProduct.builder()
                .productIdentifier(PRODUCT_IDENTIFIER)
                .brandCode(BRAND_YBS)
                .build());

    final ProductInfo productInfo =
        ProductInfo.builder().productIdentifier(PRODUCT_IDENTIFIER).productType(ISA).build();

    when(savingsTransactionLogRepository.findAllAccountsWithEntriesStartingAfterEarliestTime(
            accountNumbers, ONE_DAY_AGO, SavingsTransactionLogEntry.STATUS_ISA_DECLARATION))
        .thenReturn(Collections.emptySet());

    when(savingProductRepository.findBySavingAccountNumber(ACCOUNT_NUMBER_LONG))
        .thenReturn(savingProduct);

    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(productInfo);

    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumbers, restrictionTypes, NOW))
        .thenReturn(rules);

    when(accountServiceProperties.getAccountNumberBlacklist())
        .thenReturn(Collections.singletonList(ACCOUNT_NUMBER));

    accountService.createIsaDeclaration(requestMetadata, ACCOUNT_NUMBER);

    verify(savingsTransactionLogRepository)
        .findAllAccountsWithEntriesStartingAfterEarliestTime(
            accountNumbers, ONE_DAY_AGO, SavingsTransactionLogEntry.STATUS_ISA_DECLARATION);

    verifyNoInteractions(workLogRepository);

    verifyNoMoreInteractions(savingsTransactionLogRepository);
  }

  @Test
  void createIsaDeclarationThrowsAccountServiceExceptionWhenSavingsProductReturnsNothing() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    when(savingProductRepository.findBySavingAccountNumber(ACCOUNT_NUMBER_LONG))
        .thenReturn(Optional.empty());

    final AccountServiceException thrown =
        assertThrows(
            AccountServiceException.class,
            () -> accountService.createIsaDeclaration(requestMetadata, ACCOUNT_NUMBER));

    assertEquals("Failed to find savings product for account", thrown.getMessage());
    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(accountWarningRepository);
    verifyNoInteractions(savingsTransactionLogRepository);
    verifyNoInteractions(productService);
  }

  @Test
  void createIsaDeclarationShouldPropagateExceptionWhenSavingsProductServiceFails() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final Optional<SavingProduct> savingProduct =
        Optional.ofNullable(
            SavingProduct.builder()
                .productIdentifier(PRODUCT_IDENTIFIER)
                .brandCode(BRAND_YBS)
                .build());

    when(savingProductRepository.findBySavingAccountNumber(ACCOUNT_NUMBER_LONG))
        .thenReturn(savingProduct);

    doThrow(new RuntimeException("something went wrong"))
        .when(productService)
        .getProductInfo(PRODUCT_IDENTIFIER, requestMetadata);

    final RuntimeException thrown =
        assertThrows(
            RuntimeException.class,
            () -> accountService.createIsaDeclaration(requestMetadata, ACCOUNT_NUMBER));

    assertEquals("something went wrong", thrown.getMessage());
    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(accountWarningRepository);
    verifyNoInteractions(savingsTransactionLogRepository);
  }

  @Test
  void createIsaDeclarationThrowsWorkLogConflictExceptionWhenSavingsProductIsNotAnIsa() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final Optional<SavingProduct> savingProduct =
        Optional.ofNullable(
            SavingProduct.builder()
                .productIdentifier(PRODUCT_IDENTIFIER)
                .brandCode(BRAND_YBS)
                .build());

    final ProductInfo productInfo =
        ProductInfo.builder()
            .productIdentifier(PRODUCT_IDENTIFIER)
            .productType("NOT AN ISA")
            .build();

    when(savingProductRepository.findBySavingAccountNumber(ACCOUNT_NUMBER_LONG))
        .thenReturn(savingProduct);

    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(productInfo);

    final WorkLogConflictException thrown =
        assertThrows(
            WorkLogConflictException.class,
            () -> accountService.createIsaDeclaration(requestMetadata, ACCOUNT_NUMBER));

    assertEquals("Account type is not valid for an ISA declaration", thrown.getMessage());
    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(accountWarningRepository);
    verifyNoInteractions(savingsTransactionLogRepository);
  }

  @Test
  void createIsaDeclarationThrowsWorkLogConflictExceptionWhenAccountWarningsAreNotFound() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final List<Long> accountNumbers = Collections.singletonList(ACCOUNT_NUMBER_LONG);
    final List<String> restrictionTypes = Collections.singletonList(WEBREC);

    final List<AccountWarningRestrictionRule> rules =
        Collections.singletonList(
            new AccountWarningRestrictionRule(
                ACCOUNT_NUMBER_LONG, "NOREC", WEBREC, "NOREC_WEBTXT"));

    final Optional<SavingProduct> savingProduct =
        Optional.ofNullable(
            SavingProduct.builder()
                .productIdentifier(PRODUCT_IDENTIFIER)
                .brandCode(BRAND_YBS)
                .build());

    final ProductInfo productInfo =
        ProductInfo.builder().productIdentifier(PRODUCT_IDENTIFIER).productType(ISA).build();

    when(savingsTransactionLogRepository.findAllAccountsWithEntriesStartingAfterEarliestTime(
            accountNumbers, ONE_DAY_AGO, SavingsTransactionLogEntry.STATUS_ISA_DECLARATION))
        .thenReturn(Collections.emptySet());

    when(savingProductRepository.findBySavingAccountNumber(ACCOUNT_NUMBER_LONG))
        .thenReturn(savingProduct);

    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(productInfo);

    when(accountWarningRepository.findAccountWarningRestrictionRulesByAccountNumbersAndDate(
            accountNumbers, restrictionTypes, NOW))
        .thenReturn(rules);

    final WorkLogConflictException thrown =
        assertThrows(
            WorkLogConflictException.class,
            () -> accountService.createIsaDeclaration(requestMetadata, ACCOUNT_NUMBER));

    assertEquals("No deposit warnings set against account", thrown.getMessage());
    verifyNoInteractions(workLogRepository);
    verifyNoMoreInteractions(savingsTransactionLogRepository);
  }

  @Test
  void createIsaDeclarationThrowsWorkLogConflictExceptionWhenSavingsTransactionLogIsFound() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final List<Long> accountNumbers = Collections.singletonList(ACCOUNT_NUMBER_LONG);

    final Optional<SavingProduct> savingProduct =
        Optional.ofNullable(
            SavingProduct.builder()
                .productIdentifier(PRODUCT_IDENTIFIER)
                .brandCode(BRAND_YBS)
                .build());

    final ProductInfo productInfo =
        ProductInfo.builder().productIdentifier(PRODUCT_IDENTIFIER).productType(ISA).build();

    when(savingProductRepository.findBySavingAccountNumber(ACCOUNT_NUMBER_LONG))
        .thenReturn(savingProduct);

    when(productService.getProductInfo(PRODUCT_IDENTIFIER, requestMetadata))
        .thenReturn(productInfo);

    when(savingsTransactionLogRepository.findAllAccountsWithEntriesStartingAfterEarliestTime(
            accountNumbers, ONE_DAY_AGO, SavingsTransactionLogEntry.STATUS_ISA_DECLARATION))
        .thenReturn(new HashSet<>(Collections.singleton(ACCOUNT_NUMBER_LONG)));

    final WorkLogConflictException thrown =
        assertThrows(
            WorkLogConflictException.class,
            () -> accountService.createIsaDeclaration(requestMetadata, ACCOUNT_NUMBER));

    verify(savingsTransactionLogRepository)
        .findAllAccountsWithEntriesStartingAfterEarliestTime(
            accountNumbers, ONE_DAY_AGO, SavingsTransactionLogEntry.STATUS_ISA_DECLARATION);

    assertEquals("ISA declaration is currently in progress", thrown.getMessage());
    verifyNoInteractions(workLogRepository);
    verifyNoInteractions(accountWarningRepository);
    verifyNoMoreInteractions(savingsTransactionLogRepository);
  }

  @Test
  void checkForRecentAccountsShouldSucceedWhenOneOrMoreAccountNumbersAreFound() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID, BRAND_YBS);
    final Collection<String> brandCodes = Collections.singletonList(BRAND_YBS);

    when(accountNumberRepository
            .findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
                PARTY_ID_LONG, brandCodes, NOW.minusYears(2)))
        .thenReturn(Collections.singletonList(new AccountNumber()));

    accountService.checkForRecentAccounts(PARTY_ID_LONG, requestMetadata);

    verify(accountNumberRepository)
        .findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
            PARTY_ID_LONG, brandCodes, NOW.minusYears(2));
  }

  @Test
  void
      checkForRecentAccountsShouldShouldThrowAccountResourceNotFoundExceptionWhenNoAccountNumbersAreFound() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID, BRAND_YBS);
    final Collection<String> brandCodes = Collections.singletonList(BRAND_YBS);

    when(accountNumberRepository
            .findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
                PARTY_ID_LONG, brandCodes, NOW.minusYears(2)))
        .thenReturn(Collections.emptyList());

    final AccountResourceNotFoundException thrown =
        assertThrows(
            AccountResourceNotFoundException.class,
            () -> accountService.checkForRecentAccounts(PARTY_ID_LONG, requestMetadata));

    verify(accountNumberRepository)
        .findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
            PARTY_ID_LONG, brandCodes, NOW.minusYears(2));
    assertEquals(
        "No open or closed accounts found for 123456 since 2018-05-26T14:45:01",
        thrown.getMessage());
  }

  @Test
  void getActiveWarningsForAccountShouldReturnSuccessful() {
    final RestrictionType restrictionType = TestHelper.buildRestrictionType("CA", "test1"); // NOPMD
    final RestrictionType restrictionType2 =
        TestHelper.buildRestrictionType("PA", "test2"); // NOPMD
    final AccountWarning accountWarning =
        TestHelper.buildAccountWarning(
            1L,
            AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build(),
            restrictionType,
            NOW,
            null);
    final AccountWarning accountWarning2 =
        TestHelper.buildAccountWarning(
            1L,
            AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build(),
            restrictionType2,
            NOW,
            null);

    when(accountWarningRepository.findActiveAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Arrays.asList(accountWarning, accountWarning2));

    final Collection<Warning> expected = new HashSet<>();
    expected.add(Warning.builder().code("CA").description("test1").build());
    expected.add(Warning.builder().code("PA").description("test2").build());

    final Collection<Warning> result = accountService.getActiveWarningsForAccount(ACCOUNT_NUMBER);
    assertEquals(result, expected);
  }

  @Test
  void getActiveWarningsForAccountShouldNotReturnDuplicateRestrictions() {
    final RestrictionType restrictionType = TestHelper.buildRestrictionType("CA", "test1");
    final AccountWarning accountWarning =
        TestHelper.buildAccountWarning(
            1L,
            AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build(),
            restrictionType,
            NOW,
            null);

    when(accountWarningRepository.findActiveAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Arrays.asList(accountWarning, accountWarning));

    final Collection<Warning> expected = new HashSet<>();
    expected.add(Warning.builder().code("CA").description("test1").build());

    final Collection<Warning> result = accountService.getActiveWarningsForAccount(ACCOUNT_NUMBER);
    assertEquals(result, expected);
  }

  @Test
  void getWarningsForAccountShouldReturnSuccessfulForWarningsInWorkLog() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);
    when(workLogRepository.findRequestsByAccountNumberAndStateAndOperation(
            WorkLog.Status.PENDING, Operation.INS_ACCOUNT_WARNING, ACCOUNT_NUMBER_LONG))
        .thenReturn(
            Collections.singletonList(
                WorkLog.builder()
                    .accountNumber(ACCOUNT_NUMBER_LONG)
                    .status(WorkLog.Status.PENDING)
                    .createdBy(SACCSRV)
                    .operation(Operation.INS_ACCOUNT_WARNING)
                    .message(
                        WorkLogRequest.builder()
                            .workLogPayload(
                                AccountWarningRequest.builder()
                                    .warningType(WARNING_CODE)
                                    .notes("notes")
                                    .build())
                            .metadata(requestMetadata)
                            .build())
                    .build()));

    when(accountWarningRepository.findActiveAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Collections.emptyList());
    when(accountWarningRepository.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Collections.emptyList());

    final Collection<Warning> expected = new HashSet<>();
    expected.add(Warning.builder().code(WARNING_CODE).description("notes").build());

    Collection<Warning> result = accountService.getActiveWarningsForAccount(ACCOUNT_NUMBER);
    assertEquals(result, expected);

    result = accountService.getAllWarningsForAccount(ACCOUNT_NUMBER);
    assertEquals(result, expected);
  }

  @Test
  void getActiveWarningsForAccountShouldReturnEmptyWhenNoRestrictionsForAccount() {
    when(accountWarningRepository.findActiveAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Collections.emptyList());

    final Collection<Warning> result = accountService.getActiveWarningsForAccount(ACCOUNT_NUMBER);
    assertThat(result, is(empty()));
  }

  @Test
  void getAllWarningsForAccountShouldReturnSuccessful() {
    final RestrictionType restrictionType = TestHelper.buildRestrictionType("CA", "test1");
    final RestrictionType restrictionType2 = TestHelper.buildRestrictionType("PA", "test2");
    final AccountWarning accountWarning =
        TestHelper.buildAccountWarning(
            1L,
            AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build(),
            restrictionType,
            NOW,
            null);
    final AccountWarning accountWarning2 =
        TestHelper.buildAccountWarning(
            1L,
            AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build(),
            restrictionType2,
            NOW,
            null);

    when(accountWarningRepository.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Arrays.asList(accountWarning, accountWarning2));

    final Collection<Warning> expected = new HashSet<>();
    expected.add(Warning.builder().code("CA").description("test1").build());
    expected.add(Warning.builder().code("PA").description("test2").build());

    final Collection<Warning> result = accountService.getAllWarningsForAccount(ACCOUNT_NUMBER);
    assertEquals(result, expected);
  }

  @Test
  void getAllWarningsForAccountShouldNotReturnDuplicateRestrictions() {
    final RestrictionType restrictionType = TestHelper.buildRestrictionType("CA", "test1");
    final AccountWarning accountWarning =
        TestHelper.buildAccountWarning(
            1L,
            AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build(),
            restrictionType,
            NOW,
            null);

    when(accountWarningRepository.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Arrays.asList(accountWarning, accountWarning));

    final Collection<Warning> expected = new HashSet<>();
    expected.add(Warning.builder().code("CA").description("test1").build());

    final Collection<Warning> result = accountService.getAllWarningsForAccount(ACCOUNT_NUMBER);
    assertEquals(result, expected);
  }

  @Test
  void getAllWarningsForAccountShouldReturnEmptyWhenNoRestrictionsForAccount() {
    when(accountWarningRepository.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Collections.emptyList());

    final Collection<Warning> result = accountService.getAllWarningsForAccount(ACCOUNT_NUMBER);
    assertThat(result, is(empty()));
  }

  @Test
  void getAllWarningsForAccountShouldReturnEndedWarningsWithEdnDate() {
    final RestrictionType restrictionType = TestHelper.buildRestrictionType("CA", "test1");

    final AccountWarning accountWarning =
        TestHelper.buildAccountWarning(
            1L,
            AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build(),
            restrictionType,
            NOW,
            ONE_DAY_AGO);

    when(accountWarningRepository.findAccountWarningsByAccountNumberAndDate(
            Collections.singletonList(ACCOUNT_NUMBER_LONG), NOW))
        .thenReturn(Arrays.asList(accountWarning, accountWarning));

    final Collection<Warning> expected = new HashSet<>();
    expected.add(Warning.builder().code("CA").description("test1").endDate(ONE_DAY_AGO).build());

    final Collection<Warning> result = accountService.getAllWarningsForAccount(ACCOUNT_NUMBER);
    assertEquals(result, expected);
  }

  @ParameterizedTest
  @MethodSource("warningArgs")
  void createWarningForAccountShouldSucceed(
      final String warningType,
      final String createdBy,
      final String createdAt,
      final String notes) {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final WarningCode warningCode =
        TestHelper.buildWarningCode(
            warningType, notes, createdAt, createdBy != null ? Long.valueOf(createdBy) : null);
    final RestrictionType restrictionType = TestHelper.buildRestrictionType(warningType, "test1");
    final AccountWarningRequest workLogPayload =
        TestHelper.buildAccountWarningWorkLogPayload(warningType, createdBy, createdAt, notes);
    final WorkLogRequest workLogRequest =
        TestHelper.buildWorkLogRequest(requestMetadata, workLogPayload);

    when(accountNumberRepository.findById(ACCOUNT_NUMBER_LONG))
        .thenReturn(
            Optional.of(AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build()));

    when(restrictionTypeRepository.findByCode(warningType))
        .thenReturn(Optional.ofNullable(restrictionType));

    assert restrictionType != null;
    when(accountWarningRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            ACCOUNT_NUMBER_LONG, Collections.singletonList(restrictionType.getCode()), NOW))
        .thenReturn(Collections.emptyList());

    accountService.createWarningForAccount(ACCOUNT_NUMBER, warningCode, requestMetadata);

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("accountNumber", is(ACCOUNT_NUMBER_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty("operation", is(Operation.INS_ACCOUNT_WARNING)),
                    hasProperty("message", is(workLogRequest)),
                    hasProperty("createdBy", is(workLogPayload.getCreatedBy())))));
  }

  @Test
  void createWarningForAccountShouldThrowExceptionWhenAccountNotFound() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final WarningCode warningCode =
        TestHelper.buildWarningCode(WARNING_CODE, "notes", SERVICE_SCHEMA_USER, PARTY_ID_LONG);

    when(accountNumberRepository.findById(ACCOUNT_NUMBER_LONG)).thenReturn(Optional.empty());

    final AccountServiceException thrown =
        assertThrows(
            AccountServiceException.class,
            () ->
                accountService.createWarningForAccount(
                    ACCOUNT_NUMBER, warningCode, requestMetadata));

    assertThat(
        thrown.getMessage(),
        is("Failed to find account " + ACCOUNT_NUMBER + " for request ID: " + requestId));
    verifyNoInteractions(restrictionTypeRepository);
    verifyNoInteractions(accountWarningRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void createDuplicateWarningForAccountShouldNotCreate() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    when(accountNumberRepository.findById(ACCOUNT_NUMBER_LONG))
        .thenReturn(
            Optional.of(AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build()));

    final WarningCode warningCode =
        TestHelper.buildWarningCode(WARNING_CODE, "notes", SERVICE_SCHEMA_USER, PARTY_ID_LONG);

    final RestrictionType restrictionType = TestHelper.buildRestrictionType(WARNING_CODE, "test1");

    when(restrictionTypeRepository.findByCode(WARNING_CODE))
        .thenReturn(Optional.ofNullable(restrictionType));

    when(accountWarningRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            any(), any(), any()))
        .thenReturn(Collections.singletonList(AccountWarning.builder().build()));

    accountService.createWarningForAccount(ACCOUNT_NUMBER, warningCode, requestMetadata);

    verifyNoInteractions(workLogRepository);
  }

  @Test
  void createWarningForAccountShouldThrowExceptionWhenRestrictionTypeNotFound() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final WarningCode warningCode =
        TestHelper.buildWarningCode(WARNING_CODE, "notes", SERVICE_SCHEMA_USER, PARTY_ID_LONG);

    when(accountNumberRepository.findById(ACCOUNT_NUMBER_LONG))
        .thenReturn(
            Optional.of(AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build()));

    when(restrictionTypeRepository.findByCode(WARNING_CODE)).thenReturn(Optional.empty());

    final AccountServiceException thrown =
        assertThrows(
            AccountServiceException.class,
            () ->
                accountService.createWarningForAccount(
                    ACCOUNT_NUMBER, warningCode, requestMetadata));

    assertThat(
        thrown.getMessage(), is("Failed to find restriction type CA for request ID: " + requestId));
    verifyNoInteractions(accountWarningRepository);
    verifyNoInteractions(workLogRepository);
  }

  @ParameterizedTest
  @MethodSource("warningArgs")
  void deleteWarningForAccountShouldSucceed(
      final String warningType, final String partyId, final String schemaUser, final String notes) {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final WarningCode warningCode =
        TestHelper.buildWarningCode(
            warningType, notes, schemaUser, partyId != null ? Long.valueOf(partyId) : null);
    final RestrictionType restrictionType = TestHelper.buildRestrictionType(warningType, "test1");
    final DeleteAccountWarningRequest workLogPayload =
        TestHelper.buildDeleteAccountWarningWorkLogPayload(warningType, partyId, schemaUser);
    final WorkLogRequest workLogRequest =
        TestHelper.buildWorkLogRequest(requestMetadata, workLogPayload);

    when(accountNumberRepository.findById(ACCOUNT_NUMBER_LONG))
        .thenReturn(
            Optional.of(AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build()));

    when(restrictionTypeRepository.findByCode(warningType))
        .thenReturn(Optional.ofNullable(restrictionType));

    assert restrictionType != null;

    when(accountWarningRepository.findAccountWarningByAccountNumberAndRestrictionTypeAndDate(
            ACCOUNT_NUMBER_LONG, Collections.singletonList(restrictionType.getCode()), NOW))
        .thenReturn(
            Collections.singletonList(
                AccountWarning.builder()
                    .accountNumber(
                        AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build())
                    .build()));

    accountService.deleteWarningForAccount(ACCOUNT_NUMBER, warningCode, requestMetadata);

    verify(workLogRepository)
        .save(
            argThat(
                allOf(
                    hasProperty("sysId", is(nullValue())),
                    hasProperty("accountNumber", is(ACCOUNT_NUMBER_LONG)),
                    hasProperty("status", is(WorkLog.Status.PENDING)),
                    hasProperty("operation", is(Operation.DEL_ACCOUNT_WARNING)),
                    hasProperty("message", is(workLogRequest)),
                    hasProperty("createdBy", is(workLogPayload.getEndedBy())))));
  }

  @Test
  void deleteWarningForAccountShouldThrowExceptionWhenRestrictionTypeNotFound() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final WarningCode warningCode =
        TestHelper.buildWarningCode(WARNING_CODE, "notes", SERVICE_SCHEMA_USER, PARTY_ID_LONG);

    when(accountNumberRepository.findById(ACCOUNT_NUMBER_LONG))
        .thenReturn(
            Optional.of(AccountNumber.builder().accountNumber(ACCOUNT_NUMBER_LONG).build()));

    final AccountServiceException thrown =
        assertThrows(
            AccountServiceException.class,
            () ->
                accountService.deleteWarningForAccount(
                    ACCOUNT_NUMBER, warningCode, requestMetadata));

    assertThat(
        thrown.getMessage(), is("Failed to find restriction type CA for request ID: " + requestId));
    verifyNoInteractions(accountWarningRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void deleteWarningForAccountShouldThrowExceptionWhenAccountNotFound() {
    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);

    final WarningCode warningCode =
        TestHelper.buildWarningCode(WARNING_CODE, "notes", SERVICE_SCHEMA_USER, PARTY_ID_LONG);

    when(accountNumberRepository.findById(ACCOUNT_NUMBER_LONG)).thenReturn(Optional.empty());

    final AccountServiceException thrown =
        assertThrows(
            AccountServiceException.class,
            () ->
                accountService.deleteWarningForAccount(
                    ACCOUNT_NUMBER, warningCode, requestMetadata));

    assertThat(
        thrown.getMessage(),
        is("Failed to find account " + ACCOUNT_NUMBER + " for request ID: " + requestId));
    verifyNoInteractions(accountWarningRepository);
    verifyNoInteractions(restrictionTypeRepository);
    verifyNoInteractions(workLogRepository);
  }

  @Test
  void deleteAccountWarningShouldNotWriteAWorkLogWhenAccountIsInBlacklist() {

    final RequestMetadata requestMetadata =
        TestHelper.buildValidRequestMetadata(requestId, PARTY_ID);
    final WarningCode warningCode =
        TestHelper.buildWarningCode(WARNING_CODE, "notes", SERVICE_SCHEMA_USER, PARTY_ID_LONG);

    when(accountServiceProperties.getAccountNumberBlacklist())
        .thenReturn(Collections.singletonList(ACCOUNT_NUMBER));

    accountService.deleteWarningForAccount(ACCOUNT_NUMBER, warningCode, requestMetadata);

    verifyNoInteractions(workLogRepository);
  }

  @ParameterizedTest
  @MethodSource("warningArgsForPartyId") // NOPMD
  public void shouldReturnWarningsForAccountForGivenPartyId(
      final boolean includeShareplanAccounts, final String partyId) {
    final List<LinkedPartyDetails> linkedPartyDetailList = new ArrayList<>();
    linkedPartyDetailList.add(LinkedPartyDetails.builder().partyId(Long.valueOf(PARTY_ID)).build());
    when(partyRepository.findLinkedParties(any())).thenReturn(linkedPartyDetailList);
    final Account accounts =
        Account.builder()
            .accountNumber(ACCOUNT_NUMBER_LONG)
            .openedDate(ACCOUNT_OPENED_DATE_TIME)
            .build();
    final List<Account> accountList = Collections.singletonList(accounts);
    final List<Long> accountNumbers =
        accountList.stream().map(Account::getAccountNumber).collect(Collectors.toList());
    when(accountNumberRepository.findAccountNumbersByPartyIdAndAccountType(any(), any(), any()))
        .thenReturn(accountList);
    when(accountWarningRepository.findActiveAccountWarningsByAccountNumberAndDate(
            accountNumbers, NOW))
        .thenReturn(
            Collections.singletonList(
                AccountWarning.builder()
                    .accountNumber(
                        AccountNumber.builder()
                            .accountNumber(ACCOUNT_NUMBER_LONG)
                            .tableId(AccountNumber.TABLE_ID_SAVACC)
                            .build())
                    .restrictionType(
                        RestrictionType.builder().code(WARNING_CODE).description("test1").build())
                    .build()));
    final AccountWarningsResponse expectedResponse =
        AccountWarningsResponse.builder()
            .savings(
                AccountWarnings.builder()
                    .account(
                        Collections.singleton(
                            AccountWarningSummary.builder()
                                .accountNumber("123")
                                .openedDate(ACCOUNT_OPENED_DATE_TIME)
                                .accountWarnings(
                                    Collections.singleton(
                                        Warning.builder().code("CA").description("test1").build()))
                                .build()))
                    .build())
            .build();
    final AccountWarningsResponse accountWarningResponse =
        accountService.getAccountWarningsByPartyId(includeShareplanAccounts, partyId);
    assertThat(expectedResponse, is(accountWarningResponse));
  }

  @ParameterizedTest
  @MethodSource("warningArgsForPartyId") // NOPMD
  public void
      getAccountWarningsByPartyIdShouldReturnAccountWarningsResourceNotFoundExceptionWhenPartyIdNotPresent(
          final boolean includeShareplanAccounts, final String partyId) {
    final List<LinkedPartyDetails> linkedPartyDetailList = new ArrayList<>();
    when(partyRepository.findLinkedParties(any())).thenReturn(linkedPartyDetailList);
    final AccountWarningsResourceNotFoundException thrown =
        assertThrows(
            AccountWarningsResourceNotFoundException.class,
            () -> accountService.getAccountWarningsByPartyId(includeShareplanAccounts, partyId));

    assertThat(thrown.getMessage(), is(String.format("No parties found for Party ID %s", partyId)));
  }

  @ParameterizedTest
  @MethodSource("warningArgsForPartyId") // NOPMD
  public void getAccountWarningsByPartyIdShouldReturnEmptyResponseWhenAccountNumberNotPresent(
      final boolean includeShareplanAccounts, final String partyId) {
    final List<LinkedPartyDetails> linkedPartyDetailList = new ArrayList<>();
    linkedPartyDetailList.add(LinkedPartyDetails.builder().partyId(Long.valueOf(PARTY_ID)).build());
    when(partyRepository.findLinkedParties(any())).thenReturn(linkedPartyDetailList);
    when(accountNumberRepository.findAccountNumbersByPartyIdAndAccountType(any(), any(), any()))
        .thenReturn(Collections.emptyList());
    final AccountWarningsResponse accountWarnings =
        accountService.getAccountWarningsByPartyId(includeShareplanAccounts, partyId);
    Assertions.assertNull(accountWarnings.getSavings());
    Assertions.assertNull(accountWarnings.getShareplan());
  }

  @ParameterizedTest
  @MethodSource("warningArgsForPartyId") // NOPMD
  public void getAccountWarningsByPartyIdShouldReturnEmptyResponseWhenNoWarningsPresent(
      final boolean includeShareplanAccounts, final String partyId) {
    final List<LinkedPartyDetails> linkedPartyDetailList = new ArrayList<>();
    linkedPartyDetailList.add(LinkedPartyDetails.builder().partyId(Long.valueOf(PARTY_ID)).build());
    when(partyRepository.findLinkedParties(any())).thenReturn(linkedPartyDetailList);
    final Account accounts =
        Account.builder()
            .accountNumber(ACCOUNT_NUMBER_LONG)
            .openedDate(ACCOUNT_OPENED_DATE_TIME)
            .build();
    final List<Account> accountList = Collections.singletonList(accounts);
    final List<Long> accountNumbers =
        accountList.stream().map(Account::getAccountNumber).collect(Collectors.toList());
    when(accountNumberRepository.findAccountNumbersByPartyIdAndAccountType(any(), any(), any()))
        .thenReturn(accountList);
    when(accountWarningRepository.findActiveAccountWarningsByAccountNumberAndDate(
            accountNumbers, NOW))
        .thenReturn(Collections.emptyList());
    final AccountWarningsResponse accountWarnings =
        accountService.getAccountWarningsByPartyId(includeShareplanAccounts, partyId);
    Assertions.assertNull(accountWarnings.getSavings());
    Assertions.assertNull(accountWarnings.getShareplan());
  }

  private static Stream<Arguments> warningArgsForPartyId() {
    return Stream.of(Arguments.of(true, PARTY_ID), Arguments.of(false, PARTY_ID));
  }
}
