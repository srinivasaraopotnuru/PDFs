package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.account.model.adgcore.Account;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.ActivityType;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
class AccountNumberRepositoryTest {

  private static final LocalDateTime NOW = LocalDateTime.parse("2020-05-25T13:56:22");
  private static final LocalDateTime ACCOUNT_OPENED_DATE = NOW.minusDays(200);

  private static final Long PARTY_ID_1 = 1001L;
  private static final Long ACCOUNT_NUMBER_1 = 2001L;
  private static final Long ACCOUNT_NUMBER_2 = 3001L;
  private static final Long ACTIVITY_PLAYER_SYSID_1 = 4001L;
  private static final Long ACTIVITY_PLAYER_SYSID_2 = 5001L;
  private static final Long SAVINGS_PRODUCT_SYSID_1 = 6001L;
  private static final Long SAVINGS_PRODUCT_SYSID_2 = 7001L;
  private static final String ACTIVITY_TYPE_CODE = "ACTTYP";
  private static final String BRAND_YBS = "YBS";

  @Autowired AccountNumberRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;
  @Autowired TransactionTemplate transactionTemplate;

  private TestHelper testHelper;

  @BeforeEach
  void setup() {
    testHelper = new TestHelper(adgCoreTestEntityManager);
  }

  @Test
  void shouldFindById() {
    final SavingProduct savingProduct = testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final AccountNumber persisted =
        testHelper.persistAccountNumberForSavingProduct(ACCOUNT_NUMBER_1, savingProduct);

    final Optional<AccountNumber> found = testSubject.findById(ACCOUNT_NUMBER_1);

    assertThat(found.isPresent(), is(true));
    assertThat(found.get(), samePropertyValuesAs(persisted));
  }

  @Test
  void shouldFindOpenAndClosedAccounts() {
    final SavingProduct savingProduct = testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final ActivityType activityType = testHelper.persistActivityType(ACTIVITY_TYPE_CODE, NOW, null);
    final AccountNumber closedAccountNumber =
        setUpAccountNumber(
            ACCOUNT_NUMBER_1,
            savingProduct,
            activityType,
            ACTIVITY_PLAYER_SYSID_1,
            NOW.minusDays(1));
    final AccountNumber openAccountNumber =
        setUpOpenAccountNumber(
            ACCOUNT_NUMBER_2, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_2);

    final Collection<AccountNumber> found =
        testSubject.findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
            PARTY_ID_1, Collections.singletonList(BRAND_YBS), NOW.minusDays(2));

    assertThat(found.size(), is(2));
    assertThat(found, containsInAnyOrder(openAccountNumber, closedAccountNumber));
  }

  @Test
  void shouldFindByBrand() {
    final SavingProduct ybsSavingProduct =
        testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final SavingProduct nonYbsSavingProduct =
        testHelper.persistSavingProductWithBrandCode(SAVINGS_PRODUCT_SYSID_2, "OTHER");
    final ActivityType activityType = testHelper.persistActivityType(ACTIVITY_TYPE_CODE, NOW, null);
    final AccountNumber ybsAccountNumber =
        setUpOpenAccountNumber(
            ACCOUNT_NUMBER_1, ybsSavingProduct, activityType, ACTIVITY_PLAYER_SYSID_1);
    setUpOpenAccountNumber(
        ACCOUNT_NUMBER_2, nonYbsSavingProduct, activityType, ACTIVITY_PLAYER_SYSID_2);

    final Collection<AccountNumber> found =
        testSubject.findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
            PARTY_ID_1, Collections.singletonList(BRAND_YBS), NOW);

    assertThat(found.size(), is(1));
    assertThat(found, contains(ybsAccountNumber));
  }

  @Test
  void shouldOnlyFindClosedAccountsClosedSinceEarliestDate() {
    final SavingProduct savingProduct = testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final ActivityType activityType = testHelper.persistActivityType(ACTIVITY_TYPE_CODE, NOW, null);
    final AccountNumber shouldBeFoundAccountNumber =
        setUpAccountNumber(
            ACCOUNT_NUMBER_1,
            savingProduct,
            activityType,
            ACTIVITY_PLAYER_SYSID_1,
            NOW.minusDays(1));
    setUpAccountNumber(
        ACCOUNT_NUMBER_2, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_2, NOW.minusDays(3));

    final Collection<AccountNumber> found =
        testSubject.findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
            PARTY_ID_1, Collections.singletonList(BRAND_YBS), NOW.minusDays(2));

    assertThat(found.size(), is(1));
    assertThat(found, contains(shouldBeFoundAccountNumber));
  }

  @Test
  void shouldOnlyFindAccountsWithUnendedActivityPlayer() {
    final SavingProduct savingProduct = testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final ActivityType activityType = testHelper.persistActivityType(ACTIVITY_TYPE_CODE, NOW, null);
    final AccountNumber shouldBeFoundAccountNumber =
        setUpOpenAccountNumber(
            ACCOUNT_NUMBER_1, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_1);
    setUpOpenAccountNumberWithActivityPlayerEndDate(
        ACCOUNT_NUMBER_2, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_2, NOW);

    final Collection<AccountNumber> found =
        testSubject.findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
            PARTY_ID_1, Collections.singletonList(BRAND_YBS), NOW);

    assertThat(found.size(), is(1));
    assertThat(found, contains(shouldBeFoundAccountNumber));
  }

  @Test
  void shouldOnlyFindAccountsWhenActivityPlayerExistsForAccountNumber() {
    final SavingProduct savingProduct = testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final ActivityType activityType = testHelper.persistActivityType(ACTIVITY_TYPE_CODE, NOW, null);
    final AccountNumber shouldBeFoundAccountNumber =
        setUpOpenAccountNumber(
            ACCOUNT_NUMBER_1, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_1);
    setUpOpenAccountNumberWithoutActivityPlayer(
        ACCOUNT_NUMBER_2, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_2);

    final Collection<AccountNumber> found =
        testSubject.findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
            PARTY_ID_1, Collections.singletonList(BRAND_YBS), NOW);

    assertThat(found.size(), is(1));
    assertThat(found, contains(shouldBeFoundAccountNumber));
  }

  @Test
  void shouldOnlyFindAccountsWhenSavingsAccountForAccountNumber() {
    final SavingProduct savingProduct = testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final ActivityType activityType = testHelper.persistActivityType(ACTIVITY_TYPE_CODE, NOW, null);
    final AccountNumber shouldBeFoundAccountNumber =
        setUpOpenAccountNumber(
            ACCOUNT_NUMBER_1, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_1);
    setUpOpenAccountNumberWithoutSavingAccount(
        ACCOUNT_NUMBER_2, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_2);

    final Collection<AccountNumber> found =
        testSubject.findAccountNumbersByPartySysIdAndBrandCodesOpenOrClosedSinceEarliestDate(
            PARTY_ID_1, Collections.singletonList(BRAND_YBS), NOW);

    assertThat(found.size(), is(1));
    assertThat(found, contains(shouldBeFoundAccountNumber));
  }

  private AccountNumber setUpOpenAccountNumber(
      final Long accountNumber,
      final SavingProduct savingProduct,
      final ActivityType activityType,
      final Long activityPlayerdSysId) {
    return setUpAccountNumber(
        accountNumber, savingProduct, activityType, activityPlayerdSysId, null);
  }

  private AccountNumber setUpAccountNumber(
      final Long accountNumber,
      final SavingProduct savingProduct,
      final ActivityType activityType,
      final Long activityPlayerdSysId,
      final LocalDateTime closedDate) {
    final AccountNumber createdAccountNumber =
        testHelper.persistAccountNumberForSavingProduct(accountNumber, savingProduct);
    testHelper.persistActivityPlayerForAccountNumber(
        activityPlayerdSysId, createdAccountNumber, PARTY_ID_1, activityType, NOW, null);
    testHelper.persistSavingAccount(
        accountNumber, AccountNumberRepositoryTest.ACCOUNT_OPENED_DATE, closedDate);
    return createdAccountNumber;
  }

  private AccountNumber setUpOpenAccountNumberWithActivityPlayerEndDate(
      final Long accountNumber,
      final SavingProduct savingProduct,
      final ActivityType activityType,
      final Long activityPlayerdSysId,
      final LocalDateTime activityPlayerEndDate) {
    final AccountNumber createdAccountNumber =
        testHelper.persistAccountNumberForSavingProduct(accountNumber, savingProduct);
    testHelper.persistActivityPlayerForAccountNumber(
        activityPlayerdSysId,
        createdAccountNumber,
        PARTY_ID_1,
        activityType,
        NOW,
        activityPlayerEndDate);
    testHelper.persistSavingAccount(accountNumber, ACCOUNT_OPENED_DATE, null);
    return createdAccountNumber;
  }

  private AccountNumber setUpOpenAccountNumberWithoutActivityPlayer(
      final Long accountNumber,
      final SavingProduct savingProduct,
      final ActivityType activityType,
      final Long activityPlayerdSysId) {
    final AccountNumber createdAccountNumber =
        testHelper.persistAccountNumberForSavingProduct(accountNumber, savingProduct);
    final AccountNumber activityPlayerAccountNumber =
        new AccountNumber(9999L, AccountNumber.TABLE_ID_SAVACC, savingProduct.getSysid());
    testHelper.persistActivityPlayerForAccountNumber(
        activityPlayerdSysId, activityPlayerAccountNumber, PARTY_ID_1, activityType, NOW, null);
    testHelper.persistSavingAccount(accountNumber, ACCOUNT_OPENED_DATE, null);
    return createdAccountNumber;
  }

  private AccountNumber setUpOpenAccountNumberWithoutSavingAccount(
      final Long accountNumber,
      final SavingProduct savingProduct,
      final ActivityType activityType,
      final Long activityPlayerdSysId) {
    final AccountNumber createdAccountNumber =
        testHelper.persistAccountNumberForSavingProduct(accountNumber, savingProduct);
    testHelper.persistActivityPlayerForAccountNumber(
        activityPlayerdSysId, createdAccountNumber, PARTY_ID_1, activityType, NOW, null);
    return createdAccountNumber;
  }

  @Test
  void
      findAccountNumbersByPartyIdAndAccountTypeShouldReturnAccountNumbersWithUnendedActivityPlayer() {
    final SavingProduct savingProduct = testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final ActivityType activityType = testHelper.persistActivityType(ACTIVITY_TYPE_CODE, NOW, null);
    setUpOpenAccountNumber(ACCOUNT_NUMBER_1, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_1);
    final List<Long> partyNList = new ArrayList<>();
    partyNList.add(PARTY_ID_1);
    final List<String> accountTypes =
        new ArrayList<>(Collections.singletonList(AccountNumber.TABLE_ID_SAVACC));
    accountTypes.add(AccountNumber.TABLE_ID_CBACC);
    setUpOpenAccountNumberWithActivityPlayerEndDate(
        ACCOUNT_NUMBER_2, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_2, NOW);

    final List<Account> found =
        testSubject.findAccountNumbersByPartyIdAndAccountType(partyNList, accountTypes, NOW);

    assertThat(found.size(), is(1));
    assertEquals(found.get(0).getAccountNumber(), ACCOUNT_NUMBER_1);
    assertEquals(found.get(0).getOpenedDate(), AccountNumberRepositoryTest.ACCOUNT_OPENED_DATE);
  }

  @Test
  void
      findAccountNumbersByPartyIdAndAccountTypeShouldReturnAccountNumbersWhenActivityPlayerExistsForAccountNumber() {
    final SavingProduct savingProduct = testHelper.persistYbsSavingProduct(SAVINGS_PRODUCT_SYSID_1);
    final ActivityType activityType = testHelper.persistActivityType(ACTIVITY_TYPE_CODE, NOW, null);
    setUpOpenAccountNumber(ACCOUNT_NUMBER_1, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_1);
    setUpOpenAccountNumberWithoutActivityPlayer(
        ACCOUNT_NUMBER_2, savingProduct, activityType, ACTIVITY_PLAYER_SYSID_2);
    final List<Long> partyNList = new ArrayList<>();
    partyNList.add(PARTY_ID_1);
    final List<String> accountTypes =
        new ArrayList<>(Collections.singletonList(AccountNumber.TABLE_ID_SAVACC));
    accountTypes.add(AccountNumber.TABLE_ID_CBACC);
    final List<Account> found =
        testSubject.findAccountNumbersByPartyIdAndAccountType(partyNList, accountTypes, NOW);
    assertThat(found.size(), is(1));
    assertEquals(found.get(0).getAccountNumber(), ACCOUNT_NUMBER_1);
    assertEquals(found.get(0).getOpenedDate(), AccountNumberRepositoryTest.ACCOUNT_OPENED_DATE);
  }
}
