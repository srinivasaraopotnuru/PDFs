package uk.co.ybs.digital.account.service;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AuthenticMessageException;
import uk.co.ybs.digital.account.repository.core.AuthenticMessageRepository;

/** The Class AuthenticMessageServiceTest. */
@ExtendWith(MockitoExtension.class)
public class AuthenticMessageServiceTest {

  @Mock private AuthenticMessageRepository authenticMessageRepository;

  @InjectMocks private AuthenticMessageService service;

  /**
   * Test that we get a result back form the service.
   *
   * @throws IOException
   * @throws AuthenticMessageException
   */
  @Test
  void shouldWriteAuthenticMesage() throws AuthenticMessageException, IOException {

    when(authenticMessageRepository.writeAuthenticMessage(
            any(), any(), any(), any(), anyInt(), any(LocalDateTime.class)))
        .thenReturn(1);
    final long accNum = 1234567890L;
    service.setClock(
        Clock.fixed(Instant.parse("2021-12-01T00:00:00Z"), ZoneId.of("Europe/London")));
    final int updCount =
        service.writeAuthenticMessage("123456", accNum, AuthenticMessageService.STATUS_C);
    assertEquals(1, updCount);
  }

  @Test
  void shouldThrowAuthenticMessageException() throws IOException {
    when(authenticMessageRepository.writeAuthenticMessage(
            any(), any(), any(), any(), anyInt(), any(LocalDateTime.class)))
        .thenThrow(new AuthenticMessageException("exception while calling procedure."));
    final long accNum = 1234567890L;
    service.setClock(
        Clock.fixed(Instant.parse("2021-12-01T00:00:00Z"), ZoneId.of("Europe/London")));
    assertThrows(
        AuthenticMessageException.class,
        () -> service.writeAuthenticMessage("123456", accNum, AuthenticMessageService.STATUS_C));
  }
}
