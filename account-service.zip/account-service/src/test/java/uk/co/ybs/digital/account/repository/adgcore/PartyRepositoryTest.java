package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertFalse;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.account.model.adgcore.LinkedParty;
import uk.co.ybs.digital.account.model.adgcore.LinkedPartyDetails;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class PartyRepositoryTest {
  @Autowired PartyRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @Autowired TransactionTemplate transactionTemplate;

  @ParameterizedTest
  @MethodSource("linkedPartyDetails")
  public void findLinkedPartiesReturnsSuccess(
      final String partySysId, final int linkedPartiesCount) {
    final List<LinkedPartyDetails> linkedPartyDetails = testSubject.findLinkedParties(partySysId);
    assertFalse(linkedPartyDetails.isEmpty());
  }

  @ParameterizedTest
  @MethodSource("linkedParties")
  void findCanonicalPartyIdReturnsCanonicalIdAndNumberOfLinks(
      final Long originalPartyId, final Optional<LinkedParty> expected) {
    transactionTemplate.executeWithoutResult(
        status -> {
          adgCoreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (0, NULL)")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (1, 0)")
              .executeUpdate();
          adgCoreTestEntityManager
              .getEntityManager()
              .createNativeQuery("INSERT INTO PARTIES (SYSID, PARTY_LINK_SYSID) VALUES (2, 1)")
              .executeUpdate();
        });

    final Optional<LinkedParty> actual = testSubject.findCanonicalPartyId(originalPartyId);
    assertThat(actual, equalTo(expected));
  }

  private static Stream<Arguments> linkedPartyDetails() {
    return Stream.of(Arguments.of("4567890124", 3));
  }

  public static Stream<Arguments> linkedParties() {
    return Stream.of(
        Arguments.of(
            0L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(0L)
                    .canonicalPartyId(0L)
                    .linkCount((0L))
                    .build())),
        Arguments.of(
            1L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(1L)
                    .canonicalPartyId(0L)
                    .linkCount((1L))
                    .build())),
        Arguments.of(
            2L,
            Optional.of(
                LinkedParty.builder()
                    .originalPartyId(2L)
                    .canonicalPartyId(0L)
                    .linkCount((2L))
                    .build())),
        Arguments.of(3L, Optional.empty()));
  }
}
