package uk.co.ybs.digital.account.service.audit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.account.utils.TestHelper.readClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsUpdateFailureRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountDetailsUpdateSuccessRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountListRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditAccountTransactionsRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditIsaDeclarationSubmissionFailureRequest;
import uk.co.ybs.digital.account.service.audit.dto.AuditIsaDeclarationSubmissionSuccessRequest;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@JsonTest
class AuditServiceTest {

  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Audit service returned error status: ";

  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final String FORWARDING_AUTH = "<jwt>";
  private static final String ACCOUNT_NUMBER = "2372146519";
  private static final String START_DATE = "2019-02-01T10:00:00Z";
  private static final String END_DATE = "2020-02-01T10:00:00Z";
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String BEARER = "Bearer ";

  private AuditService auditService;
  private MockWebServer mockWebServer;

  @Autowired private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start();

    final WebClient webClient =
        WebClient.builder()
            .baseUrl("http://localhost:" + mockWebServer.getPort())
            .codecs(
                configurer -> {
                  configurer
                      .defaultCodecs()
                      .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                  configurer
                      .defaultCodecs()
                      .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                })
            .build();
    auditService = new AuditService(webClient);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void shouldAuditAccountList() throws Exception {
    final AuditAccountListRequest request = buildAuditAccountListAuthRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditAccountList(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/account/list"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource("api/auditService/request/auditAccountList/request.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditAccountDetails() throws Exception {
    final AuditAccountDetailsRequest request = buildAuditAccountDetailsAuthRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditAccountDetails(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/account/detail"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource("api/auditService/request/auditAccountDetails/request.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditAccountTransactions() throws Exception {
    final AuditAccountTransactionsRequest request = buildAuditAccountTransactionsAuthRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditAccountTransactions(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/account/transactions"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditAccountTransactions/requestWithDates.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditIsaDeclarationSubmissionSuccess() throws Exception {
    final AuditIsaDeclarationSubmissionSuccessRequest request =
        buildAuditIsaDeclarationSubmissionSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditIsaDeclarationSubmissionSuccess(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/account/isa-declaration/success"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditSubmitIsaDeclaration/successRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditIsaDeclarationSubmissionFailure() throws Exception {
    final AuditIsaDeclarationSubmissionFailureRequest request =
        buildAuditIsaDeclarationSubmissionFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditIsaDeclarationSubmissionFailure(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/account/isa-declaration/failure"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditSubmitIsaDeclaration/failureRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditUpdateAccountDetailsSuccess() throws Exception {
    final AuditAccountDetailsUpdateSuccessRequest request =
        buildAuditAccountDetailsUpdateSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditAccountDetailsUpdateSuccess(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/account/update/success"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditAccountDetailsUpdate/successRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldAuditUpdateAccountDetailsFailure() throws Exception {
    final AuditAccountDetailsUpdateFailureRequest request =
        buildAuditAccountDetailsUpdateFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditAccountDetailsUpdateFailure(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/account/update/failure"));
    assertThat(recordedRequest.getHeader(HttpHeaders.AUTHORIZATION), is(BEARER + FORWARDING_AUTH));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(REQUEST_ID.toString()));

    final String expectedBody =
        readClassPathResource(
            "api/auditService/request/auditAccountDetailsUpdate/failureRequest.json");
    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("auditMethods")
  void shouldThrowAuditServiceExceptionForConnectionError(
      final Function<AuditService, Executable> auditMethod) throws IOException {
    mockWebServer.shutdown();

    final AuditServiceException exception =
        assertThrows(AuditServiceException.class, auditMethod.apply(auditService));
    assertThat(exception.getMessage(), is(equalTo("Error calling audit service")));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  private static Stream<Function<AuditService, Executable>> auditMethods() {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    return Stream.of(
        service ->
            () -> service.auditAccountList(buildAuditAccountListAuthRequest(), requestMetadata),
        service ->
            () ->
                service.auditAccountDetails(buildAuditAccountDetailsAuthRequest(), requestMetadata),
        service ->
            () ->
                service.auditAccountTransactions(
                    buildAuditAccountTransactionsAuthRequest(), requestMetadata),
        service ->
            () ->
                service.auditIsaDeclarationSubmissionSuccess(
                    buildAuditIsaDeclarationSubmissionSuccessRequest(), requestMetadata),
        service ->
            () ->
                service.auditIsaDeclarationSubmissionFailure(
                    buildAuditIsaDeclarationSubmissionFailureRequest(), requestMetadata),
        service ->
            () ->
                service.auditAccountDetailsUpdateSuccess(
                    buildAuditAccountDetailsUpdateSuccessRequest(), requestMetadata),
        service ->
            () ->
                service.auditAccountDetailsUpdateFailure(
                    buildAuditAccountDetailsUpdateFailureRequest(), requestMetadata));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses") // NOPMD
  void auditAccountListShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuditAccountListRequest auditRequest = buildAuditAccountListAuthRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditAccountList(auditRequest, requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses") // NOPMD
  void auditAccountDetailsShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuditAccountDetailsRequest auditRequest = buildAuditAccountDetailsAuthRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditAccountDetails(auditRequest, requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses") // NOPMD
  void auditAccountTransactionsShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuditAccountTransactionsRequest auditRequest = buildAuditAccountTransactionsAuthRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditAccountTransactions(auditRequest, requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses") // NOPMD
  void
      auditIsaDeclarationSubmissionSuccessShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
          final HttpStatus responseStatus,
          final MediaType responseContentType,
          final String responseBody,
          final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuditIsaDeclarationSubmissionSuccessRequest auditRequest =
        buildAuditIsaDeclarationSubmissionSuccessRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditIsaDeclarationSubmissionSuccess(auditRequest, requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses") // NOPMD
  void
      auditIsaDeclarationSubmissionFailureShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
          final HttpStatus responseStatus,
          final MediaType responseContentType,
          final String responseBody,
          final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final AuditIsaDeclarationSubmissionFailureRequest auditRequest =
        buildAuditIsaDeclarationSubmissionFailureRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata();

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditIsaDeclarationSubmissionFailure(auditRequest, requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  private static Stream<Arguments> auditServiceErrorResponses() throws IOException {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/errorResponseInvalidSignature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.FORBIDDEN.value()),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/errorResponseBadRequest.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.BAD_REQUEST.value()),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/unexpectedResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.BAD_REQUEST.value())),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/emptyResponse.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.BAD_REQUEST.value())),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.BAD_REQUEST.value())),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readClassPathResource("api/auditService/response/textResponse.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + HttpStatus.BAD_REQUEST.value())));
  }

  private static AuditAccountListRequest buildAuditAccountListAuthRequest() {
    return AuditAccountListRequest.builder().ipAddress(IP_ADDRESS).build();
  }

  private static AuditAccountDetailsRequest buildAuditAccountDetailsAuthRequest() {
    return AuditAccountDetailsRequest.builder()
        .ipAddress(IP_ADDRESS)
        .accountInformation(
            AuditAccountDetailsRequest.AccountInformation.builder()
                .accountNumber(ACCOUNT_NUMBER)
                .build())
        .build();
  }

  private static AuditAccountTransactionsRequest buildAuditAccountTransactionsAuthRequest() {
    return AuditAccountTransactionsRequest.builder()
        .ipAddress(IP_ADDRESS)
        .accountInformation(
            AuditAccountTransactionsRequest.AccountInformation.builder()
                .accountNumber(ACCOUNT_NUMBER)
                .startDate(START_DATE)
                .endDate(END_DATE)
                .build())
        .build();
  }

  private static AuditIsaDeclarationSubmissionSuccessRequest
      buildAuditIsaDeclarationSubmissionSuccessRequest() {
    return AuditIsaDeclarationSubmissionSuccessRequest.builder()
        .ipAddress(IP_ADDRESS)
        .accountInformation(
            AuditIsaDeclarationSubmissionSuccessRequest.AccountInformation.builder()
                .accountNumber(ACCOUNT_NUMBER)
                .build())
        .build();
  }

  private static AuditIsaDeclarationSubmissionFailureRequest
      buildAuditIsaDeclarationSubmissionFailureRequest() {
    return AuditIsaDeclarationSubmissionFailureRequest.builder()
        .ipAddress(IP_ADDRESS)
        .message("audit message")
        .accountInformation(
            AuditIsaDeclarationSubmissionFailureRequest.AccountInformation.builder()
                .accountNumber(ACCOUNT_NUMBER)
                .build())
        .build();
  }

  private static AuditAccountDetailsUpdateSuccessRequest
      buildAuditAccountDetailsUpdateSuccessRequest() {
    return AuditAccountDetailsUpdateSuccessRequest.builder()
        .ipAddress(IP_ADDRESS)
        .accountName("new name")
        .accountInformation(
            AuditAccountDetailsUpdateSuccessRequest.AccountInformation.builder()
                .accountNumber(ACCOUNT_NUMBER)
                .build())
        .build();
  }

  private static AuditAccountDetailsUpdateFailureRequest
      buildAuditAccountDetailsUpdateFailureRequest() {
    return AuditAccountDetailsUpdateFailureRequest.builder()
        .ipAddress(IP_ADDRESS)
        .accountName("new name")
        .message("audit message")
        .accountInformation(
            AuditAccountDetailsUpdateFailureRequest.AccountInformation.builder()
                .accountNumber(ACCOUNT_NUMBER)
                .build())
        .build();
  }

  private static RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .host(InetSocketAddress.createUnresolved("localhost", 80))
        .partyId("1234567891")
        .brandCode("YBS")
        .forwardingAuth(FORWARDING_AUTH)
        .ipAddress(IP_ADDRESS)
        .build();
  }
}
