package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.samePropertyValuesAs;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.SavingProduct;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
class SavingProductRepositoryTest {

  private static final Long ACCOUNT_NUMBER = 12345678L;
  private static final Long ACCOUNT_NUMBER_OTHER = 22345678L;
  private static final String PRODUCT_IDENTIFIER = "PROD_IDENT";
  private static final String BRAND_CODE_YBS = "YBS";
  private static final String BRAND_CODE_CHELSEA = "CHE";

  @Autowired private SavingProductRepository testSubject;

  @Autowired private TestEntityManager adgCoreTestEntityManager;

  @Test
  void shouldFindSavingProduct() {
    final SavingProduct savingProduct1 =
        adgCoreTestEntityManager.persistAndFlush(
            new SavingProduct(1L, BRAND_CODE_YBS, PRODUCT_IDENTIFIER));
    final SavingProduct savingProduct2 =
        adgCoreTestEntityManager.persistAndFlush(
            new SavingProduct(2L, BRAND_CODE_CHELSEA, PRODUCT_IDENTIFIER));
    adgCoreTestEntityManager.persistAndFlush(
        new AccountNumber(
            ACCOUNT_NUMBER, AccountNumber.TABLE_ID_SAVACC, savingProduct1.getSysid()));
    adgCoreTestEntityManager.persistAndFlush(
        new AccountNumber(
            ACCOUNT_NUMBER_OTHER, AccountNumber.TABLE_ID_SAVACC, savingProduct2.getSysid()));
    adgCoreTestEntityManager.clear();

    final Optional<SavingProduct> foundSavingProduct =
        testSubject.findBySavingAccountNumber(ACCOUNT_NUMBER);
    assertThat(foundSavingProduct.isPresent(), is(true));
    assertThat(foundSavingProduct.get(), samePropertyValuesAs(savingProduct1));
  }

  @Test
  void shouldNotFindSavingProduct() {
    final Optional<SavingProduct> foundSavingProduct =
        testSubject.findBySavingAccountNumber(ACCOUNT_NUMBER);
    assertThat(foundSavingProduct.isPresent(), is(false));
  }

  @Test
  void shouldExcludeNonSavingAccounts() {
    final SavingProduct savingProduct =
        adgCoreTestEntityManager.persistAndFlush(
            new SavingProduct(1L, BRAND_CODE_YBS, PRODUCT_IDENTIFIER));
    adgCoreTestEntityManager.persistAndFlush(
        new AccountNumber(ACCOUNT_NUMBER, "CBACC", savingProduct.getSysid()));
    adgCoreTestEntityManager.clear();

    final Optional<SavingProduct> foundSavingProduct =
        testSubject.findBySavingAccountNumber(ACCOUNT_NUMBER);
    assertThat(foundSavingProduct.isPresent(), is(false));
  }

  @Test
  void shouldFindById() {
    final SavingProduct savingProduct =
        adgCoreTestEntityManager.persistAndFlush(
            new SavingProduct(1L, BRAND_CODE_YBS, PRODUCT_IDENTIFIER));
    adgCoreTestEntityManager.persistAndFlush(
        new AccountNumber(ACCOUNT_NUMBER, AccountNumber.TABLE_ID_SAVACC, savingProduct.getSysid()));
    adgCoreTestEntityManager.clear();

    final Optional<SavingProduct> foundSavingProduct = testSubject.findById(1L);
    assertThat(foundSavingProduct.isPresent(), is(true));
    assertThat(foundSavingProduct.get(), samePropertyValuesAs(savingProduct));
  }
}
