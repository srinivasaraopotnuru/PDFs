package uk.co.ybs.digital.account.service.mapper;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import uk.co.ybs.digital.account.model.adgcore.AccountWarningRestrictionRule;
import uk.co.ybs.digital.account.model.adgcore.RestrictionTypeRule;

public class AmendmentRestrictionMapperTest {
  private static final Long ACCOUNT_NUMBER = 1L;

  private AmendmentRestrictionMapper testSubject;

  @BeforeEach
  void beforeEach() {
    testSubject = new AmendmentRestrictionMapper();
  }

  @ParameterizedTest
  @MethodSource("testCombinations")
  void shouldMapAmendmentRestrictionFlag(
      final List<AccountWarningRestrictionRule> rules, final boolean expected) {
    final boolean result = testSubject.amendmentRestricted(rules);

    assertThat(result, is(expected));
  }

  private static Stream<Arguments> testCombinations() {
    final AccountWarningRestrictionRule isaTransfer =
        buildRestrictionRule(RestrictionTypeRule.CODE_ISA_TRANSFER);
    final AccountWarningRestrictionRule webAccess =
        buildRestrictionRule(RestrictionTypeRule.CODE_WEB_ACCESS);
    final AccountWarningRestrictionRule webReceipts =
        buildRestrictionRule(RestrictionTypeRule.CODE_WEB_RECEIPTS);
    final AccountWarningRestrictionRule webRegister =
        buildRestrictionRule(RestrictionTypeRule.CODE_WEB_REGISTER);
    final AccountWarningRestrictionRule webText =
        buildRestrictionRule(RestrictionTypeRule.CODE_WEB_TEXT);
    final AccountWarningRestrictionRule webWithdrawals =
        buildRestrictionRule(RestrictionTypeRule.CODE_WEB_WITHDRAWALS);
    final AccountWarningRestrictionRule wrong = buildRestrictionRule("wrongcode");

    return Stream.of(
        Arguments.of(Collections.singletonList(isaTransfer), true),
        Arguments.of(Collections.singletonList(webAccess), true),
        Arguments.of(Collections.singletonList(webReceipts), true),
        Arguments.of(Collections.singletonList(webRegister), true),
        Arguments.of(Collections.singletonList(webText), true),
        Arguments.of(Collections.singletonList(webWithdrawals), true),
        Arguments.of(Collections.emptyList(), false),
        Arguments.of(Collections.singletonList(wrong), false),
        Arguments.of(
            Arrays.asList(
                isaTransfer, webAccess, webReceipts, webRegister, webText, webWithdrawals),
            true),
        Arguments.of(Arrays.asList(isaTransfer, wrong), true));
  }

  private static AccountWarningRestrictionRule buildRestrictionRule(final String code) {
    return AccountWarningRestrictionRule.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .restrictionTypeRuleCode(code)
        .build();
  }
}
