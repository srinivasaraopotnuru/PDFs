package uk.co.ybs.digital.account.service.processor;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.account.exception.AccountNotFoundException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException;
import uk.co.ybs.digital.account.exception.AccountRequestProcessingException.Reason;
import uk.co.ybs.digital.account.model.adgcore.AccountNumber;
import uk.co.ybs.digital.account.model.adgcore.RestrictionType;
import uk.co.ybs.digital.account.model.core.AccountWarning;
import uk.co.ybs.digital.account.model.core.WarningNote;
import uk.co.ybs.digital.account.repository.adgcore.AccountNumberRepository;
import uk.co.ybs.digital.account.repository.adgcore.RestrictionTypeRepository;
import uk.co.ybs.digital.account.repository.core.AccountWarningCoreRepository;
import uk.co.ybs.digital.account.repository.core.WarningNoteCoreRepository;
import uk.co.ybs.digital.account.utils.TestHelper;
import uk.co.ybs.digital.account.web.dto.RequestMetadata;

@ExtendWith(MockitoExtension.class)
public class AccountWarningProcessorTest {

  private static final Long ACCOUNT_NUMBER = 1L;
  private static final Long WARNING_SYSID = 100L;
  private static final LocalDateTime PROCESS_TIME = LocalDateTime.parse("2020-05-26T14:45:01");
  private static final Long SAVING_PRODUCT_SYSID = 1L;
  private static final String RESTRICTION_TYPE_CODE = "ABC";
  private static final String CREATED_AT = "SAPP";
  private static final String CREATED_BY = "SAPP";
  private static final String NOTES = "Some Notes";

  @Mock private AccountWarningCoreRepository accountWarningCoreRepository;
  @Mock private WarningNoteCoreRepository warningNoteCoreRepository;
  @Mock private AccountNumberRepository accountNumberRepository;
  @Mock private RestrictionTypeRepository restrictionTypeRepository;
  @InjectMocks private AccountWarningProcessor testSubject;

  @Captor private ArgumentCaptor<AccountWarning> savedAccountWarning;

  @Captor private ArgumentCaptor<WarningNote> savedWarningNote;

  @Test
  void resolveShouldReturnAccount() {

    final AccountWarningRequestArguments arguments = buildRequestArguments();

    final AccountNumber account = buildAdgCoreAccountNumber();

    when(accountNumberRepository.findById(ACCOUNT_NUMBER)).thenReturn(Optional.of(account));

    final AccountNumber resolvedAccount = testSubject.resolve(arguments);

    assertThat(resolvedAccount, is(account));
  }

  @Test
  void resolveShouldThrowAccountNotFoundExceptionWhenAccountIsEmpty() {

    final AccountWarningRequestArguments arguments = buildRequestArguments();

    when(accountNumberRepository.findById(ACCOUNT_NUMBER)).thenReturn(Optional.empty());

    final AccountNotFoundException exception =
        assertThrows(AccountNotFoundException.class, () -> testSubject.resolve(arguments));

    assertThat(
        exception.getMessage(),
        is("Failed to find account " + ACCOUNT_NUMBER + " in the database"));
    verifyNoInteractions(restrictionTypeRepository);
    verifyNoInteractions(accountWarningCoreRepository);
    verifyNoInteractions(warningNoteCoreRepository);
  }

  @Test
  void executeShouldCreateWarningAndNoNotes() {
    final AccountWarningRequestArguments arguments = buildRequestArguments(null);
    final AccountNumber account =
        AccountNumber.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .tableId(AccountNumber.TABLE_ID_SAVACC)
            .savingProductSysId(SAVING_PRODUCT_SYSID)
            .build();
    final RestrictionType restrictionType =
        RestrictionType.builder().code(RESTRICTION_TYPE_CODE).startDate(PROCESS_TIME).build();
    final AccountWarning warning = buildAccountWarning();

    when(restrictionTypeRepository.findByCode(RESTRICTION_TYPE_CODE))
        .thenReturn(Optional.of(restrictionType));

    testSubject.execute(arguments, account);

    verify(accountWarningCoreRepository).saveAndFlush(savedAccountWarning.capture());

    final AccountWarning savedWarning = savedAccountWarning.getValue();
    assertThat(
        savedWarning,
        is(
            accountWarningMatcher(
                ACCOUNT_NUMBER,
                RESTRICTION_TYPE_CODE,
                PROCESS_TIME,
                PROCESS_TIME,
                CREATED_AT,
                CREATED_BY)));
    verifyNoInteractions(warningNoteCoreRepository);
  }

  @Test
  void executeShouldCreateWarningAndNotes() {
    final AccountWarningRequestArguments arguments = buildRequestArguments();
    final AccountNumber account =
        AccountNumber.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .tableId(AccountNumber.TABLE_ID_SAVACC)
            .savingProductSysId(SAVING_PRODUCT_SYSID)
            .build();
    final RestrictionType restrictionType =
        RestrictionType.builder().code(RESTRICTION_TYPE_CODE).startDate(PROCESS_TIME).build();
    final AccountWarning warning = buildAccountWarning();
    final WarningNote note = buildWarningNote(WARNING_SYSID, NOTES);

    when(restrictionTypeRepository.findByCode(RESTRICTION_TYPE_CODE))
        .thenReturn(Optional.of(restrictionType));

    testSubject.execute(arguments, account);

    verify(accountWarningCoreRepository).saveAndFlush(savedAccountWarning.capture());
    verify(warningNoteCoreRepository).saveAndFlush(savedWarningNote.capture());

    final AccountWarning savedWarning = savedAccountWarning.getValue();
    final WarningNote savedNote = savedWarningNote.getValue();
    assertThat(
        savedWarning,
        is(
            accountWarningMatcher(
                ACCOUNT_NUMBER,
                RESTRICTION_TYPE_CODE,
                PROCESS_TIME,
                PROCESS_TIME,
                CREATED_AT,
                CREATED_BY)));
    assertThat(
        savedNote,
        is(warningNoteMatcher(NOTES, PROCESS_TIME, PROCESS_TIME, CREATED_AT, CREATED_BY)));
  }

  @Test
  void executeShouldThrowAccountRequestProcessingExceptionWhenRestrictionTypeNotFound() {
    final AccountWarningRequestArguments arguments = buildRequestArguments();
    final AccountNumber account =
        AccountNumber.builder()
            .accountNumber(ACCOUNT_NUMBER)
            .tableId(AccountNumber.TABLE_ID_SAVACC)
            .savingProductSysId(SAVING_PRODUCT_SYSID)
            .build();

    when(restrictionTypeRepository.findByCode(RESTRICTION_TYPE_CODE)).thenReturn(Optional.empty());

    final AccountRequestProcessingException exception =
        assertThrows(
            AccountRequestProcessingException.class, () -> testSubject.execute(arguments, account));

    assertThat(exception.getMessage(), is(Reason.WARNING_NOT_FOUND.getDescription()));
    verifyNoInteractions(accountWarningCoreRepository);
    verifyNoInteractions(warningNoteCoreRepository);
  }

  private static AccountWarning buildAccountWarning() {
    return AccountWarning.builder()
        .sysId(WARNING_SYSID)
        .accountNumber(buildCoreAccountNumber(ACCOUNT_NUMBER))
        .restrictionType(buildRestrictionType(RESTRICTION_TYPE_CODE))
        .startDate(PROCESS_TIME)
        .createdAt(CREATED_AT)
        .createdBy(CREATED_BY)
        .createdDate(PROCESS_TIME)
        .build();
  }

  private static AccountNumber buildAdgCoreAccountNumber() {
    return AccountNumber.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .tableId(AccountNumber.TABLE_ID_SAVACC)
        .savingProductSysId(SAVING_PRODUCT_SYSID)
        .build();
  }

  private static uk.co.ybs.digital.account.model.core.AccountNumber buildCoreAccountNumber(
      final Long number) {
    return uk.co.ybs.digital.account.model.core.AccountNumber.builder()
        .accountNumber(number)
        .tableId(uk.co.ybs.digital.account.model.core.AccountNumber.TABLE_ID_SAVACC)
        .savingProductSysId(SAVING_PRODUCT_SYSID)
        .build();
  }

  private static uk.co.ybs.digital.account.model.core.RestrictionType buildRestrictionType(
      final String typeCode) {
    return uk.co.ybs.digital.account.model.core.RestrictionType.builder().code(typeCode).build();
  }

  private static WarningNote buildWarningNote(final Long warningSysId, final String notes) {
    return WarningNote.builder()
        .accountWarningSysId(warningSysId)
        .startDate(PROCESS_TIME)
        .notes(notes)
        .createdAt(CREATED_AT)
        .createdBy(CREATED_BY)
        .createdDate(PROCESS_TIME)
        .build();
  }

  private static AccountWarningRequestArguments buildRequestArguments() {
    return buildRequestArguments(
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234), "Some Notes");
  }

  private static AccountWarningRequestArguments buildRequestArguments(final String notes) {
    return buildRequestArguments(
        TestHelper.buildValidRequestMetadata(UUID.randomUUID(), 1234), notes);
  }

  private static AccountWarningRequestArguments buildRequestArguments(
      final RequestMetadata metadata, final String notes) {
    return AccountWarningRequestArguments.builder()
        .accountNumber(ACCOUNT_NUMBER)
        .warningCode(RESTRICTION_TYPE_CODE)
        .createdAt(CREATED_AT)
        .createdBy(CREATED_BY)
        .notes(notes)
        .processTime(PROCESS_TIME)
        .requestMetadata(metadata)
        .build();
  }

  private Matcher<AccountWarning> accountWarningMatcher(
      final Long accountNumber,
      final String restrictionTypeCode,
      final LocalDateTime startDate,
      final LocalDateTime createdDate,
      final String createdAt,
      final String createdBy) {
    final Matcher<uk.co.ybs.digital.account.model.core.AccountNumber> accountNumberMatcher =
        accountNumberMatcherCore(
            accountNumber,
            uk.co.ybs.digital.account.model.core.AccountNumber.TABLE_ID_SAVACC,
            SAVING_PRODUCT_SYSID);
    final Matcher<uk.co.ybs.digital.account.model.core.RestrictionType> restrictionTypeMatcher =
        restrictionTypeMatcherCore(restrictionTypeCode);
    return allOf(
        hasProperty("accountNumber", is(accountNumberMatcher)),
        hasProperty("restrictionType", is(restrictionTypeMatcher)),
        hasProperty("startDate", is(startDate)),
        hasProperty("createdDate", is(createdDate)),
        hasProperty("createdAt", is(createdAt)),
        hasProperty("createdBy", is(createdBy)),
        hasProperty("endDate", is(nullValue())),
        hasProperty("endedDate", is(nullValue())),
        hasProperty("endedAt", is(nullValue())),
        hasProperty("endedBy", is(nullValue())));
  }

  private Matcher<WarningNote> warningNoteMatcher(
      final String notes,
      final LocalDateTime startDate,
      final LocalDateTime createdDate,
      final String createdAt,
      final String createdBy) {
    return allOf(
        hasProperty("notes", is(notes)),
        hasProperty("startDate", is(startDate)),
        hasProperty("createdDate", is(createdDate)),
        hasProperty("createdAt", is(createdAt)),
        hasProperty("createdBy", is(createdBy)),
        hasProperty("endDate", is(nullValue())),
        hasProperty("endedDate", is(nullValue())),
        hasProperty("endedAt", is(nullValue())),
        hasProperty("endedBy", is(nullValue())));
  }

  private Matcher<uk.co.ybs.digital.account.model.core.AccountNumber> accountNumberMatcherCore(
      final Long accountNumber, final String tableId, final Long savingProductSysId) {

    return allOf(
        hasProperty("accountNumber", is(accountNumber)),
        hasProperty("tableId", is(tableId)),
        hasProperty("savingProductSysId", is(savingProductSysId)));
  }

  private Matcher<uk.co.ybs.digital.account.model.core.RestrictionType> restrictionTypeMatcherCore(
      final String restrictionTypeCode) {

    return allOf(hasProperty("code", is(restrictionTypeCode)));
  }
}
