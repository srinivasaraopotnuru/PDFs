package uk.co.ybs.digital.account.repository.adgcore;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.is;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import uk.co.ybs.digital.account.model.adgcore.AddressUsage;
import uk.co.ybs.digital.account.model.adgcore.Country;
import uk.co.ybs.digital.account.model.adgcore.Party;
import uk.co.ybs.digital.account.model.adgcore.PostalAddress;
import uk.co.ybs.digital.account.repository.YbsDataJpaTest;

@YbsDataJpaTest
public class CountryRepositoryTest {

  private static final LocalDateTime TODAY = LocalDateTime.parse("2020-09-01T00:00:00");
  private static final LocalDateTime YESTERDAY = LocalDateTime.parse("2020-08-31T00:00:00");
  private static final long PARTY_ID = 1246295101L;
  private static final long PARTY_ID_NOT_EXISTS = 9876543210L;

  private static long nextId = 1L;

  @Autowired CountryRepository testSubject;

  @Autowired TestEntityManager adgCoreTestEntityManager;

  @Test
  public void shouldReturnEmptyListWhenPartyIdDoesNotExist() {

    final List<Country> countries =
        testSubject.findCountriesForPartyId(PARTY_ID_NOT_EXISTS, LocalDateTime.now());

    assertThat(countries.size(), is(0));
  }

  @Test
  public void shouldReturnEmptyListForPartyIdWithNoAddresses() {

    setupPartyWithNoAddresses();

    final List<Country> countries =
        testSubject.findCountriesForPartyId(PARTY_ID, LocalDateTime.now());

    assertThat(countries.size(), is(0));
  }

  @Test
  public void shouldFindCountryForPartyIdWithSingleAddress() {
    final Country country = Country.builder().code("UK").isoCode("GB").build();
    setupPartyWithSingleAddress(country);

    final List<Country> countries =
        testSubject.findCountriesForPartyId(PARTY_ID, LocalDateTime.now());

    assertThat(countries.size(), is(1));
    assertThat(countries.get(0), is(country));
  }

  @Test
  public void
      shouldFindCountriesOrderedByPreferredContactMethodThenStartDateDescendingForPartyIdWithMultipleAddresses() {
    final Party party = Party.builder().sysId(PARTY_ID).build();
    final Country country1 = Country.builder().code("SPA").isoCode("ES").build();
    final Country country2 = Country.builder().code("IND").isoCode("IN").build();
    final Country country3 = Country.builder().code("GER").isoCode("DE").build();
    final AddressUsage addressUsage1 = buildAddressUsage(country1, party, false, YESTERDAY);
    final AddressUsage addressUsage2 = buildAddressUsage(country2, party, true, YESTERDAY);
    final AddressUsage addressUsage3 = buildAddressUsage(country3, party, false, TODAY);
    final List<AddressUsage> addressUsages =
        Arrays.asList(addressUsage1, addressUsage2, addressUsage3);
    setupPartyWithMultipleAddresses(addressUsages, party);

    final List<Country> countries =
        testSubject.findCountriesForPartyId(PARTY_ID, LocalDateTime.now());

    assertThat(countries.size(), is(3));
    assertThat(countries, contains(country2, country3, country1));
  }

  private void setupPartyWithNoAddresses() {

    final Party party = Party.builder().sysId(PARTY_ID).build();
    AddressUsage addressUsage =
        AddressUsage.builder().sysId(getNextId()).party(party).startDate(TODAY).build();

    adgCoreTestEntityManager.persist(party);
    adgCoreTestEntityManager.persist(addressUsage);

    adgCoreTestEntityManager.flush();
    adgCoreTestEntityManager.clear();
  }

  private void setupPartyWithSingleAddress(final Country country) {

    final Party party = Party.builder().sysId(PARTY_ID).build();
    final AddressUsage addressUsage = buildAddressUsage(country, party, true, TODAY);

    adgCoreTestEntityManager.persist(party);
    adgCoreTestEntityManager.persist(addressUsage.getPostalAddress().getCountry());
    adgCoreTestEntityManager.persist(addressUsage.getPostalAddress());
    adgCoreTestEntityManager.persist(addressUsage);

    adgCoreTestEntityManager.flush();
    adgCoreTestEntityManager.clear();
  }

  private void setupPartyWithMultipleAddresses(
      final List<AddressUsage> addressUsages, final Party party) {

    adgCoreTestEntityManager.persist(party);
    addressUsages.forEach(
        au -> {
          adgCoreTestEntityManager.persist(au.getPostalAddress().getCountry());
          adgCoreTestEntityManager.persist(au.getPostalAddress());
          adgCoreTestEntityManager.persist(au);
        });

    adgCoreTestEntityManager.flush();
    adgCoreTestEntityManager.clear();
  }

  private static AddressUsage buildAddressUsage(
      final Country country,
      final Party party,
      final boolean preferredContactMethod,
      final LocalDateTime startDate) {
    return AddressUsage.builder()
        .sysId(getNextId())
        .postalAddress(PostalAddress.builder().sysId(getNextId()).country(country).build())
        .party(party)
        .preferredContactMethod(preferredContactMethod)
        .startDate(startDate)
        .build();
  }

  private static long getNextId() {
    return nextId++;
  }
}
