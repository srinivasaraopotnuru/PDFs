_expected_account_restrictions_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "array",
    "items": [
        {
            "type": "object",
            "properties": {
                "code": {"type": "string"},
                "message": {"type": "string"}
            },
            "required": ["code"],
        }
    ],
}
_expected_permitted_rule_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "array",
    "items": [
        {
            "required": ["allowed", "code"],
            "type": "object",
            "properties": {
                "code": {"type": "string"},
                "allowed":{"type": "boolean"}
            }
        }
    ]
} 

_expected_product_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "object",
    "properties": {"identifier": {"type": "string"}, "description": {"type": "string"}, "type": {"type": "string"}, "smartTiered": {"type": "boolean"}},
    "required": ["identifier", "description", "type", "smartTiered"],
    "additionalProperties": False,
}

_expected_isa_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "object",
    "properties": {"flexible": {"type": "boolean"}, "helpToBuy": {"type": "boolean"}, "subscribed": {"type": "boolean"}},
    "required": ["flexible"],
    "additionalProperties": False,
}

expected_account_details_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "account": {
            "type": "object",
            "required": [
                "accountNumber",
                "amendmentRestriction",
                "accountSortCode",
                "accountType",
                "externalAccountNumber",
                "openedDate",
                "productIdentifier",
                "productDescription",
                "product",
                "currency",
                "balance",
                "withdrawals",
                "deposits",
            ],
            "properties": {
                "accountName": {"type": "string"},
                "accountNumber": {
                    "type": "string",
                    "pattern": "\\d{10}",
                },
                "amendmentRestriction": {"type": "boolean"},
                "accountSortCode": {"type": "string"},
                "accountType": {"type": "string"},
                "externalAccountNumber": {"type": "string"},
                "openedDate": {"type": "string"},
                "closedDate": {"type": "string"},
                "productIdentifier": {"type": "string"},
                "productDescription": {"type": "string"},
                "product": _expected_product_schema,
                "currency": {"type": "string"},
                "balance": {
                    "type": "array",
                    "items": [
                        {
                            "type": "object",
                            "properties": {
                                "type": {"type": "string"},
                                "amount": {"type": "string"},
                            },
                            "required": ["type", "amount"],
                        }
                    ],
                },
                "interest": {
                    "type": "object",
                    "properties": {
                        "interestInstruction": {"type": "string"},
                        "nextPaymentDate": {"type": "string"},
                        "calculationFrequency": {"type": "string"},
                        "applicationFrequency": {"type": "string"},
                        "interestRateType": {"type": "string"},
                        "interestTiers": {
                            "type": "array",
                            "items": [
                                {
                                    "type": "object",
                                    "properties": {
                                        "interestRate": {"type": "string"},
                                        "annualEquivalentRate": {"type": "string"},
                                        "rangeLow": {"type": "string"},
                                        "rangeHigh": {"type": "string"},
                                    },
                                }
                            ],
                        },
                    },
                    "required": [
                        "interestInstruction",
                        "nextPaymentDate",
                        "calculationFrequency",
                        "applicationFrequency",
                        "interestRateType",
                        "interestTiers",
                    ],
                },
                "withdrawals": {
                    "type": "object",
                    "properties": {
                        "permittedOverApi": {"type": "boolean"},
                        "permittedRules": _expected_permitted_rule_schema,
                        "limit": {
                            "type": "object",
                            "properties": {
                                "permitted": {"type": "integer"},
                                "available": {"type": "integer"},
                                "periodEnd": {
                                    "type": "string",
                                    "format": "date",
                                },
                                "interestPenalty": {
                                    "type": "object",
                                    "properties:": {"days": {"type": "integer"}},
                                    "required": ["days"],
                                    "additionalProperties": False,
                                },
                            },
                            "required": ["permitted", "available", "periodEnd"],
                            "additionalProperties": False,
                        },
                        "restrictions": _expected_account_restrictions_schema,
                    },
                    "required": ["permittedOverApi","permittedRules"],
                    "additionalProperties": False,
                },
                "deposits": {
                    "type": "object",
                    "properties": {
                        "permittedOverApi": {"type": "boolean"},
                        "permittedRules": _expected_permitted_rule_schema,
                        "limit": {
                            "type": "object",
                            "properties": {
                                 "available": {"type": "string"},
                                 "maxProductBalRemaining": {"type": "string"},
                             },
                            "additionalProperties": False,
                        },
                        "restrictions": _expected_account_restrictions_schema,
                    },
                    "required": ["permittedOverApi","permittedRules"],
                    "additionalProperties": False,
                },
                "isa": _expected_isa_schema,
            },
        }
    },
}

expected_account_list_schema = {
    "$schema": "http://json-schema.org/draft-04/schema#",
    "type": "object",
    "properties": {
        "account": {
            "type": "array",
            "items": [
                {
                    "type": "object",
                    "properties": {
                        "accountName": {"type": "string"},
                        "accountNumber": {"type": "string"},
                        "accountSortCode": {"type": "string"},
                        "accountType": {"type": "string"},
                        "externalAccountNumber": {"type": "string"},
                        "productIdentifier": {"type": "string"},
                        "productDescription": {"type": "string"},
                        "product": _expected_product_schema,
                        "currency": {"type": "string"},
                        "balance": {
                            "type": "array",
                            "items": [
                                {
                                    "type": "object",
                                    "properties": {
                                        "type": {"type": "string"},
                                        "amount": {"type": "string"},
                                    },
                                    "required": ["type", "amount"],
                                    "additionalProperties": False,
                                }
                            ],
                        },
                        "withdrawals": {
                            "type": "object",
                            "properties": {
                              "permittedOverApi": {"type": "boolean"},
                              "permittedRules": _expected_permitted_rule_schema
                            },   
                            "required": ["permittedOverApi","permittedRules"],
                            "additionalProperties": False,
                        },
                        "deposits": {
                            "type": "object",
                            "properties": {
                              "permittedOverApi": {"type": "boolean"},
                              "permittedRules": _expected_permitted_rule_schema
                            }, 
                            "required": ["permittedOverApi","permittedRules"],
                            "additionalProperties": False,
                        },
                        "isa": _expected_isa_schema,
                    },
                    "required": [
                        "accountNumber",
                        "accountSortCode",
                        "accountType",
                        "externalAccountNumber",
                        "productIdentifier",
                        "productDescription",
                        "product",
                        "currency",
                        "balance",
                        "withdrawals",
                        "deposits",
                    ],
                    "additionalProperties": False,
                }
            ],
        }
    },
    "required": ["account"],
    "additionalProperties": False,
}

expected_account_list_by_group_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "owned": {
            "type": "object",
            "additionalProperties": False,
            "required": ["account"],
            "properties": {
                "account": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": [
                            "amendmentRestriction",
                            "accountSortCode",
                            "accountType",
                            "balance",
                            "currency",
                            "deposits",
                            "externalAccountNumber",
                            "openedDate",
                            "productIdentifier",
                            "productDescription",
                            "product",
                            "withdrawals",
                        ],
                        "properties": {
                            "accountName": {"type": "string"},
                            "accountNumber": {"type": "string"},
                            "amendmentRestriction": {"type": "boolean"},
                            "accountSortCode": {"type": "string"},
                            "accountType": {"type": "string"},
                            "balance": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "additionalProperties": False,
                                    "required": ["amount", "type"],
                                    "properties": {
                                        "amount": {"type": "string"},
                                        "type": {"type": "string"},
                                    },
                                },
                            },
                            "currency": {"type": "string"},
                            "externalAccountNumber": {"type": "string"},
                            "openedDate": {"type": "string"},
                            "productIdentifier": {"type": "string"},
                            "productDescription": {"type": "string"},
                            "product": _expected_product_schema,
                            "withdrawals": {
                                "type": "object",
                                "properties": {"permittedOverApi": {"type": "boolean"},
                                "permittedRules": _expected_permitted_rule_schema
                                }, 
                                "required": ["permittedOverApi", "permittedRules"],
                                "additionalProperties": False,
                            },
                            "deposits": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema
                                }, 
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "isa": _expected_isa_schema,
                        },
                    },
                },
                "balance": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["amount", "type"],
                        "properties": {
                            "amount": {"type": "string"},
                            "type": {"type": "string"},
                        },
                    },
                },
            },
        },
        "other": {
            "type": "object",
            "additionalProperties": False,
            "required": ["account"],
            "properties": {
                "account": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": [
                            "amendmentRestriction",
                            "accountSortCode",
                            "accountType",
                            "balance",
                            "currency",
                            "deposits",
                            "externalAccountNumber",
                            "openedDate",
                            "productIdentifier",
                            "productDescription",
                            "product",
                            "withdrawals",
                        ],
                        "properties": {
                            "accountName": {"type": "string"},
                            "accountNumber": {"type": "string"},
                            "amendmentRestriction": {"type": "boolean"},
                            "accountSortCode": {"type": "string"},
                            "accountType": {"type": "string"},
                            "balance": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "additionalProperties": False,
                                    "required": ["amount", "type"],
                                    "properties": {
                                        "amount": {"type": "string"},
                                        "type": {"type": "string"},
                                    },
                                },
                            },
                            "currency": {"type": "string"},
                            "externalAccountNumber": {"type": "string"},
                            "openedDate": {"type": "string"},
                            "productIdentifier": {"type": "string"},
                            "productDescription": {"type": "string"},
                            "product": _expected_product_schema,
                            "withdrawals": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema
                                },
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "deposits": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema  
                                },
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "isa": _expected_isa_schema,
                        },
                    },
                },
                "balance": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["amount", "type"],
                        "properties": {
                            "amount": {"type": "string"},
                            "type": {"type": "string"},
                        },
                    },
                },
            },
        },
        "additionalProperties": False,
    },
}

expected_account_list_by_group_with_closed_accounts_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "object",
    "additionalProperties": False,
    "required": ["closed"],
    "properties": {
        "owned": {
            "type": "object",
            "additionalProperties": False,
            "required": ["account"],
            "properties": {
                "account": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": [
                            "amendmentRestriction",
                            "accountSortCode",
                            "accountType",
                            "balance",
                            "currency",
                            "deposits",
                            "externalAccountNumber",
                            "openedDate",
                            "productIdentifier",
                            "productDescription",
                            "product",
                            "withdrawals",
                        ],
                        "properties": {
                            "accountName": {"type": "string"},
                            "accountNumber": {"type": "string"},
                            "amendmentRestriction": {"type": "boolean"},
                            "accountSortCode": {"type": "string"},
                            "accountType": {"type": "string"},
                            "balance": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "additionalProperties": False,
                                    "required": ["amount", "type"],
                                    "properties": {
                                        "amount": {"type": "string"},
                                        "type": {"type": "string"},
                                    },
                                },
                            },
                            "currency": {"type": "string"},
                            "externalAccountNumber": {"type": "string"},
                            "openedDate": {"type": "string"},
                            "productIdentifier": {"type": "string"},
                            "productDescription": {"type": "string"},
                            "product": _expected_product_schema,
                            "withdrawals": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema    
                                },
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "deposits": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema  
                                },
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "isa": _expected_isa_schema,
                        },
                    },
                },
                "balance": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["amount", "type"],
                        "properties": {
                            "amount": {"type": "string"},
                            "type": {"type": "string"},
                        },
                    },
                },
            },
        },
        "other": {
            "type": "object",
            "additionalProperties": False,
            "required": ["account"],
            "properties": {
                "account": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": [
                            "amendmentRestriction",
                            "accountSortCode",
                            "accountType",
                            "balance",
                            "currency",
                            "deposits",
                            "externalAccountNumber",
                            "openedDate",
                            "productIdentifier",
                            "productDescription",
                            "product",
                            "withdrawals",
                        ],
                        "properties": {
                            "accountName": {"type": "string"},
                            "accountNumber": {"type": "string"},
                            "amendmentRestriction": {"type": "boolean"},
                            "accountSortCode": {"type": "string"},
                            "accountType": {"type": "string"},
                            "balance": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "additionalProperties": False,
                                    "required": ["amount", "type"],
                                    "properties": {
                                        "amount": {"type": "string"},
                                        "type": {"type": "string"},
                                    },
                                },
                            },
                            "currency": {"type": "string"},
                            "externalAccountNumber": {"type": "string"},
                            "openedDate": {"type": "string"},
                            "productIdentifier": {"type": "string"},
                            "productDescription": {"type": "string"},
                            "product": _expected_product_schema,
                            "withdrawals": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema  
                                },
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "deposits": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema  
                                },
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "isa": _expected_isa_schema,
                        },
                    },
                },
                "balance": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["amount", "type"],
                        "properties": {
                            "amount": {"type": "string"},
                            "type": {"type": "string"},
                        },
                    },
                },
            },
        },
        "closed": {
            "type": "object",
            "additionalProperties": False,
            "required": ["account"],
            "properties": {
                "account": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": [
                            "amendmentRestriction",
                            "accountSortCode",
                            "accountType",
                            "balance",
                            "currency",
                            "deposits",
                            "externalAccountNumber",
                            "openedDate",
                            "productIdentifier",
                            "productDescription",
                            "product",
                            "withdrawals",
                        ],
                        "properties": {
                            "accountName": {"type": "string"},
                            "accountNumber": {"type": "string"},
                            "amendmentRestriction": {"type": "boolean"},
                            "accountSortCode": {"type": "string"},
                            "accountType": {"type": "string"},
                            "balance": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "additionalProperties": False,
                                    "required": ["amount", "type"],
                                    "properties": {
                                        "amount": {"type": "string"},
                                        "type": {"type": "string"},
                                    },
                                },
                            },
                            "currency": {"type": "string"},
                            "externalAccountNumber": {"type": "string"},
                            "openedDate": {"type": "string"},
                            "productIdentifier": {"type": "string"},
                            "productDescription": {"type": "string"},
                            "product": _expected_product_schema,
                            "withdrawals": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema  
                                },
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "deposits": {
                                "type": "object",
                                "properties": {
                                  "permittedOverApi": {"type": "boolean"},
                                  "permittedRules": _expected_permitted_rule_schema  
                                },
                                "required": ["permittedOverApi","permittedRules"],
                                "additionalProperties": False,
                            },
                            "isa": _expected_isa_schema,
                        },
                    },
                },
                "balance": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "required": ["amount", "type"],
                        "properties": {
                            "amount": {"type": "string"},
                            "type": {"type": "string"},
                        },
                    },
                },
            },
        },
        "additionalProperties": False,
    },
}

expected_account_transaction_schema = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "type": "object",
    "required": ["transaction", "meta"],
    "properties": {
        "transaction": {
            "type": "array",
            "items": {
                "type": "object",
                "required": [
                    "accountNumber",
                    "transactionId",
                    "creditDebitIndicator",
                    "status",
                    "bookingDateTime",
                    "amount",
                ],
                "properties": {
                    "accountNumber": {"type": "string"},
                    "transactionId": {"type": "string"},
                    "creditDebitIndicator": {"type": "string"},
                    "status": {"type": "string"},
                    "bookingDateTime": {"type": "string"},
                    "valueDateTime": {"type": "string"},
                    "amount": {
                        "type": "object",
                        "required": ["amount", "currency"],
                        "properties": {
                            "amount": {"type": "string"},
                            "currency": {"type": "string"},
                        },
                    },
                    "transactionCode": {
                        "type": "object",
                        "required": ["code", "method"],
                        "properties": {
                            "code": {"type": "string"},
                            "method": {"type": "string"},
                        },
                    },
                    "transactionInformation": {"type": "string"},
                    "balance": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "required": ["type", "amount"],
                            "properties": {
                                "type": {"type": "string"},
                                "amount": {"type": "string"},
                            },
                        },
                    },
                },
            },
        },
        "meta": {
            "type": "object",
            "required": ["totalPages", "totalTransactions"],
            "properties": {
                "totalPages": {"type": "integer"},
                "totalTransactions": {"type": "integer"},
            },
        },
    },
}

expected_withdrawal_interest_penalty_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "object",
    "required": ["value"],
    "properties": {"value": {"type": "string"}},
}

expected_account_warnings_schema = {
    "$schema": "http://json-schema.org/draft-07/schema",
    "type": "array",
    "items": [
        {
            "type": "object",
            "properties": {
                "code": {"type": "string"},
                "description": {"type": "string"},
            },
        }
    ],
}

