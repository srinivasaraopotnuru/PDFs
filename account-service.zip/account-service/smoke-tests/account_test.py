import ecdsa
import hashlib
import jsonschema
import os
import uuid
from base64 import b64encode
from jwt import (
    JWT,
    jwk_from_pem,
)
from time import time

import config
import expected_json_schema
import requests
from signer import Signer

host = os.getenv("SERVICE_HOST", default="localhost:8080")
protocol = os.getenv("SERVICE_PROTOCOL", default="http://")
target_env = os.getenv("SMOKE_TARGET_ENV", default="test")

jwt_alg = "RS256"
base_path = "/account"
accounts_path_public = "/accounts"
accounts_path_private = "/private/accounts"
host_presented = host
x_request_id = str(uuid.uuid4())
request_signing_key_id_public = "apigee-nonprod-1"
request_signing_key_id_private_payment = "payment-service-nonprod-1"
request_signing_key_id_private_customer = "customer-service-nonprod-1"
request_signing_key_id_private_sales = "jwt-build-client-nonprod-1"
sca_signing_key_id = "sca_key"
no_include_shareplan_accounts = "false"
post_account_warning_request = {"code": "LPB1"}
if target_env == "dev" or target_env == "test" or target_env == "idam-test2":
    customer_number = "12462951"
    account_number = "2372146519"
    customer_number_with_closed_accounts = "2919152"
    customer_number_withdrawal_penalty = "5086491"
    account_number_withdrawal_penalty = "5734223421"
    customer_number_without_pending_declaration = "4780965"
    account_number_without_pending_declaration = "5234191407"
    customer_number_with_pending_declaration = "4175040"
    account_number_with_pending_declaration = "4808330730"
    customer_number_with_no_recent_accounts = "5441656"
    customer_number_with_no_warnings = "6674405"
    account_number_with_no_warnings = "3953644739"
    account_number_with_warnings = "3953644739"
    customer_number_with_warnings = "6674405"
    account_number_for_delete_account = "3293106507"
    customer_number_for_delete_account= "6963220032"
    customer_number_for_delete_account_warning = "6963906574"
    account_number_for_delete_account_warning = "5456318307"
    party_id_for_warnings = "0006674405"
    request_signature_private_key_customer = (
        config.request_signature_private_key_customer_test
    )
elif target_env == "flex":
    customer_number = "12462951"
    account_number = "2372146519"
    customer_number_with_closed_accounts = "4745087"
    customer_number_withdrawal_penalty = "5086491"
    account_number_withdrawal_penalty = "5734223421"
    customer_number_without_pending_declaration = "4780965"
    account_number_without_pending_declaration = "5234191407"
    customer_number_with_pending_declaration = "4175040"
    account_number_with_pending_declaration = "4808330730"
    customer_number_with_no_recent_accounts = "5441656"
    customer_number_with_no_warnings = "6674405"
    account_number_with_no_warnings = "3953644739"
    account_number_with_warnings = "3953644739"
    customer_number_with_warnings = "6674405"
    account_number_for_delete_account= "3293106507"
    customer_number_for_delete_account= "8323440"
    customer_number_for_delete_account_warning = "12772900"
    account_number_for_delete_account_warning = "3291885907"
    party_id_for_warnings = "0006674405"
    request_signature_private_key_customer = (
        config.request_signature_private_key_customer_flex
    )
else:
    raise Exception("Unexpected SMOKE_TARGET_ENV: {}".format(target_env))

signer = Signer(
    {
        request_signing_key_id_public: ecdsa.SigningKey.from_pem(
            config.request_signature_private_key_public, hashlib.sha256
        ),
        request_signing_key_id_private_payment: ecdsa.SigningKey.from_pem(
            config.request_signature_private_key_private_payment, hashlib.sha256
        ),
        request_signing_key_id_private_customer: ecdsa.SigningKey.from_pem(
            request_signature_private_key_customer, hashlib.sha256
        ),
        sca_signing_key_id: ecdsa.SigningKey.from_pem(
            config.sca_private_key, hashlib.sha256
        ),
    }
)


def test_get_account_details_should_succeed_with_valid_signature_and_scope():
    assert_get_account_details_should_succeed_with_valid_signature_and_scope(
        accounts_path_public, request_signing_key_id_public
    )


def test_private_get_account_details_should_succeed_with_valid_signature_and_scope():
    assert_get_account_details_should_succeed_with_valid_signature_and_scope(
        accounts_path_private, request_signing_key_id_private_payment
    )


def assert_get_account_details_should_succeed_with_valid_signature_and_scope(
    accounts_path, request_signing_key_id
):
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        f"{accounts_path}/{account_number}",
        authorization=authorization,
        key_id=request_signing_key_id,
    )
    assert (
        response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

    response_body = response.json()
    jsonschema.validate(
        response_body, expected_json_schema.expected_account_details_schema
    )


def test_get_accounts_by_group_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        f"{accounts_path_public}/grouped",
        authorization=authorization,
        key_id=request_signing_key_id_public,
    )
    assert (
        response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

    response_body = response.json()
    jsonschema.validate(
        response_body, expected_json_schema.expected_account_list_by_group_schema
    )



def test_get_accounts_by_group_with_closed_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(
        create_jwt(
            "ACCOUNT_READ", jwt_customer_number=customer_number_with_closed_accounts
        )
    )
    response = make_request(
        f"{accounts_path_public}/grouped?showClosedAccounts=true",
        authorization=authorization,
        key_id=request_signing_key_id_public,
    )
    assert (
        response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

    response_body = response.json()
    jsonschema.validate(
        response_body,
        expected_json_schema.expected_account_list_by_group_with_closed_accounts_schema,
    )


def test_private_get_accounts_by_group_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        f"{accounts_path_private}/grouped",
        authorization=authorization,
        key_id=request_signing_key_id_private_customer,
    )
    assert (
        response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

    response_body = response.json()
    jsonschema.validate(
        response_body, expected_json_schema.expected_account_list_by_group_schema
    )


def test_private_get_accounts_by_group_with_closed_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(
        create_jwt(
            "ACCOUNT_READ", jwt_customer_number=customer_number_with_closed_accounts
        )
    )
    response = make_request(
        f"{accounts_path_private}/grouped?showClosedAccounts=true",
        authorization=authorization,
        key_id=request_signing_key_id_private_customer,
    )
    assert (
        response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

    response_body = response.json()
    jsonschema.validate(
        response_body,
        expected_json_schema.expected_account_list_by_group_with_closed_accounts_schema,
    )


def test_get_transactions_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        f"{accounts_path_public}/{account_number}/transactions",
        authorization=authorization,
        key_id=request_signing_key_id_public,
    )
    assert (
        response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

    response_body = response.json()
    jsonschema.validate(
        response_body, expected_json_schema.expected_account_transaction_schema
    )


def test_get_transactions_should_succeed_with_valid_signature_and_scope_and_with_date_filter():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        f"{accounts_path_public}/{account_number}/transactions?startMonth=2022-01&endMonth=2022-02",
        authorization=authorization,
        key_id=request_signing_key_id_public,
    )
    assert (
        response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

    response_body = response.json()
    jsonschema.validate(
        response_body, expected_json_schema.expected_account_transaction_schema
    )


def test_private_get_withdrawal_interest_penalty_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", customer_number_withdrawal_penalty)
    )
    response = make_request(
        f"{accounts_path_private}/{account_number_withdrawal_penalty}/withdrawal-interest-penalty?"
        f"withdrawalAmount=123.45",
        authorization=authorization,
        key_id=request_signing_key_id_private_payment,
    )
    assert response.status_code == 200

    response_body = response.json()
    jsonschema.validate(
        response_body, expected_json_schema.expected_withdrawal_interest_penalty_schema
    )


def test_get_account_details_should_return_bad_request_if_account_number_is_invalid():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        f"{accounts_path_public}/foobar",
        authorization=authorization,
        key_id=request_signing_key_id_public,
    )
    assert_invalid_account_number_response(response, account_number="foobar")


def test_get_account_details_should_fail_without_valid_scope():
    authorization = create_authorization(create_jwt("PAYMENT"))
    response = make_request(
        f"{accounts_path_public}/{account_number}",
        authorization=authorization,
        key_id=request_signing_key_id_public,
    )
    assert_access_denied_response(response)


def test_get_accounts_by_group_should_fail_without_signature():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        accounts_path_public + "/grouped",
        key_id=request_signing_key_id_public,
        authorization=authorization,
        no_sign=True,
    )
    assert_invalid_signature_response(response)


def test_private_get_accounts_by_group_should_fail_without_signature():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        accounts_path_private + "/grouped",
        key_id=request_signing_key_id_private_customer,
        authorization=authorization,
        no_sign=True,
    )
    assert_invalid_signature_response(response)


def test_private_post_accounts_warning():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", customer_number_with_no_warnings)
    )
    response = make_request(
        f"{accounts_path_private}/{account_number_with_no_warnings}/warnings",
        json=post_account_warning_request,
        authorization=authorization,
        key_id=request_signing_key_id_private_payment,
        verb="post",
    )
    assert response.status_code == 202

def test_private_post_accounts_warning_sales_jwt():
    authorization = create_authorization(
        create_sales_jwt("ACCOUNT_READ", customer_number_with_no_warnings)
    )
    response = make_request(
        f"{accounts_path_private}/{account_number_with_no_warnings}/warnings",
        json=post_account_warning_request,
        authorization=authorization,
        key_id=request_signing_key_id_private_payment,
        verb="post",
    )
    assert response.status_code == 202

def test_private_get_accounts_warning():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", customer_number_with_warnings)
    )
    response = make_request(
        f"{accounts_path_private}/{account_number_with_warnings}/warnings",
        authorization=authorization,
        key_id=request_signing_key_id_private_payment,
    )
    assert response.status_code == 200

    response_body = response.json()
    jsonschema.validate(
        response_body, expected_json_schema.expected_account_warnings_schema
    )

# PATCH Update Account Details
def test_patch_update_account_details_should_return_forbidden_without_signature():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        make_update_account_details_path(account_number),
        json={"accountName": "NewAccountNickName"},
        key_id=request_signing_key_id_public,
        authorization=authorization,
        no_sign=True,
    )
    assert_invalid_signature_response(response)


def test_patch_update_account_details_should_return_forbidden_without_valid_scope():
    authorization = create_authorization(create_jwt("PAYMENT"))
    response = make_request(
        make_update_account_details_path(account_number),
        json={"accountName": "NewAccountNickName"},
        key_id=request_signing_key_id_public,
        authorization=authorization,
        verb="patch",
    )
    assert_access_denied_response(response)


def test_patch_update_account_details_should_return_bad_request_with_invalid_account_number():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        make_update_account_details_path("12345678"),
        json={"accountName": "NewAccountNickName"},
        key_id=request_signing_key_id_public,
        authorization=authorization,
        verb="patch",
    )
    assert_invalid_account_number_response(response, account_number="12345678")


def test_patch_update_account_details_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    # This does not write any records to the database. If this were to happen this test would fail on
    # subsequent runs of the tests. In smoke tests we have no way to reset warnings on accounts.
    response = make_request(
        make_update_account_details_path(account_number_without_pending_declaration),
        json={"accountName": "NewAccountNickName"},
        key_id=request_signing_key_id_public,
        authorization=authorization,
        verb="patch",
    )
    assert (
            response.status_code == 202
    ), f"unexpected http status: [{response.status_code}]: {response.text}"



# POST ISA Declaration
def test_post_isa_declaration_should_return_forbidden_without_signature():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        make_isa_declaration_path(account_number),
        json="",
        key_id=request_signing_key_id_public,
        authorization=authorization,
        no_sign=True,
    )
    assert_invalid_signature_response(response)


def test_post_isa_declaration_should_return_forbidden_without_valid_scope():
    authorization = create_authorization(create_jwt("PAYMENT"))
    response = make_request(
        make_isa_declaration_path(account_number),
        json="",
        key_id=request_signing_key_id_public,
        authorization=authorization,
        verb="post",
    )
    assert_access_denied_response(response)


def test_post_isa_declaration_should_return_bad_request_with_invalid_account_number():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        make_isa_declaration_path("12345678"),
        json="",
        key_id=request_signing_key_id_public,
        authorization=authorization,
        verb="post",
    )
    assert_invalid_account_number_response(response, account_number="12345678")


def test_post_isa_declaration_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", sub=customer_number_without_pending_declaration)
    )
    # This does not write any records to the database. If this were to happen this test would fail on
    # subsequent runs of the tests. In smoke tests we have no way to reset warnings on accounts.
    response = make_request(
        make_isa_declaration_path(account_number_without_pending_declaration),
        json="",
        key_id=request_signing_key_id_public,
        authorization=authorization,
        verb="post",
    )
    assert (
        response.status_code == 202
    ), f"unexpected http status: [{response.status_code}]: {response.text}"


def test_post_isa_declaration_should_return_conflict_with_valid_signature_and_scope():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", sub=customer_number_with_pending_declaration)
    )
    response = make_request(
        make_isa_declaration_path(account_number_with_pending_declaration),
        json="",
        key_id=request_signing_key_id_public,
        authorization=authorization,
        verb="post",
    )
    assert (
        response.status_code == 409
    ), f"unexpected http status: [{response.status_code}]: {response.text}"


# GET Recent savings accounts
def test_get_recent_savings_accounts_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", jwt_customer_number=None)
    )
    response = make_request(
        make_recent_savings_accounts_path(party_id=customer_number),
        key_id=request_signing_key_id_private_payment,
        authorization=authorization,
    )
    assert (
        response.status_code == 204
    ), f"unexpected http status: [{response.status_code}]: {response.text}"


def test_get_recent_savings_accounts_should_return_not_found_with_valid_signature_and_scope():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", jwt_customer_number=None)
    )
    response = make_request(
        make_recent_savings_accounts_path(
            party_id=customer_number_with_no_recent_accounts
        ),
        key_id=request_signing_key_id_private_payment,
        authorization=authorization,
    )
    assert (
        response.status_code == 404
    ), f"unexpected http status: [{response.status_code}]: {response.text}"


def test_get_recent_savings_accounts_should_return_forbidden_without_signature():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", jwt_customer_number=None)
    )
    response = make_request(
        make_recent_savings_accounts_path(party_id=customer_number),
        key_id=request_signing_key_id_private_payment,
        authorization=authorization,
        no_sign=True,
    )
    assert_invalid_signature_response(response)


def test_get_recent_savings_accounts_should_return_forbidden_without_valid_scope():
    authorization = create_authorization(
        create_jwt("PAYMENT", jwt_customer_number=None)
    )
    response = make_request(
        make_recent_savings_accounts_path(party_id=customer_number),
        key_id=request_signing_key_id_private_payment,
        authorization=authorization,
    )
    assert_access_denied_response(response)


def test_get_recent_savings_accounts_should_return_bad_request_without_a_party_id():
    authorization = create_authorization(
        create_jwt("ACCOUNT_READ", jwt_customer_number=None)
    )
    response = make_request(
        make_recent_savings_accounts_path(),
        key_id=request_signing_key_id_private_payment,
        authorization=authorization,
    )
    assert (
        response.status_code == 400
    ), f"unexpected http status: [{response.status_code}]: {response.text}"
    assert response.json() == {
        "id": x_request_id,
        "code": "400 Bad Request",
        "message": "Invalid value",
        "errors": [
            {"errorCode": "Field.Invalid", "message": "Invalid partyId: 'None'"}
        ],
    }

def test_private_delete_account_should_succeed_with_valid_signature_and_scope():
    
    authorization = create_authorization(
        create_jwt("ACCOUNT_WRITE", customer_number_for_delete_account)
    )
    response = make_request(
        f"{accounts_path_private}/{account_number_for_delete_account}/",
        authorization=authorization,
        key_id=request_signing_key_id_private_customer,
        verb="delete",
    )
    assert (
        response.status_code == 202
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

def test_private_delete_account_warning_should_succeed_with_valid_signature_and_scope():

    authorization = create_authorization(
        create_jwt("ACCOUNT_WRITE", customer_number_for_delete_account_warning)
    )
    response = make_request(
        f"{accounts_path_private}/{account_number_for_delete_account_warning}/",
        authorization=authorization,
        json={"code": "WEBDCF"},
        key_id=request_signing_key_id_private_customer,
        verb="delete",
    )
    assert (
        response.status_code == 202
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

def test_get_account_returns_no_warnings_for_given_partyid_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        f"{accounts_path_private}/warnings?includeShareplanAccounts={no_include_shareplan_accounts}&partyId={party_id_for_warnings}",
        authorization=authorization,
        key_id=request_signing_key_id_private_payment,
    )
    assert (
            response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"


def test_get_account_returns_warnings_for_given_partyid_should_succeed_with_valid_signature_and_scope():
    authorization = create_authorization(create_jwt("ACCOUNT_READ"))
    response = make_request(
        f"{accounts_path_private}/warnings?partyId={party_id_for_warnings}",
        authorization=authorization,
        key_id=request_signing_key_id_private_payment,
    )
    assert (
            response.status_code == 200
    ), f"unexpected http status: [{response.status_code}]: {response.text}"

def assert_invalid_signature_response(response):
    assert (
        response.status_code == 403
    ), f"unexpected http status: [{response.status_code}]: {response.text}"
    assert response.json() == make_invalid_signature_response()


def make_invalid_signature_response():
    return {
        "id": x_request_id,
        "code": "403 Forbidden",
        "message": "Forbidden",
        "errors": [
            {
                "errorCode": "AccessDenied.InvalidRequestSignature",
                "message": "Access Denied",
            }
        ],
    }


def assert_access_denied_response(response):
    assert (
        response.status_code == 403
    ), f"unexpected http status: [{response.status_code}]: {response.text}"
    assert response.json() == make_access_denied_response()


def make_access_denied_response():
    return {
        "id": x_request_id,
        "code": "403 Forbidden",
        "message": "Forbidden",
        "errors": [{"errorCode": "AccessDenied", "message": "Access Denied"}],
    }


def assert_invalid_account_number_response(response, account_number):
    assert (
        response.status_code == 400
    ), f"unexpected http status: [{response.status_code}]: {response.text}"
    assert response.json() == make_invalid_account_number_response(account_number)


def make_invalid_account_number_response(account_number):
    return {
        "id": x_request_id,
        "code": "400 Bad Request",
        "message": "Invalid value",
        "errors": [
            {
                "errorCode": "Field.Invalid",
                "message": f"accountNumber {account_number} is not a valid account number; value must be of the form 1234567890",
            }
        ],
    }


def create_authorization(bearer_token):
    return "Bearer " + bearer_token


def make_request(
    path,
    json=None,
    authorization=None,
    challenge=None,
    challenge_response=None,
    key_id=None,
    no_sign=False,
    verb="get"
):
    url = protocol + host + base_path + path

    headers = {
        "x-ybs-request-id": x_request_id,
        "Host": host_presented,
    }

    def add_header_if_not_none(header, value):
        if value is not None:
            headers[header] = value

    add_header_if_not_none("Authorization", authorization)
    add_header_if_not_none("x-ybs-request-signature-key-id", key_id)
    add_header_if_not_none("x-ybs-sca-challenge", challenge)
    add_header_if_not_none("x-ybs-sca-challenge-response", challenge_response)
    if challenge_response or challenge:
        headers["x-ybs-sca-key"] = b64encode(
            config.sca_public_key.encode("utf-8")
        ).decode()

    
    request = requests.Request(verb, url, headers, json=json).prepare()
        

    if not no_sign:
        signer.sign_request(request)
    return requests.session().send(request, verify=False)


def make_isa_declaration_path(account_number):
    return f"{accounts_path_public}/{account_number}/isa-declaration"

def make_update_account_details_path(account_number):
    return f"{accounts_path_public}/{account_number}"

def make_recent_savings_accounts_path(party_id=None):
    return f"{accounts_path_private}/savings/recent?partyId={party_id}"


def create_jwt(scope, jwt_customer_number=customer_number, sub=customer_number):
    signing_key = jwk_from_pem(config.jwt_private_key.encode())
    jwt = JWT()

    headers = {"kid": "OPAa9voYNByjE_lpbtHanOFKiV4", "alg": jwt_alg}

    message = {
        "jti": str(uuid.uuid4()),
        "sub": sub,
        "iat": time(),
        "sid": str(uuid.uuid4()),
        "aud": "DIGITAL_API",
        "brand_code": "YBS",
        "scope": scope,
        "channel": "SAPP",
        "registration_id": str(uuid.uuid4()),
        "verification_method": "BIOMETRIC",
    }
    if jwt_customer_number is not None:
        message.update({"party_id": jwt_customer_number})

    return jwt.encode(message, signing_key, jwt_alg, headers)

def create_sales_jwt(scope, jwt_customer_number=customer_number, sub=customer_number):


    signing_key = jwk_from_pem(config.jwt_private_key_nonprod.encode())
    jwt = JWT()
    
    headers = {"kid": request_signing_key_id_private_sales, "alg": jwt_alg}
    message = {
        'aud': 'DIGITAL_API',
        'iss': 'Apigee',
        'iat': time(),
        'client': 'SmokeTest',
        'client_id': "BcCDie6ezwfa4wyVEUieFn0s1TNIPKAB",
        'sub': 'my-customer-id',
        'sub_type': 'system',
        'scope': scope,
        'brand_code': 'YBS',
        'channel': 'WEB',
        'verification_method': 'PASSWORD',
        'sid': str(uuid.uuid4())
    }

    if jwt_customer_number is not None:
        message.update({"party_id": jwt_customer_number})

    return jwt.encode(message, signing_key, jwt_alg, headers)
