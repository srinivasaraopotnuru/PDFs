# Device Registration Service

## To install and run
Make sure the submodules are initialised with: `git submodule update --init --recursive`.
In the working directory, run `make all`. If you are using google auth for gitlab then you'll need to generate an access token so that docker can log in.

This will:
* Create a docker network for the DB and registration service
* Download the oracle-xe image and start it.
* Create a 'Registration' user on Oracle DB for the service to use.
* Build and run the Registration Service image from the code in a docker container.

(NB: This will take a while the first time because the oracle-xe image is nearly 9Gb)

After changing the code, run `make nuke-registration-service` to get rid of the docker container. Then run `make build-run` to restart it.

`make run-tests` will run all of the unit tests.

## Info:
This service connects to an Oracle database and uses Flyway to create the schema.
[Click here for the Gitlab registry for this project](ecommgit.ybs.com:5050/savings-app/test-data/oracle-xe:18c)

## CI Requirements
* The developer will need to create their own Artifatory API Key for local builds (see https://www.jfrog.com/confluence/display/JFROG/User+Profile#UserProfile-APIKey)
* The developer will need to set the following in the $HOME/.gradle/gradle.properties:
  * artifactory_username=[Your uXXXXXX username]
  * artifactory_password=[Your API Key]
  * artifactory_contextUrl=https://artifactory.ybs.com/artifactory
* The following are redundant and should bre removed from $HOME/.gradle/gradle.properties if they exist: ybsMavenRepositoryUrl, ybsMavenRepositoryPublishUrl, ybsMavenCredentialsHeaderName, ybsMavenCredentialsHeaderValue
* GitlabCI environment variables GITLAB_USERNAME,GITLAB_PASSWORD,GITLAB_EMAIL required to commit/push git tags
* GitlabCI environment variable SSH_PRIVATE_KEY required for commit/push to digital-infrastructure project

### Building Oracle docker image yourself
* Clone this repository: https://github.com/fuzziebrain/docker-oracle-xe (note that this Github page contains useful 
information about accessing the newly-created database and the Docker container it lives within)
* Download Oracle Database 18c Express Edition for Linux x64 from
[here](https://www.oracle.com/technetwork/database/database-technologies/express-edition/downloads/index.html)
* Copy the rpm file into the files directory in the repo
* Build the docker using the Dockerfile in the repo.

### Pulling the image from gitlab
* Run the following:
```bash
docker login registry.gitlab.com
docker pull ecommgit.ybs.com:5050/savings-app/test-data/oracle-xe:18c
```

### Running the container
* Run the image with the following command:

```bash
docker run -d \
  -p 32118:1521 \
  -p 35518:5500 \
  --name=oracle-xe \
  --volume ~/docker/oracle-xe:/opt/oracle/oradata \
  oracle-xe:18c
```

* To run sql on inside the docker image

```bash
# create an interactive bash session in the container
docker exec -it oracle-xe bash
```
```
# then inside the container connect the database as the sysdba
$ORACLE_HOME/bin/sqlplus sys/Oracle18@localhost/XEPDB1 as sysdba
```

You can also connect with Intellij/DBeaver etc:
* Service name xepdb1
* Connection type: Service Name
* Host: localhost
* Port 32118
* Username system
* Password Oracle18 

### Creating the registration service user
This also requires the presence of a user to own the schema which will ultimately
be created automatically, but for now requires the following to be executed:

~~~
create user registration IDENTIFIED by registration;
grant create session to registration;
grant create table to registration;
alter user registration quota unlimited on system;
alter user registration quota unlimited on users;
grant create SEQUENCE to registration;
~~~

### Secret environment variables
Secret environment variables can be exported in a script mounted at '/usr/src/load_secrets.sh'
In order to start up, this service expects the following secret environment variables:
* REGISTRATION_DB_PASSWORD = password for connecting to the registration db

## GitLab pipeline
The pipeline inherits from a shared pipeline.
See the [README](https://ecommgit.ybs.com/ybs/enterprise/digital/shared-pipeline-library#services-pipeline) for more information

## Setting up IntelliJ

Note that these instructions won't work properly until the service is changed to build using
Java 11. This is due to the latest version of the formatter not supporting Java 8, so the build
runs an older version, whilst the plugin runs the latest version in the IDE Java 11 runtime which 
results in slightly different output. For now the formatter must be invoked via Gradle:
`./gradlew spotlessJavaApply`

1. Install the [google-java-format](https://plugins.jetbrains.com/plugin/8527-google-java-format) plugin.
2. Add intellij format file for import order:
    1. Go to `Preferences/Settings > Editor > Code Style > Java`
    2. Click the cog next to the Scheme drop down
    3. Go to `Import Scheme > Intellij IDEA code style XML`
    4. Import `assurance/intellij-java-google-style.xml`

## Setting up Git

### Check for formatting before commit

create the file `.git/hooks/pre-commit` with the contents:

```
#!/bin/sh

# Stash instaged changes so they trigger a potential failure
git stash --keep-index > /dev/null

./gradlew spotlessJavaCheck > /dev/null
result=$?

if [ $result -ne 0 ]; then
	echo Commit failed: staged code is not formatted correctly. Please run ./gradlew spotlessJavaApply and stage the changes before commiting
fi

# Reapply stashed changes
git stash pop > /dev/null

exit $result
```

and make sure it's executable bit is set for your user:

```
chmod u+x .git/hooks/pre-commit
```

### Ignore large formatting changes in git blame
git config blame.ignoreRevsFile .git-blame-ignore-revs

