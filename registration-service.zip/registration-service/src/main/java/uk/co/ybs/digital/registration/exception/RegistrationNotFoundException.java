package uk.co.ybs.digital.registration.exception;

import java.util.UUID;

public class RegistrationNotFoundException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public RegistrationNotFoundException(final UUID registrationId) {
    super(String.format("Registration not found for ID: %s", registrationId));
  }
}
