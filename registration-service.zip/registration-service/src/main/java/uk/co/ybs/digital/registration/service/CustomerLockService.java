package uk.co.ybs.digital.registration.service;

import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.registration.exception.UnableToToLockOnCustomerException;
import uk.co.ybs.digital.registration.model.CustomerLock;
import uk.co.ybs.digital.registration.repository.CustomerLockRepository;

@RequiredArgsConstructor
@Service
public class CustomerLockService {

  private final CustomerLockRepository customerRepository;

  /*
   * Propagation.MANDATORY requires that a Transaction context exists to ensure that this service is not called
   * outside of a transaction and would silently do nothing.
   *
   * You can still get in a state where two threads attempt to save the a CustomerLock at the same time.
   * In this case (should be very rare), we'll throw an exception and let the client deal with it.
   */
  @Transactional(propagation = Propagation.MANDATORY)
  public CustomerLock acquireCustomerLock(final Long partyId) {
    try {
      return customerRepository
          .findByPartyId(partyId)
          .orElseGet(() -> customerRepository.saveAndFlush(new CustomerLock(partyId)));
    } catch (DataIntegrityViolationException e) {
      throw new UnableToToLockOnCustomerException(partyId);
    }
  }
}
