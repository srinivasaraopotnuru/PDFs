package uk.co.ybs.digital.registration.model;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "APP_DEVICE_REG_STATUS_TYPES")
@EntityListeners(AuditingEntityListener.class)
public class RegistrationStatusType {
  public enum Name {
    INITIAL,
    REGISTERED,
    EXPIRED,
    REVOKED
  }

  @Id @EqualsAndHashCode.Include private Long code;

  @NotNull private String description;

  @NotNull
  @Enumerated(EnumType.STRING)
  private RegistrationStatusType.Name name;
}
