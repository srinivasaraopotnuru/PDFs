package uk.co.ybs.digital.registration.model;

import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.springframework.data.domain.AuditorAware;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

@AllArgsConstructor
public class EntityAuditor implements AuditorAware<String> {
  public static final String AUDITOR_REQUEST_ATTRIBUTE =
      EntityAuditor.class.getName() + ".auditorName";

  @NonNull private final String defaultAuditor;

  @Override
  public Optional<String> getCurrentAuditor() {
    final String auditorName =
        Optional.ofNullable(RequestContextHolder.getRequestAttributes())
            .map(
                requestAttributes ->
                    requestAttributes.getAttribute(
                        AUDITOR_REQUEST_ATTRIBUTE, RequestAttributes.SCOPE_REQUEST))
            .map(Object::toString)
            .orElse(defaultAuditor);
    return Optional.of(auditorName);
  }
}
