package uk.co.ybs.digital.registration.exception;

public class InvalidKeyException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public InvalidKeyException(final String message) {
    super(message);
  }
}
