package uk.co.ybs.digital.registration.service;

import java.io.IOException;
import java.io.StringReader;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.util.encoders.DecoderException;
import org.bouncycastle.util.io.pem.PemReader;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CertificateVerificationService {

  public boolean verifyPem(final String pem) {
    Object pemObject = null;
    try (PemReader pemReader = new PemReader(new StringReader(pem))) {
      pemObject = pemReader.readPemObject();
    } catch (IOException | DecoderException e) {
      log.warn("Validation failed for PEM {}: {}", pem, e.getMessage());
    }

    return Objects.nonNull(pemObject);
  }
}
