package uk.co.ybs.digital.registration.service;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.auditing.AuditingHandler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;
import uk.co.ybs.digital.registration.exception.RegistrationDuplicateException;
import uk.co.ybs.digital.registration.model.App;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationRequest;

/**
 * Encapsulates the logic relating to registering a device. If an attempt to register a registration
 * ID that we already hold is made, then we reject the request. If a party ID which already has a
 * registration record in the initial state tries to register again then we log the fact and permit
 * it.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class RegistrationService {

  private final RegistrationRepository registrationRepository;
  private final RegistrationStatusTypeService registrationStatusTypeService;
  private final AppService appService;
  private final CustomerLockService customerLockService;
  private final Clock clock;
  private final AuditingHandler auditHandler;

  @Transactional
  public Registration storeRegistration(final RegistrationRequest registrationRequest) {
    final Long partyId = registrationRequest.getPartyId();
    customerLockService.acquireCustomerLock(partyId);

    final UUID registrationId = registrationRequest.getRegistrationId();
    final LocalDateTime now = LocalDateTime.now(clock);

    if (registrationRepository.existsByRegistrationId(registrationId)) {
      throw new RegistrationDuplicateException(registrationId);
    }

    if (registrationRepository.existsByPartyId(partyId)) {
      log.info("[AUDIT] Found existing registration for party id [{}]", partyId);
    } else {
      log.info("[AUDIT] No existing registrations found for party id [{}]", partyId);
    }

    final App app = appService.findByAppCode(registrationRequest.getAppCode());
    final RegistrationStatusType initialStatus =
        registrationStatusTypeService.findByName(RegistrationStatusType.Name.INITIAL);

    final Registration registration =
        Registration.builder()
            .registrationId(registrationRequest.getRegistrationId())
            .partyId(registrationRequest.getPartyId())
            .app(app)
            .build();
    registration.setCurrentStatus(initialStatus, now, auditHandler);

    final Registration persisted = registrationRepository.save(registration);

    log.info(
        "[AUDIT] Saved registration for id [{}], and party id [{}]. State is: INITIAL",
        registrationId,
        partyId);

    return persisted;
  }

  @Transactional
  public Optional<Registration> revokeRegistration(final Long partyId) {
    customerLockService.acquireCustomerLock(partyId);

    final List<Registration> activeRegistrations =
        registrationRepository.findByPartyIdAndCurrentStatusName(
            partyId, Collections.singletonList(RegistrationStatusType.Name.REGISTERED));

    if (activeRegistrations.size() > 1) {
      throw new InvalidRegistrationStateException(
          String.format("Multiple active registrations found for partyId: %d", partyId));
    } else if (activeRegistrations.isEmpty()) {
      return Optional.empty();
    } else {
      return Optional.of(revokeRegistration(activeRegistrations.get(0)));
    }
  }

  private Registration revokeRegistration(final Registration registration) {
    final LocalDateTime now = LocalDateTime.now(clock);

    final RegistrationStatusType revokedStatus =
        registrationStatusTypeService.findByName(RegistrationStatusType.Name.REVOKED);
    registration.setCurrentStatus(revokedStatus, now, auditHandler);

    final Registration saved = registrationRepository.save(registration);

    log.info(
        "[AUDIT] Revoked registration for registration id [{}] and party id [{}]. State is REVOKED.",
        registration.getRegistrationId(),
        registration.getPartyId());

    return saved;
  }
}
