package uk.co.ybs.digital.registration.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Embeddable
public class RegistrationStatusId implements Serializable {

  private static final long serialVersionUID = 1L;

  @Column(name = "APPDREG_SYSID")
  private Long registrationId;

  @Column(name = "APDVRG_CODE")
  private Long statusTypeCode;
}
