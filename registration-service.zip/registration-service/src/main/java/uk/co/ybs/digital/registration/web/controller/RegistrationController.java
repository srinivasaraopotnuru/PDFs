package uk.co.ybs.digital.registration.web.controller;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import springfox.documentation.annotations.ApiIgnore;
import uk.co.ybs.digital.registration.model.EntityAuditor;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.service.RegistrationMapper;
import uk.co.ybs.digital.registration.service.RegistrationQueryService;
import uk.co.ybs.digital.registration.service.RegistrationService;
import uk.co.ybs.digital.registration.service.audit.AuditingCertificateService;
import uk.co.ybs.digital.registration.web.controller.dto.PageResponse;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationRequest;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationResponse;
import uk.co.ybs.digital.registration.web.controller.dto.RequestMetadata;

@RestController
@RequiredArgsConstructor
@SuppressWarnings("unused") // All of these methods are called by Spring.
@Validated
public class RegistrationController {

  private final RegistrationService registrationService;
  private final RegistrationMapper registrationMapper;
  private final RegistrationQueryService registrationQueryService;
  private final AuditingCertificateService auditingCertificateService;

  private static final String UPDATED_AT = "updatedAt";
  private static final String QUERY = "query";
  private static final String INT = "int";

  @ApiOperation(
      value = "Record the fact that a user has begun the process of registering a new device")
  @PostMapping("/register")
  public RegistrationResponse createNewRegistration(
      @RequestBody @Valid final RegistrationRequest registrationRequest) {
    Registration storedRegistration = registrationService.storeRegistration(registrationRequest);
    return registrationMapper.registrationModelToResponse(storedRegistration);
  }

  @GetMapping(value = "/registration/{registrationId}")
  @ApiOperation(
      value =
          "Get registration for a Registration ID (the registration must have a status of REGISTERED)")
  public RegistrationResponse getRegistrationForId(@PathVariable final UUID registrationId) {
    Registration registration =
        registrationQueryService.getRegistrationWithRegisteredStatus(registrationId);
    return registrationMapper.registrationModelToResponse(registration);
  }

  @GetMapping(value = "/registration", params = "customerId")
  @ApiOperation(value = "Get all registrations for a customer id")
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "page",
        dataType = INT,
        paramType = QUERY,
        defaultValue = "0",
        value = "Results page you want to retrieve (0..N)"),
    @ApiImplicitParam(
        name = "size",
        dataType = INT,
        paramType = QUERY,
        defaultValue = "20",
        value = "Number of records per page."),
    @ApiImplicitParam(
        name = "sort",
        allowMultiple = true,
        dataType = "string",
        paramType = QUERY,
        value = "Sorting criteria in the format: property(,asc|desc).",
        defaultValue = "updatedAt,desc",
        allowableValues = UPDATED_AT)
  })
  @Deprecated
  public PageResponse<RegistrationResponse> getAllRegistrationsForCustomerId(
      @RequestParam final long customerId,
      @RequestParam(required = false, defaultValue = "") final String status,
      @PageableDefault(page = 0, size = 20, sort = UPDATED_AT, direction = Sort.Direction.DESC)
          @ApiIgnore
          final Pageable pageable) {
    final Page<Registration> customerRegistrations =
        registrationQueryService.getPartyRegistrations(customerId, status, pageable);
    return new PageResponse<>(
        customerRegistrations.map(registrationMapper::registrationModelToResponse));
  }

  @GetMapping(value = "/registration", params = "partyId")
  @ApiOperation(value = "Get all registrations for a party id")
  @ApiImplicitParams({
    @ApiImplicitParam(
        name = "page",
        dataType = INT,
        paramType = QUERY,
        defaultValue = "0",
        value = "Results page you want to retrieve (0..N)"),
    @ApiImplicitParam(
        name = "size",
        dataType = INT,
        paramType = QUERY,
        defaultValue = "20",
        value = "Number of records per page."),
    @ApiImplicitParam(
        name = "sort",
        allowMultiple = true,
        dataType = "string",
        paramType = QUERY,
        value = "Sorting criteria in the format: property(,asc|desc).",
        defaultValue = "updatedAt,desc",
        allowableValues = UPDATED_AT)
  })
  public PageResponse<RegistrationResponse> getAllRegistrationsForPartyId(
      @RequestParam final long partyId,
      @RequestParam(required = false, defaultValue = "") final String status,
      @PageableDefault(page = 0, size = 20, sort = UPDATED_AT, direction = Sort.Direction.DESC)
          @ApiIgnore
          final Pageable pageable) {
    final Page<Registration> partyRegistrations =
        registrationQueryService.getPartyRegistrations(partyId, status, pageable);
    return new PageResponse<>(
        partyRegistrations.map(registrationMapper::registrationModelToResponse));
  }

  // This returns either a ResponseEntity<RegistrationResponse> or ResponseEntity<String>
  @PutMapping(value = "/registration/revoke/{partyId}")
  @ApiOperation(
      value = "Revokes the only active registration for a party",
      response = RegistrationResponse.class)
  public ResponseEntity<Object> revokePartyRegistration(
      @PathVariable final long partyId,
      @RequestHeader(name = "x-ybs-admin-user", required = false) @Size(min = 1, max = 30)
          final String adminUser) {
    if (StringUtils.hasText(adminUser)) {
      RequestContextHolder.currentRequestAttributes()
          .setAttribute(
              EntityAuditor.AUDITOR_REQUEST_ATTRIBUTE, adminUser, RequestAttributes.SCOPE_REQUEST);
    }

    return registrationService
        .revokeRegistration(partyId)
        .map(registrationMapper::registrationModelToResponse)
        .map(response -> ResponseEntity.<Object>ok(response))
        .orElse(new ResponseEntity<Object>("No active registration found.", HttpStatus.NOT_FOUND));
  }

  @ApiOperation(value = "Store the certificates from the user's app")
  @PostMapping("/certificates")
  public ResponseEntity<RegistrationResponse> registerKeys(
      @RequestBody @Valid final RegisterKeysRequest registerKeysRequest,
      @ApiIgnore final RequestMetadata requestMetadata) {
    final Registration registration =
        auditingCertificateService.registerKeys(registerKeysRequest, requestMetadata);

    return ResponseEntity.ok(registrationMapper.registrationModelToResponse(registration));
  }
}
