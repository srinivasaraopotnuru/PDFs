package uk.co.ybs.digital.registration.service;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatus;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationResponse;

@Component
@AllArgsConstructor
public class RegistrationMapper {
  public RegistrationResponse registrationModelToResponse(
      @NotNull final Registration registration) {
    final RegistrationStatus currentStatus = registration.getCurrentStatus();

    return RegistrationResponse.builder()
        .registrationId(registration.getRegistrationId())
        .partyId(registration.getPartyId())
        .status(currentStatus.getStatusType().getName())
        .apiKey(registration.getApiKey())
        .scaKey(registration.getScaKey())
        .createdAt(registration.getCreatedAt())
        .updatedAt(registration.getUpdatedAt())
        .updatedBy(registration.getUpdatedBy())
        .build();
  }
}
