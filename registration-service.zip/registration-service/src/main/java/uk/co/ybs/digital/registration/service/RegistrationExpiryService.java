package uk.co.ybs.digital.registration.service;

import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.EXPIRED;
import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.INITIAL;
import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.REGISTERED;

import com.google.common.base.Objects;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.data.auditing.AuditingHandler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;

@Service
@RequiredArgsConstructor
public class RegistrationExpiryService {

  private final RegistrationStatusTypeService registrationStatusTypeService;
  private final RegistrationRepository registrationRepository;
  private final AuditingHandler auditHandler;

  /**
   * Updates the end date for all un-ended statuses belonging to a customer and adds an expired
   * status, excluding those that belong to the specified registration Id.
   *
   * @param partyId the party Id for whom the statuses should be ended.
   * @param registrationId the registation to exclude
   * @param now the time to record the expiration at
   */
  @Transactional
  public void expireAllIncompleteRegistrationsExcept(
      final Long partyId, final UUID registrationId, final LocalDateTime now) {

    final List<Registration> registrations =
        registrationRepository.findByPartyIdAndCurrentStatusName(
            partyId, Arrays.asList(INITIAL, REGISTERED));

    final List<Registration> registrationsToExpire =
        registrations.stream()
            .filter(
                registration -> !Objects.equal(registrationId, registration.getRegistrationId()))
            .collect(Collectors.toList());

    if (!registrationsToExpire.isEmpty()) {
      final RegistrationStatusType expired = registrationStatusTypeService.findByName(EXPIRED);
      registrationsToExpire.forEach(
          registration -> registration.setCurrentStatus(expired, now, auditHandler));
      registrationRepository.saveAll(registrationsToExpire);
    }
  }
}
