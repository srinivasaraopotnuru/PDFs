package uk.co.ybs.digital.registration.model;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.Type;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.auditing.AuditingHandler;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "APP_DEVICE_REGISTRATIONS")
@EntityListeners(AuditingEntityListener.class) // Allows us to use @Create/LastUpdated|By/Date
public class Registration {

  @Id
  @Column(name = "SYSID")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "APDREG_SEQ")
  @SequenceGenerator(sequenceName = "APDREG_SEQ", allocationSize = 1, name = "APDREG_SEQ")
  private Long sysId;

  @ToString.Exclude // Excluded to ensure toString does not trigger lazy load
  @Builder.Default
  @BatchSize(size = 50)
  @OneToMany(
      targetEntity = RegistrationStatus.class,
      mappedBy = "registration",
      cascade = CascadeType.ALL,
      orphanRemoval = true)
  private Set<RegistrationStatus> statuses = new HashSet<>();

  @NotNull
  @EqualsAndHashCode.Include
  @NaturalId
  @Type(type = "uuid-char")
  @Column(unique = true, nullable = false)
  private UUID registrationId;

  @NotNull
  @Positive
  @Column(name = "PERSON_PARTY_SYSID", nullable = false)
  private Long partyId;

  @NotNull
  @ManyToOne(targetEntity = App.class, optional = false)
  @JoinColumn(name = "APP_CODE")
  private App app;

  @Column private String apiKey;

  @Column private String scaKey;

  @CreatedBy
  @Column(name = "CREATE_ID", nullable = false, updatable = false)
  private String createdBy;

  @CreatedDate
  @Column(name = "CREATE_TIME", nullable = false, updatable = false)
  private LocalDateTime createdAt;

  @LastModifiedBy
  @Column(name = "UPDATE_ID")
  private String updatedBy;

  @LastModifiedDate
  @Column(name = "UPDATE_TIME")
  private LocalDateTime updatedAt;

  public Set<RegistrationStatus> getStatuses() {
    // Statuses should only be changed by calling setCurrentStatus
    return Collections.unmodifiableSet(statuses);
  }

  public void setCurrentStatus(
      final RegistrationStatusType statusType,
      final LocalDateTime statusStartTime,
      final AuditingHandler auditingHandler) {
    // End current status
    Optional<RegistrationStatus> existingStatusOfRequestedType = Optional.empty();

    boolean endedExistingStatus = false;
    for (final RegistrationStatus status : statuses) {
      final RegistrationStatusType existingStatusType = status.getStatusType();
      if (existingStatusType.equals(statusType)) {
        existingStatusOfRequestedType = Optional.of(status);
      } else if (!status.getEndDate().isPresent()) {
        status.setEndDate(statusStartTime);
        endedExistingStatus = true;
      }
    }

    boolean modifiedNewStatus = false;
    if (existingStatusOfRequestedType.isPresent()) {
      final RegistrationStatus toModify = existingStatusOfRequestedType.get();
      if (toModify.getEndDate().isPresent()) {
        toModify.setEndDate(null);
        modifiedNewStatus = true;
      }

      if (endedExistingStatus) {
        toModify.setStartDate(statusStartTime);
        modifiedNewStatus = true;
      }

    } else {
      final RegistrationStatus newStatus =
          new RegistrationStatus(this, statusType, statusStartTime);
      modifiedNewStatus = statuses.add(newStatus);
    }

    // Update our Audit status
    if (endedExistingStatus || modifiedNewStatus) {
      auditingHandler.markModified(this);
    }
  }

  public RegistrationStatus getCurrentStatus() {
    List<RegistrationStatus> statusesWithNoEndDate =
        this.statuses.stream()
            .filter(s -> !s.getEndDate().isPresent())
            .collect(Collectors.toList());
    if (statusesWithNoEndDate.size() == 0) {
      throw new InvalidRegistrationStateException(
          String.format(
              "No current status found for Registration id: %s. Statuses = %s",
              registrationId, getStatuses()));
    } else if (statusesWithNoEndDate.size() > 1) {
      throw new InvalidRegistrationStateException(
          String.format(
              "The registration %s has more than one active status so its state cannot be determined",
              registrationId));
    }
    return statusesWithNoEndDate.get(0);
  }
}
