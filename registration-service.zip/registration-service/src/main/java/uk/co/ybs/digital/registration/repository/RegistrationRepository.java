package uk.co.ybs.digital.registration.repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, Long> {
  Optional<Registration> findByRegistrationId(UUID registrationId);

  @Query(
      "SELECT DISTINCT r FROM Registration r "
          + "INNER JOIN r.statuses s "
          + "INNER JOIN s.statusType st "
          + "WHERE r.partyId=:partyId "
          + "AND s.endDate IS NULL "
          + "AND st.name IN (:statusNames)")
  List<Registration> findByPartyIdAndCurrentStatusName(
      @Param("partyId") Long partyId,
      @Param("statusNames") List<RegistrationStatusType.Name> statusNames);

  // Tried to use an @NamedQuery to prevent duplication of this query, however page sorting doesn't
  // work when doing this
  @Query(
      "SELECT DISTINCT r FROM Registration r "
          + "INNER JOIN r.statuses s "
          + "INNER JOIN s.statusType st "
          + "WHERE r.partyId=:partyId "
          + "AND s.endDate IS NULL "
          + "AND st.name = :statusName")
  Page<Registration> findByPartyIdAndCurrentStatusName(
      @Param("partyId") Long partyId,
      @Param("statusName") RegistrationStatusType.Name statusName,
      Pageable pageable);

  Page<Registration> findByPartyId(Long partyId, Pageable pageable);

  boolean existsByRegistrationId(UUID registrationId);

  boolean existsByPartyId(Long partyId);
}
