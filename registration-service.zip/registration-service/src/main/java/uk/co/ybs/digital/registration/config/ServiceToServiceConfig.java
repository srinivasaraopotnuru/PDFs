package uk.co.ybs.digital.registration.config;

import lombok.AllArgsConstructor;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import uk.co.ybs.digital.registration.service.audit.AuditServiceProperties;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnectorFactory;

@Configuration
@EnableConfigurationProperties(AuditServiceProperties.class)
@AllArgsConstructor
public class ServiceToServiceConfig {

  private final AuditServiceProperties auditServiceProperties;

  @Bean
  public WebClient auditServiceWebClient(
      final WebClient.Builder builder,
      final RequestSigningClientHttpConnectorFactory requestSigningClientHttpConnectorFactory) {
    return builder
        .baseUrl(auditServiceProperties.getUrl().toString())
        .clientConnector(requestSigningClientHttpConnectorFactory.build())
        .build();
  }
}
