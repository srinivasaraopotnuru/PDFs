package uk.co.ybs.digital.registration.config;

import java.time.Clock;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import uk.co.ybs.digital.registration.web.RequestMetadataArgumentResolver;

@Configuration
@Slf4j
public class RegistrationConfig implements WebMvcConfigurer {
  @Bean
  public Clock clock() {
    // The application should be run in UK timezone for consistency with other
    // YBS timezone handling.
    final Clock systemClock = Clock.systemDefaultZone();
    log.info("System clock is: {}", systemClock);
    return systemClock;
  }

  @Bean
  public Docket api() {
    return new Docket(DocumentationType.SWAGGER_2)
        .select()
        .apis(RequestHandlerSelectors.basePackage("uk.co.ybs.digital.registration.web.controller"))
        .paths(PathSelectors.any())
        .build();
  }

  @Override
  public void addArgumentResolvers(final List<HandlerMethodArgumentResolver> resolvers) {
    resolvers.add(new RequestMetadataArgumentResolver());
  }
}
