package uk.co.ybs.digital.registration.web.controller.dto;

public enum VerificationMethod {
  BIOMETRIC,
  PASSCODE
}
