package uk.co.ybs.digital.registration.web;

import java.util.Collections;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.logging.filters.request.BadRequestIdErrorResponseFactory;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.logging.filters.session.BadSessionIdErrorResponseFactory;
import uk.co.ybs.digital.logging.filters.session.MissingSessionIdErrorResponseFactory;
import uk.co.ybs.digital.logging.filters.session.SessionIdSourceType;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse.ErrorItem;
import uk.co.ybs.digital.security.authorize.AuthorizationErrorResponseFactory;

@Component
public class FilterErrorResponseFactory
    implements AuthorizationErrorResponseFactory<ErrorResponse>,
        BadRequestIdErrorResponseFactory<ErrorResponse>,
        BadSessionIdErrorResponseFactory<ErrorResponse>,
        MissingSessionIdErrorResponseFactory<ErrorResponse> {

  @Override
  public ErrorResponse createAccessDeniedInvalidSignatureErrorResponse(
      final HttpServletRequest request) {
    final HttpStatus httpStatus = HttpStatus.FORBIDDEN;
    return ErrorResponse.builder()
        .id(getRequestId(request))
        .code(httpStatus.value() + " " + httpStatus.getReasonPhrase())
        .message(httpStatus.getReasonPhrase())
        .errors(
            Collections.singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorItem.INVALID_REQUEST_SIGNATURE)
                    .message("Access Denied")
                    .build()))
        .build();
  }

  @Override
  public ErrorResponse createAccessDeniedErrorResponse(final HttpServletRequest request) {
    throw new UnsupportedOperationException("Not implemented");
  }

  @Override
  public ErrorResponse createInvalidRequestIdErrorResponse(
      final HttpServletRequest request, final String headerName) {
    final HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
    final UUID requestId = getRequestId(request);

    return ErrorResponse.builder(httpStatus)
        .id(requestId)
        .message(httpStatus.getReasonPhrase())
        .errors(
            Collections.singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorItem.HEADER_INVALID)
                    .message("Header invalid")
                    .path(headerName)
                    .build()))
        .build();
  }

  @Override
  public ErrorResponse createInvalidSessionIdErrorResponse(
      final HttpServletRequest request, final SessionIdSourceType sourceType) {
    final HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
    final UUID requestId = getRequestId(request);

    return ErrorResponse.builder(httpStatus)
        .id(requestId)
        .message(httpStatus.getReasonPhrase())
        .errors(
            Collections.singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorItem.FIELD_INVALID)
                    .message("SessionId is not a valid UUID")
                    .path(sourceType.toString())
                    .build()))
        .build();
  }

  @Override
  public ErrorResponse createMissingSessionIdErrorResponse(
      final HttpServletRequest request, final SessionIdSourceType sourceType) {
    throw new UnsupportedOperationException("Not implemented");
  }

  public static UUID getRequestId(final HttpServletRequest request) {
    return (UUID) request.getAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME);
  }
}
