package uk.co.ybs.digital.registration.service;

import java.util.Collections;
import java.util.UUID;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.registration.exception.InvalidSortFieldException;
import uk.co.ybs.digital.registration.exception.RegistrationNotFoundException;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatus;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;

/** Logic for querying for info about the registration and its status. */
@Service
@RequiredArgsConstructor
@Slf4j
public class RegistrationQueryService {
  private static final String VALID_SORT_FIELD = "updatedAt";

  @NonNull private final RegistrationRepository registrationRepository;

  /*
   * Returns the registration for a registration id:
   * The registration exists
   * The latest status of the registration is REGISTERED
   */
  public Registration getRegistrationWithRegisteredStatus(final UUID registrationId) {
    Registration registration =
        registrationRepository
            .findByRegistrationId(registrationId)
            .orElseThrow(() -> new RegistrationNotFoundException(registrationId));

    RegistrationStatus currentRegistrationState = registration.getCurrentStatus();
    RegistrationStatusType.Name currentStatusType =
        currentRegistrationState.getStatusType().getName();
    if (currentStatusType != RegistrationStatusType.Name.REGISTERED) {
      log.error(
          String.format(
              "The current state on RegistrationId %s is %s. It should be REGISTERED",
              registrationId, currentRegistrationState.getStatusType().getName()));
      throw new RegistrationNotFoundException(registrationId);
    }
    return registration;
  }

  /*
   * Returns the registrations for a party with pagination details.
   */
  public Page<Registration> getPartyRegistrations(
      final Long partyId, final String status, final Pageable pageable) {
    validateSortField(pageable);

    // Need to do the below, in case there are duplicate values for the sorted column, we return
    // them in a stable order
    Sort sort = pageable.getSort().and(Sort.by(Sort.Direction.ASC, "sysId"));
    Pageable newPageable = PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort);

    if (status.isEmpty()) {
      return registrationRepository.findByPartyId(partyId, newPageable);
    } else {
      final RegistrationStatusType.Name statusName;
      try {
        statusName = RegistrationStatusType.Name.valueOf(status);
      } catch (IllegalArgumentException e) {
        log.info("Unexpected registration status: {}", status);
        return new PageImpl<>(Collections.emptyList(), newPageable, 0);
      }

      return registrationRepository.findByPartyIdAndCurrentStatusName(
          partyId, statusName, newPageable);
    }
  }

  private void validateSortField(final Pageable pageable) {
    pageable
        .getSort()
        .forEach(
            sort -> {
              if (!(VALID_SORT_FIELD.equals(sort.getProperty()))) {
                throw new InvalidSortFieldException(VALID_SORT_FIELD);
              }
            });
  }
}
