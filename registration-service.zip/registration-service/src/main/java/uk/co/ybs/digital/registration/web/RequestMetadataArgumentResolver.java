package uk.co.ybs.digital.registration.web;

import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.springframework.core.MethodParameter;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.registration.web.controller.dto.RequestMetadata;

public class RequestMetadataArgumentResolver implements HandlerMethodArgumentResolver {

  private static final String HEADER_CHANNEL = "x-ybs-channel";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";

  @Override
  public boolean supportsParameter(final MethodParameter parameter) {
    return parameter.getParameterType().equals(RequestMetadata.class);
  }

  @Override
  public Object resolveArgument(
      @NonNull final MethodParameter methodParameter,
      final ModelAndViewContainer mavContainer,
      @NonNull final NativeWebRequest nativeWebRequest,
      final WebDataBinderFactory binderFactory)
      throws Exception {
    final HttpServletRequest httpServletRequest =
        ((ServletWebRequest) nativeWebRequest).getRequest();
    return RequestMetadata.builder()
        .requestId(
            (UUID) httpServletRequest.getAttribute(RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME))
        .ipAddress(httpServletRequest.getRemoteAddr())
        .channel(getHeader(HEADER_CHANNEL, httpServletRequest, methodParameter))
        .brandCode(getHeader(HEADER_BRAND_CODE, httpServletRequest, methodParameter))
        .build();
  }

  private String getHeader(
      final String name,
      final HttpServletRequest httpServletRequest,
      final MethodParameter methodParameter)
      throws MissingRequestHeaderException {
    return Optional.ofNullable(httpServletRequest.getHeader(name))
        .orElseThrow(() -> new MissingRequestHeaderException(name, methodParameter));
  }
}
