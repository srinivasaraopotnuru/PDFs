package uk.co.ybs.digital.registration.exception;

import uk.co.ybs.digital.registration.model.RegistrationStatusType;

public class StaticDataMissingException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public StaticDataMissingException(final RegistrationStatusType.Name type) {
    this(String.format("Could not retrieve status type with name [%s] from database", type));
  }

  public StaticDataMissingException(final String message) {
    super(message);
  }
}
