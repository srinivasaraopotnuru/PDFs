package uk.co.ybs.digital.registration.service.audit.dto;

import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class AuditRegistrationRequest {
  @NonNull private final String ipAddress;

  @NonNull private final UserSession userSession;
}
