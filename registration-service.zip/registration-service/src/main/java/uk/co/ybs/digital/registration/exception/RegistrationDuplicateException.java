package uk.co.ybs.digital.registration.exception;

import java.util.UUID;

public class RegistrationDuplicateException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public RegistrationDuplicateException(final UUID registrationId) {
    super(
        String.format(
            "Attempted to register with an already existing registration Id [%s]", registrationId));
  }
}
