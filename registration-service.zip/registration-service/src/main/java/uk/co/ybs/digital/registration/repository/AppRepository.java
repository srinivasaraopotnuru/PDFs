package uk.co.ybs.digital.registration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.registration.model.App;

@Repository
public interface AppRepository extends JpaRepository<App, String> {}
