package uk.co.ybs.digital.registration.service.audit;

import io.micrometer.core.annotation.Timed;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import uk.co.ybs.digital.logging.calls.CallLogged;
import uk.co.ybs.digital.registration.service.audit.dto.AuditRegistrationRequest;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse;
import uk.co.ybs.digital.registration.web.controller.dto.RequestMetadata;

@Service
@RequiredArgsConstructor
@Timed(extraTags = {"type", "s2s"})
@CallLogged(logParameters = true)
public class AuditService {

  private static final String UNEXPECTED_ERROR_MESSAGE = "Error calling audit service";
  private static final String HTTP_STATUS_ERROR_MESSAGE_FORMAT =
      "Audit service returned error status: %s";
  private static final String HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT =
      HTTP_STATUS_ERROR_MESSAGE_FORMAT + ", with error response: %s";

  private static final String REQUEST_ID_HEADER = "x-ybs-request-id";

  private final WebClient auditServiceWebClient;

  public void auditRegistration(
      final AuditRegistrationRequest request, final RequestMetadata requestMetadata) {
    auditServiceWebClient
        .post()
        .uri("/registration/register")
        .header(REQUEST_ID_HEADER, requestMetadata.getRequestId().toString())
        .accept(MediaType.APPLICATION_JSON)
        .bodyValue(request)
        .retrieve()
        .onStatus(HttpStatus::isError, this::handleHttpStatusError)
        .toBodilessEntity()
        .onErrorMap(
            this::isUnhandledException,
            thrown -> new AuditServiceException(UNEXPECTED_ERROR_MESSAGE, thrown))
        .block();
  }

  private boolean isUnhandledException(final Throwable thrown) {
    return !(thrown instanceof AuditServiceException);
  }

  private Mono<AuditServiceException> handleHttpStatusError(final ClientResponse clientResponse) {
    final HttpStatus status = clientResponse.statusCode();
    return clientResponse
        .bodyToMono(ErrorResponse.class)
        .onErrorMap(
            thrownWhenReadingErrorResponse ->
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()),
                    thrownWhenReadingErrorResponse))
        .switchIfEmpty(
            Mono.error(
                new AuditServiceException(
                    String.format(HTTP_STATUS_ERROR_MESSAGE_FORMAT, status.value()))))
        .map(
            errorResponse ->
                new AuditServiceException(
                    String.format(
                        HTTP_STATUS_ERROR_WITH_ERROR_RESPONSE_MESSAGE_FORMAT,
                        status.value(),
                        errorResponse)));
  }
}
