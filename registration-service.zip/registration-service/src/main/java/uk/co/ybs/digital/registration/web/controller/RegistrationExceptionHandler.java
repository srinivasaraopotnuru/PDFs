package uk.co.ybs.digital.registration.web.controller;

import javax.validation.ConstraintViolationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.registration.exception.InvalidKeyException;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;
import uk.co.ybs.digital.registration.exception.InvalidSortFieldException;
import uk.co.ybs.digital.registration.exception.PartyIdMismatchException;
import uk.co.ybs.digital.registration.exception.RegistrationDuplicateException;
import uk.co.ybs.digital.registration.exception.RegistrationNotFoundException;
import uk.co.ybs.digital.registration.exception.StaticDataMissingException;
import uk.co.ybs.digital.registration.exception.UnableToToLockOnCustomerException;
import uk.co.ybs.digital.registration.web.RequestIdHelper;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse;

@SuppressWarnings("unused") // All of these methods are called by spring.
@ControllerAdvice
@Slf4j
public final class RegistrationExceptionHandler {

  private static final String INVALID_REQUEST_BODY = "Invalid request body";
  private static final String INTERNAL_SERVER_ERROR = "Internal Server Error";

  @ExceptionHandler(RegistrationDuplicateException.class)
  public ResponseEntity<ErrorResponse> handleRegistrationDuplicateException(
      final RegistrationDuplicateException ex, final WebRequest request) {
    log.warn("DuplicateRegistration", ex);

    final HttpStatus status = HttpStatus.BAD_REQUEST;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.REGISTRATION_DUPLICATE)
                    .message("registrationId already exists")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(InvalidSortFieldException.class)
  public ResponseEntity<Object> handleInvalidSortFieldException(
      final InvalidSortFieldException ex, final WebRequest request) {
    log.warn("InvalidSortField", ex);

    final HttpStatus status = HttpStatus.BAD_REQUEST;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Invalid request")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message("Invalid sort")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(StaticDataMissingException.class)
  public ResponseEntity<Object> handleStaticDataMissingException(
      final StaticDataMissingException ex, final WebRequest request) {
    log.error("UnknownAppOrStatus", ex);

    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message(INTERNAL_SERVER_ERROR)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNEXPECTED_ERROR)
                    .message(INTERNAL_SERVER_ERROR)
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(InvalidRegistrationStateException.class)
  public ResponseEntity<Object> handleInvalidRegistrationStateException(
      final InvalidRegistrationStateException ex, final WebRequest request) {
    log.warn("InvalidRegistrationState", ex);

    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message(INTERNAL_SERVER_ERROR)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNEXPECTED_ERROR)
                    .message(INTERNAL_SERVER_ERROR)
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(RegistrationNotFoundException.class)
  public ResponseEntity<Object> handleRegistrationNotFoundException(
      final RegistrationNotFoundException ex, final WebRequest request) {
    log.warn("RegistrationNotFound", ex);

    final HttpStatus status = HttpStatus.NOT_FOUND;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Resource not found")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.RESOURCE_NOT_FOUND)
                    .message("Resource not found")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(PartyIdMismatchException.class)
  public ResponseEntity<Object> handlePartyIdMismatchException(
      final PartyIdMismatchException ex, final WebRequest request) {
    log.warn("PartyIdMismatch", ex);

    final HttpStatus status = HttpStatus.UNAUTHORIZED;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message("Unauthorized")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNAUTHORIZED)
                    .message("Unauthorized")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(InvalidKeyException.class)
  public ResponseEntity<Object> handleInvalidKeyException(
      final InvalidKeyException ex, final WebRequest request) {
    log.warn("InvalidPemKey", ex);

    final HttpStatus status = HttpStatus.BAD_REQUEST;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message("Invalid PEM key")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(UnableToToLockOnCustomerException.class)
  public ResponseEntity<Object> handleUnableToToLockOnCustomerException(
      final UnableToToLockOnCustomerException ex, final WebRequest request) {
    log.error("UpdateLock", ex);

    final HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message(INTERNAL_SERVER_ERROR)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNEXPECTED_ERROR)
                    .message(INTERNAL_SERVER_ERROR)
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(ConstraintViolationException.class)
  public ResponseEntity<ErrorResponse> handleConstraintViolation(
      final ConstraintViolationException ex, final WebRequest request) {
    log.warn("InvalidRequest", ex);

    final HttpStatus status = HttpStatus.BAD_REQUEST;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message(ex.getMessage())
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }

  @ExceptionHandler(HttpMessageConversionException.class)
  public ResponseEntity<ErrorResponse> handleHttpMessageConversionException(
      final HttpMessageConversionException ex, final WebRequest request) {
    log.warn("InvalidRequest", ex);

    final HttpStatus status = HttpStatus.BAD_REQUEST;
    ErrorResponse errorResponse =
        ErrorResponse.builder(status)
            .id(RequestIdHelper.getRequestId(request))
            .message(INVALID_REQUEST_BODY)
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message("Invalid JSON")
                    .build())
            .build();

    return ResponseEntity.status(status).body(errorResponse);
  }
}
