package uk.co.ybs.digital.registration.model;

import io.swagger.annotations.ApiModelProperty;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
public class App {
  @Id @NotNull @EqualsAndHashCode.Include private String code;

  @NotNull
  @ApiModelProperty(hidden = true)
  private String name;

  @NotNull
  @ApiModelProperty(hidden = true)
  private String description;

  @NotNull private String brandCode;
}
