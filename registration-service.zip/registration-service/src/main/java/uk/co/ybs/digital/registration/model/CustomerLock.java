package uk.co.ybs.digital.registration.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/*
 * This table is to allow locking on the DB, so that only one thread can update/insert a customer's data at a time.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Entity
@Table(name = "CUSTOMER_LOCK")
public class CustomerLock {
  @Id
  @Column(name = "PERSON_PARTY_SYSID")
  @EqualsAndHashCode.Include
  private Long partyId;
}
