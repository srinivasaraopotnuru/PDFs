package uk.co.ybs.digital.registration.web.controller.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import java.beans.ConstructorProperties;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class RegistrationRequest extends AbstractRegistrationDto {

  @NotNull
  @JsonProperty(required = true)
  @ApiModelProperty(required = true, example = "SAPP")
  private String appCode;

  @Builder
  @ConstructorProperties({"registrationId", "partyId", "appCode"})
  public RegistrationRequest(final UUID registrationId, final long partyId, final String appCode) {
    super(registrationId, partyId);
    this.appCode = appCode;
  }
}
