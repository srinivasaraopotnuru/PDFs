package uk.co.ybs.digital.registration.web.controller.dto;

import io.swagger.annotations.ApiModelProperty;
import java.beans.ConstructorProperties;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;

@Data
@EqualsAndHashCode(callSuper = true)
public class RegistrationResponse extends AbstractRegistrationDto {
  private RegistrationStatusType.Name status;
  private String apiKey;
  private String scaKey;
  private LocalDateTime createdAt;
  private LocalDateTime updatedAt;
  private String updatedBy;

  @Deprecated
  @ApiModelProperty(required = true)
  public long getCustomerId() {
    return getPartyId();
  }

  @Builder
  @ConstructorProperties({
    "registrationId",
    "partyId",
    "status",
    "apiKey",
    "scaKey",
    "createdAt",
    "updatedAt",
    "updatedBy"
  })
  public RegistrationResponse( // NOPMD
      final UUID registrationId,
      final Long partyId,
      final RegistrationStatusType.Name status,
      final String apiKey,
      final String scaKey,
      final LocalDateTime createdAt,
      final LocalDateTime updatedAt,
      final String updatedBy) {
    super(registrationId, partyId);
    this.status = status;
    this.apiKey = apiKey;
    this.scaKey = scaKey;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
    this.updatedBy = updatedBy;
  }
}
