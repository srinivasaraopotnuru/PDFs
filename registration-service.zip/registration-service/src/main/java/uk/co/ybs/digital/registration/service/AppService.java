package uk.co.ybs.digital.registration.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.registration.exception.StaticDataMissingException;
import uk.co.ybs.digital.registration.model.App;
import uk.co.ybs.digital.registration.repository.AppRepository;

@Service
@RequiredArgsConstructor
public class AppService {

  private final AppRepository appRepository;

  public App findByAppCode(final String appCode) {
    return appRepository
        .findById(appCode)
        .orElseThrow(
            () ->
                new StaticDataMissingException(
                    String.format(
                        "Could not retrieve app for code [%s] from the database", appCode)));
  }
}
