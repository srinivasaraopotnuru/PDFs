package uk.co.ybs.digital.registration.exception;

import java.util.UUID;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;

public class InvalidRegistrationStateException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public InvalidRegistrationStateException(final String message) {
    super(message);
  }

  public InvalidRegistrationStateException(
      final UUID registrationId,
      final RegistrationStatusType.Name expected,
      final RegistrationStatusType.Name actual,
      final String msg) {
    super(
        String.format(
            "Registration [%s] was expected to be [%s] but was [%s]: %s",
            registrationId, expected, actual, msg));
  }
}
