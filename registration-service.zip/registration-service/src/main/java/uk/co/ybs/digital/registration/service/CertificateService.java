package uk.co.ybs.digital.registration.service;

import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.INITIAL;
import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.REGISTERED;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Function;
import lombok.RequiredArgsConstructor;
import org.springframework.data.auditing.AuditingHandler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.registration.exception.InvalidKeyException;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;
import uk.co.ybs.digital.registration.exception.PartyIdMismatchException;
import uk.co.ybs.digital.registration.exception.RegistrationNotFoundException;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.model.RegistrationStatusType.Name;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest;

@Service
@RequiredArgsConstructor
public class CertificateService {
  private final Clock clock;
  private final RegistrationExpiryService expiryService;
  private final RegistrationRepository registrationRepository;
  private final RegistrationStatusTypeService registrationStatusTypeService;
  private final CertificateVerificationService certificateVerificationService;
  private final CustomerLockService customerLockService;
  private final AuditingHandler auditHandler;

  @Transactional
  public Registration registerPemKeys(final RegisterKeysRequest request) {
    final Long partyId = request.getPartyId();
    customerLockService.acquireCustomerLock(partyId);

    final LocalDateTime now = LocalDateTime.now(clock);
    final UUID registrationId = request.getRegistrationId();

    final Registration existingRegistration =
        registrationRepository
            .findByRegistrationId(registrationId)
            .map(belongsToParty(partyId))
            .map(this::inAValidState)
            .orElseThrow(() -> new RegistrationNotFoundException(registrationId));

    checkKeysPresent(request);
    checkKeysValid(request);

    expiryService.expireAllIncompleteRegistrationsExcept(partyId, registrationId, now);

    final RegistrationStatusType registered = registrationStatusTypeService.findByName(REGISTERED);

    existingRegistration.setApiKey(request.getApiKey());
    existingRegistration.setScaKey(request.getScaKey());
    existingRegistration.setCurrentStatus(registered, now, auditHandler);

    return registrationRepository.save(existingRegistration);
  }

  private void checkKeysPresent(final RegisterKeysRequest requestRegistration) {
    if (Objects.isNull(requestRegistration.getApiKey())
        || Objects.isNull(requestRegistration.getScaKey())) {
      throw new InvalidKeyException("Both API key and SCA key must be supplied");
    }
  }

  private void checkKeysValid(final RegisterKeysRequest requestRegistration) {
    if (!(certificateVerificationService.verifyPem(requestRegistration.getApiKey())
        && certificateVerificationService.verifyPem(requestRegistration.getScaKey()))) {
      throw new InvalidKeyException("Invalid key. Keys should be in PEM format");
    }
  }

  private Registration inAValidState(final Registration registration) {
    Name currentStatusType = registration.getCurrentStatus().getStatusType().getName();
    if (currentStatusType != INITIAL) {
      throw new InvalidRegistrationStateException(
          registration.getRegistrationId(), INITIAL, currentStatusType, "cannot add certificates");
    }
    return registration;
  }

  /**
   * Returns a function that takes a registration and returns it as long as it has the same party Id
   * as the argument throws a {@see PartyIdMismatchException} if the party does not match
   *
   * @param partyId the party Id to compare the registration against
   * @return the function that compares the registration's party Id with the <code>partyId</code>
   */
  private static Function<Registration, Registration> belongsToParty(final Long partyId) {
    return registration -> {
      if (!Objects.equals(registration.getPartyId(), partyId)) {
        throw new PartyIdMismatchException(partyId, registration.getRegistrationId());
      }
      return registration;
    };
  }
}
