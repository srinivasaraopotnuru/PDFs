package uk.co.ybs.digital.registration.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.registration.exception.StaticDataMissingException;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.repository.RegistrationStatusTypeRepository;

@Service
@RequiredArgsConstructor
public class RegistrationStatusTypeService {

  private static final long serialVersionUID = 1L;

  private final RegistrationStatusTypeRepository registrationStatusTypeRepository;

  public RegistrationStatusType findByName(final RegistrationStatusType.Name name) {
    return registrationStatusTypeRepository
        .findByName(name)
        .orElseThrow(() -> new StaticDataMissingException(name));
  }
}
