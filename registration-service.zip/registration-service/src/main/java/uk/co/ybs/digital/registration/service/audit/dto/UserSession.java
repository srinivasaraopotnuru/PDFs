package uk.co.ybs.digital.registration.service.audit.dto;

import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;
import uk.co.ybs.digital.registration.web.controller.dto.VerificationMethod;

@Value
@Builder
public class UserSession {

  @NonNull public UUID registrationId;

  @NonNull public VerificationMethod verificationMethod;

  @NonNull public UUID sessionId;

  @NonNull public Long partyId;

  @NonNull public String channel;

  @NonNull public String brandCode;

  public String title;

  public String surname;

  public String email;
}
