package uk.co.ybs.digital.registration.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;

@Repository
public interface RegistrationStatusTypeRepository
    extends JpaRepository<RegistrationStatusType, Long> {
  Optional<RegistrationStatusType> findByName(RegistrationStatusType.Name name);
}
