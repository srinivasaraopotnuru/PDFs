package uk.co.ybs.digital.registration.web.controller.dto;

import io.swagger.annotations.ApiModelProperty;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Value;

@Data
@EqualsAndHashCode(callSuper = true)
public class RegisterKeysRequest extends AbstractRegistrationDto {

  @NotNull(message = "You must specify an apiKey")
  private String apiKey;

  @NotNull(message = "You must specify an scaKey")
  private String scaKey;

  @NotNull(message = "You must specify a sessionId")
  @ApiModelProperty(required = true, example = "abcd1234-ab65-4f3e-a3d3-abcdef123456")
  private UUID sessionId;

  @NotNull(message = "You must specify a verificationMethod")
  @ApiModelProperty(required = true, example = "BIOMETRIC")
  private VerificationMethod verificationMethod;

  @NotNull(message = "You must specify customer details")
  @Valid
  @ApiModelProperty(required = true)
  private Customer customer;

  @Builder
  public RegisterKeysRequest( // NOPMD
      final UUID registrationId,
      final long partyId,
      final String apiKey,
      final String scaKey,
      final UUID sessionId,
      final VerificationMethod verificationMethod,
      final Customer customer) {
    super(registrationId, partyId);
    this.apiKey = apiKey;
    this.scaKey = scaKey;
    this.sessionId = sessionId;
    this.verificationMethod = verificationMethod;
    this.customer = customer;
  }

  @Value
  @Builder
  public static class Customer {
    @ApiModelProperty(example = "Mr")
    private String title;

    @NotNull(message = "You must specify firstName")
    @ApiModelProperty(required = true, example = "John")
    private String firstName;

    @NotNull(message = "You must specify lastName")
    @ApiModelProperty(required = true, example = "Smith")
    private String lastName;

    @ApiModelProperty(example = "john.smith@ybs.co.uk")
    private String email;
  }
}
