package uk.co.ybs.digital.registration.web.controller.dto;

import java.util.UUID;
import lombok.Builder;
import lombok.NonNull;
import lombok.Value;

@Value
@Builder
public class RequestMetadata {
  @NonNull private final UUID requestId;
  @NonNull private final String ipAddress;
  @NonNull private final String channel;
  @NonNull private final String brandCode;
}
