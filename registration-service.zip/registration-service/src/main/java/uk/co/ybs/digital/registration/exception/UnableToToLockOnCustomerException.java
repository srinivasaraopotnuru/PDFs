package uk.co.ybs.digital.registration.exception;

public class UnableToToLockOnCustomerException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public UnableToToLockOnCustomerException(final Long partyId) {
    super(String.format("Unable to lock on on party: %d", partyId));
  }
}
