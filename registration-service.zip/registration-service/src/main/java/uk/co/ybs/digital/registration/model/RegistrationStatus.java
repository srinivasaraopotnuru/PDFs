package uk.co.ybs.digital.registration.model;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Builder
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "APP_DEVICE_REG_STATUSES")
@EntityListeners(AuditingEntityListener.class)
public class RegistrationStatus {

  @ManyToOne
  @MapsId("registrationId")
  @JoinColumn(name = "APPDREG_SYSID")
  private Registration registration;

  @ManyToOne
  @MapsId("statusTypeCode")
  @JoinColumn(name = "APDVRG_CODE")
  private RegistrationStatusType statusType;

  @EmbeddedId @Builder.Default @EqualsAndHashCode.Include
  private RegistrationStatusId pk = new RegistrationStatusId(); // NOPMD

  @NotNull
  @Column(nullable = false)
  private LocalDateTime startDate;

  @Column private LocalDateTime endDate;

  @CreatedDate
  @Column(name = "CREATE_TIME", nullable = false, updatable = false)
  private LocalDateTime createdAt;

  @CreatedBy
  @Column(name = "CREATE_ID", nullable = false, updatable = false)
  private String createdBy;

  @LastModifiedDate
  @Column(name = "UPDATE_TIME")
  private LocalDateTime updatedAt;

  @LastModifiedBy
  @Column(name = "UPDATE_ID")
  private String updatedBy;

  public RegistrationStatus(
      final Registration registration,
      final RegistrationStatusType statusType,
      final LocalDateTime startDate) {
    this.statusType = statusType;
    this.registration = registration;
    this.startDate = startDate;
    this.pk = new RegistrationStatusId(registration.getSysId(), statusType.getCode());
  }

  public Optional<LocalDateTime> getEndDate() {
    return Optional.ofNullable(endDate);
  }

  @Override
  public String toString() {
    UUID regId = registration != null ? registration.getRegistrationId() : null;
    RegistrationStatusType.Name status = registration != null ? statusType.getName() : null;
    return String.format(
        "RegistrationStatus(RegistrationId: %s, Type: %s, StartDate: %s EndDate: %s)",
        regId, status, startDate, endDate);
  }
}
