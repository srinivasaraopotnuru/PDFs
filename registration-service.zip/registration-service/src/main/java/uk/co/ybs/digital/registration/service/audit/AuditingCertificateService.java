package uk.co.ybs.digital.registration.service.audit;

import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.service.CertificateService;
import uk.co.ybs.digital.registration.service.audit.dto.AuditRegistrationRequest;
import uk.co.ybs.digital.registration.service.audit.dto.UserSession;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest.Customer;
import uk.co.ybs.digital.registration.web.controller.dto.RequestMetadata;

@Slf4j
@Service
@AllArgsConstructor
public class AuditingCertificateService {

  @NonNull private final CertificateService certificateService;
  @NonNull private final AuditService auditService;

  public Registration registerKeys(
      final RegisterKeysRequest registerKeysRequest, final RequestMetadata requestMetadata) {
    final Registration registration = certificateService.registerPemKeys(registerKeysRequest);

    final AuditRegistrationRequest auditRegistrationRequest =
        AuditRegistrationRequest.builder()
            .ipAddress(requestMetadata.getIpAddress())
            .userSession(
                UserSession.builder()
                    .brandCode(requestMetadata.getBrandCode())
                    .channel(requestMetadata.getChannel())
                    .partyId(registerKeysRequest.getPartyId())
                    .registrationId(registerKeysRequest.getRegistrationId())
                    .sessionId(registerKeysRequest.getSessionId())
                    .verificationMethod(registerKeysRequest.getVerificationMethod())
                    .title(
                        Optional.ofNullable(registerKeysRequest.getCustomer())
                            .map(Customer::getTitle)
                            .orElse(null))
                    .surname(
                        Optional.ofNullable(registerKeysRequest.getCustomer())
                            .map(Customer::getLastName)
                            .orElse(null))
                    .email(
                        Optional.ofNullable(registerKeysRequest.getCustomer())
                            .map(Customer::getEmail)
                            .orElse(null))
                    .build())
            .build();

    auditService.auditRegistration(auditRegistrationRequest, requestMetadata);

    return registration;
  }
}
