package uk.co.ybs.digital.registration.repository;

import java.util.Optional;
import javax.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.registration.model.CustomerLock;

public interface CustomerLockRepository extends JpaRepository<CustomerLock, Long> {

  @Transactional(propagation = Propagation.MANDATORY)
  @Lock(LockModeType.PESSIMISTIC_WRITE)
  Optional<CustomerLock> findByPartyId(Long partyId);
}
