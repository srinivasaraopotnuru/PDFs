package uk.co.ybs.digital.registration.exception;

import java.util.UUID;

public class PartyIdMismatchException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public PartyIdMismatchException(final Long partyId, final UUID registrationId) {
    super(
        String.format(
            "Registration id [%s] does not belong to party Id [%s]", registrationId, partyId));
  }
}
