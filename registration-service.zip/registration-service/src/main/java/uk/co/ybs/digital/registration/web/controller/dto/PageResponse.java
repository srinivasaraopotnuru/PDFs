package uk.co.ybs.digital.registration.web.controller.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.Objects;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

public class PageResponse<T> {
  private transient Page<T> page;

  @JsonCreator
  // The @JsonProperty annotations belows shouldn't be required as argument names match the JSON.
  // However deserialization tests are failing on IntelliJ if we do not provide them here (Even when
  // gradle
  // and IntelliJ are using the exact same JVM)
  public PageResponse(
      @JsonProperty("content") final List<T> content,
      @JsonProperty("pageSize") final int pageSize,
      @JsonProperty("pageNumber") final int pageNumber,
      @JsonProperty("totalElements") final long totalElements) {
    page = new PageImpl<>(content, PageRequest.of(pageNumber, pageSize), totalElements);
  }

  public PageResponse(final Page<T> page) {
    this.page = page;
  }

  public List<T> getContent() {
    return page.getContent();
  }

  public int getTotalPages() {
    return page.getTotalPages();
  }

  public long getTotalElements() {
    return page.getTotalElements();
  }

  public int getPageNumber() {
    return page.getNumber();
  }

  public int getPageSize() {
    return page.getSize();
  }

  @Override
  public String toString() {
    return String.format(
        "PageRequest<?>(pageNumber=%s, pageSize=%s, totalElements=%s totalPages=%s content=%s)",
        getPageNumber(), getPageSize(), getTotalElements(), getTotalPages(), getContent());
  }

  @Override
  public boolean equals(final Object other) {
    if (this == other) {
      return true;
    }

    if (!(other instanceof PageResponse<?>)) {
      return false;
    }

    PageResponse<?> typedOther = (PageResponse<?>) other;

    return Objects.equals(typedOther.getContent(), getContent())
        && Objects.equals(typedOther.getPageNumber(), getPageNumber())
        && Objects.equals(typedOther.getPageSize(), getPageSize())
        && Objects.equals(typedOther.getTotalElements(), getTotalElements())
        && Objects.equals(typedOther.getTotalPages(), getTotalPages());
  }

  @Override
  public int hashCode() {
    return Objects.hash(
        getContent(), getPageNumber(), getPageSize(), getTotalElements(), getTotalPages());
  }
}
