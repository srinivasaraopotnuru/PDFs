package uk.co.ybs.digital.registration.web.controller.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
abstract class AbstractRegistrationDto {
  @NotNull(message = "You must specify a registrationId")
  @ApiModelProperty(required = true, example = "abcd1234-ab65-4f3e-a3d3-abcdef123456")
  @JsonProperty(required = true)
  private UUID registrationId;

  @NotNull(message = "You must specify a partyId")
  @Positive(message = "PartyId must be greater than 0")
  @JsonProperty(required = true)
  @ApiModelProperty(required = true, allowableValues = "range[1, infinity]", example = "5")
  @JsonAlias("customerId")
  private Long partyId;
}
