package uk.co.ybs.digital.registration.exception;

public class InvalidSortFieldException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  public InvalidSortFieldException(final String validSortField) {
    super(
        String.format(
            "Attempted to sort with an invalid name. Valid names are : [%s]", validSortField));
  }
}
