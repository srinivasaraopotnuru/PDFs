package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;
import uk.co.ybs.digital.registration.exception.InvalidSortFieldException;
import uk.co.ybs.digital.registration.exception.RegistrationNotFoundException;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatusType.Name;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;
import uk.co.ybs.digital.registration.utils.TestDataFactory;

@SuppressWarnings("OptionalGetWithoutIsPresent")
@ExtendWith(MockitoExtension.class)
class RegistrationQueryServiceTest {

  private static final String UPDATED_AT = "updatedAt";
  private static final long DUMMY_PARTY_ID = 10L;
  private final TestDataFactory testDataFactory = new TestDataFactory();
  @Mock RegistrationRepository registrationRepository;

  @SuppressWarnings("unused") // Need to inject this into the registrationQueryService
  @InjectMocks
  RegistrationQueryService registrationQueryService;

  private Registration registrationInRegisteredState;
  private Registration registrationInInitialState;

  @BeforeEach
  void setUp() {
    registrationInRegisteredState =
        testDataFactory.factoryRegistrationWithMultipleStatusesUnordered();
    registrationInRegisteredState.setPartyId(
        DUMMY_PARTY_ID); // Overwriting the partyId so I can be sure it will fail when I join on a
    // different ID later.
    lenient()
        .when(
            registrationRepository.findByRegistrationId(
                registrationInRegisteredState.getRegistrationId()))
        .thenReturn(Optional.of(registrationInRegisteredState));

    registrationInInitialState = testDataFactory.factoryRandomRegistration(Name.INITIAL);
    registrationInInitialState.setPartyId(DUMMY_PARTY_ID);
    lenient()
        .when(
            registrationRepository.findByRegistrationId(
                registrationInInitialState.getRegistrationId()))
        .thenReturn(Optional.of(registrationInInitialState));
  }

  @Test
  void throwsExceptionWhereRegistrationDoesNotExist() {
    when(registrationRepository.findByRegistrationId(any(UUID.class))).thenReturn(Optional.empty());

    assertThrows(
        RegistrationNotFoundException.class,
        () -> registrationQueryService.getRegistrationWithRegisteredStatus(UUID.randomUUID()));
  }

  @Test
  void throwsExceptionWhereRegistrationHasNoStatus() {
    Registration registration = testDataFactory.factoryRandomRegistration();
    when(registrationRepository.findByRegistrationId(registration.getRegistrationId()))
        .thenReturn(Optional.of(registration));

    assertThrows(
        InvalidRegistrationStateException.class,
        () ->
            registrationQueryService.getRegistrationWithRegisteredStatus(
                registration.getRegistrationId()));
  }

  // Positive case - the registration exists and is in the right status
  @Test
  void findsRegistrationForRegistrationId() {
    Registration foundRegistration =
        registrationQueryService.getRegistrationWithRegisteredStatus(
            registrationInRegisteredState.getRegistrationId());
    assertThat(foundRegistration, is(registrationInRegisteredState));
  }

  // Registration does not exist
  @Test
  void throwsExceptionWhereRegistrationIsNotInRegisteredState() {
    assertThrows(
        RegistrationNotFoundException.class,
        () ->
            registrationQueryService.getRegistrationWithRegisteredStatus(
                registrationInInitialState.getRegistrationId()));
  }

  @Test
  void shouldFindAllRegistrationsForPartyIdWithSysIdAddedToSortParams() {
    PageRequest expectedPageRequest =
        PageRequest.of(
            0,
            2,
            Sort.by(Sort.Direction.DESC, UPDATED_AT).and(Sort.by(Sort.Direction.ASC, "sysId")));

    @SuppressWarnings("unchecked")
    Page<Registration> pagedResponse = mock(Page.class);

    when(registrationRepository.findByPartyId(DUMMY_PARTY_ID, expectedPageRequest))
        .thenReturn(pagedResponse);

    Page<Registration> pageRegistrations =
        registrationQueryService.getPartyRegistrations(
            DUMMY_PARTY_ID, "", PageRequest.of(0, 2, Sort.by(Sort.Direction.DESC, UPDATED_AT)));

    assertThat(pageRegistrations, is(pagedResponse));
  }

  @Test
  void shouldFindAllRegistrationsForPartyIdAndStatusWithSysIdAddedToSortParams() {
    PageRequest expectedPageRequest =
        PageRequest.of(
            0,
            2,
            Sort.by(Sort.Direction.DESC, UPDATED_AT).and(Sort.by(Sort.Direction.ASC, "sysId")));

    @SuppressWarnings("unchecked")
    Page<Registration> pagedResponse = mock(Page.class);

    when(registrationRepository.findByPartyIdAndCurrentStatusName(
            DUMMY_PARTY_ID, Name.REGISTERED, expectedPageRequest))
        .thenReturn(pagedResponse);

    Page<Registration> pageRegistrations =
        registrationQueryService.getPartyRegistrations(
            DUMMY_PARTY_ID,
            "REGISTERED",
            PageRequest.of(0, 2, Sort.by(Sort.Direction.DESC, UPDATED_AT)));

    assertThat(pageRegistrations, is(pagedResponse));
  }

  @Test
  void shouldReturnEmptyPageableForUnknownRegistrationStatus() {
    final PageRequest expectedPageRequest =
        PageRequest.of(
            0,
            2,
            Sort.by(Sort.Direction.DESC, UPDATED_AT).and(Sort.by(Sort.Direction.ASC, "sysId")));
    final PageImpl<Object> expectedPageRegistrations =
        new PageImpl<>(Collections.emptyList(), expectedPageRequest, 0);

    final Page<Registration> pageRegistrations =
        registrationQueryService.getPartyRegistrations(
            DUMMY_PARTY_ID, "xyz", PageRequest.of(0, 2, Sort.by(Sort.Direction.DESC, UPDATED_AT)));

    assertThat(pageRegistrations, is(expectedPageRegistrations));

    verifyNoInteractions(registrationRepository);
  }

  @Test
  void throwsExceptionIfSortFieldIsInvalid() {
    PageRequest pageRequest = PageRequest.of(0, 2, Sort.by(Sort.Direction.DESC, "column"));

    assertThrows(
        InvalidSortFieldException.class,
        () -> registrationQueryService.getPartyRegistrations(DUMMY_PARTY_ID, "", pageRequest));
  }
}
