package uk.co.ybs.digital.registration.model;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

@SuppressWarnings("OptionalGetWithoutIsPresent")
class RegistrationStatusTypeTest {

  private static Validator validator;

  @BeforeAll
  static void setUpForAll() {
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory(); // NOPMD
    validator = factory.getValidator();
  }

  @Test
  void testModelValidationForValidInstance() {
    RegistrationStatusType statusType =
        RegistrationStatusType.builder()
            .name(RegistrationStatusType.Name.REGISTERED)
            .description("status type description")
            .build();
    Set<ConstraintViolation<RegistrationStatusType>> violations = validator.validate(statusType);
    assertThat(violations.size(), is(0));
  }

  @Test
  void testModelValidationForMissingName() {
    RegistrationStatusType statusType =
        RegistrationStatusType.builder().description("status type description").build();
    Set<ConstraintViolation<RegistrationStatusType>> violations = validator.validate(statusType);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "name");
  }

  @Test
  void testModelValidationForValidDescription() {
    RegistrationStatusType statusType =
        RegistrationStatusType.builder().name(RegistrationStatusType.Name.REGISTERED).build();
    Set<ConstraintViolation<RegistrationStatusType>> violations = validator.validate(statusType);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "description");
  }

  private void assertPropertyPathCorrect(
      final Set<ConstraintViolation<RegistrationStatusType>> violations,
      final String propertyPath) {
    assertThat(
        violations.stream().findAny().get().getPropertyPath().toString(),
        is(equalTo(propertyPath)));
  }
}
