package uk.co.ybs.digital.registration.web.controller.dto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fasterxml.jackson.databind.exc.MismatchedInputException;
import java.io.IOException;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Stream;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.boot.test.json.ObjectContent;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.registration.config.JsonConfiguration;

@JsonTest
@Import(JsonConfiguration.class)
class RegistrationRequestJsonTest {
  public static final String APP_CODE = "SAPP";
  public static final long PARTY_ID = 25L;
  private static final UUID REGISTRATION_ID =
      UUID.fromString("3b5b89cc-66fd-4538-b67b-03d50db93d1b");

  private Validator validator;

  @Autowired JacksonTester<RegistrationRequest> tester;

  @Value("classpath:jsonTest/RegistrationRequest.json")
  private Resource requestFile;

  @Value("classpath:jsonTest/RegistrationRequestWithFloatingPointPartyId.json")
  private Resource requestFileWithFloatingPointPartyId;

  private RegistrationRequest actualRequest;

  @BeforeEach
  void setUp() {
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory(); // NOPMD
    validator = factory.getValidator();

    actualRequest =
        RegistrationRequest.builder()
            .appCode(APP_CODE)
            .partyId(PARTY_ID)
            .registrationId(REGISTRATION_ID)
            .build();
  }

  @Test
  void serializes() throws IOException {
    Assertions.assertThat(tester.write(actualRequest))
        .isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("registrationRequestDifferentPayloads")
  void deserializes(final ClassPathResource requestFile) throws IOException {
    Assertions.assertThat(tester.read(requestFile)).isEqualTo(actualRequest);
  }

  @Test
  void cannotPassFloatingPointValueAsPartyId() {
    MismatchedInputException exception =
        assertThrows(
            MismatchedInputException.class, () -> tester.read(requestFileWithFloatingPointPartyId));
    assertThat(exception.getMessage(), containsString("Cannot coerce Floating-point value"));
  }

  @ParameterizedTest
  @MethodSource("requestPayloads")
  void deserializationFailsIfFieldIsMissing(final ClassPathResource requestFile) {
    assertThrows(MismatchedInputException.class, () -> tester.read(requestFile));
  }

  @ParameterizedTest
  @MethodSource("nullRequestPayloads")
  void serializationFailsIfValueIsNull(final ClassPathResource requestFile) throws IOException {
    final ObjectContent<RegistrationRequest> registrationRequest = tester.read(requestFile);
    final Set<ConstraintViolation<RegistrationRequest>> violations =
        validator.validate(registrationRequest.getObject());
    assertThat(violations, hasSize(1));
  }

  @ParameterizedTest
  @MethodSource("partyIdWithDifferentValues")
  void partyIdMustBeWholeAndPositive(final ClassPathResource requestFile) throws IOException {
    ObjectContent<RegistrationRequest> registrationRequest = tester.read(requestFile);
    Set<ConstraintViolation<RegistrationRequest>> violations =
        validator.validate(registrationRequest.getObject());
    assertThat(violations, hasSize(1));
  }

  private static Stream<Arguments> requestPayloads() {
    return Stream.of(
        Arguments.of(
            new ClassPathResource("jsonTest/RegistrationRequestWithoutRegistrationId.json")),
        Arguments.of(new ClassPathResource("jsonTest/RegistrationRequestWithoutAppCode.json")),
        Arguments.of(new ClassPathResource("jsonTest/RegistrationRequestWithoutPartyId.json")));
  }

  private static Stream<Arguments> nullRequestPayloads() {
    return Stream.of(
        Arguments.of(
            new ClassPathResource("jsonTest/RegistrationRequestWithNullRegistrationId.json")),
        Arguments.of(new ClassPathResource("jsonTest/RegistrationRequestWithNullPartyId.json")),
        Arguments.of(new ClassPathResource("jsonTest/RegistrationRequestWithNullAppCode.json")));
  }

  private static Stream<Arguments> partyIdWithDifferentValues() {
    return Stream.of(
        Arguments.of(new ClassPathResource("jsonTest/RegistrationRequestWithNegativePartyId.json")),
        Arguments.of(new ClassPathResource("jsonTest/RegistrationRequestWithZeroPartyId.json")));
  }

  private static Stream<Arguments> registrationRequestDifferentPayloads() {
    return Stream.of(
        Arguments.of(new ClassPathResource("jsonTest/RegistrationRequest.json")),
        Arguments.of(new ClassPathResource("jsonTest/RegistrationRequestWithCustomerId.json")));
  }
}
