package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.dao.DataIntegrityViolationException;
import uk.co.ybs.digital.registration.exception.UnableToToLockOnCustomerException;
import uk.co.ybs.digital.registration.model.CustomerLock;
import uk.co.ybs.digital.registration.repository.CustomerLockRepository;

@ExtendWith(MockitoExtension.class)
class CustomerLockServiceTest {

  @Mock CustomerLockRepository customerRepository;

  @InjectMocks CustomerLockService customerLockService;

  @Test
  void acquireCustomerLockInsertsANewEntityIfEntityDoesNotExist() {
    CustomerLock customerLock = new CustomerLock(10L); // NOPMD
    when(customerRepository.findByPartyId(customerLock.getPartyId())).thenReturn(Optional.empty());
    when(customerRepository.saveAndFlush(customerLock)).thenReturn(customerLock);

    CustomerLock savedCustomerLock =
        customerLockService.acquireCustomerLock(customerLock.getPartyId());
    assertThat(savedCustomerLock, is(customerLock));

    verify(customerRepository, times(1)).saveAndFlush(customerLock);
  }

  @Test
  void acquireCustomerLockDoesNotInsertANewRecordIfEntityIsPresent() {
    CustomerLock customerLock = new CustomerLock(10L); // NOPMD
    when(customerRepository.findByPartyId(customerLock.getPartyId()))
        .thenReturn(Optional.of(customerLock));

    CustomerLock foundCustomerLock =
        customerLockService.acquireCustomerLock(customerLock.getPartyId());
    assertThat(foundCustomerLock, notNullValue());
    verify(customerRepository, times(0)).save(any());
  }

  @Test
  void throwsExceptionIfSaveFails() {
    when(customerRepository.findByPartyId(anyLong()))
        .thenThrow(DataIntegrityViolationException.class);
    CustomerLock customerLock = new CustomerLock(10L); // NOPMD
    assertThrows(
        UnableToToLockOnCustomerException.class,
        () -> customerLockService.acquireCustomerLock(customerLock.getPartyId()));
  }
}
