package uk.co.ybs.digital.registration.model;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.registration.utils.TestDataFactory;

@SuppressWarnings("OptionalGetWithoutIsPresent")
class AppTest {

  private static Validator validator;
  private static final String APP_CODE = "app code";
  private static final String BRAND_CODE = "brand code";
  private static final String APP_DES = "app description";
  private static final String APP_NAME = "app name";

  @BeforeAll
  static void setUpForAll() {
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory(); // NOPMD
    validator = factory.getValidator();
  }

  @Test
  void testModelValidationForValidInstance() {
    App app =
        App.builder()
            .code(APP_CODE)
            .brandCode(BRAND_CODE)
            .description(APP_DES)
            .name(APP_NAME)
            .build();
    Set<ConstraintViolation<App>> violations = validator.validate(app);
    assertThat(violations.size(), is(0));
  }

  @Test
  void testModelValidationForMissingDescription() {
    App app = App.builder().code(APP_CODE).brandCode(BRAND_CODE).name(APP_NAME).build();
    Set<ConstraintViolation<App>> violations = validator.validate(app);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "description");
  }

  @Test
  void testModelValidationForMissingName() {
    App app = App.builder().code(APP_CODE).brandCode(BRAND_CODE).description(APP_DES).build();
    Set<ConstraintViolation<App>> violations = validator.validate(app);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "name");
  }

  @Test
  void testModelValidationForMissingCode() {
    App app = App.builder().name(APP_NAME).brandCode(BRAND_CODE).description(APP_DES).build();
    Set<ConstraintViolation<App>> violations = validator.validate(app);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "code");
  }

  @Test
  void testModelValidationForMissingBrandCode() {
    App app = App.builder().code(APP_CODE).description(APP_DES).name(APP_NAME).build();
    Set<ConstraintViolation<App>> violations = validator.validate(app);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "brandCode");
  }

  private void assertPropertyPathCorrect(
      final Set<ConstraintViolation<App>> violations, final String propertyPath) {
    assertThat(
        violations.stream().findAny().get().getPropertyPath().toString(),
        is(equalTo(propertyPath)));
  }

  @Test
  void lombokDoesNotStackOverflowWhenToStringIsCalled() {
    Registration registration = new TestDataFactory().factoryRandomRegistration();
    App app = registration.getApp();
    assertDoesNotThrow(app::toString);
  }

  @SuppressWarnings("ConstantConditions")
  // Just checking this does not stackoverflow. Doesn't matter than I'm doing .equals(null)
  @Test
  void lombokDoesNotStackOverflowWhenEqualsOrHashCodeIsCalled() {
    Registration registration = new TestDataFactory().factoryRandomRegistration();
    App app = registration.getApp();
    assertDoesNotThrow(() -> app == null);
    assertDoesNotThrow(app::hashCode);
  }
}
