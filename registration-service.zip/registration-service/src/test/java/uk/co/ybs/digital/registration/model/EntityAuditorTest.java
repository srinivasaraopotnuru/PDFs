package uk.co.ybs.digital.registration.model;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.Optional;
import java.util.function.Consumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;

class EntityAuditorTest {
  private static final String DEFAULT_AUDITOR = "default";

  private EntityAuditor testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new EntityAuditor(DEFAULT_AUDITOR);
  }

  @Test
  void shouldUseDefaultAuditorWhenRequestAttributesNotPresent() {
    assertThat(testSubject.getCurrentAuditor(), is(Optional.of(DEFAULT_AUDITOR)));
  }

  @Test
  void shouldUseDefaultAuditorWhenRequestAttributesPresentButDontContainAuditorName() {
    doWithRequestAttributes(
        requestAttributes -> {
          assertThat(testSubject.getCurrentAuditor(), is(Optional.of(DEFAULT_AUDITOR)));
        });
  }

  @Test
  void shouldUseAuditorNameWhenRequestAttributesPresentAndContainContainStringAuditorName() {
    doWithRequestAttributes(
        requestAttributes -> {
          final String auditorName = "my-auditor";
          requestAttributes.setAttribute(
              EntityAuditor.AUDITOR_REQUEST_ATTRIBUTE,
              auditorName,
              RequestAttributes.SCOPE_REQUEST);

          assertThat(testSubject.getCurrentAuditor(), is(Optional.of(auditorName)));
        });
  }

  @Test
  void shouldUseAuditorNameWhenRequestAttributesPresentAndContainContainObjectAuditorName() {
    doWithRequestAttributes(
        requestAttributes -> {
          final Long auditorName = 123456L;
          requestAttributes.setAttribute(
              EntityAuditor.AUDITOR_REQUEST_ATTRIBUTE,
              auditorName,
              RequestAttributes.SCOPE_REQUEST);

          assertThat(testSubject.getCurrentAuditor(), is(Optional.of("123456")));
        });
  }

  private void doWithRequestAttributes(final Consumer<RequestAttributes> consumer) {
    try {
      RequestAttributes requestAtttributes = new ServletWebRequest(new MockHttpServletRequest());
      RequestContextHolder.setRequestAttributes(requestAtttributes);

      consumer.accept(requestAtttributes);
    } finally {
      RequestContextHolder.resetRequestAttributes();
    }
  }
}
