package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.registration.exception.StaticDataMissingException;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.repository.RegistrationStatusTypeRepository;

@ExtendWith(MockitoExtension.class)
public class RegistrationStatusTypeServiceTest {
  @Mock private RegistrationStatusTypeRepository repository;

  private RegistrationStatusTypeService testSubject;

  @BeforeEach
  public void beforeEach() {
    testSubject = new RegistrationStatusTypeService(repository);
  }

  @Test
  void findByAppCodeShouldReturnAppWhenItExists() {
    final RegistrationStatusType type =
        RegistrationStatusType.builder()
            .code(123L)
            .name(RegistrationStatusType.Name.INITIAL)
            .build();
    when(repository.findByName(RegistrationStatusType.Name.INITIAL)).thenReturn(Optional.of(type));

    final RegistrationStatusType actual =
        testSubject.findByName(RegistrationStatusType.Name.INITIAL);
    assertThat(actual, is(type));
  }

  @Test
  void findByAppCodeShouldThrowStaticDataMissingExceptionWhenAppDoesNotExist() {
    when(repository.findByName(RegistrationStatusType.Name.INITIAL)).thenReturn(Optional.empty());

    final StaticDataMissingException thrown =
        assertThrows(
            StaticDataMissingException.class,
            () -> testSubject.findByName(RegistrationStatusType.Name.INITIAL));
    assertThat(
        thrown.getMessage(),
        is("Could not retrieve status type with name [INITIAL] from database"));
  }
}
