package uk.co.ybs.digital.registration.model;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.auditing.AuditingHandler;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;
import uk.co.ybs.digital.registration.model.RegistrationStatusType.Name;
import uk.co.ybs.digital.registration.utils.TestDataFactory;

@SuppressWarnings("OptionalGetWithoutIsPresent")
@ExtendWith(MockitoExtension.class)
class RegistrationTest {

  private static Validator validator;
  private static App app;

  @Mock private AuditingHandler auditingHandler;

  private final TestDataFactory testDataFactory = new TestDataFactory();

  @BeforeAll
  static void setUpForAll() {
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory(); // NOPMD
    validator = factory.getValidator();
    app = App.builder().code("APPCODE").build();
  }

  @Test
  void testModelValidationForValidInstance() {
    Registration registration =
        Registration.builder()
            .app(app)
            .registrationId(UUID.randomUUID())
            .partyId(1234L) // NOPMD
            .build(); // NOPMD
    Set<ConstraintViolation<Registration>> violations = validator.validate(registration);
    assertThat(violations.size(), is(0));
  }

  @Test
  void testModelValidationForNullRegistrationId() {
    Registration registration =
        Registration.builder().app(app).registrationId(null).partyId(1234L).build(); // NOPMD
    Set<ConstraintViolation<Registration>> violations = validator.validate(registration);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "registrationId");
  }

  @ParameterizedTest
  @ValueSource(longs = {-1L, 0L})
  @NullSource
  void testModelValidationForInvalidPartyId(final Long partyId) {
    Registration registration =
        Registration.builder().app(app).registrationId(UUID.randomUUID()).partyId(partyId).build();
    Set<ConstraintViolation<Registration>> violations = validator.validate(registration);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "partyId");
  }

  @Test
  void testMissingAppFailsValidation() {
    Registration registration =
        Registration.builder().registrationId(UUID.randomUUID()).partyId(1234L).build(); // NOPMD
    Set<ConstraintViolation<Registration>> violations = validator.validate(registration);
    assertThat(violations.size(), is(1));
    assertPropertyPathCorrect(violations, "app");
  }

  @Test
  void getCurrentStatusReturnsTheOneWithNoEndDateSet() {
    Registration registration = testDataFactory.factoryRandomRegistration();

    final LocalDateTime now = LocalDateTime.now();

    RegistrationStatus initialStatus =
        testDataFactory.factoryRegistrationStatus(
            registration, RegistrationStatusType.Name.INITIAL, now.minusHours(2));
    initialStatus.setEndDate(now.minusHours(1));

    // The registered status starts before the initial status, but is unended and so should still be
    // the 'active' one.
    RegistrationStatus registeredStatus =
        testDataFactory.factoryRegistrationStatus(
            registration, RegistrationStatusType.Name.REGISTERED, now.minusDays(1));

    registration.setStatuses(new HashSet<>(Arrays.asList(initialStatus, registeredStatus)));

    assertThat(registration.getCurrentStatus(), is(registeredStatus));
  }

  @Test
  void getCurrentStatusReturnsEmptyOptionalWhenAllStatusesHaveAndEndDate() {
    Registration registration = testDataFactory.factoryRegistrationWithMultipleStatusesUnordered();
    registration.getStatuses().stream()
        .filter(status -> !status.getEndDate().isPresent())
        .forEach(status -> status.setEndDate(status.getStartDate().plusHours(1)));

    InvalidRegistrationStateException thrown =
        assertThrows(InvalidRegistrationStateException.class, registration::getCurrentStatus);
    assertThat(thrown.getMessage(), containsString(registration.getRegistrationId().toString()));
  }

  @Test
  void getCurrentStatusThrowsExceptionWhenRegistrationHasMoreThanOneUnendedStatus() {
    Registration registration = factoryRegistrationWithNoCurrentStatus();
    InvalidRegistrationStateException thrown =
        assertThrows(InvalidRegistrationStateException.class, registration::getCurrentStatus);
    assertThat(thrown.getMessage(), containsString(registration.getRegistrationId().toString()));
  }

  @Test
  void getCurrentStatusThrowsExceptionWhereRegistrationHasNoUnendedStatus() {
    Registration registration = factoryRegistrationWithNoCurrentStatus();
    assertThrows(InvalidRegistrationStateException.class, registration::getCurrentStatus);
  }

  @Test
  void setCurrentStatusShouldAddNewStatusWhenRegsitrationHasNoStatuses() {
    final Registration registration = testDataFactory.factoryRandomRegistration();
    assertThat(registration.getStatuses(), is(empty()));

    final LocalDateTime now = LocalDateTime.now();
    final RegistrationStatusType initial =
        testDataFactory.factoryStatusType(RegistrationStatusType.Name.INITIAL);

    registration.setCurrentStatus(initial, now, auditingHandler);

    assertThat(
        registration.getStatuses(),
        containsInAnyOrder(
            registrationStatus(
                registration, RegistrationStatusType.Name.INITIAL, now, Optional.empty())));
    verify(auditingHandler).markModified(registration);
  }

  @Test
  void
      setCurrentStatusShouldEndCurrentStatusAndAddNewStatusWhenRegsitrationHasExistingCurrentStatuses() {
    final Registration registration =
        testDataFactory.factoryRandomRegistration(RegistrationStatusType.Name.INITIAL);
    final LocalDateTime existingStatusStartTime =
        registration.getStatuses().iterator().next().getStartDate();

    final LocalDateTime now = LocalDateTime.now();
    final RegistrationStatusType registered =
        testDataFactory.factoryStatusType(RegistrationStatusType.Name.REGISTERED);

    registration.setCurrentStatus(registered, now, auditingHandler);

    assertThat(
        registration.getStatuses(),
        containsInAnyOrder(
            registrationStatus(
                registration,
                RegistrationStatusType.Name.INITIAL,
                existingStatusStartTime,
                Optional.of(now)),
            registrationStatus(
                registration, RegistrationStatusType.Name.REGISTERED, now, Optional.empty())));
    verify(auditingHandler).markModified(registration);
  }

  @Test
  void setCurrentStatusShouldDoNothingWhenRequestStatusIsAlreadyCurrentStatus() {
    final LocalDateTime now = LocalDateTime.now();

    final RegistrationStatusType initial =
        testDataFactory.factoryStatusType(RegistrationStatusType.Name.INITIAL);
    final Registration registration =
        testDataFactory.factoryRandomRegistration(RegistrationStatusType.Name.INITIAL);
    final LocalDateTime existingStatusStartTime =
        registration.getStatuses().iterator().next().getStartDate();

    // when
    registration.setCurrentStatus(initial, now, auditingHandler);

    assertThat(
        registration.getStatuses(),
        containsInAnyOrder(
            registrationStatus(
                registration,
                RegistrationStatusType.Name.INITIAL,
                existingStatusStartTime,
                Optional.empty())));
    verify(auditingHandler, never()).markModified(registration);
  }

  @Test
  void setCurrentStatusShouldNotChangeExistingEndedStatus() {
    final LocalDateTime now = LocalDateTime.now();

    final RegistrationStatusType registered =
        testDataFactory.factoryStatusType(RegistrationStatusType.Name.REGISTERED);

    final Registration registration = testDataFactory.factoryRandomRegistration();
    final RegistrationStatus existingStatus =
        testDataFactory.factoryRegistrationStatus(registration, Name.INITIAL, now.minusDays(2));
    existingStatus.setEndDate(now.minusDays(1));
    registration.setStatuses(new HashSet<>(Collections.singleton(existingStatus)));

    // when
    registration.setCurrentStatus(registered, now, auditingHandler);

    assertThat(
        registration.getStatuses(),
        containsInAnyOrder(
            registrationStatus(
                registration,
                RegistrationStatusType.Name.INITIAL,
                now.minusDays(2),
                Optional.of(now.minusDays(1))),
            registrationStatus(
                registration, RegistrationStatusType.Name.REGISTERED, now, Optional.empty())));
    verify(auditingHandler).markModified(registration);
  }

  @Test
  void setCurrentStatusShouldReactivateExistingEndedStatus() {
    final LocalDateTime now = LocalDateTime.now();

    final RegistrationStatusType initial =
        testDataFactory.factoryStatusType(RegistrationStatusType.Name.INITIAL);

    final Registration registration = testDataFactory.factoryRandomRegistration();
    final RegistrationStatus existingStatus =
        testDataFactory.factoryRegistrationStatus(registration, Name.INITIAL, now.minusDays(2));
    existingStatus.setEndDate(now.minusDays(1));
    registration.setStatuses(new HashSet<>(Collections.singleton(existingStatus)));

    // when
    registration.setCurrentStatus(initial, now, auditingHandler);

    assertThat(
        registration.getStatuses(),
        containsInAnyOrder(
            registrationStatus(
                registration,
                RegistrationStatusType.Name.INITIAL,
                now.minusDays(2),
                Optional.empty())));
    verify(auditingHandler).markModified(registration);
  }

  @Test
  void setCurrentStatusShouldReactivateEarlierEndedStatus() {
    final LocalDateTime now = LocalDateTime.now();

    final RegistrationStatusType initial =
        testDataFactory.factoryStatusType(RegistrationStatusType.Name.INITIAL);

    final Registration registration = testDataFactory.factoryRandomRegistration();
    final RegistrationStatus existingInitial =
        testDataFactory.factoryRegistrationStatus(registration, Name.INITIAL, now.minusDays(2));
    existingInitial.setEndDate(now.minusDays(1));
    final RegistrationStatus existingRegistered =
        testDataFactory.factoryRegistrationStatus(registration, Name.REGISTERED, now.minusDays(1));

    registration.setStatuses(new HashSet<>(Arrays.asList(existingInitial, existingRegistered)));

    // when
    registration.setCurrentStatus(initial, now, auditingHandler);

    assertThat(
        registration.getStatuses(),
        containsInAnyOrder(
            registrationStatus(
                registration,
                RegistrationStatusType.Name.REGISTERED,
                now.minusDays(1),
                Optional.of(now)),
            registrationStatus(
                registration, RegistrationStatusType.Name.INITIAL, now, Optional.empty())));
    verify(auditingHandler).markModified(registration);
  }

  private Registration factoryRegistrationWithNoCurrentStatus() {
    Registration registration = testDataFactory.factoryRegistrationWithMultipleStatusesUnordered();
    registration.getStatuses().forEach(status -> status.setEndDate(null));
    return registration;
  }

  private void assertPropertyPathCorrect(
      final Set<ConstraintViolation<Registration>> violations, final String propertyPath) {
    assertThat(
        violations.stream().findAny().get().getPropertyPath().toString(),
        is(equalTo(propertyPath)));
  }

  private Matcher<RegistrationStatus> registrationStatus(
      final Registration registration,
      final RegistrationStatusType.Name statusName,
      final LocalDateTime startDate,
      final Optional<LocalDateTime> endDate) {
    return allOf(
        hasProperty("registration", is(registration)),
        hasProperty("statusType", hasProperty("name", is(statusName))),
        hasProperty("startDate", is(startDate)),
        hasProperty("endDate", is(endDate)));
  }
}
