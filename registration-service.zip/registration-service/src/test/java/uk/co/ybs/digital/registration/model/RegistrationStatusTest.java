package uk.co.ybs.digital.registration.model;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.mock;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class RegistrationStatusTest {

  private static Validator validator;
  private RegistrationStatus status;

  @BeforeEach
  void setUp() {
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory(); // NOPMD
    validator = factory.getValidator();
    status =
        new RegistrationStatus(
            mock(Registration.class), mock(RegistrationStatusType.class), LocalDateTime.now());
  }

  @Test
  void testModelValidationForValidInstance() {
    Set<ConstraintViolation<RegistrationStatus>> violations = validator.validate(status);
    assertThat(violations.size(), is(0));
  }

  @Test
  void toStringHandlesNulls() {
    RegistrationStatus statuses = factoryRegistrationStatuses();
    statuses.setRegistration(null);
    statuses.setStatusType(null);

    assertDoesNotThrow(statuses::toString);
  }

  @Test
  void toStringHasRegistrationAndStatusInformation() {
    RegistrationStatus statuses = factoryRegistrationStatuses();
    RegistrationStatusType type = statuses.getStatusType();
    Registration registration = statuses.getRegistration();

    RegistrationStatus registrationStatus =
        new RegistrationStatus(registration, type, LocalDateTime.now());
    String toString = registrationStatus.toString();
    assertThat(toString, containsString(registration.getRegistrationId().toString()));
    assertThat(toString, containsString(type.getName().toString()));
  }

  private static RegistrationStatus factoryRegistrationStatuses() {
    RegistrationStatusType type =
        RegistrationStatusType.builder().name(RegistrationStatusType.Name.INITIAL).build();

    UUID regId = UUID.randomUUID();
    Registration registration = Registration.builder().registrationId(regId).build();

    return new RegistrationStatus(registration, type, LocalDateTime.now());
  }
}
