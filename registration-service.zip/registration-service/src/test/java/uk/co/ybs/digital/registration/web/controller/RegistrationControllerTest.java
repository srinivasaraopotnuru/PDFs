package uk.co.ybs.digital.registration.web.controller;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatusType.Name;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;
import uk.co.ybs.digital.registration.service.RegistrationMapper;
import uk.co.ybs.digital.registration.service.RegistrationQueryService;
import uk.co.ybs.digital.registration.service.RegistrationService;
import uk.co.ybs.digital.registration.service.audit.AuditingCertificateService;
import uk.co.ybs.digital.registration.utils.TestDataFactory;
import uk.co.ybs.digital.registration.web.FilterErrorResponseFactory;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse;
import uk.co.ybs.digital.registration.web.controller.dto.PageResponse;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationRequest;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationResponse;
import uk.co.ybs.digital.registration.web.controller.dto.RequestMetadata;
import uk.co.ybs.digital.registration.web.controller.dto.VerificationMethod;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(controllers = RegistrationController.class)
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter
  RequestVerificationSecurityAutoConfiguration.class,
  FilterErrorResponseFactory.class, // Spring Security
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class // Metrics
})
@ActiveProfiles("test")
class RegistrationControllerTest {
  private static final Long PARTY_ID = 1234L;
  private static final String INCOMPLETE_REGISTRATION_CREATE_JSON =
      "{\"partyId\":\"" + PARTY_ID + "}";
  private static final String DUMMY_REQUEST_SIGNATURE =
      "87fg87dsg798dfg7ds98fg9sd7fg9ds7fg98dfg9d7fg9d7kjaekg";
  private static final String CERTIFICATES_ENDPOINT = "/certificates/";
  private static final String REGISTER_ENDPOINT = "/register/";
  private static final String REGISTRATION_QUERY = "/registration/%s";
  private static final String ALL_REGISTRATIONS_FOR_PARTY_ID = "/registration?partyId=%d";
  private static final String ALL_REGISTRATIONS_FOR_PARTY_ID_AND_STATUS =
      "/registration?partyId=%d&status=%s";
  private static final String ALL_REGISTRATIONS_FOR_CUSTOMER_ID = "/registration?customerId=%d";
  private static final String ALL_REGISTRATIONS_FOR_CUSTOMER_ID_AND_STATUS =
      "/registration?customerId=%d&status=%s";
  private static final String REVOKE_ENDPOINT = "/registration/revoke/%d";
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  private static final String HEADER_CHANNEL = "x-ybs-channel";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  private static final String HEADER_ADMIN_USER = "x-ybs-admin-user";
  private static final String REQUEST_SIGNATURE_KEY_ID = "key-id";
  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String CHANNEL = "SAPP";
  private static final String BRAND_CODE = "YBS";
  public static final String TITLE = "Mr";
  public static final String FIRST_NAME = "John";
  public static final String LAST_NAME = "Smith";
  public static final String EMAIL = "john.smith@ybs.co.uk";
  private final TestDataFactory testDataFactory = new TestDataFactory();

  private static final String ADMIN_USER_VALID = "my-admin-user";

  private static final Pageable PAGEABLE =
      PageRequest.of(0, 20, Sort.by(Sort.Direction.DESC, "updatedAt"));
  private String validDeviceCreateJson;
  private UUID requestId;

  @Autowired private ObjectMapper objectMapper;

  @MockBean private RegistrationService registrationService;
  @MockBean private RegistrationQueryService registrationQueryService;
  @MockBean private RegistrationMapper registrationMapper;
  @MockBean private RequestSigningVerificationService requestSigningVerificationService;
  @Autowired private MockMvc mvc;
  @MockBean private RegistrationRepository registrationRepository;
  @MockBean private AuditingCertificateService auditingCertificateService;

  @BeforeEach
  void setup() throws Exception {
    requestId = UUID.randomUUID();

    Path path = Paths.get("src/test/resources/requests/valid_registration_template.json");
    validDeviceCreateJson = String.join("\n", Files.readAllLines(path));

    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
  }

  @Test
  void postNewDevice() throws Exception {
    Registration registration = testDataFactory.factoryRandomRegistration(Name.INITIAL);
    RegistrationRequest mockRequest =
        RegistrationRequest.builder()
            .registrationId(registration.getRegistrationId())
            .partyId(registration.getPartyId())
            .appCode("SAPP")
            .build();

    RegistrationResponse mockResponse =
        RegistrationResponse.builder()
            .registrationId(registration.getRegistrationId())
            .partyId(registration.getPartyId())
            .status(Name.INITIAL)
            .build();

    when(registrationService.storeRegistration(mockRequest)).thenReturn(registration);
    when(registrationMapper.registrationModelToResponse(registration)).thenReturn(mockResponse);

    String responseJson =
        mvc.perform(
                post(REGISTER_ENDPOINT)
                    .content(
                        String.format(
                            validDeviceCreateJson,
                            mockRequest.getRegistrationId(),
                            mockRequest.getPartyId(),
                            mockRequest.getAppCode()))
                    .contentType(MediaType.APPLICATION_JSON)
                    .header(HEADER_REQUEST_ID, requestId.toString())
                    .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                    .header(HEADER_REQUEST_SIGNATURE_KEY_ID, REQUEST_SIGNATURE_KEY_ID)
                    .accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andReturn()
            .getResponse()
            .getContentAsString();
    RegistrationResponse response =
        objectMapper.readValue(responseJson, RegistrationResponse.class);
    verify(registrationService).storeRegistration(mockRequest);

    assertThat(response.getRegistrationId(), is(mockRequest.getRegistrationId()));
    assertThat(response.getPartyId(), is(mockRequest.getPartyId()));
    assertThat(response.getStatus(), is(Name.INITIAL));
  }

  @Test
  void shouldReturnBadRequestForUnparseableRequestBody() throws Exception {
    final UUID requestId = UUID.randomUUID(); // NOPMD
    final ErrorResponse errorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("Resource.InvalidFormat")
                    .message(
                        "An unexpected error occurred when attempting to parse the request body")
                    .build())
            .build();

    mvc.perform(
            post(REGISTER_ENDPOINT)
                .content("anyString")
                .contentType(MediaType.APPLICATION_JSON)
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, REQUEST_SIGNATURE_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().json(objectMapper.writeValueAsString(errorResponse), true));
  }

  @Test
  void postNewDeviceToFail() throws Exception {
    mvc.perform(
            post(REGISTER_ENDPOINT)
                .content(INCOMPLETE_REGISTRATION_CREATE_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().is4xxClientError());
  }

  @Test
  void postNewDeviceShouldReturnBadRequestWhenRequestIdIsNotAUUID() throws Exception {
    String requestId = "not-a-uuid"; // NOPMD
    Registration registration = testDataFactory.factoryRandomRegistration(Name.INITIAL);

    mvc.perform(
            post(REGISTER_ENDPOINT)
                .content(
                    String.format(
                        validDeviceCreateJson,
                        registration.getRegistrationId(),
                        registration.getPartyId(),
                        "SAPP"))
                .contentType(MediaType.APPLICATION_JSON)
                .header(HEADER_REQUEST_ID, requestId)
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, REQUEST_SIGNATURE_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(jsonPath("$.id", notNullValue()))
        .andExpect(jsonPath("$.code", is("400 Bad Request")))
        .andExpect(jsonPath("$.message", is("Bad Request")))
        .andExpect(jsonPath("$.errors.size()", is(1)))
        .andExpect(jsonPath("$.errors[0].errorCode", is("Header.Invalid")))
        .andExpect(jsonPath("$.errors[0].message", is("Header invalid")))
        .andExpect(jsonPath("$.errors[0].path", is(HEADER_REQUEST_ID)));
  }

  @Test
  void canGetRegistrationForRegistrationId() throws Exception {
    Registration registration = testDataFactory.factoryRandomRegistration(Name.REGISTERED);
    when(registrationQueryService.getRegistrationWithRegisteredStatus(
            registration.getRegistrationId()))
        .thenReturn(registration);
    String url = String.format(REGISTRATION_QUERY, registration.getRegistrationId());
    performGet(url, status().isOk());

    verify(registrationQueryService)
        .getRegistrationWithRegisteredStatus(registration.getRegistrationId());
    verify(registrationMapper).registrationModelToResponse(registration);
    verifyNoMoreInteractions(registrationQueryService);
  }

  @ParameterizedTest
  @ValueSource(strings = {ALL_REGISTRATIONS_FOR_PARTY_ID, ALL_REGISTRATIONS_FOR_CUSTOMER_ID})
  void whenGetRequestToGetAllRegistrationsByPartyIdEndPointThenCorrectResponse(final String path)
      throws Exception {
    Registration registration1 = testDataFactory.factoryRandomRegistration(Name.REGISTERED);
    Registration registration2 = testDataFactory.factoryRandomRegistration(Name.REGISTERED);

    RegistrationResponse registrationResponse1 =
        testDataFactory.factoryRandomRegistrationResponse(registration1);
    RegistrationResponse registrationResponse2 =
        testDataFactory.factoryRandomRegistrationResponse(registration2);

    PageResponse<RegistrationResponse> pageResponse =
        new PageResponse<>(
            Arrays.asList(registrationResponse1, registrationResponse2), 20, 0, 1); // NOPMD

    List<Registration> registrations = Arrays.asList(registration1, registration2);
    Page<Registration> pagedResponse =
        new PageImpl<>(registrations, PAGEABLE, registrations.size());

    when(registrationQueryService.getPartyRegistrations(PARTY_ID, "", PAGEABLE))
        .thenReturn(pagedResponse);

    when(registrationMapper.registrationModelToResponse(registration1))
        .thenReturn(registrationResponse1);
    when(registrationMapper.registrationModelToResponse(registration2))
        .thenReturn(registrationResponse2);

    final String expectedResponse = objectMapper.writeValueAsString(pageResponse);

    String url = String.format(path, PARTY_ID);

    mvc.perform(get(url).contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk())
        .andExpect(content().json(expectedResponse));

    verify(registrationQueryService).getPartyRegistrations(PARTY_ID, "", PAGEABLE);
    verify(registrationMapper).registrationModelToResponse(registration1);
    verify(registrationMapper).registrationModelToResponse(registration2);
    verifyNoMoreInteractions(registrationQueryService);
  }

  @Test
  void shouldPassPageableParameterForwardToGetCustomerRegistrations() throws Exception {
    Page<Registration> pagedResponse = new PageImpl<>(new ArrayList<>(), PAGEABLE, 0);

    when(registrationQueryService.getPartyRegistrations(eq(PARTY_ID), eq(""), any(Pageable.class)))
        .thenReturn(pagedResponse);

    String url = String.format(ALL_REGISTRATIONS_FOR_PARTY_ID, PARTY_ID);

    mvc.perform(
        get(url)
            .param("page", "0")
            .param("size", "2")
            .param("sort", "registrationId,desc")
            .param("sort", "updatedAt,asc"));

    PageRequest pageRequest =
        PageRequest.of(
            0,
            2,
            Sort.by(Sort.Direction.DESC, "registrationId")
                .and(Sort.by(Sort.Direction.ASC, "updatedAt")));

    verify(registrationQueryService).getPartyRegistrations(PARTY_ID, "", pageRequest);
  }

  @ParameterizedTest
  @ValueSource(
      strings = {
        ALL_REGISTRATIONS_FOR_PARTY_ID_AND_STATUS,
        ALL_REGISTRATIONS_FOR_CUSTOMER_ID_AND_STATUS
      })
  void shouldPassStatusNameToGetCustomerRegistrations(final String path) throws Exception {
    Page<Registration> pagedResponse = new PageImpl<>(Collections.emptyList(), PAGEABLE, 0);
    when(registrationQueryService.getPartyRegistrations(any(), any(), any()))
        .thenReturn(pagedResponse);

    mvc.perform(get(String.format(path, PARTY_ID, "REGISTERED")));

    verify(registrationQueryService).getPartyRegistrations(eq(PARTY_ID), eq("REGISTERED"), any());
  }

  @Test
  void revokesRegistrationForPartyId() throws Exception {
    Registration registration = testDataFactory.factoryRegistrationWithMultipleStatusesUnordered();
    RegistrationResponse revokedResponse =
        RegistrationResponse.builder()
            .registrationId(registration.getRegistrationId())
            .partyId(registration.getPartyId())
            .status(Name.REVOKED)
            .build();

    when(registrationService.revokeRegistration(PARTY_ID)).thenReturn(Optional.of(registration));
    when(registrationMapper.registrationModelToResponse(registration)).thenReturn(revokedResponse);

    byte[] response =
        revokeCustomerRegistration(ADMIN_USER_VALID)
            .andExpect(status().isOk())
            .andReturn()
            .getResponse()
            .getContentAsByteArray();

    RegistrationResponse actualResponse =
        objectMapper.readValue(response, RegistrationResponse.class);

    assertThat(actualResponse, is(revokedResponse));
  }

  @Test
  void returnsBadRequestWhenAdminUserTooLong() throws Exception {
    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("400 Bad Request")
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message("revokePartyRegistration.adminUser: size must be between 1 and 30")
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.put(String.format(REVOKE_ENDPOINT, PARTY_ID))
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_ADMIN_USER, "1234567890123456789012345678901")
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, REQUEST_SIGNATURE_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void returnsNotFoundIfNoRegistrationToRevoke() throws Exception {
    when(registrationService.revokeRegistration(PARTY_ID)).thenReturn(Optional.empty());

    revokeCustomerRegistration(ADMIN_USER_VALID).andExpect(status().isNotFound());
  }

  @Test
  void registrationWithPemKeysCanBeReceived() throws Exception {
    UUID requestId = UUID.randomUUID(); // NOPMD
    String publicCertificate =
        new String(Files.readAllBytes(Paths.get("src/test/resources/rsa.pem")));
    Registration registration = testDataFactory.factoryRandomRegistration(Name.INITIAL);
    registration.setApiKey(publicCertificate);
    registration.setScaKey(publicCertificate);

    RegisterKeysRequest registerKeysRequest = makeRegisterKeysRequestFromRegistration(registration);

    final RequestMetadata requestMetadata = buildRequestMetadata(requestId);
    when(auditingCertificateService.registerKeys(registerKeysRequest, requestMetadata))
        .thenReturn(registration);

    mvc.perform(
            post(CERTIFICATES_ENDPOINT)
                .content(objectMapper.writeValueAsString(registerKeysRequest))
                .contentType(MediaType.APPLICATION_JSON)
                .headers(standardHeaders(requestId))
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isOk());

    verify(registrationMapper).registrationModelToResponse(registration);
  }

  @ParameterizedTest
  @ValueSource(strings = {HEADER_CHANNEL, HEADER_BRAND_CODE})
  void certificatesEndpointShouldReturnBadRequestForMissingHeader(final String header)
      throws Exception {
    final UUID requestId = UUID.randomUUID(); // NOPMD
    final ErrorResponse response =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .code("400 Bad Request")
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode(ErrorResponse.ErrorItem.HEADER_MISSING)
                        .message("Header missing")
                        .path(header)
                        .build()))
            .build();

    final HttpHeaders headers = standardHeaders(requestId);
    headers.remove(header);

    String publicCertificate =
        new String(Files.readAllBytes(Paths.get("src/test/resources/rsa.pem")));

    Registration registration = testDataFactory.factoryRandomRegistration(Name.INITIAL);
    registration.setApiKey(publicCertificate);
    registration.setScaKey(publicCertificate);

    RegisterKeysRequest request = makeRegisterKeysRequestFromRegistration(registration);

    mvc.perform(
            post(CERTIFICATES_ENDPOINT)
                .headers(headers)
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(response)));
  }

  private ResultActions revokeCustomerRegistration(final String adminUser) throws Exception {
    return mvc.perform(
        MockMvcRequestBuilders.put(String.format(REVOKE_ENDPOINT, PARTY_ID))
            .header(HEADER_REQUEST_ID, requestId.toString())
            .header(HEADER_ADMIN_USER, adminUser)
            .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
            .header(HEADER_REQUEST_SIGNATURE_KEY_ID, REQUEST_SIGNATURE_KEY_ID)
            .accept(MediaType.APPLICATION_JSON));
  }

  private void performGet(final String url, final ResultMatcher statusToExpect) throws Exception {
    mvc.perform(
            get(url)
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, REQUEST_SIGNATURE_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(statusToExpect);
  }

  private RequestMetadata buildRequestMetadata(final UUID requestId) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .ipAddress(IP_ADDRESS)
        .channel(CHANNEL)
        .brandCode(BRAND_CODE)
        .build();
  }

  private HttpHeaders standardHeaders(final UUID requestId) {
    final HttpHeaders headers = new HttpHeaders();
    headers.add(HEADER_REQUEST_ID, requestId.toString());
    headers.add(HEADER_CHANNEL, CHANNEL);
    headers.add(HEADER_BRAND_CODE, BRAND_CODE);
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON));
    return headers;
  }

  private RegisterKeysRequest makeRegisterKeysRequestFromRegistration(
      final Registration registration) {
    return RegisterKeysRequest.builder()
        .registrationId(registration.getRegistrationId())
        .partyId(registration.getPartyId())
        .apiKey(registration.getApiKey())
        .scaKey(registration.getScaKey())
        .verificationMethod(VerificationMethod.BIOMETRIC)
        .sessionId(UUID.fromString("4a2d93a2-f309-4252-aa6f-77a0104909c9"))
        .customer(
            RegisterKeysRequest.Customer.builder()
                .title(TITLE)
                .firstName(FIRST_NAME)
                .lastName(LAST_NAME)
                .email(EMAIL)
                .build())
        .build();
  }
}
