package uk.co.ybs.digital.registration.web.controller.dto;

import java.io.IOException;
import java.util.UUID;
import java.util.stream.Stream;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@JsonTest
class RegisterKeysRequestJsonTest {
  private static final String DUMMY_API_KEY = "dummyApiKey";
  private static final String DUMMY_SCA_KEY = "dummyScaKey";
  private static final UUID SESSION_ID = UUID.fromString("597fa3f7-7e8d-45fc-a7c7-dfc8d5b83360");
  private static final UUID REGISTRATION_ID =
      UUID.fromString("e67c8a09-a826-417d-8dc0-6ef6ea4aac9a");
  private static final String TITLE = "Mr";
  private static final String FIRST_NAME = "John";
  private static final String LAST_NAME = "Smith";
  private static final String EMAIL = "john.smith@ybs.co.uk";
  private static final long PARTY_ID = 25L;

  @Autowired JacksonTester<RegisterKeysRequest> tester;

  @Value("classpath:jsonTest/RegisterKeysRequest.json")
  private Resource requestFile;

  @Test
  void serializes() throws IOException {
    final RegisterKeysRequest request = buildRegisterKeysRequest(buildCustomer());

    Assertions.assertThat(tester.write(request)).isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @ParameterizedTest
  @MethodSource("registerKeysRequestDifferentPayloads")
  void deserializesWithAllFields(
      final RegisterKeysRequest request, final ClassPathResource requestFile) throws IOException {
    Assertions.assertThat(tester.read(requestFile)).isEqualTo(request);
  }

  private static RegisterKeysRequest buildRegisterKeysRequest(
      final RegisterKeysRequest.Customer customer) {
    return RegisterKeysRequest.builder()
        .registrationId(REGISTRATION_ID)
        .partyId(PARTY_ID)
        .apiKey(DUMMY_API_KEY)
        .scaKey(DUMMY_SCA_KEY)
        .sessionId(SESSION_ID)
        .verificationMethod(VerificationMethod.BIOMETRIC)
        .customer(customer)
        .build();
  }

  private static RegisterKeysRequest.Customer buildCustomer() {
    return RegisterKeysRequest.Customer.builder()
        .title(TITLE)
        .firstName(FIRST_NAME)
        .lastName(LAST_NAME)
        .email(EMAIL)
        .build();
  }

  private static Stream<Arguments> registerKeysRequestDifferentPayloads() {
    return Stream.of(
        Arguments.of(
            buildRegisterKeysRequest(buildCustomer()),
            new ClassPathResource("jsonTest/RegisterKeysRequest.json")),
        Arguments.of(
            buildRegisterKeysRequest(buildCustomer()),
            new ClassPathResource("jsonTest/RegisterKeysRequestWithCustomerId.json")));
  }
}
