package uk.co.ybs.digital.registration.web.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MetricsAutoConfiguration;
import org.springframework.boot.actuate.autoconfigure.metrics.export.prometheus.PrometheusMetricsExportAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import uk.co.ybs.digital.logging.ServiceLoggingAutoConfiguration;
import uk.co.ybs.digital.registration.exception.InvalidKeyException;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;
import uk.co.ybs.digital.registration.exception.PartyIdMismatchException;
import uk.co.ybs.digital.registration.exception.RegistrationDuplicateException;
import uk.co.ybs.digital.registration.exception.RegistrationNotFoundException;
import uk.co.ybs.digital.registration.exception.StaticDataMissingException;
import uk.co.ybs.digital.registration.exception.UnableToToLockOnCustomerException;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.service.CertificateService;
import uk.co.ybs.digital.registration.service.RegistrationMapper;
import uk.co.ybs.digital.registration.service.RegistrationQueryService;
import uk.co.ybs.digital.registration.service.RegistrationService;
import uk.co.ybs.digital.registration.service.audit.AuditingCertificateService;
import uk.co.ybs.digital.registration.utils.TestDataFactory;
import uk.co.ybs.digital.registration.web.FilterErrorResponseFactory;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationRequest;
import uk.co.ybs.digital.security.RequestVerificationSecurityAutoConfiguration;
import uk.co.ybs.digital.security.request.signature.service.RequestSigningVerificationService;

@WebMvcTest(controllers = RegistrationController.class)
@Import({
  ServiceLoggingAutoConfiguration.class, // RequestIdFilter
  RequestVerificationSecurityAutoConfiguration.class,
  FilterErrorResponseFactory.class, // Spring Security
  MetricsAutoConfiguration.class,
  PrometheusMetricsExportAutoConfiguration.class // Metrics
})
@ActiveProfiles("test")
class RegistrationExceptionHandlerTest {

  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String DUMMY_REQUEST_SIGNATURE = "a request signature";
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  private static final String REGISTRATION_QUERY_ENDPOINT = "/registration/%s";
  private static final String DUMMY_KEY_ID = "key-id";
  private static final String APP_CODE = "SAPP";
  private static final long PARTY_ID = 1234567890L;
  private static final UUID REGISTRATION_ID =
      UUID.fromString("e783a1f4-fb05-4256-9ae1-2bc11e1e8fb5");
  private final TestDataFactory testDataFactory = new TestDataFactory();

  @MockBean private RegistrationService registrationService;
  @MockBean private RegistrationQueryService registrationQueryService;
  @MockBean private CertificateService certificateService;
  @MockBean private RegistrationMapper registrationMappingService;
  @MockBean private RequestSigningVerificationService requestSigningVerificationService;
  @MockBean private AuditingCertificateService auditingCertificateService;

  private UUID requestId;

  @Autowired private MockMvc mvc;

  @Autowired private ObjectMapper objectMapper;

  @BeforeEach
  void beforeEach() {
    requestId = UUID.randomUUID();

    when(requestSigningVerificationService.verifyRequest(any(), any())).thenReturn(true);
  }

  @ParameterizedTest
  @MethodSource("invalidGetJson")
  void sensibleErrorMessageReturnedToClientIfInvalidBody(final String content, final String message)
      throws Exception {
    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("400 Bad Request")
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message(message)
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.post("/register")
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, DUMMY_KEY_ID)
                .content(content)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void sensibleErrorMessageReturnedToClientWhereIncorrectHTTPVerb() throws Exception {
    RegistrationRequest registrationRequest =
        RegistrationRequest.builder()
            .appCode(APP_CODE)
            .partyId(PARTY_ID)
            .registrationId(REGISTRATION_ID)
            .build();

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("405 Method Not Allowed")
            .message("Method Not Allowed")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNSUPPORTED_METHOD)
                    .message("Unsupported method")
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.put("/register")
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, DUMMY_KEY_ID)
                .content(objectMapper.writeValueAsString(registrationRequest))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isMethodNotAllowed())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void shouldReturnBadRequestIfDuplicateRegistration() throws Exception {
    Registration registration = testDataFactory.factoryRandomRegistration();

    doThrow(RegistrationDuplicateException.class)
        .when(registrationQueryService)
        .getRegistrationWithRegisteredStatus(any(UUID.class));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("400 Bad Request")
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.REGISTRATION_DUPLICATE)
                    .message("registrationId already exists")
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(
                    String.format(REGISTRATION_QUERY_ENDPOINT, registration.getRegistrationId()))
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, DUMMY_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @ParameterizedTest
  @MethodSource("internalServerErrorInvalidRegistrationExceptions")
  void shouldReturnInternalServerErrorIfInvalidRegistrationStateException(final Class exception)
      throws Exception {
    Registration registration = testDataFactory.factoryRandomRegistration();

    doThrow(exception)
        .when(registrationQueryService)
        .getRegistrationWithRegisteredStatus(any(UUID.class));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("500 Internal Server Error")
            .message("Internal Server Error")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNEXPECTED_ERROR)
                    .message("Internal Server Error")
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(
                    String.format(REGISTRATION_QUERY_ENDPOINT, registration.getRegistrationId()))
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, DUMMY_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isInternalServerError())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void shouldReturnNotFoundIfRegistrationNotFoundException() throws Exception {
    Registration registration = testDataFactory.factoryRandomRegistration();

    doThrow(RegistrationNotFoundException.class)
        .when(registrationQueryService)
        .getRegistrationWithRegisteredStatus(any(UUID.class));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("404 Not Found")
            .message("Resource not found")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.RESOURCE_NOT_FOUND)
                    .message("Resource not found")
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(
                    String.format(REGISTRATION_QUERY_ENDPOINT, registration.getRegistrationId()))
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, DUMMY_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isNotFound())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void shouldReturnBadRequestIfInvalidKeyException() throws Exception {
    Registration registration = testDataFactory.factoryRandomRegistration();

    doThrow(InvalidKeyException.class)
        .when(registrationQueryService)
        .getRegistrationWithRegisteredStatus(any(UUID.class));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("400 Bad Request")
            .message("Invalid request body")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.FIELD_INVALID)
                    .message("Invalid PEM key")
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(
                    String.format(REGISTRATION_QUERY_ENDPOINT, registration.getRegistrationId()))
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, DUMMY_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isBadRequest())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  @Test
  void shouldReturnUnauthorizedIfPartyIdMismatchException() throws Exception {
    Registration registration = testDataFactory.factoryRandomRegistration();

    doThrow(PartyIdMismatchException.class)
        .when(registrationQueryService)
        .getRegistrationWithRegisteredStatus(any(UUID.class));

    final ErrorResponse expectedResponse =
        ErrorResponse.builder()
            .id(requestId)
            .code("401 Unauthorized")
            .message("Unauthorized")
            .error(
                ErrorResponse.ErrorItem.builder()
                    .errorCode(ErrorResponse.ErrorItem.UNAUTHORIZED)
                    .message("Unauthorized")
                    .build())
            .build();

    mvc.perform(
            MockMvcRequestBuilders.get(
                    String.format(REGISTRATION_QUERY_ENDPOINT, registration.getRegistrationId()))
                .header(HEADER_REQUEST_ID, requestId.toString())
                .header(HEADER_REQUEST_SIGNATURE, DUMMY_REQUEST_SIGNATURE)
                .header(HEADER_REQUEST_SIGNATURE_KEY_ID, DUMMY_KEY_ID)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isUnauthorized())
        .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
        .andExpect(content().json(objectMapper.writeValueAsString(expectedResponse)));
  }

  private static Stream<Arguments> invalidGetJson() throws IOException {

    Path path = Paths.get("src/test/resources/requests/valid_registration_template.json");
    String validDeviceCreateJson = String.join("\n", Files.readAllLines(path));

    Registration registration = new TestDataFactory().factoryRandomRegistration();
    String badUUidJson =
        String.format(
            validDeviceCreateJson,
            "foo",
            registration.getPartyId(),
            registration.getApp().getCode());
    String nullUuidJson =
        String.format(
            validDeviceCreateJson,
            null,
            registration.getPartyId(),
            registration.getApp().getCode());
    String badPartyIdJson =
        String.format(
            validDeviceCreateJson,
            registration.getRegistrationId(),
            -5L, // NOPMD
            registration.getApp().getCode());
    return Stream.of(
        Arguments.of(badUUidJson, "`foo` is not a valid UUID"),
        Arguments.of(nullUuidJson, "`null` is not a valid UUID"),
        Arguments.of(badPartyIdJson, "PartyId must be greater than 0"));
  }

  private static Stream<Arguments> internalServerErrorInvalidRegistrationExceptions() {
    return Stream.of(
        Arguments.of(StaticDataMissingException.class),
        Arguments.of(InvalidRegistrationStateException.class),
        Arguments.of(UnableToToLockOnCustomerException.class));
  }
}
