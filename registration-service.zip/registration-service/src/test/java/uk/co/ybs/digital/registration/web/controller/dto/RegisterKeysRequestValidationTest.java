package uk.co.ybs.digital.registration.web.controller.dto;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.registration.web.controller.dto.FieldErrorMatcher.fieldError;

import java.util.Arrays;
import java.util.HashMap;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.validation.BindingResult;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.Validator;

@SpringBootTest(
    classes = {ValidationAutoConfiguration.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
class RegisterKeysRequestValidationTest {

  private static final String DUMMY_API_KEY = "dummyApiKey";
  private static final String DUMMY_SCA_KEY = "dummyScaKey";
  private static final UUID SESSION_ID = UUID.fromString("597fa3f7-7e8d-45fc-a7c7-dfc8d5b83360");
  private static final UUID REGISTRATION_ID =
      UUID.fromString("e67c8a09-a826-417d-8dc0-6ef6ea4aac9a");
  private static final String TITLE = "Mr";
  private static final String FIRST_NAME = "John";
  private static final String LAST_NAME = "Smith";
  private static final String EMAIL = "john.smith@ybs.co.uk";
  private static final long PARTY_ID = 25L;

  @Autowired
  @Qualifier("defaultValidator")
  private Validator validator;

  @Test
  void validRequest() {
    final RegisterKeysRequest registerKeysRequest =
        buildRegisterKeysRequest(buildCustomer(TITLE, EMAIL, FIRST_NAME, LAST_NAME));
    final BindingResult bindingResult = validateRequest(validator, registerKeysRequest);
    assertThat(bindingResult.hasErrors(), is(false));
  }

  @Test
  void missingFields() {
    final RegisterKeysRequest request = RegisterKeysRequest.builder().build();
    final BindingResult bindingResult = validateRequest(validator, request);
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("apiKey", "You must specify an apiKey"),
                fieldError("scaKey", "You must specify an scaKey"),
                fieldError("sessionId", "You must specify a sessionId"),
                fieldError("verificationMethod", "You must specify a verificationMethod"),
                fieldError("customer", "You must specify customer details"),
                fieldError("registrationId", "You must specify a registrationId"),
                fieldError("partyId", "PartyId must be greater than 0"))));
  }

  @Test
  void missingFirstAndLastNameFields() {
    final RegisterKeysRequest request =
        buildRegisterKeysRequest(buildCustomer(TITLE, EMAIL, null, null));
    final BindingResult bindingResult = validateRequest(validator, request);
    assertThat(
        bindingResult.getFieldErrors(),
        containsInAnyOrder(
            Arrays.asList(
                fieldError("customer.firstName", "You must specify firstName"),
                fieldError("customer.lastName", "You must specify lastName"))));
  }

  private static BindingResult validateRequest(final Validator validator, final Object request) {
    final BindingResult bindingResult = new MapBindingResult(new HashMap<>(), "request");
    validator.validate(request, bindingResult);
    return bindingResult;
  }

  private static RegisterKeysRequest buildRegisterKeysRequest(
      final RegisterKeysRequest.Customer customer) {
    return RegisterKeysRequest.builder()
        .registrationId(REGISTRATION_ID)
        .partyId(PARTY_ID)
        .apiKey(DUMMY_API_KEY)
        .scaKey(DUMMY_SCA_KEY)
        .sessionId(SESSION_ID)
        .verificationMethod(VerificationMethod.BIOMETRIC)
        .customer(customer)
        .build();
  }

  private static RegisterKeysRequest.Customer buildCustomer(
      final String title, final String email, final String firstName, final String lastName) {
    return RegisterKeysRequest.Customer.builder()
        .title(title)
        .firstName(firstName)
        .lastName(lastName)
        .email(email)
        .build();
  }
}
