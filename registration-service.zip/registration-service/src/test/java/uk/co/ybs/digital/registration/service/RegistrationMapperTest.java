package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatus;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.utils.TestDataFactory;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationResponse;

class RegistrationMapperTest {

  private final TestDataFactory testDataFactory = new TestDataFactory();
  private RegistrationMapper registrationMappingService;
  private Registration registrationInRegisteredState;

  @BeforeEach
  void setUp() {
    registrationMappingService = new RegistrationMapper();
    registrationInRegisteredState =
        testDataFactory.factoryRegistrationWithMultipleStatusesUnordered();
  }

  @Test
  void canMapRegistrationModelToRegistrationResponse() {
    RegistrationResponse registrationResponse =
        registrationMappingService.registrationModelToResponse(registrationInRegisteredState);
    checkRegistrationResponseAgainstRegistrationModel(
        registrationResponse, registrationInRegisteredState);
  }

  @Test
  void usesUpdatedDetailsFromRegistration() {
    final LocalDateTime regsistrationUpdatedAt = LocalDateTime.of(2019, 10, 27, 10, 30, 0);
    final LocalDateTime statusUpdatedAt = LocalDateTime.of(2019, 12, 27, 10, 30, 1);

    final Registration registration = testDataFactory.factoryRandomRegistration();
    registration.setUpdatedAt(regsistrationUpdatedAt);
    registration.setUpdatedBy("updated-by-registration");

    final RegistrationStatus registered =
        testDataFactory.factoryRegistrationStatus(
            registration, RegistrationStatusType.Name.REGISTERED, LocalDateTime.now());
    registered.setUpdatedAt(statusUpdatedAt);
    registered.setUpdatedBy("updated-by-registration-status");
    registration.setStatuses(new HashSet<>(Arrays.asList(registered)));

    RegistrationResponse registrationResponse =
        registrationMappingService.registrationModelToResponse(registration);
    assertThat(registrationResponse.getUpdatedAt(), is(regsistrationUpdatedAt));
    assertThat(registrationResponse.getUpdatedBy(), is("updated-by-registration"));
  }

  @SuppressWarnings("OptionalGetWithoutIsPresent")
  private void checkRegistrationResponseAgainstRegistrationModel(
      final RegistrationResponse registrationResponse, final Registration model) {
    RegistrationStatusType.Name latestStatus =
        model.getStatuses().stream()
            .max(Comparator.comparing(RegistrationStatus::getStartDate))
            .get()
            .getStatusType()
            .getName();

    assertThat(registrationResponse.getRegistrationId(), is(model.getRegistrationId()));
    assertThat(registrationResponse.getPartyId(), is(model.getPartyId()));
    assertThat(registrationResponse.getStatus(), is(latestStatus));
    assertThat(registrationResponse.getApiKey(), is(model.getApiKey()));
    assertThat(registrationResponse.getScaKey(), is(model.getScaKey()));
  }
}
