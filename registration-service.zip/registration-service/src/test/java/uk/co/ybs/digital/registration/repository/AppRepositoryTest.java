package uk.co.ybs.digital.registration.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import uk.co.ybs.digital.registration.model.App;

@DataJpaTest
@ImportAutoConfiguration(FlywayAutoConfiguration.class)
@ActiveProfiles("test")
class AppRepositoryTest {

  @Autowired TestEntityManager entityManager;
  @Autowired private AppRepository repository;

  @Test
  void testAppInstancesCanBeRetrieved() {
    List<App> lookedUp = repository.findAll();
    assertThat(lookedUp.size(), is(1));
    App app = lookedUp.get(0);
    assertThat(app.getCode(), is("SAPP"));
    assertThat(app.getName(), is("YBS Savings App"));
    assertThat(app.getBrandCode(), is("YBS"));
    assertThat(app.getDescription(), is("Yorkshire Building Society Saving App"));
  }
}
