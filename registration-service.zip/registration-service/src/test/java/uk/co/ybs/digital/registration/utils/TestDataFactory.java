package uk.co.ybs.digital.registration.utils;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.UUID;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.stereotype.Component;
import uk.co.ybs.digital.registration.model.App;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatus;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationResponse;

@Component
@TestConfiguration
public class TestDataFactory {

  private static final int RANGE = 9999;

  public RegistrationStatusType factoryStatusType(final RegistrationStatusType.Name type) {
    return RegistrationStatusType.builder().code((long) type.ordinal()).name(type).build();
  }

  public Registration factoryRandomRegistration(final RegistrationStatusType.Name status) {
    return factoryRandomRegistration(Optional.ofNullable(status));
  }

  public Registration factoryRandomRegistration() {
    return factoryRandomRegistration(Optional.empty());
  }

  @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
  private Registration factoryRandomRegistration(
      final Optional<RegistrationStatusType.Name> status) {
    LocalDateTime now = LocalDateTime.now();
    App app = factoryYBSSavingsApp();
    Registration registration =
        Registration.builder()
            .registrationId(UUID.randomUUID())
            .partyId((long) (Math.random() * RANGE))
            .app(app)
            .apiKey("dummyApiKey")
            .scaKey("dummyScaKey")
            .createdAt(LocalDateTime.parse("2019-08-25T10:10:30.00"))
            .updatedAt(LocalDateTime.parse("2019-10-25T10:15:30.00"))
            .updatedBy("DIGITAL_REGISTRATION")
            .build();

    status.ifPresent(
        statusUnwrapped -> {
          RegistrationStatus registrationStatus =
              factoryRegistrationStatus(registration, statusUnwrapped, now);
          registration.setStatuses(new HashSet<>(Collections.singleton(registrationStatus)));
        });

    return registration;
  }

  private App factoryYBSSavingsApp() {
    return App.builder()
        .code("SAPP")
        .name("YBS Savings App")
        .brandCode("YBS")
        .description("Yorkshire Building Society Saving App")
        .build();
  }

  public RegistrationStatus factoryRegistrationStatus(
      final Registration registration,
      final RegistrationStatusType.Name type,
      final LocalDateTime startDate) {
    RegistrationStatusType registrationStatusType = factoryStatusType(type);

    final RegistrationStatus registrationStatus =
        new RegistrationStatus(registration, registrationStatusType, startDate);
    registrationStatus.setCreatedAt(startDate);
    registrationStatus.setUpdatedAt(startDate);
    registrationStatus.setCreatedBy("registration");
    registrationStatus.setUpdatedBy("registration");
    return registrationStatus;
  }

  public Registration factoryRegistrationWithMultipleStatusesUnordered() {
    Registration randomRegistration = factoryRandomRegistration();

    // Add multiple statuses so I know that it sorts them by start date and finds the latest.
    LocalDateTime first = LocalDateTime.of(2018, 2, 15, 13, 1); // NOPMD
    LocalDateTime second = LocalDateTime.of(2018, 2, 15, 13, 2); // NOPMD
    LocalDateTime third = LocalDateTime.of(2018, 2, 15, 13, 3); // NOPMD

    RegistrationStatus initial =
        factoryRegistrationStatus(randomRegistration, RegistrationStatusType.Name.INITIAL, first);

    RegistrationStatus expired =
        factoryRegistrationStatus(randomRegistration, RegistrationStatusType.Name.EXPIRED, second);
    initial.setEndDate(second);

    RegistrationStatus registered =
        factoryRegistrationStatus(
            randomRegistration, RegistrationStatusType.Name.REGISTERED, third);
    expired.setEndDate(third);

    randomRegistration.setStatuses(new HashSet<>(Arrays.asList(initial, registered, expired)));
    return randomRegistration;
  }

  public ErrorResponse factoryInvalidSignatureErrorResponse(final UUID requestId) {
    return ErrorResponse.builder()
        .id(requestId)
        .code("403 Forbidden")
        .message("Forbidden")
        .errors(
            Collections.singletonList(
                ErrorResponse.ErrorItem.builder()
                    .errorCode("AccessDenied.InvalidRequestSignature")
                    .message("Access Denied")
                    .build()))
        .build();
  }

  public RegistrationResponse factoryRandomRegistrationResponse(final Registration registration) {
    return RegistrationResponse.builder()
        .registrationId(registration.getRegistrationId())
        .partyId(registration.getPartyId())
        .status(registration.getCurrentStatus().getStatusType().getName())
        .apiKey(registration.getApiKey())
        .scaKey(registration.getScaKey())
        .createdAt(registration.getCreatedAt())
        .updatedAt(registration.getUpdatedAt())
        .updatedBy(registration.getUpdatedBy())
        .build();
  }
}
