package uk.co.ybs.digital.registration.web.controller.dto;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.UUID;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.Resource;
import uk.co.ybs.digital.registration.config.JsonConfiguration;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;

@JsonTest
@Import(JsonConfiguration.class)
class RegistrationResponseJsonTest {

  private static final String DUMMY_API_KEY = "dummyApiKey";
  private static final String DUMMY_SCA_KEY = "dummyScaKey";
  private static final LocalDateTime DUMMY_CREATED_AT = LocalDateTime.parse("2019-08-25T10:10:30");
  private static final LocalDateTime DUMMY_UPDATED_AT = LocalDateTime.parse("2019-10-25T10:15:30");
  private static final String DUMMY_UPDATED_BY = "DIGITAL_REGISTRATION";
  public static final long PARTY_ID = 25L;
  private RegistrationResponse actualRegistrationResponse;

  @Autowired JacksonTester<RegistrationResponse> tester;

  @Value("classpath:jsonTest/RegistrationResponse.json")
  private Resource requestFile;

  @BeforeEach
  void setUp() {
    actualRegistrationResponse =
        RegistrationResponse.builder()
            .registrationId(UUID.fromString("3b5b89cc-66fd-4538-b67b-03d50db93d1b"))
            .partyId(PARTY_ID)
            .status(RegistrationStatusType.Name.REGISTERED)
            .apiKey(DUMMY_API_KEY)
            .scaKey(DUMMY_SCA_KEY)
            .createdAt(DUMMY_CREATED_AT)
            .updatedAt(DUMMY_UPDATED_AT)
            .updatedBy(DUMMY_UPDATED_BY)
            .build();
  }

  @Test
  void serializes() throws Exception {
    Assertions.assertThat(tester.write(actualRegistrationResponse))
        .isEqualToJson(requestFile, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws IOException {
    Assertions.assertThat(tester.read(requestFile)).isEqualTo(actualRegistrationResponse);
  }
}
