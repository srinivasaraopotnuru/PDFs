package uk.co.ybs.digital.registration.web;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.context.request.WebRequest;
import uk.co.ybs.digital.logging.filters.request.RequestIdFilter;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse;

class GlobalMvcResponseEntityExceptionHandlerTest {
  private final GlobalMvcResponseEntityExceptionHandler exceptionHandler =
      new GlobalMvcResponseEntityExceptionHandler();

  /*
   * Added this to test
   * uk.co.ybs.digital.registration.web.controller.RegistrationControllerAdvice.handleServletRequestBindingException
   * in the case the exception is not a MissingRequestHeaderException.
   *
   * It seems to be impossible to trigger a ``ServletRequestBindingException`` which isn't a
   * MissingRequestHeaderException other than hard coding the controller to be broken.
   */
  @Test
  void shouldReturnBadRequestIfServletRequestBindingExceptionIsThrown() {
    final ServletRequestBindingException exception = new ServletRequestBindingException("");
    final HttpHeaders headers = new HttpHeaders();
    final HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
    final WebRequest webRequest = mock(WebRequest.class);

    final UUID requestId = UUID.randomUUID();
    when(webRequest.getAttribute(
            RequestIdFilter.REQUEST_ID_ATTRIBUTE_NAME, WebRequest.SCOPE_REQUEST))
        .thenReturn(requestId);

    final ResponseEntity<Object> response =
        exceptionHandler.handleServletRequestBindingException(
            exception, headers, httpStatus, webRequest);
    final ErrorResponse errorResponse = (ErrorResponse) response.getBody();

    final ErrorResponse expectedErrorResponse =
        ErrorResponse.builder(HttpStatus.BAD_REQUEST)
            .id(requestId)
            .message("Bad Request")
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("UnexpectedError")
                        .message("Unexpected Error")
                        .build()))
            .build();

    assertThat(errorResponse, is(expectedErrorResponse));
  }
}
