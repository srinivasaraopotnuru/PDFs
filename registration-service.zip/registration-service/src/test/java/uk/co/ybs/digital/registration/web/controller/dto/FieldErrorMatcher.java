package uk.co.ybs.digital.registration.web.controller.dto;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;

import org.hamcrest.Matcher;
import org.springframework.validation.FieldError;

public class FieldErrorMatcher { // NOPMD

  public static Matcher<FieldError> fieldError(final String field, final String defaultMessage) {
    return allOf(
        hasProperty("field", is(field)), hasProperty("defaultMessage", is(defaultMessage)));
  }
}
