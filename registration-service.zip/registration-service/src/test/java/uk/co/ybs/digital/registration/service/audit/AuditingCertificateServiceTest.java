package uk.co.ybs.digital.registration.service.audit;

import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.registration.service.CertificateService;
import uk.co.ybs.digital.registration.service.audit.dto.AuditRegistrationRequest;
import uk.co.ybs.digital.registration.service.audit.dto.UserSession;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest.Customer;
import uk.co.ybs.digital.registration.web.controller.dto.RequestMetadata;
import uk.co.ybs.digital.registration.web.controller.dto.VerificationMethod;

@ExtendWith(MockitoExtension.class)
class AuditingCertificateServiceTest {
  private static final UUID REQUEST_ID = UUID.randomUUID();
  private static final String IP_ADDRESS = "12.66.53.145";
  private static final String CHANNEL = "SAPP";
  private static final String BRAND_CODE = "YBS";
  private static final UUID SESSION_ID = UUID.fromString("d221c50f-34ef-4c83-a3d9-14ca4aef753d");
  private static final UUID REGISTRATION_ID =
      UUID.fromString("1def467a-b40b-4a0d-b6a7-8c1dff1a2939");
  private static final long PARTY_ID = 12345678900L;
  private static final String TITLE = "Mr";
  private static final String FIRST_NAME = "John";
  private static final String LAST_NAME = "Smith";
  private static final String EMAIL = "john.smith@ybs.co.uk";

  @InjectMocks private AuditingCertificateService testSubject;

  @Mock private AuditService auditService;

  @Mock private CertificateService certificateService;

  @Test
  void shouldRegisterKeysAndAuditRegistration() throws IOException {
    RegisterKeysRequest registerKeysRequest =
        buildRegisterKeysRequest(buildCustomer(TITLE, FIRST_NAME, LAST_NAME, EMAIL));
    final RequestMetadata requestMetadata = buildRequestMetadata();

    testSubject.registerKeys(registerKeysRequest, requestMetadata);

    verify(certificateService).registerPemKeys(registerKeysRequest);

    final AuditRegistrationRequest auditRegistrationRequest =
        buildAuditRegistrationRequest(registerKeysRequest.getCustomer());

    verify(auditService).auditRegistration(auditRegistrationRequest, requestMetadata);
  }

  @Test
  void shouldRegisterKeysAndAuditRegistrationNoCustomer() throws IOException {
    final RequestMetadata requestMetadata = buildRequestMetadata();
    final RegisterKeysRequest registerKeysRequest = buildRegisterKeysRequest(null);

    testSubject.registerKeys(registerKeysRequest, requestMetadata);

    verify(certificateService).registerPemKeys(registerKeysRequest);

    final AuditRegistrationRequest auditRegistrationRequest =
        buildAuditRegistrationRequest(registerKeysRequest.getCustomer());

    verify(auditService).auditRegistration(auditRegistrationRequest, requestMetadata);
  }

  private RequestMetadata buildRequestMetadata() {
    return RequestMetadata.builder()
        .requestId(REQUEST_ID)
        .ipAddress(IP_ADDRESS)
        .channel(CHANNEL)
        .brandCode(BRAND_CODE)
        .build();
  }

  private AuditRegistrationRequest buildAuditRegistrationRequest(final Customer customer) {
    return AuditRegistrationRequest.builder()
        .ipAddress(IP_ADDRESS)
        .userSession(
            UserSession.builder()
                .verificationMethod(VerificationMethod.BIOMETRIC)
                .sessionId(SESSION_ID)
                .registrationId(REGISTRATION_ID)
                .partyId(PARTY_ID)
                .channel(CHANNEL)
                .brandCode(BRAND_CODE)
                .title(Optional.ofNullable(customer).map(Customer::getTitle).orElse(null))
                .surname(Optional.ofNullable(customer).map(Customer::getLastName).orElse(null))
                .email(Optional.ofNullable(customer).map(Customer::getEmail).orElse(null))
                .build())
        .build();
  }

  private static RegisterKeysRequest buildRegisterKeysRequest(
      final RegisterKeysRequest.Customer customer) throws IOException {
    final String publicCertificate =
        new String(Files.readAllBytes(Paths.get("src/test/resources/rsa.pem")));

    return RegisterKeysRequest.builder()
        .partyId(PARTY_ID)
        .registrationId(REGISTRATION_ID)
        .verificationMethod(VerificationMethod.BIOMETRIC)
        .sessionId(SESSION_ID)
        .scaKey(publicCertificate)
        .apiKey(publicCertificate)
        .customer(customer)
        .build();
  }

  private static RegisterKeysRequest.Customer buildCustomer(
      final String title, final String firstName, final String lastName, final String email) {
    return RegisterKeysRequest.Customer.builder()
        .title(title)
        .firstName(firstName)
        .lastName(lastName)
        .email(email)
        .build();
  }
}
