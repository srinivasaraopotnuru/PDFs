package uk.co.ybs.digital.registration.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import javax.validation.ConstraintViolationException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.context.annotation.Import;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.auditing.AuditingHandler;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ActiveProfiles;
import uk.co.ybs.digital.registration.config.JpaAuditingConfig;
import uk.co.ybs.digital.registration.model.App;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatus;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.utils.TestDataFactory;

@SuppressWarnings("OptionalGetWithoutIsPresent")
@DataJpaTest
@ImportAutoConfiguration(FlywayAutoConfiguration.class)
@Import(JpaAuditingConfig.class)
@ActiveProfiles({"test", "text-logging"})
class RegistrationRepositoryTest {

  public static final long PARTY_ID = 1L;
  private static final String APP_CODE = "SAPP";

  private static final String UUID_1 = "ab5c1a07-0eb1-42ef-b194-7c1146a879ea";
  private static final String UUID_2 = "3b5b89cc-66fd-4538-b67b-03d50db93d1b";
  private static final String UUID_3 = "64f4dc03-bd4a-4282-9353-a97c30240c80";
  private static final String UUID_4 = "a3dadd60-6734-4ebc-8fa4-08dea3ae4f1d";

  private final TestDataFactory testDataFactory = new TestDataFactory();

  @Autowired RegistrationRepository registrationRepository;
  @Autowired TestEntityManager entityManager;
  @Autowired AuditingHandler auditingHandler;

  private App app;
  private RegistrationStatusType currentStatusType;

  @BeforeEach
  void setUp() {
    LocalDateTime now = LocalDateTime.now();

    app = entityManager.find(App.class, APP_CODE);
    currentStatusType = entityManager.find(RegistrationStatusType.class, PARTY_ID);

    Stream.of(UUID_1, UUID_2, UUID_3, UUID_4)
        .forEachOrdered(
            id -> {
              Registration registration1 = new Registration();
              registration1.setRegistrationId(UUID.fromString(id));
              registration1.setPartyId(PARTY_ID);
              registration1.setApp(app);
              registration1.setApiKey("dummy-api-key");
              registration1.setScaKey("dummy-sca-key");
              registration1.setCurrentStatus(currentStatusType, now, auditingHandler);
              entityManager.persist(registration1);
            });

    entityManager.flush();
  }

  @Test
  void testSavedRegistration() {
    List<Registration> lookedUp = registrationRepository.findAll();
    assertThat(lookedUp.size(), is(4));
    assertThat(lookedUp.get(0).getStatuses().size(), is(1));
  }

  @Test
  void emptyRegistrationRejected() {
    Registration incompleteRegistration = Registration.builder().build();
    persistRegistration(incompleteRegistration);
  }

  @Test
  void invalidRegistrationWithOnlyPartyIdRejected() {
    Registration incompleteRegistration = Registration.builder().partyId(PARTY_ID).build();
    incompleteRegistration.setPartyId(PARTY_ID);
    persistRegistration(incompleteRegistration);
  }

  @Test
  void invalidRegistrationWithOnlyUuidRejected() {
    Registration incompleteRegistration =
        Registration.builder().registrationId(UUID.randomUUID()).build();
    persistRegistration(incompleteRegistration);
  }

  private void persistRegistration(final Registration incompleteRegistration) {
    try {
      entityManager.persist(incompleteRegistration);
      entityManager.flush();
      fail("Should have failed in saving due to null fields");
    } catch (ConstraintViolationException e) {
      assertThat(e.getMessage(), containsString("validation"));
    }
  }

  @Test
  void localDateTimeTypeOnStatusShouldSaveToDbAndPreserveSeconds() {
    Registration registration = registrationRepository.findAll().get(0);
    RegistrationStatus status = registration.getStatuses().iterator().next();

    LocalDateTime localDateTime = LocalDateTime.of(2013, 5, 15, 16, 17, 25); // NOPMD
    status.setStartDate(localDateTime);
    status.setEndDate(localDateTime.plusSeconds(10));

    entityManager.persistAndFlush(status);

    RegistrationStatus savedStatus =
        registrationRepository
            .findByRegistrationId(registration.getRegistrationId())
            .map(Registration::getStatuses)
            .map(set -> set.iterator().next())
            .get();

    assertThat(savedStatus.getStartDate(), is(localDateTime));
    assertThat(savedStatus.getEndDate().get(), is(localDateTime.plusSeconds(10)));
  }

  @Test
  void repositorySavesRegistrationGivenOnlyAppCodeString() {
    // Insert Registration
    UUID registrationId = UUID.randomUUID();
    Registration registration =
        Registration.builder()
            .registrationId(registrationId)
            .partyId(3L) // NOPMD
            .app(App.builder().code(APP_CODE).build())
            .build();

    registrationRepository.save(registration);

    Optional<Registration> savedRegistration =
        registrationRepository.findByRegistrationId(registrationId);

    assertTrue(savedRegistration.isPresent());
    assertEquals(3L, savedRegistration.get().getPartyId().longValue());
    assertEquals(registrationId, savedRegistration.get().getRegistrationId());

    App retrievedApp = savedRegistration.get().getApp();
    assertEquals(APP_CODE, retrievedApp.getCode());
  }

  @Test
  void registrationCannotBeSavedWithDuplicateRegistrationId() {
    Registration registration1 = testDataFactory.factoryRandomRegistration();
    registrationRepository.saveAndFlush(registration1);

    Registration registration2 = testDataFactory.factoryRandomRegistration();
    registration2.setRegistrationId(registration1.getRegistrationId());

    assertThrows(
        DataIntegrityViolationException.class,
        () -> registrationRepository.saveAndFlush(registration2));
  }

  @Test
  void registrationsWithDifferentPageRequestParameters() {
    PageRequest pageable =
        PageRequest.of(
            0,
            5, // NOPMD
            Sort.by(Sort.Direction.ASC, "updatedAt").and(Sort.by(Sort.Direction.DESC, "sysId")));
    Page<Registration> registrations = registrationRepository.findByPartyId(1L, pageable);

    assertThat(registrations.getTotalElements(), is(4L));
    assertThat(registrations.getContent().get(0).getRegistrationId(), is(UUID.fromString(UUID_4)));
    assertThat(registrations.getContent().get(1).getRegistrationId(), is(UUID.fromString(UUID_3)));
    assertThat(registrations.getContent().get(2).getRegistrationId(), is(UUID.fromString(UUID_2)));
    assertThat(registrations.getContent().get(3).getRegistrationId(), is(UUID.fromString(UUID_1)));
  }

  @Test
  void existsByRegistrationIdShouldReturnTrueWhenRegistrationIdExists() {
    assertThat(registrationRepository.existsByRegistrationId(UUID.fromString(UUID_4)), is(true));
  }

  @Test
  void existsByRegistrationIdShouldReturnFalseWhenRegistrationIdDoesNotExist() {
    assertThat(registrationRepository.existsByRegistrationId(UUID.randomUUID()), is(false));
  }

  @Test
  void existsByPartyIdShouldReturnTrueWhenRegistrationExistsForCustomer() {
    assertThat(registrationRepository.existsByPartyId(PARTY_ID), is(true));
  }

  @Test
  void existsByPartyIdShouldReturnFalseWhenNoRegistrationExistsForCustomer() {
    assertThat(registrationRepository.existsByPartyId(Long.MAX_VALUE), is(false));
  }

  @Test
  void findByPartyIdAndCurrentStatusNameShouldFindRegistrationWhenCurrentStatusMatches() {
    assertThat(
        registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, Collections.singletonList(RegistrationStatusType.Name.REGISTERED)),
        hasSize(4));
  }

  @Test
  void findByPartyIdAndCurrentStatusNameShouldNotFindRegistrationWhenCurrentStatusDoesntMatch() {
    assertThat(
        registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, Collections.singletonList(RegistrationStatusType.Name.EXPIRED)),
        is(empty()));
  }

  @Test
  void findByPartyIdAndCurrentStatusNameShouldNotFindRegistrationWhenPartyIdDoesntMatch() {
    assertThat(
        registrationRepository.findByPartyIdAndCurrentStatusName(
            Long.MAX_VALUE, Collections.singletonList(RegistrationStatusType.Name.REGISTERED)),
        is(empty()));
  }

  @Test
  void findByPartyIdAndCurrentStatusNamePageableShouldFindRegistrationWhenCurrentStatusMatches() {
    final PageRequest pageable = PageRequest.of(0, 5);
    final Page<Registration> result =
        registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, RegistrationStatusType.Name.REGISTERED, pageable);
    assertThat(result.getContent(), hasSize(4));
    assertThat(result.getContent().get(0).getRegistrationId(), is(UUID.fromString(UUID_1)));
    assertThat(result.getContent().get(1).getRegistrationId(), is(UUID.fromString(UUID_2)));
    assertThat(result.getContent().get(2).getRegistrationId(), is(UUID.fromString(UUID_3)));
    assertThat(result.getContent().get(3).getRegistrationId(), is(UUID.fromString(UUID_4)));
  }

  @Test
  void
      findByPartyIdAndCurrentStatusNamePageableShouldFindRegistrationWhenCurrentStatusMatchesNotDefaultSorting() {
    final PageRequest pageable =
        PageRequest.of(0, 5, Sort.by(Sort.Direction.DESC, "registrationId"));
    final Page<Registration> result =
        registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, RegistrationStatusType.Name.REGISTERED, pageable);
    assertThat(result.getContent(), hasSize(4));
    assertThat(result.getContent().get(0).getRegistrationId(), is(UUID.fromString(UUID_1)));
    assertThat(result.getContent().get(1).getRegistrationId(), is(UUID.fromString(UUID_4)));
    assertThat(result.getContent().get(2).getRegistrationId(), is(UUID.fromString(UUID_3)));
    assertThat(result.getContent().get(3).getRegistrationId(), is(UUID.fromString(UUID_2)));
  }

  @Test
  void
      findByPartyIdAndCurrentStatusNamePageableShouldFindRegistrationWhenCurrentStatusMatchesMultiPage() {
    final Pageable pageable = PageRequest.of(0, 2, Sort.by(Sort.Direction.DESC, "registrationId"));
    final Page<Registration> result =
        registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, RegistrationStatusType.Name.REGISTERED, pageable);
    assertThat(result.getContent(), hasSize(2));
    assertThat(result.hasNext(), is(true));
    assertThat(result.getTotalElements(), is(4L));
    assertThat(result.getContent().get(0).getRegistrationId(), is(UUID.fromString(UUID_1)));
    assertThat(result.getContent().get(1).getRegistrationId(), is(UUID.fromString(UUID_4)));

    final Pageable pageable2 = result.nextPageable();
    final Page<Registration> result2 =
        registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, RegistrationStatusType.Name.REGISTERED, pageable2);
    assertThat(result2.getContent(), hasSize(2));
    assertThat(result2.hasNext(), is(false));
    assertThat(result2.getTotalElements(), is(4L));
    assertThat(result2.getContent().get(0).getRegistrationId(), is(UUID.fromString(UUID_3)));
    assertThat(result2.getContent().get(1).getRegistrationId(), is(UUID.fromString(UUID_2)));
  }

  @Test
  void
      findByPartyIdAndCurrentStatusNamePageableShouldNotFindRegistrationWhenCurrentStatusDoesntMatch() {
    final PageRequest pageable = PageRequest.of(0, 5);
    final Page<Registration> result =
        registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, RegistrationStatusType.Name.EXPIRED, pageable);
    assertThat(result.getContent(), is(empty()));
  }

  @Test
  void findByPartyIdAndCurrentStatusNamePageableShouldNotFindRegistrationWhenPartyIdDoesntMatch() {
    final PageRequest pageable = PageRequest.of(0, 5);
    final Page<Registration> result =
        registrationRepository.findByPartyIdAndCurrentStatusName(
            Long.MAX_VALUE, RegistrationStatusType.Name.REGISTERED, pageable);
    assertThat(result.getContent(), is(empty()));
  }
}
