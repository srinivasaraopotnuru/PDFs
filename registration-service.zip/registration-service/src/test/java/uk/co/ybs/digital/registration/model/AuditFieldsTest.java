package uk.co.ybs.digital.registration.model;

import static org.exparity.hamcrest.date.LocalDateTimeMatchers.after;
import static org.exparity.hamcrest.date.LocalDateTimeMatchers.sameOrAfter;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.INITIAL;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.auditing.AuditingHandler;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletWebRequest;
import uk.co.ybs.digital.registration.config.JpaAuditingConfig;
import uk.co.ybs.digital.registration.model.RegistrationStatusType.Name;

@DataJpaTest
@ImportAutoConfiguration({FlywayAutoConfiguration.class, JpaAuditingConfig.class})
@ActiveProfiles("test")
class AuditFieldsTest {

  // Must be the same as the spring.datasource.username in test/resources/application.properties
  private final String DATABASE_USER = "sa"; // NOPMD

  @Autowired TestEntityManager entityManager;

  @Autowired AuditingHandler auditingHandler;

  @Test
  void allAuditFieldsAreSetOnRegistrationAndStatusWhenTheyCreated() {
    LocalDateTime now = LocalDateTime.now();
    Registration registration = persistRegistration(findRegistrationStatus(INITIAL));

    assertThat(registration.getCreatedAt(), sameOrAfter(now));
    assertThat(registration.getUpdatedAt(), equalTo(registration.getCreatedAt()));
    assertThat(registration.getCreatedBy(), equalTo(DATABASE_USER));
    assertThat(registration.getUpdatedBy(), equalTo(DATABASE_USER));

    RegistrationStatus registrationStatus = registration.getStatuses().iterator().next();
    assertThat(registrationStatus.getCreatedAt(), sameOrAfter(now));
    assertThat(registrationStatus.getUpdatedAt(), equalTo(registrationStatus.getCreatedAt()));
    assertThat(registrationStatus.getCreatedBy(), equalTo(DATABASE_USER));
    assertThat(registrationStatus.getUpdatedBy(), equalTo(DATABASE_USER));
  }

  @Test
  void createdByAndUpdatedByAreSetWhenAuditorNamePresentInRequestAttributes() {
    try {
      final String auditorName = "my-audit-user";
      setUpRequestAttributes(auditorName);

      Registration registration = persistRegistration(findRegistrationStatus(INITIAL));
      assertThat(registration.getCreatedBy(), equalTo(auditorName));
      assertThat(registration.getUpdatedBy(), equalTo(auditorName));

      RegistrationStatus registrationStatus = registration.getStatuses().iterator().next();
      assertThat(registrationStatus.getCreatedBy(), equalTo(auditorName));
      assertThat(registrationStatus.getUpdatedBy(), equalTo(auditorName));
    } finally {
      tearDownRequestAttributes();
    }
  }

  @Test
  void addingKeysToARegistrationUpdatesUpdatedAtField() {
    Registration registration = persistRegistration(findRegistrationStatus(INITIAL));

    LocalDateTime originalCreatedAt = registration.getCreatedAt();
    LocalDateTime originalUpdatedAt = registration.getUpdatedAt();

    registration.setScaKey("SOME KEY");

    registration = entityManager.persistAndFlush(registration);

    assertThat(registration.getCreatedAt(), equalTo(originalCreatedAt));
    assertThat(registration.getUpdatedAt(), after(originalUpdatedAt));
  }

  @Test
  void settingTheCurrentStatusOnARegistrationUpdatesTheAuditFieldsOnRegistration() {
    Registration registration = persistRegistration(findRegistrationStatus(INITIAL));
    Map<Name, RegistrationStatus> statuses = getStatusesAsMap(registration);
    LocalDateTime originalCreatedAt = registration.getCreatedAt();

    final RegistrationStatus initialStatus = statuses.get(INITIAL);
    LocalDateTime originalStatusCreatedAt = initialStatus.getCreatedAt();

    LocalDateTime timeOfStatusUpdate = LocalDateTime.now();
    registration.setCurrentStatus(
        findRegistrationStatus(Name.REGISTERED), timeOfStatusUpdate, auditingHandler);

    Registration updatedRegistration = entityManager.persistAndFlush(registration);
    assertThat(updatedRegistration.getCreatedAt(), is(originalCreatedAt));
    assertThat(updatedRegistration.getUpdatedAt(), sameOrAfter(timeOfStatusUpdate));
    assertThat(updatedRegistration.getCreatedBy(), is(DATABASE_USER));
    assertThat(updatedRegistration.getUpdatedBy(), is(DATABASE_USER));

    Map<Name, RegistrationStatus> updatedStatuses = getStatusesAsMap(updatedRegistration);
    RegistrationStatus initial = updatedStatuses.get(INITIAL);
    assertThat(initial.getCreatedAt(), is(originalStatusCreatedAt));
    assertThat(initial.getUpdatedAt(), sameOrAfter(timeOfStatusUpdate));
    assertThat(initial.getCreatedBy(), equalTo(DATABASE_USER));
    assertThat(initial.getUpdatedBy(), equalTo(DATABASE_USER));

    RegistrationStatus registered = updatedStatuses.get(Name.REGISTERED);
    assertThat(registered.getCreatedAt(), sameOrAfter(timeOfStatusUpdate));
    assertThat(registered.getUpdatedAt(), is(registered.getCreatedAt()));
    assertThat(registered.getCreatedBy(), equalTo(DATABASE_USER));
    assertThat(registered.getUpdatedBy(), equalTo(DATABASE_USER));
  }

  @Test
  void
      settingTheCurrentStatusOnARegistrationUpdatesTheAuditFieldsOnRegistrationWhenAuditorNamePresentInRequestAttributes() {
    Registration registration = persistRegistration(findRegistrationStatus(INITIAL));
    Map<Name, RegistrationStatus> statuses = getStatusesAsMap(registration);
    LocalDateTime originalCreatedAt = registration.getCreatedAt();

    final RegistrationStatus initialStatus = statuses.get(INITIAL);
    LocalDateTime originalStatusCreatedAt = initialStatus.getCreatedAt();

    try {
      final String auditorName = "my-audit-user";
      setUpRequestAttributes(auditorName);

      LocalDateTime timeOfStatusUpdate = LocalDateTime.now();
      registration.setCurrentStatus(
          findRegistrationStatus(Name.REGISTERED), timeOfStatusUpdate, auditingHandler);

      Registration updatedRegistration = entityManager.persistAndFlush(registration);
      assertThat(updatedRegistration.getCreatedAt(), is(originalCreatedAt));
      assertThat(updatedRegistration.getUpdatedAt(), sameOrAfter(timeOfStatusUpdate));
      assertThat(updatedRegistration.getCreatedBy(), is(DATABASE_USER));
      assertThat(updatedRegistration.getUpdatedBy(), is(auditorName));

      Map<Name, RegistrationStatus> updatedStatuses = getStatusesAsMap(updatedRegistration);
      RegistrationStatus initial = updatedStatuses.get(INITIAL);
      assertThat(initial.getCreatedAt(), is(originalStatusCreatedAt));
      assertThat(initial.getUpdatedAt(), sameOrAfter(timeOfStatusUpdate));
      assertThat(initial.getCreatedBy(), equalTo(DATABASE_USER));
      assertThat(initial.getUpdatedBy(), equalTo(auditorName));

      RegistrationStatus registered = updatedStatuses.get(Name.REGISTERED);
      assertThat(registered.getCreatedAt(), sameOrAfter(timeOfStatusUpdate));
      assertThat(registered.getUpdatedAt(), is(registered.getCreatedAt()));
      assertThat(registered.getCreatedBy(), equalTo(auditorName));
      assertThat(registered.getUpdatedBy(), equalTo(auditorName));
    } finally {
      tearDownRequestAttributes();
    }
  }

  @Test
  void persistingAnUnmodifiedRegistrationDoesNotUpdateTheUpdatedAtField() {
    Registration registration = persistRegistration(findRegistrationStatus(INITIAL));

    LocalDateTime originalCreatedAt = registration.getCreatedAt();
    LocalDateTime originalUpdatedAt = registration.getUpdatedAt();

    registration = entityManager.persistAndFlush(registration);

    assertThat(registration.getCreatedAt(), equalTo(originalCreatedAt));
    assertThat(registration.getUpdatedAt(), equalTo(originalUpdatedAt));
  }

  @Test
  void persistingAnUnmodifiedRegistrationStatusDoesNotUpdateTheUpdatedAtField() {
    Registration registration = persistRegistration(findRegistrationStatus(INITIAL));

    RegistrationStatus status = registration.getStatuses().iterator().next();
    LocalDateTime originalCreatedAt = status.getCreatedAt();
    LocalDateTime originalUpdatedAt = status.getUpdatedAt();

    status = entityManager.persistAndFlush(status);

    assertThat(status.getCreatedAt(), equalTo(originalCreatedAt));
    assertThat(status.getUpdatedAt(), equalTo(originalUpdatedAt));
  }

  private RegistrationStatusType findRegistrationStatus(final RegistrationStatusType.Name name) {
    return entityManager.find(RegistrationStatusType.class, (long) name.ordinal());
  }

  private Registration persistRegistration(final RegistrationStatusType statusType) {
    final LocalDateTime now = LocalDateTime.now();
    UUID registrationId = UUID.randomUUID();

    final Registration registration =
        Registration.builder()
            .app(App.builder().code("SAPP").build())
            .partyId(1L)
            .registrationId(registrationId)
            .build();
    registration.setStatuses(
        new HashSet<>(Arrays.asList(new RegistrationStatus(registration, statusType, now))));
    return entityManager.persistAndFlush(registration);
  }

  private Map<Name, RegistrationStatus> getStatusesAsMap(final Registration registration) {
    return registration.getStatuses().stream()
        .collect(Collectors.toMap(status -> status.getStatusType().getName(), Function.identity()));
  }

  private String setUpRequestAttributes(final String auditorName) {
    RequestAttributes requestAttributes = new ServletWebRequest(new MockHttpServletRequest());
    RequestContextHolder.setRequestAttributes(requestAttributes);

    requestAttributes.setAttribute(
        EntityAuditor.AUDITOR_REQUEST_ATTRIBUTE, auditorName, RequestAttributes.SCOPE_REQUEST);
    return auditorName;
  }

  private void tearDownRequestAttributes() {
    RequestContextHolder.resetRequestAttributes();
  }
}
