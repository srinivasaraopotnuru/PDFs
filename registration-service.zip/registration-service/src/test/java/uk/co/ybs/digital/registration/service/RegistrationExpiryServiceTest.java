package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.EXPIRED;
import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.INITIAL;
import static uk.co.ybs.digital.registration.model.RegistrationStatusType.Name.REGISTERED;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.auditing.AuditingHandler;
import uk.co.ybs.digital.registration.model.App;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatus;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;

@ExtendWith(MockitoExtension.class)
class RegistrationExpiryServiceTest {

  private final Clock clock = Clock.fixed(Instant.now(), ZoneId.systemDefault());

  private final LocalDateTime existingStatusStart = LocalDateTime.parse("2019-01-01T01:02:03");

  @Captor ArgumentCaptor<List<RegistrationStatus>> captor;

  @Mock RegistrationRepository registrationRepository;

  @Mock AuditingHandler auditingHandler;

  @Mock RegistrationStatusTypeService statusTypeService;

  @Captor ArgumentCaptor<List<Registration>> savedRegistrationsCaptor;

  private RegistrationExpiryService expiryService;

  private RegistrationStatusType initial;
  private RegistrationStatusType registered;
  private RegistrationStatusType expired;

  @BeforeEach
  void setup() {
    expiryService =
        new RegistrationExpiryService(statusTypeService, registrationRepository, auditingHandler);

    registered = buildStatusType(REGISTERED);
    initial = buildStatusType(INITIAL);
    expired = buildStatusType(EXPIRED);
  }

  @Test
  void expireAllRegistrationsUnlessExcludedByRegistrationId() {
    final LocalDateTime now = LocalDateTime.now(clock);
    final Long partyId = 1L;

    final UUID includedRegistration1Id = UUID.randomUUID();
    final UUID includedRegistration2Id = UUID.randomUUID();
    final UUID excludedRegistrationId = UUID.randomUUID();

    final Registration includedRegistration1 =
        buildRegistration(includedRegistration1Id, registered);
    final Registration includedRegistration2 = buildRegistration(includedRegistration2Id, initial);
    final Registration excludedRegistration = buildRegistration(excludedRegistrationId, registered);
    when(registrationRepository.findByPartyIdAndCurrentStatusName(
            partyId, Arrays.asList(INITIAL, REGISTERED)))
        .thenReturn(
            Arrays.asList(includedRegistration1, excludedRegistration, includedRegistration2));

    when(statusTypeService.findByName(EXPIRED)).thenReturn(expired);

    expiryService.expireAllIncompleteRegistrationsExcept(partyId, excludedRegistrationId, now);

    verify(registrationRepository).saveAll(savedRegistrationsCaptor.capture());

    final List<Registration> savedRegistrations = savedRegistrationsCaptor.getValue();
    assertThat(
        savedRegistrations,
        contains(
            registration(
                includedRegistration1Id,
                status(registered, existingStatusStart, Optional.of(now)),
                status(expired, now, Optional.empty())),
            registration(
                includedRegistration2Id,
                status(initial, existingStatusStart, Optional.of(now)),
                status(expired, now, Optional.empty()))));
    assertThat(
        excludedRegistration,
        is(
            registration(
                excludedRegistrationId,
                status(registered, existingStatusStart, Optional.empty()))));
  }

  @Test
  void shouldNotExpireAnythingWhenTheOnlyStatusFoundIsExcludedById() {
    final LocalDateTime now = LocalDateTime.now(clock);
    final Long partyId = 1L;

    final UUID excludedRegistrationId = UUID.randomUUID();
    final Registration excludedRegistration = buildRegistration(excludedRegistrationId, registered);
    when(registrationRepository.findByPartyIdAndCurrentStatusName(
            partyId, Arrays.asList(INITIAL, REGISTERED)))
        .thenReturn(Arrays.asList(excludedRegistration));

    expiryService.expireAllIncompleteRegistrationsExcept(partyId, excludedRegistrationId, now);

    verify(registrationRepository, never()).saveAll(any());

    assertThat(
        excludedRegistration,
        is(
            registration(
                excludedRegistrationId,
                status(registered, existingStatusStart, Optional.empty()))));
  }

  @SafeVarargs
  private final Matcher<Registration> registration(
      final UUID registrationId, final Matcher<RegistrationStatus>... statuses) {
    return allOf(
        hasProperty("registrationId", is(registrationId)),
        hasProperty("statuses", containsInAnyOrder(statuses)));
  }

  private Matcher<RegistrationStatus> status(
      final RegistrationStatusType statusType,
      final LocalDateTime startDate,
      final Optional<LocalDateTime> endDate) {
    return allOf(
        hasProperty("statusType", is(statusType)),
        hasProperty("startDate", is(startDate)),
        hasProperty("endDate", is(endDate)));
  }

  private Registration buildRegistration(
      final UUID registrationId, final RegistrationStatusType statusType) {
    Registration registration =
        Registration.builder()
            .app(App.builder().code("SAPP").build())
            .registrationId(registrationId)
            .sysId(1L)
            .partyId(2L)
            .build();
    registration.setCurrentStatus(statusType, existingStatusStart, auditingHandler);
    return registration;
  }

  private RegistrationStatusType buildStatusType(final RegistrationStatusType.Name name) {
    return RegistrationStatusType.builder().name(name).code((long) name.ordinal()).build();
  }
}
