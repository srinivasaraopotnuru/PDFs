package uk.co.ybs.digital.registration.web.controller.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Collections;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;

@JsonTest
class ErrorResponseJsonTest {

  @Autowired private JacksonTester<ErrorResponse> json;

  @Value("classpath:jsonTest/ErrorResponse.json")
  private Resource file;

  private ErrorResponse fullyPopulated;

  @BeforeEach
  void beforeEach() {
    fullyPopulated =
        ErrorResponse.builder()
            .id(UUID.fromString("abcd1234-ab65-4f3e-a3d3-abcdef123456"))
            .code("400 Bad Request")
            .message("Something is bad about request")
            .errors(
                Collections.singletonList(
                    ErrorResponse.ErrorItem.builder()
                        .errorCode("Field.Invalid")
                        .message("Some invalid Field")
                        .path("the field")
                        .build()))
            .build();
  }

  @Test
  void serializes() throws Exception {
    assertThat(json.write(fullyPopulated)).isEqualToJson(file, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws Exception {
    assertThat(json.read(file)).isEqualTo(fullyPopulated);
  }
}
