package uk.co.ybs.digital.registration.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.core.Is.is;

import java.util.List;
import java.util.Optional;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ActiveProfiles;
import uk.co.ybs.digital.registration.config.JpaAuditingConfig;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;

@DataJpaTest
@ImportAutoConfiguration(FlywayAutoConfiguration.class)
@Import(JpaAuditingConfig.class)
@ActiveProfiles("test")
class RegistrationStatusTypesRepositoryTest {

  @Autowired private RegistrationStatusTypeRepository repository;

  @Test
  void testStatusTypesCanBeRetrievedAndThereIsOneOnlyOfEachStatusAndEachHasTheRightDescription() {
    List<RegistrationStatusType> lookedUp = repository.findAll();

    assertThat(
        lookedUp,
        containsStatuses(
            statusType(RegistrationStatusType.Name.INITIAL, "Registration started"),
            statusType(RegistrationStatusType.Name.REGISTERED, "Registration complete"),
            statusType(RegistrationStatusType.Name.EXPIRED, "Registration expired by user"),
            statusType(RegistrationStatusType.Name.REVOKED, "Registration revoked by YBS")));
  }

  @Test
  void testStatusTypesCanBeFoundByName() {
    Optional<RegistrationStatusType> statusType =
        repository.findByName(RegistrationStatusType.Name.INITIAL);
    assert (statusType.isPresent());
    assertThat(statusType.get().getName(), equalTo(RegistrationStatusType.Name.INITIAL));
  }

  @SafeVarargs
  private final Matcher<Iterable<? extends RegistrationStatusType>> containsStatuses(
      final Matcher<RegistrationStatusType>... statusMatcher) {
    return containsInAnyOrder(statusMatcher);
  }

  private Matcher<RegistrationStatusType> statusType(
      final RegistrationStatusType.Name name, final String description) {
    return allOf(hasProperty("name", is(name)), hasProperty("description", is(description)));
  }
}
