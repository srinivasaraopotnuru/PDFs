package uk.co.ybs.digital.registration;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableList;
import io.swagger.models.HttpMethod;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.stream.Stream;
import javax.persistence.EntityManager;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.transaction.support.TransactionTemplate;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.service.audit.dto.AuditRegistrationRequest;
import uk.co.ybs.digital.registration.service.audit.dto.UserSession;
import uk.co.ybs.digital.registration.utils.TestDataFactory;
import uk.co.ybs.digital.registration.web.controller.dto.ErrorResponse;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest.Customer;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationRequest;
import uk.co.ybs.digital.registration.web.controller.dto.VerificationMethod;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class, TestDatabaseConfiguration.class})
@ActiveProfiles({"test", "text-logging"})
class RegistrationApplicationIT {
  private static final String APP_CODE = "SAPP";
  private static final String SIGNATURE_KEY_ID = "PsDfAcRxsVQL5CwAJKP0q5ITsVe9ukn1K0lw";
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String HEADER_REQUEST_SIGNATURE = "x-ybs-request-signature";
  private static final String HEADER_REQUEST_SIGNATURE_KEY_ID = "x-ybs-request-signature-key-id";
  private static final String HEADER_CHANNEL = "x-ybs-channel";
  private static final String HEADER_BRAND_CODE = "x-ybs-brand-code";
  private static final String HEADER_ADMIN_USER = "x-ybs-admin-user";

  private static final long CUSTOMER_ID_GET_ALL_REGISTRATIONS = 1L;
  private static final long CUSTOMER_ID_GET_ALL_REGISTRATIONS_WITH_STATUS = 2L;

  private static final long PARTY_ID = 1234567890L;
  private static final String CHANNEL = "SAPP";
  private static final String BRAND_CODE = "YBS";
  private static final String IP_ADDRESS = "127.0.0.1";
  private static final UUID SESSION_ID = UUID.randomUUID();

  private static final String BASE_PATH = "/registration";
  private static final String REGISTER_PATH = "/register";
  private static final String REGISTER_KEYS_PATH = "/certificates";
  private static final String REGISTRATION_PATH = "/registration/";
  private static final String REVOKE_PATH = "/registration/revoke/" + PARTY_ID;

  private static final String DUMMY_UPDATED_BY = "sa";
  private static final String TITLE = "Mr";
  private static final String FIRST_NAME = "Joe";
  private static final String LAST_NAME = "Bloggs";
  private static final String EMAIL = "joe.bloggs@ybs.co.uk";

  private static final String PARTY_ID_STRING = "partyId";
  private static final String CUSTOMER_ID = "customerId";
  private static final String STATUS = "status";
  private static final String CREATED_AT = "createdAt";
  private static final String UPDATED_AT = "updatedAt";
  private static final String UPDATED_BY = "updatedBy";
  private static final String CONTENT = "content";

  private UUID registrationId;

  @Autowired private ObjectMapper objectMapper;

  @LocalServerPort private int port;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  private MockWebServer mockAuditService;

  @Autowired private WebTestClient signingWebClient;

  @Autowired private WebTestClient nonSigningWebTestClient;

  @Autowired TransactionTemplate transactionTemplate;

  @Autowired TestEntityManager aatTestEntityManager;

  private final TestDataFactory testDataFactory = new TestDataFactory();

  private String customersPublicKeyPem;

  @BeforeEach
  void setup() throws Exception {
    registrationId = UUID.randomUUID();

    customersPublicKeyPem =
        new String(Files.readAllBytes(Paths.get("src/test/resources/ecdsa-public.pem")));

    mockAuditService = new MockWebServer();
    mockAuditService.start(auditTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockAuditService.shutdown();
    tearDownDb();
  }

  @ParameterizedTest
  @MethodSource("customerPayloads")
  void registrationLifecycleTest(final RegisterKeysRequest.Customer customer) throws Exception {
    // create
    RegistrationRequest registrationRequest =
        RegistrationRequest.builder()
            .appCode(APP_CODE)
            .partyId(PARTY_ID)
            .registrationId(registrationId)
            .build();

    signingWebClient
        .post()
        .uri(getURI(REGISTER_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, UUID.randomUUID().toString())
        .bodyValue(registrationRequest)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("registrationId")
        .isEqualTo((registrationId).toString())
        .jsonPath(PARTY_ID_STRING)
        .isEqualTo(PARTY_ID)
        .jsonPath(CUSTOMER_ID)
        .isEqualTo(PARTY_ID)
        .jsonPath(STATUS)
        .isEqualTo((RegistrationStatusType.Name.INITIAL).toString())
        .jsonPath(CREATED_AT)
        .exists()
        .jsonPath(UPDATED_AT)
        .exists()
        .jsonPath(UPDATED_BY)
        .isEqualTo(DUMMY_UPDATED_BY);

    // register keys
    final UUID requestId = UUID.randomUUID();
    RegisterKeysRequest registerKeysRequest =
        RegisterKeysRequest.builder()
            .registrationId(registrationId)
            .partyId(PARTY_ID)
            .apiKey(customersPublicKeyPem)
            .scaKey(customersPublicKeyPem)
            .verificationMethod(VerificationMethod.BIOMETRIC)
            .sessionId(SESSION_ID)
            .customer(customer)
            .build();

    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    signingWebClient
        .post()
        .uri(getURI(REGISTER_KEYS_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .headers(standardHeaders(requestId))
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, UUID.randomUUID().toString())
        .bodyValue(registerKeysRequest)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("apiKey")
        .isEqualTo(customersPublicKeyPem)
        .jsonPath("scaKey")
        .isEqualTo(customersPublicKeyPem)
        .jsonPath(PARTY_ID_STRING)
        .isEqualTo(PARTY_ID)
        .jsonPath(CUSTOMER_ID)
        .isEqualTo(PARTY_ID)
        .jsonPath(STATUS)
        .isEqualTo((RegistrationStatusType.Name.REGISTERED).toString())
        .jsonPath(CREATED_AT)
        .exists()
        .jsonPath(UPDATED_AT)
        .exists()
        .jsonPath(UPDATED_BY)
        .isEqualTo(DUMMY_UPDATED_BY);

    assertAuditRegistration(requestId, PARTY_ID, registrationId, customer);

    // get
    signingWebClient
        .get()
        .uri(getURI(REGISTRATION_PATH + registrationId.toString()))
        .accept(MediaType.APPLICATION_JSON)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("registrationId")
        .isEqualTo((registrationId).toString())
        .jsonPath(PARTY_ID_STRING)
        .isEqualTo(PARTY_ID)
        .jsonPath(CUSTOMER_ID)
        .isEqualTo(PARTY_ID)
        .jsonPath("apiKey")
        .isEqualTo(customersPublicKeyPem)
        .jsonPath("scaKey")
        .isEqualTo(customersPublicKeyPem)
        .jsonPath(STATUS)
        .isEqualTo((RegistrationStatusType.Name.REGISTERED).toString())
        .jsonPath(CREATED_AT)
        .exists()
        .jsonPath(UPDATED_AT)
        .exists()
        .jsonPath(UPDATED_BY)
        .isEqualTo(DUMMY_UPDATED_BY);

    // revoke
    final String adminUser = "my-admin-user";

    signingWebClient
        .put()
        .uri(getURI(REVOKE_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, UUID.randomUUID().toString())
        .header(HEADER_ADMIN_USER, adminUser)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("registrationId")
        .isEqualTo((registrationId).toString())
        .jsonPath(PARTY_ID_STRING)
        .isEqualTo(PARTY_ID)
        .jsonPath(CUSTOMER_ID)
        .isEqualTo(PARTY_ID)
        .jsonPath("apiKey")
        .isEqualTo(customersPublicKeyPem)
        .jsonPath("scaKey")
        .isEqualTo(customersPublicKeyPem)
        .jsonPath(STATUS)
        .isEqualTo((RegistrationStatusType.Name.REVOKED).toString())
        .jsonPath(CREATED_AT)
        .exists()
        .jsonPath(UPDATED_AT)
        .exists()
        .jsonPath(UPDATED_BY)
        .isEqualTo(adminUser);
  }

  @ParameterizedTest
  @ValueSource(strings = {"/registration?partyId=", "/registration?customerId="})
  void getAllRegistrations(final String path) throws JsonProcessingException, InterruptedException {
    for (int i = 0; i < 3; i++) {
      createRegistrationWithStatusRegistered(CUSTOMER_ID_GET_ALL_REGISTRATIONS);
    }

    String url = path + CUSTOMER_ID_GET_ALL_REGISTRATIONS + "&page=0&size=2&sort=updatedAt,desc";

    signingWebClient
        .get()
        .uri(getURI(url))
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath(CONTENT)
        .exists()
        .jsonPath(CONTENT)
        .isArray()
        .jsonPath("pageNumber")
        .isEqualTo(0)
        .jsonPath("pageSize")
        .isEqualTo(2)
        .jsonPath("totalElements")
        .isEqualTo(3);
  }

  @ParameterizedTest
  @ValueSource(strings = {"/registration?partyId=", "/registration?customerId="})
  void getAllRegistrationsWithStatus(final String path)
      throws JsonProcessingException, InterruptedException {
    for (int i = 0; i < 3; i++) {
      createRegistrationWithStatusRegistered(CUSTOMER_ID_GET_ALL_REGISTRATIONS_WITH_STATUS);
    }

    String url =
        path
            + CUSTOMER_ID_GET_ALL_REGISTRATIONS_WITH_STATUS
            + "&status=EXPIRED&page=0&size=1&sort=updatedAt,desc";

    signingWebClient
        .get()
        .uri(getURI(url))
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, UUID.randomUUID().toString())
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath(CONTENT)
        .exists()
        .jsonPath(CONTENT)
        .isArray()
        .jsonPath("pageNumber")
        .isEqualTo(0)
        .jsonPath("pageSize")
        .isEqualTo(1)
        .jsonPath("totalElements")
        .isEqualTo(2);
  }

  @Test
  void registerShouldReturnForbiddenWhenSignatureIsMissing() {
    final UUID requestId = UUID.randomUUID();
    RegistrationRequest registerBody =
        RegistrationRequest.builder()
            .appCode(APP_CODE)
            .partyId(PARTY_ID)
            .registrationId(registrationId)
            .build();

    nonSigningWebTestClient
        .post()
        .uri(getURI(REGISTER_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .bodyValue(registerBody)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(testDataFactory.factoryInvalidSignatureErrorResponse(requestId));
  }

  @Test
  void registerShouldReturnForbiddenWhenSignatureIsInvalid() {
    final UUID requestId = UUID.randomUUID();
    RegistrationRequest registerBody =
        RegistrationRequest.builder()
            .appCode(APP_CODE)
            .partyId(PARTY_ID)
            .registrationId(registrationId)
            .build();

    nonSigningWebTestClient
        .post()
        .uri(getURI(REGISTER_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, requestId.toString())
        .header(HEADER_REQUEST_SIGNATURE, "invalid-signature")
        .bodyValue(registerBody)
        .exchange()
        .expectStatus()
        .isForbidden()
        .expectHeader()
        .contentType(MediaType.APPLICATION_JSON)
        .expectBody(ErrorResponse.class)
        .isEqualTo(testDataFactory.factoryInvalidSignatureErrorResponse(requestId));
  }

  private void createRegistrationWithStatusRegistered(final long partyId)
      throws JsonProcessingException, InterruptedException {
    UUID registrationId = UUID.randomUUID(); // NOPMD

    RegistrationRequest registerBody =
        RegistrationRequest.builder()
            .appCode(APP_CODE)
            .partyId(partyId)
            .registrationId(registrationId)
            .build();

    signingWebClient
        .post()
        .uri(getURI(REGISTER_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .header(HEADER_REQUEST_ID, UUID.randomUUID().toString())
        .bodyValue(registerBody)
        .exchange()
        .expectStatus()
        .isOk();

    UUID requestId = UUID.randomUUID();
    RegisterKeysRequest registerKeysBody =
        RegisterKeysRequest.builder()
            .registrationId(registrationId)
            .partyId(partyId)
            .apiKey(customersPublicKeyPem)
            .scaKey(customersPublicKeyPem)
            .verificationMethod(VerificationMethod.BIOMETRIC)
            .sessionId(SESSION_ID)
            .customer(buildCustomer(TITLE, EMAIL))
            .build();

    mockAuditService.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    signingWebClient
        .post()
        .uri(getURI(REGISTER_KEYS_PATH))
        .accept(MediaType.APPLICATION_JSON)
        .header(HEADER_REQUEST_SIGNATURE_KEY_ID, SIGNATURE_KEY_ID)
        .headers(standardHeaders(requestId))
        .bodyValue(registerKeysBody)
        .exchange()
        .expectStatus()
        .isOk();

    assertAuditRegistration(requestId, partyId, registrationId, registerKeysBody.getCustomer());
  }

  private static RegisterKeysRequest.Customer buildCustomer(
      final String title, final String email) {
    return RegisterKeysRequest.Customer.builder()
        .title(title)
        .firstName(FIRST_NAME)
        .lastName(LAST_NAME)
        .email(email)
        .build();
  }

  private URI getURI(final String path) {
    return URI.create("http://localhost:" + port + BASE_PATH + path);
  }

  private Consumer<HttpHeaders> standardHeaders(final UUID requestId) {
    return headers -> {
      headers.add(HEADER_REQUEST_ID, requestId.toString());
      headers.add(HEADER_CHANNEL, CHANNEL);
      headers.add(HEADER_BRAND_CODE, BRAND_CODE);
      headers.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON));
    };
  }

  private void assertAuditRegistration(
      final UUID requestId, final Long partyId, final UUID registrationId, final Customer customer)
      throws InterruptedException, JsonProcessingException {
    final RecordedRequest request = mockAuditService.takeRequest();
    assertThat(request.getMethod(), is(HttpMethod.POST.name()));
    assertThat(request.getPath(), is("/audit/registration/register"));
    assertThat(request.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));
    assertThat(request.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE), notNullValue());
    assertThat(request.getHeader(HEADER_REQUEST_SIGNATURE_KEY_ID), notNullValue());

    final AuditRegistrationRequest actual =
        objectMapper.readValue(request.getBody().readUtf8(), AuditRegistrationRequest.class);
    assertThat(
        actual,
        is(
            AuditRegistrationRequest.builder()
                .ipAddress(IP_ADDRESS)
                .userSession(
                    UserSession.builder()
                        .partyId(partyId)
                        .brandCode(BRAND_CODE)
                        .channel(CHANNEL)
                        .registrationId(registrationId)
                        .verificationMethod(VerificationMethod.BIOMETRIC)
                        .sessionId(SESSION_ID)
                        .title(customer.getTitle())
                        .surname(customer.getLastName())
                        .email(customer.getEmail())
                        .build())
                .build()));
  }

  private void tearDownDb() {
    transactionTemplate.executeWithoutResult(
        transactionStatus -> {
          final EntityManager aatEntityManager = aatTestEntityManager.getEntityManager();
          aatEntityManager.createQuery("delete from RegistrationStatus").executeUpdate();
          aatEntityManager.createQuery("delete from Registration").executeUpdate();
        });
  }

  private static Stream<Arguments> customerPayloads() {
    return Stream.of(
        Arguments.of(buildCustomer(TITLE, EMAIL)), Arguments.of(buildCustomer(null, null)));
  }
}
