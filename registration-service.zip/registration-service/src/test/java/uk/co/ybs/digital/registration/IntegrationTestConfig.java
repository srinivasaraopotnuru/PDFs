package uk.co.ybs.digital.registration;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.StringReader;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.Security;
import java.util.Objects;
import org.bouncycastle.jcajce.spec.OpenSSHPrivateKeySpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.http.codec.json.Jackson2JsonEncoder;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.test.web.reactive.server.WebTestClientConfigurer;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import uk.co.ybs.digital.security.requestsigning.ClientHttpRequestSigner;
import uk.co.ybs.digital.security.requestsigning.PayloadBuilder;
import uk.co.ybs.digital.security.requestsigning.RequestSigningClientHttpConnector;
import uk.co.ybs.digital.security.requestsigning.RequestSigningKeyRegistry;
import uk.co.ybs.digital.security.requestsigning.SignatureFactory;

@TestConfiguration
public class IntegrationTestConfig {
  @Value("${test.request.private.key}")
  String requestSigningPrivateKeyPem;

  @Bean
  public PrivateKey requestSigningPrivateKey() throws IOException, GeneralSecurityException {
    Security.addProvider(new BouncyCastleProvider());

    try (PemReader pemReader = new PemReader(new StringReader(requestSigningPrivateKeyPem))) {
      PemObject pemObject =
          Objects.requireNonNull(
              pemReader.readPemObject(),
              "Could not construct a PrivateKey from " + requestSigningPrivateKeyPem);
      OpenSSHPrivateKeySpec keySpec = new OpenSSHPrivateKeySpec(pemObject.getContent());

      KeyFactory kf = KeyFactory.getInstance("ECDSA", "BC");
      return kf.generatePrivate(keySpec);
    }
  }

  @Bean
  public WebTestClient signingWebClient(
      final ClientHttpConnector connector,
      final PrivateKey requestSigningPrivateKey,
      final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(
            new RequestSigningClientHttpConnector(
                connector,
                new ClientHttpRequestSigner(
                    new SignatureFactory(),
                    new PayloadBuilder(),
                    new RequestSigningKeyRegistry(
                        "FKbfNeQxsVQL5CwAJKP0q5fWOVe9ukn1K0lw", requestSigningPrivateKey))))
        .apply(webTestClientConfigurer)
        .build();
  }

  @Bean
  public WebTestClient nonSigningWebTestClient(
      final ClientHttpConnector connector, final WebTestClientConfigurer webTestClientConfigurer) {
    return WebTestClient.bindToServer(connector).apply(webTestClientConfigurer).build();
  }

  /**
   * WebTestClient doesn't seem to get properly configured with the Spring context ObjectMapper.
   * Manually do this.
   */
  @Bean
  public WebTestClientConfigurer webTestClientConfigurer(final ObjectMapper objectMapper) {
    return (builder, httpHandlerBuilder, connector) ->
        builder.exchangeStrategies(
            ExchangeStrategies.builder()
                .codecs(
                    (configurer) -> {
                      configurer
                          .defaultCodecs()
                          .jackson2JsonEncoder(new Jackson2JsonEncoder(objectMapper));
                      configurer
                          .defaultCodecs()
                          .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper));
                    })
                .build());
  }
}
