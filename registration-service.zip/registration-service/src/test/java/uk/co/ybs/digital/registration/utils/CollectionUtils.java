package uk.co.ybs.digital.registration.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public class CollectionUtils { // NOPMD

  public static <T> List<T> asList(final Collection<T> collection) {
    return new ArrayList<>(collection);
  }

  public static <T> List<T> asSortedList(final Collection<T> collection, final Comparator<T> cmp) {
    List<T> array = asList(collection);
    array.sort(cmp);
    return array;
  }
}
