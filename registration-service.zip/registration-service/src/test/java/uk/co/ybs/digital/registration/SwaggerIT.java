package uk.co.ybs.digital.registration;

import java.net.URI;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(
    webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = {IntegrationTestConfig.class})
@ActiveProfiles("test")
class SwaggerIT {
  @LocalServerPort private int port;

  @Autowired private WebTestClient nonSigningWebTestClient;

  @ValueSource(
      strings = {
        "/registration/swagger-resources",
        "/registration/v2/api-docs",
        "/registration/swagger-ui.html"
      })
  @ParameterizedTest
  void shouldReturnOkForSwaggerEndpointsWithNoSignature(final String path) {
    nonSigningWebTestClient.get().uri(getInfoURI(path)).exchange().expectStatus().isOk();
  }

  private URI getInfoURI(final String path) {
    return URI.create("http://localhost:" + port + path);
  }
}
