package uk.co.ybs.digital.registration.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.core.StringContains.containsString;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.IllegalTransactionStateException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import uk.co.ybs.digital.registration.model.CustomerLock;

@DataJpaTest
@ImportAutoConfiguration(FlywayAutoConfiguration.class)
@ActiveProfiles("test")
class CustomerLockRepositoryTest {

  @Autowired TestEntityManager entityManager;

  @Autowired CustomerLockRepository customerRepository;

  @Test
  void canRetrieveForPartyId() {
    CustomerLock customerLock = new CustomerLock(10L); // NOPMD
    entityManager.persistAndFlush(customerLock);

    Optional<CustomerLock> found = customerRepository.findByPartyId(10L); // NOPMD
    assertThat(found.isPresent(), is(true));

    Optional<CustomerLock> notFound = customerRepository.findByPartyId(20L); // NOPMD
    assertThat(notFound.isPresent(), is(false));
  }

  @Test
  @Transactional(propagation = Propagation.NEVER)
  void cannotBeCalledFromANonTransactionalContext() {
    IllegalTransactionStateException exception =
        assertThrows(
            IllegalTransactionStateException.class,
            () -> customerRepository.findByPartyId(10L)); // NOPMD
    assertThat(
        exception.getMessage(), allOf(containsString("transaction"), containsString("mandatory")));
  }
}
