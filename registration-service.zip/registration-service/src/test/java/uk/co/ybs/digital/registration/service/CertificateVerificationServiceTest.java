package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class CertificateVerificationServiceTest {

  private static String PEM_KEY; // NOPMD

  private final CertificateVerificationService certificateVerificationService =
      new CertificateVerificationService();

  @BeforeAll
  static void setup() throws Exception {
    PEM_KEY = new String(Files.readAllBytes(Paths.get("src/test/resources/ecdsa-public.pem")));
  }

  @Test
  void testVerifyDSAKey() {
    certificateVerificationService.verifyPem(PEM_KEY);
    assertThat(certificateVerificationService.verifyPem(PEM_KEY), is(true));
  }

  @Test
  void testVerifyRSAKey() throws Exception {
    String pemFile = new String(Files.readAllBytes(Paths.get("src/test/resources/rsa.pem")));
    assertThat(certificateVerificationService.verifyPem(pemFile), is(true));
  }

  @Test
  void testVerifyCorruptRSAKey() throws Exception {
    String pemFile =
        new String(Files.readAllBytes(Paths.get("src/test/resources/corrupt-rsa.pem")));
    assertThat(certificateVerificationService.verifyPem(pemFile), is(false));
  }
}
