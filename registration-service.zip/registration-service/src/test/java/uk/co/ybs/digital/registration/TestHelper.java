package uk.co.ybs.digital.registration;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.springframework.core.io.ClassPathResource;

public class TestHelper { // NOPMD
  public static String readResource(final String path) throws IOException {
    final Path resourcePath = new ClassPathResource(path).getFile().toPath();
    return new String(Files.readAllBytes(resourcePath), UTF_8);
  }
}
