package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.sameInstance;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import java.util.UUID;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.auditing.AuditingHandler;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;
import uk.co.ybs.digital.registration.exception.RegistrationDuplicateException;
import uk.co.ybs.digital.registration.exception.StaticDataMissingException;
import uk.co.ybs.digital.registration.model.App;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatus;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.model.RegistrationStatusType.Name;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;
import uk.co.ybs.digital.registration.utils.TestDataFactory;
import uk.co.ybs.digital.registration.web.controller.dto.RegistrationRequest;

@ExtendWith(MockitoExtension.class)
@SuppressWarnings("OptionalGetWithoutIsPresent")
class RegistrationServiceTest {

  private static final Long PARTY_ID = 1L;
  private static final UUID REGISTRATION_ID = UUID.randomUUID();
  private static final String APP_CODE = "SAPP";

  private final TestDataFactory testDataFactory = new TestDataFactory();

  @Mock private RegistrationRepository registrationRepository;
  @Mock private RegistrationStatusTypeService registrationStatusTypeService;
  @Mock private AppService appService;
  @Mock private CustomerLockService customerLockService;
  @Mock private AuditingHandler auditHandler;
  @Captor private ArgumentCaptor<Registration> savedRegistration;

  private Clock clock = Clock.fixed(Instant.now(), ZoneId.systemDefault());

  private RegistrationService registrationService;

  @BeforeEach
  void setUp() {
    registrationService =
        new RegistrationService(
            registrationRepository,
            registrationStatusTypeService,
            appService,
            customerLockService,
            clock,
            auditHandler);
  }

  private RegistrationRequest buildRegistrationRequest() {
    return RegistrationRequest.builder()
        .registrationId(REGISTRATION_ID)
        .partyId(PARTY_ID)
        .appCode(APP_CODE)
        .build();
  }

  private Registration buildSavedRegistration() {
    Registration registration = testDataFactory.factoryRandomRegistration();
    registration.setRegistrationId(REGISTRATION_ID);
    registration.setPartyId(PARTY_ID);
    return registration;
  }

  private RegistrationStatusType buildStatusType(final RegistrationStatusType.Name name) {
    return RegistrationStatusType.builder().name(name).code((long) name.ordinal()).build();
  }

  private App buildApp() {
    return App.builder().name("Some app").code(APP_CODE).build();
  }

  @Test
  void storeRegistrationSavesAValidRegistration() {
    final LocalDateTime now = LocalDateTime.now(clock);
    when(registrationRepository.existsByRegistrationId(REGISTRATION_ID)).thenReturn(false);
    when(registrationRepository.existsByPartyId(PARTY_ID)).thenReturn(false);

    final App app = buildApp();
    when(appService.findByAppCode(APP_CODE)).thenReturn(app);

    final RegistrationStatusType initialStatusType =
        buildStatusType(RegistrationStatusType.Name.INITIAL);
    when(registrationStatusTypeService.findByName(RegistrationStatusType.Name.INITIAL))
        .thenReturn(initialStatusType);

    final Registration persisted = buildSavedRegistration();
    when(registrationRepository.save(any())).thenReturn(persisted);

    final RegistrationRequest registrationRequest = buildRegistrationRequest();

    Registration actualCreated = registrationService.storeRegistration(registrationRequest);
    assertThat(actualCreated, sameInstance(persisted));

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
    verify(registrationRepository).save(savedRegistration.capture());

    final Registration saved = savedRegistration.getValue();
    assertThat(saved.getRegistrationId(), is(REGISTRATION_ID));
    assertThat(saved.getPartyId(), is(PARTY_ID));
    assertThat(saved.getApp(), is(app));
    assertThat(
        saved.getStatuses(),
        containsInAnyOrder(registrationStatus(saved, initialStatusType, now, Optional.empty())));
  }

  private Matcher<RegistrationStatus> registrationStatus(
      final Registration registration,
      final RegistrationStatusType statusType,
      final LocalDateTime startDate,
      final Optional<LocalDateTime> endDate) {
    return allOf(
        hasProperty("registration", is(registration)),
        hasProperty("statusType", is(statusType)),
        hasProperty("startDate", is(startDate)),
        hasProperty("endDate", is(endDate)));
  }

  @Test
  void storeRegistrationWithDuplicateRegistrationIdFailsWithDuplicateException() {
    when(registrationRepository.existsByRegistrationId(REGISTRATION_ID)).thenReturn(true);

    assertThrows(
        RegistrationDuplicateException.class,
        () -> registrationService.storeRegistration(buildRegistrationRequest()));

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
  }

  @Test
  void testExceptionThrownWhenStatusTypeNotFound() {
    when(registrationRepository.existsByRegistrationId(REGISTRATION_ID)).thenReturn(false);
    when(registrationRepository.existsByPartyId(PARTY_ID)).thenReturn(false);
    when(appService.findByAppCode(APP_CODE)).thenReturn(buildApp());

    when(registrationStatusTypeService.findByName(RegistrationStatusType.Name.INITIAL))
        .thenThrow(new StaticDataMissingException(RegistrationStatusType.Name.REGISTERED));

    assertThrows(
        StaticDataMissingException.class,
        () -> registrationService.storeRegistration(buildRegistrationRequest()));

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
  }

  @Test
  void testExceptionThrownWhenAppNotFound() {
    when(registrationRepository.existsByRegistrationId(REGISTRATION_ID)).thenReturn(false);
    when(registrationRepository.existsByPartyId(PARTY_ID)).thenReturn(false);

    when(appService.findByAppCode(APP_CODE)).thenThrow(new StaticDataMissingException("Oops"));

    assertThrows(
        StaticDataMissingException.class,
        () -> registrationService.storeRegistration(buildRegistrationRequest()));

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
  }

  @Test
  void storeRegistrationSuceedsWhenThereIsAlreadyARegistrationForCustomer() {
    final LocalDateTime now = LocalDateTime.now(clock);
    when(registrationRepository.existsByRegistrationId(REGISTRATION_ID)).thenReturn(false);
    when(registrationRepository.existsByPartyId(PARTY_ID)).thenReturn(true);

    final App app = buildApp();
    when(appService.findByAppCode(APP_CODE)).thenReturn(app);

    final RegistrationStatusType initialStatusType =
        buildStatusType(RegistrationStatusType.Name.INITIAL);
    when(registrationStatusTypeService.findByName(RegistrationStatusType.Name.INITIAL))
        .thenReturn(initialStatusType);

    final Registration persisted = buildSavedRegistration();
    when(registrationRepository.save(any())).thenReturn(persisted);

    final RegistrationRequest registrationRequest = buildRegistrationRequest();

    Registration actualCreated = registrationService.storeRegistration(registrationRequest);
    assertThat(actualCreated, sameInstance(persisted));

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
    verify(registrationRepository).save(savedRegistration.capture());

    final Registration saved = savedRegistration.getValue();
    assertThat(saved.getRegistrationId(), is(REGISTRATION_ID));
    assertThat(saved.getPartyId(), is(PARTY_ID));
    assertThat(saved.getApp(), is(app));
    assertThat(
        saved.getStatuses(),
        containsInAnyOrder(registrationStatus(saved, initialStatusType, now, Optional.empty())));
  }

  @Test
  void revokeRegistrationShouldRevokeExistingRegisteredRegistration() {
    final LocalDateTime now = LocalDateTime.now(clock);

    final Registration existingRegistration =
        testDataFactory.factoryRegistrationWithMultipleStatusesUnordered();
    when(registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, Collections.singletonList(RegistrationStatusType.Name.REGISTERED)))
        .thenReturn(Collections.singletonList(existingRegistration));

    final RegistrationStatusType revokedStatusType =
        buildStatusType(RegistrationStatusType.Name.REVOKED);
    when(registrationStatusTypeService.findByName(RegistrationStatusType.Name.REVOKED))
        .thenReturn(revokedStatusType);

    final Registration persisted = buildSavedRegistration();
    when(registrationRepository.save(any())).thenReturn(persisted);

    registrationService.revokeRegistration(PARTY_ID);

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
    verify(registrationRepository).save(savedRegistration.capture());

    final Registration saved = savedRegistration.getValue();
    assertThat(saved, is(existingRegistration));
    assertThat(
        saved.getStatuses(),
        containsInAnyOrder(
            registrationStatus(
                saved,
                buildStatusType(RegistrationStatusType.Name.INITIAL),
                LocalDateTime.of(2018, 2, 15, 13, 1),
                Optional.of(LocalDateTime.of(2018, 2, 15, 13, 2))),
            registrationStatus(
                saved,
                buildStatusType(RegistrationStatusType.Name.EXPIRED),
                LocalDateTime.of(2018, 2, 15, 13, 2),
                Optional.of(LocalDateTime.of(2018, 2, 15, 13, 3))),
            registrationStatus(
                saved,
                buildStatusType(RegistrationStatusType.Name.REGISTERED),
                LocalDateTime.of(2018, 2, 15, 13, 3),
                Optional.of(now)),
            registrationStatus(
                saved,
                buildStatusType(RegistrationStatusType.Name.REVOKED),
                now,
                Optional.empty())));
  }

  @Test
  void revokeRegistrationShouldThrowStaticDataMissingExceptionWhenRevokedStatusTypeDoesNotExist() {
    Registration existingRegistration = testDataFactory.factoryRandomRegistration(Name.REGISTERED);
    when(registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, Collections.singletonList(RegistrationStatusType.Name.REGISTERED)))
        .thenReturn(Collections.singletonList(existingRegistration));

    when(registrationStatusTypeService.findByName(RegistrationStatusType.Name.REVOKED))
        .thenThrow(new StaticDataMissingException(RegistrationStatusType.Name.REVOKED));

    assertThrows(
        StaticDataMissingException.class, () -> registrationService.revokeRegistration(PARTY_ID));

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
  }

  @Test
  void
      revokeRegistrationShouldThrowInvalidRegistrationStateExceptionWhenMulitpleActiveRegistrationsFound() {
    final Registration existingRegistration1 =
        testDataFactory.factoryRegistrationWithMultipleStatusesUnordered();
    final Registration existingRegistration2 =
        testDataFactory.factoryRegistrationWithMultipleStatusesUnordered();
    when(registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, Collections.singletonList(RegistrationStatusType.Name.REGISTERED)))
        .thenReturn(Arrays.asList(existingRegistration1, existingRegistration2));

    assertThrows(
        InvalidRegistrationStateException.class,
        () -> registrationService.revokeRegistration(PARTY_ID));

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
  }

  @Test
  void revokeRegistrationShouldDoNothingWhenNoActiveRegistrationFound() {
    when(registrationRepository.findByPartyIdAndCurrentStatusName(
            PARTY_ID, Collections.singletonList(RegistrationStatusType.Name.REGISTERED)))
        .thenReturn(Collections.emptyList());

    Optional<Registration> actual = registrationService.revokeRegistration(PARTY_ID);

    assertThat(actual, is(Optional.empty()));

    verify(customerLockService).acquireCustomerLock(PARTY_ID);
    verify(registrationRepository, never()).save(any());
  }
}
