package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.params.provider.EnumSource.Mode.EXCLUDE;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.auditing.AuditingHandler;
import uk.co.ybs.digital.registration.exception.InvalidKeyException;
import uk.co.ybs.digital.registration.exception.InvalidRegistrationStateException;
import uk.co.ybs.digital.registration.exception.PartyIdMismatchException;
import uk.co.ybs.digital.registration.exception.RegistrationNotFoundException;
import uk.co.ybs.digital.registration.model.Registration;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;
import uk.co.ybs.digital.registration.model.RegistrationStatusType.Name;
import uk.co.ybs.digital.registration.repository.RegistrationRepository;
import uk.co.ybs.digital.registration.utils.TestDataFactory;
import uk.co.ybs.digital.registration.web.controller.dto.RegisterKeysRequest;

@ExtendWith(MockitoExtension.class)
class CertificateServiceTest {

  private final TestDataFactory testDataFactory = new TestDataFactory();
  private Clock clock = Clock.fixed(Instant.now(), ZoneId.systemDefault());
  @Mock private RegistrationRepository registrationRepository;
  @Mock private RegistrationStatusTypeService statusTypeService;
  @Mock private CertificateVerificationService certificateVerificationService;
  @Mock private CustomerLockService customerLockService;
  @Mock private RegistrationExpiryService expiryService;
  @Mock private AuditingHandler auditingHandler;
  @Captor private ArgumentCaptor<Registration> savedRegistration;

  private CertificateService certificateService;

  @BeforeEach
  void setup() {
    certificateService =
        new CertificateService(
            clock,
            expiryService,
            registrationRepository,
            statusTypeService,
            certificateVerificationService,
            customerLockService,
            auditingHandler);
  }

  @Test
  void registerPemKeysThrowsNotFoundExceptionIfRegistrationDoesNotExist() {
    UUID registrationId = UUID.randomUUID();
    final RegisterKeysRequest request =
        RegisterKeysRequest.builder().registrationId(registrationId).partyId(1).build();

    when(registrationRepository.findByRegistrationId(registrationId)).thenReturn(Optional.empty());

    assertThrows(
        RegistrationNotFoundException.class, () -> certificateService.registerPemKeys(request));
  }

  @Test
  void registerPemKeysThrowsCustomerMismatchExceptionIfThePartyIdDoesNotMatchTheRegistration() {
    final long actualPartyId = 1;
    final long differentPartyId = 0;
    LocalDateTime now = LocalDateTime.now(clock);
    UUID registrationId = UUID.randomUUID();

    final RegisterKeysRequest request =
        RegisterKeysRequest.builder()
            .registrationId(registrationId)
            .partyId(differentPartyId)
            .build();
    Registration registration =
        buildExistingRegistration(Name.INITIAL, now, actualPartyId, registrationId);

    when(registrationRepository.findByRegistrationId(registrationId))
        .thenReturn(Optional.ofNullable(registration));

    assertThrows(PartyIdMismatchException.class, () -> certificateService.registerPemKeys(request));
  }

  @ParameterizedTest
  @EnumSource(value = RegistrationStatusType.Name.class, mode = EXCLUDE, names = "INITIAL")
  void registerPemKeysThrowsInvalidRegistrationExceptionIfItsActiveStateIsNotInitial(
      final RegistrationStatusType.Name type) {
    LocalDateTime now = LocalDateTime.now(clock);
    final long partyId = 1;
    UUID registrationId = UUID.randomUUID();
    final RegisterKeysRequest request =
        RegisterKeysRequest.builder().registrationId(registrationId).partyId(partyId).build();
    Registration registration = buildExistingRegistration(type, now, partyId, registrationId);

    when(registrationRepository.findByRegistrationId(registrationId))
        .thenReturn(Optional.of(registration));

    assertThrows(
        InvalidRegistrationStateException.class, () -> certificateService.registerPemKeys(request));
  }

  @ParameterizedTest
  @MethodSource("keysToRegister")
  void registerPemKeysThrowsInvalidKeysExceptionIfTheyAreNotProvided(
      final String apiKey, final String scaKey) {
    LocalDateTime now = LocalDateTime.now(clock);
    final long partyId = 1;
    UUID registrationId = UUID.randomUUID();
    final RegisterKeysRequest request =
        RegisterKeysRequest.builder()
            .registrationId(registrationId)
            .partyId(partyId)
            .apiKey(apiKey)
            .scaKey(scaKey)
            .build();
    Registration registration =
        buildExistingRegistration(Name.INITIAL, now, partyId, registrationId);

    when(registrationRepository.findByRegistrationId(registrationId))
        .thenReturn(Optional.of(registration));

    RuntimeException exception =
        assertThrows(InvalidKeyException.class, () -> certificateService.registerPemKeys(request));
    assertThat(exception.getMessage(), equalTo("Both API key and SCA key must be supplied"));
  }

  @Test
  void registerPemKeysThrowsInvalidKeysExceptionIfVerificationFails() {
    LocalDateTime now = LocalDateTime.now(clock);
    final long partyId = 1;
    UUID registrationId = UUID.randomUUID();
    String pem = "SOME_KEY";
    final RegisterKeysRequest request =
        RegisterKeysRequest.builder()
            .registrationId(registrationId)
            .partyId(partyId)
            .apiKey(pem)
            .scaKey(pem)
            .build();
    Registration registration =
        buildExistingRegistration(Name.INITIAL, now, partyId, registrationId);

    when(certificateVerificationService.verifyPem("SOME_KEY")).thenReturn(false);
    when(registrationRepository.findByRegistrationId(registrationId))
        .thenReturn(Optional.of(registration));

    RuntimeException exception =
        assertThrows(InvalidKeyException.class, () -> certificateService.registerPemKeys(request));
    assertThat(exception.getMessage(), equalTo("Invalid key. Keys should be in PEM format"));
  }

  @Test
  void registerPemKeysAddsTheKeysExpiresTheInitialStatusAndInsertsANewRegisteredStatus() {
    LocalDateTime now = LocalDateTime.now(clock);

    final long partyId = 1;
    UUID registrationId = UUID.randomUUID();
    String apiKey = "API_KEY";
    String scaKey = "SCA_KEY";
    final RegistrationStatusType registered = testDataFactory.factoryStatusType(Name.REGISTERED);
    Registration registration =
        buildExistingRegistration(Name.INITIAL, now, partyId, registrationId);
    final RegisterKeysRequest request =
        RegisterKeysRequest.builder()
            .registrationId(registrationId)
            .partyId(partyId)
            .apiKey(apiKey)
            .scaKey(scaKey)
            .build();

    when(registrationRepository.findByRegistrationId(registrationId))
        .thenReturn(Optional.of(registration));
    when(certificateVerificationService.verifyPem(anyString())).thenReturn(true);
    when(statusTypeService.findByName(Name.REGISTERED)).thenReturn(registered);

    Registration persisted =
        buildExistingRegistration(Name.REGISTERED, now, partyId, registrationId);
    when(registrationRepository.save(any())).thenReturn(persisted);

    Registration output = certificateService.registerPemKeys(request);

    assertThat(output, is(persisted));

    verify(customerLockService).acquireCustomerLock(partyId);
    verify(expiryService).expireAllIncompleteRegistrationsExcept(partyId, registrationId, now);
    verify(registrationRepository).save(savedRegistration.capture());

    Registration actualSavedRegistration = savedRegistration.getValue();
    assertThat(actualSavedRegistration.getRegistrationId(), equalTo(registrationId));
    assertThat(actualSavedRegistration.getPartyId(), equalTo(partyId));
    assertThat(actualSavedRegistration.getScaKey(), equalTo("SCA_KEY"));
    assertThat(actualSavedRegistration.getApiKey(), equalTo("API_KEY"));
    assertThat(
        actualSavedRegistration.getStatuses(),
        contains(
            allOf(
                hasProperty("statusType", hasProperty("name", equalTo(Name.INITIAL))),
                hasProperty("endDate", equalTo(Optional.of(now)))),
            allOf(
                hasProperty("statusType", hasProperty("name", equalTo(Name.REGISTERED))),
                hasProperty("endDate", equalTo(Optional.empty())))));
  }

  private static Stream<Arguments> keysToRegister() {
    return Stream.of(
        Arguments.of(null, null), Arguments.of(null, "scaKey"), Arguments.of("apiKey", null));
  }

  private Registration buildExistingRegistration(
      final RegistrationStatusType.Name currentStatus,
      final LocalDateTime now,
      final long partyId,
      final UUID registrationId) {
    Registration registration =
        Registration.builder().registrationId(registrationId).partyId(partyId).build();
    registration.setStatuses(
        new HashSet<>(
            Collections.singleton(
                testDataFactory.factoryRegistrationStatus(registration, currentStatus, now))));
    return registration;
  }
}
