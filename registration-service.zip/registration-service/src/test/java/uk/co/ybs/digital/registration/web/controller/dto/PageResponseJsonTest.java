package uk.co.ybs.digital.registration.web.controller.dto;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.json.JsonTest;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import uk.co.ybs.digital.registration.model.RegistrationStatusType;

@JsonTest
class PageResponseJsonTest {

  public static final long PARTY_ID = 1234L;
  @Autowired private JacksonTester<PageResponse<RegistrationResponse>> json;

  @Value("classpath:jsonTest/RegistrationPaginationResponse.json")
  private Resource file;

  private static final String DUMMY_API_KEY = "dummyApiKey";
  private static final String DUMMY_SCA_KEY = "dummyScaKey";
  private static final String DIGITAL_REGISTRATION = "DIGITAL_REGISTRATION";

  private PageResponse<RegistrationResponse> fullyPopulated;
  private final Pageable PAGEABLE = // NOPMD
      PageRequest.of(0, 20, Sort.Direction.DESC, "updatedAt");

  @BeforeEach
  void beforeEach() {
    RegistrationResponse registration1 =
        RegistrationResponse.builder()
            .registrationId(UUID.fromString("3b5b89cc-66fd-4538-b67b-03d50db93d1b"))
            .partyId(PARTY_ID)
            .status(RegistrationStatusType.Name.REGISTERED)
            .apiKey(DUMMY_API_KEY)
            .scaKey(DUMMY_SCA_KEY)
            .createdAt(LocalDateTime.parse("2019-08-25T10:10:30.00"))
            .updatedAt(LocalDateTime.parse("2019-10-25T10:15:30.00"))
            .updatedBy(DIGITAL_REGISTRATION)
            .build();

    RegistrationResponse registration2 =
        RegistrationResponse.builder()
            .registrationId(UUID.fromString("63a83027-d0cb-4e45-a5a3-073888e44ecc"))
            .partyId(PARTY_ID)
            .status(RegistrationStatusType.Name.REGISTERED)
            .apiKey(DUMMY_API_KEY)
            .scaKey(DUMMY_SCA_KEY)
            .createdAt(LocalDateTime.parse("2019-08-26T10:10:30.00"))
            .updatedAt(LocalDateTime.parse("2019-10-26T10:15:30.00"))
            .updatedBy(DIGITAL_REGISTRATION)
            .build();

    RegistrationResponse registration3 =
        RegistrationResponse.builder()
            .registrationId(UUID.fromString("ab5c1a07-0eb1-42ef-b194-7c1146a879ea"))
            .partyId(PARTY_ID)
            .status(RegistrationStatusType.Name.REGISTERED)
            .apiKey(DUMMY_API_KEY)
            .scaKey(DUMMY_SCA_KEY)
            .createdAt(LocalDateTime.parse("2019-08-27T10:10:30.00"))
            .updatedAt(LocalDateTime.parse("2019-10-27T10:15:30.00"))
            .updatedBy(DIGITAL_REGISTRATION)
            .build();

    RegistrationResponse registration4 =
        RegistrationResponse.builder()
            .registrationId(UUID.fromString("a3dadd60-6734-4ebc-8fa4-08dea3ae4f1d"))
            .partyId(PARTY_ID)
            .status(RegistrationStatusType.Name.REGISTERED)
            .apiKey(DUMMY_API_KEY)
            .scaKey(DUMMY_SCA_KEY)
            .createdAt(LocalDateTime.parse("2019-08-28T10:10:30.00"))
            .updatedAt(LocalDateTime.parse("2019-10-28T10:15:30.00"))
            .updatedBy(DIGITAL_REGISTRATION)
            .build();

    List<RegistrationResponse> registrations =
        Arrays.asList(registration1, registration2, registration3, registration4);
    fullyPopulated = new PageResponse<>(new PageImpl<>(registrations, PAGEABLE, 4));
  }

  @Test
  void serializes() throws Exception {
    assertThat(json.write(fullyPopulated)).isEqualToJson(file, JSONCompareMode.STRICT);
  }

  @Test
  void deserializes() throws Exception {
    // This test will pass even if totalElements is changed in the JSON file.
    // It is required for deserialization but is ignored and re-computed in the underlying PageImpl
    // instance.
    assertThat(json.read(file)).isEqualTo(fullyPopulated);
  }
}
