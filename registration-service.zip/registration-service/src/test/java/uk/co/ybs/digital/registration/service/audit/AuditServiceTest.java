package uk.co.ybs.digital.registration.service.audit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.startsWith;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static uk.co.ybs.digital.registration.TestHelper.readResource;

import java.io.IOException;
import java.util.UUID;
import java.util.stream.Stream;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import okhttp3.mockwebserver.RecordedRequest;
import org.hamcrest.Matcher;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.web.reactive.function.client.ClientHttpConnectorAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import uk.co.ybs.digital.registration.config.ServiceToServiceConfig;
import uk.co.ybs.digital.registration.service.audit.dto.AuditRegistrationRequest;
import uk.co.ybs.digital.registration.service.audit.dto.UserSession;
import uk.co.ybs.digital.registration.utils.ServiceRandomPortInitializer;
import uk.co.ybs.digital.registration.web.controller.dto.RequestMetadata;
import uk.co.ybs.digital.registration.web.controller.dto.VerificationMethod;
import uk.co.ybs.digital.security.requestsigning.RequestSigningAutoConfiguration;

@SpringBootTest(
    classes = {
      AuditService.class,
      ServiceToServiceConfig.class,
      RequestSigningAutoConfiguration.class,
      ClientHttpConnectorAutoConfiguration
          .class // Required by the WebClient bean defined in AccountServiceConfig
    },
    webEnvironment = SpringBootTest.WebEnvironment.NONE)
@AutoConfigureWebClient
@ContextConfiguration(initializers = ServiceRandomPortInitializer.class)
@ActiveProfiles({"test", "text-logging"})
class AuditServiceTest {
  private static final String IP_ADDRESS = "127.0.0.1";
  private static final String CHANNEL = "SAPP";
  private static final String BRAND_CODE = "YBS";
  private static final String HEADER_REQUEST_ID = "x-ybs-request-id";
  private static final String FAILED_ERROR_CODE = "400";

  private static final String HTTP_STATUS_ERROR_MESSAGE_PREFIX =
      "Audit service returned error status: ";
  public static final String AUDIT_CERTIFICATES_RESPONSE_PATH = "jsonTest/api/audit/certificates";

  @Autowired private AuditService auditService;

  @Value("${uk.co.ybs.digital.audit-test-port}")
  private int auditTestPort;

  private MockWebServer mockWebServer;

  @BeforeEach
  void setUp() throws IOException {
    mockWebServer = new MockWebServer();
    mockWebServer.start(auditTestPort);
  }

  @AfterEach
  void tearDown() throws IOException {
    mockWebServer.shutdown();
  }

  @Test
  void shouldAuditRegistration() throws Exception {
    final UUID requestId = UUID.randomUUID();
    final AuditRegistrationRequest request = buildValidAuditRegistrationRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(requestId);

    mockWebServer.enqueue(new MockResponse().setResponseCode(HttpStatus.NO_CONTENT.value()));

    auditService.auditRegistration(request, requestMetadata);

    final RecordedRequest recordedRequest = mockWebServer.takeRequest();
    assertThat(recordedRequest.getMethod(), is(HttpMethod.POST.name()));
    assertThat(recordedRequest.getPath(), is("/audit/registration/register"));
    assertThat(recordedRequest.getHeader(HEADER_REQUEST_ID), is(requestId.toString()));
    assertThat(recordedRequest.getHeader(HttpHeaders.ACCEPT), is(MediaType.APPLICATION_JSON_VALUE));

    final String expectedBody =
        readResource(AUDIT_CERTIFICATES_RESPONSE_PATH + "/request/AuditRegistrationRequest.json");

    JSONAssert.assertEquals(
        expectedBody, recordedRequest.getBody().readUtf8(), JSONCompareMode.STRICT);
  }

  @Test
  void shouldThrowAuditServiceExceptionForConnectionError() throws IOException {
    UUID requestId = UUID.randomUUID();

    mockWebServer.shutdown();
    final AuditRegistrationRequest auditRegistrationRequest = buildValidAuditRegistrationRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(requestId);

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditRegistration(auditRegistrationRequest, requestMetadata));
    assertThat(exception.getMessage(), is(equalTo("Error calling audit service")));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  @ParameterizedTest
  @MethodSource("auditServiceErrorResponses")
  void auditRegistrationShouldThrowAuditServiceExceptionsForAuditServiceErrorResponses(
      final HttpStatus responseStatus,
      final MediaType responseContentType,
      final String responseBody,
      final Matcher<String> expectedMessage) {
    mockWebServer.enqueue(
        new MockResponse()
            .setResponseCode(responseStatus.value())
            .setHeader(HttpHeaders.CONTENT_TYPE, responseContentType)
            .setBody(responseBody));

    final UUID requestId = UUID.randomUUID();
    final AuditRegistrationRequest auditRegistrationRequest = buildValidAuditRegistrationRequest();
    final RequestMetadata requestMetadata = buildRequestMetadata(requestId);

    final AuditServiceException exception =
        assertThrows(
            AuditServiceException.class,
            () -> auditService.auditRegistration(auditRegistrationRequest, requestMetadata));
    assertThat(exception.getMessage(), is(expectedMessage));
    assertThat(exception.getCause(), not(instanceOf(AuditServiceException.class)));
  }

  private static Stream<Arguments> auditServiceErrorResponses() throws IOException {
    return Stream.of(
        Arguments.of(
            HttpStatus.FORBIDDEN,
            MediaType.APPLICATION_JSON,
            readResource(
                AUDIT_CERTIFICATES_RESPONSE_PATH
                    + "/response/error-response-invalid-signature.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + "403"),
                containsString("AccessDenied.InvalidRequestSignature"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readResource(
                AUDIT_CERTIFICATES_RESPONSE_PATH + "/response/error-response-bad-request.json"),
            allOf(
                startsWith(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_ERROR_CODE),
                containsString("Field.Invalid"))),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readResource(AUDIT_CERTIFICATES_RESPONSE_PATH + "/response/unexpected-response.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_ERROR_CODE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readResource(AUDIT_CERTIFICATES_RESPONSE_PATH + "/response/empty-response.json"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_ERROR_CODE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.APPLICATION_JSON,
            readResource(AUDIT_CERTIFICATES_RESPONSE_PATH + "/response/text-response.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_ERROR_CODE)),
        Arguments.of(
            HttpStatus.BAD_REQUEST,
            MediaType.TEXT_PLAIN,
            readResource(AUDIT_CERTIFICATES_RESPONSE_PATH + "/response/text-response.txt"),
            is(HTTP_STATUS_ERROR_MESSAGE_PREFIX + FAILED_ERROR_CODE)));
  }

  private AuditRegistrationRequest buildValidAuditRegistrationRequest() {
    return AuditRegistrationRequest.builder()
        .ipAddress("12.66.53.145")
        .userSession(
            UserSession.builder()
                .brandCode("YBS")
                .channel("SAPP")
                .partyId(1234567890L)
                .registrationId(UUID.fromString("597fa3f7-7e8d-45fc-a7c7-dfc8d5b83360"))
                .sessionId(UUID.fromString("79c1ee70-6771-4bc5-8004-de707b582b69"))
                .verificationMethod(VerificationMethod.BIOMETRIC)
                .title("Mr")
                .surname("Smith")
                .email("john.smith@ybs.co.uk")
                .build())
        .build();
  }

  private RequestMetadata buildRequestMetadata(final UUID requestId) {
    return RequestMetadata.builder()
        .requestId(requestId)
        .ipAddress(IP_ADDRESS)
        .channel(CHANNEL)
        .brandCode(BRAND_CODE)
        .build();
  }
}
