package uk.co.ybs.digital.registration.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import uk.co.ybs.digital.registration.exception.StaticDataMissingException;
import uk.co.ybs.digital.registration.model.App;
import uk.co.ybs.digital.registration.repository.AppRepository;

@ExtendWith(MockitoExtension.class)
public class AppServiceTest {
  @Mock private AppRepository appRepository;

  private AppService testSubject;

  private static final String SAPP = "SAPP";

  @BeforeEach
  public void beforeEach() {
    testSubject = new AppService(appRepository);
  }

  @Test
  void findByAppCodeShouldReturnAppWhenItExists() {
    final App app = App.builder().code(SAPP).build();
    when(appRepository.findById(SAPP)).thenReturn(Optional.of(app));

    final App actual = testSubject.findByAppCode(SAPP);
    assertThat(actual, is(app));
  }

  @Test
  void findByAppCodeShouldThrowStaticDataMissingExceptionWhenAppDoesNotExist() {
    when(appRepository.findById(SAPP)).thenReturn(Optional.empty());

    final StaticDataMissingException thrown =
        assertThrows(StaticDataMissingException.class, () -> testSubject.findByAppCode(SAPP));
    assertThat(thrown.getMessage(), is("Could not retrieve app for code [SAPP] from the database"));
  }
}
