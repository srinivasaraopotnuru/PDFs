#!/bin/bash

docker network ls | grep -q " reg_network "
SPL_NETWORK_EXISTS=$?

if [ "$SPL_NETWORK_EXISTS" -eq 0 ]; then
    echo "'reg_network' already exists"
    exit 0
fi

docker network create reg_network

