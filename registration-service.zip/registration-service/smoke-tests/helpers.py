import hashlib
import os

import requests
from ecdsa import SigningKey

import config
from signer import Signer

host = os.getenv('SERVICE_HOST', 'localhost:8080')
protocol = os.getenv('SERVICE_PROTOCOL', 'http')
host_presented = 'some.host.name'
context_path = '/registration'
request_path = '/register'
strip_whitespace_regex = '\\s*'
key_id = 'apigee-nonprod-1'
signer = Signer({
    key_id: SigningKey.from_pem(config.private_key, hashlib.sha256)
})


def sign(request: requests.PreparedRequest):
    signer.sign_request(request)


def create_register_body(reg_id, party_id):
    return {"registrationId": reg_id,
            "partyId": party_id,
            "appCode": "SAPP"}


def create_certificates_body(reg_id, party_id):
    return {
        "registrationId": reg_id,
        "partyId": party_id,
        "scaKey": "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA10ygROPFohtOFV/iFy93yp2sFbFEPy/ACNuukoMun8ubbjCbtrqbQP9mYQKiBj18QWSMDo94yLEK+DzPHpaZ2WUF/uVFbirj3ZqapOAfb4zlJsdP47h5nvh5K2ycVTtTwTJo4T/WWbNWLUrio7Peg1A4+dYY+eMQyaXDT1biiv5WpfhB4cI/DDf1xvcFNE6zHp33K0kTuUNdfAluMQHiZx0hiYihdI/wdHyDze+48FfVVMtvDzu1pf4Yjbmc5ll9+Ke9qD6/KKpnd6RJAEIFWl0azQALpJBxADQR5T9OpqR1J+4PVUTFudlwArkpTLedFC1S6k0ZjnVgmxXCtFrHCQIDAQAB\n-----END PUBLIC KEY-----",
        "apiKey": "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA10ygROPFohtOFV/iFy93yp2sFbFEPy/ACNuukoMun8ubbjCbtrqbQP9mYQKiBj18QWSMDo94yLEK+DzPHpaZ2WUF/uVFbirj3ZqapOAfb4zlJsdP47h5nvh5K2ycVTtTwTJo4T/WWbNWLUrio7Peg1A4+dYY+eMQyaXDT1biiv5WpfhB4cI/DDf1xvcFNE6zHp33K0kTuUNdfAluMQHiZx0hiYihdI/wdHyDze+48FfVVMtvDzu1pf4Yjbmc5ll9+Ke9qD6/KKpnd6RJAEIFWl0azQALpJBxADQR5T9OpqR1J+4PVUTFudlwArkpTLedFC1S6k0ZjnVgmxXCtFrHCQIDAQAB\n-----END PUBLIC KEY-----"
    }
