import os
import pytest
import uuid
from grappa import should

import config
import helpers
import requests

host = os.getenv('SERVICE_HOST', 'localhost:8081')
protocol = os.getenv('SERVICE_PROTOCOL', 'http://')
host_presented = host
context_path = '/registration'
request_path = '/register'
strip_whitespace_regex = '\\s*'
party_id = 6959472174
verification_method= 'BIOMETRIC'


@pytest.fixture
def request_id():
    return str(uuid.uuid4())


@pytest.fixture(scope="session")
def registration_id():
    return str(uuid.uuid4())


@pytest.fixture(scope="session")
def session_id():
    return str(uuid.uuid4())


def test_register_endpoint(request_id, registration_id):
    url = f'{protocol}{host}/registration/register'
    msg_body = create_register_body(party_id, registration_id)
    request = requests.Request('post',
                               url,
                               json=msg_body,
                               headers={
                                   'x-ybs-request-id': request_id,
                                   'x-ybs-request-signature-key-id': helpers.key_id,
                                   'Host': host_presented
                               }).prepare()
    # response contains the id of the newly-created device
    helpers.sign(request)
    response = requests.session().send(request, verify=False)

    response.status_code | should.equal(200, msg=response.text)


@pytest.mark.run(after="test_register_endpoint")
def test_certificates_endpoint(request_id, registration_id, session_id):
    msg_body = create_certificates_body(party_id, registration_id, session_id, verification_method)
    path = '/registration/certificates'
    url = f'{protocol}{host}{path}'
    request = requests.Request('post',
                               url,
                               json=msg_body,
                               headers={
                                   'x-ybs-request-id': request_id,
                                   'x-ybs-request-signature-key-id': helpers.key_id,
                                   'x-ybs-channel': 'SAPP',
                                   'x-ybs-brand-code':'YBS',
                                   'Host': host_presented
                               }).prepare()
    # response contains th id of the newly-created device
    helpers.sign(request)
    response = requests.session().send(request, verify=False)

    response.status_code | should.equal(200, msg=response.text)


@pytest.mark.run(after="test_certificates_endpoint")
def test_get_registration_endpoint(request_id, registration_id):
    path = f'/registration/registration/{registration_id}'
    url = f'{protocol}{host}{path}'
    request = requests.Request('get',
                               url,
                               headers={
                                   'x-ybs-request-id': request_id,
                                   'x-ybs-request-signature-key-id': helpers.key_id,
                                   'Host': host_presented
                               }).prepare()
    # response contains the id of the newly-created device
    helpers.sign(request)
    response = requests.session().send(request, verify=False)

    with should(response.json()):
        should.be.a('dict')
        should.have.key("registrationId").should.be.equal.to(registration_id)
        should.have.key("status").should.be.equal.to("REGISTERED"),
        should.have.key("partyId").should.be.equal.to(party_id),
        should.have.key("apiKey").should.be.equal.to(config.public_key),
        should.have.key("scaKey").should.be.equal.to(config.public_key),
        should.have.key('updatedBy').should.not_be.none,
        should.have.key('createdAt').should.not_be.none,
        should.have.key('updatedAt').should.not_be.none


@pytest.mark.run(after="test_certificates_endpoint")
def test_get_registrations_endpoint(request_id, registration_id):
    path = f'/registration/registration?partyId={party_id}'
    url = f'{protocol}{host}{path}'
    request = requests.Request('get',
                               url,
                               headers={
                                   'x-ybs-request-id': request_id,
                                   'x-ybs-request-signature-key-id': helpers.key_id,
                                   'Host': host_presented
                               }).prepare()
    # response contains the id of the newly-created device
    helpers.sign(request)
    response = requests.session().send(request, verify=False)

    response_dict = response.json()
    with should(response_dict):
        should.be.a('dict')
        should.have.key("pageSize").should.be.equal.to(20),
        should.have.key("pageNumber").should.be.equal.to(0),
        should.have.key("totalPages").should.be.higher.than(0),
        should.have.key("totalElements").should.be.higher.than(0),
        should.have.key("content").should.be.a('list') > should.not_be.empty
        
    with should(response_dict["content"][0]):
        should.be.a('dict')
        should.have.key("registrationId").should.not_be.none,
        should.have.key("status").should.not_be.none,
        should.have.key("partyId").should.not_be.none,
        should.have.key("customerId").should.not_be.none,
        should.have.key("apiKey").should.not_be.none,
        should.have.key("scaKey").should.not_be.none,
        should.have.key('updatedBy').should.not_be.none,
        should.have.key('createdAt').should.not_be.none,
        should.have.key('updatedAt').should.not_be.none


@pytest.mark.run(after="test_get_registration_endpoint")
def test_revoke_registration_endpoint(request_id, registration_id):
    path = f'/registration/registration/revoke/{party_id}'
    url = f'{protocol}{host}{path}'
    admin_user = 'smoketest-admin-user'
    request = requests.Request('put',
                               url,
                               headers={
                                   'x-ybs-request-id': request_id,
                                   'x-ybs-request-signature-key-id': helpers.key_id,
                                   'x-ybs-admin-user': admin_user,
                                   'Host': host_presented
                               }).prepare()
    # response contains the id of the newly-created device
    helpers.sign(request)
    response = requests.session().send(request, verify=False)

    with should(response.json()):
        should.be.a('dict')
        should.have.key("registrationId").should.be.equal.to(registration_id)
        should.have.key("status").should.be.equal.to("REVOKED"),
        should.have.key("partyId").should.be.equal.to(party_id),
        should.have.key("customerId").should.be.equal.to(party_id),
        should.have.key("apiKey").should.be.equal.to(config.public_key),
        should.have.key("scaKey").should.be.equal.to(config.public_key),
        should.have.key('updatedBy').should.be.equal.to(admin_user),
        should.have.key('createdAt').should.not_be.none,
        should.have.key('updatedAt').should.not_be.none

def create_register_body(customer, registration_id):
    return {
        "registrationId": registration_id,
        "partyId": customer,
        "appCode": "SAPP"
    }


def create_certificates_body(customer, registration_id, session_id, verification_method):
    return {
        "registrationId": registration_id,
        "partyId": customer,
        "apiKey": config.public_key,
        "scaKey": config.public_key,
        "sessionId": session_id,
        "verificationMethod": verification_method,
        "customer": {
            "title": "Mr",
            "firstName": "John",
            "lastName": "Smith",
            "email": "YBSSavingsApp@ybs.co.uk"
          }
    }
