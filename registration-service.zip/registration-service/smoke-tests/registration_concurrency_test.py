#!/usr/bin/env python3
import json
import os
import threading
import uuid

import requests

import helpers

host = os.getenv('SERVICE_HOST', 'localhost:8080')
protocol = os.getenv('SERVICE_PROTOCOL', 'http://')
errors = []


def do_registration(index):
    registration = init_registration(index)
    reg_id = registration['registrationId']
    party_id = registration['partyId']
    request_id = str(uuid.uuid4())

    certificates_body = helpers.create_certificates_body(reg_id, party_id)

    url = f'{protocol}{host}/registration/certificates'
    request = requests.Request(
        'post',
        url,
        data=json.dumps(certificates_body),
        headers={
            'Content-Type': 'application/json',
            'x-ybs-request-id': request_id,
            'x-ybs-request-signature-key-id': helpers.key_id,
            'Host': helpers.host_presented
        }).prepare()

    helpers.sign(request)
    response = requests.session().send(request, verify=False)

    print(f'Certificate content {response.content}')
    if not (
            response.status_code == 200 or response.status_code == 401):  # 401 means the registration changed under its feet, which is what we expect (PartyIdMismatchException)
        errors.append(response)


def init_registration(index):
    reg_id = str(uuid.uuid4())
    party_id = 10
    request_id = str(uuid.uuid4())

    body = helpers.create_register_body(reg_id, party_id)

    url = f'{protocol}{host}/registration/register'
    request = requests.Request(
        'post',
        url,
        data=json.dumps(body),
        headers={
            'Content-Type': 'application/json',
            'x-ybs-request-id': request_id,
            'x-ybs-request-signature-key-id': helpers.key_id,
            'Host': helpers.host_presented
        }
    ).prepare()

    helpers.sign(request)
    response = requests.session().send(request, verify=False)
    print(f'Register content: {response.content}')

    return response.json()


def test_concurrent_registrations():
    threads = []
    for index in range(
            2):  ## I can only seem to replicate this with two threads ... More than that and I get different errors
        thread = threading.Thread(target=do_registration, args=(index,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    for error in errors:
        print(f'Status code {error.status_code}, Content {error.content}')

    assert len(errors) == 0
