import json
import sys
from enum import Enum

import requests

class OpenShift:

  ###Applications
  CFG_STATEFULSETS = "statefulsets"
  CFG_DEPLOY = "deploymentconfigs"
  CFG_ROUTE = "routes"
  CFG_SERVICE = "services"

  ###Other config
  CFG_AUTOSCALE = "horizontalpodautoscalers"

  ###Builds
  CFG_BUILD = "buildconfigs"
  CFG_IMAGE_STREAM = "imagestreams"

  ###Resources
  CFG_SECRET = "secrets"
  CFG_CONFIGMAPS = "configmaps"

  ###Storage
  CFG_PVCLAIMS = "persistentvolumeclaims"

  ###RBAC, Roles, Users etc
  CFG_ROLES = "roles"
  CFG_ROLEBINDINGS = "rolebindings"
  CFG_SVC_ACCOUNTS = "serviceaccounts"

  def __init__(self, subdomain, namespace, username, password, proxies):

    if subdomain is None: raise Exception("subdomain cannot be None")
    if namespace is None: raise Exception("namespace cannot be None")

    self.host = ('https://{}.os.ybs.com').format(subdomain)
    self.namespace = namespace
    self.username = username
    self.password = password
    self.proxies = proxies
    self.session = requests.Session()

    # self.session.auth = username.strip(), password.strip()
    self.session.headers.update({
      'Accept': 'application/json'
    })
    print(self.session.headers)
    auth_token = self.get_token(username, password)
    if auth_token is not None:
      self.session.headers.update({
        'Authorization': "Bearer " + auth_token
      })

  def get_token(self, username, password):
    geturi = '/oauth/authorize?client_id=openshift-challenging-client&response_type=token'
    # https://<master-address>:8443/oauth/authorize?client_id=openshift-challenging-client&response_type=token
    response = self.session.get(self.host + geturi, proxies=self.proxies, verify=False, auth=(username.strip(), password.strip()), allow_redirects=False)
    # print("response: ", response.headers)
    # print("response: ", response.text)
    token = None
    if 'Location' in response.headers:
      # Get token from the redirect URL
      # print('Location', response.headers['Location'])
      start = response.headers['Location'].index("access_token=")
      end = response.headers['Location'].index("&", start)
      token = response.headers['Location'][(start+13):end]
      print("token:", token)
    return token

  def get_config(self, cfgtype, name):
    '''Gets an OpenShift BuildConfig.'''
    geturi = (
      '{}/namespaces/{}'
      '/{}/{}').format(self.get_api_base(cfgtype), self.namespace, cfgtype, name)
    print("geturi:", geturi)

    response = self.session.get(self.host + geturi, proxies=self.proxies, verify=False)
    print("response.status_code:", response.status_code)
    #print("Response: ", response.text)
    self.check_response(response, 200, 404)

    resultDict = None
    if response.status_code == 200:
      resultDict = response.json()
    return resultDict

  def upsert_config(self, cfgtype, name, new_value, old_value=None):
      '''Updates an OpenShift BuildConfig.'''
      theuri = (
          '{}/namespaces/{}'
          '/{}').format(self.get_api_base(cfgtype), self.namespace, cfgtype)
      print("theuri:", theuri)

      if (old_value is None):
          response = self.session.post(self.host + theuri, proxies=self.proxies, data=json.dumps(new_value), verify=False)
      else:
          theuri = theuri + ("/{}").format(name)
          response = self.session.put(self.host + theuri, proxies=self.proxies, data=json.dumps(new_value), verify=False)
      print("response.status_code:", response.status_code)
      #print("Response: ", response.text)
      self.check_response(response, 200, 201)

  def instantiate(self, cfgtype, name, req_value):
      '''Instantiate an OpenShift Config. e.g activate a deployment or build'''
      resultDict = None
      theuri = (
          '{}/namespaces/{}'
          '/{}/{}/instantiate').format(self.get_api_base(cfgtype), self.namespace, cfgtype, name)
      print("theuri:", theuri)

      response = self.session.post(self.host + theuri, proxies=self.proxies, data=json.dumps(req_value), verify=False)
      print("response.status_code:", response.status_code)
      #print("Response: ", response.text)
      self.check_response(response, 200, 201)

      resultDict = response.json()
      return resultDict

  def followlog(self, cfgtype, name, sinceTime, breakStr=None, timeoutSecs=10, limitBytes=64000):
      '''Read a log for an OpenShift Config. e.g deployment or build log and follow it until completion'''
      '''Returns a string'''
      resultDict = None
      theuri = (
          '{}/namespaces/{}'
          '/{}/{}/log?follow=true&sinceTime={}&limitBytes={}').format(
              self.get_api_base(cfgtype), self.namespace, cfgtype, name, sinceTime, limitBytes)
      print("theuri:", theuri)

      response = self.session.get(self.host + theuri, proxies=self.proxies, verify=False, stream=True, timeout=timeoutSecs)
      # print("response.status_code:", response.status_code)
      #print("Response: ", response.text)
      # self.check_response(response, 200)

      resultStr = ""
      for line in response.iter_lines():
          # filter out keep-alive new lines
          # print("line:", line)
          if line:
              decoded_line = line.decode('utf-8')
              print("logline:", decoded_line)
              resultStr = resultStr + decoded_line + "\n"
              if breakStr is not None and breakStr in decoded_line:
                  break

      # resultStr = response.text
      return resultStr

  def watch(self, cfgtype, name, breakStr=None, timeoutSecs=10):
      '''Read a watch for an OpenShift Config. e.g deployment or build log and follow it until completion'''
      '''Returns a string'''
      resultDict = None
      theuri = (
          '{}/watch/namespaces/{}'
          '/{}/{}?watch=true&includeUninitialized=true&timeoutSeconds={}').format(
              self.get_api_base(cfgtype), self.namespace, cfgtype, name, 30)
      print("theuri:", theuri)

      response = self.session.get(self.host + theuri, proxies=self.proxies, verify=False, stream=True, timeout=timeoutSecs)

      resultStr = ""
      for line in response.iter_lines():
          # filter out keep-alive new lines
          # print("line:", line)
          if line:
              decoded_line = line.decode('utf-8')
              print("watchline:", decoded_line)
              resultStr = resultStr + decoded_line + "\n"
              if breakStr is not None and breakStr in decoded_line:
                  break

      # resultStr = response.text
      return resultStr

  def get_status(self, cfgtype, name):
    '''Get status for something in OpenShift'''
    '''Returns a string'''
    resultDict = None
    theuri = (
      '{}/namespaces/{}'
      '/{}/{}').format(
        self.get_api_base(cfgtype), self.namespace, cfgtype, name)
    print("theuri:", theuri)

    response = self.session.get(self.host + theuri, proxies=self.proxies, verify=False, timeout=10)
    print("response.status_code:", response.status_code)
    self.check_response(response, 200, 201)
    resultDict = response.json()
    return resultDict

  @staticmethod
  def get_api_base(cfgtype):
    apibase = "/oapi/v1"
    if cfgtype == OpenShift.CFG_SERVICE or cfgtype == OpenShift.CFG_SECRET\
        or cfgtype == OpenShift.CFG_PVCLAIMS or cfgtype == OpenShift.CFG_SVC_ACCOUNTS\
        or cfgtype == OpenShift.CFG_CONFIGMAPS:
      apibase = "/api/v1"
    if cfgtype == OpenShift.CFG_AUTOSCALE:
      apibase = "/apis/autoscaling/v1"
    if cfgtype == OpenShift.CFG_STATEFULSETS:
      apibase = "/apis/apps/v1beta1"
    if cfgtype == OpenShift.CFG_ROLES or cfgtype == OpenShift.CFG_ROLEBINDINGS:
      apibase = "/apis/rbac.authorization.k8s.io/v1beta1"
    return apibase

  @staticmethod
  def check_response(response, *status_codes):
    if response.status_code not in status_codes:
      msg = 'invalid response code [{}]'.format(response.status_code)
      raise RuntimeError(msg, ':', response.text)
