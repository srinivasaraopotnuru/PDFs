'''scans for changes against merge base and only deploys modified configs,
this ignores untracked files so these should be added to the index if they
should be included'''

import hashlib
import itertools
import json
import os
import re
import shutil
import stat
import sys
import time
import zlib
from base64 import b64decode, b64encode
from datetime import datetime
from tempfile import TemporaryDirectory

import git_utils
import hashing
import os_utils
from openshift import OpenShift

CFG_ROOT_DIR = "openshift-config"
###Applications
CFG_STATEFULSETS = "statefulsets"
CFG_DEPLOY = "deployconfig"
CFG_SERVICE = "service"
CFG_ROUTES = "routes"

CFG_AUTOSCALE = "autoscaling"

###Builds
CFG_BUILD = "buildconfig"
CFG_IMAGE_STREAM = "imagestream"

###Resources
CFG_SECRET = "secrets"
CFG_CONFIGMAPS = "configmaps"

###Storage
CFG_PVCLAIMS = "pvclaims"

###RBAC, Roles, Users etc
CFG_ROLES = "roles"
CFG_ROLEBINDINGS = "role-bindings"
CFG_SVC_ACCOUNTS = "svc-accounts"

###Actions
ACT_DEPLOY = "deploy-request"
ACT_WATCH = "watch"
ACT_CHECK_STATUS = "check-status"

def update_config(openshift):
  print("update_config")
  repo = git_utils.find_git_root(os.getcwd())
  git_root_dir = repo.working_tree_dir
  envType = os.getenv('ENVIRONMENT_TYPE')
  if envType is None:
    raise RuntimeError("Env var: ENVIRONMENT_TYPE must be defined")

  nsAppsDir = os.path.join(git_root_dir, CFG_ROOT_DIR, envType, 'applications')
  if os.path.isdir(nsAppsDir):
    configEntries = sorted(os.listdir(nsAppsDir))
    if len(configEntries) <= 0:
      raise RuntimeError("No applications found for", envType)
    for appName in configEntries:
      print("appName", appName)
      if appName.startswith("."):
        # Ignore hidden applications
        continue
      # Configure secrets first
      nsScrtsDir = os.path.join(nsAppsDir, appName, 'secrets')
      if os.path.isdir(nsScrtsDir):
        configEntries = os.listdir(nsScrtsDir)
        for scrtName in configEntries:
          print("scrtName", scrtName)
          upsert_config(openshift, nsScrtsDir, scrtName, None, OpenShift.CFG_SECRET, envType)
      # Configure resources.
      print("configmaps")
      upsert_config(openshift, nsAppsDir, appName, CFG_CONFIGMAPS, OpenShift.CFG_CONFIGMAPS, envType)
      # Configure storage.
      print("pvclaims")
      upsert_config(openshift, nsAppsDir, appName, CFG_PVCLAIMS, OpenShift.CFG_PVCLAIMS, envType)
      # Configure RBAC.
      print("roles")
      upsert_config(openshift, nsAppsDir, appName, CFG_ROLES, OpenShift.CFG_ROLES, envType)
      print("serviceaccounts")
      upsert_config(openshift, nsAppsDir, appName, CFG_SVC_ACCOUNTS, OpenShift.CFG_SVC_ACCOUNTS, envType)
      print("rolebindings")
      upsert_config(openshift, nsAppsDir, appName, CFG_ROLEBINDINGS, OpenShift.CFG_ROLEBINDINGS, envType)
      # Configure application in specific order.
      print("buildconfig")
      upsert_config(openshift, nsAppsDir, appName, CFG_BUILD, OpenShift.CFG_BUILD, envType)
      print("imagestream")
      upsert_config(openshift, nsAppsDir, appName, CFG_IMAGE_STREAM, OpenShift.CFG_IMAGE_STREAM, envType)
      print("deployconfig")
      upsert_config(openshift, nsAppsDir, appName, CFG_DEPLOY, OpenShift.CFG_DEPLOY, envType)
      print("statefulsets")
      upsert_config(openshift, nsAppsDir, appName, CFG_STATEFULSETS, OpenShift.CFG_STATEFULSETS, envType)
      print("routes")
      upsert_config(openshift, nsAppsDir, appName, CFG_ROUTES, OpenShift.CFG_ROUTE, envType)
      print("service")
      upsert_config(openshift, nsAppsDir, appName, CFG_SERVICE, OpenShift.CFG_SERVICE, envType)
      print("scaling")
      upsert_config(openshift, nsAppsDir, appName, CFG_AUTOSCALE, OpenShift.CFG_AUTOSCALE, envType)
      # Run actions at the end.
      print("run-deploy")
      svc_action(openshift, nsAppsDir, appName, ACT_DEPLOY, OpenShift.CFG_DEPLOY)
      print("watch")
      watch(openshift, nsAppsDir, appName, ACT_WATCH)
      print("check-status")
      check_status(openshift, nsAppsDir, appName, ACT_CHECK_STATUS)
  else:
    raise RuntimeError("No config found for", envType)

def check_status(openshift, nsAppsDir, appName, cfgDir):

  actionFile = os.path.join(nsAppsDir, appName, cfgDir, 'detail.json')
  actionDict = None

  if os.path.isfile(actionFile):
    with open(actionFile, 'r') as f:
      actionDict = json.load(f)

  if actionDict is not None:
    appType = actionDict['type']
    cfgName = actionDict['name']
    assertPath = actionDict['assertPath']
    comparator = actionDict['assertComparator']
    successVal = actionDict['successVal']
    print("Checking status for:", assertPath, comparator, successVal)

    deployTimeout = int(os.getenv('OPENSHIFT_DEPLOY_TIMEOUT', 300))
    limitBytes = int(os.getenv('OPENSHIFT_DEPLOY_LOGBYTES', 64000))
    pollInterval = 10
    maxRetries = (deployTimeout / pollInterval) - 1
    print("maxRetries:", maxRetries)

    svcStarted = False
    svcFailed = False
    loopCount = 0
    while not (svcStarted or svcFailed):
      if loopCount > 0:
        time.sleep(pollInterval)
      loopCount += 1
      ##Check the status!
      print("Checking status[", loopCount, "]")
      statusDict = openshift.get_status(appType, cfgName)
      #print("statusDict:", statusDict)
      print("statusDict:", statusDict['status'])
      actualValue = find_by_path(statusDict, assertPath)
      if (comparator == "=" and actualValue == successVal)\
          or (actualValue is not None and comparator == ">" and actualValue > successVal)\
          or (actualValue is not None and comparator == "<" and actualValue < successVal):
        print("Deployed OK")
        svcStarted = True
      if not svcStarted and loopCount >= maxRetries:
        svcFailed = True
    if not svcStarted:
      print("Deployment failed")
      raise RuntimeError("Deployment failed, or could not be proven")

def watch(openshift, nsAppsDir, appName, cfgDir):

  actionFile = os.path.join(nsAppsDir, appName, cfgDir, 'detail.json')
  actionDict = None
  appType = OpenShift.CFG_DEPLOY
  cfgName = appName
  logSuccessMsg = "Started Application"

  if os.path.isfile(actionFile):
    with open(actionFile, 'r') as f:
      actionDict = json.load(f)

  if actionDict is not None:
    appType = actionDict['type']
    cfgName = actionDict['name']
    logSuccessMsg = actionDict['success']
    print("Watching for:", logSuccessMsg)

    deployTimeout = int(os.getenv('OPENSHIFT_DEPLOY_TIMEOUT', 300))
    limitBytes = int(os.getenv('OPENSHIFT_DEPLOY_LOGBYTES', 64000))

    svcStarted = False
    svcFailed = False
    loopCount = 0
    while not (svcStarted or svcFailed):
      loopCount += 1
      ##Check the watch!
      print("Checking watch[", loopCount, "]")
      logStr = openshift.watch(appType, cfgName, logSuccessMsg, deployTimeout)
      # print("logStr:", logStr)
      if logSuccessMsg in logStr:
        print("Deployed OK")
        svcStarted = True
      if not svcStarted and loopCount >= 2:
        svcFailed = True
    if not svcStarted:
      print("Deployment failed")
      raise RuntimeError("Deployment failed, or could not be proven")

def svc_action(openshift, nsAppsDir, appName, cfgDir, opShiftCfg):

  actionFile = os.path.join(nsAppsDir, appName, cfgDir, 'detail.json')
  logTrackFile = os.path.join(nsAppsDir, appName, cfgDir, 'log-track.json')
  actionDict = None
  logSuccessMsg = "Started Application"

  if os.path.isfile(actionFile):
    with open(actionFile, 'r') as f:
      actionDict = json.load(f)

  if os.path.isfile(logTrackFile):
    with open(logTrackFile, 'r') as f:
      logTrackDict = json.load(f)
      logSuccessMsg = logTrackDict['success']

  if actionDict is not None:
    print("Looking for:", logSuccessMsg)
    cfgName = actionDict['name']
    sinceTime = datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')
    openshift.instantiate(opShiftCfg, cfgName, actionDict)

    deployTimeout = int(os.getenv('OPENSHIFT_DEPLOY_TIMEOUT', 300))
    limitBytes = int(os.getenv('OPENSHIFT_DEPLOY_LOGBYTES', 64000))

    svcStarted = False
    svcFailed = False
    loopCount = 0
    while not (svcStarted or svcFailed):
      loopCount += 1
      ##Check the logs!
      print("Checking logs[", loopCount, "]")
      logStr = openshift.followlog(opShiftCfg, cfgName, sinceTime, logSuccessMsg, deployTimeout, limitBytes)
      # print("logStr:", logStr)
      if logSuccessMsg in logStr:
        print("Deployed OK")
        svcStarted = True
      if not svcStarted and loopCount >= 2:
        svcFailed = True
    if not svcStarted:
      print("Deployment failed")
      raise RuntimeError("Deployment failed, or could not be proven")

def upsert_config(openshift, nsAppsDir, appName, cfgDir, opShiftCfg, envType):
  dckrCfgFile = None
  cfgAbsPath = None
  if cfgDir is None:
    cfgAbsPath = os.path.join(nsAppsDir, appName)
    dckrCfgFile = os.path.join(nsAppsDir, appName, 'dockerconfig.json')
  else:
    cfgAbsPath = os.path.join(nsAppsDir, appName, cfgDir)

  if os.path.isdir(cfgAbsPath):
    cfgFiles = os.listdir(cfgAbsPath)
    print("cfgFiles:", cfgFiles)
    for cfgFileName in cfgFiles:
      if cfgFileName == 'dockerconfig.json':
        # Ignore this as dealt with separately.
        continue
      cfgFile = os.path.join(cfgAbsPath ,cfgFileName)
      print("cfgFile:", cfgFile)
      if os.path.isfile(cfgFile) and not os.path.basename(cfgFile).startswith('.'):
        with open(cfgFile, 'r') as f:
          cfgDict = json.load(f)
          cfgName = cfgDict["metadata"]["name"]
          old_val = openshift.get_config(opShiftCfg, cfgName)
          print("old_val:", old_val)
          okToUpsert = True

          dckrCfgJsonB64 = None
          if OpenShift.CFG_SECRET == opShiftCfg and cfgDict['type'] == "kubernetes.io/dockerconfigjson" and dckrCfgFile is not None and os.path.isfile(dckrCfgFile):
            with open(dckrCfgFile, 'r') as f:
              dckrCfgJson = json.load(f)
              for key, value in dckrCfgJson['auths'].items():
                if ('password' in value):
                  #Replace username environment var key with value
                  envKeyUsername = value['username']
                  envValUsername = os.getenv(envKeyUsername)
                  if envValUsername is not None and envValUsername != "":
                    value['username'] = envValUsername
                  else:
                    print(envKeyUsername, "not defined.", cfgName, "secret will not be upserted.")
                    okToUpsert = False
                  #Replace password environment var key with value
                  envKeyPassword = value['password']
                  envValPassword = os.getenv(envKeyPassword)
                  if envValPassword is not None and envValPassword != "":
                    value['password'] = envValPassword
                  else:
                    print(envKeyPassword, "not defined.", cfgName, "secret will not be upserted.")
                    okToUpsert = False
                  #Replace auth (B64) environment var key with value
                  envKeysAuthRE = re.search(r"base64\((\w+:\w+)\)", value['auth'])
                  print("envKeysAuthRE:", envKeysAuthRE.group(1))
                  envKeysAuth = envKeysAuthRE.group(1)
                  envKeysList = envKeysAuth.split(":", 2)
                  envValAuthUsername = os.getenv(envKeysList[0])
                  envValAuthPassword = os.getenv(envKeysList[1])
                  if envValAuthUsername is not None and envValAuthUsername != "" and envValAuthPassword is not None and envValAuthPassword != "":
                    b64auth = b64encode((envValAuthUsername + ":" + envValAuthPassword).encode())
                    value['auth'] = b64auth.decode("ascii")
                  else:
                    print("Keys: ", envKeysAuth, "not defined.", cfgName, "secret will not be upserted.")
                    okToUpsert = False
              # print("dckrCfgJson:", dckrCfgJson)
              dckrCfgStr = json.dumps(dckrCfgJson)
              dckrCfgJsonB64 = b64encode(dckrCfgStr.encode())
            if dckrCfgJsonB64 is not None:
              cfgDict['data'].update({'.dockerconfigjson': dckrCfgJsonB64.decode("ascii")})

          prvSshKeyB64 = None
          if OpenShift.CFG_SECRET == opShiftCfg and cfgDict['type'] == "kubernetes.io/ssh-auth":
            if os.path.isfile(os.path.expanduser("~/.ssh/id_rsa")):
              with open(os.path.expanduser("~/.ssh/id_rsa"), 'r') as f:
                prvSshKey = f.read()
                prvSshKeyB64 = b64encode(prvSshKey.encode())
            else:
              okToUpsert = False
            if prvSshKeyB64 is not None:
              cfgDict['data'].update({'ssh-privatekey': prvSshKeyB64.decode("ascii")})

          if OpenShift.CFG_SECRET == opShiftCfg and cfgDict['type'] == "Opaque":
            envKey = None
            for key, value in cfgDict['data'].items():
              #print("key:", key, "value:", value)
              envKey = re.search(r"base64\((\w+)\)", value)
              #print(envKey.group(1))
              print("envKey:", envKey.group(1))
              envVal = os.getenv(envKey.group(1))
              if envVal is not None and envVal != "":
                cfgDict['data'][key] = b64encode(envVal.encode()).decode("ascii")
              else:
                print(envKey.group(1), "not defined.", cfgName, "secret will not be upserted.")
                okToUpsert = False
            if envKey is None:
              okToUpsert = False

          if cfgDict['kind'] == "ConfigMap":
            print("ConfigMap:", cfgDict['metadata']['name'])
            match = None
            for key, value in cfgDict['data'].items():
              print("key:", key, "value:", value)
              for match in re.finditer(r"\$\(var:(\w+)\)", value):
                print(match.group(1))
                print("match:", match.group(1))
                envVal = os.getenv(match.group(1))
                if envVal is not None and envVal != "":
                  cfgDict['data'][key] = value.replace(match.group(0), envVal)
                else:
                  print(match.group(1), "not defined.", cfgName, "ConfigMap will not be upserted.")
                  okToUpsert = False

          print("cfgDict", cfgDict)

          rVer = None
          if (old_val is not None and 'metadata' in old_val and 'resourceVersion' in old_val['metadata']):
            rVer = old_val['metadata']['resourceVersion']
          print("rVer:", rVer)
          svcIP = None
          if (old_val is not None and 'spec' in old_val and 'clusterIP' in old_val['spec']):
            svcIP = old_val['spec']['clusterIP']
          print("svcIP:", svcIP)
          if CFG_PVCLAIMS == cfgDir and old_val is not None and old_val["status"]["phase"] == "Bound":
            okToUpsert = False
            print(cfgName, "pvClaim is currently bound, it cannot be updated.")

          if cfgDict['kind'] == "DeploymentConfig":
            buildVsn = os.getenv('VERSION')
            print("buildVsn:", buildVsn)
            #TODO: Potentially need to loop over containers.
            imgName = cfgDict['spec']['template']['spec']['containers'][0]['image']
            print("imgName:", imgName)
            if buildVsn is not None and imgName is not None and ":" not in imgName:
              imgName = imgName + ":" + buildVsn
              print("imgName:", imgName)
              cfgDict['spec']['template']['spec']['containers'][0]['image'] = imgName

          #print(cfgName, " cfig: ", cfgJson)
          if cfgDict['kind'] == "Route" and envType != "prod":
            curHost = cfgDict['spec']['host']
            domPrefixYbsCom = re.search(r"(\w+)\.test\.os\.ybs\.com", curHost)
            domPrefixYbsCoUk = re.search(r"(\w+)\.nonprod\.services\.ybs\.co\.uk", curHost)
            #print("domPrefix:", domPrefix)
            hostSep = "."
            if domPrefixYbsCom is not None or domPrefixYbsCoUk is not None:
              hostSep = "-"
            newHost = curHost.replace(curHost, ("{}{}{}").format(openshift.namespace, hostSep, curHost))
            print("newHost:", newHost)
            cfgDict['spec']['host'] = newHost

          if 'metadata' in cfgDict:
            if 'annotations' not in cfgDict['metadata']:
              cfgDict['metadata']['annotations'] = {}
            deployerTag = os.getenv('OPENSHIFT_DEPLOYER_TAG', openshift.username)
            cfgDict['metadata']['annotations'].update({'ybs/deployed-by': deployerTag})
            cfgDict['metadata']['annotations'].update({'ybs/deployed-date': datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%SZ')})
          if rVer is not None:
            cfgDict['metadata'].update({'resourceVersion': rVer})
          if svcIP is not None:
            cfgDict['spec'].update({'clusterIP': svcIP})
          # print("cfgJson: ", cfgJson)
          if okToUpsert:
            print("Upserting")
            openshift.upsert_config(opShiftCfg, cfgName, cfgDict, old_value=old_val)
      else:
        print("cfgFile not found (or hidden):", cfgFile)
  else:
    print("cfgDir not found:", cfgAbsPath)

def find_by_path(dictin, element):
  '''Finds a value in a dictionary at the path specified.'''
  keys = element.split('.')
  rv = dictin
  for key in keys:
    if key in rv:
      rv = rv[key]
    else:
      rv = None
      break
  return rv

def get_proxies():

    proxies = {
        'http':None,
        'https':None,
        'no':None,
        'no_proxy':None
    }
    envProxy = os.getenv('PYHTTP_PROXY')
    if envProxy is not None:
        proxies['http'] = envProxy
    envProxySSL = os.getenv('PYHTTPS_PROXY')
    if envProxySSL is not None:
        proxies['https'] = envProxySSL
    envNoProxy = os.getenv('PYNO_PROXY')
    if envNoProxy is not None:
        proxies['no'] = envNoProxy
        proxies['no_proxy'] = envNoProxy
    print("proxies:", proxies)
    return proxies

def main():
    os_password = os.getenv('OPENSHIFT_DEPLOY_PASSWD')
    if os_password is None or os_password == "":
        os_password = b64decode(os.getenv('OPENSHIFT_DEPLOY_PASSWD_B64')).decode("ascii")
    openshift = OpenShift(
        os.getenv('OPENSHIFT_DEPLOY_SUBDOMAIN'),
        os.getenv('OPENSHIFT_DEPLOY_NAMESPACE'),
        os.getenv('OPENSHIFT_DEPLOY_USER'),
        os_password.strip(),
        get_proxies()
    )

    if 'master' in sys.argv:
        if  os.getenv('CI') or input("this script is meant to be run on CI, are you sure you want to run it locally? (y/N) ").lower() == 'y':
            update_config(openshift)
    else:
        update_config(openshift)
    print("FINISHED")

if __name__ == '__main__':
    main()
