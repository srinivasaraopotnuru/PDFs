mkdir -p target
curl -X PUT "https://ds-mocks-dev.apps.ostest.ybs.com/mockserver/clear?type=EXPECTATIONS" > target/clear.txt
