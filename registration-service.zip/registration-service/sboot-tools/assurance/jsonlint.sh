#!/bin/bash

function lint_all() {
	local result=0
	while read filename; do
		echo -e "Testing: $filename"
    jsonlint $filename > /dev/null || result=1;
	done
	[ $result -eq 0 ]
}

find . -type f -path '*openshift-config*/*' -name '*.json' | lint_all
