#!/usr/bin/env bash
set -e

if [ "$OPENSHIFT_DEPLOY_USER" == "" ]; then
  OPENSHIFT_DEPLOY_USER=$OS_USERNAME
fi
if [ "$OPENSHIFT_DEPLOY_PASSWD" == "" ]; then
  OPENSHIFT_DEPLOY_PASSWD=$OS_PASSWORD
fi
if [ "$OPENSHIFT_DEPLOY_PASSWD" == "" ]; then
  OPENSHIFT_DEPLOY_PASSWD=$(echo -n "$OPENSHIFT_DEPLOY_PASSWD_B64" | base64 --decode)
fi
if [ "" == "$OPENSHIFT_DEPLOY_USER" ] || [ "" == "$OPENSHIFT_DEPLOY_PASSWD" ]; then
  echo "ERROR: OPENSHIFT_DEPLOY_USER or OPENSHIFT_DEPLOY_PASSWD is not set"
  echo "       If running locally you you can use: \`. ./sboot-tools/set-env.sh\` to persist env vars in this shell"
fi

OPENSHIFT_DEPLOY_HOST=$OPENSHIFT_DEPLOY_SUBDOMAIN.$OPENSHIFT_DEPLOY_DOMAIN
echo "Connecting to: $OPENSHIFT_DEPLOY_HOST..."
oc login -u "$OPENSHIFT_DEPLOY_USER" -p "$OPENSHIFT_DEPLOY_PASSWD" "$OPENSHIFT_DEPLOY_HOST" --certificate-authority="$CI_SERVER_TLS_CA_FILE"
oc project "$OPENSHIFT_DEPLOY_NAMESPACE"
oc status | grep "$OPENSHIFT_DEPLOY_NAMESPACE.*$OPENSHIFT_DEPLOY_HOST"
