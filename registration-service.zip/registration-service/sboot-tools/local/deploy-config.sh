#!/usr/bin/env bash
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
. "$gwd/sboot-tools/local/gradle-env.sh"
echo pwd=`pwd`

export ARTIFACTORY_USERNAME=$AD_USERNAME
export ARTIFACTORY_PASSWORD=`echo -n $AD_PASSWORD_B64 | base64 --decode`

. "$gwd/sboot-tools/local/check_virtenv.sh"

export VERSION=`cat $gwd/build/version.txt`
pipenv run python "$gwd/sboot-tools/deploy/deploy-config.py"

##Clean up env vars
export ARTIFACTORY_USERNAME=
export ARTIFACTORY_PASSWORD=
