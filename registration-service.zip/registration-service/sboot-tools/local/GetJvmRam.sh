#Gets the Container's RAM in bytes and multiplies by 70% to get a value for the JVM to use.
#If the container has more than 1 Gig of RAM, calculate JVM RAM based on the value of 1Gig.
#Divides final result to work out value in MiB.
CRAM=$(cat /sys/fs/cgroup/memory/memory.limit_in_bytes)
if [ $CRAM -gt 1073741824 ]; then
    CRAM=1073741824
fi
echo $(( $CRAM * 70 / 100 / 1024 / 1024 ))