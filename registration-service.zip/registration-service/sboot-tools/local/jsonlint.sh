#!/usr/bin/env sh
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
#cd "$gwd"
echo Checking installed version...
apglint_vsn=`npm list -g --depth=0 jsonlint-cli | grep jsonlint-cli`
echo Found version: $apglint_vsn

#Check if jsonlint-cli not already installed
if [ "$apglint_vsn" = "" ]; then
    echo Need to install jsonlint-cli
    ### Install jsonlint-cli node package
    if [ "$(uname -s)" = "Linux" ]; then
        #Need sudo here. (write access to /usr/local/lib is required)
        sudo npm install -g jsonlint-cli
    elif [[ "$(uname -s)" == MINGW* ]]; then
        npm install -g jsonlint-cli
    fi
fi

jsonlint-cli "$gwd/openshift-config/**/*.json"
