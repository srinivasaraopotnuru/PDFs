#!/usr/bin/env bash
##############################
### Expects optional parameter to determine the Apigee environment to test against,
### e.g: dev test etc.
##############################
export gwd=`git rev-parse --show-toplevel`
#echo $gwd
#cd "$gwd"

source "$gwd/sboot-tools/local/check_virtenv.sh"
apigeeEnv=${1:-dev}
unitTestFeature=${2:-dev}
#Include function to write to .env file.
. ./sboot-tools/common/functions.sh
WritePropertyInFile .env TARGET_ENV $apigeeEnv

echo Running against APIGEE $apigeeEnv environment


#Use pytest -s to output stdout.
pipenv run unit-test --junit-xml=target/unit-tests.xml
