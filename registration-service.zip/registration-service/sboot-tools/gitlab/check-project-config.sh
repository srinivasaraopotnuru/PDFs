#!/usr/bin/env bash
set -e

# Get a GITLAB_TOKEN token and export to GITLAB_TOKEN before running this script
if [ "$GITLAB_TOKEN" = "" ]; then
  echo "Please export your GitLab API token as GITLAB_TOKEN" >&2
  exit 1
fi
mkdir -p target

# Source the gitlab utils
. $(dirname "$0")/gitlab-utils.sh
GetAllDomainProjects

EXITCODE=0
for PROJ_ID in $PROJ_IDS
do
  PROJECT=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID")
  # echo "$PROJECT" | jq
  PROJECT_NAME=$(echo "$PROJECT" | jq -r '.name')
  PROJECT_PATH=$(echo "$PROJECT" | jq -r '.path_with_namespace')
  echo "Found project: $PROJECT_NAME : $PROJECT_PATH (ID:$PROJ_ID)"
  ARCHIVED=$(echo "$PROJECT" | jq -r '.archived')
  if [ "$ARCHIVED" == "false" ] && [[ ! $PROJECT_NAME =~ .+-mainline-trunk$ ]] && grep -qv "$PROJECT_PATH" <<<"$EXCLUDED_PROJECTS" ; then
    MERGE_APPROVALS=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/approvals")
    # echo -n "MERGE_APPROVALS="
    # echo "$MERGE_APPROVALS" | jq
    MR_AUTHOR_APPROVAL=$(echo "$MERGE_APPROVALS" | jq -r '.merge_requests_author_approval')
    MR_DISABLE_OVERRIDE=$(echo "$MERGE_APPROVALS" | jq -r '.disable_overriding_approvers_per_merge_request')
    MR_RESET_ON_PUSH=$(echo "$MERGE_APPROVALS" | jq -r '.reset_approvals_on_push')
    MASTER_PUSH_PROTECTED=$(echo "$PROTECTED_BRANCHES" | jq '.[] | select(.name == "master") | .push_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    PROTECTED_BRANCHES=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/protected_branches")
    # echo -n "PROTECTED_BRANCHES="
    # echo "$PROTECTED_BRANCHES" | jq
    MASTER_PUSH_PROTECTED=$(echo "$PROTECTED_BRANCHES" | jq '.[] | select(.name == "master") | .push_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    MASTER_MERGE_PROTECTED=$(echo "$PROTECTED_BRANCHES" | jq '.[] | select(.name == "master") | .merge_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    PROTECTED_ENVS=$(curl -ks --header "PRIVATE-TOKEN: $GITLAB_TOKEN" "https://ecommgit.ybs.com/api/v4/projects/$PROJ_ID/protected_environments")
    # echo -n "PROTECTED_ENVS="
    # echo "$PROTECTED_ENVS" | jq
    FLEX_ENV_PROTECTED=$(echo "$PROTECTED_ENVS" | jq '.[] | select(.name == "staging" or .name == "flex") | .deploy_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    OS3FLEX_ENV_PROTECTED=$(echo "$PROTECTED_ENVS" | jq '.[] | select(.name == "os3/flex") | .deploy_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    OS4FLEX_ENV_PROTECTED=$(echo "$PROTECTED_ENVS" | jq '.[] | select(.name == "os4/flex") | .deploy_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    PROD_ENV_PROTECTED=$(echo "$PROTECTED_ENVS" | jq '.[] | select(.name == "production" or .name == "prod") | .deploy_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    OS3PROD_ENV_PROTECTED=$(echo "$PROTECTED_ENVS" | jq '.[] | select(.name == "os3/prod") | .deploy_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    OS4PROD_ENV_PROTECTED=$(echo "$PROTECTED_ENVS" | jq '.[] | select(.name == "os4/prod") | .deploy_access_levels[] | select( .user_id == null and .group_id == null ) | .access_level')
    APPROVE_ENV_PROTECTED=$(echo "$PROTECTED_ENVS" | jq '.[] | select(.name == "prod/approve") | .deploy_access_levels[] | .group_id')
    VISIBILITY=$(echo "$PROJECT" | jq -r '.visibility')
    PIPELINE_MERGE=$(echo "$PROJECT" | jq -r '.only_allow_merge_if_pipeline_succeeds')
    DISCUSSION_MERGE=$(echo "$PROJECT" | jq -r '.only_allow_merge_if_all_discussions_are_resolved')
    APPROVALS_MERGE=$(echo "$PROJECT" | jq -r '.approvals_before_merge')
    PROJ_TOPICS=$(echo "$PROJECT" | jq -r '.tag_list | @sh' | sed "s/' '/,/" | tr \', ,)
    echo "PROJ_TOPICS=$PROJ_TOPICS"
    echo "VISIBILITY=$VISIBILITY, MASTER_PUSH_PROTECTED=$MASTER_PUSH_PROTECTED, MASTER_MERGE_PROTECTED=$MASTER_MERGE_PROTECTED"
    echo "FLEX_ENV_PROTECTED=$FLEX_ENV_PROTECTED, OS3FLEX_ENV_PROTECTED=$OS3FLEX_ENV_PROTECTED, OS4FLEX_ENV_PROTECTED=$OS4FLEX_ENV_PROTECTED"
    echo "PROD_ENV_PROTECTED=$PROD_ENV_PROTECTED, OS3PROD_ENV_PROTECTED=$OS3PROD_ENV_PROTECTED, OS4PROD_ENV_PROTECTED=$OS4PROD_ENV_PROTECTED"
    echo "APPROVE_ENV_PROTECTED=$APPROVE_ENV_PROTECTED"
    echo "PIPELINE_MERGE=$PIPELINE_MERGE, DISCUSSION_MERGE=$DISCUSSION_MERGE, APPROVALS_MERGE=$APPROVALS_MERGE"
    echo "MR_AUTHOR_APPROVAL=$MR_AUTHOR_APPROVAL, MR_DISABLE_OVERRIDE=$MR_DISABLE_OVERRIDE, MR_RESET_ON_PUSH=$MR_RESET_ON_PUSH"
    if [ "$VISIBILITY" != "internal" ]; then
      echo "ERROR: Invalid VISIBILITY" >&2
      EXITCODE=$((EXITCODE+1))
    fi
    if [ "$MR_AUTHOR_APPROVAL" == "true" ]; then
      echo "ERROR: Invalid MR_AUTHOR_APPROVAL" >&2
      EXITCODE=$((EXITCODE+1))
    fi
    if [ "$MR_DISABLE_OVERRIDE" != "true" ]; then
      echo "ERROR: Invalid MR_DISABLE_OVERRIDE" >&2
      EXITCODE=$((EXITCODE+1))
    fi
    if [ "$MR_RESET_ON_PUSH" != "true" ]; then
      echo "ERROR: Invalid MR_RESET_ON_PUSH" >&2
      EXITCODE=$((EXITCODE+1))
    fi
    if [[ ! $PROJ_TOPICS =~ .*,api-versions,.* ]]; then
      if [ "$MASTER_PUSH_PROTECTED" == "40" ]; then
        echo "WARNING: MASTER_PUSH_PROTECTED not adequate enough"
      elif [ "$MASTER_PUSH_PROTECTED" != "0" ]; then
        echo "ERROR: Invalid MASTER_PUSH_PROTECTED" >&2
        EXITCODE=$((EXITCODE+1))
      fi
      if [ "$MASTER_MERGE_PROTECTED" != "30" ]; then
        echo "ERROR: Invalid MASTER_MERGE_PROTECTED" >&2
        EXITCODE=$((EXITCODE+1))
      fi
      if [[ ! $PROJ_TOPICS =~ .*,not-deployable,.* ]]; then
        if [ "$APPROVE_ENV_PROTECTED" != "151" ]; then
          echo "ERROR: Invalid APPROVE_ENV_PROTECTED" >&2
          EXITCODE=$((EXITCODE+1))
        fi
        if [[ $PROJ_TOPICS =~ .*,API,.* ]]; then
          if [ "$FLEX_ENV_PROTECTED" != "30" ]; then
            echo "ERROR: Invalid FLEX_ENV_PROTECTED" >&2
            EXITCODE=$((EXITCODE+1))
          fi
          if [ "$PROD_ENV_PROTECTED" != "40" ]; then
            echo "ERROR: Invalid PROD_ENV_PROTECTED" >&2
            EXITCODE=$((EXITCODE+1))
          fi
        else
          if [[ ! $PROJ_TOPICS =~ .*,OS4-Migrated,.* ]]; then
            if [ "$OS3FLEX_ENV_PROTECTED" != "30" ]; then
              echo "ERROR: Invalid OS3FLEX_ENV_PROTECTED" >&2
              EXITCODE=$((EXITCODE+1))
            fi
            if [ "$OS3PROD_ENV_PROTECTED" != "40" ]; then
              echo "ERROR: Invalid OS3PROD_ENV_PROTECTED" >&2
              EXITCODE=$((EXITCODE+1))
            fi
          fi
          if [ "$OS4FLEX_ENV_PROTECTED" != "30" ]; then
            echo "ERROR: Invalid OS4FLEX_ENV_PROTECTED" >&2
            EXITCODE=$((EXITCODE+1))
          fi
          if [ "$OS4PROD_ENV_PROTECTED" != "40" ]; then
            echo "ERROR: Invalid OS4PROD_ENV_PROTECTED" >&2
            EXITCODE=$((EXITCODE+1))
          fi
        fi
      fi
      if [[ ! $PROJ_TOPICS =~ .*,module,.* ]]; then
        if [ "$PIPELINE_MERGE" != "true" ]; then
          echo "ERROR: Invalid PIPELINE_MERGE" >&2
          EXITCODE=$((EXITCODE+1))
        fi
      fi
      if [ "$DISCUSSION_MERGE" != "true" ]; then
        echo "ERROR: Invalid DISCUSSION_MERGE" >&2
        EXITCODE=$((EXITCODE+1))
      fi
    fi
    echo "--------------------"
  fi
done

echo "--------------------"
echo "FINISHED: $EXITCODE invalid project configs found"
exit $EXITCODE
