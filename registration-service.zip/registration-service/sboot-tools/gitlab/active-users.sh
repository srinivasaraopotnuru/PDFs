#!/usr/bin/env bash
set -e

# Get a GITLAB_TOKEN token and export to GITLAB_TOKEN before running this script
if [ "$GITLAB_TOKEN" = "" ]; then
  echo "Please export your GitLab API token as GITLAB_TOKEN" >&2
  exit
fi
mkdir -p target

# Source the gitlab utils
. $(dirname "$0")/gitlab-utils.sh
GetAllUsers

jq -s 'add' target/users*.json | jq -r '.[] | select(.state == "active") | "\(.username) \(.name)"' | tee target/users.json
echo "View results in: target/users.json"
