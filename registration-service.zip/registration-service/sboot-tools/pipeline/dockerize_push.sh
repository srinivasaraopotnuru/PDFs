#!/usr/bin/env sh

set -e

##If DOCKER_REGISTRY_PUSH is not defined, use DOCKER_REGISTRY
if [ "$DOCKER_REGISTRY_PUSH" == "" ]; then
  DOCKER_REGISTRY_PUSH="$DOCKER_REGISTRY"
fi

echo ""
echo "Logging in with username: "$ARTIFACTORY_USERNAME
docker login -u "$ARTIFACTORY_USERNAME" -p "$ARTIFACTORY_PASSWORD" $DOCKER_REGISTRY_PUSH
echo ""

IMAGE_NAME=$DOCKER_REGISTRY_PUSH/$DOCKER_NAME

docker push $IMAGE_NAME:$VERSION
docker tag $IMAGE_NAME:$VERSION $IMAGE_NAME:latest
docker push $IMAGE_NAME:latest
