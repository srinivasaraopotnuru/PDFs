#!/bin/sh
export gwd=$(git rev-parse --show-toplevel)

####################
## Example Usage: ##
## From File:
## ./sboot-tools/apigee/convert-swagger.sh svc-swagger.json > api-swagger.json
## From URL:
## curl https://ds-savings-test.test.os.ybs.com/savings/v1/web-account/v2/api-docs | ./sboot-tools/apigee/convert-swagger.sh > api-swagger.json
####################

#Load config
. "$gwd/create_new_api.cfg"
newContextRoot="/${newDomainGroup}/${newSvcVersion}/${newEntity}"

jq '.host = "api-digital-dev.ybs.co.uk" | .basePath = "'"$newContextRoot"'" | walk(if type == "object" then with_entries(if .key | contains("'"$newContextRoot"/'") then .key |= sub("'"$newContextRoot"'";"") else . end) else . end)' "$@"
