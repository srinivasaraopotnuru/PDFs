source /oracle_scripts/check_db.sh

echo "Wait until DB is up"
check_db
while [ $DB_OK = 1 ]
do
  echo "DB not up yet. Sleeping for 10 seconds (CTRL+C to exit)"
  sleep 10
  check_db
done

echo "Check the user tablespace has been created"
check_user_tablespace
while [ $USERS_TABLESPACE != 1 ]
do
    echo "User tablespace has not been created yet. Sleeping for 10 seconds (CTRL+C to ext)"
    sleep 10
    check_user_tablespace
done

echo "Creating registration user"
$ORACLE_HOME/bin/sqlplus sys/Oracle18@localhost/XEPDB1 as sysdba @/oracle_scripts/create_registration_user.sql
