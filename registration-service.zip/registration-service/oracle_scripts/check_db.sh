function check_db {
  echo Checking if I can run SQL against the DB
  RETVAL=`/opt/oracle/product/18c/dbhomeXE/bin/sqlplus -silent sys/Oracle18@localhost/XEPDB1 as sysdba <<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
SELECT 'Alive' FROM dual;
EXIT;
EOF`

  if [ "$RETVAL" = "Alive" ]; then
    echo RETVAL: $RETVAL
    DB_OK=0
  else
    echo RETVAL: $RETVAL
    DB_OK=1
  fi
}

function check_user_tablespace {
  USERS_TABLESPACE=`/opt/oracle/product/18c/dbhomeXE/bin/sqlplus -silent sys/Oracle18@localhost/XEPDB1 as sysdba <<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
SELECT COUNT(*) FROM USER_TABLESPACES WHERE TABLESPACE_NAME = 'USERS';
EXIT;
EOF`
echo USERS_TABLESPACE: $USERS_TABLESPACE
}
